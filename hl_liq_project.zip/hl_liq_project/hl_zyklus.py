#!/usr/bin/env python3
"""
Zyklus-Studie (U141): Rallyes, Rücksetzer, Warnsignale und „Dip kaufen, laufen lassen“ (Version 2026-09-23.62).

Regeln vorab in KONZEPT_Zyklen.md (09.10.2026, vor jedem Lauf auf echten Daten). Nur Bericht, nur lesend:
  - Tagesschlüsse aus makro.db (Coin Metrics: BTC ab 2013, ETH und XMR ab 2016, ZEC ab 2017); HYPE aus swing.db und Gold (PAXG)
    aus regime.db beschreibend; Funding, Binance-OI und Fear & Greed aus makro.db und swing.db;
  - Teil A Zyklen: Directional Change mit 10/20/30 % gegen 1000 Vorzeichen-Surrogate (Drift und Schwankung bleiben);
  - Teil B Strategien: HODL, T200, VOL, Z1 Dip halten, Z2 raus bei Überhitzung, Z3 Ziel bei der typischen Rallye, Z0 Zufall;
    Urteile B1 Timing (gegen die Surrogate) und B2 sicherer als HODL (Sharpe im Kern-Portfolio BTC+ETH, Blockbootstrap);
  - Teil C Warnsignale: OI-Überhitzung, Funding-Druck, RSI ≥ 80, Gier ≥ 80 gegen einen Rücksetzer in 14 Tagen (RR gegen die Surrogate);
  - Teil D Gegenprobe: Z1/Z2 mit echter Ausführung (hl_swing auf den Binance-30-min-Kerzen ab 2020), beschreibend.
Z1/Z2 sind dieselben Regeln wie im TradeLabor (hl_swing, Art „dip“); die schnelle Rechnung über viele Pfade gleichzeitig ist im
Selbsttest Tag für Tag gegen hl_swing.einstieg/plan/nachfuehren geprüft. Schreibt nichts; berührt weder hl_liq.db noch Prognose,
Fusion, v3, Kaskaden oder Labor.

  python3 hl_zyklus.py --studie --db <hl_liq.db>   Debug-Bericht „★ Zyklen: Rallyes, Rücksetzer, Warnsignale (U141)“
  python3 hl_zyklus.py --selbsttest                Bausteine, Gleichheit mit hl_swing, Kausalität, Nulltests, Positivkontrollen
"""
from __future__ import annotations

import argparse
import calendar
import math
import os
import sqlite3
import sys
import time

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

import hl_makro as MK
import hl_regime as RG
import hl_swing as SW

VERSION_MODUL = "2026-09-23.62"
TAG = 86400
COINS_TEST = ("BTC", "ETH", "ZEC", "XMR")                 # Tests in A, B1, C
KERN = ("BTC", "ETH")                                     # Kern-Portfolio (B2)
CM = {"BTC": "cm:btc:PriceUSD", "ETH": "cm:eth:PriceUSD", "ZEC": "cm:zec:PriceUSD", "XMR": "cm:xmr:PriceUSD"}
START = {"BTC": "2013-01-01", "ETH": "2016-01-01", "XMR": "2016-01-01", "ZEC": "2017-01-01"}     # Studie ab (S)
VORLAUF_TAGE = 400                                        # so viele Tage vor S werden mitgeladen (σ, Mittel, Median)
B_VORLAUF = 365                                           # Teil B frühestens Reihenbeginn + 365 Tage
B_MIN_TAGE = 365                                          # Teil B nur mit mindestens so vielen Bewertungstagen
SCHWELLEN = (0.10, 0.20, 0.30)
SCHWELLEN_GOLD = (0.03, 0.05, 0.10)
KOSTEN = {"BTC": 0.0010, "ETH": 0.0010}                   # je Seite (Kassa, mit Abstand zur Mitte)
KOSTEN_STANDARD = 0.0020
LUECKE_MAX = 3
N_SURR_A = 1000
N_SURR_B = 200
N_SURR_C = 1000
N_PLACEBO = 200
N_BOOT_B2 = 2000
N_BOOT_C = 1000
BLOCK_B2 = 30
BLOCK_C = 60
EREIGNIS_TAGE = 14
EREIGNIS_K = 1.5
EREIGNIS_FEST = 0.10
ALPHA = 0.05
SAAT = 141
CHUNK = 250                                               # Surrogate je Rechenblock (Speicher)
Z1, Z2, ZZ = "zyklus_dip", "zyklus_dip_heiss", "zyklus_dip_zufall"
STRATEGIE_TITEL = {"HODL": "HODL (kaufen und halten)", "T200": "T200 (über dem 200-Tage-Mittel)", "VOL": "VOL (Schwankung gesteuert)",
                   "Z1": "Z1 Dip halten", "Z2": "Z2 Dip, raus bei Überhitzung", "Z3": "Z3 Dip, raus am typischen Ziel",
                   "Z0": "Z0 Zufall (Ausstiege wie Z1)"}
B_FOLGE = ("HODL", "T200", "VOL", "Z1", "Z2", "Z3")
B2_TESTS = ("T200", "VOL", "Z1", "Z2", "Z3")
B1_TESTS = ("Z1", "Z2", "Z3")
SIGNALE = (("C1", "OI-Überhitzung (Perzentil ≥ 0,90 der 90 Tage)"), ("C2", "Funding-Druck z30 ≥ 2"), ("C3", "RSI(14) ≥ 80"),
           ("C4", "Gier: Fear & Greed ≥ 80"))
HWZ = SW.HWZ


# ================================================================================================ Ausgabe

def _de(x, nd: int = 2, vz: bool = False) -> str:
    return RG._de(x, nd, vz)


def _pz(p) -> str:
    return RG._pz(p)


def _dt(tag) -> str:
    return time.strftime("%d.%m.%Y", time.gmtime(int(tag) * TAG)) if tag is not None else "—"


def _pl(x_log, nd: int = 0, vz: bool = True) -> str:
    """Log-Rendite als Prozent (e^x − 1)."""
    if x_log is None or not np.isfinite(x_log):
        return "—"
    return _de((math.exp(float(x_log)) - 1.0) * 100.0, nd, vz) + " %"


def _pr(x, nd: int = 0, vz: bool = False) -> str:
    """Anteil als Prozent."""
    if x is None or not np.isfinite(x):
        return "—"
    return _de(float(x) * 100.0, nd, vz) + " %"


def _tausend(n) -> str:
    return f"{int(n):,}".replace(",", ".")


def _px(x) -> str:
    """Kurs lesbar mit deutschem Komma: ab 1000 ohne Nachkommastellen mit Tausenderpunkt, darunter 1–4 Stellen."""
    if x is None or not np.isfinite(x):
        return "—"
    x = float(x)
    if abs(x) >= 1000:
        return _tausend(round(x))
    nd = 1 if abs(x) >= 100 else (2 if abs(x) >= 1 else 4)
    return _de(x, nd)


def _n(k: int, ein: str, viele: str) -> str:
    return f"{k} {ein if k == 1 else viele}"


def _mal(r) -> str:
    """Kursveränderung: bis +900 % in Prozent, darüber als Vielfaches (×)."""
    if r is None or not np.isfinite(r):
        return "—"
    return f"×{_tausend(round(1 + r))}" if r >= 9 else _pr(r, 0, True)


def _nanmed(x) -> float:
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]
    return float(np.median(x)) if len(x) else float("nan")


def _nanq(x, q) -> float:
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]
    return float(np.quantile(x, q)) if len(x) else float("nan")


def tag_aus(datum: str) -> int:
    return calendar.timegm(time.strptime(datum, "%Y-%m-%d")) // TAG


# ================================================================================================ Daten (nur lesend)

def achse(tage, werte, ab_tag: int | None = None) -> dict | None:
    """
    Tageswerte -> lückenlose Tagesachse. Doppelte Tage: der letzte zählt. Lücken bis LUECKE_MAX Tage: der letzte Kurs gilt weiter
    (Rendite 0, der volle Schritt am ersten Tag danach). Längere Lücken: die Reihe beginnt nach der letzten solchen Lücke
    (KONZEPT_Zyklen.md 12) -- der Bericht nennt sie.
    """
    tage = np.asarray(tage, dtype=np.int64); werte = np.asarray(werte, dtype=float)
    ok = np.isfinite(werte) & (werte > 0)
    tage, werte = tage[ok], werte[ok]
    if ab_tag is not None:
        m = tage >= ab_tag; tage, werte = tage[m], werte[m]
    if not len(tage):
        return None
    s = np.argsort(tage, kind="stable"); tage, werte = tage[s], werte[s]
    letzte = np.concatenate([tage[1:] != tage[:-1], [True]]); tage, werte = tage[letzte], werte[letzte]
    lang = np.nonzero(np.diff(tage) > LUECKE_MAX + 1)[0]
    lange = [(int(tage[i]), int(tage[i + 1])) for i in lang]
    if len(lang):
        a = int(lang[-1]) + 1; tage, werte = tage[a:], werte[a:]
    t0 = int(tage[0]); n = int(tage[-1]) - t0 + 1
    c = np.full(n, np.nan); c[tage - t0] = werte
    gef = 0
    for i in range(1, n):
        if not np.isfinite(c[i]):
            c[i] = c[i - 1]; gef += 1
    return {"tag0": t0, "c": c, "gefuellt": gef, "lange_luecken": lange}


def ausrichten(R: dict, tage, werte) -> np.ndarray:
    """Externe Tagesreihe auf die Achse der Kursreihe R legen (fehlend = NaN)."""
    n = len(R["c"]); out = np.full(n, np.nan)
    tage = np.asarray(tage, dtype=np.int64); werte = np.asarray(werte, dtype=float)
    i = tage - R["tag0"]; m = (i >= 0) & (i < n) & np.isfinite(werte)
    out[i[m]] = werte[m]
    return out


def reihe_bauen(coin: str, ax: dict, s_tag: int | None, rolle: str, quelle: str, schwellen=SCHWELLEN, F: dict | None = None,
                datenbeginn: int | None = None) -> dict:
    """Kursreihe eines Coins mit Studienbeginn S (Index), Beginn von Teil B (Index oder None) und Kosten je Seite."""
    c = ax["c"]; n = len(c); t0 = ax["tag0"]
    S = max(0, int(s_tag) - t0) if s_tag is not None else 0
    B = max(S, B_VORLAUF)
    if n - B < B_MIN_TAGE:
        B = None
    return {"coin": coin, "quelle": quelle, "tag0": t0, "c": c, "n": n, "S": S, "B": B, "F": F, "oi": None, "fng": None,
            "kosten": KOSTEN.get(coin, KOSTEN_STANDARD), "rolle": rolle, "schwellen": tuple(schwellen),
            "gefuellt": ax["gefuellt"], "lange_luecken": ax["lange_luecken"], "datenbeginn": datenbeginn if datenbeginn is not None else t0}


def _schluss_aus_kerzen(K: dict | None) -> dict | None:
    """30-min-Kerzen -> Tagesschlüsse voller Tage (hl_swing.tagesreihen)."""
    if K is None:
        return None
    T = SW.tagesreihen(K)
    if T is None:
        return None
    ok = T["voll"] & np.isfinite(T["c"])
    return achse((T["d0"] + np.arange(T["nd"]))[ok], T["c"][ok])


def _ro(pfad: str):
    if not os.path.exists(pfad):
        return None
    return sqlite3.connect(f"file:{pfad}?mode=ro", uri=True, timeout=10)


def daten_laden(db: str, log=print) -> dict:
    """Alle Reihen der Studie aus makro.db, swing.db und regime.db (nur lesend)."""
    pfad_mk, pfad_sw, pfad_rg = MK.makro_pfad(db), SW.swing_pfad(db), RG.regime_pfad(db)
    reihen: dict = {}; info: dict = {"pfade": {"makro": pfad_mk, "swing": pfad_sw, "regime": pfad_rg}, "fehlt": []}
    ext: dict = {}
    con = MK.lesen(pfad_mk)
    if con is None:
        info["fehlt"].append(f"makro.db fehlt ({pfad_mk})")
    else:
        try:
            Rh = MK.Reihen(con)
            for coin, name in CM.items():
                t, w = Rh(name)
                if not len(t):
                    info["fehlt"].append(f"{coin}: {name} fehlt in makro.db"); continue
                s_tag = tag_aus(START[coin])
                ax = achse(t, w, ab_tag=s_tag - VORLAUF_TAGE)
                if ax is None or ax["tag0"] + len(ax["c"]) - 1 < s_tag + 365:
                    info["fehlt"].append(f"{coin}: zu wenig Tage in makro.db"); continue
                reihen[coin] = reihe_bauen(coin, ax, s_tag, "test", "Coin Metrics", datenbeginn=int(t.min()))
            for k in ("bnc:funding_btc_tag", "bnc:oi_btc_coins", "fng:wert"):
                ext[k] = Rh(k)
        finally:
            con.close()
    if "BTC" in reihen:
        t, w = ext.get("bnc:funding_btc_tag", (np.zeros(0), np.zeros(0)))
        ok = np.isfinite(w)
        reihen["BTC"]["F"] = {"ts": (np.asarray(t)[ok] * TAG).astype(np.int64), "rate": np.asarray(w, dtype=float)[ok]} if ok.any() else None
        t, w = ext.get("bnc:oi_btc_coins", (np.zeros(0), np.zeros(0)))
        reihen["BTC"]["oi"] = ausrichten(reihen["BTC"], t, w) if len(t) else None
    for coin in ("BTC", "ETH"):
        if coin in reihen:
            t, w = ext.get("fng:wert", (np.zeros(0), np.zeros(0)))
            reihen[coin]["fng"] = ausrichten(reihen[coin], t, w) if len(t) else None
    con = _ro(pfad_sw)
    if con is None:
        info["fehlt"].append("swing.db fehlt (HYPE und Funding von ETH/ZEC/XMR)")
    else:
        try:
            for coin in ("ETH", "ZEC", "XMR"):
                if coin in reihen:
                    F = SW.funding_lesen(con, coin)
                    reihen[coin]["F"] = F if len(F["ts"]) else None
            K = SW.kerzen_lesen(con, "HYPE")
            ax = _schluss_aus_kerzen(K)
            if ax is not None and len(ax["c"]) >= 120:
                F = SW.funding_lesen(con, "HYPE")
                reihen["HYPE"] = reihe_bauen("HYPE", ax, None, "beschreibend", "Binance-Perp (swing.db)", F=F if len(F["ts"]) else None)
            else:
                info["fehlt"].append("HYPE: keine Tageskerzen in swing.db")
        except sqlite3.Error as e:
            info["fehlt"].append(f"swing.db nicht lesbar: {e}")
        finally:
            con.close()
    con = _ro(pfad_rg)
    if con is None:
        info["fehlt"].append("regime.db fehlt (Gold/PAXG)")
    else:
        try:
            rows = con.execute("SELECT ts, o, h, l, c, v FROM rg_klines WHERE coin='PAXG' ORDER BY ts").fetchall()
            if rows:
                a = np.array(rows, dtype=float)
                K = {"ts": a[:, 0].astype(np.int64), "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}
                ax = _schluss_aus_kerzen(K)
                if ax is not None and len(ax["c"]) >= 120:
                    reihen["PAXG"] = reihe_bauen("PAXG", ax, None, "beschreibend", "regime.db (30 min)", schwellen=SCHWELLEN_GOLD)
            if "PAXG" not in reihen:
                info["fehlt"].append("PAXG: keine Tageskerzen in regime.db")
        except sqlite3.Error as e:
            info["fehlt"].append(f"regime.db nicht lesbar: {e}")
        finally:
            con.close()
    return {"reihen": reihen, "info": info}


# ================================================================================================ Bausteine (über viele Pfade)

def renditen(C: np.ndarray) -> np.ndarray:
    """Log-Renditen r_t = ln(c_t/c_{t−1}); Spalte 0 NaN."""
    r = np.full(C.shape, np.nan)
    r[:, 1:] = np.diff(np.log(C), axis=1)
    return r


def sigma_batch(R: np.ndarray) -> np.ndarray:
    """σ_t = √EWMA(r²) mit Halbwertszeit HWZ einschließlich t, je Zeile wie hl_swing.sigma_tag (Lücke trägt weiter)."""
    lam = 0.5 ** (1.0 / HWZ); P, n = R.shape
    out = np.full((P, n), np.nan); e = np.full(P, np.nan)
    V = R * R
    for t in range(n):
        v = V[:, t]; ok = np.isfinite(v)
        if ok.any():
            e = np.where(ok, np.where(np.isfinite(e), lam * e + (1 - lam) * v, v), e)
        out[:, t] = e
    return np.sqrt(out)


def rsi_batch(C: np.ndarray, n: int = 14) -> np.ndarray:
    """RSI nach Wilder je Zeile (lückenlose Reihen), wie hl_swing.rsi_wilder."""
    P, N = C.shape; out = np.full((P, N), np.nan)
    if N <= n:
        return out
    d = np.diff(C, axis=1); g = np.maximum(d, 0.0); v = np.maximum(-d, 0.0)
    ag = g[:, :n].mean(axis=1); av = v[:, :n].mean(axis=1)
    for k in range(n, N):
        if k > n:
            ag = (ag * (n - 1) + g[:, k - 1]) / n; av = (av * (n - 1) + v[:, k - 1]) / n
        with np.errstate(divide="ignore", invalid="ignore"):
            out[:, k] = np.where(av == 0, np.where(ag > 0, 100.0, 50.0), 100.0 - 100.0 / (1.0 + ag / np.where(av == 0, 1.0, av)))
    return out


def T_aus_reihe(c: np.ndarray, tag0: int) -> dict:
    """hl_swing-Tagesreihe aus Tagesschlüssen: RV_t = r_t² (σ wie in der Studie), Hoch = Tief = Schluss, jeder Tag voll."""
    n = len(c); r = np.full(n, np.nan); r[1:] = np.diff(np.log(c))
    return {"d0": int(tag0), "nd": n, "tag_ts": (int(tag0) + np.arange(n)) * TAG, "o": c, "h": c, "l": c, "c": c, "RV": r * r,
            "voll": np.isfinite(c)}


def fz_reihe(R: dict) -> np.ndarray:
    """Funding-Druck z30 je Tag (hl_swing.Kennzahlen.fz), NaN ohne Funding."""
    if R.get("F") is None:
        return np.full(R["n"], np.nan)
    T = T_aus_reihe(R["c"], R["tag0"])
    return SW.Kennzahlen(T, R["F"]).fz(SW.STRATEGIEN[Z2]["funding_tage"])


def oi_perzentil(oi: np.ndarray | None, fenster: int = 90, mind: int = 60) -> np.ndarray:
    """Mittelrang des heutigen OI unter den fenster Tagen davor (wie hl_indikatoren._rank), mindestens mind Werte."""
    if oi is None:
        return None
    n = len(oi); out = np.full(n, np.nan)
    for t in range(fenster, n):
        x = oi[t]
        if not np.isfinite(x):
            continue
        w = oi[t - fenster:t]; w = w[np.isfinite(w)]
        if len(w) < mind or w.max() - w.min() <= 1e-12 * max(1.0, abs(w.max())):
            continue
        out[t] = (np.sum(w < x) + 0.5 * np.sum(w == x)) / len(w)
    return out


def vorzeichen(n_pfade: int, g0: int, g1: int, saat: int = SAAT) -> np.ndarray:
    """Ein zufälliges Vorzeichen je Kalendertag [g0, g1] und Surrogat, für alle Coins gemeinsam (int8, ±1)."""
    rng = np.random.default_rng(saat)
    return (rng.integers(0, 2, size=(n_pfade, g1 - g0 + 1), dtype=np.int8) * 2 - 1).astype(np.int8)


def surrogate(R: dict, V: np.ndarray, g0: int, mu: float, zeilen=None) -> np.ndarray:
    """Kurse der Surrogate: r* = μ + s·(r − μ) mit dem Vorzeichen des Kalendertags; erste Zeile = echte Kurse (zeilen = Auswahl)."""
    c = R["c"]; n = len(c); r = np.diff(np.log(c))
    s = V[:, R["tag0"] + 1 - g0: R["tag0"] + n - g0]
    if zeilen is not None:
        s = s[zeilen]
    rs = mu + s.astype(float) * (r[None, :] - mu)
    X = np.empty((rs.shape[0] + 1, n)); X[0] = np.log(c)
    X[1:, 0] = math.log(c[0]); X[1:, 1:] = math.log(c[0]) + np.cumsum(rs, axis=1)
    return np.exp(X)


def mu_reihe(R: dict) -> float:
    """Mittlere Tagesrendite ab S (Drift der Surrogate)."""
    c = R["c"][R["S"]:]
    return float(np.mean(np.diff(np.log(c)))) if len(c) > 2 else 0.0


# ================================================================================================ Teil A: Zyklen

def dc_batch(X: np.ndarray, u: float, v: float, i0: int = 0) -> dict:
    """
    Directional Change auf log. Schlüssen X (P, n) ab Index i0: Tief bestätigt bei x ≥ Tief + u, Hoch bei x ≤ Hoch − v; neue Extreme
    nur strikt; ohne Richtung beide verfolgt, Abwärts zuerst geprüft. Liefert die Ereignisse (je Pfad nach Zeit sortiert) und den
    Zustand am Ende (laufendes Extrem).
    """
    P, n = X.shape
    mode = np.zeros(P, dtype=np.int8); hi = X[:, i0].copy(); lo = hi.copy()
    hi_i = np.full(P, i0, dtype=np.int64); lo_i = hi_i.copy()
    ev = []
    for t in range(i0 + 1, n):
        x = X[:, t]
        m = (mode >= 0) & (x > hi); hi = np.where(m, x, hi); hi_i = np.where(m, t, hi_i)
        m = (mode <= 0) & (x < lo); lo = np.where(m, x, lo); lo_i = np.where(m, t, lo_i)
        top = (mode >= 0) & (x <= hi - v)
        bot = (mode <= 0) & (x >= lo + u) & ~top
        if top.any():
            p = np.nonzero(top)[0]
            ev.append((p, np.ones(len(p), dtype=np.int8), hi_i[p], hi[p], np.full(len(p), t), x[p]))
            mode = np.where(top, -1, mode).astype(np.int8); lo = np.where(top, x, lo); lo_i = np.where(top, t, lo_i)
        if bot.any():
            p = np.nonzero(bot)[0]
            ev.append((p, -np.ones(len(p), dtype=np.int8), lo_i[p], lo[p], np.full(len(p), t), x[p]))
            mode = np.where(bot, 1, mode).astype(np.int8); hi = np.where(bot, x, hi); hi_i = np.where(bot, t, hi_i)
    if ev:
        cols = [np.concatenate([e[k] for e in ev]) for k in range(6)]
    else:
        cols = [np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.int8), np.zeros(0, dtype=np.int64), np.zeros(0), np.zeros(0, dtype=np.int64), np.zeros(0)]
    o = np.lexsort((cols[4], cols[0]))
    p, typ, ei, ex, ci, cx = (a[o] for a in cols)
    return {"p": p, "typ": typ, "ext_i": ei, "ext_x": ex, "conf_i": ci, "conf_x": cx, "P": P,
            "ende": {"mode": mode, "hi": hi, "hi_i": hi_i, "lo": lo, "lo_i": lo_i}}


def beine(D: dict) -> dict:
    """Abgeschlossene Beine je Pfad; das erste Extrem jedes Pfads zählt nicht als Beinanfang (es kann vor dem Datenbeginn liegen)."""
    p, typ = D["p"], D["typ"]
    if len(p) < 2:
        leer = np.zeros(0, dtype=np.int64)
        return {"auf": {k: leer for k in ("p", "t_tief", "t_hoch", "x_tief", "x_hoch", "b_tief", "bx_tief", "b_hoch", "bx_hoch")},
                "ab": {k: leer for k in ("p", "t_hoch", "t_tief", "x_hoch", "x_tief")}, "tiefs": {"p": leer, "t": leer}}
    erst = np.concatenate([[True], p[1:] != p[:-1]])
    gleich = p[1:] == p[:-1]
    start = gleich & ~erst[:-1]
    auf = start & (typ[:-1] == -1) & (typ[1:] == 1)
    ab = start & (typ[:-1] == 1) & (typ[1:] == -1)
    ei, ex, ci, cx = D["ext_i"], D["ext_x"], D["conf_i"], D["conf_x"]
    A = {"p": p[:-1][auf], "t_tief": ei[:-1][auf], "t_hoch": ei[1:][auf], "x_tief": ex[:-1][auf], "x_hoch": ex[1:][auf],
         "b_tief": ci[:-1][auf], "bx_tief": cx[:-1][auf], "b_hoch": ci[1:][auf], "bx_hoch": cx[1:][auf]}
    B = {"p": p[:-1][ab], "t_hoch": ei[:-1][ab], "t_tief": ei[1:][ab], "x_hoch": ex[:-1][ab], "x_tief": ex[1:][ab]}
    tm = (typ == -1) & ~erst
    return {"auf": A, "ab": B, "tiefs": {"p": p[tm], "t": ei[tm]}}


def _median_je_pfad(p: np.ndarray, x: np.ndarray, P: int) -> np.ndarray:
    out = np.full(P, np.nan)
    if not len(p):
        return out
    o = np.lexsort((x, p)); p, x = p[o], x[o]
    grenzen = np.searchsorted(p, np.arange(P + 1))
    for k in range(P):
        a, b = grenzen[k], grenzen[k + 1]
        if b > a:
            out[k] = float(np.median(x[a:b]))
    return out


def _mittel_je_pfad(p: np.ndarray, x: np.ndarray, P: int) -> np.ndarray:
    s = np.bincount(p, weights=x, minlength=P)[:P]; k = np.bincount(p, minlength=P)[:P]
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(k > 0, s / np.maximum(k, 1), np.nan)


def _p_zweiseitig(echt: float, null: np.ndarray) -> float:
    null = null[np.isfinite(null)]
    if not np.isfinite(echt) or not len(null):
        return float("nan")
    ge = (1 + np.sum(null >= echt)) / (len(null) + 1); le = (1 + np.sum(null <= echt)) / (len(null) + 1)
    return float(min(1.0, 2.0 * min(ge, le)))


def _p_groesser(echt: float, null: np.ndarray) -> float:
    null = null[np.isfinite(null)]
    if not np.isfinite(echt) or not len(null):
        return float("nan")
    return float((1 + np.sum(null >= echt)) / (len(null) + 1))


def zyklen_beschreiben(Bn: dict, pfad: int, n_jahre: float, X_schwelle: float) -> dict:
    """Beschreibende Kennzahlen der Beine eines Pfads (echte Kurse: Pfad 0)."""
    A = {k: v[Bn["auf"]["p"] == pfad] for k, v in Bn["auf"].items()}
    Bb = {k: v[Bn["ab"]["p"] == pfad] for k, v in Bn["ab"].items()}
    gr = A["x_hoch"] - A["x_tief"]; dauer = A["t_hoch"] - A["t_tief"]
    tiefe = Bb["x_tief"] - Bb["x_hoch"]; dauer_ab = Bb["t_tief"] - Bb["t_hoch"]
    tiefs = np.sort(Bn["tiefs"]["t"][Bn["tiefs"]["p"] == pfad])
    zyk = np.diff(tiefs)
    nach = A["x_hoch"] - A["bx_tief"]; bis_hoch = A["t_hoch"] - A["b_tief"]
    runde = A["bx_hoch"] - A["bx_tief"]; halten = A["b_hoch"] - A["b_tief"]

    def q(a, f=np.median):
        return float(f(a)) if len(a) else float("nan")

    def qq(a):
        return (float(np.quantile(a, 0.25)), float(np.quantile(a, 0.75))) if len(a) else (float("nan"), float("nan"))
    return {"n": int(len(gr)), "je_jahr": len(gr) / n_jahre if n_jahre > 0 else float("nan"),
            "groesse": q(gr), "groesse_q": qq(gr), "groesse_mittel": q(gr, np.mean), "dauer": q(dauer), "dauer_q": qq(dauer),
            "tiefe": q(tiefe), "tiefe_q": qq(tiefe), "dauer_ab": q(dauer_ab), "dauer_ab_q": qq(dauer_ab), "n_ab": int(len(tiefe)),
            "zyklus": q(zyk), "nach": q(nach), "bis_hoch": q(bis_hoch), "runde": q(runde), "runde_mittel": q(runde, np.mean),
            "runde_treffer": float(np.mean(runde > 0)) if len(runde) else float("nan"), "halten": q(halten),
            "ab_2x": float(np.mean(gr >= math.log(1 + 2 * X_schwelle))) if len(gr) else float("nan"),
            "ab_3x": float(np.mean(gr >= math.log(1 + 3 * X_schwelle))) if len(gr) else float("nan")}


def teil_a(reihen: dict, V: np.ndarray, g0: int, n_surr: int, log=lambda s: None) -> dict:
    """
    Teil A je Coin und Schwelle: Beschreibung (echte Kurse), aktueller Stand, Vergleich mit den Surrogaten (je Coin beschreibend).
    Urteil je Schwelle (KONZEPT_Zyklen.md 4 und 12): mittlere log. Rallyegröße je Coin, gemittelt über die Test-Coins, gegen dieselbe
    Größe auf den gemeinsamen Surrogaten; p zweiseitig, Holm über die Schwellen, dieselbe Richtung in beiden Hälften.
    """
    out: dict = {}; pool: dict = {}
    for coin, R in reihen.items():
        S = R["S"]; n = R["n"]
        if n - S < 120:
            continue
        mu = mu_reihe(R); jahre = (n - 1 - S) / 365.25
        test = R["rolle"] == "test" and n_surr > 0
        mitte = S + (n - S) // 2
        je = {}
        for X in R["schwellen"]:
            u, v = math.log(1 + X), -math.log(1 - X)
            echt = dc_batch(np.log(R["c"][None, :]), u, v, i0=S)
            Bn = beine(echt)
            info = zyklen_beschreiben(Bn, 0, jahre, X)
            info["u"], info["v"] = u, v
            info["stand"] = _dc_stand(echt, R, X)
            gr0 = Bn["auf"]["x_hoch"] - Bn["auf"]["x_tief"]; t0 = Bn["auf"]["t_tief"]
            info["n_haelften"] = (int(np.sum(t0 < mitte)), int(np.sum(t0 >= mitte)))
            info["mittel_log"] = float(gr0.mean()) if len(gr0) else float("nan")
            if test:
                mit = [np.array([info["mittel_log"]])]
                mit1 = [np.array([float(gr0[t0 < mitte].mean()) if np.any(t0 < mitte) else np.nan])]
                mit2 = [np.array([float(gr0[t0 >= mitte].mean()) if np.any(t0 >= mitte) else np.nan])]
                dauer = []; runde = []
                for a_ in range(0, n_surr, CHUNK):
                    zeilen = np.arange(a_, min(n_surr, a_ + CHUNK))
                    Cs = surrogate(R, V, g0, mu, zeilen)[1:]
                    Ds = beine(dc_batch(np.log(Cs), u, v, i0=S))
                    A_ = Ds["auf"]; g = A_["x_hoch"] - A_["x_tief"]; k = len(zeilen)
                    mit.append(_mittel_je_pfad(A_["p"], g, k))
                    m1 = A_["t_tief"] < mitte
                    mit1.append(_mittel_je_pfad(A_["p"][m1], g[m1], k)); mit2.append(_mittel_je_pfad(A_["p"][~m1], g[~m1], k))
                    dauer.append(_median_je_pfad(A_["p"], (A_["t_hoch"] - A_["t_tief"]).astype(float), k))
                    runde.append(_mittel_je_pfad(A_["p"], A_["bx_hoch"] - A_["bx_tief"], k))
                mit = np.concatenate(mit); mit1 = np.concatenate(mit1); mit2 = np.concatenate(mit2)
                dauer = np.concatenate(dauer); runde = np.concatenate(runde)
                info["vergleich"] = {"p": _p_zweiseitig(mit[0], mit[1:]), "null_mittel": _nanmed(mit[1:]),
                                     "null_q": (_nanq(mit[1:], 0.05), _nanq(mit[1:], 0.95)),
                                     "dauer_null": _nanmed(dauer), "runde_null": _nanmed(runde),
                                     "runde_null_q": (_nanq(runde, 0.05), _nanq(runde, 0.95)), "n_surr": n_surr}
                pl = pool.setdefault(X, {"coins": [], "ganz": [], "h1": [], "h2": [], "n_h": [0, 0]})
                pl["coins"].append(coin); pl["ganz"].append(mit); pl["h1"].append(mit1); pl["h2"].append(mit2)
                pl["n_h"][0] += info["n_haelften"][0]; pl["n_h"][1] += info["n_haelften"][1]
            je[X] = info
            log(f"    {coin} {X * 100:.0f} %: {info['n']} Rallyes")
        out[coin] = {"je": je, "jahre": jahre, "von": R["tag0"] + S, "bis": R["tag0"] + n - 1, "mitte": R["tag0"] + mitte}
    # Urteil je Schwelle, gepoolt über die Test-Coins (gleich gewichtet), Holm über die Schwellen
    urteil = {}
    for X, pl in pool.items():
        G = np.vstack(pl["ganz"]); H1 = np.vstack(pl["h1"]); H2 = np.vstack(pl["h2"])
        with np.errstate(invalid="ignore"):
            g = np.nanmean(G, axis=0); h1 = np.nanmean(H1, axis=0); h2 = np.nanmean(H2, axis=0)
        urteil[X] = {"coins": pl["coins"], "echt": float(g[0]), "null_median": _nanmed(g[1:]),
                     "null_q": (_nanq(g[1:], 0.05), _nanq(g[1:], 0.95)), "p": _p_zweiseitig(float(g[0]), g[1:]),
                     "h1": (float(h1[0]), _nanmed(h1[1:])), "h2": (float(h2[0]), _nanmed(h2[1:])),
                     "n_haelften": tuple(pl["n_h"]), "n_surr": n_surr}
    urteil_a(urteil)
    return {"je_coin": out, "urteil": urteil, "n_tests": len(urteil)}


def urteil_a(U: dict) -> None:
    """Teil A (vorab): Holm über die Schwellen; belegt mit p Holm < 0,05, Richtung ≠ 0 und derselben Richtung in beiden Hälften
    (je mindestens 3 Rallyes)."""
    for X, ph in zip(list(U), RG.holm([U[X]["p"] for X in U])):
        t = U[X]; t["p_holm"] = ph
        richtung = np.sign(t["echt"] - t["null_median"]) if np.isfinite(t["echt"]) and np.isfinite(t["null_median"]) else 0.0
        h_ok = all(np.isfinite(e) and np.isfinite(nm) and np.sign(e - nm) == richtung for e, nm in (t["h1"], t["h2"]))
        t["haelften"] = bool(h_ok and min(t["n_haelften"]) >= 3)
        t["belegt"] = bool(np.isfinite(ph) and ph < ALPHA and t["haelften"] and richtung != 0)
        t["richtung"] = "länger" if richtung > 0 else ("kürzer" if richtung < 0 else "gleich")


def _dc_stand(D: dict, R: dict, X: float) -> dict:
    """Laufendes Bein der echten Kurse am letzten Tag."""
    e = D["ende"]; c = R["c"]; n = R["n"]; t0 = R["tag0"]
    mode = int(e["mode"][0]); letzt = float(c[-1])
    st = {"mode": mode, "schluss": letzt, "tag": t0 + n - 1}
    if mode == -1:
        hoch_i = int(D["ext_i"][-1]) if len(D["ext_i"]) and D["typ"][-1] == 1 else None
        st.update(hoch=float(math.exp(D["ext_x"][-1])) if hoch_i is not None else None, hoch_tag=(t0 + hoch_i) if hoch_i is not None else None,
                  tief=float(math.exp(e["lo"][0])), tief_tag=t0 + int(e["lo_i"][0]), bestaetigt_ab=float(math.exp(e["lo"][0])) * (1 + X))
    elif mode == 1:
        tief_i = int(D["ext_i"][-1]) if len(D["ext_i"]) and D["typ"][-1] == -1 else None
        st.update(tief=float(math.exp(D["ext_x"][-1])) if tief_i is not None else None, tief_tag=(t0 + tief_i) if tief_i is not None else None,
                  hoch=float(math.exp(e["hi"][0])), hoch_tag=t0 + int(e["hi_i"][0]), bestaetigt_ab=float(math.exp(e["hi"][0])) * (1 - X))
    return st


# ================================================================================================ Teil B: Strategien

def dip_matrizen(C: np.ndarray, SIG: np.ndarray, R: dict) -> dict:
    """
    Z1-Lage für alle Pfade und Tage (wie hl_swing.dip_lage): L = tiefster Schluss d−10 … d−1 (jüngster bei Gleichstand) an j, H = höchster
    Schluss j−19 … j; Dump, Erholung, Abstand in σ_d; Einstieg nach den Schwellen von R; LS = min(L, c_d) für den Stop.
    """
    nt, nh = int(R["tief_tage"]), int(R["hoch_tage"]); P, n = C.shape
    out = {k: np.full((P, n), np.nan) for k in ("L", "H", "dump", "erh", "abst", "LS")}
    out["ein"] = np.zeros((P, n), dtype=bool); out["ok"] = np.zeros((P, n), dtype=bool)
    if n <= nt:
        return out
    W = sliding_window_view(C, nt, axis=1)[:, :n - nt]                  # Fenster k = Tage k … k+nt−1 -> für d = k + nt
    jr = np.argmin(W[:, :, ::-1], axis=2)
    d = np.arange(nt, n)
    J = (d[None, :] - 1) - jr
    Lv = np.take_along_axis(C, J, axis=1)
    HM = sliding_window_view(C, nh, axis=1).max(axis=2)                 # HM[:, i] = max C[i … i+nh−1]
    gut = J - nh + 1 >= 0
    Hv = np.take_along_axis(HM, np.clip(J - nh + 1, 0, HM.shape[1] - 1), axis=1)
    cd = C[:, nt:]; s = SIG[:, nt:]
    sok = np.isfinite(s) & (s > 0)
    with np.errstate(divide="ignore", invalid="ignore"):
        dump = np.log(Hv / Lv) / s; erh = np.log(cd / Lv) / s; abst = np.log(Hv / cd) / s
    lage = gut & sok
    out["L"][:, nt:] = np.where(lage, Lv, np.nan); out["H"][:, nt:] = np.where(lage, Hv, np.nan)
    out["dump"][:, nt:] = np.where(lage, dump, np.nan); out["erh"][:, nt:] = np.where(lage, erh, np.nan)
    out["abst"][:, nt:] = np.where(lage, abst, np.nan)
    if "dump" in R:
        out["ein"][:, nt:] = lage & (dump >= R["dump"]) & (erh >= R["erholung"]) & (abst >= R["abstand"])
    out["LS"][:, nt:] = np.where(sok, np.minimum(Lv, cd), np.nan)
    out["ok"][:, nt:] = sok
    return out


def simulieren(C: np.ndarray, SIG: np.ndarray, EIN: np.ndarray, LS: np.ndarray, R: dict, i0: int, i1: int, kosten: float,
               RSI: np.ndarray | None = None, FZ: np.ndarray | None = None, M: np.ndarray | None = None, Lziel: np.ndarray | None = None) -> dict:
    """
    Long-only am Tagesschluss über P Pfade gleichzeitig, Tage i0 … i1. Einstieg am Schluss t (EIN, flach, nicht am Schluss eines
    Ausstiegs): Stop k = ln(c/LS)/σ + stop_unter_tief, sl = c·e^{−kσ} (wie hl_swing.plan); ab t+1 Ausstieg zum Schluss bei c ≤ sl
    (Stop bzw. Nachzieh-Stop), c ≥ Ziel (Z3), Zeit (t − e ≥ max_tage), Überhitzung (Z2); sonst Nachzieh-Stop vom besten Schluss ab
    t+1 (wie hl_swing.nachfuehren mit e = Folgetag). pos[:, t] = gehalten vom Schluss t bis t+1; kost[:, t] = Kosten am Schluss t.
    """
    P, n = C.shape; trail = float(R["trail"]); su = float(R["stop_unter_tief"]); mx = int(R["max_tage"])
    pos = np.zeros((P, n), dtype=bool); kost = np.zeros((P, n))
    drin = np.zeros(P, dtype=bool); e = np.zeros(P, dtype=np.int64); sl = np.full(P, np.nan); best = np.full(P, -np.inf)
    tp = np.full(P, np.inf); px_e = np.full(P, np.nan); L_e = np.full(P, np.nan); s_e = np.full(P, np.nan); spitze = np.full(P, -np.inf)
    nachgezogen = np.zeros(P, dtype=bool)
    heiss = R.get("art") == "dip_heiss"
    tr = {k: [] for k in ("p", "e", "x", "px_e", "px_x", "grund", "L", "s_e", "spitze")}
    for t in range(i0, i1 + 1):
        c = C[:, t]; s = SIG[:, t]
        raus = np.zeros(P, dtype=bool)
        if drin.any() and t > i0:
            alt = drin & (t > e)
            stop = alt & (c <= sl)
            ziel = alt & ~stop & (c >= tp)
            zeit = alt & ~stop & ~ziel & (t - e >= mx)
            sig = np.zeros(P, dtype=bool)
            if heiss:
                h = np.zeros(P, dtype=bool)
                if RSI is not None:
                    h |= np.nan_to_num(RSI[:, t], nan=-1.0) >= R["rsi_max"]
                if FZ is not None and np.isfinite(FZ[t]) and FZ[t] >= R["funding_z"]:
                    h |= True
                sig = alt & ~stop & ~ziel & ~zeit & h
            raus = stop | ziel | zeit | sig
            if raus.any():
                p = np.nonzero(raus)[0]
                spitze[p] = np.maximum(spitze[p], c[p])
                grund = np.where(stop[p], np.where(nachgezogen[p], 2, 1), np.where(ziel[p], 3, np.where(zeit[p], 4, 5)))
                for k, w in (("p", p), ("e", e[p]), ("x", np.full(len(p), t)), ("px_e", px_e[p]), ("px_x", c[p]), ("grund", grund),
                             ("L", L_e[p]), ("s_e", s_e[p]), ("spitze", spitze[p])):
                    tr[k].append(np.asarray(w))
                kost[p, t] += kosten
                drin[p] = False
            bleib = drin & (t > e)
            if bleib.any():
                best = np.where(bleib, np.maximum(best, c), best)
                spitze = np.where(bleib, np.maximum(spitze, c), spitze)
                with np.errstate(invalid="ignore"):
                    neu = best * np.exp(-trail * s)
                hoeher = bleib & np.isfinite(neu) & (neu > sl)
                sl = np.where(hoeher, neu, sl); nachgezogen |= hoeher
        neu_ein = ~drin & ~raus & EIN[:, t] & np.isfinite(s) & (s > 0) & np.isfinite(LS[:, t])
        if t >= i1:
            neu_ein[:] = False                                              # am letzten Tag keine neue Position
        if neu_ein.any():
            p = np.nonzero(neu_ein)[0]
            k_ = np.log(c[p] / LS[p, t]) / s[p] + su
            sl[p] = c[p] * np.exp(-k_ * s[p]); best[p] = -np.inf; spitze[p] = c[p]; nachgezogen[p] = False
            e[p] = t; px_e[p] = c[p]; s_e[p] = s[p]; drin[p] = True; kost[p, t] += kosten
            Lz = Lziel[p, t] if Lziel is not None else LS[p, t]
            L_e[p] = Lz
            tp[p] = np.inf
            if M is not None:
                m = M[p, t]; okm = np.isfinite(m)
                tp[p] = np.where(okm, np.maximum(Lz * np.exp(np.where(okm, m, 0.0) * s[p]), c[p] * np.exp(0.5 * s[p])), np.inf)
        pos[:, t] = drin
    T = {k: (np.concatenate(v) if v else np.zeros(0)) for k, v in tr.items()}
    for k in ("p", "e", "x", "grund"):
        T[k] = T[k].astype(np.int64)
    # offen am Ende
    T["offen"] = {"p": np.nonzero(drin)[0], "e": e[drin], "px_e": px_e[drin]}
    return {"pos": pos, "kost": kost, "trades": T}


GRUENDE = {1: "Stop", 2: "Nachzieh-Stop", 3: "Ziel", 4: "Zeit", 5: "Überhitzung"}


def ziel_matrix(T1: dict, C: np.ndarray, P: int, n: int, min_trades: int = 10) -> np.ndarray:
    """Z3: m[p, t] = Median des Höchststands ln(Spitze/L)/σ_e der Z1-Trades von Pfad p, die vor t endeten (mindestens min_trades)."""
    M = np.full((P, n), np.nan)
    if not len(T1["p"]):
        return M
    hoch = np.log(T1["spitze"] / T1["L"]) / T1["s_e"]
    for p in range(P):
        m = T1["p"] == p
        if m.sum() < min_trades:
            continue
        x = T1["x"][m]; h = hoch[m]; o = np.argsort(x, kind="stable"); x, h = x[o], h[o]
        for k in range(min_trades - 1, len(x)):
            a = int(x[k]) + 1; b = int(x[k + 1]) + 1 if k + 1 < len(x) else n
            if a < n:
                M[p, a:min(b, n)] = float(np.median(h[:k + 1]))
    return M


def t200_pos(c: np.ndarray, i0: int, i1: int) -> np.ndarray:
    n = len(c); pos = np.zeros(n)
    cs = np.concatenate([[0.0], np.cumsum(c)])
    for t in range(max(i0, 199), i1 + 1):
        pos[t] = 1.0 if c[t] > (cs[t + 1] - cs[t - 199]) / 200.0 else 0.0
    if i1 + 1 < n:
        pos[i1 + 1:] = 0.0
    return pos


def vol_pos(sig: np.ndarray, i0: int, i1: int, schritt: float = 0.10) -> np.ndarray:
    """w = min(1, σ*/σ_t), σ* = Median von σ über die 365 Tage davor; umschichten bei |Δw| ≥ schritt."""
    n = len(sig); w = np.zeros(n); jetzt = 0.0
    for t in range(i0, i1 + 1):
        h = sig[max(0, t - 365):t]; h = h[np.isfinite(h)]
        if len(h) < 300 or not np.isfinite(sig[t]) or sig[t] <= 0:
            w[t] = jetzt; continue
        ziel = min(1.0, float(np.median(h)) / float(sig[t]))
        if t == i0 or abs(ziel - jetzt) >= schritt:
            jetzt = ziel
        w[t] = jetzt
    return w


def renditen_aus_pos(c: np.ndarray, pos: np.ndarray, kosten: float, i0: int, i1: int, kost: np.ndarray | None = None) -> np.ndarray:
    """Tagesrendite (einfach) vom Schluss t−1 bis t mit der Position vom Schluss t−1, minus Kosten am Schluss t; Tage i0 … i1."""
    r = np.zeros(len(c))
    r[1:] = pos[:-1] * (c[1:] / c[:-1] - 1.0)
    if kost is None:
        dp = np.abs(np.diff(np.concatenate([[0.0], pos])))
        kost = dp * kosten
    r = r - kost
    return r[i0:i1 + 1]


def kennzahlen_reihe(r: np.ndarray, pos: np.ndarray | None = None, kost: np.ndarray | None = None, tag0: int = 0) -> dict:
    """CAGR, Schwankung, Sharpe, größter Rückgang, Calmar, Anteil im Markt, schlechtestes Kalenderjahr."""
    r = np.asarray(r, dtype=float); n = len(r)
    if n < 30:
        return {"n": n}
    eq = np.cumprod(1.0 + r); jahre = n / 365.0
    cagr = eq[-1] ** (1.0 / jahre) - 1.0 if eq[-1] > 0 else -1.0
    sd = float(r.std(ddof=1))
    sr = float(r.mean() / sd * math.sqrt(365)) if sd > 0 else float("nan")
    mdd = float(np.max(1.0 - eq / np.maximum.accumulate(eq)))
    out = {"n": n, "cagr": cagr, "vol": sd * math.sqrt(365), "sharpe": sr, "mdd": mdd, "calmar": cagr / mdd if mdd > 0 else float("nan"),
           "gesamt": eq[-1] - 1.0}
    if pos is not None:
        out["im_markt"] = float(np.mean(pos))
    if kost is not None:
        out["kosten_jahr"] = float(np.sum(kost)) / jahre
    jahr = np.array([time.gmtime((tag0 + k) * TAG).tm_year for k in range(n)])
    schlecht = None
    for j in np.unique(jahr):
        m = jahr == j
        if m.sum() >= 180:
            v = float(np.prod(1.0 + r[m]) - 1.0)
            if schlecht is None or v < schlecht[1]:
                schlecht = (int(j), v)
    out["schlechtestes_jahr"] = schlecht
    return out


def _sharpe(r: np.ndarray) -> float:
    sd = r.std(ddof=1) if len(r) > 1 else 0.0
    return float(r.mean() / sd * math.sqrt(365)) if sd > 0 else float("nan")


def sharpe_test(r_s: np.ndarray, r_h: np.ndarray, n_boot: int = N_BOOT_B2, block: int = BLOCK_B2, saat: int = SAAT) -> dict:
    """ΔSR = SR(Strategie) − SR(HODL); p einseitig aus dem zirkulären Blockbootstrap gepaarter Tagesrenditen (zentriert)."""
    n = len(r_s); d = _sharpe(r_s) - _sharpe(r_h)
    if n < 2 * block or not np.isfinite(d):
        return {"d": d, "p": float("nan"), "q": (float("nan"), float("nan"))}
    rng = np.random.default_rng(saat); nb = int(math.ceil(n / block))
    ds = np.empty(n_boot)
    off = np.arange(block)
    for k in range(n_boot):
        st = rng.integers(0, n, nb)
        idx = ((st[:, None] + off[None, :]) % n).ravel()[:n]
        ds[k] = _sharpe(r_s[idx]) - _sharpe(r_h[idx])
    ok = np.isfinite(ds); ds = ds[ok]
    p = float((1 + np.sum(ds - d >= d)) / (len(ds) + 1)) if len(ds) else float("nan")
    return {"d": d, "p": p, "q": (float(np.quantile(ds, 0.05)), float(np.quantile(ds, 0.95))) if len(ds) else (float("nan"),) * 2}


def _b1_stat(lauf: dict, C: np.ndarray, mu: float, i0: int, i1: int, mitte_i: int | None = None) -> tuple:
    """Summen für den Mehrertrag je Markttag: Σ pos_{t−1}(r_t − μ) − Kosten und Σ pos_{t−1} je Pfad (ganz und je Hälfte)."""
    pos, kost = lauf["pos"], lauf["kost"]
    r = np.diff(np.log(C), axis=1)                                         # r[:, t−1] = ln(c_t/c_{t−1})
    a, b = i0 + 1, i1 + 1
    pv = pos[:, a - 1:b - 1].astype(float)
    x = pv * (r[:, a - 1:b - 1] - mu)
    k = kost[:, i0:i1 + 1]
    if mitte_i is None:
        return (x.sum(axis=1) - k.sum(axis=1), pv.sum(axis=1))
    m = mitte_i
    h1 = (x[:, :max(0, m - a)].sum(axis=1) - k[:, :max(0, m - i0)].sum(axis=1), pv[:, :max(0, m - a)].sum(axis=1))
    h2 = (x[:, max(0, m - a):].sum(axis=1) - k[:, max(0, m - i0):].sum(axis=1), pv[:, max(0, m - a):].sum(axis=1))
    return (x.sum(axis=1) - k.sum(axis=1), pv.sum(axis=1)), h1, h2


def z_laeufe(C: np.ndarray, R_: dict, i0: int, i1: int, fz: np.ndarray, welche=("Z1", "Z2", "Z3")) -> dict:
    """Z1, Z2 und Z3 auf allen Pfaden von C (Zeile 0 = echte Kurse, bei den Surrogaten alle gleich behandelt)."""
    r = renditen(C); SIG = sigma_batch(r)
    R1, R2 = SW.STRATEGIEN[Z1], SW.STRATEGIEN[Z2]
    D = dip_matrizen(C, SIG, R1)
    out = {"SIG": SIG, "D": D}
    L1 = simulieren(C, SIG, D["ein"], D["LS"], R1, i0, i1, R_["kosten"], Lziel=D["L"])
    out["Z1"] = L1
    if "Z2" in welche:
        RSI = rsi_batch(C, R2["rsi_tage"])
        out["Z2"] = simulieren(C, SIG, D["ein"], D["LS"], R2, i0, i1, R_["kosten"], RSI=RSI, FZ=fz, Lziel=D["L"])
        out["RSI"] = RSI
    if "Z3" in welche:
        M = ziel_matrix(L1["trades"], C, C.shape[0], C.shape[1])
        out["Z3"] = simulieren(C, SIG, D["ein"], D["LS"], R1, i0, i1, R_["kosten"], M=M, Lziel=D["L"])
        out["M"] = M
    return out


def _trades_liste(T: dict, pfad: int = 0) -> list:
    m = T["p"] == pfad
    return [{"e": int(e), "x": int(x), "px_e": float(a), "px_x": float(b), "grund": GRUENDE.get(int(g), "?"),
             "r": math.log(b / a), "L": float(L), "s_e": float(s), "spitze": float(sp)}
            for e, x, a, b, g, L, s, sp in zip(T["e"][m], T["x"][m], T["px_e"][m], T["px_x"][m], T["grund"][m], T["L"][m], T["s_e"][m],
                                               T["spitze"][m])]


def teil_b(reihen: dict, V: np.ndarray, g0: int, n_surr: int, n_placebo: int = N_PLACEBO, n_boot: int = N_BOOT_B2,
           log=lambda s: None) -> dict:
    """Teil B: je Coin alle Strategien auf den echten Kursen (Beschreibung, Z0, verzögerte Ausführung), B1 gegen die Surrogate, B2 im Kern."""
    je: dict = {}; b1_summen: dict = {}
    for coin, R in reihen.items():
        if R.get("B") is None:
            continue
        c = R["c"]; n = R["n"]; i0 = R["B"]; i1 = n - 1; kosten = R["kosten"]
        fz = fz_reihe(R)
        Z = z_laeufe(c[None, :].copy(), R, i0, i1, fz)
        sig0 = Z["SIG"][0]
        pos = {"HODL": np.where(np.arange(n) >= i0, 1.0, 0.0), "T200": t200_pos(c, i0, i1), "VOL": vol_pos(sig0, i0, i1)}
        pos["HODL"][i1 + 1:] = 0.0
        erg = {}
        for k in ("HODL", "T200", "VOL"):
            p = pos[k].copy(); p[:i0] = 0.0
            dp = np.abs(np.diff(np.concatenate([[0.0], p]))); kost = dp * kosten
            r = renditen_aus_pos(c, p, kosten, i0, i1, kost)
            wechsel = float(np.sum(dp[i0:i1 + 1] > 0)) / ((i1 - i0 + 1) / 365.0)
            erg[k] = {"r": r, "kz": kennzahlen_reihe(r, p[i0:i1 + 1], kost[i0:i1 + 1], R["tag0"] + i0),
                      "trades_jahr": wechsel if k == "VOL" else wechsel / 2.0, "pos": p}
        for k in ("Z1", "Z2", "Z3"):
            L_ = Z[k]; p = L_["pos"][0].astype(float); kost = L_["kost"][0]
            r = renditen_aus_pos(c, p, kosten, i0, i1, kost)
            tl = _trades_liste(L_["trades"])
            erg[k] = {"r": r, "kz": kennzahlen_reihe(r, p[i0:i1 + 1], kost[i0:i1 + 1], R["tag0"] + i0), "trades": tl,
                      "trades_jahr": len(tl) / ((i1 - i0 + 1) / 365.0), "pos": p, "kost": kost,
                      "offen": [int(x) for x in L_["trades"]["offen"]["e"]]}
        # verzögerte Ausführung (Positionen einen Tag später), beschreibend
        for k in B_FOLGE:
            p = erg[k]["pos"]; pl = np.concatenate([[0.0], p[:-1]])
            dp = np.abs(np.diff(np.concatenate([[0.0], pl])))
            rl = renditen_aus_pos(c, pl, kosten, i0, i1, dp * kosten)
            erg[k]["verzoegert"] = {"sharpe": _sharpe(rl), "cagr": kennzahlen_reihe(rl).get("cagr")}
        # Z0: zufälliger Long-Einstieg an flachen Tagen mit der Rate von Z1, Ausstiege wie Z1. Flach am Schluss t heißt: schon am
        # Schluss t−1 ohne Position (am Schluss eines Ausstiegs gibt es keinen Einstieg), Stop berechenbar, nicht der letzte Tag.
        D0 = Z["D"]
        elig = np.zeros(n, dtype=bool); elig[i0:i1] = True
        elig &= D0["ok"][0] & np.isfinite(D0["LS"][0])
        n_ein = len(erg["Z1"]["trades"]) + len(erg["Z1"]["offen"])
        n_flach = int(np.sum(elig & ~np.concatenate([[False], erg["Z1"]["pos"][:-1].astype(bool)])))
        q = n_ein / n_flach if n_flach else 0.0
        z0 = None
        if n_placebo and q > 0:
            rng = np.random.default_rng(SAAT + 7 + len(je))
            Cp = np.repeat(c[None, :], n_placebo, axis=0); SIGp = np.repeat(sig0[None, :], n_placebo, axis=0)
            EIN = (rng.random((n_placebo, n)) < q) & elig[None, :]
            LSp = np.repeat(D0["LS"][0][None, :], n_placebo, axis=0)
            L0 = simulieren(Cp, SIGp, EIN, LSp, SW.STRATEGIEN[ZZ], i0, i1, kosten)
            sr = []; cg = []; md = []; ntr = []
            for k in range(n_placebo):
                r = renditen_aus_pos(c, L0["pos"][k].astype(float), kosten, i0, i1, L0["kost"][k])
                kz = kennzahlen_reihe(r)
                sr.append(kz["sharpe"]); cg.append(kz["cagr"]); md.append(kz["mdd"]); ntr.append(int(np.sum(L0["trades"]["p"] == k)))
            sr, cg, md = np.array(sr), np.array(cg), np.array(md)
            z0 = {"q": q, "sharpe": (_nanmed(sr), _nanq(sr, 0.05), _nanq(sr, 0.95)),
                  "cagr": (_nanmed(cg), _nanq(cg, 0.05), _nanq(cg, 0.95)),
                  "mdd": (_nanmed(md), _nanq(md, 0.05), _nanq(md, 0.95)),
                  "trades_jahr": float(np.median(ntr)) / ((i1 - i0 + 1) / 365.0), "im_markt": float(np.mean(L0["pos"][:, i0:i1 + 1]))}
        je[coin] = {"erg": erg, "z0": z0, "i0": i0, "i1": i1, "von": R["tag0"] + i0, "bis": R["tag0"] + i1, "rolle": R["rolle"],
                    "markt": float(c[i1] / c[i0] - 1.0)}
        log(f"    {coin}: Z1 {len(erg['Z1']['trades'])} Trades, im Markt {_pr(erg['Z1']['kz'].get('im_markt'))}")
        # B1-Summen: echte Kurse und Surrogate
        if R["rolle"] == "test" and n_surr > 0:
            mu = mu_reihe(R)
            Cs = surrogate(R, V, g0, mu, np.arange(n_surr))
            Zs = z_laeufe(Cs, R, i0, i1, fz)
            b1_summen[coin] = {"mu": mu, "i0": i0, "i1": i1, "tag0": R["tag0"], "Z": {k: Zs[k] for k in B1_TESTS}, "C": Cs}
    # B1: gepoolt über die Test-Coins, Hälften nach Kalender
    b1 = {}
    if b1_summen:
        von = min(v["tag0"] + v["i0"] for v in b1_summen.values()); bis = max(v["tag0"] + v["i1"] for v in b1_summen.values())
        mitte = von + (bis - von) // 2
        for k in B1_TESTS:
            num = 0; den = 0; n1 = 0; d1 = 0; n2 = 0; d2 = 0
            for coin, v in b1_summen.items():
                ganz, h1, h2 = _b1_stat(v["Z"][k], v["C"], v["mu"], v["i0"], v["i1"], mitte - v["tag0"])
                num = num + ganz[0]; den = den + ganz[1]; n1 = n1 + h1[0]; d1 = d1 + h1[1]; n2 = n2 + h2[0]; d2 = d2 + h2[1]
            with np.errstate(invalid="ignore", divide="ignore"):
                st = num / den; s1 = n1 / d1; s2 = n2 / d2
            b1[k] = {"stat": float(st[0]), "null": st[1:], "p": _p_groesser(float(st[0]), st[1:]),
                     "h1": (float(s1[0]), _nanmed(s1[1:])), "h2": (float(s2[0]), _nanmed(s2[1:])),
                     "markttage": float(den[0]), "null_median": _nanmed(st[1:]),
                     "null_q": (_nanq(st[1:], 0.05), _nanq(st[1:], 0.95))}
        urteil_b1(b1)
        b1["_mitte"] = mitte; b1["_coins"] = list(b1_summen)
    # B2: Kern-Portfolio (gleich gewichtet über die verfügbaren Kern-Coins, täglich ausgeglichen)
    b2 = kern_portfolio(je, reihen, n_boot)
    return {"je_coin": je, "b1": b1, "b2": b2}


def urteil_b1(b1: dict) -> None:
    """B1 (vorab): Holm über Z1–Z3; belegt mit p Holm < 0,05 und in beiden Hälften über dem Surrogat-Median."""
    for k, ph in zip(B1_TESTS, RG.holm([b1[k]["p"] for k in B1_TESTS])):
        b1[k]["p_holm"] = ph
        b1[k]["haelften"] = all(np.isfinite(a) and np.isfinite(b) and a > b for a, b in (b1[k]["h1"], b1[k]["h2"]))
        b1[k]["belegt"] = bool(np.isfinite(ph) and ph < ALPHA and b1[k]["haelften"])


def urteil_b2(tests: dict) -> None:
    """B2 (vorab): Holm über die fünf; belegt mit p Holm < 0,05, ΔSR > 0 und ΔSR > 0 in beiden Hälften."""
    namen = [k for k in B2_TESTS if k in tests]
    for k, ph in zip(namen, RG.holm([tests[k]["p"] for k in namen])):
        t = tests[k]; t["p_holm"] = ph
        t["haelften"] = bool(np.isfinite(t["h1"]) and np.isfinite(t["h2"]) and t["h1"] > 0 and t["h2"] > 0)
        t["belegt"] = bool(np.isfinite(ph) and ph < ALPHA and t["haelften"] and t["d"] > 0)


def kern_portfolio(je: dict, reihen: dict, n_boot: int) -> dict:
    kern = [c for c in KERN if c in je]
    if not kern:
        return {}
    von = min(je[c]["von"] for c in kern); bis = min(je[c]["bis"] for c in kern)
    if bis - von < 2 * 365:
        return {}
    tage = np.arange(von, bis + 1); n = len(tage)
    port = {}
    for k in B_FOLGE:
        summe = np.zeros(n); anz = np.zeros(n)
        for c in kern:
            r = je[c]["erg"][k]["r"]; a = je[c]["von"] - von
            m = min(n - a, len(r))
            summe[a:a + m] += r[:m]; anz[a:a + m] += 1
        port[k] = np.where(anz > 0, summe / np.maximum(anz, 1), 0.0)
    out = {"von": von, "bis": bis, "coins": kern, "kz": {k: kennzahlen_reihe(port[k], tag0=von) for k in B_FOLGE}, "tests": {}}
    h = n // 2; out["mitte"] = von + h
    for i, k in enumerate(B2_TESTS):
        t = sharpe_test(port[k], port["HODL"], n_boot, BLOCK_B2, SAAT + 31 + i)
        t["h1"] = _sharpe(port[k][:h]) - _sharpe(port["HODL"][:h]); t["h2"] = _sharpe(port[k][h:]) - _sharpe(port["HODL"][h:])
        out["tests"][k] = t
    urteil_b2(out["tests"])
    return out


# ================================================================================================ Teil C: Warnsignale

def ereignis_batch(C: np.ndarray, SIG: np.ndarray, h: int = EREIGNIS_TAGE, k: float = EREIGNIS_K) -> tuple:
    """E[:, t]: tiefster Schluss der Tage t+1 … t+h ≤ c_t·e^{−k·σ_t·√h}; dazu fest −10 %; gültig nur mit h Folgetagen und σ."""
    X = np.log(C); P, n = X.shape
    fmin = np.full((P, n), np.inf)
    for j in range(1, h + 1):
        fmin[:, :n - j] = np.minimum(fmin[:, :n - j], X[:, j:])
    gueltig = np.zeros((P, n), dtype=bool); gueltig[:, :n - h] = True
    gueltig &= np.isfinite(SIG)
    with np.errstate(invalid="ignore"):
        E = fmin <= X - k * SIG * math.sqrt(h)
    E10 = fmin <= X + math.log(1 - EREIGNIS_FEST)
    return E & gueltig, E10 & gueltig, gueltig


def _rr(a, b, c, d):
    with np.errstate(invalid="ignore", divide="ignore"):
        return (a / (a + b)) / (c / (c + d))


def teil_c(reihen: dict, V: np.ndarray, g0: int, n_surr: int, n_boot: int = N_BOOT_C, log=lambda s: None) -> dict:
    """Teil C: je Signal das gepoolte Risikoverhältnis, Null aus den Surrogaten, Intervall aus dem Kalender-Blockbootstrap."""
    coins = [c for c in COINS_TEST if c in reihen and reihen[c]["rolle"] == "test"]
    if not coins:
        return {}
    G0 = min(reihen[c]["tag0"] for c in coins); G1 = max(reihen[c]["tag0"] + reihen[c]["n"] - 1 for c in coins)
    G = G1 - G0 + 1
    # je Signal und Coin: echte Zählung je Kalendertag (für Bootstrap und Hälften) und Summen je Surrogat
    kal = {s: np.zeros((4, G)) for s, _ in SIGNALE}; kal10 = {s: np.zeros((4, G)) for s, _ in SIGNALE}
    null = {s: np.zeros((n_surr, 4)) for s, _ in SIGNALE}; null_h = {s: [np.zeros((n_surr, 4)), np.zeros((n_surr, 4))] for s, _ in SIGNALE}
    abdeckung = {s: [] for s, _ in SIGNALE}; signaltage = {s: [] for s, _ in SIGNALE}
    extern = {}
    for coin in coins:
        R = reihen[coin]; S = R["S"]
        oi = oi_perzentil(R.get("oi")); fz = fz_reihe(R); fng = R.get("fng")
        extern[coin] = {"C1": (oi >= 0.90) if oi is not None else None, "C1d": np.isfinite(oi) if oi is not None else None,
                        "C2": fz >= 2.0, "C2d": np.isfinite(fz), "C4": (fng >= 80) if fng is not None else None,
                        "C4d": np.isfinite(fng) if fng is not None else None}
    # Kalenderhälften je Signal: Mitte der Abdeckung (erste bis letzte Tage mit Signal und Ereignis)
    spannen = {}
    for coin in coins:
        R = reihen[coin]; n = R["n"]; S = R["S"]
        for s, _ in SIGNALE:
            dmask = _signal_definiert(s, extern[coin], n)
            if dmask is None:
                continue
            dm = dmask.copy(); dm[:S] = False; dm[n - EREIGNIS_TAGE:] = False
            if dm.any():
                idx = np.nonzero(dm)[0]
                a, b = R["tag0"] + int(idx[0]), R["tag0"] + int(idx[-1])
                spannen[s] = (min(spannen.get(s, (a, b))[0], a), max(spannen.get(s, (a, b))[1], b))
    mitte = {s: (v[0] + (v[1] - v[0]) // 2) for s, v in spannen.items()}
    for coin in coins:
        R = reihen[coin]; n = R["n"]; S = R["S"]; mu = mu_reihe(R); off = R["tag0"] - G0
        for a in [-1] + list(range(0, n_surr, CHUNK)):
            if a == -1:
                Cb = R["c"][None, :].copy(); zeilen = None
            else:
                zeilen = np.arange(a, min(n_surr, a + CHUNK)); Cb = surrogate(R, V, g0, mu, zeilen)[1:]
            SIG = sigma_batch(renditen(Cb))
            E, E10, gl = ereignis_batch(Cb, SIG)
            RSI = rsi_batch(Cb, 14)
            gl[:, :S] = False
            for s, _ in SIGNALE:
                if s == "C3":
                    sg = RSI >= 80.0; sd = np.isfinite(RSI)
                else:
                    if extern[coin][s] is None:
                        continue
                    sg = np.broadcast_to(extern[coin][s], (Cb.shape[0], n)); sd = np.broadcast_to(extern[coin][s + "d"], (Cb.shape[0], n))
                m = gl & sd
                if not m.any():
                    continue
                A_ = sg & m & E; B_ = sg & m & ~E; C_ = ~sg & m & E; D_ = ~sg & m & ~E
                if a == -1:
                    for i, M_ in enumerate((A_, B_, C_, D_)):
                        kal[s][i, off:off + n] += M_[0]
                    for i, M_ in enumerate((sg & m & E10, sg & m & ~E10, ~sg & m & E10, ~sg & m & ~E10)):
                        kal10[s][i, off:off + n] += M_[0]
                    abdeckung[s].append(coin)
                    signaltage[s].append((coin, np.nonzero(sg[0] & m[0])[0]))
                else:
                    blk = slice(a, a + len(zeilen))
                    null[s][blk] += np.stack([M_.sum(axis=1) for M_ in (A_, B_, C_, D_)], axis=1)
                    if s in mitte:
                        mi = mitte[s] - R["tag0"]
                        for hh, sl_ in enumerate((slice(0, max(0, mi)), slice(max(0, mi), n))):
                            null_h[s][hh][blk] += np.stack([M_[:, sl_].sum(axis=1) for M_ in (A_, B_, C_, D_)], axis=1)
        log(f"    {coin}: Warnsignale gezählt")
    out = {}
    for s, titel in SIGNALE:
        if not abdeckung[s]:
            out[s] = {"titel": titel, "coins": []}
            continue
        k4 = kal[s].sum(axis=1); rr = float(_rr(*k4))
        nz = null[s]; rr_null = _rr(nz[:, 0], nz[:, 1], nz[:, 2], nz[:, 3])
        p = _p_groesser(rr, rr_null) if n_surr else float("nan")
        # Hälften
        h = {}
        if s in mitte:
            mi = mitte[s] - G0
            for hh, sl_ in enumerate((slice(0, mi), slice(mi, G))):
                kk = kal[s][:, sl_].sum(axis=1); e_rr = float(_rr(*kk))
                zz = null_h[s][hh]; n_rr = _rr(zz[:, 0], zz[:, 1], zz[:, 2], zz[:, 3]) if n_surr else np.array([np.nan])
                h[hh] = (e_rr, _nanmed(n_rr) if np.isfinite(n_rr).any() else float("nan"))
        # Kalender-Blockbootstrap des echten RR
        q = _rr_bootstrap(kal[s], n_boot, BLOCK_C, SAAT + 51)
        k10 = kal10[s].sum(axis=1)
        episoden = 0; tage_sig = 0
        for coin, idx in signaltage[s]:
            tage_sig += len(idx)
            if len(idx):
                episoden += 1 + int(np.sum(np.diff(idx) > EREIGNIS_TAGE))
        out[s] = {"titel": titel, "coins": abdeckung[s], "rr": rr, "p": p, "null_median": _nanmed(rr_null) if n_surr else float("nan"),
                  "p_sig": float(k4[0] / (k4[0] + k4[1])) if k4[0] + k4[1] > 0 else float("nan"),
                  "p_ohne": float(k4[2] / (k4[2] + k4[3])) if k4[2] + k4[3] > 0 else float("nan"),
                  "signaltage": tage_sig, "episoden": episoden, "q": q, "haelften_werte": h,
                  "p10_sig": float(k10[0] / (k10[0] + k10[1])) if k10[0] + k10[1] > 0 else float("nan"),
                  "p10_ohne": float(k10[2] / (k10[2] + k10[3])) if k10[2] + k10[3] > 0 else float("nan"),
                  "spanne": spannen.get(s)}
    urteil_c(out)
    return out


def urteil_c(out: dict) -> None:
    """Teil C (vorab): Holm über die Signale mit Daten; belegt mit p Holm < 0,05 und RR über dem Surrogat-Median in beiden Hälften."""
    tests = [s for s, _ in SIGNALE if (out.get(s) or {}).get("coins")]
    for s, ph in zip(tests, RG.holm([out[s]["p"] for s in tests])):
        o = out[s]; o["p_holm"] = ph
        hv = o.get("haelften_werte") or {}
        o["haelften"] = bool(len(hv) == 2 and all(np.isfinite(a) and np.isfinite(b) and a > b for a, b in hv.values()))
        o["belegt"] = bool(np.isfinite(ph) and ph < ALPHA and o["haelften"])


def _signal_definiert(s: str, ex: dict, n: int):
    if s == "C3":
        m = np.ones(n, dtype=bool); m[:15] = False
        return m
    return ex.get(s + "d")


def _rr_bootstrap(k: np.ndarray, n_boot: int, block: int, saat: int) -> tuple:
    """90-%-Band des gepoolten RR aus dem zirkulären Kalender-Blockbootstrap (dieselben Blöcke für alle Coins)."""
    G = k.shape[1]
    if G < 2 * block or n_boot <= 0:
        return (float("nan"), float("nan"))
    kk = np.concatenate([k, k], axis=1); cs = np.concatenate([np.zeros((4, 1)), np.cumsum(kk, axis=1)], axis=1)
    rng = np.random.default_rng(saat); nb = int(math.ceil(G / block)); rr = np.empty(n_boot)
    for i in range(n_boot):
        st = rng.integers(0, G, nb)
        s4 = (cs[:, st + block] - cs[:, st]).sum(axis=1)
        rr[i] = _rr(*s4)
    rr = rr[np.isfinite(rr)]
    return (float(np.quantile(rr, 0.05)), float(np.quantile(rr, 0.95))) if len(rr) else (float("nan"), float("nan"))


# ================================================================================================ Teil D: Gegenprobe mit Ausführung

def teil_d(db: str | None, n_placebo: int = N_PLACEBO, roh: dict | None = None, log=lambda s: None) -> dict:
    """Z1/Z2 mit der U140-Rechnung auf den Binance-30-min-Kerzen ab 2020 (beschreibend, kein Urteil)."""
    if roh is None:
        pfad = SW.swing_pfad(db)
        con = _ro(pfad)
        if con is None:
            return {"grund": f"swing.db fehlt ({pfad})"}
        try:
            roh = {}
            for c in SW.COINS:
                K = SW.kerzen_lesen(con, c)
                roh[c] = (K, SW.funding_lesen(con, c)) if K is not None else None
        except sqlite3.Error as e:
            return {"grund": f"swing.db nicht lesbar: {e}"}
        finally:
            con.close()
    daten = {}
    for c, v in roh.items():
        if v is None or v[0] is None:
            continue
        D = SW.daten_aufbereiten(v[0], v[1])
        if D is not None and D["T"]["nd"] >= SW.VORLAUF_TAGE + 40:
            daten[c] = D
    if not daten:
        return {"grund": "keine Kerzen in swing.db"}
    out = {}
    for i, name in enumerate((Z1, Z2)):
        log(f"    {SW.KURZ[name]} mit Ausführung …")
        out[name] = SW.strategie_rechnen(name, daten, n_placebo, seed=61 + i)
    return {"E": out, "coins": list(daten)}


# ================================================================================================ Studie

def studie_rechnen(reihen: dict, n_a: int = N_SURR_A, n_b: int = N_SURR_B, n_c: int = N_SURR_C, n_placebo: int = N_PLACEBO,
                   n_boot_b: int = N_BOOT_B2, n_boot_c: int = N_BOOT_C, teile=("A", "B", "C"), log=print, saat: int = SAAT) -> dict:
    t0 = time.time()
    if not reihen:
        return {"reihen": {}, "rechenzeit": 0.0}
    g0 = min(R["tag0"] for R in reihen.values()); g1 = max(R["tag0"] + R["n"] - 1 for R in reihen.values())
    V = vorzeichen(max(n_a, n_b, n_c, 1), g0, g1, saat)
    out = {"reihen": reihen, "n_a": n_a, "n_b": n_b, "n_c": n_c, "n_placebo": n_placebo}
    if "A" in teile:
        log("  Teil A: Zyklen …"); out["A"] = teil_a(reihen, V[:n_a], g0, n_a, log)
    if "B" in teile:
        log("  Teil B: Strategien …"); out["B"] = teil_b(reihen, V[:n_b], g0, n_b, n_placebo, n_boot_b, log)
    if "C" in teile:
        log("  Teil C: Warnsignale …"); out["C"] = teil_c(reihen, V[:n_c], g0, n_c, n_boot_c, log)
    out["stand"] = aktueller_stand(reihen)
    out["rechenzeit"] = time.time() - t0
    return out


def aktueller_stand(reihen: dict) -> dict:
    """Je Coin am letzten Tag: Veränderungen, Abstand zum 90-Tage-Hoch und zum Höchststand, Z1 heute, Warnsignale heute."""
    out = {}
    for coin, R in reihen.items():
        c = R["c"]; n = R["n"]
        if n < 40:
            continue
        T = T_aus_reihe(c, R["tag0"]); I = SW.Kennzahlen(T, R.get("F")); d = n - 1
        lg = SW.dip_lage(SW.STRATEGIEN[Z1], T, I, d)
        sig = SW.einstieg(SW.STRATEGIEN[Z1], T, I, d)
        rsi = float(I.rsi(14)[d]); fz = float(I.fz(30)[d]) if R.get("F") is not None else float("nan")
        oi = oi_perzentil(R.get("oi")); fng = R.get("fng")
        out[coin] = {"tag": R["tag0"] + d, "schluss": float(c[d]),
                     "ver": {k: float(c[d] / c[d - k] - 1.0) for k in (1, 7, 30) if d - k >= 0},
                     "hoch90": float(c[max(0, d - 89):d + 1].max()), "hoch_alle": float(c.max()), "hoch_alle_tag": R["tag0"] + int(np.argmax(c)),
                     "sigma": float(I.sig[d]), "dip": lg, "z1_heute": sig is not None, "rsi": rsi, "fz": fz,
                     "oi": float(oi[d]) if oi is not None and np.isfinite(oi[d]) else None,
                     "fng": float(fng[d]) if fng is not None and np.isfinite(fng[d]) else (float(fng[d - 1]) if fng is not None and np.isfinite(fng[d - 1]) else None)}
    return out


def studie(db: str, n_a: int = N_SURR_A, n_b: int = N_SURR_B, n_c: int = N_SURR_C, mit_d: bool = True) -> str:
    t0 = time.time()
    print("Zyklus-Studie (U141): Daten lesen …", flush=True)
    L = daten_laden(db)
    for coin, R in L["reihen"].items():
        print(f"  {coin}: {_dt(R['tag0'])}–{_dt(R['tag0'] + R['n'] - 1)} ({_tausend(R['n'])} Tage, {R['quelle']})", flush=True)
    for f in L["info"]["fehlt"]:
        print(f"  fehlt: {f}", flush=True)
    print("Rechnen …", flush=True)
    V = studie_rechnen(L["reihen"], n_a, n_b, n_c, log=lambda s: print(s, flush=True))
    if mit_d:
        print("  Teil D: Gegenprobe mit Ausführung …", flush=True)
        V["D"] = teil_d(db, log=lambda s: print(s, flush=True))
    V["info"] = L["info"]
    return bericht_text(V, time.time() - t0)


# ================================================================================================ Bericht

def _r(x, nd=2) -> str:
    return _de(x, nd, True) if x is not None and np.isfinite(x) else "—"


def _sig_text(o: dict) -> str:
    return "✓ belegt" if o.get("belegt") else "nicht belegt"


def bericht_text(V: dict, laufzeit: float | None = None) -> str:
    Z = []; a = Z.append
    reihen = V.get("reihen") or {}
    a(f"★ Zyklen: Rallyes, Rücksetzer, Warnsignale (U141) · Modul {VERSION_MODUL}")
    a("Vorab festgelegt in KONZEPT_Zyklen.md (09.10.2026), vor diesem Lauf. Nur Bericht, nur lesend. „Belegt“ heißt: die vorab")
    a("festgelegte Bedingung ist erfüllt, nicht mehr. Keine Anlageberatung -- die Studie misst, was war.")
    a(f"Surrogate: Teil A {V.get('n_a')}, Teil B {V.get('n_b')}, Teil C {V.get('n_c')} (ein Vorzeichen je Kalendertag für alle Coins, Drift "
      f"und Schwankung bleiben); Rechenzeit {_de(V.get('rechenzeit'), 0)} s" + (f", Laufzeit gesamt {_de(laufzeit, 0)} s" if laufzeit else "") + ".")
    a("")
    a("DATEN")
    for coin, R in reihen.items():
        extra = []
        if R.get("F") is not None:
            extra.append(f"Funding ab {_dt(int(R['F']['ts'][0]) // TAG)}")
        if R.get("oi") is not None and np.isfinite(R["oi"]).any():
            extra.append(f"OI ab {_dt(R['tag0'] + int(np.nonzero(np.isfinite(R['oi']))[0][0]))}")
        if R.get("fng") is not None and np.isfinite(R["fng"]).any():
            extra.append(f"Fear & Greed ab {_dt(R['tag0'] + int(np.nonzero(np.isfinite(R['fng']))[0][0]))}")
        if R["gefuellt"]:
            extra.append(f"{R['gefuellt']} Tage aufgefüllt")
        if R["lange_luecken"]:
            extra.append("Reihe beginnt nach einer Lücke " + ", ".join(f"{_dt(x)}–{_dt(y)}" for x, y in R["lange_luecken"][-2:]))
        a(f"  {coin:<5} {R['quelle']:<26} Studie ab {_dt(R['tag0'] + R['S'])}, Teil B ab {_dt(R['tag0'] + R['B']) if R.get('B') is not None else '— (zu kurz)'}, "
          f"bis {_dt(R['tag0'] + R['n'] - 1)} ({'Test' if R['rolle'] == 'test' else 'beschreibend'})" + (f"; {'; '.join(extra)}" if extra else ""))
    for f in (V.get("info") or {}).get("fehlt", []):
        a(f"  fehlt: {f}")
    a("")
    _ergebnis(V, a)
    _stand(V, a)
    if "A" in V:
        _bericht_a(V, a)
    if "B" in V:
        _bericht_b(V, a)
    if "C" in V:
        _bericht_c(V, a)
    if "D" in V:
        _bericht_d(V, a)
    a("")
    a("LESART")
    a("  Teil A vergleicht die echten Rallyes mit 1000 Zufallswegen, die Drift, Schwankungsballung und Tagesbewegungen der echten")
    a("  Kurse behalten und nur die Vorzeichen auslosen. „Wie Zufall“ heißt: Größe und Dauer der Zyklen sind das, was Drift und")
    a("  Schwankung von selbst erzeugen -- dann gibt es kein festes Prozentziel, das „sicher“ vor dem Rücksetzer liegt.")
    a("  Teil B: Wer nur einen Teil f der Tage im Markt ist, hat ohne echtes Timing ein √f-mal kleineres Sharpe als HODL; weniger")
    a("  Rückgang allein ist deshalb kein Beleg. Stops wirken hier am Tagesschluss (Kassa, ohne Funding), im Labor jederzeit (Teil D).")
    a("  Teil C zählt nur Richtungsinformation: Ein Signal, das bloß hohe Schwankung anzeigt, erzeugt auch auf den Surrogaten mehr")
    a("  Rücksetzer. Echtes Geld nur nach belegter Historie und mindestens 6 Monaten Labor ohne Widerspruch, nie automatisch.")
    return "\n".join(Z)


def _ergebnis(V: dict, a) -> None:
    a("ERGEBNIS (Regeln vorab, KONZEPT_Zyklen.md 8)")
    A = V.get("A") or {}
    if A:
        U = A.get("urteil") or {}
        a("  1. Zyklen -- Rallye vom bestätigten Tief bis zum Hoch vor dem nächsten Rücksetzer derselben Größe (Median je Coin):")
        for X in SCHWELLEN:
            t = U.get(X)
            if t is None:
                txt = "ohne Test"
            elif t["belegt"]:
                txt = f"{t['richtung']} als Zufall -- belegt (p Holm {_pz(t['p_holm'])})"
            else:
                txt = f"nicht anders als ein Zufallsweg mit derselben Drift und Schwankung (p Holm {_pz(t['p_holm'])})"
            med = "; ".join(f"{c} {_pl(o['je'][X]['groesse'])} in {_de(o['je'][X]['dauer'], 0)} T"
                            for c, o in A["je_coin"].items() if X in o["je"] and o["je"][X]["n"])
            a(f"     {int(X * 100)} %: {txt}. {med}")
    B = V.get("B") or {}
    b2 = (B.get("b2") or {}).get("tests") or {}
    if b2:
        bel = sorted([(k, t) for k, t in b2.items() if t["belegt"]], key=lambda kt: -kt[1]["d"])
        a("  2. Sicherer als HODL (Sharpe im Kern-Portfolio): " + (", ".join(f"{STRATEGIE_TITEL[k]} ΔSR {_r(t['d'])} (p Holm {_pz(t['p_holm'])})"
                                                                         for k, t in bel) if bel else "keine Strategie belegt sicherer als HODL"))
    b1 = B.get("b1") or {}
    if any(k in b1 for k in B1_TESTS):
        bel = [k for k in B1_TESTS if b1.get(k, {}).get("belegt")]
        a("  3. Timing (besser als derselbe Ablauf auf Zufallswegen): " + (", ".join(STRATEGIE_TITEL[k] for k in bel) if bel else "Z1–Z3 nicht belegt"))
    C = V.get("C") or {}
    if C:
        bel = [(s, o) for s, o in C.items() if o.get("belegt")]
        a("  4. Warnsignale: " + (", ".join(f"{o['titel']} RR {_de(o['rr'], 2)} (90 %: {_de(o['q'][0], 2)}–{_de(o['q'][1], 2)})" for s, o in bel)
                                if bel else "kein Signal belegt"))
    if b2 or b1:
        z_bel = any(b2.get(k, {}).get("belegt") for k in ("Z1", "Z2", "Z3")) or any(b1.get(k, {}).get("belegt") for k in B1_TESTS)
        tv_bel = any(b2.get(k, {}).get("belegt") for k in ("T200", "VOL"))
        if z_bel:
            folge = "Belegtes bei Z1–Z3 ist Kandidat: Labor 6 Monate ohne Widerspruch, dann Entscheidung beim Nutzer."
        elif tv_bel:
            folge = "Nur die einfache Regel (T200/VOL) trägt; die Dip-Idee bringt darüber hinaus nichts Belegtes."
        else:
            folge = "Nichts belegt: HODL im Kern bleibt der Maßstab; Sicherheit kommt aus Größe und Streuung (Rückgänge unten)."
        a(f"  5. Was daraus folgt: {folge}")
    a("")


def _stand(V: dict, a) -> None:
    st = V.get("stand") or {}
    if not st:
        return
    a("AKTUELLER STAND (letzter Tagesschluss je Quelle; nur Lage, keine Empfehlung)")
    A = (V.get("A") or {}).get("je_coin") or {}
    for coin, s in st.items():
        ver = ", ".join(f"{k} T {_pr(v, 1, True)}" for k, v in s["ver"].items())
        a(f"  {coin:<5} {_dt(s['tag'])} Schluss {_px(s['schluss'])} ({ver}); vom 90-Tage-Hoch {_pr(s['schluss'] / s['hoch90'] - 1, 1, True)}, "
          f"vom Höchststand {_pr(s['schluss'] / s['hoch_alle'] - 1, 1, True)} ({_dt(s['hoch_alle_tag'])}); σ_Tag {_de(s['sigma'] * 100, 2)} %")
        for X, o in ((A.get(coin) or {}).get("je") or {}).items():
            b = o.get("stand") or {}
            if b.get("mode") == -1:
                med = o.get("tiefe")
                a(f"        {int(round(X * 100))} %: Abwärtsbein seit Hoch {_px(b['hoch'])} ({_dt(b['hoch_tag'])}) -- Tief bisher {_px(b['tief'])} "
                  f"({_dt(b['tief_tag'])}, {_pr(b['tief'] / b['hoch'] - 1, 1, True)}), heute {_pr(s['schluss'] / b['hoch'] - 1, 1, True)}; Median-Rücksetzer "
                  f"{_pl(med)}; Aufschwung bestätigt ab {_px(b['bestaetigt_ab'])}" if b.get("hoch") else
                  f"        {int(round(X * 100))} %: Abwärtsbein, Tief bisher {_px(b['tief'])}; Aufschwung bestätigt ab {_px(b['bestaetigt_ab'])}")
            elif b.get("mode") == 1:
                med = o.get("groesse")
                a(f"        {int(round(X * 100))} %: Aufwärtsbein seit Tief {_px(b['tief'])} ({_dt(b['tief_tag'])}) -- Hoch bisher {_px(b['hoch'])} "
                  f"({_dt(b['hoch_tag'])}, {_pr(b['hoch'] / b['tief'] - 1, 1, True)}), heute {_pr(s['schluss'] / b['hoch'] - 1, 1, True)} unter dem Hoch; "
                  f"Median-Rallye {_pl(med)}; Rücksetzer bestätigt ab {_px(b['bestaetigt_ab'])}" if b.get("tief") else
                  f"        {int(round(X * 100))} %: Aufwärtsbein, Hoch bisher {_px(b['hoch'])}; Rücksetzer bestätigt ab {_px(b['bestaetigt_ab'])}")
        lg = s.get("dip")
        if lg:
            a(f"        Z1 heute: Dump {_pr(lg['L'] / lg['H'] - 1, 1, True)} = {_de(lg['dump'], 1)} σ (ab 5), Erholung {_de(lg['erholung'], 1)} σ, "
              f"unter dem Hoch {_de(lg['abstand'], 1)} σ (je ab 1) -> {'Signal' if s['z1_heute'] else 'kein Signal'}")
        w = [f"RSI {_de(s['rsi'], 0)} (ab 80)"]
        if np.isfinite(s.get("fz", float("nan"))):
            w.append(f"Funding-z {_de(s['fz'], 1, True)} (ab +2)")
        if s.get("oi") is not None:
            w.append(f"OI-Perzentil {_de(s['oi'], 2)} (ab 0,90)")
        if s.get("fng") is not None:
            w.append(f"Fear & Greed {_de(s['fng'], 0)} (ab 80)")
        a("        Warnsignale heute: " + ", ".join(w))
    a("")


def _bericht_a(V: dict, a) -> None:
    A = V["A"]
    a(f"TEIL A -- ZYKLEN (Directional Change auf Tagesschlüssen; Vergleich mit {V.get('n_a')} Surrogaten, die Drift und Schwankung behalten)")
    a("  Rallye = Tief bis Hoch (bestätigt, sobald der Kurs X % vom Tief gestiegen ist); Rücksetzer = Hoch bis Tief (bestätigt nach X %")
    a("  Fall). „ab Best.“ = vom Schluss am Tag der Bestätigung des Tiefs bis zum Hoch. Runde = am Bestätigungstag des Tiefs kaufen, am")
    a("  Bestätigungstag des Hochs verkaufen (vor Kosten). Je Coin nur beschreibend (p ohne Holm); das Urteil steht darunter.")
    for coin, o in A["je_coin"].items():
        a(f"  {coin} {_dt(o['von'])}–{_dt(o['bis'])} ({_de(o['jahre'], 1)} Jahre)")
        for X, i in o["je"].items():
            if not i["n"]:
                a(f"    {_de(X * 100, 0):>2} %: keine abgeschlossene Rallye"); continue
            a(f"    {_de(X * 100, 0):>2} %: {_n(i['n'], 'Rallye', 'Rallyes')} ({_de(i['je_jahr'], 1)} je Jahr) Median {_pl(i['groesse'])} [{_pl(i['groesse_q'][0])} … "
              f"{_pl(i['groesse_q'][1])}] in {_de(i['dauer'], 0)} T [{_de(i['dauer_q'][0], 0)}…{_de(i['dauer_q'][1], 0)}]; Rücksetzer {_pl(i['tiefe'])} "
              f"[{_pl(i['tiefe_q'][0])} … {_pl(i['tiefe_q'][1])}] in {_de(i['dauer_ab'], 0)} T; Zyklus Tief→Tief {_de(i['zyklus'], 0)} T")
            a(f"         ab Best. bis Hoch {_pl(i['nach'])} in {_de(i['bis_hoch'], 0)} T; Rallyes ≥ {_de(2 * X * 100, 0)} %: {_pr(i['ab_2x'])}, "
              f"≥ {_de(3 * X * 100, 0)} %: {_pr(i['ab_3x'])}; Runde Median {_pl(i['runde'], 1)}, Ø {_pl(i['runde_mittel'], 1)}, Treffer "
              f"{_pr(i['runde_treffer'])}, Haltedauer {_de(i['halten'], 0)} T")
            t = i.get("vergleich")
            if t:
                a(f"         gegen Zufall: Ø Rallye (geometrisch) {_pl(i['mittel_log'])} gegen {_pl(t['null_mittel'])} (90 %: {_pl(t['null_q'][0])} … "
                  f"{_pl(t['null_q'][1])}), p {_pz(t['p'])}; Dauer {_de(i['dauer'], 0)} gegen {_de(t['dauer_null'], 0)} T; Runde Ø "
                  f"{_pl(i['runde_mittel'], 1)} gegen {_pl(t['runde_null'], 1)} (90 %: {_pl(t['runde_null_q'][0], 1)} … {_pl(t['runde_null_q'][1], 1)})")
    U = A.get("urteil") or {}
    if U:
        a(f"  URTEIL je Schwelle (vorab, KONZEPT_Zyklen.md 4/12): Ø log. Rallyegröße je Coin, gemittelt über "
          f"{', '.join(next(iter(U.values()))['coins'])}, gegen dieselbe Größe auf den Surrogaten; Holm über {len(U)}, beide Hälften")
        for X, t in U.items():
            a(f"    {_de(X * 100, 0):>2} %: echt {_pl(t['echt'])} gegen Zufall {_pl(t['null_median'])} (90 %: {_pl(t['null_q'][0])} … {_pl(t['null_q'][1])}), "
              f"p {_pz(t['p'])}, p Holm {_pz(t['p_holm'])}; Hälften {_pl(t['h1'][0])}/{_pl(t['h1'][1])} und {_pl(t['h2'][0])}/{_pl(t['h2'][1])} "
              f"(echt/Zufall, Rallyes {t['n_haelften'][0]}/{t['n_haelften'][1]}) -> Richtung {t['richtung']} als Zufall: "
              f"{'✓ belegt' if t['belegt'] else 'nicht belegt'}")
    a("")


def _bericht_b(V: dict, a) -> None:
    B = V["B"]
    a("TEIL B -- STRATEGIEN (nur Long, Tagesschluss, Kosten je Seite 0,10 % BTC/ETH sonst 0,20 %, kein Funding, Bargeld 0 %)")
    for coin, o in B["je_coin"].items():
        a(f"  {coin} {_dt(o['von'])}–{_dt(o['bis'])} (Kurs {_mal(o['markt'])}; {'Test' if o['rolle'] == 'test' else 'beschreibend'})")
        a(f"    {'Strategie':<32}{'CAGR':>9}{'Sharpe':>8}{'Rückgang':>10}{'Calmar':>8}{'im Markt':>10}{'Trades/J':>9}{'Kosten/J':>9}"
          f"{'schlechtestes Jahr':>20}{'1 T später':>14}")
        for k in B_FOLGE:
            e = o["erg"][k]; kz = e["kz"]
            sj = kz.get("schlechtestes_jahr")
            a(f"    {STRATEGIE_TITEL[k]:<32}{_pr(kz.get('cagr'), 0, True):>9}{_de(kz.get('sharpe'), 2):>8}{_pr(-kz.get('mdd', float('nan')), 0, True):>10}"
              f"{_de(kz.get('calmar'), 2):>8}{_pr(kz.get('im_markt'), 0):>10}{(_de(e.get('trades_jahr'), 1) if k != 'HODL' else '—'):>9}{_pr(kz.get('kosten_jahr'), 1):>9}"
              f"{(f'{sj[0]} {_pr(sj[1], 0, True)}' if sj else '—'):>20}{('SR ' + _de(e['verzoegert']['sharpe'], 2)):>14}")
        z0 = o.get("z0")
        if z0:
            a(f"    {STRATEGIE_TITEL['Z0']:<32}{_pr(z0['cagr'][0], 0, True):>9}{_de(z0['sharpe'][0], 2):>8}{_pr(-z0['mdd'][0], 0, True):>10}{'':>8}"
              f"{_pr(z0['im_markt'], 0):>10}{_de(z0['trades_jahr'], 1):>9}   Median von {V.get('n_placebo')} Läufen, Sharpe 90 %: "
              f"{_de(z0['sharpe'][1], 2)} … {_de(z0['sharpe'][2], 2)}")
        tr = o["erg"]["Z1"]["trades"]
        if tr:
            gr: dict = {}
            for t in tr:
                gr[t["grund"]] = gr.get(t["grund"], 0) + 1
            rs = np.array([t["r"] for t in tr])
            a(f"    Z1-Trades: {len(tr)}, Treffer {_pr(np.mean(rs > 0))}, Ø {_pl(np.mean(rs), 1)} je Trade (Median {_pl(np.median(rs), 1)}), "
              f"Ø Haltedauer {_de(np.mean([t['x'] - t['e'] for t in tr]), 1)} T; Ausstiege " + ", ".join(f"{k} {v}" for k, v in sorted(gr.items(), key=lambda kv: -kv[1]))
              + (f"; offen seit {', '.join(_dt(reihen_tag(V, coin, e)) for e in o['erg']['Z1']['offen'])}" if o["erg"]["Z1"]["offen"] else ""))
    b1 = B.get("b1") or {}
    if any(k in b1 for k in B1_TESTS):
        a(f"  B1 TIMING (Mehrertrag je Markttag gegen die Drift, gepoolt über {', '.join(b1['_coins'])}; Null: {V.get('n_b')} Surrogate; Holm über 3; "
          f"Hälften geteilt am {_dt(b1['_mitte'])})")
        for k in B1_TESTS:
            o = b1[k]
            a(f"    {STRATEGIE_TITEL[k]:<32} {_de(o['stat'] * 1e4, 1, True)} bp je Markttag ({_tausend(o['markttage'])} Markttage), Zufall "
              f"{_de(o['null_median'] * 1e4, 1, True)} bp (90 %: {_de(o['null_q'][0] * 1e4, 1, True)} … {_de(o['null_q'][1] * 1e4, 1, True)}), p "
              f"{_pz(o['p'])}, p Holm {_pz(o['p_holm'])}; Hälften {_de(o['h1'][0] * 1e4, 1, True)}/{_de(o['h1'][1] * 1e4, 1, True)} und "
              f"{_de(o['h2'][0] * 1e4, 1, True)}/{_de(o['h2'][1] * 1e4, 1, True)} bp -> {_sig_text(o)}")
    b2 = B.get("b2") or {}
    if b2:
        a(f"  B2 SICHERER ALS HODL (Kern-Portfolio {'+'.join(b2['coins'])} {_dt(b2['von'])}–{_dt(b2['bis'])}, gleich gewichtet über die "
          f"verfügbaren Coins, täglich ausgeglichen; ΔSR mit Blockbootstrap 30 T, Holm über 5, beide Hälften)")
        a(f"    {'Strategie':<32}{'CAGR':>9}{'Sharpe':>8}{'Rückgang':>10}{'Calmar':>8}{'ΔSR':>8}{'90 %':>16}{'p':>8}{'p Holm':>9}{'Hälften':>14}  Urteil")
        for k in B_FOLGE:
            kz = b2["kz"][k]; t = b2["tests"].get(k)
            zus = (f"{_r(t['d']):>8}{(_de(t['q'][0], 2) + ' … ' + _de(t['q'][1], 2)):>16}{_pz(t['p']):>8}{_pz(t['p_holm']):>9}"
                   f"{(_r(t['h1']) + '/' + _r(t['h2'])):>14}  {_sig_text(t)}") if t else ""
            a(f"    {STRATEGIE_TITEL[k]:<32}{_pr(kz.get('cagr'), 0, True):>9}{_de(kz.get('sharpe'), 2):>8}{_pr(-kz.get('mdd', float('nan')), 0, True):>10}"
              f"{_de(kz.get('calmar'), 2):>8}{zus}")
    a("")


def reihen_tag(V: dict, coin: str, idx: int) -> int:
    return (V.get("reihen") or {}).get(coin, {}).get("tag0", 0) + int(idx)


def _bericht_c(V: dict, a) -> None:
    C = V["C"]
    a(f"TEIL C -- WARNSIGNALE (Ereignis: tiefster Schluss der nächsten {EREIGNIS_TAGE} Tage ≥ {_de(EREIGNIS_K, 1)}·σ·√{EREIGNIS_TAGE} unter dem "
      f"Schluss; RR gepoolt; Null: {V.get('n_c')} Surrogate; Holm über die Signale mit Daten; beide Hälften)")
    for s, titel in SIGNALE:
        o = C.get(s) or {}
        if not o.get("coins"):
            a(f"  {s} {titel}: keine Daten"); continue
        hv = o.get("haelften_werte") or {}
        htxt = " und ".join(f"{_de(e, 2)}/{_de(nm, 2)}" for e, nm in hv.values()) if hv else "—"
        a(f"  {s} {titel} ({', '.join(o['coins'])}, {_dt(o['spanne'][0]) if o.get('spanne') else '—'}–{_dt(o['spanne'][1]) if o.get('spanne') else '—'}): "
          f"{_tausend(o['signaltage'])} Signaltage in {o['episoden']} Episoden; Rücksetzer mit Signal {_pr(o['p_sig'], 1)}, ohne {_pr(o['p_ohne'], 1)}; "
          f"RR {_de(o['rr'], 2)} (90 %: {_de(o['q'][0], 2)}–{_de(o['q'][1], 2)}), Zufall {_de(o['null_median'], 2)}, p {_pz(o['p'])}, p Holm "
          f"{_pz(o.get('p_holm'))}; Hälften {htxt} (echt/Zufall); fest −10 %: {_pr(o['p10_sig'], 1)} gegen {_pr(o['p10_ohne'], 1)} -> {_sig_text(o)}")
    a("  „Crowding“ (Positionierung der Leaderboard-Konten) hat keine lange Historie: vorwärts im Labor (leaderboard_folgen/gegen).")
    a("")


def _bericht_d(V: dict, a) -> None:
    D = V["D"]
    a("TEIL D -- GEGENPROBE MIT AUSFÜHRUNG (hl_swing: Binance-30-min-Kerzen ab 2020, Gebühren, Abstand zur Mitte, Funding; 100 USD Risiko "
      "je Trade; beschreibend, kein Urteil)")
    if D.get("grund"):
        a(f"  {D['grund']}"); a(""); return
    for name, e in D["E"].items():
        if not e.get("n"):
            a(f"  {SW.KURZ[name]}: keine Trades"); continue
        tr = e["trades"]; P = e.get("placebo") or {}; h = e.get("hac") or {}
        gr: dict = {}
        for t in tr:
            gr[t["grund"]] = gr.get(t["grund"], 0) + 1
        a(f"  {SW.KURZ[name]} ({name}): {e['n']} Trades, Treffer {_pr(np.mean([t['netto'] > 0 for t in tr]))}, Ø R {_r(e['mittel_R'])} ± "
          f"{_de(e['se_R'], 2)}, Sharpe/J {_r(e.get('sharpe_jahr'))}, Tagesergebnis p {_pz(h.get('p'))}, Ø Haltedauer "
          f"{_de(np.mean([t['tage'] for t in tr]), 1)} T")
        if P:
            a(f"    Placebo (zufälliger Long-Einstieg, gleiche Ausstiege): Median Ø R {_r(P['median'])}, Mehrertrag {_r(P.get('mehr'))} ± "
              f"{_de(P.get('se'), 2)} R, p {_pz(P.get('p'))}")
        a("    Ausstiege: " + ", ".join(f"{k} {v}" for k, v in sorted(gr.items(), key=lambda kv: -kv[1]))
          + "; je Coin: " + "; ".join(f"{c} {jc['n']} Trades, Summe {_r(jc['summe_R'], 1)} R" for c, jc in e["je_coin"].items()))
    a("")


# ================================================================================================ Selbsttest (ohne Netz)

def _markt_tage(n: int = 3000, saat: int = 1, sigma: float = 0.03, drift: float = 0.0008, effekt=None, nu: float = 4.0,
                garch: tuple = (0.08, 0.90)) -> np.ndarray:
    """Tagesschlüsse: GARCH(1,1) mit t-Schocks; effekt(x_bis_gestern, σ_t, t) -> zusätzliche Drift für Tag t (kausal)."""
    rng = np.random.default_rng(saat); a_, b_ = garch
    om = sigma * sigma * (1 - a_ - b_) if a_ + b_ < 1 else sigma * sigma
    h = sigma * sigma; x = np.empty(n); x[0] = math.log(100.0)
    for t in range(1, n):
        z = rng.standard_t(nu) / math.sqrt(nu / (nu - 2)) if nu > 2 else rng.normal()
        dr = effekt(x[:t], math.sqrt(h), t) if effekt else 0.0
        r = drift + dr + math.sqrt(h) * z
        h = om + a_ * (r - drift - dr) ** 2 + b_ * h if a_ + b_ < 1 else sigma * sigma
        x[t] = x[t - 1] + r
    return np.exp(x)


def _universum_tage(saat: int, n: int = 2600, effekt=None, drift: float = 0.0008, garch=(0.08, 0.90), mit_extern: bool = True,
                    extern_fn=None, coins=COINS_TEST) -> dict:
    """Synthetische Reihen für die Studie (Test-Coins, Start 01.01.2016, S nach 400 Tagen)."""
    t0 = tag_aus("2016-01-01"); reihen = {}
    for i, coin in enumerate(coins):
        eff = effekt() if effekt else None
        c = _markt_tage(n, saat + 97 * i, sigma=0.03 + 0.005 * i, drift=drift, effekt=eff, garch=garch)
        ax = {"tag0": t0, "c": c, "gefuellt": 0, "lange_luecken": []}
        R = reihe_bauen(coin, ax, t0 + VORLAUF_TAGE, "test", "synthetisch")
        if mit_extern:
            rng = np.random.default_rng(saat + 5 * i)
            ts = (t0 + np.arange(n)) * TAG
            R["F"] = {"ts": ts.astype(np.int64), "rate": 1e-4 + rng.normal(0, 5e-5, n)}
            if coin in ("BTC",):
                R["oi"] = 1e5 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))
            if coin in ("BTC", "ETH"):
                R["fng"] = np.clip(50 + 25 * np.sin(np.arange(n) / 37.0) + rng.normal(0, 8, n), 0, 100)
        if extern_fn:
            extern_fn(R, i)
        reihen[coin] = R
    return reihen


def _dc_skalar(x: np.ndarray, u: float, v: float, i0: int = 0) -> list:
    """Referenz: Directional Change Schritt für Schritt (eine Reihe)."""
    mode = 0; hi = lo = x[i0]; hi_i = lo_i = i0; ev = []
    for t in range(i0 + 1, len(x)):
        if mode >= 0 and x[t] > hi:
            hi, hi_i = x[t], t
        if mode <= 0 and x[t] < lo:
            lo, lo_i = x[t], t
        if mode >= 0 and x[t] <= hi - v:
            ev.append((1, hi_i, hi, t, x[t])); mode = -1; lo, lo_i = x[t], t
        elif mode <= 0 and x[t] >= lo + u:
            ev.append((-1, lo_i, lo, t, x[t])); mode = 1; hi, hi_i = x[t], t
    return ev


def _sim_referenz(c: np.ndarray, tag0: int, R: dict, i0: int, i1: int, F: dict | None = None, u=None) -> list:
    """Referenz mit hl_swing.einstieg/plan/nachfuehren Tag für Tag (Ein- und Ausstieg zum Schluss, Stop am Schluss)."""
    T = T_aus_reihe(c, tag0); I = SW.Kennzahlen(T, F)
    trades = []; pos = None; t = i0
    while t <= i1:
        if pos is not None and t > pos["d"]:
            ct = c[t]; grund = None
            if ct <= pos["sl"]:
                grund = "Nachzieh-Stop" if pos["nachgezogen"] else "Stop"
            elif t - pos["d"] >= R["max_tage"]:
                grund = "Zeit"
            else:
                res = SW.nachfuehren(R, T, I, t, {"seite": "long", "e": pos["d"] + 1, "sl": pos["sl"]})
                if res.get("aus"):
                    grund = "Überhitzung"
                elif res.get("sl") is not None:
                    pos["sl"] = res["sl"]; pos["nachgezogen"] = True
            if grund:
                trades.append((pos["d"], t, grund)); pos = None; t += 1
                continue
        if pos is None and t < i1:
            sig = SW.einstieg(R, T, I, t, None if u is None else (u[t], 0.5))
            if sig is not None:
                P = SW.plan(sig, float(c[t]))
                pos = {"d": t, "sl": P["sl"], "nachgezogen": False, "sl0": P["sl"]}
        t += 1
    return trades


def probe(verbose: bool = True, schnell: bool = False) -> tuple:
    pruef = []

    def ok(name, bed, text=""):
        pruef.append((name, bool(bed), text))
        if verbose:
            print(f"  {'ok  ' if bed else 'FEHL'} {name:<72} {text}", flush=True)
    t_start = time.time()
    for fn in (_probe_dc, _probe_rsi_sigma, _probe_dip_hand, _probe_gleichheit, _probe_urteile, _probe_bausteine, _probe_identitaet, _probe_kausal,
               _probe_bericht):
        try:
            fn(ok)
        except Exception as e:
            import traceback
            ok(f"{fn.__name__} ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
    try:
        _probe_statistik(ok, schnell)
    except Exception as e:
        import traceback
        ok("_probe_statistik ohne Absturz", False, f"{type(e).__name__}: {e} -- {traceback.format_exc().splitlines()[-3].strip()}")
    return all(p[1] for p in pruef), pruef, time.time() - t_start


def _probe_dc(ok) -> None:
    # Handreihe: 100 (Start, als Tief bestätigt mit 112) → 120 (Hoch) → 104 bestätigt (≤ 108) → 98 (Tief) → 108 bestätigt (≥ 107,8) → 125
    # (Hoch) → 112 bestätigt (≤ 112,5) → 111 (laufendes Tief, Aufschwung ab 122,1)
    k = [100, 105, 112, 120, 110, 104, 98, 103, 108, 115, 125, 118, 112, 111, 122, 120]
    x = np.log(np.array(k, dtype=float)); u, v = math.log(1.1), -math.log(0.9)
    D = dc_batch(x[None, :], u, v)
    ev = list(zip(D["typ"].tolist(), D["ext_i"].tolist(), D["conf_i"].tolist()))
    soll = [(-1, 0, 2), (1, 3, 5), (-1, 6, 8), (1, 10, 12)]                # Start ohne Richtung: +10 % ab 100 bestätigt das Tief am Start
    Bn = beine(D)
    gr = (Bn["auf"]["x_hoch"] - Bn["auf"]["x_tief"]).tolist()
    runde = (Bn["auf"]["bx_hoch"] - Bn["auf"]["bx_tief"]).tolist()
    st = _dc_stand(D, {"c": np.array(k, dtype=float), "n": len(k), "tag0": 0}, 0.10)
    hand = (ev == soll and len(gr) == 1 and abs(gr[0] - math.log(125 / 98)) < 1e-12 and abs(runde[0] - math.log(112 / 108)) < 1e-12
            and Bn["auf"]["t_tief"].tolist() == [6] and Bn["ab"]["t_hoch"].tolist() == [3]      # erstes Extrem (Tief am Start) beginnt kein Bein
            and st["mode"] == -1 and abs(st["tief"] - 111.0) < 1e-9 and abs(st["bestaetigt_ab"] - 122.1) < 1e-9)
    # gleich der Referenz auf Zufallsreihen, viele Pfade zugleich
    rng = np.random.default_rng(4); X = np.cumsum(rng.normal(0, 0.03, (40, 900)), axis=1)
    Db = dc_batch(X, math.log(1.15), -math.log(0.85), i0=5)
    gleich = True
    for p in range(40):
        m = Db["p"] == p
        ref = _dc_skalar(X[p], math.log(1.15), -math.log(0.85), 5)
        mine = list(zip(Db["typ"][m].tolist(), Db["ext_i"][m].tolist(), Db["ext_x"][m].tolist(), Db["conf_i"][m].tolist(), Db["conf_x"][m].tolist()))
        if [(a, b, round(c, 12), d, round(e, 12)) for a, b, c, d, e in mine] != [(a, b, round(c, 12), d, round(e, 12)) for a, b, c, d, e in ref]:
            gleich = False
    ok("Directional Change: Handreihe (Hochs, Tiefs, Bestätigung, Runde, erstes Extrem), 40 Pfade = Schritt-für-Schritt-Referenz",
       hand and gleich, f"Ereignisse {ev}, Rallye {_pl(gr[0] if gr else None, 1)}, Runde {_pl(runde[0] if runde else None, 1)}, Stand ab {_de(st.get('bestaetigt_ab'), 1)}")


def _probe_rsi_sigma(ok) -> None:
    ref = SW.rsi_wilder(np.array([44.3389, 44.0902, 44.1497, 43.6124, 44.3278, 44.8264, 45.0955, 45.4245, 45.8433, 46.0826, 45.8931, 46.0328,
                                  45.614, 46.282, 46.282, 46.0028, 46.0328, 46.4116, 46.2222, 45.6439]), 14)[14:]
    wilder = np.allclose(np.round(ref, 2), [70.53, 66.32, 66.55, 69.41, 66.36, 57.97])
    rng = np.random.default_rng(8); C = 100 * np.exp(np.cumsum(rng.normal(0, 0.03, (6, 500)), axis=1))
    rb = rsi_batch(C, 14)
    gleich_mk = all(np.allclose(SW.rsi_wilder(C[k], 14), MK.rsi_wilder(C[k], 14), equal_nan=True, rtol=0, atol=1e-10) for k in range(6))
    gleich_b = all(np.allclose(rb[k], SW.rsi_wilder(C[k], 14), equal_nan=True, rtol=0, atol=1e-9) for k in range(6))
    lk = C[0].copy(); lk[100] = np.nan; rl = SW.rsi_wilder(lk, 14); ohne = SW.rsi_wilder(np.delete(C[0], 100), 14)
    luecke = np.isnan(rl[100]) and np.allclose(np.delete(rl, 100), ohne, equal_nan=True)
    sb = sigma_batch(renditen(C))
    gleich_s = all(np.allclose(sb[k], SW.sigma_tag(T_aus_reihe(C[k], 0)["RV"]), equal_nan=True, rtol=1e-12, atol=0) for k in range(6))
    ok("RSI nach Wilder (Rechenbeispiel, = hl_makro, viele Pfade, Lücke) und σ (= hl_swing.sigma_tag)", wilder and gleich_mk and gleich_b and luecke and gleich_s,
       f"Beispiel {', '.join(_de(v, 2) for v in ref[:3])} …; Lücke ohne RSI und Fortsetzung wie ohne den Tag")


def _T_fest(c, s: float = 0.01) -> dict:
    """Handreihe mit fester Schwankung (RV konstant) -- die Schwellen in σ lassen sich so genau setzen."""
    T = T_aus_reihe(np.asarray(c, dtype=float), 0); T["RV"] = np.full(len(c), s * s)
    return T


def _probe_dip_hand(ok) -> None:
    """Z1 von Hand: Schwellen 5 σ/1 σ/1 σ genau (hl_swing und schnelle Rechnung), Fenster, Gleichstand; dann ein gebauter Handel:
    Stop = L·e^{−σ}, Nachzieh-Stop ab dem Folgetag, Zeit 60 T, Überhitzung (RSI und Funding), Kosten, keine Wiederkehr am Ausstiegsschluss."""
    fehler = []
    R1, R2 = SW.STRATEGIEN[Z1], SW.STRATEGIEN[Z2]
    eps = 1e-6

    def fall(dump, erh=None, abst=None, extra=None):
        c = [100.0] * 30
        s0 = SW.Kennzahlen(_T_fest(c + [100.0, 100.0])).sig[31]
        L = 100.0 * math.exp(-dump * s0); c.append(L)
        c.append(L * math.exp(erh * s0) if erh is not None else 100.0 * math.exp(-abst * s0))
        if extra:
            c = extra(c, s0)
        T = _T_fest(c); I = SW.Kennzahlen(T); d = len(c) - 1
        e_sw = SW.einstieg(R1, T, I, d)
        C = np.asarray(c)[None, :]; SIG = np.full_like(C, I.sig[d])
        e_b = bool(dip_matrizen(C, SIG, R1)["ein"][0, d])
        return e_sw, e_b, SW.dip_lage(R1, T, I, d)
    faelle = {"Signal": (5 + eps, 1 + eps, None, True), "Dump 5 σ − ε": (5 - eps, 1 + eps, None, False),
              "Erholung 1 σ − ε": (5 + eps, 1 - eps, None, False), "Abstand 1 σ − ε": (6.0, None, 1 - eps, False),
              "Abstand 1 σ + ε": (6.0, None, 1 + eps, True)}
    for name, (du, er, ab, soll) in faelle.items():
        e_sw, e_b, lg = fall(du, er, ab)
        if (e_sw is not None) != soll or e_b != soll:
            fehler.append(f"{name}: hl_swing {e_sw is not None}, schnell {e_b}")
    # Tief vor 11 Tagen liegt außerhalb des Fensters; Gleichstand -> das jüngste Tief
    def alt_tief(c, s0):
        L = c[30]; return c[:30] + [L] + [L * math.exp(0.5 * s0)] * 10 + [L * math.exp(1.6 * s0)]
    e_sw, e_b, lg = fall(5.2, 1.2, None, alt_tief)
    if e_sw is not None or e_b:
        fehler.append("Fenster 10 Tage")

    def gleich(c, s0):
        L = c[30]; return c[:30] + [L, L * math.exp(0.3 * s0), L, L * math.exp(1.2 * s0)]
    e_sw, e_b, lg = fall(5.2, 1.2, None, gleich)
    if not (lg and lg["j"] == 32 and e_sw is not None and e_b):
        fehler.append("Gleichstand")
    # gebauter Handel mit echtem σ aus den Renditen: ruhige Vorgeschichte (±1 %), Dump, Erholung genau über der Schwelle
    base = [100.0]
    for k in range(80):
        base.append(base[-1] * (1.01 if k % 2 == 0 else 1 / 1.01))
    c = np.array(base + [base[-1] * f for f in (0.97, 0.94, 0.91, 0.885, 0.89)], dtype=float)
    d = len(c) - 1; L = c[d - 1]
    sv = sigma_batch(renditen(c[None, :]))[0, d - 1]
    c[d] = L * math.exp(sv) * (1 + 1e-9)                                  # Erholung = σ_{d−1}: genau die Schwelle 1 σ_d (r_d = σ_{d−1})
    T = T_aus_reihe(c, 0); I = SW.Kennzahlen(T)
    e1 = SW.einstieg(R1, T, I, d)
    c_lo = c.copy(); c_lo[d] = L * math.exp(sv) * (1 - 1e-9); T_lo = T_aus_reihe(c_lo, 0)
    if e1 is None or SW.einstieg(R1, T_lo, SW.Kennzahlen(T_lo), d) is not None:
        fehler.append("Erholung mit echtem σ")
    sl_soll = L * math.exp(-I.sig[d])
    if e1 is not None and abs(SW.plan(e1, float(c[d]))["sl"] / sl_soll - 1) > 1e-12:
        fehler.append("Stop L·e^{−σ}")

    def handel(weiter, R, **kw):
        cw = np.concatenate([c, np.asarray(weiter, dtype=float)]); C = cw[None, :]
        SIG = sigma_batch(renditen(C)); D = dip_matrizen(C, SIG, R1)
        RSI = kw.pop("RSI", None)
        if isinstance(RSI, str):
            RSI = rsi_batch(C, 14)
        L_ = simulieren(C, SIG, D["ein"], D["LS"], R, 30, len(cw) - 1, 0.001, RSI=RSI, Lziel=D["L"], **kw)
        return cw, SIG, L_, _trades_liste(L_["trades"]), RSI
    # Nachzieh-Stop: 30 Tage +0,4 %, dann −3 % je Tag
    cw, SIG, L1, t1, _ = handel([c[d] * math.exp(0.004 * k) for k in range(1, 31)] + [c[d] * math.exp(0.12 - 0.03 * k) for k in range(1, 8)], R1)
    if not (len(t1) == 1 and t1[0]["e"] == d and t1[0]["grund"] == "Nachzieh-Stop"):
        fehler.append(f"Nachzieh-Stop {[(x['e'], x['x'], x['grund']) for x in t1]}")
    else:
        x = t1[0]["x"]; best = cw[d + 1:x].max(); sl_ = best * math.exp(-3 * SIG[0, x - 1])
        if not (cw[x] <= sl_ * (1 + 1e-12) and cw[x - 1] > best * math.exp(-3 * SIG[0, x - 2])):
            fehler.append("Nachzieh-Stop: Tag")
        if abs(L1["kost"][0].sum() - 0.002) > 1e-12 or not L1["pos"][0, d] or L1["pos"][0, x] or L1["pos"][0, d - 1]:
            fehler.append("Kosten/Position")
    # Zeit: langsamer Anstieg -> Ausstieg nach genau 60 Tagen
    _, _, _, tz, _ = handel(c[d] * np.exp(0.0005 * np.arange(1, 75)), R1)
    if not (tz and tz[0]["grund"] == "Zeit" and tz[0]["x"] - tz[0]["e"] == 60):
        fehler.append(f"Zeit {[(x['e'], x['x'], x['grund']) for x in tz]}")
    # Überhitzung: steiler Anstieg -> RSI ≥ 80 -> Z2 raus am ersten solchen Schluss
    cw, _, _, t2, RSI = handel(c[d] * np.exp(0.03 * np.arange(1, 26)), R2, RSI="echt")
    erstes = int(np.nonzero(RSI[0, d + 1:] >= 80)[0][0]) + d + 1 if np.any(RSI[0, d + 1:] >= 80) else None
    if not (erstes and t2 and t2[0]["grund"] == "Überhitzung" and t2[0]["x"] == erstes):
        fehler.append(f"Überhitzung {[(x['e'], x['x'], x['grund']) for x in t2]} (RSI ≥ 80 ab {erstes})")
    _, _, _, t1h, _ = handel(c[d] * np.exp(0.03 * np.arange(1, 26)), R1)
    if t1h and t1h[0]["grund"] == "Überhitzung":
        fehler.append("Z1 ohne Überhitzungs-Ausstieg")
    # Funding-Druck ≥ 2 an einem Tag -> Z2 raus an genau diesem Schluss
    n2 = len(c) + 25; FZ = np.zeros(n2); FZ[d + 3] = 2.0
    _, _, _, t2f, _ = handel(c[d] * np.exp(0.03 * np.arange(1, 26)), R2, RSI=np.zeros((1, n2)), FZ=FZ)
    if not (t2f and t2f[0]["x"] == d + 3 and t2f[0]["grund"] == "Überhitzung"):
        fehler.append("Funding-Druck")
    # keine Wiederkehr am Ausstiegsschluss: fallender Kurs, Einstieg jeden Tag erlaubt -> Stop, nächster Einstieg erst am Folgetag
    cf = np.concatenate([c, c[d] * np.exp(-0.03 * np.arange(1, 30))]); Cf = cf[None, :]; Sf = sigma_batch(renditen(Cf))
    Lr = simulieren(Cf, Sf, np.ones_like(Cf, dtype=bool), Cf.copy(), SW.STRATEGIEN[ZZ], d + 1, len(cf) - 1, 0.001)
    tr_ = _trades_liste(Lr["trades"])
    if not (len(tr_) >= 5 and all(b_["e"] == a_["x"] + 1 for a_, b_ in zip(tr_, tr_[1:]))):
        fehler.append(f"Wiederkehr {[(x['e'], x['x']) for x in tr_[:4]]}")
    ok("Z1/Z2 von Hand: Schwellen 5 σ/1 σ/1 σ genau (hl_swing = schnell), Fenster, Gleichstand, Stop L·e^{−σ}, Nachzieh-Stop, Zeit, Überhitzung",
       not fehler, ", ".join(fehler) if fehler else f"Einstieg Tag {d}, Stop {_de(sl_soll, 3)}, {len(tr_)} Stops ohne Wiederkehr am selben Schluss")


def _probe_gleichheit(ok) -> None:
    """Die schnelle Rechnung (viele Pfade) gegen hl_swing.einstieg/plan/nachfuehren Tag für Tag: dieselben Einstiege und Ausstiege."""
    fehler = []; n_tr = 0
    for saat in (3, 4, 5):
        c = _markt_tage(1400, saat, sigma=0.035, drift=0.0005)
        rng = np.random.default_rng(saat)
        F = {"ts": (np.arange(1400) * TAG).astype(np.int64), "rate": 1e-4 + rng.normal(0, 8e-5, 1400)}
        T = T_aus_reihe(c, 0); I = SW.Kennzahlen(T, F)
        C = c[None, :]; SIG = sigma_batch(renditen(C)); D = dip_matrizen(C, SIG, SW.STRATEGIEN[Z1])
        ein_ref = np.array([SW.einstieg(SW.STRATEGIEN[Z1], T, I, d) is not None for d in range(1400)])
        if not np.array_equal(ein_ref, D["ein"][0]):
            fehler.append(f"Einstiege Saat {saat}: {int(np.sum(ein_ref != D['ein'][0]))} Tage")
        fz = I.fz(30); RSI = rsi_batch(C, 14)
        for name, kw in ((Z1, {}), (Z2, {"RSI": RSI, "FZ": fz})):
            Rr = SW.STRATEGIEN[name]
            L_ = simulieren(C, SIG, D["ein"], D["LS"], Rr, 300, 1399, 0.001, Lziel=D["L"], **kw)
            mine = [(t["e"], t["x"], t["grund"]) for t in _trades_liste(L_["trades"])]
            ref = _sim_referenz(c, 0, Rr, 300, 1399, F)
            n_tr += len(ref)
            if mine != ref:
                fehler.append(f"{name} Saat {saat}: {len(mine)} gegen {len(ref)} Trades, erste Abweichung "
                              f"{next(((a, b) for a, b in zip(mine, ref) if a != b), None)}")
        # Kontrolle mit denselben Zufallszahlen
        u = np.random.default_rng(saat + 9).random(1400)
        EIN = (u < SW.STRATEGIEN[ZZ]["p_tag"])[None, :] & D["ok"] & np.isfinite(D["LS"])
        Lz = simulieren(C, SIG, EIN, D["LS"], SW.STRATEGIEN[ZZ], 300, 1399, 0.001)
        mine = [(t["e"], t["x"], t["grund"]) for t in _trades_liste(Lz["trades"])]
        ref = _sim_referenz(c, 0, SW.STRATEGIEN[ZZ], 300, 1399, F, u=u)
        if mine != ref:
            fehler.append(f"Zufall Saat {saat}: {len(mine)} gegen {len(ref)}")
    ok("Gleichheit mit dem Labor: Z1, Z2 und Zufall = hl_swing.einstieg/plan/nachfuehren Tag für Tag (3 Märkte)", not fehler,
       "; ".join(fehler[:3]) if fehler else f"{n_tr} Trades gleich (Einstiegstag, Ausstiegstag, Grund)")


def _probe_urteile(ok) -> None:
    """Die vorab festgelegten Urteile an gebauten Ergebnissen: Holm, Richtung, Hälften, Mindestzahl, ΔSR > 0, Signale mit Daten."""
    fehler = []

    def a_(p, echt=0.5, nm=0.4, h1=(0.5, 0.4), h2=(0.5, 0.4), nh=(5, 5)):
        return {"p": p, "echt": echt, "null_median": nm, "h1": h1, "h2": h2, "n_haelften": nh}
    U = {0.1: a_(0.01), 0.2: a_(0.02), 0.3: a_(0.04)}; urteil_a(U)                      # Holm 0,03 / 0,04 / 0,04
    if not (all(U[X]["belegt"] for X in U) and [round(U[X]["p_holm"], 9) for X in U] == [0.03, 0.04, 0.04]):
        fehler.append("A Holm")
    U = {0.1: a_(0.01), 0.2: a_(0.02, h2=(0.3, 0.4)), 0.3: a_(0.04, nh=(2, 5))}; urteil_a(U)
    if [U[X]["belegt"] for X in U] != [True, False, False]:
        fehler.append("A Hälften/Mindestzahl")
    U = {0.1: a_(0.02), 0.2: a_(0.03), 0.3: a_(0.03)}; urteil_a(U)
    if any(U[X]["belegt"] for X in U):
        fehler.append("A ohne Holm")
    U = {0.1: a_(0.001, echt=0.3, nm=0.4, h1=(0.3, 0.4), h2=(0.35, 0.4))}; urteil_a(U)
    if not (U[0.1]["belegt"] and U[0.1]["richtung"] == "kürzer"):
        fehler.append("A Richtung")

    def b_(p, h1=(1e-4, 0.0), h2=(1e-4, 0.0)):
        return {"p": p, "h1": h1, "h2": h2}
    b1 = {"Z1": b_(0.01), "Z2": b_(0.02, h2=(-1e-4, 0.0)), "Z3": b_(0.3)}; urteil_b1(b1)
    if [b1[k]["belegt"] for k in B1_TESTS] != [True, False, False] or abs(b1["Z2"]["p_holm"] - 0.04) > 1e-12:
        fehler.append("B1")

    def t_(p, d=0.2, h1=0.1, h2=0.1):
        return {"p": p, "d": d, "h1": h1, "h2": h2}
    tests = {"T200": t_(0.005), "VOL": t_(0.01, h1=-0.1), "Z1": t_(0.011), "Z2": t_(0.5), "Z3": t_(0.004, d=-0.1)}; urteil_b2(tests)
    if [tests[k]["belegt"] for k in B2_TESTS] != [True, False, True, False, False] or abs(tests["Z1"]["p_holm"] - 0.03) > 1e-12:
        fehler.append("B2")

    def c_(p, hv=((1.5, 1.0), (1.4, 1.0))):
        return {"coins": ["BTC"], "p": p, "haelften_werte": {0: hv[0], 1: hv[1]}}
    C = {"C1": c_(0.001), "C2": c_(0.02), "C3": c_(0.004, hv=((1.5, 1.0), (0.9, 1.0))), "C4": {"coins": []}}; urteil_c(C)
    if [C[k].get("belegt") for k in ("C1", "C2", "C3")] != [True, True, False] or "p_holm" in C["C4"] or abs(C["C3"]["p_holm"] - 0.008) > 1e-12:
        fehler.append("C")
    ok("Urteile von Hand: Holm, Richtung, Hälften, Mindestzahl Rallyes, ΔSR > 0, nur Signale mit Daten", not fehler,
       ", ".join(fehler) if fehler else "A, B1, B2, C wie in KONZEPT_Zyklen.md 4–6")


def _probe_identitaet(ok) -> None:
    """Surrogate mit Vorzeichen +1 sind die echten Kurse: Dann muss jede Null-Größe (Teil A ganz und je Hälfte, B1 ganz und je
    Hälfte, C ganz und je Hälfte) der echten gleichen -- fängt jede ungleiche Behandlung von echten Kursen und Surrogaten."""
    reihen = _universum_tage(81, n=1600)
    g0 = min(R["tag0"] for R in reihen.values()); g1 = max(R["tag0"] + R["n"] - 1 for R in reihen.values())
    V = np.ones((3, g1 - g0 + 1), dtype=np.int8)
    fehler = []
    gl = lambda a, b: np.isfinite(a) and np.isfinite(b) and abs(a - b) <= 1e-9 * max(1.0, abs(a))
    A = teil_a(reihen, V, g0, 3)
    for X, t in A["urteil"].items():
        if not (gl(t["echt"], t["null_median"]) and gl(*t["h1"]) and gl(*t["h2"])):
            fehler.append(f"A {int(X * 100)} %")
    B = teil_b(reihen, V, g0, 3, n_placebo=0, n_boot=50)
    for k in B1_TESTS:
        o = B["b1"][k]
        if not (gl(o["stat"], o["null_median"]) and gl(*o["h1"]) and gl(*o["h2"])):
            fehler.append(f"B1 {k}")
    C = teil_c(reihen, V, g0, 3, n_boot=10)
    for s_, o in C.items():
        if not o.get("coins") or not o["signaltage"]:
            continue
        if not (gl(o["rr"], o["null_median"]) and all(gl(e, nm) for e, nm in o["haelften_werte"].values())):
            fehler.append(f"C {s_}")
    ok("Surrogate mit Vorzeichen +1 = echte Kurse: Null-Größen A, B1, C (ganz und je Hälfte) gleich den echten", not fehler,
       ", ".join(fehler) if fehler else f"{len(A['urteil'])} Schwellen, {len(B1_TESTS)} Strategien, {sum(1 for o in C.values() if o.get('coins'))} Signale gleich")


def _probe_bausteine(ok) -> None:
    fehler = []
    # T200: Schluss über dem Mittel der 200 Tage einschließlich heute
    c = np.concatenate([np.full(250, 100.0), np.full(50, 101.0), np.full(100, 99.0)])
    p = t200_pos(c, 220, 399)
    c2 = np.concatenate([np.full(100, 100.0), [1000.0], np.full(199, 100.0), [100.5]])     # Ausreißer genau 200 Tage vor dem Prüftag
    if not (p[249] == 0 and p[250] == 1 and p[299] == 1 and p[300] == 0 and p[219] == 0 and t200_pos(c2, 299, 300)[300] == 1
            and t200_pos(c2, 299, 300)[299] == 0):
        fehler.append("T200")
    Cb = np.array([[100.0, 101.0, 102.0, 101.0, 103.0]]); pos_ = np.array([[False, True, True, False, False]])
    kost_ = np.array([[0.0, 0.001, 0.0, 0.001, 0.0]])
    g, h1, h2 = _b1_stat({"pos": pos_, "kost": kost_}, Cb, 0.001, 0, 4, 3)
    soll = (math.log(102 / 101) - 0.001 + math.log(101 / 102) - 0.001 - 0.002)
    if not (abs(g[0][0] - soll) < 1e-12 and g[1][0] == 2 and abs(h1[0][0] - (math.log(102 / 101) - 0.001 - 0.001)) < 1e-12 and h1[1][0] == 1
            and abs(h2[0][0] - (math.log(101 / 102) - 0.001 - 0.001)) < 1e-12 and h2[1][0] == 1):
        fehler.append("B1-Statistik")
    # Z3: Ziel erst ab dem Tag nach dem Ende des 10. Trades, Median der Höchststände nur aus Trades, die vorher endeten
    x_ = np.arange(10, 130, 10); sp_ = np.exp(0.01 * np.arange(1, 13) * 3)               # Höchststand k·3 σ bei σ 1 %, L = 1
    T1 = {"p": np.zeros(12, dtype=np.int64), "x": x_, "spitze": sp_, "L": np.ones(12), "s_e": np.full(12, 0.01)}
    M = ziel_matrix(T1, None, 1, 140)
    soll_m = {100: np.nan, 101: np.median(3.0 * np.arange(1, 11)), 110: np.median(3.0 * np.arange(1, 11)), 111: np.median(3.0 * np.arange(1, 12)),
              121: np.median(3.0 * np.arange(1, 13)), 139: np.median(3.0 * np.arange(1, 13))}
    if not all((np.isnan(v) and np.isnan(M[0, t])) or abs(M[0, t] - v) < 1e-9 for t, v in soll_m.items()) or np.isfinite(M[0, :101]).any():
        fehler.append("Z3-Ziel kausal")
    # Kosten: HODL kauft einmal; eine Runde kostet 2 × Satz
    r = renditen_aus_pos(np.full(10, 100.0), np.array([0, 0, 1, 1, 1, 0, 0, 0, 0, 0], dtype=float), 0.001, 0, 9)
    if abs(r.sum() + 0.002) > 1e-12 or abs(r[2] + 0.001) > 1e-12 or abs(r[5] + 0.001) > 1e-12:
        fehler.append("Kosten")
    # VOL: doppelte Schwankung -> halber Anteil; Schritt 0,10
    sig = np.concatenate([np.full(400, 0.02), np.full(10, 0.021), np.full(30, 0.04), np.full(30, 0.021)])
    w = vol_pos(sig, 380, 469)
    if not (abs(w[399] - 1) < 1e-12 and abs(w[400] - 1) < 1e-12 and abs(w[410] - 0.5) < 1e-12 and abs(w[440] - 0.02 / 0.021) < 1e-12):
        fehler.append(f"VOL {w[399]:.3f} {w[400]:.3f} {w[410]:.3f} {w[440]:.3f}")             # 0,048 Änderung: kein Umschichten
    # Sharpe-Test: gleiche Reihen -> ΔSR 0, p groß; Holm
    rng = np.random.default_rng(2); x = rng.normal(0.001, 0.03, 1500)
    t = sharpe_test(x, x.copy(), 300)
    if not (abs(t["d"]) < 1e-12 and t["p"] > 0.4):
        fehler.append(f"Sharpe gleich p {t['p']:.2f}")
    t2 = sharpe_test(x + 0.002, x, 300)
    if not (t2["d"] > 0 and t2["p"] < 0.01):
        fehler.append(f"Sharpe besser p {t2['p']:.3f}")
    if [round(v, 6) for v in RG.holm([0.01, 0.04, 0.03])] != [0.03, 0.06, 0.06]:
        fehler.append("Holm")
    # Ereignis: Fall um 1,5 σ √14 genau an der Grenze
    C = np.full((1, 40), 100.0); S_ = np.full((1, 40), 0.01)
    C[0, 10] = 100.0 * math.exp(-1.5 * 0.01 * math.sqrt(14)) * (1 - 1e-9)
    E, E10, gl = ereignis_batch(C, S_)
    soll = np.zeros(40, dtype=bool); soll[0:10] = True                     # Tage 0 … 9 sehen den Fall an Tag 10 in ihren 14 Folgetagen
    C[0, 10] = 100.0 * math.exp(-1.5 * 0.01 * math.sqrt(14)) * (1 + 1e-9)
    E_knapp, _, _ = ereignis_batch(C, S_)
    if not (np.array_equal(E[0], soll) and not E_knapp[0].any() and gl[0, :26].all() and not gl[0, 26:].any()):
        fehler.append(f"Ereignis {np.nonzero(E[0])[0].tolist()}")
    # OI-Perzentil: Mittelrang wie hl_indikatoren._rank
    oi = np.concatenate([np.arange(1.0, 91.0), [90.0]])
    pz = oi_perzentil(oi)
    if abs(pz[90] - (89 + 0.5) / 90) > 1e-12:
        fehler.append("OI-Perzentil")
    # Surrogate: echte erste Zeile, Drift und |r − μ| bleiben, Vorzeichen je Kalendertag für alle Coins gleich
    R1 = {"c": 100 * np.exp(np.cumsum(rng.normal(0, 0.02, 300))), "tag0": 1000, "n": 300, "S": 0}
    R2 = {"c": 50 * np.exp(np.cumsum(rng.normal(0, 0.03, 200))), "tag0": 1100, "n": 200, "S": 0}
    Vz = vorzeichen(5, 1000, 1299, 3)
    mu1 = mu_reihe(R1)
    S1 = surrogate(R1, Vz, 1000, mu1); S2 = surrogate(R2, Vz, 1000, mu_reihe(R2))
    r1 = np.diff(np.log(S1), axis=1); r1e = np.diff(np.log(R1["c"]))
    gl_ = np.allclose(S1[0], R1["c"]) and np.allclose(np.abs(r1[1:] - mu1), np.abs(r1e - mu1)[None, :])
    vz1 = np.sign(r1[1:, 100:] - mu1); vz2 = np.sign(np.diff(np.log(S2), axis=1)[1:, :199] - mu_reihe(R2))
    e1 = np.sign(r1e[100:] - mu1); e2 = np.sign(np.diff(np.log(R2["c"]))[:199] - mu_reihe(R2))
    gemeinsam = np.array_equal(vz1[:, :199] * e1[None, :199], vz2 * e2[None, :])
    if not (gl_ and gemeinsam):
        fehler.append("Surrogate")
    ok("Bausteine: T200, Kosten, VOL, Sharpe-Test, Holm, Ereignis 1,5 σ √14, OI-Perzentil, Surrogate (Vorzeichen je Kalendertag gemeinsam)",
       not fehler, ", ".join(fehler) if fehler else "alle wie von Hand")


def _probe_kausal(ok) -> None:
    """Kurse nach Tag d ändern: Signale, Positionen, σ, RSI und Ereignisse bis d (Ereignis bis d − 14) bitgleich."""
    c = _markt_tage(1300, 21, sigma=0.035)
    c2 = c.copy(); d0 = 900
    c2[d0 + 1:] = c2[d0 + 1:] * np.exp(np.cumsum(np.random.default_rng(1).normal(0, 0.05, len(c2) - d0 - 1)))
    fehler = []
    res = []
    for cc in (c, c2):
        C = cc[None, :]; SIG = sigma_batch(renditen(C)); D = dip_matrizen(C, SIG, SW.STRATEGIEN[Z1]); RSI = rsi_batch(C)
        Zl = z_laeufe(C, {"kosten": 0.001}, 400, 1299, np.full(len(cc), np.nan))
        E, _, _ = ereignis_batch(C, SIG)
        res.append((SIG[0], D["ein"][0], RSI[0], Zl["Z1"]["pos"][0], Zl["Z2"]["pos"][0], Zl["Z3"]["pos"][0], t200_pos(cc, 400, 1299),
                    vol_pos(SIG[0], 400, 1299), E[0]))
    for name, a_, b_ in zip(("σ", "Einstieg", "RSI", "Z1", "Z2", "Z3", "T200", "VOL"), res[0][:8], res[1][:8]):
        if not np.array_equal(a_[:d0 + 1], b_[:d0 + 1], equal_nan=True) if a_.dtype.kind == "f" else not np.array_equal(a_[:d0 + 1], b_[:d0 + 1]):
            fehler.append(name)
    if not np.array_equal(res[0][8][:d0 - EREIGNIS_TAGE + 1], res[1][8][:d0 - EREIGNIS_TAGE + 1]):
        fehler.append("Ereignis")
    gegen = not np.array_equal(res[0][3][d0 + 1:], res[1][3][d0 + 1:]) or not np.array_equal(res[0][1][d0 + 1:], res[1][1][d0 + 1:])
    ok("Kausalität: Kurse nach Tag 900 geändert -> σ, Z1-Lage, RSI, Positionen Z1/Z2/Z3/T200/VOL bis 900 und Ereignis bis 886 gleich",
       not fehler and gegen, ("abweichend: " + ", ".join(fehler)) if fehler else "bitgleich; danach verschieden (Gegenprobe)")


def _probe_bericht(ok) -> None:
    reihen = _universum_tage(77, n=1500)
    del reihen["ZEC"]
    reihen["ETH"]["oi"] = None; reihen["XMR"]["F"] = None
    ax = {"tag0": tag_aus("2025-06-01"), "c": _markt_tage(400, 5, sigma=0.05), "gefuellt": 2, "lange_luecken": [(tag_aus("2025-05-01"), tag_aus("2025-05-20"))]}
    reihen["HYPE"] = reihe_bauen("HYPE", ax, None, "beschreibend", "synthetisch")
    axg = {"tag0": tag_aus("2023-10-01"), "c": _markt_tage(1100, 6, sigma=0.01, drift=0.0004), "gefuellt": 0, "lange_luecken": []}
    reihen["PAXG"] = reihe_bauen("PAXG", axg, None, "beschreibend", "synthetisch", schwellen=SCHWELLEN_GOLD)
    V = studie_rechnen(reihen, n_a=40, n_b=20, n_c=40, n_placebo=10, n_boot_b=100, n_boot_c=100, log=lambda s: None)
    V["D"] = teil_d(None, n_placebo=10, roh={k: v for k, v in list(SW._universum(5, n=2, tage=700, drift=0.001).items())})
    V["info"] = {"fehlt": ["ZEC: zu wenig Tage in makro.db"]}
    txt = bericht_text(V)
    teile = ("ERGEBNIS", "AKTUELLER STAND", "TEIL A", "TEIL B", "B1 TIMING", "B2 SICHERER ALS HODL", "TEIL C", "TEIL D", "LESART",
             "Z0 Zufall", "Runde", "Warnsignale heute", "HYPE", "PAXG", "fehlt: ZEC", "Reihe beginnt nach einer Lücke", "3 %")
    fehlt = [t for t in teile if t not in txt]
    ok("Bericht: alle Abschnitte, fehlende Reihen (ZEC, OI, Funding), HYPE/PAXG beschreibend, Teil D", not fehlt,
       f"fehlt: {fehlt}" if fehlt else f"{len(txt)} Zeichen")


def _effekt_dip(staerke: float = 0.4, tage: int = 10):
    """Positivkontrolle B1: nach einem Z1-Signal (gleiche Regel, σ aus den Tagesrenditen) tage lang Drift +staerke σ."""
    zustand = {"rest": 0, "e": None, "lam": 0.5 ** (1 / HWZ)}

    def f(x, s, t):
        if t >= 2:
            r = x[-1] - x[-2]
            zustand["e"] = r * r if zustand["e"] is None else zustand["lam"] * zustand["e"] + (1 - zustand["lam"]) * r * r
        if zustand["rest"] > 0:
            zustand["rest"] -= 1
            return staerke * s
        if t < 32 or zustand["e"] is None:
            return 0.0
        sg = math.sqrt(zustand["e"]); w = x[-11:-1]
        j = len(x) - 2 - int(np.argmin(w[::-1])); L = x[j]; H = x[j - 19:j + 1].max()
        if H - L >= 5 * sg and x[-1] - L >= sg and H - x[-1] >= sg:
            zustand["rest"] = tage - 1
            return staerke * s
        return 0.0
    return f


def _effekt_heiss(staerke: float = 0.6, tage: int = 7):
    """Positivkontrolle C3: nach RSI(14) ≥ 80 (Wilder, aus den Schlüssen) tage lang Drift −staerke σ."""
    zustand = {"rest": 0, "ag": None, "av": None, "n": 0, "g": [], "v": []}

    def f(x, s, t):
        if t >= 2:
            dlt = math.exp(x[-1]) - math.exp(x[-2]); g, v = max(dlt, 0.0), max(-dlt, 0.0)
            z = zustand; z["n"] += 1
            if z["ag"] is None:
                z["g"].append(g); z["v"].append(v)
                if z["n"] == 14:
                    z["ag"], z["av"] = sum(z["g"]) / 14, sum(z["v"]) / 14
            else:
                z["ag"] = (z["ag"] * 13 + g) / 14; z["av"] = (z["av"] * 13 + v) / 14
        z = zustand
        if z["rest"] > 0:
            z["rest"] -= 1
            return -staerke * s
        if z["ag"] is not None:
            rsi = 100.0 if z["av"] == 0 else 100 - 100 / (1 + z["ag"] / z["av"])
            if rsi >= 80:
                z["rest"] = tage - 1
                return -staerke * s
        return 0.0
    return f


def _effekt_regime(staerke: float = 0.005, dauer: int = 200, saat: int = 0):
    """Positivkontrollen A und B2: Drift-Regime ±staerke je Tag, Wechsel im Mittel alle dauer Tage (eigener Zufall je Coin)."""
    zaehler = {"k": 0}

    def fabrik():
        zaehler["k"] += 1
        z = {"r": 1.0, "rng": np.random.default_rng(saat * 1000 + zaehler["k"])}

        def f(x, s, t):
            if z["rng"].random() < 1.0 / dauer:
                z["r"] = -z["r"]
            return staerke * z["r"]
        return f
    return fabrik


def _effekt_ruecklauf(halb: float = 15.0):
    """Positivkontrolle A (Umkehr auf der Bein-Skala): der Log-Kurs wird zum Mittel der 200 Tage davor zurückgezogen."""
    def fabrik():
        k = 1 - 0.5 ** (1 / halb)

        def f(x, s, t):
            return -k * (x[-1] - x[-200:].mean()) if t >= 30 else 0.0
        return f
    return fabrik


def _probe_statistik(ok, schnell: bool = False) -> None:
    """Nulltests und Positivkontrollen der vorab festgelegten Urteile (weniger Surrogate als im Bericht, Holm wie im Bericht)."""
    nA, nB, nC = 600, 100, 160
    still = lambda s: None
    # Nulltest: faire Vorzeichen, GARCH, Drift -> A, B1, C ohne Beleg
    reihen = _universum_tage(11, n=2600)
    V0 = studie_rechnen(reihen, n_a=nA, n_b=nB, n_c=nC, n_placebo=20, n_boot_b=200, n_boot_c=100, log=still)
    bel_a = [X for X, t in V0["A"]["urteil"].items() if t["belegt"]]
    bel_b1 = [k for k in B1_TESTS if V0["B"]["b1"][k]["belegt"]]
    bel_c = [s for s, o in V0["C"].items() if o.get("belegt")]
    pa = [round(t["p"], 2) for t in V0["A"]["urteil"].values()]
    ok("Nulltest: Zufallsmarkt (4 Coins, GARCH, Drift, faire Vorzeichen) -> Zyklen, Timing und Warnsignale ohne Beleg",
       not bel_a and not bel_b1 and not bel_c,
       f"A p {pa}; B1 p {[round(V0['B']['b1'][k]['p'], 2) for k in B1_TESTS]}; C p {[round(o['p'], 2) for o in V0['C'].values() if o.get('coins')]}"
       + (f" -- belegt: {bel_a} {bel_b1} {bel_c}" if bel_a or bel_b1 or bel_c else ""))
    # B2-Null: unabhängige Tagesrenditen (ohne Ballung) -> keine Strategie sicherer als HODL
    rb = _universum_tage(12, n=3200, garch=(0.0, 0.0), drift=0.0012, coins=("BTC", "ETH"))
    Vb = studie_rechnen(rb, n_a=0, n_b=0, n_c=0, n_placebo=0, n_boot_b=300, teile=("B",), log=still)
    bel2 = [k for k, t in Vb["B"]["b2"]["tests"].items() if t["belegt"]]
    ok("Nulltest B2: unabhängige Renditen mit Drift -> keine Strategie sicherer als HODL", not bel2,
       ", ".join(f"{k} ΔSR {_r(t['d'])} p {_pz(t['p_holm'])}" for k, t in Vb["B"]["b2"]["tests"].items()))
    # Positivkontrollen A: Schwung auf der Bein-Skala (Drift-Regime) -> länger; Rücklauf zum 200-Tage-Mittel -> kürzer
    for name, fabrik, drift, soll in (("Drift-Regime ±0,5 %/Tag", _effekt_regime(0.005, 100, 3), 0.0, "länger"),
                                      ("Rücklauf zum 200-Tage-Mittel (Halbwertszeit 15 T)", _effekt_ruecklauf(15.0), 0.0005, "kürzer")):
        ra = _universum_tage(20, n=2600, effekt=fabrik, drift=drift, mit_extern=False)
        Va = studie_rechnen(ra, n_a=nA, teile=("A",), log=still)
        U = Va["A"]["urteil"]
        bel = [(X, t["richtung"]) for X, t in U.items() if t["belegt"]]
        ok(f"Positivkontrolle A: {name} -> Rallyes {soll} als Zufall belegt", bel and all(r == soll for _, r in bel),
           ", ".join(f"{int(X * 100)} % p Holm {_pz(t['p_holm'])} {t['richtung']}" for X, t in U.items()))
    # Positivkontrolle B1: Erholung nach Dumps -> Z1 belegt
    rp = _universum_tage(30, n=2600, effekt=lambda: _effekt_dip(0.5, 10), mit_extern=False)
    Vp = studie_rechnen(rp, n_a=0, n_b=nB, n_c=0, n_placebo=10, n_boot_b=200, teile=("B",), log=still)
    o = Vp["B"]["b1"]["Z1"]
    ok("Positivkontrolle B1: gepflanzte Erholung nach Dumps -> Z1 Timing belegt", o["belegt"],
       f"{_de(o['stat'] * 1e4, 1, True)} bp je Markttag gegen Zufall {_de(o['null_median'] * 1e4, 1, True)}, p Holm {_pz(o['p_holm'])}")
    # Positivkontrolle B2: lange Trends mit Crashs -> T200 sicherer als HODL
    rt = _universum_tage(40, n=4000, effekt=_effekt_regime(0.006, 250, 40), drift=0.0, mit_extern=False, coins=("BTC", "ETH"))
    Vt = studie_rechnen(rt, n_a=0, n_b=0, n_c=0, n_placebo=0, n_boot_b=300, teile=("B",), log=still)
    t = Vt["B"]["b2"]["tests"]["T200"]
    ok("Positivkontrolle B2: lange Trends mit Crashs -> T200 sicherer als HODL belegt", t["belegt"],
       f"ΔSR {_r(t['d'])} (Hälften {_r(t['h1'])}/{_r(t['h2'])}), p Holm {_pz(t['p_holm'])}")
    # Positivkontrolle C3: Rücksetzer nach RSI ≥ 80
    rc = _universum_tage(50, n=2600, effekt=lambda: _effekt_heiss(0.6, 7), mit_extern=False)
    Vc = studie_rechnen(rc, n_a=0, n_b=0, n_c=nC, teile=("C",), n_boot_c=100, log=still)
    o = Vc["C"]["C3"]
    ok("Positivkontrolle C3: gepflanzter Rücksetzer nach RSI ≥ 80 -> C3 belegt", o["belegt"],
       f"RR {_de(o['rr'], 2)} gegen Zufall {_de(o['null_median'], 2)}, p Holm {_pz(o['p_holm'])}")
    # Positivkontrolle C4: ein äußeres Signal kündigt Rücksetzer an (Gier 85 vor gepflanztem Fall)
    def mit_gier(R, i):
        if R["coin"] not in ("BTC", "ETH"):
            return
        rng = np.random.default_rng(600 + i); n = R["n"]
        tage = np.nonzero(rng.random(n) < 0.012)[0]
        fng = np.full(n, 50.0); fng[tage] = 85.0
        x = np.log(R["c"]); s_ = 0.03
        for d in tage:
            if d + 8 < n:
                x[d + 1:d + 8] -= 0.6 * s_ * np.arange(1, 8)
                x[d + 8:] -= 0.6 * s_ * 7
        R["c"] = np.exp(x); R["fng"] = fng
    rg = _universum_tage(60, n=2600, mit_extern=False, extern_fn=mit_gier)
    Vg = studie_rechnen(rg, n_a=0, n_b=0, n_c=nC, teile=("C",), n_boot_c=100, log=still)
    o = Vg["C"]["C4"]
    ok("Positivkontrolle C4: äußeres Signal vor gepflanztem Fall -> C4 belegt (C1/C2 ohne Daten)", o["belegt"] and not Vg["C"]["C1"].get("coins"),
       f"RR {_de(o['rr'], 2)} gegen Zufall {_de(o['null_median'], 2)}, p Holm {_pz(o['p_holm'])}")


def selbsttest(schnell: bool = False) -> bool:
    print("Zyklus-Studie (U141) -- Selbsttest: Directional Change, RSI/σ, Z1/Z2 von Hand und gleich hl_swing, Bausteine, Kausalität, Bericht, "
          "Nulltests, Positivkontrollen", flush=True)
    alles, _, dauer = probe(True, schnell)
    print(f"  Ergebnis: {'bestanden' if alles else 'NICHT bestanden'} ({dauer:.0f} s)", flush=True)
    return alles


# ================================================================================================ Aufruf

def main() -> int:
    ap = argparse.ArgumentParser(description="Zyklus-Studie (U141): Rallyes, Rücksetzer, Warnsignale, Dip halten")
    ap.add_argument("--studie", action="store_true")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--db", default=os.environ.get("HL_DB", "hl_liq.db"))
    ap.add_argument("--surrogate", type=int, default=None, help="weniger Surrogate (nur zum Ausprobieren; das Urteil gilt mit den Standardwerten)")
    ap.add_argument("--ohne-d", action="store_true")
    a = ap.parse_args()
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.studie:
        n = a.surrogate
        print(studie(a.db, n or N_SURR_A, min(n, N_SURR_B) if n else N_SURR_B, n or N_SURR_C, not a.ohne_d), flush=True)
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
