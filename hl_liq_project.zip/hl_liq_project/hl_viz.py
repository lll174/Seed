#!/usr/bin/env python3
"""
hl_viz.py — Visualisierung für die von hl_recorder.py aufgezeichneten Daten.

Drei Modi:
    python hl_viz.py --coin BTC                  # Heatmap als PNG
    python hl_viz.py --coin BTC --depth          # aktueller Snapshot als Balken
    python hl_viz.py --serve                     # Live-Dashboard im Browser

Das Dashboard läuft parallel zum Recorder auf derselben SQLite-Datei
(WAL-Modus, gleichzeitiges Lesen ist unproblematisch) und aktualisiert sich
selbst. Es braucht keine Internetverbindung und keine JS-Bibliotheken.
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import re
import shutil
import subprocess
import sys
import math
import sqlite3
import time
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB_PATH = "hl_liq.db"


def connect(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA temp_store=MEMORY")      # Sortierpuffer im RAM, nicht auf der SD-Karte
    return con


# ---------------------------------------------------------------------------
# Datenabfrage
# ---------------------------------------------------------------------------

def load_grid(con, coin: str, hours: int):
    """Heatmap als Gitter (Zeitachse x Preisachse) plus Preisreihe."""
    t_from = int(time.time()) - hours * 3600

    heat = con.execute(
        "SELECT ts, bucket_px, side, notional FROM heatmap "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    bars = con.execute(
        "SELECT ts, open, high, low, close, volume FROM bars "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    liqs = con.execute(
        "SELECT ts, px, sz, side FROM liquidations "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()

    if not heat or not bars:
        return None

    times = sorted({r["ts"] for r in heat})
    levels = sorted({r["bucket_px"] for r in heat})
    t_idx = {t: i for i, t in enumerate(times)}
    l_idx = {p: i for i, p in enumerate(levels)}

    grid = [[0.0] * len(times) for _ in levels]
    sides = [[""] * len(times) for _ in levels]
    for r in heat:
        i, j = l_idx[r["bucket_px"]], t_idx[r["ts"]]
        grid[i][j] += r["notional"]
        sides[i][j] = r["side"]

    return {
        "times": times, "levels": levels, "grid": grid, "sides": sides,
        "price": [(r["ts"], r["close"]) for r in bars],
        "liqs": [(r["ts"], r["px"], r["px"] * r["sz"], r["side"]) for r in liqs],
    }


def bnc_grid(con, coin: str, hours: int) -> dict:
    """Heatmap der EINGETRETENEN Binance-Liquidationen: 10-min-Spalten x 0,25-%-Preisstufen."""
    now = int(time.time()); t_from = now - hours * 3600
    liqs = bnc_liqs(con, coin, t_from)
    cand, _ = bnc_candles(con, coin, 5, hours * 60)
    times = list(range(t_from // 600 * 600, now + 600, 600))
    t_idx = {t: i for i, t in enumerate(times)}
    cells: dict = {}
    for ts, px, usd, side in liqs:
        cells.setdefault((bucket_px(px), ts // 600 * 600), [0.0, side])
        cells[(bucket_px(px), ts // 600 * 600)][0] += usd
    levels = sorted({b for b, _ in cells})
    l_idx = {p: i for i, p in enumerate(levels)}
    grid = [[0.0] * len(times) for _ in levels]; sides = [[""] * len(times) for _ in levels]
    for (b, t), (usd, side) in cells.items():
        if t in t_idx:
            grid[l_idx[b]][t_idx[t]] += usd; sides[l_idx[b]][t_idx[t]] = side
    return {"times": times, "levels": levels, "grid": grid, "sides": sides,
            "price": [(c["t"], c["c"]) for c in cand], "liqs": [(ts, px, usd, "A" if side == "long" else "B") for ts, px, usd, side in liqs],
            # Zellen mit Summe: Binance meldet EINZELNE Orders; ein Hotspot ist eine Summe je
            # Preisstufe und Zeitfenster. Die Fusions-Heatmap zeichnet nur Zellen über der Schwelle.
            "cells": sorted([(t, b, usd, side) for (b, t), (usd, side) in cells.items()]),
            "realized": True}


def bnc_depth(con, coin: str, hours: int = 24) -> dict:
    """Momentaufnahme der eingetretenen Liquidationen der letzten Stunden, je Preisstufe und Seite."""
    now = int(time.time()); liqs = bnc_liqs(con, coin, now - hours * 3600)
    agg: dict = {}
    for ts, px, usd, side in liqs:
        c = agg.setdefault((bucket_px(px), side), {"bucket_px": bucket_px(px), "side": side, "notional": 0.0, "n_pos": 0})
        c["notional"] += usd; c["n_pos"] += 1
    cand, _ = bnc_candles(con, coin, 1, 120)
    price = cand[-1]["c"] if cand else None
    vol_1h = sum(c["v"] * c["c"] for c in cand[-60:]) if cand else 0
    return {"rows": sorted(agg.values(), key=lambda r: r["bucket_px"]), "price": price, "vol_1h": vol_1h,
            "ts": max((l[0] for l in liqs), default=now), "realized": True, "hours": hours}


def load_depth(con, coin: str):
    """Aktuellster Snapshot: Cluster ober- und unterhalb des Kurses."""
    row = con.execute(
        "SELECT MAX(ts) t FROM heatmap WHERE coin=?", (coin,)).fetchone()
    if not row or not row["t"]:
        return None
    ts = row["t"]
    rows = con.execute(
        "SELECT bucket_px, side, notional, n_pos FROM heatmap "
        "WHERE coin=? AND ts=? ORDER BY bucket_px", (coin, ts)).fetchall()
    px = con.execute(
        "SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1",
        (coin,)).fetchone()
    vol = con.execute(
        "SELECT SUM(volume*close) v FROM bars WHERE coin=? AND ts>=?",
        (coin, ts - 3600)).fetchone()
    return {
        "ts": ts,
        "price": px["close"] if px else None,
        "vol_1h": (vol["v"] or 0) if vol else 0,
        "rows": [dict(r) for r in rows],
    }


# ---------------------------------------------------------------------------
# Statische Grafiken
# ---------------------------------------------------------------------------

_SPERRE_CACHE: dict = {"ts": 0.0, "set": set()}
_HOSTS_CACHE: dict = {"ts": 0.0, "set": set()}


def _eigene_hosts() -> set:
    """Adressen und Namen, unter denen dieser Rechner erreichbar ist (S1: Host-Allowlist für POST)."""
    if time.time() - _HOSTS_CACHE["ts"] < 300:
        return _HOSTS_CACHE["set"]
    out = {"localhost", "127.0.0.1", "::1", "0.0.0.0"}
    try:
        import socket
        hn = socket.gethostname(); out.add(hn.lower()); out.add((hn + ".local").lower())
        for info in socket.getaddrinfo(hn, None):
            out.add(str(info[4][0]))
        try:
            s_ = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s_.connect(("10.255.255.255", 1)); out.add(s_.getsockname()[0]); s_.close()
        except OSError:
            pass
    except Exception:
        pass
    try:
        for a in (_lbl_own() or {}).get("_hosts", []) if isinstance((_lbl_own() or {}).get("_hosts"), list) else []:
            out.add(str(a).lower())
    except Exception:
        pass
    _HOSTS_CACHE.update({"ts": time.time(), "set": out})
    return out


def gesperrte_konten(con) -> set:
    """
    Masterregel (22.09.): dauerhaft gesperrte Konten (konto_status, vom Recorder ab 300 gebündelten Trades/24 h, bis 23.12 ab 2.000 Fills/Tag
    geschrieben) plus manuelle Liste (labels.json "sperre": true; "sperre": false schützt). 60 s gecacht.
    Gesperrte liefern kein Verhaltenssignal: nicht in Direktionalen Walen, Wal-Flow, Scores, Elite,
    Smart-Flow, Gegen-Flow; Leaderboard-Flows/Fills entfallen, weil der Recorder sie nicht mehr abfragt.
    """
    if time.time() - _SPERRE_CACHE["ts"] < 60:
        return _SPERRE_CACHE["set"]
    out: set = set()
    try:
        out = {r[0].lower() for r in con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}   # 23.29: vorläufig zählt mit
    except sqlite3.OperationalError:
        pass
    try:
        for a, v in (_lbl_own() or {}).items():
            if isinstance(v, dict) and "sperre" in v:
                (out.add if v.get("sperre") else out.discard)(a.lower())
    except Exception:
        pass
    _SPERRE_CACHE.update({"ts": time.time(), "set": out})
    return out


_WH: dict = {"lock": threading.Lock(), "cache": {}, "lauf": {}}
_WAL_OFFEN: dict = {"ts": 0, "map": {}, "rechnet": False}
_WAL_OFFEN_LOCK = threading.Lock()


def load_whales(con, coin: str, hours: int = 72, cache_s: float = 0):
    """
    Aktuelle Wale, Ereignisse und Netto-Exposure-Zeitreihe.
    23.35: cache_s > 0 (Dashboard-Abruf, Prognose): Ergebnis so lange im Speicher, und je Coin und Fenster rechnet höchstens
    EIN Thread -- wer währenddessen fragt, bekommt den vorigen Stand oder wartet auf die laufende Berechnung. Vorher rechneten
    im Thread-Abzug vom 30.09. sechs Threads gleichzeitig dieselbe Abfrage (vier Seitenabrufe, zwei Prognosen).
    """
    if cache_s <= 0:
        return _load_whales_roh(con, coin, hours)
    key = (coin, int(hours))
    with _WH["lock"]:
        c = _WH["cache"].get(key)
        if c and time.time() - c[0] < cache_s:
            return c[1]
        ev = _WH["lauf"].get(key)
        eigner = ev is None
        if eigner:
            ev = threading.Event(); _WH["lauf"][key] = ev
        elif c:
            return c[1]                                            # läuft schon: vorigen Stand liefern
    if not eigner:
        ev.wait(180)
        with _WH["lock"]:
            c = _WH["cache"].get(key)
        return c[1] if c else _load_whales_roh(con, coin, hours)
    try:
        p = _load_whales_roh(con, coin, hours)
        with _WH["lock"]:
            _WH["cache"][key] = (time.time(), p)
            if len(_WH["cache"]) > 32:
                _WH["cache"].pop(min(_WH["cache"], key=lambda k: _WH["cache"][k][0]), None)
        return p
    finally:
        with _WH["lock"]:
            if _WH["lauf"].get(key) is ev:
                _WH["lauf"].pop(key, None)
        ev.set()


def _wal_eroeffnet(con, now: int) -> dict:
    """
    23.35: (Konto, Coin) -> Zeitpunkt, an dem die laufende Position eröffnet wurde (erste „open“ nach dem letzten „close“),
    aus den Ereignissen der letzten 30 Tage in EINEM Durchgang, 10 min im Speicher, höchstens eine Berechnung zugleich.
    Vorher je Position zwei verschachtelte Unterabfragen über die ganze Tabelle. Frühere Eröffnungen: None.
    """
    with _WAL_OFFEN_LOCK:
        if now - _WAL_OFFEN["ts"] < 600 or (_WAL_OFFEN["rechnet"] and _WAL_OFFEN["ts"]):
            return _WAL_OFFEN["map"]
        _WAL_OFFEN["rechnet"] = True
    try:
        m: dict = {}
        for ts, a, c, ev in con.execute("SELECT ts, addr, coin, event FROM whale_positions WHERE ts>=? AND event IN ('open','close') ORDER BY ts",
                                        (now - 30 * 86_400,)):
            if ev == "close":
                m.pop((a, c), None)
            elif (a, c) not in m:
                m[(a, c)] = int(ts)
        with _WAL_OFFEN_LOCK:
            _WAL_OFFEN.update(ts=now, map=m)
        return m
    except sqlite3.OperationalError:
        return {}
    finally:
        with _WAL_OFFEN_LOCK:
            _WAL_OFFEN["rechnet"] = False


def _load_whales_roh(con, coin: str, hours: int = 72):
    try:
        con.execute("SELECT 1 FROM whale_positions LIMIT 1")
    except sqlite3.OperationalError:
        return {"current": [], "events": [], "exposure": [], "price": []}
    t_from = int(time.time()) - hours * 3600

    # letzter Zustand je Wal-Position: jüngste Zeile der letzten 6 h, die kein close ist. 23.35: vorher über die GANZE Tabelle
    # mit verschachtelten Unterabfragen (41 s bei 2 Mio Zeilen auf einem schnellen Rechner, Minuten auf dem Pi) -- und dieselbe
    # Position kam doppelt, wenn zwei Ereignisse denselben Zeitstempel trugen (z. B. add und snap). Offene Positionen haben alle
    # 10 min einen Snapshot; die Eröffnungszeit kommt aus dem Fenster selbst, ältere aus _wal_eroeffnet (30 Tage).
    now_c = int(time.time())
    letzt: dict = {}; offen_fenster: dict = {}
    felder = ("addr", "coin", "event", "side", "size", "pos_value", "entry_px", "liq_px", "leverage", "upnl", "mark_px", "ts")
    cur_ = con.cursor(); cur_.row_factory = None                      # Tupel: im großen Durchgang deutlich schneller als sqlite3.Row
    for r in cur_.execute(f"SELECT {', '.join(felder)} FROM whale_positions WHERE ts>=? ORDER BY ts", (now_c - WAL_FENSTER_S,)):
        k = (r[0], r[1]); v_ = letzt.get(k)
        if r[2] == "close":
            offen_fenster[k] = None                                   # im Fenster geschlossen: ältere Eröffnung gilt nicht mehr
        elif r[2] == "open" and (v_ is None or v_[2] == "close" or offen_fenster.get(k) is None):
            offen_fenster[k] = int(r[11])                             # erste Eröffnung nach dem letzten Schließen
        if v_ is not None and v_[11] == r[11] and v_[2] == "close":
            continue                                                  # gleicher Zeitstempel: das Schließen gewinnt (Stand)
        letzt[k] = r
    offen_alt = _wal_eroeffnet(con, now_c) if any(k not in offen_fenster for k in letzt) else {}
    current = []
    for k, r in letzt.items():
        if r[2] == "close":
            continue
        d = {f: r[i] for i, f in enumerate(felder) if f != "event"}
        d["opened_at"] = offen_fenster[k] if k in offen_fenster else offen_alt.get(k)
        current.append(d)
    current.sort(key=lambda d: -(d["pos_value"] or 0))

    events = con.execute("""
        SELECT ts, addr, event, side, pos_value, delta_usd, mark_px, leverage
        FROM whale_positions
        WHERE coin=? AND ts>=? AND event != 'snap' ORDER BY ts""",
        (coin, t_from)).fetchall()
    G_ = gesperrte_konten(con)                                        # Masterregel: Gesperrte tragen kein Signal
    if G_:
        current = [r for r in current if str(r["addr"]).lower() not in G_]
        events = [r for r in events if str(r[1]).lower() not in G_]

    # Wal-Flow: Netto-Fluss der DIREKTIONALEN Wale in den letzten 15/30/60 min -- das schnellste
    # Signal, das wir haben (Wale werden jede Minute abgefragt). Kaufdruck = Long eröffnet/aufgestockt
    # oder Short reduziert/geschlossen; Verkaufsdruck umgekehrt. Maßstab: Z-Score gegen die eigene
    # Verteilung der Stundenflüsse der letzten 7 Tage; Breite = wie viele Wale in dieselbe Richtung.
    bmap0 = behavior_map(con)
    pc = behavior_per_coin(con)
    now_ = int(time.time())
    ev_rows = con.execute("""SELECT ts, addr, event, side, delta_usd FROM whale_positions
                             WHERE coin=? AND ts>=? AND event IN ('open','add','reduce','close','flip')""",
                          (coin, now_ - 7 * 86_400)).fetchall()

    def group_of(addr_l: str) -> str:
        """
        Gruppe des Kontos IN DIESEM COIN. Hat es hier gerade keine Position (etwa weil es sie
        geschlossen hat), gilt die kontoweite Klasse -- NICHT blind "direktional": Ein Market
        Maker, der seine BTC-Position schließt, bleibt ein Market Maker.
        """
        e = pc.get((addr_l, coin))
        if e:
            return e["group"]
        cls = bmap0.get(addr_l, "")
        if cls.startswith("Market-Maker"):
            return "mm"
        if cls.startswith("Hedge"):
            return "hedge"
        if cls.startswith("gemischt"):
            return "mixed"
        return "dir"

    # Alle Konten, die in diesem Coin Ereignisse haben -- auch solche, die nicht mehr in der
    # Wal-Liste stehen, weil sie ihre Position geschlossen haben. Sonst fiele genau das
    # aussagekräftigste Ereignis (ein Wal steigt vollständig aus) aus jeder Gruppe heraus.
    grp_of = {a: group_of(a) for a in ({r["addr"].lower() for r in ev_rows} | set(bmap0))}
    dir_set = {a for a, g in grp_of.items() if g == "dir"}

    def signed(event: str, side: str, delta) -> float:
        d = abs(delta or 0)
        if event in ("open", "add", "flip"):
            return d if side == "long" else -d
        return -d if side == "long" else d                     # reduce/close einer Long-Position = Verkaufsdruck
    # Jede Gruppe bekommt ihre eigene Statistik: Wer alle außer den direktionalen ausschließt,
    # erfährt nie, ob eine andere Gruppe das bessere Signal liefert. Die Selbstkalibrierung
    # misst es und gewichtet entsprechend -- ausschließen wäre eine Annahme, messen ist Wissen.
    #
    # EIN Durchgang über die Ereignisse für alle Gruppen und alle Fenster. Vier Gruppen mal
    # drei Fenster plus Stundenreihe wären 16 Durchläufe über bis zu 280.000 Zeilen gewesen --
    # mehrere Sekunden je Aufruf auf dem Pi.
    acc = {g: {w: {"buy": 0.0, "sell": 0.0, "nb": set(), "ns": set()} for w in (15, 30, 60)} for g in GROUPS}
    hourly = {g: {} for g in GROUPS}
    cut = {w: now_ - w * 60 for w in (15, 30, 60)}
    for r in ev_rows:
        a = r["addr"].lower(); g = grp_of.get(a, "dir")
        v = signed(r["event"], r["side"], r["delta_usd"])
        if v:
            h = hourly[g]; b = r["ts"] // 3600
            h[b] = h.get(b, 0.0) + v
        ts = r["ts"]
        if ts < cut[60] or not v:
            continue
        for w in (15, 30, 60):
            if ts >= cut[w]:
                d = acc[g][w]
                if v > 0: d["buy"] += v; d["nb"].add(a)
                else: d["sell"] += -v; d["ns"].add(a)

    members_by_group = {}
    for a, g in grp_of.items():
        members_by_group.setdefault(g, set()).add(a)

    def pack(g: str) -> dict:
        f = {f"w{w}": {"buy_usd": acc[g][w]["buy"], "sell_usd": acc[g][w]["sell"],
                       "net_usd": acc[g][w]["buy"] - acc[g][w]["sell"],
                       "n_buy": len(acc[g][w]["nb"]), "n_sell": len(acc[g][w]["ns"])} for w in (15, 30, 60)}
        # Die Vergleichsverteilung muss alle Stunden enthalten, auch die ruhigen --
        # "in dieser Stunde floss nichts" ist eine Beobachtung, kein fehlender Messwert.
        #
        # Ein Z-Wert ist dafür aber das falsche Werkzeug: Trägt man die Nullstunden
        # einfach nach, schrumpft die Streuung (der Mittelwert liegt ohnehin nahe null),
        # die Z-Werte wachsen, und das Signal feuerte in der Prüfung in 42 statt 2 Prozent
        # der Stunden. Eine Verteilung, die zu drei Vierteln aus Nullen besteht, ist nicht
        # glockenförmig; Mittelwert und Streuung beschreiben sie nicht.
        #
        # Deshalb entscheidet über das Signal jetzt der RANG: Gehört diese Stunde zu den
        # stärksten der Woche? Das ist robust gegen die vielen Nullen und unmittelbar
        # verständlich. Der Z-Wert bleibt als grobe Kennzahl erhalten, berechnet wie
        # bisher über die aktiven Stunden.
        # Vergleichsreihe OHNE die laufende Stunde: Sie enthält den Fluss, der gerade eingeordnet
        # werden soll -- ein Wert, der mit sich selbst verglichen wird, wirkt kleiner als er ist.
        aktive = [v for h_, v in hourly[g].items() if h_ != now_ // 3600]
        # Rang in der vollständigen Wochenreihe (hl_forecast.rang_in_reihe, vom Nulltest geprüft).
        # Nur mit mindestens 48 h Ereignis-Historie -- sonst wäre jede Zahl ein Rekord.
        hist_h = (now_ - min((r["ts"] for r in ev_rows), default=now_)) / 3600
        def rang(wert: float) -> float | None:
            if hist_h < 48:
                return None
            return hl_forecast.rang_in_reihe(wert, aktive)
        vals = aktive
        if len(vals) >= 24:
            m = sum(vals) / len(vals); sd = (sum((v - m) ** 2 for v in vals) / max(1, len(vals) - 1)) ** 0.5
            f["hour_sd"] = sd
            f["z30"] = (f["w30"]["net_usd"] * 2 - m) / sd if sd > 0 else 0.0     # 30 min auf Stunde hochgerechnet
            f["z60"] = (f["w60"]["net_usd"] - m) / sd if sd > 0 else 0.0
        else:
            f["hour_sd"] = f["z30"] = f["z60"] = None
        w30 = f["w30"]; same = w30["n_buy"] if w30["net_usd"] > 0 else w30["n_sell"]
        f["breadth"] = same
        # M9: Signal = Rang statt Z-Wert. Drei Bedingungen, alle nötig:
        #  1. Rang: die 30-min-Summe (auf die Stunde hochgerechnet) gehört zu den obersten
        #     2 % der Wochenstunden -- ein Perzentil feuert per Konstruktion mit fester Rate,
        #  2. deshalb eine absolute Untergrenze von 1 Mio netto,
        #  3. und Breite: mindestens vier direktionale Wale in dieselbe Richtung.
        # Der Z-Wert bleibt als Kennzahl für die Anzeige.
        f["rang30"] = rang(w30["net_usd"] * 2)
        f["event_signal"] = bool(f["rang30"] is not None and f["rang30"] >= 98 and abs(w30["net_usd"]) >= 1e6 and same >= 4)
        f["event_signal_z"] = bool(f["z30"] is not None and abs(f["z30"]) >= 2.5 and same >= 4)   # alte Regel, nur zum Vergleich
        f["n_members"] = len(members_by_group.get(g, ()))
        return f

    groups = {g: pack(g) for g in GROUPS if members_by_group.get(g) or hourly[g]}
    flow = dict(groups.get("dir") or pack("dir"))
    flow["groups"] = groups
    flow["group_names"] = GROUPS
    flow["n_directional"] = len(dir_set)
    flow["n_total"] = len(grp_of)
    flow["sizes"] = {g: len(m) for g, m in members_by_group.items()}
    flow["per_coin"] = grp_of                                    # für die Ereignisliste im Dashboard

    # Direktionale Wale: nur Konten, deren Verhaltensklasse "direktional" ist
    # (eine Seite, kein Hedge-, kein Market-Maker-Muster), je Seite Anzahl und Wert.
    # Gefunden 15.09. mit check_treiber (BTC und ETH zeigten identische Zahlen): `current` enthält
    # ALLE Coins (für die Wal-Tabelle), die Richtungs-Zusammenfassung muss aber je Coin gerechnet
    # werden -- sonst zählt ein Wal mit BTC long und ETH long doppelt, und einer mit BTC long und
    # ETH short fällt als "zwei Seiten" heraus, obwohl er in BTC klar positioniert ist.
    by_addr: dict = {}
    for r in current:
        if r["coin"] == coin:
            by_addr.setdefault(r["addr"], []).append(r)
    dirn = {"n_long": 0, "usd_long": 0.0, "n_short": 0, "usd_short": 0.0, "n_whales": len(by_addr), "n_directional": 0, "coin": coin}
    # Klasse JE COIN (behavior_per_coin), nicht kontoweit: Ein Wal mit BTC long und ETH short ist
    # kontoweit "gemischt", in BTC aber eine Seite -- dieselbe Konvention wie lb_groups(coin) bei
    # Smart Money. Hedge- und Market-Maker-Konten bleiben ausgeschlossen.
    pcoin = behavior_per_coin(con)
    for addr, rows in by_addr.items():
        grp = (pcoin.get((addr.lower(), coin)) or {}).get("group") or ("dir" if behavior_map(con).get(addr.lower(), "").startswith("direktional") else "")
        if grp not in ("dir", "mixed"):
            continue
        sides = {r["side"] for r in rows}
        if len(sides) != 1:
            continue
        side = sides.pop(); usd = sum(r["pos_value"] or 0 for r in rows)
        dirn["n_directional"] += 1
        if side == "long":
            dirn["n_long"] += 1; dirn["usd_long"] += usd
        else:
            dirn["n_short"] += 1; dirn["usd_short"] += usd

    # Netto-Exposure je Snapshot: long positiv, short negativ. 23.36: ohne Gesperrte (Masterregel, wie Tabelle und Ereignisse
    # oben) -- bis 23.35 zählten ihre Positionen mit, auch geschlossene, die der Recorder als Schnappschuss weiterschrieb.
    # Nur die Gesperrten, die in diesem Coin und Zeitraum überhaupt Schnappschüsse haben, kommen in die Liste (kurz).
    g_ex = []
    if G_:
        g_ex = sorted(G_ & {str(r[0]) for r in con.execute(
            "SELECT DISTINCT lower(addr) FROM whale_positions WHERE coin=? AND ts>=? AND event='snap'", (coin, t_from))})
    ohne_g = (" AND lower(addr) NOT IN (" + ",".join("?" * len(g_ex)) + ")") if g_ex else ""
    exposure = con.execute(f"""
        SELECT ts,
               SUM(CASE WHEN side='long'  THEN pos_value ELSE 0 END) AS long_usd,
               SUM(CASE WHEN side='short' THEN pos_value ELSE 0 END) AS short_usd,
               COUNT(*) AS n
        FROM whale_positions
        WHERE coin=? AND ts>=? AND event='snap'{ohne_g}
        GROUP BY ts ORDER BY ts""", (coin, t_from, *g_ex)).fetchall()

    price = con.execute(
        "SELECT ts, close FROM bars WHERE coin=? AND ts>=? ORDER BY ts",
        (coin, t_from)).fetchall()[::5]          # jede 5. Minute reicht fürs Bild

    return {
        "current": [dict(r) for r in current],
        "events": [dict(r) for r in events],
        "directional": dirn, "flow": flow,
        "exposure": [dict(r) for r in exposure],
        "price": [(r["ts"], r["close"]) for r in price],
    }


def load_stops(con, coin: str, price: float) -> dict:
    """
    Aktuelle Orders der Konten ab 250k für einen Coin: je Adresse die jüngste Abfrage der letzten 6 Stunden (die unterste
    Größenstufe wird nur alle 6 h gefragt; n_fresh = davon in den letzten 20 min abgefragt, oldest = ältester Stand --
    beides zeigt die Zeile unter dem Chart). Daraus Cluster je Preis-Bucket (0,25 %-Raster) für
    stop_sell (Verkaufskaskade nach unten), stop_buy (Kaufkaskade nach oben),
    tp_* (absorbieren) und limit_* (ruhende Liquidität).
    """
    out = {"orders": [], "clusters": [], "n_whales": 0, "ts": None}
    try:
        rows = con.execute("""
            SELECT t.* FROM trigger_orders t
            JOIN (SELECT addr, MAX(ts) mts FROM trigger_orders
                  WHERE ts > ? GROUP BY addr) m ON m.addr = t.addr AND m.mts = t.ts
            WHERE t.coin = ? AND t.kind != 'none'
            ORDER BY t.kind, t.trigger_px""", (int(time.time()) - 6 * 3600, coin)).fetchall()
        # Konten der untersten Stufe werden nur alle 6 h gefragt -- so weit reicht das Fenster
        n_wh, oldest = con.execute("SELECT COUNT(*), MIN(mts) FROM (SELECT addr, MAX(ts) mts FROM trigger_orders "
                                   "WHERE ts > ? GROUP BY addr)", (int(time.time()) - 6 * 3600,)).fetchone()
        n_fresh = con.execute("SELECT COUNT(DISTINCT addr) FROM trigger_orders WHERE ts > ?",
                              (int(time.time()) - 1200,)).fetchone()[0]
    except sqlite3.OperationalError:
        return out
    out["n_whales"] = n_wh
    out["n_fresh"] = n_fresh
    out["oldest"] = oldest
    out["n_with_orders"] = len({r["addr"] for r in rows
                                if (r["trigger_px"] or r["limit_px"]) and price
                                and abs((r["trigger_px"] or r["limit_px"]) / price - 1) <= 0.30})
    if not rows:
        return out
    out["ts"] = max(r["ts"] for r in rows)
    agg: dict = {}
    for r in rows:
        px = r["trigger_px"] or r["limit_px"]
        if not px:
            continue
        out["orders"].append({"addr": r["addr"][:6] + "…" + r["addr"][-4:], "kind": r["kind"],
                              "px": px, "size": r["size"], "notional": r["notional"],
                              "type": r["order_type"], "tpsl": r["is_tpsl"],
                              "dist": (px / price - 1) if price else 0})
        b = bucket_px(px)                       # M10: dasselbe Raster wie die Börsenbücher, sonst verschmilzt die Fusion nie
        k = (r["kind"], b)
        a = agg.setdefault(k, {"kind": r["kind"], "px": b, "notional": 0.0, "n": 0, "addrs": set()})
        a["notional"] += r["notional"]; a["n"] += 1; a["addrs"].add(r["addr"])
    out["clusters"] = sorted(({**a, "addrs": len(a["addrs"]),
                               "dist": (a["px"] / price - 1) if price else 0} for a in agg.values()),
                             key=lambda x: x["px"])
    return out


def load_api_budget(con) -> dict | None:
    try:
        rows = dict(con.execute("SELECT k, v FROM meta WHERE k IN "
                                "('api_weight_1m','api_weight_budget','api_weight_ts','rate_limited',"
                                "'poller_batch','poller_want','poller_due_a','poller_due_b','poller_due_c','addr_total',"
                                "'task_errors','recorder_alive',"
                                "'thermal_temp','thermal_level','thermal_weight_factor','thermal_interval_factor','thermal_since')"))
    except sqlite3.OperationalError:
        return None
    if "api_weight_1m" not in rows:
        return None
    thermal = {"temp": float(rows["thermal_temp"]) if rows.get("thermal_temp") else None,
               "level": int(rows.get("thermal_level") or 0), "weight_factor": float(rows.get("thermal_weight_factor") or 1),
               "interval_factor": float(rows.get("thermal_interval_factor") or 1), "since": int(rows.get("thermal_since") or 0)}
    poller = {k: int(rows.get(k) or 0) for k in ("poller_batch", "poller_want", "poller_due_a", "poller_due_b", "poller_due_c", "addr_total")}
    try:
        poller["task_errors"] = json.loads(rows.get("task_errors") or "{}")
    except ValueError:
        poller["task_errors"] = {}
    poller["alive"] = int(rows.get("recorder_alive") or 0)
    return {"thermal": thermal, "poller": poller, "used": int(rows["api_weight_1m"]), "budget": int(rows.get("api_weight_budget", 1200)),
            "ts": int(rows.get("api_weight_ts", 0)), "r429": int(rows.get("rate_limited", 0))}


def load_mas(con, coin: str, price: float) -> dict:
    """
    Gleitende Durchschnitte aus Tageskerzen (daily_bars, nachgeladen von
    hl_binance): 50/200 Tage und 50/200 Wochen. Die laufende Kerze wird durch
    den aktuellen Kurs ersetzt -- so, wie Charts es zeigen.
    """
    out = {"ma50d": None, "ma200d": None, "ma50w": None, "ma200w": None,
           "days": 0, "weeks": 0, "source": None, "cross": None}
    try:
        rows = con.execute("SELECT ts, close, source FROM daily_bars WHERE coin=? "
                           "ORDER BY ts", (coin,)).fetchall()
    except sqlite3.OperationalError:
        return out
    if not rows:
        return out
    today = int(time.time()) // 86_400 * 86_400
    closed = [(r["ts"], r["close"]) for r in rows if r["ts"] < today]
    out["source"] = rows[-1]["source"]
    daily = [c for _, c in closed] + ([price] if price else [])
    out["days"] = len(closed)

    # Wochen: ISO-Woche, Schluss = letzter Tag der Woche; laufende Woche = Kurs
    import datetime as _dt
    weekly, cur_key = [], None
    for ts, c in closed:
        y, w, _ = _dt.datetime.fromtimestamp(ts, _dt.timezone.utc).isocalendar()
        if (y, w) != cur_key:
            weekly.append(c); cur_key = (y, w)
        else:
            weekly[-1] = c
    now_key = _dt.datetime.now(_dt.timezone.utc).isocalendar()[:2]
    if price:
        if cur_key == now_key:
            weekly[-1] = price
        else:
            weekly.append(price)
    out["weeks"] = len(weekly)

    def sma(seq, n):
        return sum(seq[-n:]) / n if len(seq) >= n else None

    out["ma50d"], out["ma200d"] = sma(daily, 50), sma(daily, 200)
    out["ma50w"], out["ma200w"] = sma(weekly, 50), sma(weekly, 200)
    if out["ma50d"] and out["ma200d"]:
        out["cross"] = "golden" if out["ma50d"] > out["ma200d"] else "death"
    for k in ("ma50d", "ma200d", "ma50w", "ma200w"):
        out[k + "_dist"] = (price / out[k] - 1) if (out[k] and price) else None
    return out


def find_fvgs(candles: list[dict], min_pct: float = 0.0005) -> list[dict]:
    """
    Fair Value Gaps: Dreikerzen-Lücken, rein aus den Kerzen berechnet.

    Bullisch: Tief der dritten Kerze über dem Hoch der ersten.
    Bärisch:  Hoch der dritten Kerze unter dem Tief der ersten.
    Die Zone zwischen beiden ist die Lücke. Sie gilt als "gemildert", sobald
    spätere Kerzen wieder hineinlaufen: teilweise (Anteil), oder ganz, wenn
    der Kurs die ferne Kante erreicht. Nichts davon wird gespeichert.
    """
    gaps = []
    for i in range(2, len(candles)):
        a, b, c = candles[i - 2], candles[i - 1], candles[i]
        if c["l"] > a["h"]:
            kind, top, bot = "bull", c["l"], a["h"]
        elif c["h"] < a["l"]:
            kind, top, bot = "bear", a["l"], c["h"]
        else:
            continue
        mid = (top + bot) / 2
        if mid <= 0 or (top - bot) / mid < min_pct:
            continue
        gaps.append({"i": i - 1, "t": b["t"], "kind": kind, "top": top, "bot": bot,
                     "size_pct": (top - bot) / mid, "fill_i": None, "fill_pct": 0.0})

    for g in gaps:
        span = g["top"] - g["bot"]
        for j in range(g["i"] + 2, len(candles)):
            c = candles[j]
            if g["kind"] == "bull":
                if c["l"] <= g["bot"]:
                    g["fill_i"], g["fill_pct"] = j, 1.0
                    break
                if c["l"] < g["top"]:
                    g["fill_pct"] = max(g["fill_pct"], (g["top"] - c["l"]) / span)
            else:
                if c["h"] >= g["top"]:
                    g["fill_i"], g["fill_pct"] = j, 1.0
                    break
                if c["h"] > g["bot"]:
                    g["fill_pct"] = max(g["fill_pct"], (c["h"] - g["bot"]) / span)
    return gaps


ICON_SVG = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
    '<rect width="64" height="64" rx="12" fill="#0d1117"/>'
    '<rect x="10" y="36" width="8" height="18" fill="#e04b4b"/>'
    '<rect x="22" y="24" width="8" height="30" fill="#3ba55d"/>'
    '<rect x="34" y="30" width="8" height="24" fill="#e04b4b"/>'
    '<rect x="46" y="14" width="8" height="40" fill="#39ff14"/>'
    '<line x1="8" y1="20" x2="56" y2="20" stroke="#58a6ff" stroke-width="2" stroke-dasharray="4 3"/>'
    '</svg>')

_HEALTH_CACHE: dict = {"ts": 0, "check": None, "running": False}
_HEALTH_LOCK = threading.Lock()


def _run_quick_check(db: str) -> None:
    """quick_check im Hintergrund -- bei 1 GB auf einem USB-Stick dauert er Minuten."""
    try:
        con = connect(db)
        t0 = time.time()
        res = con.execute("PRAGMA quick_check").fetchone()[0]
        con.close()
        result = {"db_ok": res == "ok", "db_detail": "" if res == "ok" else str(res)[:120],
                  "check_seconds": round(time.time() - t0, 1), "checked_at": int(time.time())}
    except sqlite3.Error as e:
        result = {"db_ok": False, "db_detail": str(e)[:120], "check_seconds": 0,
                  "checked_at": int(time.time())}
    with _HEALTH_LOCK:
        _HEALTH_CACHE.update(ts=int(time.time()), check=result, running=False)


def load_health(db: str, max_age: int = 6 * 3600) -> dict:
    """
    Backup-Status (billig, bei jedem Aufruf frisch) und Zustand der Datenbank
    (quick_check, höchstens alle 6 h, im Hintergrund). Der Aufruf blockiert nie:
    läuft die Prüfung gerade, kommt der letzte bekannte Stand oder "läuft".
    """
    now = int(time.time())
    with _HEALTH_LOCK:
        stale = _HEALTH_CACHE["check"] is None or now - _HEALTH_CACHE["ts"] >= max_age
        if stale and not _HEALTH_CACHE["running"]:
            _HEALTH_CACHE["running"] = True
            threading.Thread(target=_run_quick_check, args=(db,), daemon=True).start()
        check = _HEALTH_CACHE["check"]
        running = _HEALTH_CACHE["running"]

    backup = None
    bdir = os.path.join(os.path.dirname(os.path.abspath(db)), "dbbackup")
    try:
        c0 = connect(db)
        r0 = c0.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
        c0.close()
        if r0 and r0[0]:
            bdir = r0[0]
    except sqlite3.Error:
        pass
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            backup = json.load(f)
    except (OSError, ValueError):
        pass

    bfree = btotal = bsame = None
    try:
        u = shutil.disk_usage(bdir if os.path.isdir(bdir) else os.path.dirname(os.path.abspath(db)))
        bfree, btotal = u.free, u.total
        bsame = os.stat(bdir).st_dev == os.stat(os.path.dirname(os.path.abspath(db))).st_dev if os.path.isdir(bdir) else None
    except OSError:
        pass
    data = {"backup": backup, "checking": running, "backup_dir": bdir, "backup_free": bfree, "backup_total": btotal,
            "backup_same_device": bsame,
            "db_size": os.path.getsize(db) if os.path.exists(db) else 0}
    if check:
        data.update(check)
    else:
        data.update(db_ok=None, db_detail="Prüfung läuft", check_seconds=0, checked_at=None)
    return data


_KLINE_CACHE: dict = {}
_KLINE_LOCK = threading.Lock()


def aggregate(rows, step: int) -> list[dict]:
    """Zeilen (ts, o, h, l, c, v) in Kerzen der Länge step (Sekunden) falten."""
    candles, cur = [], None
    for ts, o, h, l, c, v in rows:
        b = ts // step * step
        if cur is None or b != cur["t"]:
            if cur:
                candles.append(cur)
            cur = {"t": b, "o": o, "h": h, "l": l, "c": c, "v": v or 0}
        else:
            cur["h"] = max(cur["h"], h); cur["l"] = min(cur["l"], l); cur["c"] = c; cur["v"] += v or 0
    if cur:
        candles.append(cur)
    return candles


def week_start(ts: int) -> int:
    """Montag 00:00 UTC der Woche, in der ts liegt."""
    return (ts - 4 * 86_400) // 604_800 * 604_800 + 4 * 86_400   # 1970-01-01 war ein Donnerstag


def fetch_binance_klines(coin: str, interval: str, limit: int) -> list[dict]:
    """Binance-Futures-Kerzen als Ergänzung für lange Zeiträume; 5 min im Speicher gehalten."""
    import urllib.request
    key = (coin, interval, limit)
    with _KLINE_LOCK:
        hit = _KLINE_CACHE.get(key)
        if hit and time.time() - hit[0] < 300:
            return hit[1]
    out = []
    for base, path in (("https://fapi.binance.com", "/fapi/v1/klines"), ("https://api.binance.com", "/api/v3/klines")):
        try:
            url = f"{base}{path}?symbol={coin}USDT&interval={interval}&limit={limit}"
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}),
                                        timeout=15) as r:
                data = json.loads(r.read().decode())
            if isinstance(data, list) and data:
                out = [{"t": int(k[0]) // 1000, "o": float(k[1]), "h": float(k[2]), "l": float(k[3]),
                        "c": float(k[4]), "v": float(k[5])} for k in data]
                break
        except Exception:
            continue
    with _KLINE_LOCK:
        _KLINE_CACHE[key] = (time.time(), out)
    return out


def load_long_candles(con, coin: str, agg: int, minutes: int) -> tuple[list[dict], str]:
    """
    Kerzen ab 4 h Raster: aus den vorhandenen Tabellen der Datenbank, ergänzt
    um Binance, wo die eigene Aufzeichnung nicht zurückreicht.
      4 h   -> klines30 (30-min-Kerzen von Binance, falls hl_timestats geladen hat),
               sonst Binance 4h-Kerzen; die jüngsten Stunden aus den eigenen 1-min-Bars
      1 Tag -> daily_bars (5 Jahre, von hl_binance), sonst Binance 1d
      1 Wo  -> daily_bars zu ISO-Wochen gefaltet, sonst Binance 1w
    Liefert (Kerzen, Quellenangabe).
    """
    now = int(time.time()); t_from = now - minutes * 60; step = agg * 60
    src = []
    if agg == 240:
        try:
            rows = con.execute("SELECT ts, open, high, low, close, volume FROM klines30 WHERE coin=? AND ts>=? ORDER BY ts",
                               (coin, t_from)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        cands = aggregate([tuple(r) for r in rows], step) if rows else []
        if cands and cands[0]["t"] <= t_from + 2 * 86_400:
            candles, src = cands, ["Binance-30-min-Kerzen (klines30)"]
        else:
            candles, src = fetch_binance_klines(coin, "4h", 6 * 30 + 2), ["Binance 4h"]
        # die eigenen Minutenbars ersetzen das jüngste Stück, wo sie vorliegen
        own = con.execute("SELECT ts, open, high, low, close, volume FROM bars WHERE coin=? AND ts>=? ORDER BY ts",
                          (coin, max(t_from, now - 8 * 86_400))).fetchall()
        own_c = aggregate([tuple(r) for r in own], step)
        if own_c:
            first_own = own_c[0]["t"]
            candles = [c for c in candles if c["t"] < first_own] + own_c
            src.append("jüngste Kerzen aus eigenen Hyperliquid-Bars")
    else:
        try:
            rows = con.execute("SELECT ts, open, high, low, close, volume FROM daily_bars WHERE coin=? AND ts>=? ORDER BY ts",
                               (coin, t_from - 7 * 86_400)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        if rows and rows[0][0] <= t_from + 30 * 86_400:
            daily = [{"t": r[0], "o": r[1], "h": r[2], "l": r[3], "c": r[4], "v": r[5] or 0} for r in rows]
            src = ["Tageskerzen (daily_bars, Binance via hl_binance)"]
        else:
            daily = fetch_binance_klines(coin, "1d", min(1000, minutes // 1440 + 7))
            src = ["Binance 1d"]
        if agg >= 10080:
            weeks, cur = [], None
            for c in daily:
                w = week_start(c["t"])
                if cur is None or cur["t"] != w:
                    if cur:
                        weeks.append(cur)
                    cur = dict(c, t=w)
                else:
                    cur["h"] = max(cur["h"], c["h"]); cur["l"] = min(cur["l"], c["l"]); cur["c"] = c["c"]; cur["v"] += c["v"]
            if cur:
                weeks.append(cur)
            candles = weeks
        else:
            candles = daily
        candles = [c for c in candles if c["t"] >= t_from - (604_800 if agg >= 10080 else 0)]
        # laufende Kerze: Schluss aus dem eigenen aktuellen Kurs
        last = con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if candles and last and last[0]:
            candles[-1]["c"] = last[0]
            candles[-1]["h"] = max(candles[-1]["h"], last[0]); candles[-1]["l"] = min(candles[-1]["l"], last[0])
    return candles, " + ".join(src)


# ---------------------------------------------------------------------------
# Binance als zweite Quelle. Grundsatz: Datenbank zuerst (bnc_liquidations,
# bnc_metrics, bnc_bars, daily_bars), Live-Abfragen nur für das, was nicht
# gespeichert wird (Kerzen kurzer Raster, Orderbuch, Funding), mit Speicher-Cache
# und stiller Rückfallebene, damit das Dashboard ohne Netz nicht bricht.
# ---------------------------------------------------------------------------

_BNC_CACHE: dict = {}
_BNC_LOCK = threading.Lock()
BNC_INTERVALS = {1: "1m", 5: "5m", 15: "15m", 60: "1h", 240: "4h", 1440: "1d", 10080: "1w"}


_EXT_ERR: dict = {}          # Quelle -> letzte Fehlermeldung im Klartext


def _cached(key, ttl, fn):
    with _BNC_LOCK:
        hit = _BNC_CACHE.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    try:
        val = fn()
        _EXT_ERR.pop(key[0] if isinstance(key, tuple) else key, None)
    except Exception as e:
        # Den Grund festhalten. Ihn zu verschlucken war die eigentliche Schwäche: Im
        # Dashboard stand nur "Fehler", und ob die Gegenstelle langsam war, ein Coin dort
        # gar nicht gehandelt wird oder die Schnittstelle sich geändert hat, ließ sich
        # nicht unterscheiden -- man konnte nur raten.
        val = None
        _EXT_ERR[key[0] if isinstance(key, tuple) else key] = f"{type(e).__name__}: {e}"[:160]
    with _BNC_LOCK:
        _BNC_CACHE[key] = (time.time(), val)
        _kappen(_BNC_CACHE, 128)
    return val


def _bnc_get(path: str, params: dict, timeout: int = 12):
    import urllib.request, urllib.parse
    url = f"https://fapi.binance.com{path}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}),
                                timeout=timeout) as r:
        return json.loads(r.read().decode())


def bucket_px(px: float) -> float:
    step = math.log(1.0025)
    return round(math.exp(round(math.log(px) / step) * step), 6)


def bnc_candles(con, coin: str, agg: int, minutes: int) -> tuple[list[dict], str]:
    """Binance-Kerzen im gewünschten Raster: live (30 s Cache), sonst aus bnc_bars/daily_bars."""
    iv = BNC_INTERVALS.get(agg, "5m")
    limit = min(1500, max(10, minutes // max(agg, 1) + 2))
    live = _cached(("kl", coin, iv, limit), 30, lambda: [
        {"t": int(k[0]) // 1000, "o": float(k[1]), "h": float(k[2]), "l": float(k[3]), "c": float(k[4]), "v": float(k[5])}
        for k in _bnc_get("/fapi/v1/klines", {"symbol": f"{coin}USDT", "interval": iv, "limit": limit})])
    if live:
        return live, f"Binance {iv}"
    t_from = int(time.time()) - minutes * 60
    table = "daily_bars" if agg >= 1440 else "bnc_bars"
    try:
        rows = con.execute(f"SELECT ts, open, high, low, close, volume FROM {table} WHERE coin=? AND ts>=? ORDER BY ts",
                           (coin, t_from)).fetchall()
    except sqlite3.OperationalError:
        rows = []
    return aggregate([tuple(r) for r in rows], agg * 60), f"{table} (gespeichert, Live-Abruf nicht möglich)"


def bnc_liqs(con, coin: str, since: int) -> list[tuple]:
    """Eingetretene Liquidationen (ts, px, notional, side_liq): side_liq long = Long liquidiert (SELL-Fill)."""
    try:
        rows = con.execute("SELECT ts, price, notional, side FROM bnc_liquidations WHERE coin=? AND ts>=? ORDER BY ts",
                           (coin, since)).fetchall()
    except sqlite3.OperationalError:
        return []
    # Die Seite ist beim Schreiben bereits normalisiert ("long" = Long-Position liquidiert,
    # also SELL-Fill). Sie hier erneut aus dem ersten Buchstaben abzuleiten, drehte sie um:
    # "LONG".startswith("S") ist falsch -> aus long wurde short und umgekehrt. Rohwerte aus
    # der Zeit davor ("SELL"/"BUY") werden weiterhin richtig übersetzt.
    def seite(v) -> str:
        t = str(v).strip().lower()
        if t in ("long", "short"):
            return t
        return "long" if t.startswith("s") else "short"      # SELL-Fill = Long liquidiert
    return [(r[0], r[1], r[2], seite(r[3])) for r in rows]


def bnc_book(coin: str, price: float) -> list[dict]:
    """Orderbuch-Tiefe als Cluster im 0,25-%-Raster (kind limit_buy/limit_sell), ±30 % um den Kurs."""
    def fetch():
        d = _bnc_get("/fapi/v1/depth", {"symbol": f"{coin}USDT", "limit": 1000})
        out = {}
        for side, kind in (("bids", "limit_buy"), ("asks", "limit_sell")):
            for p, q in d.get(side, []):
                p, q = float(p), float(q)
                if not price or abs(p / price - 1) > 0.30:
                    continue
                b = bucket_px(p)
                c = out.setdefault((kind, b), {"kind": kind, "px": b, "notional": 0.0, "n": 0, "addrs": 0, "src": "bnc"})
                c["notional"] += p * q; c["n"] += 1
        return list(out.values())
    return _cached(("book", coin, round(price / 50) if price else 0), 15, fetch) or []


def bnc_funding(coin: str):
    def fetch():
        d = _bnc_get("/fapi/v1/premiumIndex", {"symbol": f"{coin}USDT"})
        return float(d.get("lastFundingRate") or 0) / 8       # Binance: je 8 h -> je Stunde wie bei Hyperliquid
    return _cached(("funding", coin), 60, fetch)


def bnc_metrics_series(con, coin: str, hours: int) -> dict:
    """Kennzahlen als Zeitreihen: gespeichert (bnc_metrics), Verhältnisse zusätzlich live nachgeladen (5 min Cache)."""
    since = int(time.time()) - hours * 3600
    out: dict = {}
    try:
        for m, ts, v in con.execute("SELECT metric, ts, value FROM bnc_metrics WHERE coin=? AND ts>=? ORDER BY ts",
                                    (coin, since)):
            out.setdefault(m, []).append([ts, v])
    except sqlite3.OperationalError:
        pass
    per = "5m" if hours <= 24 else "1h"
    limit = min(500, hours * (12 if per == "5m" else 1) + 2)
    live = _cached(("ratios", coin, per, limit), 300, lambda: {
        m: [[int(r["timestamp"]) // 1000, float(r[field])] for r in _bnc_get(path, {"symbol": f"{coin}USDT", "period": per, "limit": limit})]
        for path, m, field in (("/futures/data/globalLongShortAccountRatio", "global_ls_account", "longShortRatio"),
                               ("/futures/data/topLongShortPositionRatio", "top_ls_position", "longShortRatio"),
                               ("/futures/data/takerlongshortRatio", "taker_ls", "buySellRatio"),
                               ("/futures/data/openInterestHist", "oi_notional", "sumOpenInterestValue"))})
    if live:
        for m, series in live.items():
            merged = {t: v for t, v in out.get(m, [])}
            merged.update({t: v for t, v in series if t >= since})
            out[m] = [[t, merged[t]] for t in sorted(merged)]
    latest = {m: (ser[-1][1] if ser else None) for m, ser in out.items()}
    return {"series": out, "latest": latest}


def attach_binance(con, payload: dict, coin: str, agg: int, minutes: int, src: str) -> dict:
    """
    src == 'bnc':    Kerzen, Marken, Orderbuch, Funding, Trend, RSI, FVGs aus Binance;
                     Marken = eingetretene Liquidationen im Chartzeitraum.
    src == 'fusion': Hyperliquid-Chart bleibt; dazu Binance-Orderbuch je Preisstufe
                     zu den Orders addiert, eingetretene Liquidationen beider Börsen als
                     Marker, Volumen/Funding beider Börsen, Kennzahlen.
    """
    now = int(time.time())
    cand, csrc = bnc_candles(con, coin, agg, minutes)
    price_b = cand[-1]["c"] if cand else (payload.get("price") or 0)
    liqs = bnc_liqs(con, coin, now - minutes * 60)
    book = bnc_book(coin, price_b or payload.get("price") or 0)
    fund = bnc_funding(coin)
    met = bnc_metrics_series(con, coin, 24)
    vol_b = sum(c["v"] * c["c"] for c in cand if c["t"] >= now - 3600) if cand else 0
    liq_marks = [(ts, px, usd, side, "bnc") for ts, px, usd, side in liqs]
    # eigene (Hyperliquid) Liquidationen im selben Fenster als Marker
    try:
        for r in con.execute("SELECT ts, px, px*sz, side FROM liquidations WHERE coin=? AND ts>=? ORDER BY ts",
                             (coin, now - minutes * 60)):
            liq_marks.append((r[0], r[1], r[2], "long" if str(r[3]).upper().startswith("A") else "short", "hl"))
    except sqlite3.OperationalError:
        pass
    payload["liq_marks"] = liq_marks
    _cdc_t0 = time.time()
    _cdc_bekannt_leer = ungelistet("Crypto.com", coin)
    cdc = None if _cdc_bekannt_leer else cdc_snapshot(coin, price_b or payload.get("price") or 0)
    payload["cdc"] = cdc
    if not _cdc_bekannt_leer:
        note_ext("Crypto.com", _cdc_t0, cdc is not None, coin)
    payload["bnc"] = {"metrics": met["latest"], "vol_1h": vol_b, "funding": fund, "book_n": len(book),
                      "liqs_1h": {"long": sum(u for t, p, u, sd in liqs if sd == "long" and t >= now - 3600),
                                  "short": sum(u for t, p, u, sd in liqs if sd == "short" and t >= now - 3600)}}
    if src == "bnc":
        if cand:
            payload["candles"] = cand; payload["source"] = csrc; payload["price"] = price_b
            payload["fvgs"] = find_fvgs(cand, 0.0005)
            closes = [c["c"] for c in cand]
            payload["rsi14"] = rsi14(closes) if len(closes) >= 16 else None
            m1, _ = bnc_candles(con, coin, 1, 120)
            payload["trend_60m"] = (m1[-1]["c"] / m1[-61]["c"] - 1) if len(m1) >= 61 else None
            payload["vol_1h"] = vol_b
        # Marken: eingetretene Liquidationen je Preisstufe im Chartzeitraum
        lv: dict = {}
        for ts, px, usd, side in liqs:
            c = lv.setdefault((bucket_px(px), side), {"px": bucket_px(px), "side": side, "notional": 0.0, "n_pos": 0})
            c["notional"] += usd; c["n_pos"] += 1
        levels = sorted(lv.values(), key=lambda x: -x["notional"])[:14]
        for l in levels:
            l["dist"] = (l["px"] / price_b - 1) if price_b else 0
        payload["levels"] = levels; payload["levels_realized"] = True
        payload["stops"] = {"clusters": book, "orders": [], "n_whales": 0, "n_fresh": 0, "n_with_orders": 0,
                            "oldest": None, "ts": now, "book": True}
        payload["funding"] = fund
        if book:
            near = lambda kind: sum(c["notional"] for c in book if c["kind"] == kind and abs(c["px"] / price_b - 1) <= 0.005)
            b, a = near("limit_buy"), near("limit_sell")
            payload["book"] = {"imb_50": (b - a) / (b + a) if (b + a) else 0, "bid_50": b, "ask_50": a, "src": "bnc"}
        payload["tick_events"] = []
    else:   # fusion
        stops = payload.get("stops") or {"clusters": []}
        merged: dict = {}
        for c in stops.get("clusters", []):
            merged[(c["kind"], c["px"])] = dict(c)
        for c in book:
            key = (c["kind"], c["px"])
            if key in merged:
                merged[key]["notional"] += c["notional"]; merged[key]["n"] += c["n"]; merged[key]["src"] = "both"
            else:
                merged[key] = dict(c)
        p0 = payload.get("price") or price_b
        for c in merged.values():
            c["dist"] = (c["px"] / p0 - 1) if p0 else 0
        # Crypto.com-Orderbuch ebenfalls je Preisstufe addieren (Data Mix Fusion: alle Quellen)
        for c in (cdc or {}).get("book", []):
            key = (c["kind"], c["px"])
            if key in merged:
                merged[key]["notional"] += c["notional"]; merged[key]["n"] += c["n"]; merged[key]["src"] = "mix"
            else:
                merged[key] = dict(c)
        for c in merged.values():
            c["dist"] = (c["px"] / p0 - 1) if p0 else 0
        stops["clusters"] = sorted(merged.values(), key=lambda c: c["px"]); stops["book_n"] = len(book); stops["cdc_book_n"] = len((cdc or {}).get("book", []))
        # Reichweite und Betrag der Fremdbücher sichtbar machen: /fapi/v1/depth liefert höchstens
        # 1.000 Stufen je Seite -- bei BTC rund ein Prozent um den Kurs. Tiefere Wände gibt es
        # über diese Schnittstelle nicht; "4 Stufen" ist deshalb kein Fehler, sondern die Grenze.
        def buch_kennzahlen(cl):
            if not cl or not p0:
                return None
            return {"span_pct": max(abs(c["px"] / p0 - 1) for c in cl) * 100,
                    "bid_usd": sum(c["notional"] for c in cl if c["kind"] == "limit_buy"),
                    "ask_usd": sum(c["notional"] for c in cl if c["kind"] == "limit_sell")}
        stops["book_bnc"] = buch_kennzahlen(book); stops["book_cdc"] = buch_kennzahlen((cdc or {}).get("book", []))
        payload["stops"] = stops
        vol_c = (cdc or {}).get("vol_1h") or 0
        hl_vol = payload.get("vol_1h") or 0
        payload["vol_1h"] = hl_vol + vol_b + vol_c
        payload["vol_split"] = {"hl": hl_vol, "bnc": vol_b, "cdc": vol_c}
        if fund is not None and payload.get("funding") is not None:
            payload["funding_bnc"] = fund
    return payload


def rsi14(closes: list) -> float | None:
    if len(closes) < 16:
        return None
    gains, losses = [], []
    for a, b in zip(closes[-15:-1], closes[-14:]):
        gains.append(max(b - a, 0)); losses.append(max(a - b, 0))
    ag, al = sum(gains) / 14, sum(losses) / 14
    return 100.0 if al == 0 else round(100 - 100 / (1 + ag / al), 1)


# ---------------------------------------------------------------------------
# Zugangsschlüssel (accesstokens.json, normale Datei) und Crypto.com als dritte Börse.
# Crypto.com-Marktdaten sind öffentlich -- kein Schlüssel nötig; die Datei ist für
# Quellen gedacht, die später dazukommen (CoinGlass, CryptoQuant, Glassnode, Nansen, Arkham).
# ---------------------------------------------------------------------------

TOKENS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "accesstokens.json")
_TOK: dict = {"mtime": 0, "data": {}}


def tokens() -> dict:
    """Schlüssel aus accesstokens.json; leere Werte gelten als nicht vorhanden."""
    try:
        m = os.path.getmtime(TOKENS_FILE)
    except OSError:
        return {}
    if m != _TOK["mtime"]:
        try:
            with open(TOKENS_FILE) as f:
                raw = json.load(f)
            _TOK["data"] = {k: {kk: vv for kk, vv in v.items() if vv and not kk.startswith("_")}
                            for k, v in raw.items() if isinstance(v, dict)}
        except (OSError, ValueError):
            _TOK["data"] = {}
        _TOK["mtime"] = m
    return _TOK["data"]


CDC_BASE = "https://api.crypto.com/exchange/v1/public/"
CDC_TF = {1: "M1", 5: "M5", 15: "M15", 60: "H1", 240: "H4", 1440: "D1", 10080: "7D"}


def cdc_get(method: str, params: dict):
    """Öffentliche Crypto.com-Exchange-API; HL_TEST_STUBS=1 liefert feste Antworten für Tests."""
    if os.environ.get("HL_TEST_STUBS"):
        return _cdc_stub(method, params)
    import urllib.request, urllib.parse, urllib.error
    url = CDC_BASE + method + "?" + urllib.parse.urlencode(params)
    # Kurze Wartezeit mit Absicht: Der Schnappschuss macht SECHS Anfragen nacheinander.
    # Bei zwölf Sekunden je Anfrage konnte ein einziger zäher Endpunkt den ganzen
    # Chart-Abruf über eine Minute blockieren -- und genau das sah im Dashboard wie ein
    # Fehlschlag aus. Sechs Sekunden reichen für eine gesunde Antwort um ein Vielfaches.
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}), timeout=6) as r:
            d = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        # Crypto.com antwortet auf ein unbekanntes Instrument mit HTTP 400 und legt den
        # Grund in den Rumpf. Ohne ihn zu lesen, sieht ein nicht gehandelter Coin wie eine
        # Störung aus -- genau daran ist die erste Fassung dieser Erkennung gescheitert.
        rumpf = ""
        try:
            rumpf = e.read().decode()[:200]
        except Exception:
            pass
        if e.code in (400, 404):
            raise RuntimeError(f"Instrument unbekannt (HTTP {e.code}): {params.get('instrument_name', '?')}"
                               + (f" · {rumpf}" if rumpf else "")) from None
        raise RuntimeError(f"HTTP {e.code}: {rumpf or e.reason}") from None
    if d.get("code") not in (0, "0", None):
        raise RuntimeError(f"crypto.com {method}: {d.get('code')} {d.get('message', '')}")
    return d.get("result", {})


def _cdc_stub(method: str, params: dict):
    now_ms = int(time.time() * 1000); px = 77100.0
    if method == "get-tickers":
        return {"data": [{"i": params.get("instrument_name"), "a": str(px), "v": "5580.6", "vv": "434638617.0", "oi": "6273.37",
                          "h": "78920", "l": "76622", "c": "-0.0122", "b": str(px - 0.1), "k": str(px + 0.1), "t": now_ms}]}
    if method == "get-book":
        return {"data": [{"bids": [[str(px - 5 * (i + 1)), str(0.3 + i * 0.05), "1"] for i in range(50)],
                          "asks": [[str(px + 5 * (i + 1)), str(0.25 + i * 0.05), "1"] for i in range(50)], "t": now_ms}]}
    if method == "get-trades":
        return {"data": [{"p": str(px), "q": "0.05" if i % 3 else "0.20", "s": "BUY" if i % 4 else "SELL", "t": now_ms - i * 1000} for i in range(150)]}
    if method == "get-candlestick":
        return {"data": [{"o": px, "h": px + 100, "l": px - 100, "c": px, "v": "100", "t": now_ms - k * 3600_000} for k in range(50)]}
    if method == "get-valuations":
        vt = params.get("valuation_type")
        return {"data": [{"v": str(px * (1.0001 if vt == "mark_price" else 1.0)), "t": now_ms}]}
    return {}


def cdc_snapshot(coin: str, price: float) -> dict | None:
    """
    Crypto.com-Kennzahlen für einen Coin, 30 s im Speicher: Open Interest (Coins und USD),
    24-h-Volumen, Stundenvolumen aus Kerzen, Taker-Flow aus den letzten 150 Trades,
    Prämie Mark gegen Index, Orderbuch als Cluster (kind limit_buy/limit_sell, src cdc).
    None, wenn der Coin dort nicht gehandelt wird oder die API nicht erreichbar ist.
    """
    inst = f"{coin}USD-PERP"
    def fetch():
        t = cdc_get("get-tickers", {"instrument_name": inst}).get("data") or []
        if not t:
            return None
        t = t[0]
        last = float(t.get("a") or price or 0)
        oi = float(t.get("oi") or 0)
        out = {"last": last, "oi": oi, "oi_usd": oi * last, "vol_24h_usd": float(t.get("vv") or 0),
               "high": float(t.get("h") or 0), "low": float(t.get("l") or 0), "ts": int(time.time())}
        try:
            c = cdc_get("get-candlestick", {"instrument_name": inst, "timeframe": "H1"}).get("data") or []
            out["vol_1h"] = sum(float(k.get("v") or 0) for k in c[:1]) * last if c else 0
            out["vol_24h_from_candles"] = sum(float(k.get("v") or 0) for k in c[:24]) * last if c else 0
        except Exception:
            out["vol_1h"] = 0
        try:
            tr = cdc_get("get-trades", {"instrument_name": inst, "count": 150}).get("data") or []
            buy = sum(float(x.get("q") or 0) for x in tr if str(x.get("s", "")).upper() == "BUY")
            sell = sum(float(x.get("q") or 0) for x in tr if str(x.get("s", "")).upper() == "SELL")
            out["taker_ls"] = (buy / sell) if sell > 0 else (None if buy == 0 else 9.99)
            out["taker_n"] = len(tr); out["taker_span_s"] = (int(tr[0].get("t", 0)) - int(tr[-1].get("t", 0))) / 1000 if len(tr) > 1 else 0
        except Exception:
            out["taker_ls"] = None
        try:
            mk = float((cdc_get("get-valuations", {"instrument_name": inst, "valuation_type": "mark_price", "count": 1}).get("data") or [{}])[0].get("v") or 0)
            ix = float((cdc_get("get-valuations", {"instrument_name": f"{coin}USD-INDEX", "valuation_type": "index_price", "count": 1}).get("data") or [{}])[0].get("v") or 0)
            out["premium"] = (mk / ix - 1) if mk and ix else None
        except Exception:
            out["premium"] = None
        try:
            bk = (cdc_get("get-book", {"instrument_name": inst, "depth": 50}).get("data") or [{}])[0]
            clusters: dict = {}
            for side, kind in (("bids", "limit_buy"), ("asks", "limit_sell")):
                for lvl in bk.get(side, []):
                    p, q = float(lvl[0]), float(lvl[1])
                    if not last or abs(p / last - 1) > 0.30:
                        continue
                    b = bucket_px(p)
                    c = clusters.setdefault((kind, b), {"kind": kind, "px": b, "notional": 0.0, "n": 0, "addrs": 0, "src": "cdc"})
                    c["notional"] += p * q; c["n"] += 1
            out["book"] = list(clusters.values())
        except Exception:
            out["book"] = []
        return out
    return _cached(("cdc", coin), 30, fetch)


# ---------------------------------------------------------------------------
# Weitere Quellen: Bybit, OKX (öffentliche Futures-Endpunkte), ETF-Flows (Farside,
# CoinGlass mit Schlüssel), Smart Money aus dem Hyperliquid-Leaderboard.
# Jede Quelle darf einzeln ausfallen; HL_TEST_STUBS=1 liefert feste Antworten.
# ---------------------------------------------------------------------------

def fetch_json(url: str, timeout: int = 12, data: bytes | None = None, text: bool = False):
    if os.environ.get("HL_TEST_STUBS"):
        return _src_stub(url, data, text)
    import urllib.request
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0",
                                                          **({"Content-Type": "application/json"} if data else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read().decode(errors="replace")
    return raw if text else json.loads(raw)


def _src_stub(url: str, data, text):
    """Feste Antworten für Tests ohne Netz -- Feldnamen wie in den echten APIs."""
    now_ms = int(time.time() * 1000); px = 77100.0
    if "api.bybit.com" in url:
        if "/tickers" in url:
            return {"result": {"list": [{"lastPrice": str(px), "openInterest": "51000", "openInterestValue": str(51000 * px), "fundingRate": "0.0001", "turnover24h": "9.8e9", "volume24h": "127000"}]}}
        if "account-ratio" in url:
            return {"result": {"list": [{"buyRatio": "0.58", "sellRatio": "0.42", "timestamp": str(now_ms)}]}}
        if "recent-trade" in url:
            return {"result": {"list": [{"price": str(px), "size": "0.1" if i % 3 else "0.4", "side": "Buy" if i % 5 else "Sell", "time": str(now_ms - i * 500)} for i in range(500)]}}
    if "okx.com" in url:
        if "/public/open-interest" in url:
            return {"data": [{"instId": "BTC-USDT-SWAP", "oi": "2900000", "oiCcy": "29000", "ts": str(now_ms)}]}
        if "/market/ticker" in url:
            return {"data": [{"last": str(px), "vol24h": "2500000", "volCcy24h": "25000", "ts": str(now_ms)}]}
        if "/public/funding-rate" in url:
            return {"data": [{"fundingRate": "0.00012", "nextFundingRate": "0.0001"}]}
        if "long-short-account-ratio" in url:
            return {"data": [[str(now_ms), "1.9"]]}
        if "taker-volume" in url:
            return {"data": [[str(now_ms), "1200", "1500"]]}
        if "/public/instruments" in url:
            return {"data": [{"instId": "BTC-USDT-SWAP", "ctVal": "0.01"}]}
        if "liquidation-orders" in url:
            return {"data": [{"details": [{"side": "sell", "sz": "50", "bkPx": str(px - 500), "ts": str(now_ms - 60000)}, {"side": "buy", "sz": "20", "bkPx": str(px + 400), "ts": str(now_ms - 120000)}]}]}
    if "farside.co.uk" in url:
        rows = "".join(f"<tr><td>{d} Sep 2026</td><td>120.5</td><td>(10.2)</td><td>-</td><td>{tot}</td></tr>"
                       for d, tot in ((8, "301.4"), (9, "(45.0)"), (10, "212.7")))
        return f"<html><table><tr><th>Date</th><th>IBIT</th><th>FBTC</th><th>GBTC</th><th>Total</th></tr>{rows}</table></html>"
    if "stats-data.hyperliquid.xyz" in url:
        rows = [{"ethAddress": f"0x{i:040x}", "accountValue": str(2e6 + i * 1e5), "displayName": ("Bobby" if i == 3 else None),
                 "windowPerformances": [["day", {"pnl": "1000", "roi": "0.01", "vlm": "1e6"}], ["week", {"pnl": "5000", "roi": "0.02", "vlm": "5e6"}],
                                        ["month", {"pnl": str(3e6 - i * 4e4), "roi": "0.3", "vlm": "5e7"}], ["allTime", {"pnl": "9e6", "roi": "1", "vlm": "1e9"}]]} for i in range(120)]
        return {"leaderboardRows": rows}
    if "api.hyperliquid.xyz/info" in url and data:
        req = json.loads(data.decode()); i = int(req.get("user", "0x0")[2:], 16)
        side = 1 if i % 3 else -1
        return {"assetPositions": [{"type": "oneWay", "position": {"coin": "BTC", "szi": str(side * (10 + i % 7)), "positionValue": str((10 + i % 7) * px),
                                                                     "leverage": {"type": "cross", "value": 10}, "liquidationPx": str(px * (0.9 if side > 0 else 1.1)), "entryPx": str(px)}}],
                "marginSummary": {"accountValue": "2e6"}}
    return {} if not text else ""


def _f(x, default=0.0) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


_EXT_CALLS: dict = {}          # Quelle -> {ts, dauer, ok} der letzten Live-Abfrage
_EXT_LOCK = threading.Lock()
_EXT_FEHLT: dict = {}          # (Quelle, Coin) -> Zeitpunkt der Feststellung "nicht gelistet"
FEHLT_ERNEUT_NACH = 6 * 3600   # so lange nicht erneut fragen; Börsen listen gelegentlich nach


def ungelistet(quelle: str, coin: str) -> bool:
    """Wurde für diesen Coin bei dieser Quelle schon festgestellt, dass es ihn dort nicht gibt?"""
    t = _EXT_FEHLT.get((quelle, coin))
    return bool(t and time.time() - t < FEHLT_ERNEUT_NACH)


def merke_ungelistet(quelle: str, coin: str) -> None:
    """
    Ein Coin, den die Börse nicht führt, ist kein Fehler -- und jede weitere Anfrage dazu
    ist verschwendet. XMR und ZEC etwa werden bei Crypto.com nicht als Perpetual gehandelt;
    ohne dieses Gedächtnis stellte das Dashboard bei jedem Chart-Abruf sechs Anfragen, die
    alle scheitern mussten, und zählte die Quelle als gestört.
    """
    _EXT_FEHLT[(quelle, coin)] = time.time()


def note_ext(quelle: str, t0: float, ok: bool, coin: str = "") -> None:
    """
    Live-Abrufe des Dashboards festhalten. Bybit, OKX und Crypto.com werden nicht von
    einem Dienst aufgezeichnet, sondern bei jedem Chart-Abruf direkt geholt -- ohne
    diesen Vermerk tauchen sie im Netzwerkstatus gar nicht auf, obwohl sie Netzverkehr
    erzeugen und ausfallen können.
    """
    schluessel = {"Crypto.com": "cdc", "Bybit": "bybit", "OKX": "okx"}.get(quelle, quelle)
    with _EXT_LOCK:
        e = _EXT_CALLS.setdefault(quelle, {"n": 0, "fehler": 0})
        e.update(ts=int(time.time()), dauer=round(time.time() - t0, 2), ok=ok)
        e["n"] += 1
        if not ok:
            grund = _EXT_ERR.get(schluessel) or ""
            # "ticker not found" und leere Antworten heißen: Diesen Coin gibt es dort nicht.
            # Das als Störung zu zählen, hat die Quelle grundlos als fehlerhaft gezeigt.
            # Alle Formen, in denen eine Börse "diesen Coin gibt es hier nicht" sagt.
            # Der Wortlaut unterscheidet sich je Anbieter und je Kanal -- Crypto.com
            # meldet über REST HTTP 400, über andere Wege "ticker not found".
            g = grund.lower()
            fehlt = (not grund) or any(x in g for x in (
                "instrument unbekannt", "not found", "nicht gehandelt",
                "http 400", "http 404", "http error 400", "http error 404",
                "invalid instrument", "invalid_instrument", "unknown symbol",
                "unknown instrument", "does not exist", "40004"))
            if fehlt and coin:
                merke_ungelistet(quelle, coin)
                e.setdefault("ohne", set()).add(coin)
                e["ok"] = True                      # kein Fehlschlag der Quelle
            else:
                e["fehler"] += 1
                e["grund"] = grund or "leere Antwort"
                e["grund_ts"] = int(time.time())
                e["grund_coin"] = coin


def bybit_snapshot(coin: str) -> dict | None:
    """Bybit linear Perpetual: OI, Funding, 24-h-Umsatz, Long/Short-Konten, Taker aus 500 Trades."""
    sym = f"{coin}USDT"; base = "https://api.bybit.com/v5/market"
    def fetch():
        t = (fetch_json(f"{base}/tickers?category=linear&symbol={sym}").get("result") or {}).get("list") or []
        if not t:
            return None
        t = t[0]; last = _f(t.get("lastPrice"))
        out = {"last": last, "oi": _f(t.get("openInterest")), "oi_usd": _f(t.get("openInterestValue")) or _f(t.get("openInterest")) * last,
               "funding": _f(t.get("fundingRate")) / 8, "vol_24h_usd": _f(t.get("turnover24h")), "ts": int(time.time())}
        try:
            r = (fetch_json(f"{base}/account-ratio?category=linear&symbol={sym}&period=5min&limit=1").get("result") or {}).get("list") or []
            if r:
                b, s_ = _f(r[0].get("buyRatio")), _f(r[0].get("sellRatio"))
                out["ls_account"] = (b / s_) if s_ > 0 else None
        except Exception:
            out["ls_account"] = None
        try:
            tr = (fetch_json(f"{base}/recent-trade?category=linear&symbol={sym}&limit=500").get("result") or {}).get("list") or []
            buy = sum(_f(x.get("size")) for x in tr if str(x.get("side", "")).lower() == "buy")
            sell = sum(_f(x.get("size")) for x in tr if str(x.get("side", "")).lower() == "sell")
            out["taker_ls"] = (buy / sell) if sell > 0 else None; out["taker_n"] = len(tr)
            ts_ = [_f(x.get("time")) for x in tr if x.get("time")]
            out["taker_span_s"] = (max(ts_) - min(ts_)) / 1000 if len(ts_) > 1 else 0
            out["vol_1h"] = out["vol_24h_usd"] / 24      # Näherung: gleichmäßig über den Tag
        except Exception:
            out["taker_ls"] = None; out["vol_1h"] = out["vol_24h_usd"] / 24
        return out
    return _cached(("bybit", coin), 45, fetch)


def okx_snapshot(coin: str) -> dict | None:
    """OKX USDT-Swap: OI, Funding, 24-h-Volumen, Long/Short-Konten, Taker-Volumen, jüngste Liquidationen."""
    inst = f"{coin}-USDT-SWAP"; base = "https://www.okx.com/api/v5"
    def fetch():
        tk = (fetch_json(f"{base}/market/ticker?instId={inst}").get("data") or [])
        if not tk:
            return None
        tk = tk[0]; last = _f(tk.get("last"))
        out = {"last": last, "vol_24h_usd": _f(tk.get("volCcy24h")) * last, "ts": int(time.time())}
        out["vol_1h"] = out["vol_24h_usd"] / 24
        try:
            oi = (fetch_json(f"{base}/public/open-interest?instType=SWAP&instId={inst}").get("data") or [{}])[0]
            out["oi"] = _f(oi.get("oiCcy")); out["oi_usd"] = out["oi"] * last
        except Exception:
            out["oi"] = 0; out["oi_usd"] = 0
        try:
            fr = (fetch_json(f"{base}/public/funding-rate?instId={inst}").get("data") or [{}])[0]
            out["funding"] = _f(fr.get("fundingRate")) / 8
        except Exception:
            out["funding"] = None
        try:
            ls = (fetch_json(f"{base}/rubik/stat/contracts/long-short-account-ratio?ccy={coin}&period=5m").get("data") or [])
            out["ls_account"] = _f(ls[0][1]) if ls else None
        except Exception:
            out["ls_account"] = None
        try:
            tv = (fetch_json(f"{base}/rubik/stat/taker-volume?ccy={coin}&instType=CONTRACTS&period=5m").get("data") or [])
            if tv:
                sell, buy = _f(tv[0][1]), _f(tv[0][2])
                out["taker_ls"] = (buy / sell) if sell > 0 else None
        except Exception:
            out["taker_ls"] = None
        try:
            ct = _cached(("okx_ctval", coin), 86_400, lambda: _f(((fetch_json(f"{base}/public/instruments?instType=SWAP&instId={inst}").get("data") or [{}])[0]).get("ctVal"), 0.01)) or 0.01
            lq = (fetch_json(f"{base}/public/liquidation-orders?instType=SWAP&uly={coin}-USDT&state=filled&limit=100").get("data") or [])
            det = lq[0].get("details", []) if lq else []
            since = (time.time() - 3600) * 1000
            out["liq_1h_long"] = sum(_f(d.get("sz")) * _f(d.get("bkPx")) for d in det if d.get("side") == "sell" and _f(d.get("ts")) >= since) * ct
            out["liq_1h_short"] = sum(_f(d.get("sz")) * _f(d.get("bkPx")) for d in det if d.get("side") == "buy" and _f(d.get("ts")) >= since) * ct
        except Exception:
            out["liq_1h_long"] = out["liq_1h_short"] = None
        return out
    return _cached(("okx", coin), 45, fetch)


def etf_flows(coin: str) -> dict | None:
    """
    Tägliche Netto-Flüsse der Spot-ETFs (Mio USD): CoinGlass mit Schlüssel, sonst Farside-Tabelle.
    Liefert die letzten 10 Tage, den letzten Tag, die 5-Tage-Summe und die Serie gleicher Vorzeichen.
    """
    if coin not in ("BTC", "ETH"):
        return None
    def fetch():
        days: list = []
        key = (tokens().get("coinglass") or {}).get("api_key")
        if key:
            try:
                import urllib.request
                url = f"https://open-api-v4.coinglass.com/api/etf/{'bitcoin' if coin == 'BTC' else 'ethereum'}/flow-history"
                req = urllib.request.Request(url, headers={"CG-API-KEY": key, "User-Agent": "hl-dashboard/1.0"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    d = json.loads(r.read().decode())
                for row in (d.get("data") or [])[-15:]:
                    ts = int(row.get("timestamp") or 0) // 1000
                    days.append((time.strftime("%Y-%m-%d", time.gmtime(ts)), _f(row.get("flow_usd")) / 1e6))
            except Exception:
                days = []
        if not days:
            html = fetch_json(f"https://farside.co.uk/{coin.lower()}/", timeout=20, text=True)
            months = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}
            for row in re.findall(r"<tr[^>]*>(.*?)</tr>", html, re.S):
                cells = [re.sub(r"<[^>]+>", "", c).replace("&nbsp;", " ").strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)]
                if len(cells) < 3:
                    continue
                m = re.match(r"(\d{1,2}) (\w{3}) (\d{4})", cells[0])
                if not m or m.group(2) not in months:
                    continue
                tot = cells[-1].replace(",", "")
                neg = tot.startswith("(")
                val = _f(tot.strip("()"), 0.0) * (-1 if neg else 1) if tot not in ("-", "") else 0.0
                days.append((f"{m.group(3)}-{months[m.group(2)]:02d}-{int(m.group(1)):02d}", val))
        if not days:
            return None
        days = sorted(days)[-10:]
        vals = [v for _, v in days]
        streak = 0
        for v in reversed(vals):
            if v == 0 or (streak and (v > 0) != (vals[-1] > 0)):
                break
            streak += 1
        return {"days": days, "last": vals[-1], "last_date": days[-1][0], "sum5": sum(vals[-5:]), "streak": streak * (1 if vals[-1] > 0 else -1),
                "source": "CoinGlass" if key else "Farside"}
    return _cached(("etf", coin), 3600, fetch)


_WARM: dict = {}


def _lbact_bg(coin, price, days, min_big, newest_first, hourly):
    c = connect(Handler.db)
    try:
        return load_lb_activity(c, coin, price, days=days, min_big=min_big, newest_first=newest_first, hourly=hourly)
    finally:
        c.close()


def _warm(key, fn):
    """Langsame Quelle im Hintergrund berechnen: liefert den letzten Stand, stößt die Erneuerung an."""
    with _BNC_LOCK:
        hit = _BNC_CACHE.get(key)
        running = _WARM.get(key)
    fresh = hit and time.time() - hit[0] < {"smart": 600, "etf": 3600, "lbact": 30, "lbact48": 30}.get(key[0], 300)
    if fresh:
        return hit[1]
    if not running:
        def run():
            try:
                val = fn()
                with _BNC_LOCK:
                    _BNC_CACHE[key] = (time.time(), val)
                    _kappen(_BNC_CACHE, 128)
            finally:
                with _BNC_LOCK:
                    _WARM[key] = None
        with _BNC_LOCK:
            _WARM[key] = threading.Thread(target=run, daemon=True)
            _WARM[key].start()
    return hit[1] if hit else None


_LB_CACHE: dict = {}


def load_leaderboard(con, coin: str, top_n: int = 20, days: int = 7) -> dict:
    key = (coin, top_n, days)
    with _LBACT_LOCK:
        hit = _LB_CACHE.get(key)
        if hit and time.time() - hit[0] < 30:
            return hit[1]
    out = _load_leaderboard(con, coin, top_n, days)
    with _LBACT_LOCK:
        _LB_CACHE[key] = (time.time(), out)
        _kappen(_LB_CACHE, 48)                      # Schlüsselraum begrenzen (Re-Audit N5)
    return out


def _load_leaderboard(con, coin: str, top_n: int = 20, days: int = 7) -> dict:
    """
    Jüngste Abfrage des Recorders: Top-Konten mit Positionen (gruppiert), Trendreihe je
    Stunde für den Coin (lb_trend) und die BTC-Trendkachel (aktuell gegen 24 h zuvor).
    """
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.OperationalError:
        return {"ts": None, "accounts": [], "trend": [], "btc": None, "summary": None, "top_n": top_n}
    if not last:
        return {"ts": None, "accounts": [], "trend": [], "btc": None, "summary": None, "top_n": top_n}
    accts = [dict(r) for r in con.execute(
        "SELECT rank, addr, name, account_value, pnl_30d, roi_30d, pnl_7d, n_positions FROM lb_accounts WHERE ts=? AND rank<=? ORDER BY rank",
        (last, top_n))]
    pos = con.execute(
        "SELECT rank, addr, coin, side, size, pos_value, entry_px, liq_px, leverage, upnl, mark_px FROM lb_positions WHERE ts=? AND rank<=? ORDER BY rank, pos_value DESC",
        (last, top_n)).fetchall()
    by_addr: dict = {}
    for r in pos:
        by_addr.setdefault(r["addr"], []).append(dict(r))
    for a in accts:
        a["positions"] = by_addr.get(a["addr"], [])
        a["upnl"] = sum(p["upnl"] or 0 for p in a["positions"])
        a["pos_total"] = sum(p["pos_value"] or 0 for p in a["positions"])
    since = last - days * 86_400
    trend = [dict(r) for r in con.execute(
        "SELECT ts, n_long, n_short, usd_long, usd_short, net_usd, n_accounts, mark_px FROM lb_trend WHERE coin=? AND top_n=? AND ts>=? ORDER BY ts",
        (coin, top_n, since))]
    # aktuelle Verteilung im gewählten Coin aus der jüngsten Abfrage
    cur = {"n_long": 0, "n_short": 0, "usd_long": 0.0, "usd_short": 0.0}
    for r in pos:
        if r["coin"] == coin:
            if r["side"] == "long":
                cur["n_long"] += 1; cur["usd_long"] += r["pos_value"] or 0
            else:
                cur["n_short"] += 1; cur["usd_short"] += r["pos_value"] or 0
    cur["net_usd"] = cur["usd_long"] - cur["usd_short"]
    def btc_tile():
        btc_now = {"n_long": 0, "n_short": 0, "usd_long": 0.0, "usd_short": 0.0}
        for r in pos:
            if r["coin"] == "BTC":
                if r["side"] == "long":
                    btc_now["n_long"] += 1; btc_now["usd_long"] += r["pos_value"] or 0
                else:
                    btc_now["n_short"] += 1; btc_now["usd_short"] += r["pos_value"] or 0
        btc_now["net_usd"] = btc_now["usd_long"] - btc_now["usd_short"]
        ago = con.execute("SELECT net_usd, n_long, n_short FROM lb_trend WHERE coin='BTC' AND top_n=? AND ts<=? ORDER BY ts DESC LIMIT 1",
                          (top_n, last - 86_400)).fetchone()
        first = con.execute("SELECT net_usd FROM lb_trend WHERE coin='BTC' AND top_n=? AND ts>=? ORDER BY ts LIMIT 1", (top_n, since)).fetchone()
        btc_now["net_24h_ago"] = ago["net_usd"] if ago else None
        btc_now["delta_24h"] = (btc_now["net_usd"] - ago["net_usd"]) if ago else None
        btc_now["delta_7d"] = (btc_now["net_usd"] - first["net_usd"]) if first else None
        return btc_now
    # Leaderboard-Flow: Ereignisse DIREKTIONALER Konten in 30/60/180 min, Z-Score gegen 7-Tage-Stundenflüsse
    flow = {}; events = []
    try:
        dir_set = hl_forecast.lb_directional_addrs(con, coin)
        now_ = int(time.time())
        ev = con.execute("SELECT ts, addr, coin, event, side, delta_usd, pos_value, mark_px FROM lb_events WHERE coin=? AND ts>=? ORDER BY ts DESC",
                         (coin, now_ - 7 * 86_400)).fetchall()
        def signed(e):
            d = abs(e["delta_usd"] or 0)
            if e["event"] in ("open", "add", "flip"):
                return d if e["side"] == "long" else -d
            return -d if e["side"] == "long" else d
        names = {r["addr"]: (r["name"], r["rank"]) for r in con.execute("SELECT addr, name, rank FROM lb_accounts WHERE ts=?", (last,))}
        for w in (30, 60, 180):
            buy = sell = 0.0; nb = set(); ns = set()
            for e in ev:
                if e["ts"] < now_ - w * 60 or e["addr"] not in dir_set:
                    continue
                v = signed(e)
                if v > 0: buy += v; nb.add(e["addr"])
                elif v < 0: sell += -v; ns.add(e["addr"])
            flow[f"w{w}"] = {"buy_usd": buy, "sell_usd": sell, "net_usd": buy - sell, "n_buy": len(nb), "n_sell": len(ns)}
        hourly: dict = {}
        for e in ev:
            if e["addr"] in dir_set:
                hourly[e["ts"] // 3600] = hourly.get(e["ts"] // 3600, 0.0) + signed(e)
        # Z-Wert nur über aktive Stunden (Anzeige). Nullstunden nachzutragen war falsch --
        # die Streuung schrumpfte, das Signal feuerte in 42 statt 2 Prozent der Stunden.
        vals = [v for h_, v in hourly.items() if h_ != now_ // 3600]      # ohne die laufende Stunde
        if len(vals) >= 24:
            m = sum(vals) / len(vals); sd = (sum((v - m) ** 2 for v in vals) / max(1, len(vals) - 1)) ** 0.5
            flow["z60"] = (flow["w60"]["net_usd"] - m) / sd if sd > 0 else 0.0
        else:
            flow["z60"] = None
        w60 = flow["w60"]; same = w60["n_buy"] if w60["net_usd"] > 0 else w60["n_sell"]
        # M9: Signal = Rang in der vollständigen Wochenreihe (inklusive Nullstunden), plus
        # absolute Untergrenze (500 k netto) und Breite (drei Konten). Mindestens 48 h Historie.
        hist_h = (now_ - min((e["ts"] for e in ev), default=now_)) / 3600
        flow["rang60"] = hl_forecast.rang_in_reihe(w60["net_usd"], vals) if hist_h >= 48 else None
        flow["event_signal"] = bool(flow["rang60"] is not None and flow["rang60"] >= 98 and abs(w60["net_usd"]) >= 5e5 and same >= 3)
        flow["event_signal_z"] = bool(flow["z60"] is not None and abs(flow["z60"]) >= 2.5 and same >= 3)   # alte Regel, nur zum Vergleich
        flow["n_directional"] = len(dir_set)
        events = [dict(e, directional=e["addr"] in dir_set, name=names.get(e["addr"], (None, None))[0], rank=names.get(e["addr"], (None, None))[1])
                  for e in ev[:40]]
    except sqlite3.OperationalError:
        pass
    # Abholstand der Fills: wie viele Konten hängen zurück? Gehört sichtbar ins Dashboard,
    # sonst müsste man für diese eine Zahl den Zweiminutenbericht laufen lassen.
    lag = None
    try:
        rows = [r[0] or 0 for r in con.execute("SELECT ts FROM lb_cursor")]
        if rows:
            jetzt = int(time.time())
            rueck = sorted((jetzt - t) / 3600 for t in rows)
            lag = {"n": len(rueck), "median_h": rueck[len(rueck) // 2], "max_h": rueck[-1],
                   "hinten": sum(1 for r in rueck if r > 3)}
    except sqlite3.OperationalError:
        pass
    return {"ts": last, "accounts": accts, "trend": trend, "btc": btc_tile(), "summary": cur, "top_n": top_n,
            "flow": flow, "events": events, "lag": lag}


_LBACT_CACHE: dict = {}
_LBACT_LOCK = threading.Lock()

# Kaufdruck = Open Long + Close Short + Spot-Buy; Verkaufsdruck = Open Short + Close Long + Spot-Sell.
# Als SQL-Ausdruck, damit die Datenbank aggregiert -- nicht Python über hunderttausende Zeilen.
_IS_BUY_SQL = "COALESCE(buy, (CASE WHEN lower(dir) LIKE '%open long%' OR lower(dir) LIKE '%close short%' OR lower(dir) LIKE '%buy%' THEN 1 WHEN upper(side) LIKE 'B%' AND lower(dir) NOT LIKE '%sell%' AND lower(dir) NOT LIKE '%short%' AND lower(dir) NOT LIKE '%close long%' THEN 1 ELSE 0 END))"


_LBACT_CACHE: dict = {}
_LBACT_LOCK = threading.Lock()


def _is_buy(d: str, side: str) -> bool:
    d = (d or "").lower()
    if "open long" in d or "close short" in d or "buy" in d:
        return True
    if "open short" in d or "close long" in d or "sell" in d:
        return False
    return (side or "").upper().startswith("B")


def load_lb_activity(con, coin: str, price: float, days: int = 3, min_big: float = 5e4, newest_first: bool = False,
                     hourly: bool = False) -> dict | None:
    """
    Käufe/Verkäufe der Top-Konten (Perp und Spot). Alle Summen rechnet SQLite über die Spalte
    buy (Index coin, ts, buy); Python sieht nur Gruppen. Ergebnis 30 s gehalten, weil /chart alle
    5 s anfragt. Vorher: Vollscan und Python-Summen je Aufruf -- das hat den Pi lahmgelegt.
    """
    key = (coin, days, min_big, newest_first, hourly, round(price / 50) if price else 0)
    with _LBACT_LOCK:
        hit = _LBACT_CACHE.get(key)
        if hit and time.time() - hit[0] < 30:
            return hit[1]
    try:
        last_fill = con.execute("SELECT MAX(ts) FROM lb_fills").fetchone()[0]
        has_buy = "buy" in {r[1] for r in con.execute("PRAGMA table_info(lb_fills)")}
    except sqlite3.OperationalError:
        return None
    if not last_fill:
        return None
    # Kaufdruck-Ausdruck: Spalte buy, sonst (alte Datenbank vor der Migration) aus dir/side
    BUY = "buy" if has_buy else ("(CASE WHEN lower(dir) LIKE '%open long%' OR lower(dir) LIKE '%close short%' OR lower(dir) LIKE '%buy%' THEN 1 "
                                 "WHEN lower(dir) LIKE '%open short%' OR lower(dir) LIKE '%close long%' OR lower(dir) LIKE '%sell%' THEN 0 "
                                 "WHEN upper(side) LIKE 'B%' THEN 1 ELSE 0 END)")
    now = int(time.time()); since = now - days * 86_400; d24 = now - 86_400
    per_coin: dict = {}
    for r in con.execute(f"""SELECT coin, market, {BUY} b, SUM(notional) usd, COUNT(*) n, SUM(closed_pnl) pnl,
                                    SUM(CASE WHEN ts>=? THEN notional ELSE 0 END) usd24
                             FROM lb_fills WHERE ts>=? GROUP BY coin, market, b""", (d24, since)):
        buy = bool(r["b"]); c = r["coin"]
        d = per_coin.setdefault(c, {"coin": c, "buy_usd": 0.0, "sell_usd": 0.0, "buy_usd_24h": 0.0, "sell_usd_24h": 0.0, "n_buyers": 0, "n_sellers": 0,
                                    "n": 0, "spot_usd": 0.0, "perp_usd": 0.0, "closed_pnl": 0.0})
        d["n"] += r["n"]; d["closed_pnl"] += r["pnl"] or 0
        d["buy_usd" if buy else "sell_usd"] += r["usd"] or 0; d["buy_usd_24h" if buy else "sell_usd_24h"] += r["usd24"] or 0
        d["spot_usd" if r["market"] == "spot" else "perp_usd"] += r["usd"] or 0
    for r in con.execute(f"SELECT coin, {BUY} b, COUNT(DISTINCT addr) a FROM lb_fills WHERE ts>=? GROUP BY coin, b", (since,)):
        if r["coin"] in per_coin:
            per_coin[r["coin"]]["n_buyers" if r["b"] else "n_sellers"] = r["a"]
    coins = []
    for c, d in sorted(per_coin.items(), key=lambda kv: -(kv[1]["buy_usd"] + kv[1]["sell_usd"])):
        d["net_usd"] = d["buy_usd"] - d["sell_usd"]; d["net_usd_24h"] = d["buy_usd_24h"] - d["sell_usd_24h"]; coins.append(d)
    names = {}
    try:
        last_lb = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
        for r in con.execute("SELECT addr, name, rank FROM lb_accounts WHERE ts=?", (last_lb,)):
            names[r["addr"]] = {"name": r["name"], "rank": r["rank"]}
    except sqlite3.OperationalError:
        pass
    per_acct: dict = {}
    for r in con.execute(f"""SELECT addr, {BUY} b, SUM(notional) usd, COUNT(*) n, MAX(ts) last, SUM(px*sz) pxsz, SUM(sz) sz
                             FROM lb_fills WHERE coin=? AND ts>=? GROUP BY addr, b""", (coin, since)):
        a = per_acct.setdefault(r["addr"], {"addr": r["addr"], "buy": 0.0, "sell": 0.0, "n": 0, "last": 0, "pxsz": 0.0, "sz": 0.0})
        a["n"] += r["n"]; a["last"] = max(a["last"], r["last"])
        if r["b"]:
            a["buy"] += r["usd"] or 0; a["pxsz"] += r["pxsz"] or 0; a["sz"] += r["sz"] or 0
        else:
            a["sell"] += r["usd"] or 0
    accts = sorted(per_acct.values(), key=lambda a: -(a["buy"] + a["sell"]))[:30]
    for a in accts:
        a["net"] = a["buy"] - a["sell"]; a["vwap_buy"] = (a["pxsz"] / a["sz"]) if a["sz"] else None
        a["since_buy_pct"] = ((price / a["vwap_buy"] - 1) * 100) if (a["vwap_buy"] and price) else None
        a.update(names.get(a["addr"], {})); a.pop("pxsz", None); a.pop("sz", None)
    # Eine große Order wird in viele Teilausführungen zerlegt -- oft Dutzende in derselben
    # Sekunde. Einzeln aufgelistet füllen sie die Tabelle mit identischen Zeilen und verdecken
    # alles andere. Deshalb je Konto, Richtung, Markt und Minute zu einer Zeile gebündelt,
    # mit Anzahl der Teilausführungen und mengengewichtetem Preis.
    big = []
    # Ausgewählt wird nach Größe (die größten N), ANGEZEIGT wird chronologisch -- eine Tabelle,
    # deren Zeilen zeitlich springen, ist nicht lesbar, und alle übrigen Tabellen sind
    # chronologisch. Deshalb die Auswahl in einer Unterabfrage, die Sortierung außen.
    auswahl = "ts DESC" if newest_first else "usd DESC"
    for r in con.execute(f"""SELECT * FROM (
                                 SELECT MAX(ts) ts, addr, market, dir, {BUY} b, SUM(notional) usd,
                                        SUM(px*notional)/NULLIF(SUM(notional),0) px, SUM(closed_pnl) pnl, COUNT(*) n
                                 FROM lb_fills WHERE coin=? AND ts>=?
                                 GROUP BY addr, market, dir, {BUY}, ts/60
                                 HAVING usd >= ? ORDER BY {auswahl} LIMIT ?)
                             ORDER BY ts DESC""",
                         (coin, since, min_big, 60 if newest_first else 25)):
        buy = bool(r["b"])
        big.append({"ts": r["ts"], "addr": r["addr"], "market": r["market"], "dir": r["dir"], "buy": buy,
                    "px": r["px"], "notional": r["usd"], "n": r["n"], "closed_pnl": r["pnl"],
                    "since_pct": ((price / r["px"] - 1) * 100 * (1 if buy else -1)) if (price and r["px"]) else None,
                    **names.get(r["addr"], {})})
    series = []
    if hourly:
        h0 = since // 3600 * 3600; buckets: dict = {}
        for r in con.execute(f"""SELECT (ts/3600)*3600 h, {BUY} b, SUM(notional) usd, COUNT(*) n FROM lb_fills
                                 WHERE coin=? AND ts>=? GROUP BY h, b""", (coin, h0)):
            d = buckets.setdefault(r["h"], {"ts": r["h"], "buy": 0.0, "sell": 0.0, "n": 0})
            d["buy" if r["b"] else "sell"] += r["usd"] or 0; d["n"] += r["n"]
        pxs = {}
        try:
            for r in con.execute("SELECT (ts/3600)*3600 h, MAX(ts) mts, close FROM bars WHERE coin=? AND ts>=? GROUP BY h", (coin, h0)):
                pxs[r["h"]] = r["close"]
        except sqlite3.OperationalError:
            pass
        cum = 0.0
        for t in range(h0, now + 1, 3600):
            d = buckets.get(t, {"ts": t, "buy": 0.0, "sell": 0.0, "n": 0}); cum += d["buy"] - d["sell"]
            series.append({**d, "cum": cum, "px": pxs.get(t)})
    spot = []
    try:
        last_spot = con.execute("SELECT MAX(ts) FROM lb_spot").fetchone()[0]
        if last_spot:
            for r in con.execute("SELECT coin, token, COUNT(*) n, SUM(total) total, SUM(value_usd) usd, SUM(entry_ntl) entry FROM lb_spot WHERE ts=? GROUP BY token ORDER BY usd DESC", (last_spot,)):
                spot.append({"coin": r["coin"], "token": r["token"], "n": r["n"], "total": r["total"], "usd": r["usd"] or 0, "entry": r["entry"] or 0})
    except sqlite3.OperationalError:
        pass
    sel = next((d for d in coins if d["coin"] == coin), None)
    out = {"since": since, "last_fill": last_fill, "coins": coins, "accounts": accts, "big": big, "spot": spot, "selected": sel, "days": days, "series": series}
    with _LBACT_LOCK:
        _LBACT_CACHE[key] = (time.time(), out)
        _kappen(_LBACT_CACHE, 48)
    return out


def smart_money(con, coin: str, top_n: int = 50) -> dict | None:
    """Smart-Money-Kachel aus der jüngsten Leaderboard-Abfrage des Recorders (Top 50)."""
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.OperationalError:
        return None
    if not last:
        return None
    out = {"n_accounts": con.execute("SELECT COUNT(*) FROM lb_accounts WHERE ts=? AND rank<=?", (last, top_n)).fetchone()[0],
           "coin": {"n_long": 0, "usd_long": 0.0, "n_short": 0, "usd_short": 0.0},
           "all": {"n_long": 0, "usd_long": 0.0, "n_short": 0, "usd_short": 0.0}, "ts": last}
    net: dict = {}
    for r in con.execute("SELECT addr, coin, side, pos_value FROM lb_positions WHERE ts=? AND rank<=?", (last, top_n)):
        signed = (r["pos_value"] or 0) * (1 if r["side"] == "long" else -1)
        d = net.setdefault(r["addr"], {"all": 0.0, "coin": 0.0})
        d["all"] += signed
        if r["coin"] == coin:
            d["coin"] += signed
    for addr, d in net.items():
        for key in ("all", "coin"):
            v = d[key]
            if v > 0:
                out[key]["n_long"] += 1; out[key]["usd_long"] += v
            elif v < 0:
                out[key]["n_short"] += 1; out[key]["usd_short"] += -v
    return out


def attach_sources(payload: dict, coin: str, src: str, con=None) -> dict:
    """ETF-Flows und Smart Money in jeder Quelle; Bybit und OKX im Binance- und Fusionsmodus."""
    payload["etf"] = _warm(("etf", coin), lambda: etf_flows(coin))
    payload["smart"] = smart_money(con, coin) if con is not None else None
    payload["lb"] = load_leaderboard(con, coin, 20) if con is not None else None
    # Käufe/Verkäufe: im Hintergrund berechnet (eigene Verbindung), der Aufruf liefert den letzten Stand sofort
    price = payload.get("price") or 0
    payload["cb"] = coinbase_cached(Handler.db, coin, price)
    payload["lb_act"] = _warm(("lbact", coin, 3), lambda: _lbact_bg(coin, price, 3, 5e4, False, False))
    payload["lb_act48"] = _warm(("lbact48", coin, 2), lambda: _lbact_bg(coin, price, 2, 2.5e4, True, True))
    if src in ("bnc", "fusion"):
        _t0 = time.time()
        payload["bybit"] = None if ungelistet("Bybit", coin) else bybit_snapshot(coin)
        if not ungelistet("Bybit", coin):
            note_ext("Bybit", _t0, payload.get("bybit") is not None, coin)
        _t0 = time.time()
        payload["okx"] = None if ungelistet("OKX", coin) else okx_snapshot(coin)
        if not ungelistet("OKX", coin):
            note_ext("OKX", _t0, payload.get("okx") is not None, coin)
    return payload


def load_chart(con, coin: str, minutes: int = 240, agg: int = 1, top: int = 14,
               fvg_min: float = 0.0005):
    """Kerzen aus den 1-Minuten-Bars plus die stärksten aktuellen Level."""
    t_from = int(time.time()) - minutes * 60
    source = "eigene Hyperliquid-Bars"
    if agg >= 240:
        candles, source = load_long_candles(con, coin, agg, minutes)
        rows = con.execute("SELECT ts, open, high, low, close, volume FROM bars "
                           "WHERE coin=? AND ts>=? ORDER BY ts", (coin, int(time.time()) - 3600)).fetchall()
    else:
        rows = con.execute(
            "SELECT ts, open, high, low, close, volume FROM bars "
            "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
        candles = aggregate([tuple(r) for r in rows], max(agg, 1) * 60)

    # 60-Minuten-Trend aus den Minutenbars, unabhängig vom Chart-Raster
    trend = None
    if len(rows) >= 61:
        t_ref = rows[-1]["ts"] - 3600                                    # N2 (Audit v10): 60 Minuten, nicht 60 Zeilen
        then_row = next((r for r in reversed(rows) if r["ts"] <= t_ref), rows[0])
        c_now, c_then = rows[-1]["close"], then_row["close"]
        if c_then:
            trend = c_now / c_then - 1

    # RSI(14) nach Wilder auf dem angezeigten Kerzenraster
    rsi = None
    closes = [c["c"] for c in candles]
    if len(closes) >= 16:
        gains, losses = [], []
        for a, b in zip(closes[:-1], closes[1:]):
            d_ = b - a
            gains.append(max(d_, 0.0)); losses.append(max(-d_, 0.0))
        n = 14
        ag = sum(gains[:n]) / n
        al = sum(losses[:n]) / n
        for g_, l_ in zip(gains[n:], losses[n:]):
            ag = (ag * (n - 1) + g_) / n
            al = (al * (n - 1) + l_) / n
        rsi = 100.0 if al == 0 else 100.0 - 100.0 / (1.0 + ag / al)

    d = load_depth(con, coin)
    levels = []
    if d and d["price"]:
        px = d["price"]
        near = [r for r in d["rows"] if 0.88 * px < r["bucket_px"] < 1.15 * px]
        near.sort(key=lambda r: -r["notional"])
        for r in near[:top]:
            levels.append({
                "px": r["bucket_px"], "side": r["side"],
                "notional": r["notional"], "n_pos": r["n_pos"],
                "dist": (r["bucket_px"] - px) / px,
                # Verhältnis zum Stundenvolumen: entscheidet, ob ein Level trägt
                "x_vol": (r["notional"] / d["vol_1h"]) if d["vol_1h"] else 0,
            })

    try:
        events = [dict(r) for r in con.execute(
            "SELECT t_trigger, reason, move_pct, px_extreme, n_ticks, n_liqs "
            "FROM tick_events WHERE coin=? AND reason != 'control' "
            "ORDER BY t_trigger DESC LIMIT 5", (coin,))]
    except sqlite3.OperationalError:
        events = []

    # Zusatzsignale für die Konfluenz-Anzeige, alle ohne Speicherung
    book = funding = None
    danger = None
    try:
        r = con.execute("SELECT ts, spread_bps, bid_50, ask_50, imb_50 FROM book_summary "
                        "WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if r and time.time() - r["ts"] < 600:
            book = dict(r)
        r = con.execute("SELECT ts, funding, oi FROM ctx_bars WHERE coin=? "
                        "ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if r and time.time() - r["ts"] < 900:
            funding = dict(r)
        # Danger-Time: ist das aktuelle 30-Minuten-Fenster laut Zeit-Heatmap belastbar erhöht?
        import datetime as _dt
        nowu = _dt.datetime.now(_dt.timezone.utc)
        slot = nowu.hour * 2 + (1 if nowu.minute >= 30 else 0)
        r = con.execute("SELECT threshold, rate, lift FROM time_heatmap WHERE coin=? AND tz='UTC' "
                        "AND weekday=? AND slot=? AND robust=1 ORDER BY threshold DESC LIMIT 1",
                        (coin, nowu.weekday(), slot)).fetchone()
        if r:
            danger = dict(r)
    except sqlite3.OperationalError:
        pass

    fvgs = find_fvgs(candles, fvg_min)
    last = candles[-1]["c"] if candles else 0
    mas = load_mas(con, coin, last)
    stops = load_stops(con, coin, last)
    budget = load_api_budget(con)
    for g in fvgs:
        g["dist"] = ((g["bot"] if g["kind"] == "bull" else g["top"]) / last - 1) if last else 0

    return {
        "candles": candles, "levels": levels,
        "tick_events": events,
        "fvgs": fvgs,
        "book": book, "funding": funding, "danger": danger,
        "mas": mas, "source": source, "agg": agg, "stops": stops, "budget": budget,
        "price": d["price"] if d else None,
        "vol_1h": d["vol_1h"] if d else 0,
        "snapshot_ts": d["ts"] if d else 0,
        "trend_60m": trend,
        "rsi14": rsi,
        "rsi_tf": f"{agg} min" if agg < 60 else f"{agg // 60} h",
    }


def plot_heatmap(con, coin: str, hours: int, out: str,
                 threshold: float = 0.70, gamma: float = 2.6) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.colors import LinearSegmentedColormap
    from matplotlib.dates import DateFormatter, date2num

    d = load_grid(con, coin, hours)
    if d is None:
        print(f"Keine Daten für {coin} in den letzten {hours} h.")
        return

    z = np.array(d["grid"], dtype=float)

    # Perzentil-Zuordnung statt Normierung aufs Maximum: entscheidend ist der
    # Rang einer Zelle unter allen anderen. Anschließend eine Potenz, damit
    # die Masse dunkel bleibt und nur die stärksten Cluster leuchten.
    pos = z[z > 0]
    if pos.size == 0:
        print("Nur leere Zellen.")
        return
    srt = np.sort(pos)
    rank = np.searchsorted(srt, z, side="right") / srt.size
    rank[z <= 0] = 0.0
    vis = rank >= threshold
    q = np.zeros_like(rank)
    q[vis] = ((rank[vis] - threshold) / max(1e-9, 1 - threshold)) ** gamma
    q = np.ma.masked_where(~vis, q)

    cmap = LinearSegmentedColormap.from_list("liq", [
        (0.00, "#04060f"), (0.22, "#0a288c"), (0.45, "#0096c8"),
        (0.68, "#3cdcb4"), (0.85, "#ffd60a"), (1.00, "#ffffeb")])
    cmap.set_bad("#04060f")

    x = date2num([np.datetime64(t, "s") for t in d["times"]])
    y = np.array(d["levels"])

    fig, ax = plt.subplots(figsize=(15, 8.5))
    ax.set_facecolor("#04060f")
    mesh = ax.pcolormesh(x, y, q, cmap=cmap, vmin=0, vmax=1, shading="nearest")

    pt = date2num([np.datetime64(t, "s") for t, _ in d["price"]])
    ax.plot(pt, [p for _, p in d["price"]], color="#ffffff", lw=1.5,
            label="Kurs", zorder=5)

    if d["liqs"]:
        lt = date2num([np.datetime64(t, "s") for t, *_ in d["liqs"]])
        lp = [p for _, p, *_ in d["liqs"]]
        ls = [max(6, min(220, n / 4000)) for *_, n, _ in d["liqs"]]
        ax.scatter(lt, lp, s=ls, facecolor="none", edgecolor="#ff3b6b",
                   lw=1.1, zorder=6, label="Liquidationen")

    prices = [p for _, p in d["price"]]
    ax.set_ylim(min(prices) * 0.90, max(prices) * 1.10)
    ax.xaxis.set_major_formatter(DateFormatter("%d.%m %H:%M"))
    ax.set_title(f"{coin} — Liquidationscluster, letzte {hours} h · "
                 f"nur oberhalb Perzentil {threshold*100:.0f}", fontsize=12)
    ax.set_ylabel("Preis")
    ax.grid(alpha=0.10, ls=":")
    ax.legend(loc="upper left", framealpha=0.6)
    cb = fig.colorbar(mesh, ax=ax, pad=0.01)
    cb.set_label("relative Clusterstärke (Rang unter allen Zellen)")
    fig.autofmt_xdate()
    plt.tight_layout()
    plt.savefig(out, dpi=130, facecolor="#0d1117")
    print(f"Gespeichert: {out}")


def plot_depth(con, coin: str, out: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    d = load_depth(con, coin)
    if not d or not d["rows"] or not d["price"]:
        print(f"Kein aktueller Snapshot für {coin}.")
        return

    px, v1h = d["price"], d["vol_1h"]
    rows = [r for r in d["rows"] if 0.8 * px < r["bucket_px"] < 1.25 * px]
    if not rows:
        print("Keine Cluster im relevanten Preisbereich.")
        return

    fig, ax = plt.subplots(figsize=(9, 11))
    for r in rows:
        col = "#e04b4b" if r["side"] == "long" else "#3ba55d"
        ax.barh(r["bucket_px"], r["notional"], height=px * 0.0022,
                color=col, alpha=0.85)

    ax.axhline(px, color="#00e5ff", lw=2)
    ax.text(ax.get_xlim()[1], px, f"  {px:,.2f}", va="center",
            color="#00808f", fontsize=10, fontweight="bold")

    if v1h > 0:
        ax.axvline(v1h * 0.5, color="grey", ls="--", lw=1)
        ax.text(v1h * 0.5, ax.get_ylim()[1], " 0.5x 1h-Vol",
                rotation=90, va="top", fontsize=8, color="grey")

    ax.set_title(f"{coin} — Cluster um den Kurs\n"
                 f"rot = Long-Liquidationen, grün = Short-Liquidationen\n"
                 f"Stand {time.strftime('%d.%m. %H:%M', time.localtime(d['ts']))}",
                 fontsize=11)
    ax.set_xlabel("Notional (USD)")
    ax.grid(axis="x", alpha=0.2, ls=":")
    plt.tight_layout()
    plt.savefig(out, dpi=130)
    print(f"Gespeichert: {out}")


# ---------------------------------------------------------------------------
# Live-Dashboard
# ---------------------------------------------------------------------------

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0d1117">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<link rel="manifest" href="/manifest.json">
<link rel="icon" href="/icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icon.svg">
<title>HL Liquidationen</title>
<style>
 table.w{border-collapse:collapse;font-size:11px;min-width:min(100%,900px)}
 table.w th{color:#8b949e;font-weight:500;text-align:left;padding:4px 10px;
   border-bottom:1px solid #21262d;font-size:10px;text-transform:uppercase;white-space:nowrap}
 table.w td{padding:5px 10px;border-bottom:1px solid #161b22;white-space:nowrap}
 table.w th.n,table.w td.n{text-align:right;font-variant-numeric:tabular-nums}
 .mono{font-family:ui-monospace,monospace;font-size:10px;color:#8b949e}
 body{background:#0d1117;color:#c9d1d9;font:13px system-ui,sans-serif;margin:0;padding:16px}
 h1{font-size:17px;margin:0 0 3px} h2{font-size:13px;margin:0 0 2px;color:#e6edf3}
 .sub{color:#8b949e;font-size:11px;line-height:1.45}
 canvas{background:#01030a;border:1px solid #21262d;border-radius:6px;width:100%;
        display:block;cursor:crosshair}
 .row{display:flex;gap:16px;flex-wrap:wrap;margin-top:6px}
 .col{flex:1;min-width:330px}
 .panel{margin-top:20px}
 .bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:12px 0 6px}
 label.lbl{font-size:10px;color:#8b949e;text-transform:uppercase;letter-spacing:.4px}
 select,button{background:#21262d;color:#c9d1d9;border:1px solid #30363d;
   border-radius:5px;padding:5px 9px;font-size:12px}
 button.tog{cursor:pointer;min-width:64px;font-weight:600}
 button.tog.on{background:#1f3d2a;border-color:#3ba55d;color:#7ee787}
 button.tog.off{background:#21262d;color:#8b949e}
 .kpi{display:flex;gap:20px;flex-wrap:wrap;margin:12px 0;padding:10px 12px;
      background:#161b22;border:1px solid #21262d;border-radius:6px}
 .kpi div span{display:block;color:#8b949e;font-size:10px;text-transform:uppercase;
               letter-spacing:.4px}
 .kpi b{font-size:17px;font-weight:600}
 .kpi b .d{display:block;font-size:11px;font-weight:500;color:#8b949e;text-transform:none;letter-spacing:0}
 .kpi b > span:not(.d){text-transform:none;letter-spacing:0;font-size:inherit;font-weight:inherit}
 .kpi b .d span{text-transform:none;letter-spacing:0;font-size:inherit;display:inline}
 .warn{color:#d29922;font-size:11px;margin-top:14px}
 .leg{display:flex;gap:14px;align-items:center;font-size:10px;color:#8b949e;
      margin:5px 0;flex-wrap:wrap}
 /* ---- Struktur: Kopf bleibt oben, Abschnitte nummeriert und einklappbar ---- */
 .top{position:sticky;top:0;z-index:20;background:rgba(13,17,23,0.96);backdrop-filter:blur(6px);
      margin:-16px -16px 0;padding:10px 16px 6px;border-bottom:1px solid #21262d}
 .titlerow{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
 .titlerow h1{margin:0;font-size:17px}
 .nav{display:flex;gap:4px;flex-wrap:wrap;margin-top:6px}
 .nav a{color:#c9d1d9;text-decoration:none;font-size:11px;padding:4px 9px;border-radius:12px;
        background:#161b22;border:1px solid #21262d;cursor:pointer}
 .nav a:hover{border-color:#58a6ff;color:#58a6ff}
 .nav a.dim{color:#8b949e}
 .panel{scroll-margin-top:96px}
 h2.sech{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none;margin:0}
 h2.sech .num{display:inline-flex;width:22px;height:22px;border-radius:50%;background:#21262d;color:#8b949e;
      font-size:11px;align-items:center;justify-content:center;flex:none}
 h2.sech .ttl{flex:1}
 h2.sech .help{font-size:12px;color:#8b949e;border:1px solid #30363d;border-radius:50%;width:18px;height:18px;
      display:inline-flex;align-items:center;justify-content:center;flex:none}
 h2.sech .help:hover{color:#58a6ff;border-color:#58a6ff}
 h2.sech .help.exp{border-radius:5px;width:auto;padding:0 6px;font-size:13px}
 h2.sech .chev{color:#8b949e;font-size:12px;transition:transform .15s;flex:none}
 .panel.closed .body{display:none}
 .panel.closed h2.sech .chev{transform:rotate(-90deg)}
 .panel.closed h2.sech{margin:0}
 .sub.help{border-left:2px solid #30363d;padding-left:10px;margin:8px 0 10px}
 /* ---- Handy (bis 700 px): alles untereinander, große Tippflächen ---- */
 @media (max-width:700px){
  body{padding:10px 10px 24px}
  .top{margin:-10px -10px 0;padding:8px 10px 6px}
  .titlerow h1{font-size:15px}
  .nav{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;padding-bottom:2px}
  .nav a{padding:5px 9px;font-size:11px;white-space:nowrap;flex:none}
  .kpi div span{white-space:normal}
  .panel{scroll-margin-top:120px}
  h1{font-size:16px} .sub{font-size:11px}
  .bar{display:grid;grid-template-columns:1fr 1fr;gap:8px 10px;align-items:center}
  .bar label.lbl{grid-column:1/-1;margin:2px 0 -4px;font-size:9px}
  .bar select,.bar button{width:100%;min-height:40px;font-size:14px;padding:6px 8px}
  .bar button.tog{grid-column:1/-1}
  .kpi{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:10px 14px;padding:10px}
  .kpi > div{min-width:0;overflow-wrap:anywhere}
  .kpi b{font-size:clamp(13px,4vw,17px);white-space:normal}
  .kpi b > span:not(.d){white-space:normal}
  .kpi b .d{display:block;font-size:12px;font-weight:500}
  .kpi div span{font-size:9px}
  .col{min-width:0;flex-basis:100%}
  .leg{gap:8px 12px;font-size:10px}
  .panel{margin-top:16px}
  canvas{border-radius:4px}
  #signalbox{font-size:12px}
  table.w{font-size:12px} table.w tr.grp td{background:#1c2128;border-top:2px solid #30363d;padding-top:7px}
 /* breite Tabellen scrollen im eigenen Rahmen seitwärts, statt die Seite zu verkleinern */
 #whaletable,#lbtable,#stoplevels,#lbactcoins,#lbactbig,#lbactspot,#lbact48coins,#lbact48big,#fcdrivers{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #fclearn .kpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr));gap:10px 14px}
 #fcdrivers table.w{min-width:640px}
 #whaletable table.w,#lbtable table.w,#lbactcoins table.w,#lbactbig table.w,#lbact48coins table.w,#lbact48big table.w{min-width:700px}
 #lbactspot table.w{min-width:560px}
 .lbl-name{color:#e3b341;font-weight:600;font-family:system-ui;font-size:12px}
 .lbl-dim{color:#6e7681;font-family:system-ui;font-size:11px}
 .lbl-ev{display:inline-block;font-size:10px;font-weight:600;padding:1px 6px;border-radius:8px;background:#7c2d12;color:#fed7aa;margin-left:4px;vertical-align:middle}
.lbl-ev.off{background:#21262d;color:#8b949e;font-weight:400}
 .lbl-beh{color:#8b949e;font-family:system-ui;font-size:11px;margin-left:8px}
 .lbl-links{font-family:system-ui;font-size:11px;margin-left:8px} .lbl-links a{color:#58a6ff;text-decoration:none} .lbl-links a:hover{text-decoration:underline}
 table.w td,table.w th{padding:6px 8px}
  #tip{max-width:80vw}
 }
 .sw{display:inline-block;width:11px;height:11px;border-radius:2px;
     margin-right:4px;vertical-align:-1px}
 .grad{width:110px;height:9px;border-radius:2px;background:linear-gradient(90deg,
   #04060f,#0a288c,#0096c8,#3cdcb4,#ffd60a,#ffffeb)}
 #tip{position:fixed;z-index:99;pointer-events:none;display:none;
      background:#0d1117;border:1px solid #30363d;border-radius:8px;
      padding:9px 12px;font-size:12px;box-shadow:0 6px 20px #000a;max-width:260px}
 #tip .t{color:#8b949e;font-size:10px;margin-bottom:5px}
 #tip .r{display:flex;justify-content:space-between;gap:16px;margin:2px 0}
 #tip .r i{font-style:normal;color:#8b949e}
 #tip .r b{font-weight:600}
@media print{
 body.drucken{background:#fff!important;color:#000!important}
 body.drucken .nav, body.drucken button, body.drucken .help, body.drucken .exp, body.drucken .chev,
 body.drucken #sec-update, body.drucken #sec-debug, body.drucken #sec-system, body.drucken #sec-network{display:none!important}
 body.drucken .panel{break-inside:avoid; page-break-inside:avoid; border:1px solid #ccc; background:#fff!important; color:#000!important}
 body.drucken .panel.closed .body, body.drucken .panel .body{display:block!important}
 body.drucken table, body.drucken td, body.drucken th, body.drucken .kpi, body.drucken .sub{color:#000!important; background:#fff!important}
 body.drucken canvas{max-width:100%!important; height:auto!important}
 body.drucken #snaphead{display:block!important; color:#000!important}
}
/* 23.33 TradeLabor */
 #sec-labor .labscroll{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #sec-labor table.w td{vertical-align:top}
 #sec-labor .lz{display:block;font-size:10px;color:#8b949e;white-space:normal;max-width:230px;line-height:1.35;margin-top:1px}
 #labtabs{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0 8px}
 #labtabs button.tog{min-width:0}
 #labkpi b{font-size:15px}
 /* 23.33: die Treiberfamilien-Tabelle scrollt im eigenen Rahmen -- vorher lief auf dem Handy die ganze Seite seitwärts */
 #famtab{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #pooltab,#profistab,#fcdrivers{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}   /* 23.34: Pool-Tabelle (Handy) und Treibertabelle (Desktop) liefen über die Seite hinaus */
/* 23.47 Makro-Chart (U121) */
 #mktabs{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 4px} #mktabs button.tog{min-width:0}
 #sec-makro .mkzeile{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0 8px}
 #sec-makro .mkzeile button.tog{min-width:0;padding:4px 8px} #sec-makro .mkzeile .lbl{margin-right:2px}
 #sec-makro .mkszen input{width:64px;background:#21262d;color:#c9d1d9;border:1px solid #30363d;border-radius:5px;padding:4px 6px;font-size:12px;margin-left:4px}
 #sec-makro .mkfred input{flex:1 1 220px;min-width:0;max-width:380px;background:#21262d;color:#c9d1d9;border:1px solid #30363d;border-radius:5px;padding:5px 8px;font-size:12px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
 #sec-makro .mkfred .sub{flex:1 1 100%}
 #sec-makro .mkfig{margin:14px 0 4px} #sec-makro .mkkopf{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;margin-bottom:2px}
 #sec-makro .mkkopf b{color:#e6edf3;font-size:12px} #sec-makro .mkkopf .mktab{margin-left:auto;padding:2px 8px;font-size:11px}
 #sec-makro .mkleg{margin:2px 0 4px} #sec-makro .mkquelle{font-size:10px;color:#6e7681;margin-top:3px}
 #sec-makro .mkleer{padding:18px 8px;border:1px dashed #21262d;border-radius:6px}
 #sec-makro .mkscroll,#sec-makro .mktabelle{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #sec-makro .mktabelle{max-height:420px;overflow-y:auto}
 #sec-makro .mksatz{font-size:12px;color:#c9d1d9;line-height:1.5;margin:6px 0 8px}
 #sec-makro .lz{display:block;font-size:10px;color:#8b949e;white-space:normal;max-width:300px;line-height:1.35;margin-top:1px}
 #sec-makro table.mkzonen td{vertical-align:top}
 #sec-makro .mkbalken{position:relative;display:inline-block;width:110px;height:10px;vertical-align:middle}
 #sec-makro .mkspur{position:absolute;left:0;right:0;top:4px;height:2px;background:#30363d;border-radius:1px}
 #sec-makro .mkmitte{position:absolute;left:50%;top:1px;width:1px;height:8px;background:#30363d}
 #sec-makro .mkpunkt{position:absolute;top:1px;width:8px;height:8px;border-radius:50%;background:#c9d1d9;box-shadow:0 0 0 2px #0d1117}
 #sec-makro .mkpz{font-variant-numeric:tabular-nums;color:#c9d1d9;font-size:11px}
 #sec-makro .mkh3{font-size:12px;color:#e6edf3;margin:14px 0 4px} #sec-makro .mkdetails{margin:6px 0}
 #sec-makro .mkgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));column-gap:18px;margin-bottom:8px} #sec-makro .mkgrid .mkfig{margin:10px 0 2px;min-width:0}
 #sec-makro .mkgrid .mkkopf b{order:1;flex:1 1 0;min-width:0} #sec-makro .mkgrid .mkkopf .mktab{order:2}
 #sec-makro .mkgrid .mkkopf .sub{order:3;flex-basis:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
 @media (max-width:700px){ #sec-makro .mkgrid .mkkopf .sub{white-space:normal} }
 #sec-makro .mkkarten{display:none} #sec-makro .mkkarte{border-bottom:1px solid #161b22;padding:7px 0}
 #sec-makro .mkk1{display:flex;justify-content:space-between;gap:10px;align-items:baseline}
 #sec-makro .mkk1 b{font-weight:500;color:#c9d1d9;font-size:12px} #sec-makro .mkk1 span{font-variant-numeric:tabular-nums;color:#e6edf3;white-space:nowrap}
 #sec-makro .mkk2{display:flex;gap:8px;align-items:center;margin-top:3px;font-size:11px;color:#8b949e}
 @media (max-width:700px){ #sec-makro .mkzonenwrap{display:none} #sec-makro .mkkarten{display:block} #sec-makro .mkkopf .mktab{padding:4px 10px} }
</style></head><body>
<div class="top">
 <div class="titlerow">
  <h1>Hyperliquid — Liquidationscluster</h1>
  <div class="bar" style="margin:0">
   <label class="lbl" for="coin">Coin</label><select id="coin"></select>
   <label class="lbl" for="src">Quelle</label>
   <select id="src" title="Datenquelle für alle Abschnitte">
    <option value="hl" selected>Hyperliquid Daten</option>
    <option value="bnc">Binance Daten</option>
    <option value="fusion">Data Mix Fusion (Hyperliquid + Binance + Crypto.com)</option></select>
   <button onclick="load()" title="alle Daten jetzt neu laden">Neu laden</button>
  </div>
 </div>
 <nav class="nav">
  <a href="#sec-chart">Chart</a><a href="#sec-signal">Konfluenz</a><a href="#sec-forecast">AI-Prognose</a><a href="#sec-familien">Treiberfamilien</a><a href="#sec-labor">TradeLabor</a><a href="#sec-makro">Makro</a><a href="#sec-orders">Orders &amp; Stops</a>
  <a href="#sec-heat">Heatmap</a><a href="#sec-depth">Momentaufnahme</a><a href="#sec-whales">Wale</a><a href="#sec-leaderboard">Leaderboard</a><a href="#sec-lbact">Käufe/Verkäufe 3 T</a><a href="#sec-lbact48">48 h</a><a href="#sec-pool">Aktive Profis</a>
  <a href="#sec-update" class="dim">Update</a><a href="#sec-debug" class="dim">Debug</a><a href="#sec-system" class="dim">System</a>
  <a class="dim" onclick="toggleAll()" style="margin-left:auto" title="alle Abschnitte ein- oder ausklappen">alle ▾/▸</a>
 </nav>
</div>
<div class="sub" style="margin:8px 0 0">Echte Positionen aus der Kette, keine Schätzung. Kurs und Cluster aktualisieren sich automatisch;
 Tippen oder Fahren über eine Grafik zeigt Werte und Fadenkreuz. Jeder Abschnitt lässt sich am Titel einklappen, „ⓘ" zeigt die Erklärung.</div>

<div class="kpi" id="kpi"></div>

<div class="panel" id="sec-chart" data-sec="chart">
 <h2 class="sech" onclick="toggleSec('chart')"><span class="num">1</span><span class="ttl">Live-Chart — Kurs mit aktuellen Liquidationsmarken</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('chart')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="tf">Raster</label>
  <select id="tf"><option value="1|120">1 min · 2 h</option>
   <option value="5|720" selected>5 min · 12 h</option>
   <option value="15|2880">15 min · 2 Tage</option>
   <option value="60|10080">1 h · 7 Tage</option>
   <option value="240|43200">4 h · 30 Tage</option>
   <option value="1440|525600">1 Tag · 1 Jahr</option>
   <option value="10080|2628000">1 Woche · 5 Jahre</option></select>
  <button id="fvgtoggle" class="tog on" title="Fair Value Gaps ein- oder ausblenden">FVG an</button>
  <label class="lbl" for="fvg" title="Fair Value Gaps, die kleiner sind als dieser Anteil des Kurses, gelten als Rauschen und werden nicht gezeichnet">FVG-Mindestgröße</label>
  <select id="fvg" title="Lücken kleiner als dieser Anteil des Kurses werden ignoriert"><option value="0.0005" selected>0,05 % des Kurses</option>
   <option value="0.001">0,1 % des Kurses</option>
   <option value="0.0025">0,25 % des Kurses</option></select>
 </div>
 <div class="sub help" style="display:none">Waagerechte Linien sind Preisniveaus, auf denen gehebelte
  Positionen zwangsliquidiert würden. Rechts steht je Linie das Notional und der
  Abstand zum Kurs.</div>
 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Short-Liquidationen (über dem Kurs)</span>
  <span><i class="sw" style="background:#e04b4b"></i>Long-Liquidationen (unter dem Kurs)</span>
  <span>durchgezogen = ab halbem Stundenvolumen · gestrichelt = darunter</span>
  <span><i class="sw" style="background:rgba(57,255,20,.35);border:1px solid #39ff14"></i>bullisches FVG</span>
  <span><i class="sw" style="background:rgba(224,75,75,.35);border:1px solid #e04b4b"></i>bärisches FVG</span>
  <span>kräftig = offen · blass = gefüllt</span>
  <span title="Ein FVG ist die Lücke zwischen dem Hoch von Kerze 1 und dem Tief von Kerze 3 (bullisch) bzw. umgekehrt. Die FVG-Mindestgröße ist diese Lücke als Anteil des Kurses: 0,05 % bei 80.000 sind 40 USD. Kleinere Lücken werden nicht gezeichnet.">FVG-Mindestgröße = Lücke als Anteil des Kurses ⓘ</span>
  <span><i class="sw" style="background:#39d3ff"></i>Support</span>
  <span><i class="sw" style="background:#c678dd"></i>Resistance</span>
  <span><i class="sw" style="background:#8b949e"></i>Take-Profits</span>
  <span><i class="sw" style="background:#e04b4b"></i>/<i class="sw" style="background:#3ba55d"></i> Stops (gepunktet)</span>
  <span><i class="sw" style="background:#ff9f43"></i>Binance-Liquidation ▲▼</span>
  <span><i class="sw" style="background:#ff3b6b"></i>HL-Liquidation ▲▼ (Binance/Fusion)</span>
 </div>
 <canvas id="chart" height="400" data-hm="340"></canvas>
 <div class="sub" id="chartinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-signal" data-sec="signal">
 <h2 class="sech" onclick="toggleSec('signal')"><span class="num">2</span><span class="ttl">Konfluenz — welche Faktoren zeigen in dieselbe Richtung?</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Eine Zählung sichtbarer Faktoren, keine Prognose. Jede Regel steht
  daneben, damit du sie prüfen und verwerfen kannst. Die zugrunde liegende These —
  Cluster ziehen, Lücken werden gefüllt — ist genau das, was der Recorder erst noch
  belegen muss. <b>Nicht validiert.</b></div>

 <div id="signalbox" style="margin-top:8px;padding:10px 12px;background:#161b22;
  border:1px solid #21262d;border-radius:6px;font-size:12px;line-height:1.6"></div>
 <div id="konfbilanz" class="sub" style="margin-top:6px"></div>

 </div></div>

<div class="panel" id="sec-forecast" data-sec="forecast">
 <h2 class="sech" onclick="toggleSec('forecast')"><span class="num" style="background:#3b2f6e;color:#c9b8ff">AI</span><span class="ttl">AI-Prognose — kalkulierter Pfad für 7 Tage, Kauf- und Verkaufspreis für die nächsten 4–12 Stunden</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('fcchart')" title="Prognose als PNG exportieren">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
 <div id="ankerbox" class="sub" style="margin:4px 0 8px"></div>
 <div class="sub help" style="display:none">Alle 15 Minuten werden sämtliche gesammelten Daten zu einer Prognose verrechnet — ein
  transparentes Modell, kein Orakel. <b>Regime und Drift:</b> Lage zu MA 200 Tage und MA 50 Wochen, 60-Minuten-Trend, RSI,
  Drift der letzten Tage. <b>Richtungsdruck:</b> nur direktionale Konten — direktionale Wale, direktionales Smart Money,
  Käufe und Verkäufe direktionaler Leaderboard-Konten der letzten 24 h, Top-20-Trend, dazu Taker-Flow aller Börsen, Funding
  (gegen die Menge) und ETF-Flows. <b>Magneten:</b> Liquidationscluster ziehen, Limit-Wände bremsen, ein gekreuzter
  Stop-Auslöser wird zur Kaskade. <b>Pfad:</b> Stunde für Stunde bis 7 Tage, das Band ist die realisierte Volatilität mal
  Wurzel der Zeit — je weiter, desto breiter, so ehrlich ist die Unsicherheit. <b>Kauf- und Verkaufspreis:</b> im Fenster
  4–12 h, an Wänden und Clustern ausgerichtet; bei klarem Gegendruck wird abgeraten. Jede Prognose wird gespeichert und
  nach 4 und 24 Stunden gegen den echten Kurs geprüft — die Trefferquote steht unten und ist der ehrlichste Wert auf der Seite.</div>
 <div id="fcguide" class="kpi" style="margin:6px 0"></div>
 <div id="fclive" class="sub" style="margin:0 0 6px"></div>
 <div class="leg"><span><i class="sw" style="background:#fff"></i>Kurs 48 h</span><span><i class="sw" style="background:#c9b8ff"></i>Prognosepfad (Ensemble, gestrichelt; dünn = reines Modell)</span><span><i class="sw" style="background:rgba(201,184,255,0.18)"></i>Unsicherheitsband</span><span><i class="sw" style="background:#3ba55d"></i>Kaufpreis</span><span><i class="sw" style="background:#e04b4b"></i>Verkaufspreis</span><span>Magneten: Liq-Cluster · Wände</span></div>
 <div class="bar" style="margin:4px 0 6px">
  <label class="lbl">Ansicht</label>
  <button class="tog off fcz" data-span="24">24 h</button><button class="tog off fcz" data-span="72">3 T</button><button class="tog off fcz" data-span="216">alles</button>
  <button class="tog off" id="fcprev" title="nach links">◀</button><button class="tog off" id="fcnext" title="nach rechts">▶</button><button class="tog off" id="fcnow" title="zum Jetzt">jetzt</button>
  <span class="sub" style="margin:0" id="fcview"></span>
 </div>
 <canvas id="fcchart" height="300" data-hm="260" style="cursor:grab;touch-action:pan-y"></canvas>
<div id="verlauf" style="margin-top:8px"></div>
 <div id="fcdrivers" style="margin-top:8px"></div>
 <div id="fclearn" style="margin-top:8px"></div>
 <div class="sub" id="fcinfo"></div>
 </div>
</div>

<div class="panel" id="sec-familien" data-sec="familien">
 <h2 class="sech" onclick="toggleSec('familien')"><span class="num" style="background:#1f3a2e;color:#7ee787">TF</span><span class="ttl">Treiberfamilien — Parallelbetrieb, wirkt nicht auf die AI-Prognose</span></h2>
 <div class="body">
 <div class="sub">Ähnliche Treiber sind zu Familien zusammengefasst; jede Familie wird auf ihrem eigenen Horizont gegen den Zufall
  geprüft, je Coin getrennt. Gewicht bekommt eine Familie erst nach zwei Wochen in Folge mit belegtem Vorsprung — bis dahin
  nennt die Familien-Prognose die Basisrate. „Stärke“ sagt voraus, ob eine große Bewegung kommt, nicht wohin. „Profi-Flow“
  ist der Netto-Handel der Darwin-Liste und wird ab jetzt aufgezeichnet.</div>
 <div id="famtab" class="sub" style="margin-top:6px">lädt …</div>
 </div>
</div>

<div class="panel" id="sec-labor" data-sec="labor">
 <h2 class="sech" onclick="toggleSec('labor')"><span class="num" style="background:#3a2f12;color:#e3b341">TL</span><span class="ttl">TradeLabor — simulierter Handel mit allen Daten, live (kein echtes Geld)</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Simulierter Handel: kein echtes Geld, keine Order an eine Börse. Jede Strategie handelt je Coin (BTC, ETH, ZEC, HYPE,
  seit 29.09. auch XMR) ein eigenes Konto mit 10.000 USD je Trade. Die Regeln werden beim ersten Start eingefroren (Kennung Name@Prüfsumme) — jede Änderung
  ergibt eine neue Kennung mit eigener Bilanz, nichts wird rückwirkend angepasst: ein echter Vorwärtstest. Ausführung bewusst vorsichtig
  gerechnet: Markt-Orders zum Briefkurs plus Marktauswirkung aus der Buchtiefe (Orderbuch alle 5 s), Limit-Orders nur gefüllt, wenn der Kurs
  durch den Preis läuft; Gebühren Taker 0,045 %, Maker 0,015 % (XMR als HIP-3-Markt mit Betreiberanteil: doppelt); Funding stündlich; liegen
  Stop und Ziel in derselben Minute, gilt der Stop.
  Zwei Vorlagen werden kopiert, nach derselben Regel und jeweils mit Gegenprobe: „Darwin-Liste live folgen“ (Aktive Profis) und seit 23.39
  „Elite live folgen“ (die Elite des Coins) — eröffnet ein Konto netto mindestens 10.000 USD binnen 15 min, steigt die Strategie mit ein und
  folgt ihm beim Schließen wieder hinaus.
  Seit 23.40 laufen zwei Grid-Bots mit, „Grid Long“ und das Spiegelbild „Grid Short“: Range aus den Kursen der letzten 24 h (10.–90. Perzentil),
  4–12 Stufen mit mindestens 0,2 % Abstand, 10.000 USD je Coin auf die Stufen verteilt — jede Stufe hält ein Los oder eine Einstiegs-Order, jedes
  Los verkauft (Short: kauft zurück) eine Stufe weiter. Aufgebaut wird nur ohne Trend gegen das Grid, nachgeführt stündlich. Eine starke Bewegung
  in Grid-Richtung (≥ 3 σ in 5 oder 15 min in der günstigen Hälfte, Squeeze bzw. Kaskade, Ausbruch aus der Range) sitzen sie aus: keine Verkäufe,
  Trailing-Stop 1,5 σ(1 h) vom Extrem. Dagegen: Notausstieg zum Marktpreis und Pause (4 h, nach Wiederholung binnen 24 h 12 bzw. 24 h). Summe und
  Blöcke der Grids zählen den Bestand mit (Tagesergebnis nach Bestandswert) — sonst sähe ein Grid durch viele kleine Gewinne besser aus, als es ist.
  Zwei Kontrollen laufen mit: „Zufall“ zeigt, was Gebühren und Zufall kosten, „Halten Long“ den Markt ohne jedes Signal. Bei über 30 Strategien
  sehen einige zufällig gut aus — „Glück“ rechnet das heraus. t, Glück und Stufen zählen <b>Blöcke</b>: Trades einer Strategie, die im selben
  Zeitblock ihres Horizonts eröffnet wurden (meist dasselbe Signal in mehreren Coins), sind eine Beobachtung. „bewährt“ erst ab 30 Blöcken,
  t ≥ 3, beide Hälften positiv und 14 Tagen.
  Die Hebel-Wahl rechnet alle Ergebnisse auf 3×, 5× oder 10× hoch, mit Liquidation, wenn der Rückgang im Trade 90 % der Marge erreicht.
  Das Labor wirkt auf nichts anderes: keine Prognose, kein Treiber, kein API-Gewicht. Takt 15 s auf dem Pi; die Seite fragt nur, solange
  dieser Abschnitt offen ist.</div>
 <div id="labkpi" class="kpi" style="margin:8px 0">lädt …</div>
 <div id="labtabs"></div>
 <div id="labbody"></div>
 </div>
</div>

<div class="panel" id="sec-makro" data-sec="makro">
 <h2 class="sech" onclick="toggleSec('makro')"><span class="num" style="background:#13304a;color:#79c0ff">MK</span><span class="ttl">Makro — wo steht der Markt im Zyklus? Monate bis Jahre, Tagesdaten</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Mittel- und langfristige Lage statt kurzfristiger Signale (Recherche vom 05.10.2026: RECHERCHE_Makro_Chart_05-10-2026.md).
  Gezeigt werden <b>Positionen</b>: Bänder im Kurschart (Realized Price, 200-Wochen-MA, Power-Law-Fair-Value, Kurzfrist-Kostenbasis,
  Stromkosten eines Miners) und Perzentile der eigenen Historie, am Tag t nur mit Daten bis t gerechnet. Feste Schwellen aus 2013–2021
  (MVRV 3,7 oder 1, NUPL 0,75, Puell 4, Pi Cycle …) fehlen bewusst: Die Ausschläge schrumpfen seit 2011, 2025/26 haben sie oben und unten
  versagt. Makro (Liquidität, Zinsen, Dollar) steht als Kulisse mit rollierender Korrelation daneben, nie als Zeitgeber.
  Quellen frei: Coin Metrics Community, FRED, alternative.me, DefiLlama, Blockchain.com, Deribit, Binance, Farside, BGeometrics (letzte 4 Jahre,
  15 Abrufe am Tag). Abruf im Hintergrund nach Plan (Tagesdaten), gespeichert in einer eigenen Datei makro.db neben der Hauptdatenbank
  — hl_liq.db bleibt unberührt. Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor. Debug: „Makro: Stand und Quellen“.</div>
 <div id="mkbar"></div>
 <div id="mkbody" class="sub">lädt …</div>
 </div>
</div>

<div class="panel" id="sec-orders" data-sec="orders">
 <h2 class="sech" onclick="toggleSec('orders')"><span class="num">3</span><span class="ttl">Wartende Orders und Stops — Konten ab 250k USD</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('stops')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Trigger-Orders stehen nicht im Orderbuch: Sie werden erst am Auslösepreis zu
  Market-Orders — wie Liquidationen. Sell-Stops unter dem Kurs lösen Verkaufskaskaden aus,
  Buy-Stops darüber Kaufkaskaden. Take-Profits und ruhende Limit-Orders wirken gegenteilig,
  sie absorbieren. Abgefragt werden alle Konten ab 250k USD, gestaffelt nach Größe: ab 20 Mio
  alle 10 Minuten, 5–20 Mio alle 45 Minuten, 1–5 Mio alle 3 Stunden, darunter alle 6 Stunden —
  so passt es ins API-Budget. Gezeigt wird je Konto der jüngste Stand. Fahren oder Tippen zeigt
  ein Fadenkreuz mit dem Preis.</div>

 <div class="leg">
  <span><i class="sw" style="background:#e04b4b"></i>Sell-Stop (Verkaufskaskade)</span>
  <span><i class="sw" style="background:#3ba55d"></i>Buy-Stop (Kaufkaskade)</span>
  <span><i class="sw" style="background:#39d3ff"></i>Limit-Kauf (Kaufwand)</span>
  <span><i class="sw" style="background:#c678dd"></i>Limit-Verkauf (Verkaufswand)</span>
  <span><i class="sw" style="background:#8b949e"></i>Take-Profit</span>
 </div>
 <canvas id="stops" height="720" data-hm="560"></canvas>
 <div class="sub" id="stopsinfo"></div>
 <div id="stopslevels" style="margin-top:8px;overflow-x:auto"></div>

 </div></div>

<div class="panel" id="sec-heat" data-sec="heat">
 <h2 class="sech" onclick="toggleSec('heat')"><span class="num">4</span><span class="ttl">Heatmap — Clusterentwicklung über die Zeit</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('heat')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="hours">Zeitraum</label>
  <select id="hours"><option value="6">6 h</option><option value="24" selected>24 h</option>
   <option value="72">3 Tage</option><option value="168">7 Tage</option></select>
 </div>
 <div class="sub help" style="display:none">Waagerecht die Zeit, senkrecht der Preis. Die Farbe zeigt den
  Rang einer Zelle unter allen anderen, nicht den Absolutwert — sonst würde ein
  einzelner Großcluster die Skala verzerren.</div>
 <div class="bar">
  <label class="lbl" for="thr">Liquiditäts-Schwelle</label>
  <input type="range" id="thr" min="0" max="97" value="70" style="width:190px">
  <span class="sub" id="thrval" style="min-width:92px">Perzentil 70</span>
 </div>
 <div class="leg">
  <span>schwach<i class="grad" style="margin:0 6px;display:inline-block"></i>stark</span>
  <span><i class="sw" style="background:#fff"></i>Kursverlauf</span>
  <span><i class="sw" style="background:#ff3b6b"></i>eingetretene Liquidation (HL)</span>
  <span id="bncliqleg" style="display:none"><i class="sw" style="background:#ff9f43"></i>Binance-Liquidationen ab
   <select id="bncliqmin" style="font-size:12px;padding:1px 4px;margin-left:4px"><option value="5">5 Mio</option><option value="10">10 Mio</option><option value="20" selected>20 Mio</option><option value="50">50 Mio</option><option value="100">100 Mio</option></select>
   je 10 min und Preisstufe</span>
 </div>
 <canvas id="heat" height="430" data-hm="360"></canvas>
 <div class="sub" id="heatinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-depth" data-sec="depth">
 <h2 class="sech" onclick="toggleSec('depth')"><span class="num">5</span><span class="ttl">Momentaufnahme — Cluster rund um den aktuellen Kurs</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('depth')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Senkrecht der Preis, Balkenlänge das Notional. Die gestrichelte
  Linie markiert das halbe Stundenvolumen: Cluster links davon werden vom Markt
  eher geschluckt, ohne den Kurs zu bewegen.</div>

 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Short-Liquidationen</span>
  <span><i class="sw" style="background:#e04b4b"></i>Long-Liquidationen</span>
  <span><i class="sw" style="background:#00e5ff"></i>aktueller Kurs</span>
 </div>
 <canvas id="depth" height="430" data-hm="360"></canvas>
 <div class="sub" id="depthinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-whales" data-sec="whales">
 <h2 class="sech" onclick="toggleSec('whales')"><span class="num">6</span><span class="ttl">Wale — Konten ab 10 Mio. USD Gesamtwert</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('whalechart')" title="Exposure-Chart als PNG exportieren">⤓ Chart</a><a class="help exp" onclick="event.stopPropagation();exportWhaleTable()" title="Wal-Liste mit allen Positionen als PNG exportieren (bei sehr langen Listen mehrere Teile)">⤓ Liste</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Oben die Netto-Ausrichtung aller Wale (grün = mehr Long, rot = mehr
  Short) gegen den Kurs. Darunter jede aktuell offene Wal-Position mit Einstieg,
  Liquidationspreis und Abstand dorthin — über alle Coins, der gewählte ist hervorgehoben.
  Ganz unten die letzten Änderungen im gewählten Coin. Der Blockkopf je Wallet nennt, wenn
  bekannt, wer dahintersteht: aus <code>labels.json</code> (eigene Pflege, Vorrang), dem
  Hyperliquid-Leaderboard (selbst gewählte Namen), Vault-Namen, Etherscan- und Arbiscan-Tags;
  dazu die Verhaltensklasse aus unseren Daten (Hedge, Market-Maker-Muster, direktional) und Links
  zu HypurrScan, Arbiscan und Arkham. „unbekannt" heißt: keine Quelle kennt einen Namen — das ist bei
  den meisten Walen so. Hedge heißt: mehrere Coins, eine Seite, niedriger Hebel — typisch für
  Market Maker und Basis-Trader, die Spot oder Optionen absichern, nicht für Wetten.
  <b>Vorsicht bei der Deutung:</b> Ein großer Short kann eine abgesicherte
  Spot-Position sein und sagt dann nichts über die Erwartung des Halters.</div>

 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Long-Exposure</span>
  <span><i class="sw" style="background:#e04b4b"></i>Short-Exposure</span>
  <span><i class="sw" style="background:#fff"></i>Kurs</span>
  <span>▲ öffnet / stockt auf &nbsp; ▼ reduziert / schließt</span>
 </div>
 <canvas id="whalechart" height="260" data-hm="220"></canvas>
 <div id="whaletable" style="margin-top:10px;overflow-x:auto"></div>
 <div id="whaleevents" class="sub" style="margin-top:8px"></div>
 <div id="bncmetrics" style="display:none;margin-top:10px">
  <div class="leg"><span><i class="sw" style="background:#58a6ff"></i>Open Interest (USD)</span>
   <span><i class="sw" style="background:#d29922"></i>Long/Short-Verhältnis Konten (global)</span>
   <span><i class="sw" style="background:#c678dd"></i>Long/Short Top-Trader (Position)</span>
   <span><i class="sw" style="background:#3ba55d"></i>Taker Kauf/Verkauf</span></div>
  <canvas id="metricschart" height="260" data-hm="220"></canvas>
  <div class="sub" id="metricsinfo"></div>
 </div>
</div>

<div class="warn" id="warn">
 </div></div>
<div class="panel" id="sec-leaderboard" data-sec="leaderboard">
 <h2 class="sech" onclick="toggleSec('leaderboard')"><span class="num">7</span><span class="ttl">Leaderboard Top 20 — die profitabelsten Konten und ihre Positionen</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('lbchart')" title="Trend-Chart als PNG exportieren">⤓ Chart</a><a class="help exp" onclick="event.stopPropagation();exportLbTable()" title="Leaderboard-Liste als PNG exportieren">⤓ Liste</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Die 20 Konten mit dem höchsten 30-Tage-PnL im Hyperliquid-Leaderboard (Kontowert ab 500k),
  ihre offenen Positionen und der unrealisierte PnL — vom Recorder alle 10 Minuten abgefragt. Das Chart zeigt,
  wie sich die Positionierung dieser Konten im gewählten Coin über die Zeit verschiebt: Long-Wert (grün) und
  Short-Wert (rot) je Stunde, dazu der Netto-Wert als Linie — einmal pro Stunde in <code>lb_trend</code>
  gespeichert, für Top 20 und Top 50, je Coin. Profitabel in den letzten 30 Tagen heißt nicht profitabel morgen;
  die Aussage liegt in der Verschiebung, nicht im Stand.</div>
 <div class="leg"><span><i class="sw" style="background:#3ba55d"></i>Long-Wert Top 20</span><span><i class="sw" style="background:#e04b4b"></i>Short-Wert Top 20</span><span><i class="sw" style="background:#58a6ff"></i>netto (Linie)</span><span><i class="sw" style="background:#fff"></i>Kurs</span></div>
 <canvas id="lbchart" height="240" data-hm="200"></canvas>
 <div class="sub" id="lbinfo"></div>
 <div id="lbtable" style="margin-top:8px"></div>
 </div>
</div>

<div class="panel" id="sec-lbact" data-sec="lbact">
 <h2 class="sech" onclick="toggleSec('lbact')"><span class="num">8</span><span class="ttl">Leaderboard — Käufe und Verkäufe der letzten 3 Tage (Perp und Spot)</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Alle Fills der Top-50-Konten der letzten 3 Tage, stündlich vom Recorder geholt (<code>userFillsByTime</code>), Perp und Spot.
  Kaufdruck = Open Long, Close Short und Spot-Käufe; Verkaufsdruck = Open Short, Close Long und Spot-Verkäufe. Die
  Übersicht je Coin zählt Konten und Notional beider Seiten, die Tabelle darunter die größten Einzeltrades im gewählten Coin
  mit der Kursentwicklung seit dem Trade — aus Sicht des Traders: positiv heißt, der Trade liegt im Gewinn. Spot-Bestände
  der Top-Konten stehen ganz unten (UBTC = BTC, UETH = ETH, USOL = SOL). Ein Verkauf kann Gewinnmitnahme, Absicherung oder
  Ausstieg sein — die Liste zeigt das Verhalten, nicht die Absicht.</div>
 <div id="lbactcoins"></div>
 <div id="lbactinfo" class="sub" style="margin-top:6px"></div>
 <div id="lbactbig" style="margin-top:8px"></div>
 <div id="lbactspot" style="margin-top:8px"></div>
 </div>
</div>

<div class="panel" id="sec-lbact48" data-sec="lbact48">
 <h2 class="sech" onclick="toggleSec('lbact48')"><span class="num">9</span><span class="ttl">Leaderboard — Käufe und Verkäufe der letzten 48 Stunden</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('lbact48chart')" title="Chart als PNG exportieren">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Dieselben Fills wie in Abschnitt 8, aber nur die letzten 48 Stunden — für ganz aktuelle Kauf- und
  Verkaufssignale. Das Chart zeigt je Stunde den Kaufdruck (grün, nach oben) und Verkaufsdruck (rot, nach unten) der
  Top-50-Konten im gewählten Coin, die blaue Linie den aufgelaufenen Netto-Wert, weiß den Kurs. Darunter die Übersicht je
  Coin und alle Trades ab 50k im gewählten Coin, neueste zuerst, mit der Kursentwicklung seit dem Trade aus Sicht des Traders.
  Der Recorder holt neue Fills stündlich — der jüngste Fill kann bis zu einer Stunde alt sein.</div>
 <div class="leg"><span><i class="sw" style="background:#3ba55d"></i>Kaufdruck je Stunde</span><span><i class="sw" style="background:#e04b4b"></i>Verkaufsdruck je Stunde</span><span><i class="sw" style="background:#58a6ff"></i>netto aufgelaufen</span><span><i class="sw" style="background:#fff"></i>Kurs</span></div>
 <canvas id="lbact48chart" height="220" data-hm="190"></canvas>
 <div id="lbact48info" class="sub"></div>
 <div id="lbact48coins" style="margin-top:8px"></div>
 <div id="lbact48big" style="margin-top:8px"></div>
 </div>
</div>

<div class="panel" id="sec-pool" data-sec="pool">
 <h2 class="sech" onclick="toggleSec('pool')"><span class="num">10</span><span class="ttl">Aktive Profis — Darwin-Liste mit belegtem Timing</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Vorschau auf das Vorhaben „Aktive Profis": Der Kandidatenpool (Kontowert ≥ 1 Mio, Tagesumsatz ≥ 500k) wird stündlich aus
  der vollständigen Leaderboard-Datei von Hyperliquid gefüllt. Gezeigt werden die 20 Pool-Konten mit der besten ROI laut Hyperliquid — einzahlungsbereinigt,
  aber OHNE die Prüfungen aus Phase 2 (2–150 gebündelte Trades am Tag, belegtes Timing der Ein- und Ausstiege aus Wal-, Leaderboard- und
  Pool-Positionen, Bot-Marke). Umschlag = Wochenumsatz
  je Kontowert: unter 0,5× eher Halter, über 50× Hochfrequenz. Die Liste ist Beobachtung, kein Signal.</div>
 <div id="profistab"></div>
 <div class="sub" style="margin:12px 0 6px"><b>Pool (Vorschau nach Hyperliquids ROI)</b> — Rang nach
  <select id="poolwin" style="font-size:12px;padding:1px 4px"><option value="roi_7d" selected>ROI 7 Tage</option><option value="roi_1d">ROI 1 Tag</option><option value="roi_30d">ROI 30 Tage</option><option value="pnl_7d">PnL 7 Tage (absolut)</option></select>
  · Anzahl <select id="pooln" style="font-size:12px;padding:1px 4px"><option value="20">20</option><option value="100">100</option><option value="500" selected>500</option></select>
  <span id="poolinfo"></span></div>
 <div id="pooltab"></div>
 </div>
</div>
<div class="panel" id="sec-network" data-sec="network">
 <h2 class="sech" onclick="toggleSec('network')"><span class="ttl">Netzwerkstatus &mdash; Abfragen, Zeitplan, Grenzen</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erkl&auml;rung ein-/ausblenden">&#9432;</a><a class="help exp" onclick="event.stopPropagation();exportChart('netchart')" title="Chart als PNG">&#8595;</a><span class="chev">&#9662;</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Alles, was ins Netz geht, an einer Stelle. Das Chart zeigt das verbrauchte
  API-Gewicht je Minute, getrennt nach Verbraucher, gegen die Grenze von 1.200 je Minute und IP-Adresse.
  Darunter der Zeitplan: was wann zuletzt lief, wie lange es dauerte, was dabei herauskam und wann es
  wieder dran ist. Fehler werden mit Aufgabe, Zeitpunkt und Meldung benannt.</div>
<canvas id="netchart" height="200" data-hm="180"></canvas>
<div id="netlimit" class="sub" style="margin:8px 0 2px"></div>
<div class="sub" style="margin:10px 0 2px"><b>Datenströme der Fremdbörsen</b> — gespeicherte Zeilen je Segment (Liquidationen, Kennzahlen, Buch, Kerzen), eine Spur je Börse mit eigener Skala; kein Gewichtsbudget, aber ein Fluss, der abreißen kann · Fenster
 <select id="netextwin" style="font-size:12px;padding:1px 4px"><option value="30" selected>30 min (Minutenbalken)</option><option value="360">6 h (15-min-Balken)</option><option value="720">12 h (15-min-Balken)</option></select>
 <a class="help exp" onclick="event.stopPropagation();exportChart('netext')" title="Chart als PNG exportieren">⤓</a></div>
<canvas id="netext" height="320" data-hm="300"></canvas>
<div id="netextinfo" class="sub" style="margin:6px 0 2px"></div>
<div id="netquellen" style="overflow-x:auto"></div>
<div id="netjobs" style="overflow-x:auto"></div>
<div id="neterr"></div>
 </div>
</div>

<div class="panel" id="sec-update" data-sec="update">
 <h2 class="sech" onclick="toggleSec('update')"><span class="ttl">Aktualisierung</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Lädt das Archiv von GitHub und spielt es mit <code>update.py</code> ein: Dienste stoppen,
  Dateien ersetzen, Syntaxprüfung mit Rückrollen, Units erneuern, Dienste starten. Das Dashboard
  ist dabei etwa eine Minute nicht erreichbar; die Seite wartet und lädt danach selbst neu.
  Braucht <code>sudo.txt</code> (Rechte 600) im Projektordner.</div>

 <button id="updbtn" class="tog off" style="margin-top:8px;min-width:220px">Update von GitHub einspielen</button>
 <button id="restbtn" class="tog off" style="margin-top:8px;min-width:220px" title="Spielt die Projektdateien aus dem jüngsten Ordner updates/vor_* zurück (die Sicherung vor dem letzten Update). Datenbanken und Laufzeitzustand werden nicht berührt. Der jetzige Stand wird vorher selbst gesichert.">Letztes Backup wiederherstellen</button>
 <div class="sub" id="restinfo" style="margin-top:4px"></div>
 <pre id="updlog" style="display:none;margin-top:8px;background:#0d1117;border:1px solid #21262d;border-radius:6px;
   padding:10px;font-size:11px;max-height:320px;overflow:auto;white-space:pre-wrap"></pre>
</div>

<div class="panel" id="sec-debug" data-sec="debug">
 <h2 class="sech" onclick="toggleSec('debug')"><span class="ttl">Debug — Diagnoselauf mit Terminal-Ausgabe</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Startet eines der Diagnoseskripte oder liest ein Journal — als Dashboard-Benutzer, ohne sudo,
  aus einer festen Liste (kein freies Kommando). Die Ausgabe erscheint hier wie im Terminal; „Kopieren" legt sie mit
  Kopfzeile in die Zwischenablage, zum Einfügen in den Chat. Läufe mit Live-Abfragen (Leaderboard-Diagnose) brauchen
  bis zu einer Minute. Journale setzen voraus, dass der Benutzer sie lesen darf (Gruppe systemd-journal).</div>
 <div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="dbgselect">Lauf</label><select id="dbgselect"></select>
  <button id="dbgrun" class="tog off">Ausführen</button>
  <button id="dbgcopy" class="tog off" disabled title="Konsolenausgabe mit Kopfzeile in die Zwischenablage">Konsole kopieren</button>
  <button id="dbgsel" class="tog off" disabled title="alles markieren — danach „Kopieren" im Handy-Menü">Alles markieren</button>
  <button id="dbgsave" class="tog off" disabled title="als Textdatei speichern — lässt sich aus dem Download-Ordner teilen">Als Datei</button>
  <span id="dbgstate" class="sub" style="margin:0"></span>
 </div>
 <textarea id="dbgout" readonly spellcheck="false" style="display:block;width:100%;box-sizing:border-box;margin:0;background:#0d1117;border:1px solid #21262d;border-radius:6px;padding:10px;font:11px monospace;
   height:320px;resize:vertical;white-space:pre-wrap;color:#c9d1d9"></textarea>
 <div id="berichte" style="margin-top:10px"></div>
 </div>
</div>

<div class="panel" id="sec-system" data-sec="system">
 <h2 class="sech" onclick="toggleSec('system')"><span class="ttl">System — Temperatur und Zustand des Pi</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('syschart')" title="Verlauf als PNG exportieren">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Der Dashboard-Server misst alle 60 Sekunden CPU-Temperatur, Takt, Drosselungsflags der Firmware,
  Last, Speicher und Datenträger und hält 24 Stunden Verlauf. Die Seite fragt jede Minute nach. Der Pi 5 beginnt bei
  80 °C zu drosseln, bei 85 °C stärker — Dauerwerte über 70 °C unter Last sind ein Hinweis auf schlechte Kühlung.
  „Unterspannung" heißt: das Netzteil liefert zu wenig, das ist die häufigste Ursache für Instabilität.</div>
 <div class="kpi" id="syskpi" style="margin:6px 0"></div>
 <div class="leg"><span><i class="sw" style="background:#e3b341"></i>CPU-Temperatur (°C)</span><span><i class="sw" style="background:#58a6ff"></i>CPU-Last gesamt (%, rechte Skala 0–100)</span><span>Linien: 70 °C · 80 °C (Drosselung)</span></div>
 <canvas id="syschart" height="160" data-hm="140"></canvas>
 <div class="sub" id="sysinfo"></div>
 <div id="speicher" style="margin-top:12px"></div>
 </div>
</div>

<div id="taskbar" style="display:none;margin:6px 0;padding:8px 10px;background:#3d1d1d;border:1px solid #e04b4b;border-radius:6px;font-size:12px;color:#ffb4b4"></div>
<div id="tip"></div>

<div id="boot" style="background:#7a1f1f;color:#fff;padding:8px 14px;font:13px monospace;white-space:pre-wrap">Dashboard-Skript wird geladen … (bleibt diese Zeile stehen, ist das Skript nicht gestartet)
 </div></div>
<script>
// Eigenständiger Wächter: fängt auch Parse-Fehler des Hauptskripts, die dort selbst nichts mehr melden könnten
window.onerror=function(msg,src,line,col,err){
 var b=document.getElementById('boot'); if(!b) return;
 b.style.display='block';
 b.textContent='Skriptfehler: '+msg+' (Zeile '+line+', Spalte '+col+')'+(err&&err.stack?'\\n'+String(err.stack).split('\\n').slice(0,3).join('\\n'):'');
};
window.addEventListener('unhandledrejection',function(e){
 var b=document.getElementById('boot'); if(!b) return;
 b.style.display='block'; b.textContent='Ladefehler: '+(e.reason&&e.reason.message||e.reason);
});
</script>
<script>
document.getElementById('boot').style.display='none';   // Hauptskript läuft
const $=id=>document.getElementById(id);
// Fehler sichtbar machen: statt still in der Konsole zu landen, erscheinen sie oben auf der Seite
// Fehlerleiste: Verbindungsfehler verschwinden von selbst, sobald wieder Daten ankommen;
// Skriptfehler bleiben stehen (die gehen nicht von allein weg).
const ERR_LINES=[];                       // {kind:'fetch'|'script', text}
function renderErr(){
 let b=document.getElementById('errbar');
 if(!ERR_LINES.length){ if(b) b.remove(); return; }
 if(!b){b=document.createElement('div');b.id='errbar';
  b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:99;background:#7a1f1f;color:#fff;'
   +'padding:8px 14px;font:13px monospace;white-space:pre-wrap;border-bottom:2px solid #e04b4b';
  document.body.prepend(b);}
 b.textContent=ERR_LINES.slice(-6).map(l=>l.text).join('\\n');
}
function showErr(t, kind){
 kind=kind||(/keine Verbindung|Ladefehler|Failed to fetch|HTTP \\d/.test(t)?'fetch':'script');
 ERR_LINES.push({kind, text:new Date().toLocaleTimeString('de-DE')+'  '+t});
 while(ERR_LINES.length>6) ERR_LINES.shift();
 renderErr();
}
function clearFetchErr(){
 const had=ERR_LINES.some(l=>l.kind==='fetch'); if(!had) return;
 for(let i=ERR_LINES.length-1;i>=0;i--) if(ERR_LINES[i].kind==='fetch') ERR_LINES.splice(i,1);
 renderErr();
}
addEventListener('error',e=>showErr('Skriptfehler: '+e.message+' (Zeile '+e.lineno+')','script'));
addEventListener('unhandledrejection',e=>showErr('Ladefehler: '+(e.reason&&e.reason.message||e.reason),'fetch'));
// 23.35: dieselbe Adresse nicht doppelt anfragen, solange die erste Antwort noch aussteht (Takt 5 s, Antwort langsamer:
// vorher stapelten sich die Anfragen einer Seite auf dem Pi). Wer während des Wartens fragt, bekommt dieselbe Antwort.
const GET_LAUF={};
function getJSON(url){ if(GET_LAUF[url]) return GET_LAUF[url]; const p=getJSON1(url); GET_LAUF[url]=p; p.then(()=>{ delete GET_LAUF[url]; },()=>{ delete GET_LAUF[url]; }); return p; }
async function getJSON1(url){
 let r;
 try{ r=await fetch(url); }catch(e){ showErr(url.split('?')[0]+': keine Verbindung ('+e.message+')','fetch'); throw e; }
 if(!r.ok){ const t=await r.text(); showErr(url.split('?')[0]+': HTTP '+r.status+' '+t.slice(0,160),'fetch'); throw new Error('HTTP '+r.status); }
 try{ const j=await r.json(); clearFetchErr(); return j; }
 catch(e){ showErr(url.split('?')[0]+': keine gültige Antwort ('+e.message+')','fetch'); throw e; }
}
// Tab wieder sichtbar (Handy: Browser aus dem Hintergrund geholt): sofort neu laden statt
// auf den nächsten Takt zu warten -- und die Verbindungsfehler aus der Hintergrundzeit räumen sich
// mit der ersten erfolgreichen Antwort selbst weg.
document.addEventListener('visibilitychange',()=>{ if(!document.hidden){ setTimeout(()=>{ load(); loadHealth(); },200); } });
addEventListener('online',()=>{ setTimeout(load,500); });
let LAST=null, LAST_DEPTH=null, LAST_DATA=null, LAST_CHART=null, LAST_HEALTH=null, GEO={}, FVG_ON=true;
function SRC(){ const e=document.getElementById('src'); return e?e.value:'hl'; }
// Verhältnis x:1 als Kachel: Wert, darunter die Aufteilung in Prozent, Definition als Tooltip
function ratioTile(label, v, aWord, bWord, defn){
 // Verhältnis a:b -> "1,27 : 1" und darunter "56 % <aWord> · 44 % <bWord>"
 if(v==null||!isFinite(v)) return `<div title="${defn}"><span>${label}</span><b>—</b></div>`;
 const share=v/(1+v)*100, col=v>1.15?'#3ba55d':v<0.87?'#e04b4b':'#c9d1d9';
 return `<div title="${defn}"><span>${label}</span><b style="color:${col}">${(+v).toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2})} : 1`
  +`<span class="d">${share.toFixed(0)} % ${aWord} · ${(100-share).toFixed(0)} % ${bWord}</span></b></div>`;
}
const SRC_NAME={hl:'Hyperliquid',bnc:'Binance',fusion:'Data Mix Fusion'};
function setFvg(on){
 FVG_ON=on; const b=$('fvgtoggle'); if(!b) return;
 b.textContent=on?'FVG an':'FVG aus'; b.className='tog '+(on?'on':'off');
 if(LAST_CHART) drawChart(LAST_CHART);
}
function fillHealth(h){
 const b=$('kpi_backup'), d=$('kpi_db'); if(!b||!d) return;
 const bk=h.backup;
 if(!bk){ b.textContent='noch keines'; b.style.color='#d29922'; b.title='läuft 5 min nach Recorder-Start'; }
 else if(bk.ok){
  const age=(Date.now()/1000-bk.ts)/3600;
  b.textContent=hm(bk.ts); b.style.color=age<26?'#3ba55d':age<50?'#d29922':'#e04b4b';
  b.title=`vor ${age.toFixed(1)} h · ${(bk.size/1e6).toFixed(0)} MB · ${(bk.bars||0).toLocaleString('de-DE')} Bars · Ordner ${h.backup_dir||'?'}`;
  if(h.backup_free!=null&&h.db_size&&h.backup_free<h.db_size*1.1){
   b.textContent=hm(bk.ts)+' ⚠'; b.style.color='#e04b4b';
   b.title+=`\nPLATZ REICHT NICHT für das nächste Backup: ${(h.backup_free/1e9).toFixed(1)} GB frei, ${(h.db_size*1.1/1e9).toFixed(1)} GB nötig — das nächste wird übersprungen, das vorhandene bleibt.`; }
 } else {
  b.textContent='fehlgeschlagen'; b.style.color='#e04b4b';
  b.title=(bk.error||'')+(bk.last_good?` · gutes Backup von ${hm(bk.last_good)} liegt vor`:'');
 }
 if(h.db_ok===true){ d.textContent='OK'; d.style.color='#3ba55d';
  d.title=`quick_check bestanden · ${(h.db_size/1e6).toFixed(0)} MB · geprüft ${hm(h.checked_at)}`; }
 else if(h.db_ok===false){ d.textContent='BESCHÄDIGT'; d.style.color='#e04b4b';
  d.title=h.db_detail||'quick_check fehlgeschlagen'; }
 else if(h.checking){ d.textContent='prüft …'; d.style.color='#d29922'; d.title='quick_check läuft im Hintergrund'; }
 else { d.textContent='—'; d.style.color=''; }
}
// ---- Stop-Orders der Wale ----------------------------------------------------
// ---- Schlüsselniveaus aus den Orders: eine Rechnung für Panel, Chart und Konfluenz ----
function keyLevels(d){
 const S=(d&&d.stops&&d.stops.clusters)||[], p0=d&&(d.price||(d.candles&&d.candles.length?d.candles[d.candles.length-1].c:0));
 if(!S.length||!p0) return null;
 const inR=s=>Math.abs(s.dist)<=0.30;
 const best=(kind,sign)=>S.filter(s=>s.kind===kind&&inR(s)&&Math.sign(s.dist)===sign).sort((a,b)=>b.notional-a.notional)[0]||null;
 const nearest=(kind,sign)=>S.filter(s=>s.kind===kind&&inR(s)&&Math.sign(s.dist)===sign).sort((a,b)=>Math.abs(a.dist)-Math.abs(b.dist))[0]||null;
 const sum=(kind,sign,within)=>S.filter(s=>s.kind===kind&&Math.sign(s.dist)===sign&&Math.abs(s.dist)<=within).reduce((a,s)=>a+s.notional,0);
 return {
  support:    best('limit_buy',-1),          // größte Kaufwand unter dem Kurs
  resistance: best('limit_sell',1),          // größte Verkaufswand darüber
  tp_long:    best('tp_sell',1),             // Take-Profits der Longs (Verkauf oben)
  tp_short:   best('tp_buy',-1),             // Take-Profits der Shorts (Kauf unten)
  stop_sell:  best('stop_sell',-1), stop_sell_near: nearest('stop_sell',-1), stop_sell_2pct: sum('stop_sell',-1,0.02),
  stop_buy:   best('stop_buy',1),   stop_buy_near:  nearest('stop_buy',1),   stop_buy_2pct:  sum('stop_buy',1,0.02),
 };
}
const KEY_STYLE={support:['SUPPORT','#39d3ff'],resistance:['RESISTANCE','#c678dd'],tp_long:['TAKE-PROFIT LONGS','#8b949e'],
  tp_short:['TAKE-PROFIT SHORTS','#8b949e'],stop_sell:['SELL-STOPS','#e04b4b'],stop_buy:['BUY-STOPS','#3ba55d']};

function drawStops(d){
 const c=$('stops'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H);
 const S=(d.stops&&d.stops.clusters)||[], p0=d.price||(d.candles&&d.candles.length?d.candles[d.candles.length-1].c:0);
 const narrow=W<600, L=narrow?58:76, R=narrow?8:12, T=14, B=26, pw=W-L-R, ph=H-T-B;
 const info=$('stopsinfo'), lv=$('stopslevels');
 if(!S.length||!p0){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.textAlign='center';
  g.fillText(d.stops&&d.stops.n_whales?'Keine offenen Orders der Großkonten in diesem Coin':'Noch keine Order-Abfragen — der Recorder fragt Wale alle 2 Minuten', W/2, H/2);
  g.textAlign='left'; if(info) info.textContent=(d.stops&&d.stops.book&&SRC()==='bnc')?'Binance-Orderbuch derzeit nicht abrufbar — Netzverbindung des Pi prüfen; die Seite versucht es alle 5 s erneut':''; if(lv) lv.innerHTML=''; GEO.stops=null; return; }
 // Preisbereich fest ±30 %, Kaufseite links, Verkaufsseite rechts der Mittelachse
 let lo=p0*0.70, hi=p0*1.30; const pad=(hi-lo)*0.03; lo-=pad; hi+=pad;
 const Y=p=>T+(hi-p)/(hi-lo)*ph, mid=L+pw/2, half=pw/2-8;
 const inR=s=>s.px>=lo&&s.px<=hi;
 const BUY=['limit_buy','stop_buy','tp_buy'], SELL=['limit_sell','stop_sell','tp_sell'];
 const col={stop_sell:'#e04b4b',stop_buy:'#3ba55d',tp_sell:'#8b949e',tp_buy:'#8b949e',limit_sell:'#c678dd',limit_buy:'#39d3ff'};
 // je Preisstufe und Seite ein gestapelter Balken: Segmente nach Art
 const rows=new Map();
 S.filter(inR).forEach(s=>{ const side=BUY.includes(s.kind)?'buy':'sell'; const k=s.px.toFixed(4)+side;
  const r=rows.get(k)||{px:s.px,side,total:0,segs:[],addrs:0,n:0,dist:s.dist}; r.total+=s.notional; r.segs.push(s); r.addrs=Math.max(r.addrs,s.addrs); r.n+=s.n; rows.set(k,r); });
 const mx=Math.max(...[...rows.values()].map(r=>r.total),1);
 // Gitter und Preisachse
 g.strokeStyle='#161b22'; g.lineWidth=1;
 for(let k=0;k<=6;k++){const y=T+ph*k/6; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right';
 for(let k=0;k<=6;k++){const p=lo+(hi-lo)*(1-k/6); g.fillText(px(p).slice(0,9), L-6, T+ph*k/6+3);}
 g.textAlign='left';
 // Mittelachse und Seitentitel
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(mid,T); g.lineTo(mid,H-B); g.stroke();
 g.fillStyle='#8b949e'; g.font='bold 10px system-ui'; g.textAlign='right'; g.fillText('◀ KAUFSEITE', mid-6, T+10);
 g.textAlign='left'; g.fillText('VERKAUFSSEITE ▶', mid+6, T+10);
 const bars=[]; const h=Math.max(3,Math.min(8,ph/60));
 const order=[...rows.values()].sort((a,b)=>b.px-a.px);
 order.forEach(r=>{ const y=Y(r.px), w=Math.max(3,half*r.total/mx);
  let x=r.side==='buy'?mid-2:mid+2, dir=r.side==='buy'?-1:1;
  const kinds=r.side==='buy'?BUY:SELL;
  kinds.forEach(kd=>{ r.segs.filter(s=>s.kind===kd).forEach(s=>{ const sw=Math.max(1,w*s.notional/r.total);
   g.fillStyle=col[kd]; g.globalAlpha=kd.startsWith('tp')?0.6:kd.startsWith('limit')?0.8:1;
   g.fillRect(dir<0?x-sw:x, y-h/2, sw, h); g.globalAlpha=1; x+=dir*sw; }); });
  bars.push({y,h,r,x0:Math.min(mid,x),x1:Math.max(mid,x)}); });
 // Beschriftung der größten Balken, kollisionsfrei je Seite
 g.font='10px system-ui'; ['buy','sell'].forEach(side=>{ let last=-99;
  bars.filter(b=>b.r.side===side&&b.r.total>=mx*0.12).sort((a,b)=>a.y-b.y).forEach(b=>{ if(Math.abs(b.y-last)<11) return; last=b.y;
   const t=fmt(b.r.total)+(b.r.addrs>1?` · ${b.r.addrs} K.`:''); g.fillStyle='#c9d1d9';
   if(side==='buy'){ g.textAlign='right'; g.fillText(t, b.x0-5, b.y+4); } else { g.textAlign='left'; g.fillText(t, b.x1+5, b.y+4); } }); });
 g.textAlign='left';
 // Schlüsselniveaus markieren
 const K=keyLevels(d)||{};
 Object.entries(KEY_STYLE).forEach(([k,[label,color]])=>{ const s=K[k]; if(!s||s.px<lo||s.px>hi) return; const y=Y(s.px);
  g.strokeStyle=color; g.lineWidth=1; g.setLineDash([2,3]); g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
  g.fillStyle=color; g.font='bold 9px system-ui'; const onBuy=['support','tp_short','stop_sell'].includes(k);
  g.textAlign=onBuy?'left':'right'; g.fillText(label, onBuy?L+3:W-R-3, y-4); });
 g.textAlign='left';
 // Kurs
 const y0=Y(p0); g.strokeStyle='#58a6ff'; g.setLineDash([5,4]); g.lineWidth=1.5;
 g.beginPath(); g.moveTo(L,y0); g.lineTo(W-R,y0); g.stroke(); g.setLineDash([]);
 g.fillStyle='#58a6ff'; g.fillRect(W-R-60,y0-8,60,16); g.fillStyle='#0d1117'; g.font='bold 10px system-ui';
 g.textAlign='right'; g.fillText(px(p0).slice(0,9), W-R-4, y0+4); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText('Balkenlänge = Notional · gestapelt nach Art', L, H-8);
 GEO.stops={bars,L,T,B,pw,ph,W,H,R,lo,hi,mid};
 if(info&&d.stops.book&&SRC()==='bnc') info.innerHTML=`Binance-Orderbuch (bis 1.000 Stufen je Seite, ±30 %): ${d.stops.clusters.length} Preisstufen · Bereich ±30 % · Stand ${hm(d.stops.ts)}`;
 else if(info&&SRC()==='fusion'){ const B=d.stops.book_bnc, C=d.stops.book_cdc, fm=v=>v>=1e9?(v/1e9).toFixed(1)+' Mrd':(v/1e6).toFixed(1)+' Mio';
   info.innerHTML=`Data Mix Fusion: ${d.stops.n_whales} HL-Konten abgefragt (${d.stops.n_with_orders||0} mit Orders) + Binance-Orderbuch ${d.stops.book_n||0} Stufen${B?` (reicht ±${B.span_pct.toFixed(1)} %: ${fm(B.bid_usd)} Bid / ${fm(B.ask_usd)} Ask — Binance liefert höchstens 1.000 Stufen je Seite, tiefere Wände sind dort nicht abrufbar)`:''} + Crypto.com-Orderbuch ${d.stops.cdc_book_n||0} Stufen${C?` (±${C.span_pct.toFixed(1)} %, ${fm(C.bid_usd+C.ask_usd)})`:''} — je Preisstufe summiert · Bereich ±30 %`; }
 else if(info) info.innerHTML=`${d.stops.n_whales} Konten abgefragt, davon <b>${d.stops.n_with_orders||0}</b> mit Orders in ${$('coin').value} innerhalb ±30 % `
  +`(${d.stops.n_fresh||0} in den letzten 20 min abgefragt`
  +(d.stops.oldest?`, ältester Stand vor ${Math.round((Date.now()/1000-d.stops.oldest)/60)} min`:'')+`)`
  +(d.stops.ts?` · jüngste Abfrage ${hm(d.stops.ts)}`:'')
  +` · Spalte „Konten" in der Tabelle = Konten am jeweiligen Preisniveau`;
 // Live-Auswertung
 if(lv){ const row=(label,s,extra)=>`<tr><td>${label}</td><td class="n" style="color:${extra}">${s?px(s.px):'—'}</td>`
    +`<td class="n">${s?(s.dist*100).toFixed(2)+' %':'—'}</td><td class="n">${s?fmt(s.notional):'—'}</td><td class="n">${s?s.addrs:'—'}</td></tr>`;
  lv.innerHTML=`<table class="w"><tr><th>Niveau</th><th class="n">Preis</th><th class="n">Abstand</th><th class="n">Notional</th><th class="n">Konten</th></tr>`
   +row('Support — größte Kaufwand unter dem Kurs', K.support, '#39d3ff')
   +row('Resistance — größte Verkaufswand über dem Kurs', K.resistance, '#c678dd')
   +row('Höchste Take-Profits der Longs (Verkauf oben)', K.tp_long, '#8b949e')
   +row('Höchste Take-Profits der Shorts (Kauf unten)', K.tp_short, '#8b949e')
   +row('Größtes Sell-Stop-Cluster unter dem Kurs (Verkaufskaskade)', K.stop_sell, '#e04b4b')
   +row('Nächster Sell-Stop unter dem Kurs', K.stop_sell_near, '#e04b4b')
   +row('Größtes Buy-Stop-Cluster über dem Kurs (Kaufkaskade)', K.stop_buy, '#3ba55d')
   +row('Nächster Buy-Stop über dem Kurs', K.stop_buy_near, '#3ba55d')
   +`<tr><td>Sell-Stops innerhalb 2 % unter dem Kurs</td><td class="n" colspan="3" style="color:#e04b4b">${fmt(K.stop_sell_2pct||0)} USD</td><td></td></tr>`
   +`<tr><td>Buy-Stops innerhalb 2 % über dem Kurs</td><td class="n" colspan="3" style="color:#3ba55d">${fmt(K.stop_buy_2pct||0)} USD</td><td></td></tr>`
   +`</table>`; }
}
function crosshair(c, G, x, y, price){
 // waagerechte Preislinie mit Etikett am Rand, dazu eine senkrechte Linie an der Zeigerposition
 const g=c.getContext('2d'), d=devicePixelRatio||1; g.save(); g.setTransform(d,0,0,d,0,0);
 g.strokeStyle='rgba(201,209,217,0.55)'; g.lineWidth=1; g.setLineDash([4,3]);
 g.beginPath(); g.moveTo(G.L,y); g.lineTo(G.W-G.R,y); g.stroke();
 g.beginPath(); g.moveTo(x,G.T); g.lineTo(x,G.H-G.B); g.stroke(); g.setLineDash([]);
 const t=px(price).slice(0,10); g.font='bold 10px system-ui'; const w=g.measureText(t).width+10;
 g.fillStyle='#c9d1d9'; g.fillRect(G.L-w-2,y-8,w,16); g.fillStyle='#0d1117'; g.textAlign='right'; g.fillText(t,G.L-7,y+4);
 g.textAlign='left'; g.restore();
}
function tipStops(ev){
 const G=GEO.stops, c=$('stops'); if(!G) return hideTip();
 const r=c.getBoundingClientRect(), y=ev.clientY-r.top, x=ev.clientX-r.left;
 if(y>=G.T&&y<=G.H-G.B&&LAST_CHART){ drawStops(LAST_CHART); crosshair(c,G,x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const side=x<G.mid?'buy':'sell';
 const hit=G.bars.filter(b=>b.r.side===side&&Math.abs(b.y-y)<=Math.max(b.h,6)).sort((a,b)=>Math.abs(a.y-y)-Math.abs(b.y-y))[0];
 if(!hit) return hideTip();
 const name={stop_sell:'Sell-Stops',stop_buy:'Buy-Stops',tp_sell:'Take-Profit (Verkauf)',tp_buy:'Take-Profit (Kauf)',limit_sell:'Limit-Verkäufe',limit_buy:'Limit-Käufe'};
 const rows=hit.r.segs.map(s=>[name[s.kind]||s.kind, fmt(s.notional)+' USD · '+s.n+' Orders · '+s.addrs+' Konten']);
 rows.push(['Abstand',(hit.r.dist*100).toFixed(2)+' %', hit.r.dist<0?'#e04b4b':'#3ba55d']);
 showTip(ev, (side==='buy'?'Kaufseite bei ':'Verkaufsseite bei ')+px(hit.r.px)+' · '+fmt(hit.r.total), rows);
}

// ---- Konfluenz: transparente Regeln, jede mit Begründung --------------------
let LAST_WHALES=null, SIGNAL=null;
// Kaskadenmodell: Wo löst eine Kaskade aus, welche Art, wohin könnte sie laufen?
// Ablauf je Richtung in 0,25-%-Stufen vom Kurs weg: Auslöser = erstes nennenswertes Stop-Cluster
// (oder Liquidationscluster). Ab dort summiert sich der Druck (Stops + Liquidationen derselben
// Richtung, Perp-Notional), dagegen steht die Aufnahme: ruhende Limits (Support/Resistance) plus
// eine organische Grundaufnahme je Stufe (5 % des Stundenvolumens). Die Kaskade endet auf der
// Stufe, auf der die aufgelaufene Aufnahme den aufgelaufenen Druck erreicht -- das ist das Ziel.
// Long-Squeeze = Kaskade nach unten (Longs werden gestoppt/liquidiert), Short-Squeeze = nach oben.
function cascadeModel(d){
 const p0=d.price, vol=d.vol_1h||0, SC=(d.stops&&d.stops.clusters)||[], L=d.levels||[];
 if(!p0) return null;
 const step=Math.log(1.0025), bkt=px=>Math.round(Math.log(px)/step);
 const out={};
 for(const dir of ['down','up']){
  const sgn=dir==='down'?-1:1;
  const pressure=new Map(), absorb=new Map();
  const addTo=(m,b,v)=>m.set(b,(m.get(b)||0)+v);
  SC.forEach(s=>{ const b=bkt(s.px); const rel=(s.px/p0-1)*sgn; if(rel<=0||rel>0.15) return;
   if(dir==='down'&&s.kind==='stop_sell') addTo(pressure,b,s.notional);
   if(dir==='up'&&s.kind==='stop_buy') addTo(pressure,b,s.notional);
   if(dir==='down'&&(s.kind==='limit_buy'||s.kind==='tp_buy')) addTo(absorb,b,s.notional);
   if(dir==='up'&&(s.kind==='limit_sell'||s.kind==='tp_sell')) addTo(absorb,b,s.notional); });
  L.forEach(l=>{ const rel=(l.px/p0-1)*sgn; if(rel<=0||rel>0.15) return;
   if(dir==='down'&&l.side==='long') addTo(pressure,bkt(l.px),l.notional);
   if(dir==='up'&&l.side==='short') addTo(pressure,bkt(l.px),l.notional); });
  const b0=bkt(p0), minTrig=Math.max(vol*0.25,5e6), organic=vol*0.05;
  let trig=null, cumP=0, cumA=0, chain=[], target=null, wallMax=null, absorbTotal=0;
  for(let k=1;k<=60;k++){ const b=b0+sgn*k, px=Math.exp(b*step);
   const pr=pressure.get(b)||0, ab=absorb.get(b)||0;
   if(!trig){ if(pr>=minTrig){ trig={px,pressure:pr}; cumP=pr; chain.push({px,pressure:pr}); } continue; }
   cumP+=pr; cumA+=ab+organic; absorbTotal+=ab;
   if(pr>=Math.max(vol*0.1,2e6)) chain.push({px,pressure:pr});
   if(ab>(wallMax?wallMax.notional:0)) wallMax={px,notional:ab};
   if(cumA>=cumP){ target={px,cumP,cumA,steps:k}; break; } }
  if(trig&&!target){ const px=Math.exp((b0+sgn*60)*step); target={px,cumP,cumA,steps:60,open:true}; }
  out[dir]=trig?{trigger:trig,target,chain,wall:wallMax,absorb:absorbTotal,type:dir==='down'?'Long-Squeeze':'Short-Squeeze'}:null;
 }
 return out;
}
function cascadeText(c, p0, dir){
 const C=c&&c[dir]; if(!C) return null;
 const tDist=(C.trigger.px/p0-1)*100, zDist=(C.target.px/p0-1)*100;
 const chainTxt=C.chain.length>1?` · Kette: ${C.chain.slice(0,4).map(x=>px(x.px)+' ('+fmt(x.pressure)+')').join(' → ')}${C.chain.length>4?' …':''}`:'';
 const wall=C.wall?` · größte Aufnahme ${fmt(C.wall.notional)} bei ${px(C.wall.px)}`:'';
 return `${dir==='down'?'Verkaufskaskade':'Kaufkaskade'} (${C.type}) ab ${px(C.trigger.px)} (${tDist>=0?'+':''}${tDist.toFixed(2)} %): Druck ${fmt(C.target.cumP)} gegen Aufnahme ${fmt(C.target.cumA)} — Ziel ≈ ${px(C.target.px)} (${zDist>=0?'+':''}${zDist.toFixed(2)} %)${C.target.open?', Aufnahme reicht im Modell nicht — offen':''}${chainTxt}${wall}`;
}
// 24.09.: Konfluenz-Ergebnis an den Server melden (höchstens alle 5 min je Coin) und Bilanz anzeigen
let KONF_LOG={};
function konfluenzMelden(S, px0){ try{ const coin=$('coin').value, now=Date.now(); if(!coin||!px0||now-(KONF_LOG[coin]||0)<300000) return; KONF_LOG[coin]=now;
  const z=S.zone||{}; fetch('/konfluenz/log?'+new URLSearchParams({coin, label:S.label, net:String(S.net), dir:S.dir||'', zk:z.kind||'',
   zb:z.bot!=null?String(z.bot):'', zt:z.top!=null?String(z.top):'', ztx:z.text||'', px:String(px0)})).catch(()=>{}); }catch(e){} }
async function konfBilanzLaden(){ let b; try{ b=await getJSON('/konfluenz/bilanz'); }catch(e){ return; } const el=$('konfbilanz'); if(!el) return;
 const q=x=>x==null?'—':(x*100).toFixed(0)+' %', K=b.kategorien||{}, Z=b.zonen||{};
 const t=(n,k)=>k&&k.n?`${n}: ${k.n}× · 4 h ${q(k.r4)} richtig (Zufall ${q(k.basis4)}) · 12 h ${q(k.r12)} (Zufall ${q(k.basis12)})`:null;
 const teile=[t('ab 3 Punkten',K.stark), t('leicht',K.leicht), t('bei ABWARTEN',K.abwarten)].filter(Boolean);
 el.innerHTML=`<b>Bilanz der Konfluenz</b> (${b.n_faelle||0} Fälle${b.seit?' seit '+hm(b.seit):''}): `
  +(teile.length?teile.join(' · '):'noch keine ausgewerteten Fälle -- die ersten 12 h nach der ersten Aufzeichnung abwarten')
  +(Z.n?` · Zonen: ${Z.erreicht} von ${Z.n} erreicht, danach in ${q(Z.gehalten)} gehalten (Zufall ${q(Z.basis)})`:'')
  +`<div style="font-size:11px">${esc(b.hinweis||'')}</div>`; }
konfBilanzLaden(); setInterval(konfBilanzLaden, 600000);
function computeSignal(){
 const d=LAST_CHART; if(!d||!d.candles||!d.candles.length) return;
 const px0=d.price||d.candles[d.candles.length-1].c;
 const R=[], zones=[]; let buy=0, sell=0;
 const add=(side,pts,text)=>{ if(side==='buy')buy+=pts; else if(side==='sell')sell+=pts; R.push({side,pts,text}); };
 const near=(v,pct)=>Math.abs(v)<=pct;

 // 1. Liquidationscluster: Nähe = Anlauf wahrscheinlich (warten), frisch abgeräumt = Umkehrchance
 // (im Binance-Modus sind die Marken EINGETRETENE Liquidationen -- dafür gelten die Binance-Regeln unten)
 const L=d.levels_realized?[]:(d.levels||[]);
 const big=l=>l.x_vol>=0.5;
 const dn=L.filter(l=>l.side==='long'&&big(l)&&l.dist<0).sort((a,b)=>b.dist-a.dist)[0];
 const up=L.filter(l=>l.side==='short'&&big(l)&&l.dist>0).sort((a,b)=>a.dist-b.dist)[0];
 if(dn&&near(dn.dist,0.006)) add('wait',0,`Großes Long-Cluster ${(dn.dist*100).toFixed(2)} % unter dem Kurs (${fmt(dn.notional)}) — Anlauf wahrscheinlich, Kauf erst nach Abholung`);
 if(up&&near(up.dist,0.006)) add('wait',0,`Großes Short-Cluster ${(up.dist*100).toFixed(2)} % über dem Kurs (${fmt(up.notional)}) — Anlauf wahrscheinlich, Verkauf erst nach Abholung`);
 const ev=(d.tick_events||[]).filter(e=>Date.now()/1000-e.t_trigger/1000<3600)[0];
 if(ev){ const rec=(px0/ev.px_extreme-1);
  if(ev.move_pct<0&&rec>0.003&&ev.n_liqs>0){ add('buy',2,`Long-Kaskade vor ${Math.round((Date.now()/1000-ev.t_trigger/1000)/60)} min (${(ev.move_pct*100).toFixed(2)} %, ${ev.n_liqs} Liqs), Kurs ${(rec*100).toFixed(2)} % über dem Tief — Cluster abgeräumt`);
   zones.push({kind:'buy',bot:ev.px_extreme,top:ev.px_extreme*1.006,text:'Kaskadentief'}); }
  if(ev.move_pct>0&&rec<-0.003&&ev.n_liqs>0){ add('sell',2,`Short-Squeeze vor ${Math.round((Date.now()/1000-ev.t_trigger/1000)/60)} min (${(ev.move_pct*100).toFixed(2)} %, ${ev.n_liqs} Liqs), Kurs ${(-rec*100).toFixed(2)} % unter dem Hoch — Cluster abgeräumt`);
   zones.push({kind:'sell',bot:ev.px_extreme*0.994,top:ev.px_extreme,text:'Squeeze-Hoch'}); }
 }

 // 1b. Stop-Orders der Wale: Sell-Stops dicht unter dem Kurs = Kaskade nach unten droht,
 //     Buy-Stops dicht darüber = Kaskade nach oben. Wie Cluster: erst abwarten, dann handeln.
 //     Frisch ausgelöste Stops erkennt man daran, dass sie verschwunden sind -- das
 //     übernimmt die Kaskaden-Regel oben über die tatsächlichen Liquidationsfills.
 const SC=(d.stops&&d.stops.clusters)||[], vol1h=d.vol_1h||0;
 const bigStop=s=>s.notional>=Math.max(vol1h*0.25, 5e6);
 const sellStop=SC.filter(s=>s.kind==='stop_sell'&&s.dist<0&&s.dist>-0.008&&bigStop(s)).sort((a,b)=>b.dist-a.dist)[0];
 const buyStop =SC.filter(s=>s.kind==='stop_buy' &&s.dist>0&&s.dist< 0.008&&bigStop(s)).sort((a,b)=>a.dist-b.dist)[0];
 const CM=cascadeModel(d); LAST_CASCADE=CM;
 if(sellStop) add('wait',0,`Sell-Stops ${(sellStop.dist*100).toFixed(2)} % unter dem Kurs (${fmt(sellStop.notional)}, ${sellStop.addrs} Konten) — Verkaufskaskade droht, kein Long davor`);
 if(buyStop)  add('wait',0,`Buy-Stops +${(buyStop.dist*100).toFixed(2)} % über dem Kurs (${fmt(buyStop.notional)}, ${buyStop.addrs} Konten) — Kaufkaskade möglich, kein Short davor`);
 // Ruhende Limit-Orders: eine Kaufwand dicht unter dem Kurs stützt, eine Verkaufswand darüber deckelt.
 // Take-Profits wirken wie Limits (sie absorbieren), zählen aber nur als Hinweis.
 // Schlüsselniveaus -- dieselbe Rechnung wie Panel und Chart (keyLevels)
 const K=keyLevels(d)||{}, wall=s=>s&&s.notional>=Math.max(vol1h*0.5, 10e6);
 if(wall(K.support)&&K.support.dist>-0.01)      add('buy',1,`Support ${(K.support.dist*100).toFixed(2)} % unter dem Kurs: Kaufwand ${fmt(K.support.notional)} (${K.support.addrs} Konten)`);
 else if(K.support&&K.support.dist>-0.01)       add('warn',0,`Support ${(K.support.dist*100).toFixed(2)} % unter dem Kurs, aber klein (${fmt(K.support.notional)}) — kein Punkt`);
 if(wall(K.resistance)&&K.resistance.dist<0.01) add('sell',1,`Resistance +${(K.resistance.dist*100).toFixed(2)} % über dem Kurs: Verkaufswand ${fmt(K.resistance.notional)} (${K.resistance.addrs} Konten)`);
 else if(K.resistance&&K.resistance.dist<0.01)  add('warn',0,`Resistance +${(K.resistance.dist*100).toFixed(2)} % über dem Kurs, aber klein (${fmt(K.resistance.notional)}) — kein Punkt`);
 if(wall(K.tp_long)&&K.tp_long.dist<0.01)   add('warn',0,`Take-Profits der Longs +${(K.tp_long.dist*100).toFixed(2)} % über dem Kurs: ${fmt(K.tp_long.notional)} — Verkaufsdruck beim Anstieg (Hinweis)`);
 if(wall(K.tp_short)&&K.tp_short.dist>-0.01) add('warn',0,`Take-Profits der Shorts ${(K.tp_short.dist*100).toFixed(2)} % unter dem Kurs: ${fmt(K.tp_short.notional)} — Kaufdruck beim Rückgang (Hinweis)`);
 // Kaskadenmasse dicht am Kurs, unabhängig vom größten Einzelcluster
 if((K.stop_sell_2pct||0)>=Math.max(vol1h*0.5,10e6)) add('wait',0,`Sell-Stops innerhalb 2 % unter dem Kurs summieren sich auf ${fmt(K.stop_sell_2pct)} — ${cascadeText(CM,px0,'down')||'Verkaufskaskade bei Unterschreiten'}`);
 if((K.stop_buy_2pct||0) >=Math.max(vol1h*0.5,10e6)) add('wait',0,`Buy-Stops innerhalb 2 % über dem Kurs summieren sich auf ${fmt(K.stop_buy_2pct)} — ${cascadeText(CM,px0,'up')||'Kaufkaskade bei Überschreiten'}`);
 // Kaskadenprognose als eigene Hinweise, wenn der Auslöser innerhalb 3 % liegt (auch ohne die 2-%-Summe)
 for(const dir of ['down','up']){ const C=CM&&CM[dir]; if(!C) continue; const tDist=Math.abs(C.trigger.px/px0-1);
  const already=(dir==='down'&&(K.stop_sell_2pct||0)>=Math.max(vol1h*0.5,10e6))||(dir==='up'&&(K.stop_buy_2pct||0)>=Math.max(vol1h*0.5,10e6));
  if(tDist<=0.03&&!already) add('warn',0,`Kaskadenprognose: ${cascadeText(CM,px0,dir)}`); }

 // Stops UND Liquidationscluster auf derselben Seite dicht am Kurs: doppelter Magnet
 if(sellStop&&dn&&near(dn.dist,0.008)) add('wait',0,`Sell-Stops und Long-Liquidationen liegen beide dicht unter dem Kurs — doppelter Magnet nach unten`);
 if(buyStop&&up&&near(up.dist,0.008))  add('wait',0,`Buy-Stops und Short-Liquidationen liegen beide dicht über dem Kurs — doppelter Magnet nach oben`);

 // 2. Offene Fair Value Gaps direkt am Kurs
 const F=(d.fvgs||[]).filter(f=>f.fill_i==null);
 const fb=F.filter(f=>f.kind==='bull'&&f.top<=px0&&px0/f.top-1<0.005)[0];
 const fs=F.filter(f=>f.kind==='bear'&&f.bot>=px0&&f.bot/px0-1<0.005)[0];
 if(fb){ add('buy',1,`Offenes bullisches FVG ${px(fb.bot)}–${px(fb.top)} direkt unter dem Kurs`); zones.push({kind:'buy',bot:fb.bot,top:fb.top,text:'bullisches FVG'}); }
 if(fs){ add('sell',1,`Offenes bärisches FVG ${px(fs.bot)}–${px(fs.top)} direkt über dem Kurs`); zones.push({kind:'sell',bot:fs.bot,top:fs.top,text:'bärisches FVG'}); }
 const inb=F.filter(f=>f.kind==='bull'&&px0>=f.bot&&px0<=f.top)[0], ins=F.filter(f=>f.kind==='bear'&&px0>=f.bot&&px0<=f.top)[0];
 if(inb){ add('buy',1,`Kurs steht IM bullischen FVG ${px(inb.bot)}–${px(inb.top)}`); zones.push({kind:'buy',bot:inb.bot,top:inb.top,text:'bullisches FVG'}); }
 if(ins){ add('sell',1,`Kurs steht IM bärischen FVG ${px(ins.bot)}–${px(ins.top)}`); zones.push({kind:'sell',bot:ins.bot,top:ins.top,text:'bärisches FVG'}); }

 // 3. RSI
 if(d.rsi14!=null){ if(d.rsi14<=30) add('buy',1,`RSI ${d.rsi14.toFixed(0)} (${d.rsi_tf}) überverkauft`);
  else if(d.rsi14>=70) add('sell',1,`RSI ${d.rsi14.toFixed(0)} (${d.rsi_tf}) überkauft`); }

 // 4. Orderbuch-Imbalance (Tiefe innerhalb 50 bps)
 if(d.book){ const i=d.book.imb_50;
  if(i>=0.3) add('buy',1,`Orderbuch: ${(i*100).toFixed(0)} % mehr Bid- als Ask-Tiefe (50 bps)`);
  else if(i<=-0.3) add('sell',1,`Orderbuch: ${(-i*100).toFixed(0)} % mehr Ask- als Bid-Tiefe (50 bps)`); }

 // 5. Funding: extreme Werte bedeuten einseitige Positionierung
 if(d.funding){ const f=d.funding.funding;
  if(f<=-0.00005) add('buy',1,`Funding ${(f*100).toFixed(4)} %/h negativ — Shorts zahlen, Squeeze-Potenzial`);
  else if(f>=0.0001) add('sell',1,`Funding ${(f*100).toFixed(4)} %/h stark positiv — Longs überfüllt`); }

 // 6. Wal-Netto-Ausrichtung im gewählten Coin
 // Wal-Flow: Positionsänderungen der direktionalen Wale in den letzten 30 min -- schnellstes Signal (Nachrichten!)
 if(LAST_WHALES&&LAST_WHALES.flow&&LAST_WHALES.flow.groups){ const FG=LAST_WHALES.flow.groups, NM=LAST_WHALES.flow.group_names||{};
  const okW=w=>w&&(w.buy_usd+w.sell_usd)>=3e5&&(w.n_buy+w.n_sell)>=2;
  for(const g of ['hedge','mm','mixed']){ const gf=FG[g]; if(!gf) continue;
   let w=gf.w30, win='30 min', z=gf.z30; if(!okW(w)&&okW(gf.w60)){ w=gf.w60; win='60 min'; z=gf.z60; }
   if(!okW(w)) continue; const gr=w.buy_usd+w.sell_usd;
   if(Math.abs(w.net_usd)>gr*0.5) add('warn',0,`Wal-Flow ${NM[g]||g} ${win}: ${w.net_usd>0?w.n_buy+' Konten bauen Long auf / Short ab':w.n_sell+' Konten bauen Long ab / Short auf'}, netto ${w.net_usd>=0?'+':'−'}${fmt(Math.abs(w.net_usd))}${z!=null?` (Z ${z.toFixed(1)})`:''} — Hinweis, Gruppe wird noch bewertet`); } }
 if(LAST_WHALES&&LAST_WHALES.flow&&LAST_WHALES.flow.w30){ const F=LAST_WHALES.flow; const okW=w=>w&&(w.buy_usd+w.sell_usd)>=3e5&&(w.n_buy+w.n_sell)>=2;
  let w=F.w30, win='30 min', z=F.z30; if(!okW(w)&&okW(F.w60)){ w=F.w60; win='60 min'; z=F.z60; }   // langsame Serien: 60-min-Fenster
  const gross=w.buy_usd+w.sell_usd;
  if(okW(w)){ const big=F.event_signal, pts=big?2:1;
   if(w.net_usd>gross*0.5&&w.n_buy>=2) add('buy',pts,`Wal-Flow ${win}: ${w.n_buy} direktionale Wale bauen Long auf / Short ab, netto +${fmt(w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL: breit und außergewöhnlich schnell':''}`);
   else if(w.net_usd<-gross*0.5&&w.n_sell>=2) add('sell',pts,`Wal-Flow ${win}: ${w.n_sell} direktionale Wale bauen Long ab / Short auf, netto −${fmt(-w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL: breit und außergewöhnlich schnell':''}`);
   else add('warn',0,`Wal-Flow ${win} gemischt: ${w.n_buy} Wale kaufen ${fmt(w.buy_usd)}, ${w.n_sell} verkaufen ${fmt(w.sell_usd)} — kein Punkt`); } }
 // Coinbase-Spot: Nachfrage ohne Hebel. Prämie = Aufschlag gegenüber dem Perp-Kurs,
 // Taker-Flow = was aggressiv gekauft oder verkauft wurde, Buchtiefe als Stütze.
 if(LAST_CHART&&LAST_CHART.cb&&LAST_CHART.cb.aktiv){ const C=LAST_CHART.cb;
  if(C.premium_z!=null&&Math.abs(C.premium_z)>=1.5)
   add('warn',0,
       `Ohne Punkte, bis die Prämie gegen Binance-Spot neu gebaut ist (nach Rutschen fällt der HL-Perp unter Spot und die Prämie schlägt nach oben aus): Coinbase-Prämie ${C.premium_bps>=0?'+':''}${C.premium_bps.toFixed(1)} bps zum Perp-Kurs (Mittel ${(C.premium_mittel||0)>=0?'+':''}${(C.premium_mittel||0).toFixed(1)}, Z ${(C.premium_z||0).toFixed(1)}) — US-Spot zahlt ${(C.premium_z||0)>0?'Aufschlag':'Abschlag'}`);
  const F=C.flow60||{}, brutto=(F.buy_usd||0)+(F.sell_usd||0);
  if(brutto>=2e5&&Math.abs(F.net_usd)>brutto*0.3){ const z=C.flow_z;
   add(F.net_usd>0?'buy':'sell', (z!=null&&Math.abs(z)>=2.5)?2:1,
       `Spot-Taker-Flow 60 min: ${fmt(F.buy_usd)} aggressiv gekauft gegen ${fmt(F.sell_usd)} verkauft${z!=null?` (Z ${z.toFixed(1)})`:''}${C.vol_rel?` · Volumen ${C.vol_rel.toFixed(1)}x`:''}`); }
  const B=C.book||{};
  if(B.imbalance!=null&&Math.abs(B.imbalance)>=0.25&&(B.bid25+B.ask25)>=1e5)
   add(B.imbalance>0?'buy':'sell',1,
       `Spot-Orderbuch ±25 bps: ${fmt(B.bid25)} Gebot gegen ${fmt(B.ask25)} Angebot (${(B.imbalance*100).toFixed(0)} %)`);
  (C.walls||[]).slice(0,2).forEach(w=>add('warn',0,`Spot-Wand ${w.side==='bid'?'Kauf':'Verkauf'} ${fmt(w.usd)} bei ${px(w.px)}`));
 } else if(LAST_CHART&&LAST_CHART.cb&&LAST_CHART.cb.alter_min!=null)
   add('warn',0,`Coinbase-Daten ${LAST_CHART.cb.alter_min} min alt — Dienst prüfen`);
 // Leaderboard-Flow: Positionsänderungen der direktionalen Top-Konten (Stände alle 5 min verglichen)
 if(LAST_CHART&&LAST_CHART.lb&&LAST_CHART.lb.flow&&LAST_CHART.lb.flow.w60){ const F=LAST_CHART.lb.flow; const okW=w=>w&&(w.buy_usd+w.sell_usd)>=1.5e5&&(w.n_buy+w.n_sell)>=2;
  let w=F.w60, win='60 min'; if(!okW(w)&&okW(F.w180)){ w=F.w180; win='3 h'; }
  if(okW(w)){ const gross=w.buy_usd+w.sell_usd, z=F.z60, big=F.event_signal, pts=big?2:1;
   if(w.net_usd>gross*0.5&&w.n_buy>=2) add('buy',pts,`Leaderboard-Flow ${win}: ${w.n_buy} direktionale Top-Konten bauen Long auf / Short ab, netto +${fmt(w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL':''}`);
   else if(w.net_usd<-gross*0.5&&w.n_sell>=2) add('sell',pts,`Leaderboard-Flow ${win}: ${w.n_sell} direktionale Top-Konten bauen Long ab / Short auf, netto −${fmt(-w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL':''}`);
   else add('warn',0,`Leaderboard-Flow ${win} gemischt: ${w.n_buy} Konten kaufen ${fmt(w.buy_usd)}, ${w.n_sell} verkaufen ${fmt(w.sell_usd)} — kein Punkt`); } }
 // Nur direktionale Wale zählen: Hedges und Market Maker sind keine Meinung, sondern Absicherung
 if(LAST_WHALES&&LAST_WHALES.directional&&LAST_WHALES.directional.n_directional){
  const D=LAST_WHALES.directional;
  if(D.usd_long>D.usd_short*1.5) add('buy',1,`Direktionale Wale netto long: ${D.n_long} Konten ${fmt(D.usd_long)} gegen ${D.n_short} Konten ${fmt(D.usd_short)} short (Hedges und Market Maker ausgenommen)`);
  else if(D.usd_short>D.usd_long*1.5) add('sell',1,`Direktionale Wale netto short: ${D.n_short} Konten ${fmt(D.usd_short)} gegen ${D.n_long} Konten ${fmt(D.usd_long)} long (Hedges und Market Maker ausgenommen)`);
  else add('warn',0,`Direktionale Wale ausgeglichen: ${D.n_long} long ${fmt(D.usd_long)} gegen ${D.n_short} short ${fmt(D.usd_short)} — kein Punkt`);
 } else if(LAST_WHALES&&LAST_WHALES.directional){ add('warn',0,`${LAST_WHALES.directional.n_whales} Wale erfasst, keiner direktional — Wal-Faktor entfällt`); }

 // 6b. Binance (Binance-Modus und Fusion): Taker-Flow, Top-Trader-Positionierung, laufende Kaskade
 if(SRC()!=='hl'&&d.bnc){ const M=d.bnc.metrics||{}, LQ=d.bnc.liqs_1h||{}, CD=d.cdc||null;
  // Taker-Flow börsenübergreifend: Binance und Crypto.com nach Volumen gewichtet -- EIN Punkt, nicht zwei
  const parts=[]; if(M.taker_ls!=null) parts.push({n:'Binance',r:+M.taker_ls,w:Math.max(d.bnc.vol_1h||0,1)});
  // Trade-Stichproben (Crypto.com 150, Bybit 500 Trades) nur, wenn sie mindestens 60 s abdecken -- sonst Sekundenrauschen
  if(CD&&CD.taker_ls!=null&&CD.taker_ls<9&&(CD.taker_span_s||0)>=60) parts.push({n:'Crypto.com',r:+CD.taker_ls,w:Math.max(CD.vol_1h||0,1)});
  if(d.bybit&&d.bybit.taker_ls!=null&&(d.bybit.taker_span_s||0)>=60) parts.push({n:'Bybit',r:+d.bybit.taker_ls,w:Math.max(d.bybit.vol_1h||0,1)});
  if(d.okx&&d.okx.taker_ls!=null) parts.push({n:'OKX',r:+d.okx.taker_ls,w:Math.max(d.okx.vol_1h||0,1)});
  const lsx=[['Binance',M.global_ls_account],['Bybit',d.bybit&&d.bybit.ls_account],['OKX',d.okx&&d.okx.ls_account]].filter(e=>e[1]!=null);
  if(lsx.length>=2){ const avg=lsx.reduce((a,e)=>a+ +e[1],0)/lsx.length;
   if(avg>=2.5) add('warn',0,`Konten börsenübergreifend einseitig long (Ø ${avg.toFixed(1)}:1 — ${lsx.map(e=>`${e[0]} ${(+e[1]).toFixed(2)}`).join(', ')}) — Kaskadenrisiko nach unten (Hinweis)`);
   else if(avg<=0.6) add('warn',0,`Konten börsenübergreifend einseitig short (Ø ${avg.toFixed(2)}:1) — Squeeze-Risiko nach oben (Hinweis)`); }
  if(d.okx&&(d.okx.liq_1h_long||0)+(d.okx.liq_1h_short||0)>=5e6) add('wait',0,`OKX: ${fmt(d.okx.liq_1h_long||0)} Long- und ${fmt(d.okx.liq_1h_short||0)} Short-Liquidationen in der letzten Stunde — Kaskade läuft oder lief gerade`);
  if(parts.length){ const wsum=parts.reduce((a,p)=>a+p.w,0), r=parts.reduce((a,p)=>a+p.r*p.w,0)/wsum, lbl=parts.map(p=>`${p.n} ${p.r.toFixed(2)}`).join(', ');
   const agree=parts.every(p=>p.r>=1.2)||parts.every(p=>p.r<=0.8);
   if(r>=1.2) add('buy',1,`Taker-Flow ${(parts.length>1?'börsenübergreifend ':'')}${r.toFixed(2)}× mehr aggressive Käufe als Verkäufe (${lbl})${parts.length>1&&!agree?' — Börsen uneins':''}`);
   else if(r<=0.8) add('sell',1,`Taker-Flow ${(parts.length>1?'börsenübergreifend ':'')}nur ${r.toFixed(2)}× — aggressive Verkäufe überwiegen (${lbl})${parts.length>1&&!agree?' — Börsen uneins':''}`);
   else if(parts.length>1&&!agree&&parts.some(p=>p.r>=1.2)&&parts.some(p=>p.r<=0.8)) add('warn',0,`Taker-Flow gegenläufig: ${lbl} — Börsen uneins, kein Punkt`); }
  const fHL=(d.funding!=null&&typeof d.funding==='object')?d.funding.funding:d.funding;
  if(CD&&CD.premium!=null&&fHL!=null&&SRC()==='fusion'){ const prem=CD.premium, f=+fHL;
   if(Math.abs(prem)>0.0005&&Math.sign(prem)!==Math.sign(f)) add('warn',0,`Prämie Crypto.com ${(prem*100).toFixed(3)} % gegen Funding Hyperliquid ${(f*100).toFixed(4)} %/h gegenläufig — Positionierung der Börsen uneins (Hinweis)`);
   else if(Math.abs(prem)>0.002) add('warn',0,`Prämie Crypto.com ${(prem*100).toFixed(3)} % — Perpetual deutlich ${prem>0?'über':'unter'} Index, ${prem>0?'Longs zahlen, Squeeze-Risiko nach unten':'Shorts zahlen, Squeeze-Risiko nach oben'} (Hinweis)`); }
  if(M.top_ls_position!=null){ if(M.top_ls_position>=1.5) add('buy',1,`Binance Top-Trader netto long (Positionsverhältnis ${(+M.top_ls_position).toFixed(2)})`);
   else if(M.top_ls_position<=0.67) add('sell',1,`Binance Top-Trader netto short (Positionsverhältnis ${(+M.top_ls_position).toFixed(2)})`); }
  if(M.global_ls_account!=null&&M.global_ls_account>=3) add('warn',0,`Binance: ${(+M.global_ls_account).toFixed(1)}× mehr Long- als Short-Konten — einseitig, Kaskadenrisiko nach unten (Hinweis)`);
  const vol=d.bnc.vol_1h||vol1h||0;
  if((LQ.long||0)>=Math.max(vol*0.1,5e6)) add('wait',0,`Binance: ${fmt(LQ.long)} Long-Liquidationen in der letzten Stunde — Verkaufskaskade läuft oder lief gerade`);
  if((LQ.short||0)>=Math.max(vol*0.1,5e6)) add('wait',0,`Binance: ${fmt(LQ.short)} Short-Liquidationen in der letzten Stunde — Kaufkaskade läuft oder lief gerade`);
  const fHL2=(d.funding!=null&&typeof d.funding==='object')?d.funding.funding:d.funding;
  if(d.bnc.funding!=null&&SRC()==='fusion'&&fHL2!=null&&Math.sign(d.bnc.funding)!==Math.sign(+fHL2)&&Math.abs(d.bnc.funding)>0.00002)
   add('warn',0,`Funding gegenläufig: Hyperliquid ${(+fHL2*100).toFixed(4)} %/h, Binance ${(d.bnc.funding*100).toFixed(4)} %/h (Hinweis)`); }

 // 6c. ETF-Flows (BTC/ETH, jede Quelle): Regime-Faktor, ein Punkt
 if(d.etf&&['BTC','ETH'].includes($('coin').value)){ const E=d.etf;
  if(E.last>0&&E.sum5>0) add('buy',1,`ETF-Zuflüsse: ${E.last>0?'+':''}${E.last.toFixed(0)} Mio am ${E.last_date}, 5 Tage +${E.sum5.toFixed(0)} Mio${E.streak>=3?` — ${E.streak}. Zuflusstag in Folge`:''} (${E.source})`);
  else if(E.last<0&&E.sum5<0) add('sell',1,`ETF-Abflüsse: ${E.last.toFixed(0)} Mio am ${E.last_date}, 5 Tage ${E.sum5.toFixed(0)} Mio${E.streak<=-3?` — ${-E.streak}. Abflusstag in Folge`:''} (${E.source})`);
  else add('warn',0,`ETF-Flows uneinheitlich: letzter Tag ${E.last>0?'+':''}${E.last.toFixed(0)} Mio, 5 Tage ${E.sum5>0?'+':''}${E.sum5.toFixed(0)} Mio — kein Punkt`); }
 // 6d. Smart Money: Netto-Ausrichtung der profitabelsten Leaderboard-Konten, ein Punkt
 if(d.smart){ const S=d.smart, c=S.coin, a=S.all, use=(c.n_long+c.n_short)>=5?c:a, scope=(c.n_long+c.n_short)>=5?$('coin').value:'alle Coins';
  if(use.n_long+use.n_short>=5){
   if(use.usd_long>use.usd_short*1.5) add('buy',1,`Smart Money netto long (${scope}): ${use.n_long} Konten ${fmt(use.usd_long)} gegen ${use.n_short} Konten ${fmt(use.usd_short)} — die profitabelsten ${S.n_accounts} Konten der letzten 30 Tage`);
   else if(use.usd_short>use.usd_long*1.5) add('sell',1,`Smart Money netto short (${scope}): ${use.n_short} Konten ${fmt(use.usd_short)} gegen ${use.n_long} Konten ${fmt(use.usd_long)} — die profitabelsten ${S.n_accounts} Konten der letzten 30 Tage`);
   else add('warn',0,`Smart Money ausgeglichen (${scope}): ${use.n_long} long ${fmt(use.usd_long)}, ${use.n_short} short ${fmt(use.usd_short)} — kein Punkt`); } }

 // 6f. Käufe/Verkäufe der Top-50-Konten im gewählten Coin, letzte 24 h: ein Punkt ab 1,5-fachem Übergewicht und mind. 3 Konten
 if(d.lb_act&&d.lb_act.selected){ const S=d.lb_act.selected, b=S.buy_usd_24h, s_=S.sell_usd_24h;
  if(b+s_>=1e6&&S.n_buyers+S.n_sellers>=3){
   if(b>s_*1.5) add('buy',1,`Leaderboard-Konten kaufen ${$('coin').value}: 24 h ${fmt(b)} gekauft gegen ${fmt(s_)} verkauft (Perp + Spot, ${S.n_buyers} Käufer / ${S.n_sellers} Verkäufer)`);
   else if(s_>b*1.5) add('sell',1,`Leaderboard-Konten verkaufen ${$('coin').value}: 24 h ${fmt(s_)} verkauft gegen ${fmt(b)} gekauft (Perp + Spot, ${S.n_sellers} Verkäufer / ${S.n_buyers} Käufer)`);
   else add('warn',0,`Leaderboard-Konten in ${$('coin').value} uneinig: 24 h ${fmt(b)} gekauft, ${fmt(s_)} verkauft — kein Punkt`); } }

 // 6e. Leaderboard-Top-20-Trend im gewählten Coin: Drehung oder starker Aufbau als Hinweis (Punkte gibt Smart Money)
 if(d.lb&&d.lb.summary&&d.lb.trend&&d.lb.trend.length>=2){ const S=d.lb.summary, T=d.lb.trend, now=T[T.length-1].ts;
  const ago=[...T].reverse().find(r=>r.ts<=now-86400)||T[0]; const gross=S.usd_long+S.usd_short;
  if(gross>0){ const delta=S.net_usd-ago.net_usd;
   if(Math.sign(S.net_usd)!==Math.sign(ago.net_usd)&&Math.abs(S.net_usd)>gross*0.1) add('warn',0,`Leaderboard Top 20 in ${$('coin').value} gedreht: von netto ${ago.net_usd>0?'long':'short'} auf netto ${S.net_usd>0?'long':'short'} ${fmt(Math.abs(S.net_usd))} innerhalb 24 h (Hinweis)`);
   else if(Math.abs(delta)>=gross*0.25) add('warn',0,`Leaderboard Top 20 in ${$('coin').value}: netto ${delta>0?'+':'−'}${fmt(Math.abs(delta))} in 24 h — ${delta>0?'Longs bauen auf':'Shorts bauen auf'} (Hinweis)`); } }

 // 7. Gleitende Durchschnitte: Regime, je ein Punkt
 const m=d.mas||{};
 if(m.ma200d_dist!=null){ if(m.ma200d_dist>0) add('buy',1,`Kurs ${(m.ma200d_dist*100).toFixed(1)} % über dem MA 200 Tage (${px(m.ma200d)}) — Regime bullisch`);
  else add('sell',1,`Kurs ${(-m.ma200d_dist*100).toFixed(1)} % unter dem MA 200 Tage (${px(m.ma200d)}) — Regime bärisch`); }
 if(m.ma50w_dist!=null){ if(m.ma50w_dist>0) add('buy',1,`Kurs ${(m.ma50w_dist*100).toFixed(1)} % über dem MA 50 Wochen (${px(m.ma50w)})`);
  else add('sell',1,`Kurs ${(-m.ma50w_dist*100).toFixed(1)} % unter dem MA 50 Wochen (${px(m.ma50w)})`); }
 if(m.cross) add('warn',0,`${m.cross==='golden'?'Golden Cross':'Death Cross'}: MA 50 Tage ${m.cross==='golden'?'über':'unter'} MA 200 Tage (Hinweis, keine Punkte — schon über das Regime erfasst)`);

 // 8. Danger-Time aus der Zeit-Heatmap: keine Richtung, nur Warnung
 if(d.danger) add('warn',0,`Danger-Time: in diesem Wochentag-/Zeitfenster historisch ${d.danger.lift.toFixed(1)}x so oft Bewegungen über ${(d.danger.threshold*100).toFixed(0)} % (belastbar)`);

 const net=buy-sell, waiting=R.some(r=>r.side==='wait');
 let label,color;
 if(waiting&&Math.abs(net)<3){label='ABWARTEN — Cluster-Anlauf';color='#d29922';}
 else if(net>=3){label='KAUF-KONFLUENZ';color='#3ba55d';}
 else if(net<=-3){label='VERKAUFS-KONFLUENZ';color='#e04b4b';}
 else if(net>0){label='leicht bullisch';color='#7ee787';}
 else if(net<0){label='leicht bärisch';color='#ff7b72';}
 else{label='NEUTRAL';color='#c9d1d9';}
 // Zone nur, wenn Richtung und Preisniveau zusammenpassen
 const dir=net>0?'buy':net<0?'sell':null;
 let zone=dir?zones.filter(z=>z.kind===dir)[0]:null, zoneWeg=null;
 // 24.09.: keine Zone GEGEN einen drohenden Anlauf (Stops, Cluster, doppelter Magnet) -- die Zone rückt ans Kaskadenziel,
 // also dorthin, wo der Druck laut Modell aufgefangen wird („erst nach Abholung“). Fehlt ein Ziel, bleibt die Zone weg.
 const drohtAb=R.some(r=>r.side==='wait'&&/Long-Cluster|Sell-Stops|Magnet nach unten/.test(r.text));
 const drohtAuf=R.some(r=>r.side==='wait'&&/Short-Cluster|Buy-Stops|Magnet nach oben/.test(r.text));
 if(dir&&((dir==='buy'&&drohtAb)||(dir==='sell'&&drohtAuf))){
  const C=CM&&CM[dir==='buy'?'down':'up'];
  if(C&&C.target&&C.target.px) zone={kind:dir,bot:C.target.px*(dir==='buy'?0.997:1),top:C.target.px*(dir==='buy'?1:1.003),text:'erst nach Abholung (Kaskadenziel)'};
  else { zone=null; zoneWeg=dir==='buy'?'unten':'oben'; }
 }
 SIGNAL={label,color,net,zone,dir};
 konfluenzMelden(SIGNAL, px0);
 const t=$('kpi_signal'); if(t){t.textContent=label;t.style.color=color;t.title=`Kauf ${buy} · Verkauf ${sell}`;}
 const box=$('signalbox'); if(!box) return;
 const zoneNote=zone
   ?`<div style="margin-top:6px;color:${dir==='buy'?'#3ba55d':'#e04b4b'}">■ Zone im Chart: ${zone.text} ${px(zone.bot)}–${px(zone.top)}</div>`
   :zoneWeg?`<div class="sub" style="margin-top:6px;color:#d29922">Keine Zone: ein Anlauf nach ${zoneWeg} droht, und für das Kaskadenziel fehlt ein Preis -- erst die Abholung abwarten.</div>`
   :(dir?`<div class="sub" style="margin-top:6px">Keine Zone eingezeichnet: die ${dir==='buy'?'Kauf':'Verkaufs'}-Punkte stammen aus Faktoren ohne Preisniveau (Wale, Orderbuch, Funding, RSI). Eine Zone entsteht erst durch ein FVG am Kurs oder ein frisch abgeräumtes Cluster.</div>`:'');
 const ic={buy:'▲',sell:'▼',wait:'⏸',warn:'⚠'}, col={buy:'#3ba55d',sell:'#e04b4b',wait:'#d29922',warn:'#d29922'};
 box.innerHTML=`<div style="font-size:15px;font-weight:600;color:${color};margin-bottom:6px">${label}
   <span style="font-size:11px;color:#8b949e;font-weight:400">· Kauf-Punkte ${buy}, Verkaufs-Punkte ${sell}, netto ${net>0?'+':''}${net}</span></div>`
  +(R.length?R.map(r=>`<div><span style="color:${col[r.side]}">${ic[r.side]}</span> ${r.text}`
    +(r.pts?` <span class="mono">(${r.side==='buy'?'+':'−'}${r.pts})</span>`:'')+`</div>`).join('')
   :'<div class="sub">Kein Faktor aktiv — Kurs ohne Cluster, Lücke oder Extremwert in der Nähe.</div>')
  +zoneNote
  +`<div class="sub" style="margin-top:8px">Schwellen: Konfluenz ab 3 Punkten netto. Cluster zählen ab halbem Stundenvolumen. `
  +`Orderbuch ab 30 % Imbalance, Funding ab −0,005 / +0,01 %/h, direktionale Wale ab 1,5-fachem Übergewicht (Hedges und Market Maker ausgenommen), Smart Money ab 1,5-fachem Übergewicht, ETF-Flows wenn letzter Tag und 5-Tage-Summe dasselbe Vorzeichen haben, Taker-Flow börsenübergreifend ab 1,2 / unter 0,8. Kaskadenprognose: Auslöser = erstes Stop- oder Liquidationscluster ab 25 % des Stundenvolumens; ab dort Druck (Stops + Liquidationen derselben Richtung) gegen Aufnahme (ruhende Limits + 5 % des Stundenvolumens je 0,25-%-Stufe); Ziel = Stufe, auf der die Aufnahme den Druck einholt. Long-Squeeze = nach unten, Short-Squeeze = nach oben. Ein Modell aus sichtbaren Orders, keine Vorhersage. `
  +`MA 200 Tage und MA 50 Wochen je ein Punkt nach Lage des Kurses. Stop-Cluster ab 25 % des Stundenvolumens (mind. 5 Mio) → Abwarten; `
  +`Kauf-/Verkaufswände ab 50 % (mind. 10 Mio) je ein Punkt; Take-Profits als Hinweis. Orders von Konten ab 250k USD.</div>`;
}

let healthTimer=null;
// ---- Chart als PNG exportieren: Neuzeichnung in 3-facher Auflösung, Kopfzeile mit Kontext ----
let EXPORT_DPR=0;
const EXPORT_DRAW={netchart:()=>NET&&drawNet(), netext:()=>NET_EXT&&drawNetExt(), syschart:()=>LAST_SYS&&drawSystem(LAST_SYS), fcchart:()=>LAST_FC&&drawForecast(LAST_FC), chart:()=>LAST_CHART&&drawChart(LAST_CHART), stops:()=>LAST_CHART&&drawStops(LAST_CHART), lbchart:()=>LAST_CHART&&LAST_CHART.lb&&drawLbChart(LAST_CHART.lb), lbact48chart:()=>LAST_CHART&&drawLbAct48(LAST_CHART.lb_act48),
 heat:()=>LAST&&drawHeat(LAST), depth:()=>LAST_DEPTH&&drawDepth(LAST_DEPTH), whalechart:()=>LAST_WHALES&&drawWhales(LAST_WHALES),
 metricschart:()=>{const m=LAST_DATA&&(LAST_DATA.metrics||(LAST_DATA.bnc&&LAST_DATA.bnc.metrics)); if(m) drawMetrics(m);}};
function exportChart(id){
 const c=$(id), draw=EXPORT_DRAW[id]; if(!c||!draw) return;
 const scale=3, title=(c.closest('.panel')&&c.closest('.panel').querySelector('.ttl'))?c.closest('.panel').querySelector('.ttl').textContent:id;
 try{
  EXPORT_DPR=scale; draw();                            // in hoher Auflösung ins sichtbare Canvas zeichnen
  const r=c.getBoundingClientRect(), W=Math.round(r.width), H=Math.round(c.height/scale);
  const head=44, pad=16, out=document.createElement('canvas'); out.width=(W+2*pad)*scale; out.height=(H+head+2*pad)*scale;
  const g=out.getContext('2d'); g.setTransform(scale,0,0,scale,0,0);
  g.fillStyle='#0d1117'; g.fillRect(0,0,W+2*pad,H+head+2*pad);
  g.fillStyle='#c9d1d9'; g.font='bold 14px system-ui'; g.fillText(title, pad, pad+16);
  const meta=`${$('coin').value} · ${SRC_NAME[SRC()]} · ${new Date().toLocaleString('de-DE')} · Hyperliquid-Liquidationscluster`;
  g.fillStyle='#8b949e'; g.font='11px system-ui'; g.fillText(meta, pad, pad+34);
  g.drawImage(c, 0,0,c.width,c.height, pad, pad+head, W, H);   // Backing-Store 1:1 in Exportpixel
  g.strokeStyle='#30363d'; g.lineWidth=1; g.strokeRect(pad+0.5, pad+head+0.5, W-1, H-1);
  const a=document.createElement('a'); const ts=new Date(); const pad2=n=>String(n).padStart(2,'0');
  a.download=`hl_${id}_${$('coin').value}_${SRC()}_${ts.getFullYear()}${pad2(ts.getMonth()+1)}${pad2(ts.getDate())}-${pad2(ts.getHours())}${pad2(ts.getMinutes())}.png`;
  a.href=out.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove();
 }catch(e){ showErr('Export: '+(e.message||e)); }
 finally{ EXPORT_DPR=0; draw(); }                        // zurück auf Bildschirmauflösung
}

// ---- Wal-Liste als PNG: die gruppierte Tabelle wird auf ein Canvas gezeichnet ----
function exportWhaleTable(){
 const d=LAST_WHALES; if(!d||!d.current||!d.current.length){ showErr('Export: keine Wal-Positionen geladen'); return; }
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4);
 const age=s=>{const h=(Date.now()/1000-s)/3600; return h<1?Math.round(h*60)+' min':h<48?h.toFixed(1)+' h':(h/24).toFixed(1)+' T';};
 // Gruppierung wie in der Tabelle
 const groups=new Map();
 d.current.forEach(w=>{ const g=groups.get(w.addr)||{addr:w.addr,rows:[],total:0,long:0,short:0,upnl:0};
   g.rows.push(w); g.total+=w.pos_value||0; g.upnl+=w.upnl||0; if(w.side==='long') g.long+=w.pos_value||0; else g.short+=w.pos_value||0; groups.set(w.addr,g); });
 const ordered=[...groups.values()].sort((a,b)=>b.total-a.total); ordered.forEach(g=>g.rows.sort((a,b)=>(b.pos_value||0)-(a.pos_value||0)));
 // Zeilen aufbauen: [typ, zellen...]
 const cols=[['Wallet / Name',270,'l'],['Coin',60,'l'],['Seite',55,'l'],['Wert',90,'r'],['Hebel',55,'r'],['Einstieg',100,'r'],['Liq.-Preis',100,'r'],['Abstand',75,'r'],['unreal. PnL',95,'r'],['offen seit',80,'l'],['Stand',70,'l']];
 const lines=[];
 ordered.forEach(g=>{ const L=(LABELS||{})[g.addr.toLowerCase()]||{}; const net=g.long-g.short;
   lines.push({type:'grp', a:`${short(g.addr)} · ${g.rows.length} Position${g.rows.length>1?'en':''}`+(L.name?` · ${esc(L.name)}`:''),
     b:(L.behavior||'')+`   Gesamt ${fmt(g.total)} · netto ${net>0?'long':net<0?'short':'neutral'} ${fmt(Math.abs(net))} · PnL ${g.upnl>=0?'+':''}${fmt(g.upnl)}`, netcol:net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9'});
   g.rows.forEach(w=>{ const dist=w.mark_px?(w.liq_px-w.mark_px)/w.mark_px*100:0;
     lines.push({type:'row', hl:w.coin===coin, cells:[short(w.addr), w.coin, w.side, fmt(w.pos_value), (w.leverage||0)+'x', px(w.entry_px||0), px(w.liq_px||0), (dist>0?'+':'')+dist.toFixed(1)+' %', (w.upnl>=0?'+':'')+fmt(w.upnl||0), w.opened_at?age(w.opened_at):'—', age(w.ts)+' alt'],
       colors:[null,null,w.side==='long'?'#3ba55d':'#e04b4b',null,null,null,null,Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':null,(w.upnl||0)>=0?'#3ba55d':'#e04b4b',null,null]}); }); });
 // Seiten: höchstens 600 Zeilen je Bild (Canvas-Grenze), 2-fache Auflösung
 const scale=2, rowH=22, grpH=36, head=64, pad=16, W=cols.reduce((a,c)=>a+c[1],0)+2*pad;
 const pages=[]; let cur=[], h=0;
 lines.forEach(l=>{ const lh=l.type==='grp'?grpH:rowH; if(cur.length&&h+lh>600*rowH){ pages.push(cur); cur=[]; h=0; } cur.push(l); h+=lh; });
 if(cur.length) pages.push(cur);
 const D=d.directional||{}, ts=new Date(), pad2=n=>String(n).padStart(2,'0');
 const stamp=`${ts.getFullYear()}${pad2(ts.getMonth()+1)}${pad2(ts.getDate())}-${pad2(ts.getHours())}${pad2(ts.getMinutes())}`;
 pages.forEach((pg,pi)=>{
  const H=head+28+pg.reduce((a,l)=>a+(l.type==='grp'?grpH:rowH),0)+pad;
  const c=document.createElement('canvas'); c.width=W*scale; c.height=H*scale; const g=c.getContext('2d'); g.setTransform(scale,0,0,scale,0,0);
  g.fillStyle='#0d1117'; g.fillRect(0,0,W,H);
  g.fillStyle='#c9d1d9'; g.font='bold 15px system-ui'; g.fillText(`Wale — Konten ab 10 Mio USD Gesamtwert${pages.length>1?` (Teil ${pi+1} von ${pages.length})`:''}`, pad, pad+16);
  g.fillStyle='#8b949e'; g.font='11px system-ui';
  g.fillText(`${coin} · ${SRC_NAME[SRC()]} · ${ts.toLocaleString('de-DE')} · ${ordered.length} Wallets, ${d.current.length} Positionen`
    +(D.n_directional?` · direktional: ${D.n_long} long ${fmt(D.usd_long)} vs. ${D.n_short} short ${fmt(D.usd_short)}`:''), pad, pad+34);
  // Spaltenköpfe
  let y=head+8; g.fillStyle='#8b949e'; g.font='bold 10px system-ui';
  let x=pad; cols.forEach(([n,w,al])=>{ g.textAlign=al==='r'?'right':'left'; g.fillText(n.toUpperCase(), al==='r'?x+w-6:x+6, y); x+=w; });
  g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(pad,y+6); g.lineTo(W-pad,y+6); g.stroke(); y+=20;
  pg.forEach(l=>{
   if(l.type==='grp'){ g.fillStyle='#1c2128'; g.fillRect(pad,y-2,W-2*pad,grpH-4);
     g.fillStyle='#e3b341'; g.font='bold 12px system-ui'; g.textAlign='left'; g.fillText(l.a, pad+6, y+12);
     g.fillStyle=l.netcol; g.font='11px system-ui'; g.fillText(l.b, pad+6, y+27); y+=grpH; return; }
   if(l.hl){ g.fillStyle='#161b22'; g.fillRect(pad,y-2,W-2*pad,rowH-2); }
   let x=pad; g.font='11px monospace';
   l.cells.forEach((v,i)=>{ const [n,w,al]=cols[i]; g.fillStyle=l.colors[i]||'#c9d1d9'; g.textAlign=al==='r'?'right':'left'; g.fillText(String(v), al==='r'?x+w-6:x+(i===0?18:6), y+13); x+=w; });
   g.strokeStyle='#21262d'; g.beginPath(); g.moveTo(pad,y+rowH-3); g.lineTo(W-pad,y+rowH-3); g.stroke(); y+=rowH; });
  g.textAlign='left';
  const a=document.createElement('a'); a.download=`hl_wale_${coin}_${SRC()}_${stamp}${pages.length>1?`_teil${pi+1}`:''}.png`; a.href=c.toDataURL('image/png');
  setTimeout(()=>{ document.body.appendChild(a); a.click(); a.remove(); }, pi*400);
 });
}

function exportLbTable(){
 const L=LAST_CHART&&LAST_CHART.lb; if(!L||!L.accounts||!L.accounts.length){ showErr('Export: keine Leaderboard-Daten geladen'); return; }
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4), scale=2, rowH=22, grpH=36, head=64, pad=16;
 const cols=[['Rang / Konto',300,'l'],['Coin',60,'l'],['Seite',55,'l'],['Wert',90,'r'],['Hebel',55,'r'],['Einstieg',100,'r'],['Liq.-Preis',100,'r'],['Abstand',75,'r'],['unreal. PnL',95,'r'],['Kurs',90,'r']];
 const W=cols.reduce((a,c)=>a+c[1],0)+2*pad, lines=[];
 L.accounts.forEach(a=>{ const net=a.positions.reduce((s,p)=>s+(p.side==='long'?1:-1)*(p.pos_value||0),0);
  lines.push({type:'grp', a:`#${a.rank} ${a.name?a.name+' · ':''}${short(a.addr)} · ${a.positions.length} Position${a.positions.length!==1?'en':''}`, b:`Kontowert ${fmt(a.account_value)} · PnL 30 T +${fmt(a.pnl_30d)} (${(a.roi_30d*100).toFixed(0)} %) · 7 T ${a.pnl_7d>=0?'+':''}${fmt(a.pnl_7d)} · Positionen ${fmt(a.pos_total)} · netto ${net>0?'long':net<0?'short':'—'} ${fmt(Math.abs(net))} · unreal. PnL ${a.upnl>=0?'+':''}${fmt(a.upnl)}`, netcol:net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9'});
  a.positions.forEach(p=>{ const dist=p.mark_px?(p.liq_px-p.mark_px)/p.mark_px*100:0;
   lines.push({type:'row', hl:p.coin===coin, cells:[`#${a.rank}`, p.coin, p.side, fmt(p.pos_value), (p.leverage||0)+'x', px(p.entry_px||0), p.liq_px?px(p.liq_px):'—', p.liq_px?(dist>0?'+':'')+dist.toFixed(1)+' %':'—', (p.upnl>=0?'+':'')+fmt(p.upnl||0), p.mark_px?px(p.mark_px):'—'],
     colors:[null,null,p.side==='long'?'#3ba55d':'#e04b4b',null,null,null,null,Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':null,(p.upnl||0)>=0?'#3ba55d':'#e04b4b',null]}); }); });
 const H=head+28+lines.reduce((a,l)=>a+(l.type==='grp'?grpH:rowH),0)+pad, c=document.createElement('canvas'); c.width=W*scale; c.height=H*scale;
 const g=c.getContext('2d'); g.setTransform(scale,0,0,scale,0,0); g.fillStyle='#0d1117'; g.fillRect(0,0,W,H);
 g.fillStyle='#c9d1d9'; g.font='bold 15px system-ui'; g.fillText('Hyperliquid-Leaderboard Top 20 — Positionen und PnL', pad, pad+16);
 const S=L.summary||{}; g.fillStyle='#8b949e'; g.font='11px system-ui'; g.fillText(`${coin} · ${new Date().toLocaleString('de-DE')} · Stand ${hm(L.ts)} · in ${coin}: ${S.n_long||0} long ${fmt(S.usd_long||0)} vs. ${S.n_short||0} short ${fmt(S.usd_short||0)}`, pad, pad+34);
 let y=head+8; g.fillStyle='#8b949e'; g.font='bold 10px system-ui'; let x=pad; cols.forEach(([n,w,al])=>{ g.textAlign=al==='r'?'right':'left'; g.fillText(n.toUpperCase(), al==='r'?x+w-6:x+6, y); x+=w; });
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(pad,y+6); g.lineTo(W-pad,y+6); g.stroke(); y+=20;
 lines.forEach(l=>{ if(l.type==='grp'){ g.fillStyle='#1c2128'; g.fillRect(pad,y-2,W-2*pad,grpH-4); g.fillStyle='#e3b341'; g.font='bold 12px system-ui'; g.textAlign='left'; g.fillText(l.a,pad+6,y+12); g.fillStyle=l.netcol; g.font='11px system-ui'; g.fillText(l.b,pad+6,y+27); y+=grpH; return; }
  if(l.hl){ g.fillStyle='#161b22'; g.fillRect(pad,y-2,W-2*pad,rowH-2); } let x=pad; g.font='11px monospace';
  l.cells.forEach((v,i)=>{ const [n,w,al]=cols[i]; g.fillStyle=l.colors[i]||'#c9d1d9'; g.textAlign=al==='r'?'right':'left'; g.fillText(String(v), al==='r'?x+w-6:x+(i===0?18:6), y+13); x+=w; });
  g.strokeStyle='#21262d'; g.beginPath(); g.moveTo(pad,y+rowH-3); g.lineTo(W-pad,y+rowH-3); g.stroke(); y+=rowH; });
 g.textAlign='left'; const ts=new Date(), p2=n=>String(n).padStart(2,'0');
 const a=document.createElement('a'); a.download=`hl_leaderboard_${coin}_${ts.getFullYear()}${p2(ts.getMonth()+1)}${p2(ts.getDate())}-${p2(ts.getHours())}${p2(ts.getMinutes())}.png`; a.href=c.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove();
}

// ---- Abschnitte ein-/ausklappen, Zustand im Browser gemerkt ----------------------
// Konto als Link auf HypurrScan (22.09.): Name oder Kurzadresse, neuer Tab
function hsLink(addr, inner){ return `<a href="https://hypurrscan.io/address/${esc(addr)}" target="_blank" rel="noopener" style="color:#58a6ff;text-decoration:none" title="${esc(addr)} auf HypurrScan öffnen">${inner}</a>`; }
function secState(){ try{ return JSON.parse(localStorage.getItem('hl_sec')||'{}'); }catch(e){ return {}; } }
function applySec(){
 const st=secState();
 document.querySelectorAll('.panel[data-sec]').forEach(p=>p.classList.toggle('closed', !!st[p.dataset.sec]));
}
function toggleSec(key){
 const p=document.getElementById('sec-'+key); if(!p) return;
 const st=secState(); st[key]=!p.classList.contains('closed'); p.classList.toggle('closed', st[key]);
 try{ localStorage.setItem('hl_sec', JSON.stringify(st)); }catch(e){}
 if(!st[key]){ setTimeout(load,50); }          // beim Aufklappen neu zeichnen
 if(!st[key]&&key==='labor'&&typeof laborLaden==='function') setTimeout(()=>laborLaden(true),60);
 if(!st[key]&&key==='makro'&&typeof mkLaden==='function') setTimeout(()=>mkLaden(false),60);     // 23.47 Makro-Chart
}
function toggleAll(){
 const ps=[...document.querySelectorAll('.panel[data-sec]')], anyOpen=ps.some(p=>!p.classList.contains('closed'));
 const st={}; ps.forEach(p=>{ st[p.dataset.sec]=anyOpen; p.classList.toggle('closed', anyOpen); });
 try{ localStorage.setItem('hl_sec', JSON.stringify(st)); }catch(e){}
 if(!anyOpen) setTimeout(load,50);
}
function applySrcLabels(){
 const src=SRC(), n=SRC_NAME[src];
 const set=(sel,txt)=>{ const e=document.querySelector(sel); if(e) e.textContent=txt; };
 set('#sec-chart .ttl', src==='hl'?'Live-Chart — Kurs mit aktuellen Liquidationsmarken':src==='bnc'?'Live-Chart (Binance) — Kurs mit eingetretenen Liquidationen':'Live-Chart (Data Mix Fusion) — HL-Marken, Liquidationen beider Börsen');
 set('#sec-orders .ttl', src==='hl'?'Wartende Orders und Stops — Konten ab 250k USD':src==='bnc'?'Orderbuch Binance — Tiefe je Preisstufe':'Orders (Data Mix Fusion) — HL-Konten + Orderbücher Binance und Crypto.com je Preisstufe summiert');
 set('#sec-heat .ttl', src==='hl'?'Heatmap — Clusterentwicklung über die Zeit':src==='bnc'?'Heatmap (Binance) — eingetretene Liquidationen über die Zeit':'Heatmap (Data Mix Fusion) — HL-Cluster, Binance-Liquidationen orange');
 set('#sec-depth .ttl', src==='hl'?'Momentaufnahme — Cluster rund um den aktuellen Kurs':src==='bnc'?'Momentaufnahme (Binance) — Liquidationen der letzten 24 h um den Kurs':'Momentaufnahme (Data Mix Fusion) — HL-Cluster, Binance eingetreten orange');
 set('#sec-whales .ttl', src==='hl'?'Wale — Konten ab 10 Mio. USD Gesamtwert':src==='bnc'?'Binance und Crypto.com — Open Interest, Long/Short, Taker-Flow':'Wale (HL), Kennzahlen Binance und Crypto.com');
 set('#sec-signal .ttl', src==='hl'?'Konfluenz — welche Faktoren zeigen in dieselbe Richtung?':`Konfluenz (${n}) — welche Faktoren zeigen in dieselbe Richtung?`);
 document.body.dataset.src=src;
}
function toggleHelp(a){
 const h=a.closest('.panel').querySelector('.sub.help'); if(!h) return;
 h.style.display=h.style.display==='none'?'block':'none';
}
applySec();

// ---- AI-Prognose: alle 5 min nachfragen (Server rechnet alle 15 min) -------------------------
let LAST_FC=null, FC_COIN='';
async function loadForecast(){
 const coin=$('coin').value;
 try{ const fc=await getJSON('/forecast?coin='+encodeURIComponent(coin)); LAST_FC=fc; FC_COIN=coin; drawForecast(fc); }catch(e){}
 verlaufLaden(false);
}
// ---------------------------------------------------------------------------
// Verlauf der Treiber (23.09.): Bias (dick) und gewählte Treiber der letzten 24/72 h unter dem Kurs, Ereignisse
// (Rutsch rot, Anstieg grün) nach der Definition der Ereignis-Profile. Rein beschreibend, keine Vorhersage.
// ---------------------------------------------------------------------------
let VL={h:72, daten:null, coin:null, t:0, wahl:null, wahlCoin:null};
const VL_FARBEN=['#58a6ff','#d29922','#a371f7','#3fb950','#f778ba','#79c0ff','#ffa657','#56d4dd'];
async function verlaufLaden(force){
 const coin=FC_COIN||$('coin').value;
 if(!force&&VL.daten&&VL.coin===coin&&VL.daten.stunden===VL.h&&Date.now()-VL.t<300000){ verlaufZeichnen(); return; }
 try{ VL.daten=await getJSON('/verlauf?coin='+encodeURIComponent(coin)+'&h='+VL.h); VL.coin=coin; VL.t=Date.now(); }catch(e){ return; }
 if(!VL.wahl||VL.wahlCoin!==coin){ VL.wahl=Object.entries(VL.daten.aktuell||{}).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1])).slice(0,4).map(x=>x[0]); VL.wahlCoin=coin; }
 verlaufZeichnen();
}
function verlaufWahl(nm){ const i=VL.wahl.indexOf(nm); if(i>=0) VL.wahl.splice(i,1); else VL.wahl.push(nm); verlaufZeichnen(); }
function verlaufZeichnen(){
 const el=$('verlauf'), D=VL.daten; if(!el||!D) return;
 const esc=x=>String(x).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const t=D.t||[];
 const knopf=h=>`<button class="tog ${VL.h===h?'on':'off'}" data-vlh="${h}">${h} h</button>`;
 let kopf=`<div class="sub" style="margin:4px 0">Verlauf der Treiber ${knopf(24)} ${knopf(72)} — oben der Kurs, unten <b style="color:#fff">Bias</b> (dick) und die gewählten Treiber (−1 … +1). Rote/grüne Bänder: Rutsch/Anstieg nach der Definition der Ereignis-Profile, erst 4 h später erkennbar. Rein beschreibend, keine Vorhersage.</div>`;
 if(t.length<2){ el.innerHTML=kopf+'<div class="sub">Noch zu wenige gespeicherte Prognosen für einen Verlauf.</div>'; verlaufKlicks(el); return; }
 const W=420, H=250, L=46, R=6, T1=6, H1=70, T2=T1+H1+12, H2=H-T2-22;
 const t0=D.ts-D.stunden*3600, t1=D.ts, X=v=>L+(v-t0)/(t1-t0)*(W-L-R);
 const pv=(D.px||[]).filter(v=>v), lo=Math.min(...pv), hi=Math.max(...pv), Yp=v=>T1+(hi-v)/((hi-lo)||1)*H1, Ys=v=>T2+(1-Math.max(-1,Math.min(1,v)))/2*H2;
 const pfad=(ys,f)=>{ let d='',an=false; t.forEach((x,i)=>{ const y=ys[i]; if(y==null){ an=false; return; } d+=(an?'L':'M')+X(x).toFixed(1)+','+f(y).toFixed(1); an=true; }); return d; };
 let s=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:900px;height:auto;display:block" font-size="9" fill="#8b949e">`;
 (D.ereignisse||[]).forEach(e=>{ if(e.ts<t0) return; const x0=X(e.ts), x1=Math.min(X(e.ts+4*3600),W-R), f=e.dir==='ab'?'#e04b4b':'#3ba55d';
   s+=`<rect x="${x0.toFixed(1)}" y="${T1}" width="${Math.max(x1-x0,1).toFixed(1)}" height="${H-22-T1}" fill="${f}" opacity="0.14"><title>${e.dir==='ab'?'Rutsch':'Anstieg'} ab ${hm(e.ts)} (${e.z>0?'+':''}${e.z} σ in 4 h)</title></rect><line x1="${x0.toFixed(1)}" x2="${x0.toFixed(1)}" y1="${T1}" y2="${H-22}" stroke="${f}" stroke-dasharray="3,3"/>`; });
 s+=`<text x="${L-3}" y="${T1+7}" text-anchor="end">${px(hi)}</text><text x="${L-3}" y="${T1+H1}" text-anchor="end">${px(lo)}</text>`;
 s+=`<path d="${pfad(D.px,Yp)}" fill="none" stroke="#c9d1d9" stroke-width="1.3"/>`;
 [1,0.5,0,-0.5,-1].forEach(v=>{ s+=`<line x1="${L}" x2="${W-R}" y1="${Ys(v).toFixed(1)}" y2="${Ys(v).toFixed(1)}" stroke="#30363d"${v===0?'':' stroke-dasharray="2,4"'}/><text x="${L-3}" y="${(Ys(v)+3).toFixed(1)}" text-anchor="end">${v>0?'+':''}${v}</text>`; });
 VL.wahl.forEach((nm,i)=>{ const ys=(D.treiber||{})[nm]; if(ys) s+=`<path d="${pfad(ys,Ys)}" fill="none" stroke="${VL_FARBEN[i%VL_FARBEN.length]}" stroke-width="1.1"/>`; });
 s+=`<path d="${pfad(D.bias||[],Ys)}" fill="none" stroke="#ffffff" stroke-width="2"/>`;
 const schritt=D.stunden>36?12*3600:6*3600;
 for(let x=Math.ceil(t0/schritt)*schritt; x<=t1; x+=schritt){ const d=new Date(x*1000), lab=(d.getHours()===0?d.getDate()+'.'+(d.getMonth()+1)+'. ':'')+hm(x);
   s+=`<line x1="${X(x).toFixed(1)}" x2="${X(x).toFixed(1)}" y1="${H-22}" y2="${H-18}" stroke="#8b949e"/><text x="${X(x).toFixed(1)}" y="${H-8}" text-anchor="middle">${lab}</text>`; }
 s+='</svg>';
 const akt=D.aktuell||{}, alle=Object.keys(D.treiber||{}).sort((a,b)=>Math.abs(akt[b]||0)-Math.abs(akt[a]||0));
 let leg='<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">';
 alle.forEach(nm=>{ const i=VL.wahl.indexOf(nm), c=i>=0?VL_FARBEN[i%VL_FARBEN.length]:null;
   leg+=`<span class="tog ${c?'on':'off'}" data-vlnm="${esc(nm)}" style="cursor:pointer${c?';border-color:'+c+';color:'+c:''}">${esc(nm)}${akt[nm]!=null?' '+(akt[nm]>0?'+':'')+akt[nm].toFixed(2):''}</span>`; });
 el.innerHTML=kopf+s+leg+'</div>'+(D.fehler?`<div class="sub">Ereignis-Markierung nicht verfügbar: ${esc(D.fehler)}</div>`:'');
 verlaufKlicks(el);
}
function verlaufKlicks(el){ el.onclick=ev=>{ const n=ev.target.closest('[data-vlnm]'); if(n){ verlaufWahl(n.dataset.vlnm); return; }
  const h=ev.target.closest('[data-vlh]'); if(h){ VL.h=+h.dataset.vlh; verlaufLaden(true); } }; }
// Sichtfenster des Prognose-Charts: Start (Stunden relativ zu jetzt, -48..) und Spanne (Stunden)
let FC_VIEW={start:-48, span:216};
function fcClamp(){ FC_VIEW.span=Math.max(6,Math.min(216,FC_VIEW.span)); FC_VIEW.start=Math.max(-48,Math.min(168-FC_VIEW.span,FC_VIEW.start)); }
function fcSetSpan(span){ FC_VIEW.span=span; FC_VIEW.start=span>=216?-48:-Math.round(span/4); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); }   // Vorgaben: ein Viertel Vergangenheit, drei Viertel Prognose
function fcPan(dh){ FC_VIEW.start+=dh; fcClamp(); if(LAST_FC) drawForecast(LAST_FC); }
function fcInit(){
 document.querySelectorAll('.fcz').forEach(b=>b.onclick=()=>fcSetSpan(+b.dataset.span));
 $('fcprev').onclick=()=>fcPan(-Math.round(FC_VIEW.span/3)); $('fcnext').onclick=()=>fcPan(Math.round(FC_VIEW.span/3)); $('fcnow').onclick=()=>{ FC_VIEW.start=Math.max(-48,-Math.round(FC_VIEW.span/4)); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); };
 const c=$('fcchart'); let drag=null, pinch=null;
 const hpx=()=>{ const G=GEO.fc; return G?G.pw/FC_VIEW.span:1; };   // Pixel je Stunde
 c.addEventListener('mousedown',e=>{ drag={x:e.clientX,start:FC_VIEW.start}; c.style.cursor='grabbing'; });
 addEventListener('mousemove',e=>{ if(drag){ FC_VIEW.start=drag.start-(e.clientX-drag.x)/hpx(); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); } });
 addEventListener('mouseup',()=>{ if(drag){ drag=null; c.style.cursor='grab'; } });
 c.addEventListener('mousemove',e=>{ if(!drag) fcCrosshair(e.clientX); });
 c.addEventListener('mouseleave',()=>{ if(LAST_FC) drawForecast(LAST_FC); });
 c.addEventListener('wheel',e=>{ e.preventDefault(); const r=c.getBoundingClientRect(), G=GEO.fc; if(!G) return; const hx=FC_VIEW.start+(e.clientX-r.left-G.Lm)/G.pw*FC_VIEW.span;
  const f=e.deltaY>0?1.25:0.8; const ns=Math.max(6,Math.min(216,FC_VIEW.span*f)); FC_VIEW.start=hx-(hx-FC_VIEW.start)*ns/FC_VIEW.span; FC_VIEW.span=ns; fcClamp(); if(LAST_FC) drawForecast(LAST_FC); },{passive:false});
 c.addEventListener('touchstart',e=>{ if(e.touches.length===1){ drag={x:e.touches[0].clientX,start:FC_VIEW.start,moved:false}; } else if(e.touches.length===2){ pinch={d:Math.abs(e.touches[0].clientX-e.touches[1].clientX),span:FC_VIEW.span}; drag=null; } },{passive:true});
 c.addEventListener('touchmove',e=>{ if(pinch&&e.touches.length===2){ const d=Math.abs(e.touches[0].clientX-e.touches[1].clientX); FC_VIEW.span=pinch.span*pinch.d/Math.max(d,10); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); return; }
  if(drag&&e.touches.length===1){ const dx=e.touches[0].clientX-drag.x; if(Math.abs(dx)>4) drag.moved=true; FC_VIEW.start=drag.start-dx/hpx(); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); } },{passive:true});
 c.addEventListener('touchend',e=>{ if(drag&&!drag.moved&&e.changedTouches.length){ fcCrosshair(e.changedTouches[0].clientX); setTimeout(()=>{ if(LAST_FC) drawForecast(LAST_FC); },2500); } drag=null; if(e.touches.length<2) pinch=null; },{passive:true});
}
function fcCrosshair(clientX){
 const G=GEO.fc, fc=LAST_FC, c=$('fcchart'); if(!G||!fc) return; const r=c.getBoundingClientRect(); const x=clientX-r.left; if(x<G.Lm||x>G.W-G.R) return;
 const h=Math.round(FC_VIEW.start+(x-G.Lm)/G.pw*FC_VIEW.span); drawForecast(fc);
 const g=c.getContext('2d'), d=devicePixelRatio||1; g.save(); g.setTransform(d,0,0,d,0,0);
 const X=t=>G.Lm+((t-fc.ts)/3600-FC_VIEW.start)/FC_VIEW.span*G.pw, xx=X(fc.ts+h*3600);
 g.strokeStyle='rgba(201,209,217,0.55)'; g.setLineDash([4,3]); g.beginPath(); g.moveTo(xx,G.T); g.lineTo(xx,G.T+G.ph); g.stroke(); g.setLineDash([]);
 let lines=[];
 if(h<=0){ const hist=fc.history||[]; const pt=hist.reduce((a,b)=>Math.abs(b.t-(fc.ts+h*3600))<Math.abs(a.t-(fc.ts+h*3600))?b:a,hist[0]); if(pt) lines=[`${hm(pt.t)}`,`Kurs ${px(pt.c)}`]; }
 else { const p=fc.path[Math.min(fc.path.length-1,h)], b=fc.band[Math.min(fc.band.length-1,h)]; lines=[`+${h} h · ${hm(fc.ts+h*3600)}`,`Prognose ${px(p.px)} (${((p.px/fc.price-1)*100).toFixed(2)} %)`,`Band ${px(b.lo)} – ${px(b.hi)}`]; if(p.px_model!=null) lines.push(`reines Modell ${px(p.px_model)}`); }
 g.font='11px system-ui'; const w=Math.max(...lines.map(l=>g.measureText(l).width))+14, bx=Math.min(xx+8,G.W-G.R-w), by=G.T+6;
 g.fillStyle='rgba(22,27,34,0.95)'; g.fillRect(bx,by,w,lines.length*15+8); g.strokeStyle='#30363d'; g.strokeRect(bx+0.5,by+0.5,w-1,lines.length*15+7);
 g.fillStyle='#c9d1d9'; g.textAlign='left'; lines.forEach((l,i)=>g.fillText(l,bx+7,by+15+i*15)); g.restore();
}
// ---------------------------------------------------------------------------
// Treiber-Signale (22.09.): Pfeile bei Änderung, Doppelpfeil ab 0,5, Blitz bei Umschwung, Töne.
// Verlauf je Coin und Treiber in localStorage (60 min), Vergleich nur bei NEUER Prognose (fc.ts).
// ---------------------------------------------------------------------------
const SIG={STARK:0.5, MIN:0.05, FENSTER:600, TOPN:5};
function sigHist(coin){ try{ return JSON.parse(localStorage.getItem('hl_drvhist_'+coin)||'{}'); }catch(e){ return {}; } }
function sigSave(coin,h){ try{ localStorage.setItem('hl_drvhist_'+coin, JSON.stringify(h)); }catch(e){} }
let TON={on:(localStorage.getItem('hl_ton')||'0')==='1', ctx:null};
function tonCtx(){ if(!TON.ctx){ try{ TON.ctx=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ return null; } } if(TON.ctx.state==='suspended') TON.ctx.resume().catch(()=>{}); return TON.ctx; }
function tonSirene(sek){ const c=tonCtx(); if(!c) return; const t0=c.currentTime, g=c.createGain(); g.gain.setValueAtTime(0.0001,t0); g.gain.linearRampToValueAtTime(0.25,t0+0.1); g.gain.setValueAtTime(0.25,t0+sek-0.2); g.gain.linearRampToValueAtTime(0.0001,t0+sek); g.connect(c.destination);
 const o=c.createOscillator(); o.type='sawtooth'; o.frequency.setValueAtTime(600,t0); for(let t=0;t<sek;t+=0.5){ o.frequency.linearRampToValueAtTime(1200,t0+t+0.25); o.frequency.linearRampToValueAtTime(600,t0+t+0.5); } o.connect(g); o.start(t0); o.stop(t0+sek); }
function tonKasse(sek){ const c=tonCtx(); if(!c) return; const t0=c.currentTime;
 // Ratsche (gefiltertes Rauschen) + zwei Glockentöne, zweimal im Abstand von 0,35 s, ausklingend bis sek
 const n=c.createBuffer(1, c.sampleRate*0.12, c.sampleRate), d=n.getChannelData(0); for(let i=0;i<d.length;i++) d[i]=(Math.random()*2-1)*(1-i/d.length);
 [0,0.35].forEach(dt=>{ const src=c.createBufferSource(); src.buffer=n; const f=c.createBiquadFilter(); f.type='highpass'; f.frequency.value=2500; const g=c.createGain(); g.gain.value=0.15; src.connect(f); f.connect(g); g.connect(c.destination); src.start(t0+dt);
  [1568,2093].forEach((fr,k)=>{ const o=c.createOscillator(); o.type='sine'; o.frequency.value=fr; const g2=c.createGain(); g2.gain.setValueAtTime(0.0001,t0+dt+0.02); g2.gain.exponentialRampToValueAtTime(0.22,t0+dt+0.04); g2.gain.exponentialRampToValueAtTime(0.0001,t0+dt+Math.max(0.6,sek-dt)); o.connect(g2); g2.connect(c.destination); o.start(t0+dt+0.02); o.stop(t0+dt+Math.max(0.6,sek-dt)+0.05); }); }); }
function tonSchalter(){ TON.on=!TON.on; localStorage.setItem('hl_ton',TON.on?'1':'0'); if(TON.on) tonCtx(); tonAnzeige(); }
function tonAnzeige(){ const b=$('tonbtn'); if(b){ b.textContent=TON.on?'🔔 Töne an':'🔕 Töne aus'; b.className='tog '+(TON.on?'on':'off'); } }
document.addEventListener('click',()=>{ if(TON.on) tonCtx(); },{once:false});
function sigBewerten(fc){
 // Liefert je Treiber {pfeil:'▲'|'▼'|'▲▲'|'▼▼'|'', blitz:'rot'|'gruen'|null} und löst Töne aus.
 const coin=fc.coin||$('coin').value, H=sigHist(coin), now=fc.ts, out={}; const alle=(fc.drivers||[]).concat(fc.inaktiv||[]);
 const neu=(H._ts||0)!==now;                                    // nur bei neuer Prognose Verlauf fortschreiben
 let tonNeg=false, tonPos=false;
 const gewichtet=(fc.drivers||[]).slice().sort((a,b)=>Math.abs(b.score*b.weight)-Math.abs(a.score*a.weight)).slice(0,SIG.TOPN).map(d=>d.name);
 const umschwung={rot:[], gruen:[]};
 alle.forEach(d=>{
  const key=d.name, rec=H[key]||{v:[]}; const sc=d.score==null?null:d.score;
  const prev=[...rec.v].reverse().find(x=>x.t!==now)||null;      // VORIGE Prognose (22.09.: vorher der eigene Eintrag beim Nachladen -> Pfeil verschwand nach 60 s)
  let pfeil='', blitz=null;
  if(prev&&sc!=null&&prev.s!=null){ const dlt=sc-prev.s; if(Math.abs(dlt)>=SIG.MIN) pfeil=(Math.abs(dlt)>=SIG.STARK?(dlt>0?'▲▲':'▼▼'):(dlt>0?'▲':'▼')); }
  // 1) seltener Treiber springt an: Ereignis-Marke wechselt von aus auf an
  if(neu&&d.ereignis===true&&!(prev&&prev.e)&&sc!=null){ if(sc<0) tonNeg=true; else if(sc>0) tonPos=true; }
  // 3) Umschwung: Top-Treiber fällt/steigt binnen 10 min um >= 0,5
  if(sc!=null&&gewichtet.includes(key)){ const alt=rec.v.filter(x=>x.t>=now-SIG.FENSTER&&x.t!==now&&x.s!=null); if(alt.length){ const ref=alt[0].s; if(ref-sc>=SIG.STARK) umschwung.rot.push(key); else if(sc-ref>=SIG.STARK) umschwung.gruen.push(key); } }
  out[key]={pfeil, blitz:null};
  if(neu){ rec.v.push({t:now, s:sc, e:d.ereignis===true}); rec.v=rec.v.filter(x=>x.t>=now-3600); H[key]=rec; }
 });
 if(umschwung.rot.length>=2){ umschwung.rot.forEach(k=>out[k].blitz='rot'); if(neu) tonNeg=true; }
 if(umschwung.gruen.length>=2){ umschwung.gruen.forEach(k=>out[k].blitz='gruen'); if(neu) tonPos=true; }
 if(neu){ H._ts=now; sigSave(coin,H); if(TON.on){ if(tonNeg) tonSirene(5); else if(tonPos) tonKasse(3); } }
 return out;
}
function drawForecast(fc){
 const c=$('fcchart'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H);
 const guide=$('fcguide'), drv=$('fcdrivers'), info=$('fcinfo');
 if(!fc||fc.error||!fc.path){ if(W){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText(fc&&fc.error?('Prognose nicht berechenbar: '+fc.error):'Prognose wird berechnet …',12,24); }
  guide.innerHTML=''; drv.innerHTML=''; info.textContent=fc&&fc.error?'':'erste Berechnung läuft — braucht etwa eine Minute nach dem Start'; return; }
 const p0=fc.price, B=fc.buy, S=fc.sell, O=fc.outlook, col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9', sg=v=>(v>=0?'+':'')+v.toFixed(2)+' %';
 // ---- Guide-Kacheln ----
 guide.innerHTML=`<div title="Gewichteter Richtungsdruck aller Treiber, −1 bis +1"><span>Bias</span><b style="color:${col(fc.bias)}">${fc.label}<span class="d">${fc.bias>=0?'+':''}${fc.bias.toFixed(2)} · Konfidenz ${(fc.confidence*100).toFixed(0)} %</span></b></div>`
  +(fc.p_up!=null?`<div title="Wahrscheinlichkeit, dass der Kurs in 4 h höher steht. v1 = altes Modell (trägt die Prognose, solange v2 im Schatten ist); v2 = K2-Neubau (hl_kalib), parallel gerechnet -- beide werden 4 h später direkt bewertet (Kachel Kalibrierung v2)"><span>P(aufwärts 4 h) — v1 gegen v2</span><b><span style="color:${fc.kalib==='v2'?'#8b949e':'#e6edf3'}">v1 ${((fc.p_up_v1!=null?fc.p_up_v1:fc.p_up)*100).toFixed(1)} %</span> · <span style="color:${fc.kalib==='v2'?'#e6edf3':'#58a6ff'}">v2 ${fc.p_up_v2!=null?(fc.p_up_v2*100).toFixed(1)+' %':(fc.kalib2&&fc.kalib2.fehler?'Fehler: '+esc(fc.kalib2.fehler):fc.kalib2&&fc.kalib2.zu_wenig?`zu wenige Fälle (${fc.kalib2.n} von ${fc.kalib2.min_faelle||30}; ${fc.kalib2.n_bloecke||0} Blöcke, ${fc.kalib2.tol_ausgelassen||0} unter Toleranz)`:'noch nicht kalibriert (erster Lernzyklus ≤ 15 min)')}</span>${fc.kalib==='v2'?' <span class="lbl-ev">v2 AKTIV</span>':' <span class="lbl-ev off">v2 Schatten</span>'}<span class="d">24 h: v1 ${fc.p_up_24!=null?(fc.p_up_24*100).toFixed(1)+' %':'—'} · v2 ${fc.p_up_24_v2!=null?(fc.p_up_24_v2*100).toFixed(1)+' %':'—'}${fc.kalib2&&fc.kalib2.n_eff!=null?' · v2-Modell: n_eff '+fc.kalib2.n_eff+', Prior-Anteil '+((fc.kalib2.prior_anteil||0)*100).toFixed(0)+' %':''}</span></b></div>`:'')
  +(()=>{ const FU=fc.fusion, K=fc.kosten||{}; if(!FU) return '';
     const q=x=>x==null?'—':(x*100).toFixed(1)+' %';
     const ant=A=>A&&Object.keys(A).length?Object.entries(A).sort((a,b)=>b[1]-a[1]).map(([m,v])=>m+' '+(v*100).toFixed(0)+' %').join(' · '):'—';
     const sw=h=>K['p_taker_'+h]==null?'—':'Taker '+(K['p_taker_'+h]>=1?'unerreichbar':q(K['p_taker_'+h]))+' / Maker '+(K['p_maker_'+h]>=1?'unerreichbar':q(K['p_maker_'+h]));
     const ueber=(p,h)=>{ const s_=K['p_taker_'+h]; if(p==null||s_==null) return ''; const r_=Math.max(p,1-p); return r_>=s_?` <span style="color:#3ba55d">(Fusion ${q(r_)} für ihre Richtung: darüber)</span>`:` (Fusion ${q(r_)} für ihre Richtung: darunter)`; };
     const fe=(FU.fehler&&FU.fehler.length?' · Fehler: '+esc(FU.fehler.join('; ')):'')+(K.fehler?' · Kosten: '+esc(K.fehler):'');
     return `<div title="Fusionsprognose (hl_fusion, Schatten, wirkt nicht auf die angezeigte Prognose): Mischung der Experten Basisrate, v1, v2, v3 und Analog-Suche. Die Gewichte lernen nach jedem 4-h- bzw. 24-h-Block aus dem Log-Verlust (Bayes-Mischung, schlafende Experten, Fixed Share); jede Zahl steht fest, bevor das Ergebnis bekannt ist. Anteile = Gewicht der Experten an dieser Zahl. Kostenschwelle: nötige Trefferquote p* = 1/2 + Kosten / (2 · E|r|), E|r| = mittlere Bewegung des Coins in den letzten 30 Tagen, Kosten = Hin- und Rückweg (Taker: Gebühr plus halber Spread; Maker: Gebühr). Darüber = die Fusion sagt mehr Vorsprung, als die Kosten fressen."><span>P(aufwärts) Fusion — Schatten</span><b>4 h ${q(FU.p_4)} · 24 h ${q(FU.p_24)}<span class="d">Anteile 4 h: ${ant(FU.anteile_4)}${fc.p_up_v3!=null?' · v3 allein '+q(fc.p_up_v3):''}<br>Kostenschwelle 4 h: ${sw(4)}${ueber(FU.p_4,4)} · 24 h: ${sw(24)}${ueber(FU.p_24,24)}${K.er_4!=null?' · E|r| 4 h '+(K.er_4*100).toFixed(2)+' %':''}${fe}</span></b></div>`; })()
  +(()=>{ const KA=fc.kaskade_info, KK=fc.kaskade||{}; if(!KA&&!KK.fehler) return '';
     const tt='Kaskaden-Gleichung (hl_kaskade, Schatten, wirkt nicht auf die Prognose): Erreicht der Kurs Liquidationscluster der Heatmap, verschiebt ihn der erzwungene Fluss nach dem Wurzelgesetz I = Y · σ_Tag · √(Q / V_Tag) weiter; reicht das bis zum nächsten Cluster, läuft die Kaskade weiter. Kipppunkt = Kurs, ab dem ein Rutsch (bzw. Anstieg) eine Kaskade auslöst, die mindestens 0,5 σ(4 h) weiter trägt; Ende = wo sie stoppt. Y wird je Coin aus der Historie geschätzt und gilt erst mit Placebo und Seitenspiegel als belegt; bis dahin Y = 1 aus der Literatur. P(Rutsch ≥ 2 σ) nach Modell, seit 23.44 mit gemischter Schwankung (die Schwankung einer Stunde streut um die gemessene; ohne die Mischung kamen große Ausschläge auf dem Pi doppelt so oft vor wie vorhergesagt); ohne Heatmap = derselbe Zufallsweg ohne die Cluster. Asymmetrie = Schatten-Treiber (Gewicht 0). Debug: ★ Kaskaden-Gleichung.';
     if(KK.fehler||(KA&&KA.fehlt)) return `<div title="${tt}"><span>Kaskaden-Gleichung — Schatten</span><b style="font-size:13px">—<span class="d">${esc(KK.fehler||KA.fehlt)}</span></b></div>`;
     const pc=x=>x==null?'—':(x>=0?'+':'−')+Math.abs(x).toFixed(2).replace('.',',')+' %';
     const q=x=>x==null?'—':(x*100).toFixed(1).replace('.',',')+' %';
     const M4=((KA.modell||{}).h||{})['4'], bel=!!(M4&&M4.belegt), BI=KA.bilanz||{};
     const seite=(s,wort)=>{ const S=(KA.seiten||{})[s]||{}, r=(bel&&S.kal)?S.kal:S.ref;
        if(!S.n) return `${wort}: keine Cluster in Reichweite`;
        return r&&r.kipp_px!=null?`${wort}: Kipppunkt ${px(r.kipp_px)} (${pc(r.kipp_pct)}) → Ende ${px(r.ende_px)} (${pc(r.ende_pct)})`:`${wort}: kein Kipppunkt bis 3 σ`; };
     const yt=bel?`Y ${String(M4.Y).replace('.',',')} belegt (4 h)`:`Y = 1 aus der Literatur (${M4?'4 h nicht belegt':BI['4']&&BI['4'].zu_wenig?'4 h: noch zu wenige Blöcke':BI['1']?'4 h noch ohne Kalibrierung':'Kalibrierung ausstehend'})`;
     const MH=M4||((KA.modell||{}).h||{})['1'], hh=M4?'4':'1';
     const pz=MH?` · P(Rutsch ≥ 2 σ in ${hh} h) ${q(MH.p.ab['2'])}, P(Anstieg ≥ 2 σ) ${q(MH.p.auf['2'])}, ohne Heatmap ${q(MH.p.ab['2_basis'])}`:'';
     const bz=h=>{ const b=BI[h]; return !b?'':b.zu_wenig?`${h} h: ${b.n||0} von 120 Blöcken`:`${h} h: n ${b.n}, Y ${String(b.Y).replace('.',',')} ${b.belegt?'belegt':'nicht belegt'}`; };
     const bil=[bz('1'),bz('4')].filter(x=>x).join(' · ');
     return `<div title="${tt}"><span>Kaskaden-Gleichung — Schatten</span><b style="font-size:13px">${seite('ab','unten')}<span class="d">${seite('auf','oben')}<br>${yt} · Asymmetrie ${KA.A>=0?'+':'−'}${Math.abs(KA.A).toFixed(2).replace('.',',')}${pz}${bil?'<br>Kalibrierung '+bil:''}</span></b></div>`; })()
  +`<div title="${B.reason}"><span>Optimaler Kaufpreis (nächste ${B.window_h[0]}–${B.window_h[1]} h)</span><b style="color:${B.advised?'#3ba55d':'#8b949e'}">${px(B.px)}<span class="d">${sg(B.dist_pct)} zum Kurs · ${B.advised?B.reason:B.note}</span></b></div>`
  +`<div title="${S.reason}"><span>Optimaler Verkaufspreis (offene Positionen, ${S.window_h[0]}–${S.window_h[1]} h)</span><b style="color:${S.advised?'#e04b4b':'#8b949e'}">${px(S.px)}<span class="d">${sg(S.dist_pct)} zum Kurs · ${S.advised?S.reason:S.note}</span></b></div>`
  +(()=>{ const E=fc.empf&&fc.empf.gesamt; if(!E||!(E.kauf&&E.kauf.n)) return `<div title="Bilanz der Empfehlungen (U8): je Coin und UTC-Tag die erste Empfehlung, bewertet 24 h später"><span>Bilanz der Empfehlungen</span><b>noch keine<span class="d">erste Bewertung 24 h nach der ersten gespeicherten Prognose</span></b></div>`;
     const K=E.kauf, V=E.verkauf||{}, G=fc.empf.gebuehren||{}, p=x=>x==null?'—':(x>=0?'+':'')+(x*100).toFixed(2)+' %', q=x=>x==null?'—':(x*100).toFixed(0)+' %';
     const farbe=c=>!c?'#c9d1d9':c[0]>0?'#3ba55d':c[1]<0?'#e04b4b':'#d29922', iv=c=>c?` (${p(c[0])} … ${p(c[1])})`:'';
     return `<div title="Bilanz der Empfehlungen (U8), alle Coins: je Coin und UTC-Tag die erste Empfehlung (${K.n} Fälle aus ${fc.empf.tage} Tagen). Das Limit liegt ab der Prognose ${fc.empf.order_h} h; bewertet wird alles ${fc.empf.ausstieg_h} h nach der Prognose, nach Gebühren (Maker ${(G.maker*100).toFixed(3)} %, Taker ${(G.taker*100).toFixed(3)} %). Kauf: Limit gegen sofort kaufen (Markt) und nie kaufen (0). Verkauf, für eine offene Long-Position: Limit gegen sofort verkaufen und halten. Farbe: grün, wenn das Limit die Markt-Variante mit 95 % schlägt, rot, wenn es sicher schlechter ist, gelb, wenn offen. Je Coin und nach 'advised' getrennt: Debug „Bilanz der Empfehlungen (U8)“."><span>Bilanz der Empfehlungen (${K.n} Fälle)</span><b style="color:${farbe(K.diff_markt_ci)}">Kauf: Limit ${p(K.limit)} · Markt ${p(K.markt)} · gefüllt ${q(K.fuellquote)}<span class="d">Limit − Markt ${p(K.diff_markt)}${iv(K.diff_markt_ci)} · Verkauf: Limit ${p(V.limit)} · sofort ${p(V.markt)} · halten ${p(V.nie)} · gefüllt ${q(V.fuellquote)}</span></b></div>`; })()
  +`<div title="Erwartete Bewegung der ersten ${O.h1} Stunden zum nächsten Magneten"><span>Nächste Bewegung (${O.h1} h)</span><b style="color:${col(O.target_pct)}">${px(O.target_12h)}<span class="d">${sg(O.target_pct)}${O.cascade?` · dann ${O.cascade.type} ab ${px(O.cascade.trigger)} bis ≈ ${px(O.cascade.target)}`:''}</span></b></div>`
  +`<div title="Pfad-Endpunkt nach 7 Tagen und Unsicherheitsband"><span>7 Tage</span><b style="color:${col(O.end_pct)}">${px(O.end_px)}<span class="d">${sg(O.end_pct)} · Band ${px(O.lo)} – ${px(O.hi)}</span></b></div>`
  +(()=>{ const sc=fc.score||{}; if(!sc.n&&!sc.n_4h) return `<div title="Trefferquote: Richtung nach 4 h und 24 h gegen den echten Kurs geprüft"><span>Trefferquote</span><b>noch keine<span class="d">erste Prüfung 4 h nach der ersten Prognose</span></b></div>`;
     const Q=(q)=>{ if(!q||!q.n) return null; const ci=q.ci?` (${(q.ci[0]*100).toFixed(0)}–${(q.ci[1]*100).toFixed(0)})`:''; const b=q.base!=null?` · Basis ${(q.base*100).toFixed(0)} %`:''; return `${(q.hit_rate*100).toFixed(0)} %${ci}${b} · n_eff ${q.n_eff}`; };
     const q4=Q(sc.q4), q24=Q(sc.q24); const main=sc.q4&&sc.q4.n?sc.q4:sc.q24; const farbe=(q)=>{ if(!q||!q.n||!q.ci) return '#c9d1d9'; return q.ci[0]>(q.base||0.5)?'#3ba55d':q.ci[1]<(q.base||0.5)?'#e04b4b':'#d29922'; };
     const bs=(q)=>q&&q.brier_skill!=null?`Brier-Skill ${q.h} h ${q.brier_skill>=0?'+':''}${(q.brier_skill*100).toFixed(1)} %`:null;
     return `<div title="Eine Prognose je 15-min-Fenster gezählt. Klammer: Wilson-Intervall (95 %) auf n_eff — der Zahl UNABHÄNGIGER Fälle, nicht der Fensterzahl (bei 4 h ein Sechzehntel, bei 24 h ein Sechsundneunzigstel). Basis: Quote von 'immer aufwärts' bzw. 'immer abwärts' in denselben Fenstern — nur der Abstand dazu ist Können. Grün: Intervall ganz über der Basis; rot: ganz darunter. Brier-Skill: Güte der gespeicherten Wahrscheinlichkeit gegen Raten mit der Drift (über 0 = besser)."><span>Trefferquote</span><b style="color:${farbe(main)}">${q4?'4 h: '+q4:(q24?'24 h: '+q24:'—')}<span class="d">${q4&&q24?'24 h: '+q24:''}${[bs(sc.q4),bs(sc.q24)].filter(Boolean).length?' · '+[bs(sc.q4),bs(sc.q24)].filter(Boolean).join(' · '):''}${sc.mae_pct!=null?' · Fehler 24 h Ø '+sc.mae_pct.toFixed(2)+' %':''}${(()=>{ const l=[['72 h',sc.q72],['168 h',sc.q168]].filter(([n,q])=>q&&q.n).map(([n,q])=>`${n}: ${Q(q)}`); return l.length?`<br><span style="color:#8b949e">unkalibriert (Drift ohne gelernte Gewichte): ${l.join(' · ')}</span>`:''; })()}</span></b></div>`; })();
 // ---- Chart: 48 h Historie + 7 Tage Pfad ----
 if(!W){ return; }
 const hist=fc.history||[], path=fc.path, band=fc.band;
 fcClamp(); const vs=FC_VIEW.start, vsp=FC_VIEW.span, Lm=64,R=64,T=14,Bm=26,pw=W-Lm-R,ph=H-T-Bm;
 const X=t=>Lm+((t-fc.ts)/3600-vs)/vsp*pw, inView=t=>{ const hh=(t-fc.ts)/3600; return hh>=vs-1&&hh<=vs+vsp+1; };
 // Preisskala aus dem sichtbaren Ausschnitt
 const vis=[...hist.filter(h=>inView(h.t)).map(h=>h.c),...band.filter(b=>inView(fc.ts+b.h*3600)).flatMap(b=>[b.lo,b.hi])];
 if(vs<=12){ vis.push(B.px,S.px); }
 const allPx=vis.filter(v=>v); const lo=(allPx.length?Math.min(...allPx):fc.price*0.95)*0.997, hi=(allPx.length?Math.max(...allPx):fc.price*1.05)*1.003, Y=v=>T+(hi-v)/(hi-lo)*ph;
 g.strokeStyle='#161b22'; for(let k=0;k<=5;k++){const y=T+ph*k/5; g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.fillStyle='#6e7681'; g.font='10px system-ui'; g.textAlign='right'; g.fillText(px(hi-(hi-lo)*k/5),Lm-4,y+3);}
 g.textAlign='left';
 // Clip auf den Zeichenbereich
 g.save(); g.beginPath(); g.rect(Lm,T,pw,ph); g.clip();
 // Zeitgitter: Tage immer; 6-h-Linien unter 5 Tagen Spanne; Stundenlinien unter 30 h
 const stepH=vsp<=30?1:vsp<=120?6:24;
 for(let hh=Math.ceil(vs/stepH)*stepH; hh<=vs+vsp; hh+=stepH){ const t=fc.ts+hh*3600, x=X(t); const isDay=hh%24===0&&hh!==0;
  g.strokeStyle=isDay?'#30363d':'#161b22'; g.beginPath(); g.moveTo(x,T); g.lineTo(x,T+ph); g.stroke();
  g.fillStyle=isDay?'#8b949e':'#6e7681'; g.font='9px system-ui'; g.textAlign='center';
  g.fillText(stepH===24?(hh>0?'+'+(hh/24)+' T':hh===0?'jetzt':(hh/24)+' T'):(stepH===6?(hh%24===0?(hh>0?'+'+(hh/24)+' T':'jetzt'):(hh>0?'+':'')+hh+' h'):(hh%6===0?((hh>0?'+':'')+hh+' h'):'')),x,H-8); }
 g.textAlign='left';
 // Trennlinie jetzt
 g.strokeStyle='#8b949e'; g.setLineDash([2,3]); g.beginPath(); g.moveTo(X(fc.ts),T); g.lineTo(X(fc.ts),T+ph); g.stroke(); g.setLineDash([]); g.fillStyle='#8b949e'; g.font='10px system-ui'; g.fillText('jetzt',X(fc.ts)+3,T+10);
 // Band
 g.fillStyle='rgba(201,184,255,0.14)'; g.beginPath(); band.forEach((b,i)=>{ const x=X(fc.ts+b.h*3600); i?g.lineTo(x,Y(b.hi)):g.moveTo(x,Y(b.hi)); }); for(let i=band.length-1;i>=0;i--){ const b=band[i]; g.lineTo(X(fc.ts+b.h*3600),Y(b.lo)); } g.closePath(); g.fill();
 // Magneten
 const M=fc.magnets||{}; const drawMag=(arr,color,label)=>arr.forEach(m=>{ const y=Y(m.px); if(y<T||y>T+ph) return; g.strokeStyle=color; g.lineWidth=1; g.setLineDash([1,3]); g.beginPath(); g.moveTo(X(fc.ts),y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]); g.fillStyle=color; g.font='9px system-ui'; g.textAlign='right'; g.fillText(`${label} ${fmt(m.usd)}`,W-R-2,y-2); g.textAlign='left'; });
 drawMag(M.liq_up||[],'rgba(59,165,93,0.8)','Short-Liq'); drawMag(M.liq_dn||[],'rgba(224,75,75,0.8)','Long-Liq'); drawMag(M.wall_up||[],'rgba(200,120,255,0.8)','Wand'); drawMag(M.wall_dn||[],'rgba(88,166,255,0.8)','Wand');
 // Historie
 if(hist.length>1){ g.strokeStyle='#fff'; g.lineWidth=1.4; g.beginPath(); hist.forEach((h,i)=>i?g.lineTo(X(h.t),Y(h.c)):g.moveTo(X(h.t),Y(h.c))); g.stroke(); }
 // Pfad (Ensemble) und, dünn, der reine Modellpfad
 if(path[1]&&path[1].px_model!=null){ g.strokeStyle='rgba(201,184,255,0.45)'; g.lineWidth=1; g.setLineDash([3,4]); g.beginPath(); path.forEach((p,i)=>{ const x=X(fc.ts+p.h*3600); i?g.lineTo(x,Y(p.px_model)):g.moveTo(x,Y(p.px_model)); }); g.stroke(); g.setLineDash([]); }
 g.strokeStyle='#c9b8ff'; g.lineWidth=2; g.setLineDash([7,4]); g.beginPath(); path.forEach((p,i)=>{ const x=X(fc.ts+p.h*3600); i?g.lineTo(x,Y(p.px)):g.moveTo(x,Y(p.px)); }); g.stroke(); g.setLineDash([]);
 // Fenster 4-12 h und Kauf/Verkauf
 g.fillStyle='rgba(255,255,255,0.04)'; g.fillRect(X(fc.ts+4*3600),T,X(fc.ts+12*3600)-X(fc.ts+4*3600),ph);
 [[B.px,'#3ba55d','KAUF '+px(B.px)+(B.advised?'':' (nicht ratsam)')],[S.px,'#e04b4b','VERKAUF '+px(S.px)+(S.advised?'':' (nicht ratsam)')]].forEach(([v,cc,lbl])=>{ const y=Y(v); if(y<T||y>T+ph) return;
  g.strokeStyle=cc; g.lineWidth=1.4; g.setLineDash([5,3]); g.beginPath(); g.moveTo(X(fc.ts),y); g.lineTo(X(fc.ts+24*3600),y); g.stroke(); g.setLineDash([]); g.fillStyle=cc; g.font='bold 10px system-ui'; g.fillText(lbl,X(fc.ts)+4,y-3); });
 g.restore();
 // Kurs jetzt
 if(Y(p0)>=T&&Y(p0)<=T+ph){ g.fillStyle='#58a6ff'; g.fillRect(W-R+2,Y(p0)-8,R-4,16); g.fillStyle='#0d1117'; g.font='bold 10px system-ui'; g.fillText(px(p0),W-R+5,Y(p0)+4); }
 $('fcview').textContent=`${vs<=0?hm(fc.ts+vs*3600):'+'+Math.round(vs)+' h'} bis +${Math.round(vs+vsp)} h · ${vsp<=30?'Stundenraster':vsp<=120?'6-h-Raster':'Tagesraster'} · ziehen = scrollen, Rad/Pinch = zoomen, tippen = Werte`;
 GEO.fc={fc,Lm,R,T,B:Bm,pw,ph,W,H,lo,hi};
 // ---- Treiber (mit gelerntem Gewicht und Trefferquote je Treiber) ----
 const SIGS=sigBewerten(fc);
 drv.innerHTML=(fc.regime&&fc.regime.text?`<div class="sub" style="margin:4px 0 6px" title="Regime-Flags aus Volatilität, Open-Interest-Perzentil, Liquidationsintensität und Taker-Flow-Varianz: sie weiten das Prognoseband, verschieben aber keine Richtung (Auditbericht v3: diese Größen sagen Volatilität voraus, nicht Richtung)">Regime: ${esc(fc.regime.text)}</div>`:'')
  +`<div class="sub" style="margin:2px 0 6px;color:#6e7681">${fc.drivers.length} von ${fc.n_treiber||30} Treibern aktiv · inaktive Zeilen gedimmt mit Grund · <span class="lbl-ev">EREIGNIS</span> = Ereignis-Treiber schlägt an · <span style="color:#3ba55d">▲</span>/<span style="color:#e04b4b">▼</span> Änderung seit der letzten Prognose (≥ 0,05), Doppelpfeil ab 0,5 · <span style="color:#e04b4b">⚡</span> Umschwung: mindestens 2 der 5 gewichtigsten Treiber binnen 10 min um ≥ 0,5 gefallen (Sirene) <button id="tonbtn" class="tog off" style="margin-left:8px;padding:2px 8px" onclick="event.stopPropagation();tonSchalter()">🔕 Töne aus</button> <a class="help" onclick="event.stopPropagation();tonCtx();tonKasse(3);setTimeout(()=>tonSirene(2),3300)" title="Probe: Kasse (3 s), dann Sirene (2 s)">Probe</a></div>`
  +`<table class="w"><tr><th>Treiber</th><th class="n">Richtung</th><th class="n" title="v1: Gewicht des alten Modells (trägt die Prognose, solange v2 im Schatten ist)">Gewicht</th><th class="n" title="v2: Gewicht des K2-Neubaus in Score-Einheiten, parallel gelernt (Prior klingt mit n_eff ab; Achsenabschnitt trägt die Drift). Blau = weicht vom Prior ab, rot = invertiert.">Gew. v2</th><th class="n">Prior</th><th class="n">Treffer</th><th>Begründung</th></tr>`
  +fc.drivers.concat(fc.inaktiv||[]).map(d=>{ const sg=(SIGS[d.name]||{}); return `<tr${d.score==null?' style="opacity:.55"':''}><td><b>${d.name}</b>${(d.schatten||['Pool-Positionierung','Pool-Flow 4 h','Pool-Timing-Flow','Coinbase-Prämie'].includes(d.name))?` <span class="lbl-ev" style="background:#1f2a44;color:#9cc4ff" title="${d.name==='Coinbase-Prämie'?'Gewicht 0: gegen den HL-Perp gemessen und damit fehlerhaft -- bis zum Neubau gegen Binance-Spot (U56); nicht in v2':d.name==='Kaskaden-Asymmetrie'?'Kaskaden-Gleichung (hl_kaskade): erwartete Kaskadenreichweite oben gegen unten nach dem Wurzelgesetz mit Y = 1; Gewicht 0 in v1, nicht in v2 und v3 -- sammelt ihre eigene Bilanz (Familie Kaskaden)':'Schatten-Treiber aus allen Pool-Konten (Top 500 und Kandidaten): Gewicht 0 in v1, nicht in v2 -- sammelt seine eigene Bilanz'}">Schatten</span>`:''}${sg.pfeil?` <span style="color:${sg.pfeil[0]==='▲'?'#3ba55d':'#e04b4b'};font-size:12px" title="Änderung des Scores seit der letzten Prognose${sg.pfeil.length>1?' -- stark (≥ 0,5)':''}">${sg.pfeil}</span>`:''}${sg.blitz?` <span style="color:${sg.blitz==='rot'?'#e04b4b':'#3ba55d'};font-size:13px" title="Umschwung: gehört zu mindestens 2 gewichtigen Treibern, die binnen 10 min um ≥ 0,5 ${sg.blitz==='rot'?'gefallen':'gestiegen'} sind">⚡</span>`:''}${d.learned?' <span class="lbl-beh" title="Gewicht aus der eigenen Trefferbilanz gelernt">gelernt</span>':''}${d.ereignis===true?' <span class="lbl-ev" title="Ereignis-Treiber: das Ereignis schlägt gerade an">EREIGNIS</span>':d.ereignis===false?' <span class="lbl-ev off" title="Ereignis-Treiber: derzeit kein Ereignis (Bedingung im Text)">kein Ereignis</span>':''}</td><td class="n" style="color:${d.score==null?'#6e7681':col(d.score)}">${d.score==null?'—':(d.score>=0?'+':'')+d.score.toFixed(2)}</td><td class="n"${d.learned?' style="color:#c9b8ff"':''}>${d.weight.toFixed(2)}</td><td class="n" style="color:${d.weight_v2==null?'#6e7681':d.weight_v2<0?'#e04b4b':Math.abs(d.weight_v2-(d.prior||d.weight))>0.05?'#58a6ff':'#c9d1d9'}" title="${d.weight_v2!=null?'v2-Gewicht '+d.weight_v2.toFixed(3)+(d.weight_v2<0?' (invertiert)':''):(fc.kalib2&&fc.kalib2.fehler?'v2-Fehler: '+esc(fc.kalib2.fehler):fc.kalib2&&fc.kalib2.zu_wenig?'v2: zu wenige Fälle ('+fc.kalib2.n+' von '+fc.kalib2.min_faelle+')':fc.kalib2&&fc.kalib2.weights?'v2: für diesen Treiber kein Gewicht':'v2: kein Modell gespeichert')}">${d.weight_v2!=null?d.weight_v2.toFixed(2):`<span style="font-size:11px">${fc.kalib2&&fc.kalib2.fehler?'Fehler':fc.kalib2&&fc.kalib2.zu_wenig?'zu wenig':fc.kalib2&&fc.kalib2.weights?'—':'kein Modell'}</span>`}</td><td class="n" style="color:#6e7681">${(d.prior||d.weight).toFixed(1)}</td><td class="n" style="color:${d.hit_rate==null||!d.ci?'#6e7681':d.ci[0]>0.5?'#3ba55d':d.ci[1]<0.5?'#e04b4b':'#c9d1d9'}" title="${d.hit_rate!=null?'Trefferquote des Treibervorzeichens (4-h-Spur, in-sample) mit Wilson-Intervall auf n_eff; ein Treiber verlässt seinen Prior erst ab n_eff 50':d.name==='Kaskaden-Asymmetrie'?'Bewusst nicht im v1-Lernen (nicht in PRIORS) und nicht in v2/v3: Die Bilanz dieses Treibers steht in der Familie Kaskaden (Abschnitt Treiberfamilien) und in der Richtungsprobe im Debug ★ Kaskaden-Gleichung.':'Noch keine Bilanz: Ein Treiber zählt in einem bewerteten Fall nur, wenn sein Score im Betrag über 0,1 lag -- kleinere Werte sind kein Richtungsurteil. Dieser Treiber war in keinem bewerteten Block deutlich genug (Extremwert-Treiber wie Funding oder Vol-Spike zählen erst bei extremen Werten) oder ist noch zu neu.'}">${d.hit_rate!=null?(d.hit_rate*100).toFixed(0)+' %'+(d.ci?' ('+(d.ci[0]*100).toFixed(0)+'–'+(d.ci[1]*100).toFixed(0)+')':'')+' · n_eff '+(d.n_eff!=null?d.n_eff:'—')+(d.lift!=null?`<br><span style="font-size:10px;color:${d.lift_z!=null&&d.lift_z>=2?'#3ba55d':d.lift_z!=null&&d.lift_z<=-2?'#e04b4b':'#8b949e'}" title="Lift = Trefferquote minus Zufalls-Erwartung aus den Randverteilungen der eigenen Fälle (q·p + (1−q)(1−p)); z gegen den Standardfehler der Differenz auf n_eff. Ein Treiber, der im Aufwärtstrend immer 'auf' sagt, hat hohe Quote und Lift null.">Lift ${(d.lift*100).toFixed(0)>=0?'+':''}${(d.lift*100).toFixed(0)} pp${d.lift_z!=null?' (z '+d.lift_z.toFixed(1)+')':''}</span>`:'')+(d.oos&&d.oos.hit_rate!=null?`<br><span style="font-size:10px;color:#8b949e" title="Out-of-sample je Treiber: Fälle seit der laufenden Gewichtsversion, ab 25 Blöcken">OOS ${(d.oos.hit_rate*100).toFixed(0)} % · n_eff ${d.oos.n_eff}</span>`:''):d.name==='Kaskaden-Asymmetrie'?'— <span style="font-size:10px">Bilanz in der Familie Kaskaden</span>':'— <span style="font-size:10px">nie |Score| > 0,05</span>'}</td><td>${d.text}</td></tr>`; }).join('')+'</table>'
  +(fc.elite_konten&&fc.elite_konten.length?(()=>{ const mio=v=>v==null?'—':(v/1e6).toFixed(1)+' M', pc=v=>v==null?'—':`<span style="color:${v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9'}">${(v*100).toFixed(1)} %</span>`, nm=e=>{ const L=(LABELS||{})[e.addr]||{}; return e.name||L.name||(e.addr.slice(0,6)+'…'+e.addr.slice(-4)); };
   return `<div class="sub" style="margin:10px 0 4px"><b>Elite-Konten in ${esc(fc.coin||'')} (${fc.elite_konten.length})</b> — die Konten hinter dem Treiber „Elite-Positionierung": Beleg n ≥ 10, Vorlauf > 0, t ≥ 1, Gewinn-Schranke; Position im Coin aus dem jüngsten Stand</div>`
   +`<table class="w"><tr><th>#</th><th>Konto</th><th class="n">Kontowert</th><th class="n" title="Konto-Score 0–1">Score</th><th class="n" title="Schritte im Coin (28 T)">n</th><th class="n" title="4-h-Vorlauf, driftbereinigt">α 4h</th><th class="n" title="t-Wert des Vorlaufs">t</th><th>Position</th><th class="n">Wert</th><th class="n" title="unrealisierter Gewinn der Position">uPnL</th><th class="n" title="Leaderboard-Gewinn 30 T">PnL 30 T</th><th class="n" title="gebündelte Trades je Tag (Fills oder Positionsänderungs-Minuten, 3 Tage); über 300 = keine Elite">Trades/T</th></tr>`
   +fc.elite_konten.map((e,i)=>`<tr><td>${i+1}</td><td>${hsLink(e.addr, `<b>${esc(nm(e))}</b>`)}${e.rank?` <span class="d">#${e.rank}</span>`:''}</td><td class="n">${mio(e.account_value)}</td><td class="n">${e.score!=null?e.score.toFixed(2):'—'}</td><td class="n">${e.n!=null?e.n:'—'}</td><td class="n">${e.alpha_4h!=null?(e.alpha_4h*100).toFixed(2)+' %':'—'}</td><td class="n">${e.t_4h!=null?e.t_4h.toFixed(1):'—'}</td><td style="color:${e.side==='long'?'#3ba55d':e.side==='short'?'#e04b4b':'#6e7681'}">${e.side||'flat'}</td><td class="n">${e.pos_value?mio(e.pos_value):'—'}</td><td class="n">${pc(e.upnl_pct)}</td><td class="n" style="color:${e.pnl_30d>0?'#3ba55d':e.pnl_30d<0?'#e04b4b':'#c9d1d9'}">${e.pnl_30d!=null?mio(e.pnl_30d):'—'}</td><td class="n" style="color:${e.trades_tag>300?'#e04b4b':'#c9d1d9'}">${e.trades_tag!=null?e.trades_tag:'—'}</td></tr>`).join('')+'</table>'; })():'');
 tonAnzeige();
 // U25 Stufe 1: Konstellationen und Vorbedingungen (Rückschau, keine Modellbestandteile)
 if(fc.konstellation){ const K=fc.konstellation, V=K.vorbedingungen||{}, pc=v=>v==null?'—':(v*100).toFixed(0)+' %';
  const paare=(K.konstellationen||[]).slice(0,12), meta=paare[0]||{};
  // U131 (23.53): Leer-Meldung nach Ursache, Liste der erfassten Ereignisse (vorher sah man nicht, welche Bewegungen gezählt wurden)
  const liste=(arr,vz,n)=>arr.length?`<table class="w"><tr><th>Treiber</th><th class="n" title="Anteil der Ereignisse, in denen der Treiber an der Vorbedingung ${vz} zeigte (|Score| ≥ 0,3)">vor der Bewegung</th><th class="n">Basis</th><th class="n">Lift</th><th class="n">z</th><th class="n" title="mittlerer Score in Richtung der späteren Bewegung">Ø Score</th></tr>`+arr.map(r=>`<tr><td>${esc(r.treiber)}</td><td class="n">${pc(r.anteil_vor)}</td><td class="n">${pc(r.basis)}</td><td class="n" style="color:${r.lift>0.1?'#3ba55d':r.lift<-0.1?'#e04b4b':'#c9d1d9'}">${(r.lift*100).toFixed(0)>=0?'+':''}${(r.lift*100).toFixed(0)} pp</td><td class="n" style="color:${Math.abs(r.z)>=2?'#e6edf3':'#6e7681'}">${r.z.toFixed(1)}</td><td class="n">${r.mittel_vor>=0?'+':''}${r.mittel_vor.toFixed(2)}</td></tr>`).join('')+'</table>'
   :`<div class="sub">${(n||0)<3?`noch zu wenige Ereignisse: ${n||0} von mindestens 3`:`${n} Ereignisse, aber kein Treiber mit Werten in mindestens 3 davon`}</div>`;
  const pz=x=>(x>=0?'+':'−')+Math.abs(x).toFixed(1).replace('.',',')+' %';
  const evl=(arr,ext)=>{ if(!arr||!arr.length) return ''; const neu=arr.slice(-6).reverse();
   return `<div class="sub" style="margin-top:4px;color:#8b949e" title="Vorbedingung = frühester Prognosezeitpunkt der Bewegung · Prozent vom Kurs dort (in Klammern die größte Bewegung von einem Punkt des Ereignisses aus) · ${ext} = Extrem der Bewegung">Erfasst: ${neu.map(e=>`${hm(e.ts)} ${pz(e.bewegung)}${e.max!=null&&Math.abs(e.max-e.bewegung)>=0.1?' ('+pz(e.max)+')':''}, ${ext} ${e.extrem_ts?hm(e.extrem_ts):'—'}`).join(' · ')}${arr.length>6?` · … und ${arr.length-6} frühere`:''}</div>`; };
  const stab=(K.stabil||[]); drv.innerHTML+=`<div class="sub" style="margin:12px 0 4px"><b>Konstellationen</b> — wenn zwei gewichtige Treiber gemeinsam in eine Richtung ausschlagen (|Score| ≥ 0,3): wie oft folgte der Kurs binnen 4 h? Rückschau auf ${K.n_bloecke} Blöcke, nur Anzeige. Auswahl-Effekt: ${meta.n_tests||0} Paar-Prüfungen, ${meta.n_z2||0} mit z ≥ 2 (rein zufällig erwartet ~${meta.erwartet_z2||0})</div>`
   +(paare.length?`<table class="w"><tr><th>Treiber A + B</th><th>Richtung</th><th class="n">Quote</th><th class="n">Wilson</th><th class="n">Basis</th><th class="n">Lift</th><th class="n">n_eff</th><th class="n">z</th></tr>`+paare.map(r=>`<tr><td>${esc(r.a)} + ${esc(r.b)}</td><td style="color:${r.richtung==='up'?'#3ba55d':'#e04b4b'}">${r.richtung==='up'?'aufwärts':'abwärts'}</td><td class="n">${pc(r.quote)}</td><td class="n">${r.ci?pc(r.ci[0])+'–'+pc(r.ci[1]):'—'}</td><td class="n">${pc(r.basis)}</td><td class="n" style="color:${r.lift>0.1?'#3ba55d':r.lift<-0.1?'#e04b4b':'#c9d1d9'}">${(r.lift*100).toFixed(0)>=0?'+':''}${(r.lift*100).toFixed(0)} pp</td><td class="n">${r.n_eff}</td><td class="n" style="color:${r.z>=2?'#e6edf3':'#6e7681'}">${r.z.toFixed(1)}</td></tr>`).join('')+'</table>':'<div class="sub">noch keine Paare mit mindestens 5 gemeinsamen Ausschlägen</div>')
   +(stab.length?`<div class="sub" style="margin:4px 0 8px;color:#3ba55d">Über Wochen stabil (z ≥ 2 an ≥ 14 Tagen, Kandidaten für Interaktionsterme in v2): ${stab.map(x=>`${esc(x.a)} + ${esc(x.b)} ${x.richtung==='up'?'↑':'↓'} (${x.tage}/${x.tage_gesamt} T)`).join(' · ')}</div>`:`<div class="sub" style="margin:4px 0 8px;color:#6e7681">Stabilität über Tage wird seit ${K.hist_tage||0} Tagen aufgezeichnet; Kandidaten für Stufe 2 erscheinen hier ab 14 Tagen mit z ≥ 2</div>`)
   +`<div class="sub" style="margin:12px 0 4px"><b>Vorbedingungen</b> — was lag vor, bevor der Kurs binnen ${V.horizont_h||24} h um ≥ ${((V.bewegung||0.03)*100).toFixed(0)} % stieg (${V.n_up||0} Ereignisse) bzw. fiel (${V.n_down||0} Ereignisse)? Anteil der Ereignisse, in denen der Treiber an der Vorbedingung in die spätere Richtung zeigte, gegen die Basis aller ${V.n_all||0} Blöcke</div>`
   +(V.methode==='u131'?`<div class="sub" style="margin:0 0 6px;color:#6e7681" title="Bezug: jede gespeicherte Prognose (die erste je 15 min) -- vorher nur die erste je 4-h-Block, dadurch wirkten Bewegungen mit Hoch bzw. Tief mitten im Block kleiner, als sie waren. Ein Ereignis = eine Bewegung: Prognosezeitpunkte gehören zusammen, solange die Bewegung läuft (der Kurs war noch nicht bis auf 1,5 % an ihrem Extrem) oder sie auf dasselbe Tief bzw. Hoch zulaufen; neu nach diesem Ankommen oder nach einer Gegenbewegung um 3 %. Vorbedingung = frühester Zeitpunkt. Abgleich mit den Kursdaten: Debug ★ Vorbedingungen: Ereignisliste.">Rückschau ${V.von?hm(V.von):'—'} bis ${V.bis?hm(V.bis):'—'} (jüngere Prognosen: ihre 24 h laufen noch) · berechnet ${K.ts?hm(K.ts):'—'} · Bezug jede gespeicherte Prognose (15 min)</div>`
     :`<div class="sub" style="margin:0 0 6px;color:#d29922">Stand vor 23.53 (Bezug nur der Beginn jedes 4-h-Blocks, verkettete Ereignisse) -- wird binnen einer Stunde neu berechnet</div>`)
   +`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:8px"><div style="min-width:0"><div class="sub" style="color:#3ba55d">vor Anstiegen ≥ ${((V.bewegung||0.03)*100).toFixed(0)} %</div>${liste(V.up||[],'aufwärts',V.n_up)}${evl(V.ereignisse_up,'Hoch')}</div><div style="min-width:0"><div class="sub" style="color:#e04b4b">vor Rückgängen ≥ ${((V.bewegung||0.03)*100).toFixed(0)} %</div>${liste(V.down||[],'abwärts',V.n_down)}${evl(V.ereignisse_down,'Tief')}</div></div>`;
 }
 // ---- Selbstoptimierung ----
 const Lr=fc.learn||{}, EN=fc.ensemble||{}, AN=fc.analog, MS=fc.magnet_stats, MU=fc.magnet_used, sc=fc.score||{};
 const lw=Lr.weights||{}; const nLearned=Object.values(lw).filter(w=>Math.abs((w.weight||0)-(w.prior||0))>0.02).length;
 $('fclearn').innerHTML=`<div class="sub" style="margin:6px 0 4px"><b>Selbstoptimierung</b> — das Modell lernt an seinen eigenen Prognosen</div><div class="kpi" style="margin:0">`
  +(()=>{ const c4=Lr.cal||{}, c24=Lr.cal_24||{}, P=Lr.plan||{};
     return `<div title="Treibergewichte aus der Trefferbilanz gelernt: Logit auf die 4-h-Richtung (Hauptspur), Prior als Anker mit lam = 4 / n_eff. n_eff = unabhängige Fälle (Fenster / 16). Lernstart ab n_eff ${P.min_n_eff||40}; ein einzelner Treiber verlässt seinen Prior erst ab n_eff ${P.min_n_eff_treiber||50} eigener Fälle. beta = gelernter Maßstab der Wahrscheinlichkeit (1 = Vorgabe; kleiner heißt: die Treiber sind weniger wert, als der Prior annahm). Die 24-h-Spur lernt getrennt und langsamer (Fenster / 96)."><span>Gelernte Gewichte</span><b>${nLearned} von ${Object.keys(lw).length||Object.keys(fc.drivers).length}<span class="d">4 h: n_eff ${c4.n_eff!=null?c4.n_eff:'—'} (${c4.n||0} Fenster)${c4.gelernt?' · β '+(c4.beta!=null?c4.beta.toFixed(2):'—')+' · λ '+(c4.lam!=null?c4.lam:'—'):' · Lernen ab n_eff '+(P.min_n_eff||40)} · 24 h: n_eff ${c24.n_eff!=null?c24.n_eff:'—'}${c24.gelernt?' · β '+(c24.beta!=null?c24.beta.toFixed(2):'—'):' (noch Prior)'} · Version ${Lr.wver?hm(Lr.wver):'—'}</span></b></div>`; })()
  +(fc.kalib2?(()=>{ const k=fc.kalib2, o=k.oof||{}, sd=(fc.score||{}); const d2=sd.direkt_v2, d1=sd.direkt_v1; const zl=(k.zuverlaessigkeit||[]).map(b=>`${(b[2]*100).toFixed(0)}→${(b[3]*100).toFixed(0)}`).join(' · ');
    return `<div class="kpi" style="grid-column:1/-1" title="Kalibrierung v2 (K2-Neubau): L2-Logit auf standardisierten Treibern, Prior als abklingender Ausgangspunkt (n_eff/200), λ per geblockter Kreuzvalidierung mit Embargo, 90 Tage, Toleranz-Labels. Out-of-fold = Kreuzvalidierung; direkte Bilanz = gespeicherte Prognosen, Ruf = Vorzeichen von p−0,5 (Enthaltung unter 2 Punkten)"><span>Kalibrierung v2 ${fc.kalib==='v2'?'<span class="lbl-ev">AKTIV</span>':'<span class="lbl-ev off">Schatten</span>'}</span><b style="font-size:13px">${k.fehler?'Fehler: '+esc(k.fehler):k.zu_wenig?`zu wenige Fälle: ${k.n} von ${k.min_faelle||30} (${k.n_bloecke||0} Blöcke, ${k.tol_ausgelassen||0} unter Toleranz)`:`n ${k.n} · n_eff ${k.n_eff} · λ ${k.lam} · Prior-Anteil ${((k.prior_anteil||0)*100).toFixed(0)} % · OOF: Quote ${o.hit_rate!=null?(o.hit_rate*100).toFixed(0)+' %':'—'}${o.basisrate?' (= Basisrate, c 0)':''}, Brier-Skill ${o.brier_skill!=null?o.brier_skill.toFixed(3):'—'}${o.skill_ref?' gegen c 0':''}`}<span class="d">direkte Bilanz gespeicherter Prognosen (4 h): v1 ${d1&&d1.n?`${(d1.hit_rate*100).toFixed(0)} % (n ${d1.n}, Skill ${d1.brier_skill!=null?d1.brier_skill.toFixed(3):'—'})`:'—'} · v2 ${d2&&d2.n?`${(d2.hit_rate*100).toFixed(0)} % (n ${d2.n}, Skill ${d2.brier_skill!=null?d2.brier_skill.toFixed(3):'—'}, ${sd.enthalten_v2||0} Enthaltungen)`:'noch keine bewerteten v2-Prognosen'}${zl?` · Zuverlässigkeit (vorhergesagt→eingetreten): ${zl}`:''}</span></b></div>`; })():'')

  +(fc.fusion||fc.kalib3?(()=>{ const FU=fc.fusion_info||{}, k3=fc.kalib3||{}, o=k3.oof||{};
    const q=x=>x==null?'—':(x*100).toFixed(0)+' %';
    const v3t=k3.fehler?'Fehler: '+esc(String(k3.fehler)):k3.zu_wenig?`zu wenige Fälle (${k3.n||0} von ${k3.min_faelle||60}, je Coin mindestens ${k3.min_coin||15})`:k3.n?`n ${k3.n} · n_eff ${k3.n_eff} Zeitblöcke · ${k3.coins||0} Coins${k3.im_modell===false?' (dieser Coin noch nicht im Modell)':''} · λ ${k3.lam_b} · ${k3.r==null?'ganz geteilt':'Abweichung je Coin (r '+k3.r+')'} · c ${k3.c} · OOF: Quote ${q(o.hit_rate)}, Brier-Skill ${o.brier_skill!=null?o.brier_skill.toFixed(3):'—'}`:'noch kein Modell (stündlich, erstmals 5 min nach dem Start)';
    const bil=(b,h)=>b&&b.n?`${h} h: ${b.n} Blöcke${b.nachtrag?' ('+b.nachtrag+' nachgetragen)':''} · Log-Verlust je Block Fusion ${b.ll_fusion.toFixed(4)} gegen Basisrate ${b.ll_basis!=null?b.ll_basis.toFixed(4):'—'}${b.se_basis!=null&&b.d_basis!=null?' (Abstand '+(b.d_basis>=0?'+':'')+b.d_basis.toFixed(4)+' ± '+b.se_basis.toFixed(4)+(b.d_basis<-2*b.se_basis?', belegt besser':b.d_basis>2*b.se_basis?', belegt schlechter':', nicht belegt')+')':''} · bester Experte ${b.bester||'—'} · Quote ${q(b.quote)} · Brier-Skill ${b.skill!=null?b.skill.toFixed(3):'—'}`:`${h} h: noch keine bewerteten Blöcke`;
    return `<div class="kpi" style="grid-column:1/-1" title="Kalibrierung v3 (hl_fusion, Schatten): v2 über alle Coins geteilt, auf den Familienwerten -- gemeinsame Gewichte, Abweichung je Coin nur gegen Beleg, Achsenabschnitt je Coin, Kalibrierfaktor c aus den OOF-Vorhersagen (0 = Basisrate). Fusion: Bilanz der gestellten Fusionszahlen (jede vor dem Ergebnis festgelegt) gegen die Basisrate und den besten Experten auf denselben Blöcken; Abstand = Fusion minus Basisrate je Block ± 1 Standardfehler (belegt erst jenseits von 2 Standardfehlern); nachgetragen = aus gespeicherten Prognosen der letzten 60 Tage, ebenfalls ohne Blick in die Zukunft. Debug: ★ Fusion und v3."><span>Fusion und Kalibrierung v3 <span class="lbl-ev off">Schatten</span></span><b style="font-size:13px">v3: ${v3t}<span class="d">${bil(FU.bilanz_4,4)}<br>${bil(FU.bilanz_24,24)}</span></b></div>`; })():'')
  +`<div title="Mischung aus Modellpfad und Analog-Median; Gewichte aus den laufenden Trefferquoten beider Modelle"><span>Ensemble</span><b>${((EN.w_model||0.6)*100).toFixed(0)} % Modell · ${((EN.w_analog||0.4)*100).toFixed(0)} % Analog<span class="d">${(Lr.ensemble||{}).from||''}${sc.model&&sc.model.n?` · Modell ${(sc.model.hit_rate*100).toFixed(0)} %${sc.model.ci?' ('+(sc.model.ci[0]*100).toFixed(0)+'–'+(sc.model.ci[1]*100).toFixed(0)+')':''}`:''}${sc.analog&&sc.analog.n?` · Analog ${(sc.analog.hit_rate*100).toFixed(0)} %${sc.analog.ci?' ('+(sc.analog.ci[0]*100).toFixed(0)+'–'+(sc.analog.ci[1]*100).toFixed(0)+')':''}`:''}</span></b></div>`
  +(()=>{ const n=Lr.scores_n||0, el=Lr.elite||[], T=Lr.score_test;
     const kurz=a=>a.slice(0,6)+'…'+a.slice(-4);
     const rho=(v)=>v==null?'—':(v>=0?'+':'')+v.toFixed(2);
     const test=T?(T.zu_wenig?`Score-Test: erst ${T.n} Konten mit Schritten in der Folgewoche (ab 5)`:`Score-Test out-of-sample: ρ ${rho(T.rho)} ± ${(1.96*T.se).toFixed(2)} (n ${T.n}) · Vorlauf ${rho(T.rho_vorlauf)} · Edge ${rho(T.rho_edge)} · Konsistenz ${rho(T.rho_konsistenz)} · Größe ${rho(T.rho_groesse)}`):'Score-Test: frühestens sieben Tage nach dem ersten Schnappschuss';
     return `<div title="Konto-Score (hl_score): Wer hat recht, nicht nur wer ist groß. Je Konto und Coin aus Vorlauf (35 %: Folgerendite der eigenen Schritte nach 4 h, driftbereinigt, geschrumpft), Edge je Umsatz (25 %: PnL / Umsatz aus dem Leaderboard), Konsistenz (20 %: Vorzeichen über vier Fenster), Größe (10 %) und Klasse (10 %). Täglich neu, Schnappschuss in forecasts.db. Score-Test: Rangkorrelation des Scores von vor sieben Tagen mit dem Vorlauf der Folgewoche — je Komponente. Liegt Größe bei null, ist die goldene Regel in ihrer Größen-Form widerlegt."><span>Konto-Score</span><b>${n?n+' Konten bewertet':'—'}<span class="d">${el.length?'Elite: '+el.map(e=>`${kurz(e.addr)} ${e.score!=null?e.score.toFixed(2):''}${e.alpha_4h!=null?' (α '+(e.alpha_4h*100).toFixed(2)+' %, n '+e.n+')':''}`).join(' · '):'noch keine Schritte bewertet'}${Lr.scores_snapshot?' · Stand '+hm(Lr.scores_snapshot):''}<br>${test}</span></b></div>`; })()
  +(AN?`<div title="Die ähnlichsten Momente der Kurshistorie (Renditen, Volatilität, RSI, Lage zum 7-Tage-Mittel, Tageszeit, Wochentag)"><span>Analog-Suche</span><b>${AN.n} Analoge<span class="d">aus ${AN.span_days.toFixed(0)} Tagen Historie · 24 h danach: Median ${(AN.ret[24].med*100).toFixed(2)} %, ${(AN.ret[24].p_up*100).toFixed(0)} % aufwärts${AN.ret[24].ci?' ('+(AN.ret[24].ci[0]*100).toFixed(0)+'–'+(AN.ret[24].ci[1]*100).toFixed(0)+')':''}${AN.ret[24].p_up_base!=null?' · Basis '+(AN.ret[24].p_up_base*100).toFixed(0)+' %':''} · 7 T: ${AN.ret[168]?(AN.ret[168].med*100).toFixed(1)+' % ('+(AN.ret[168].q20*100).toFixed(1)+' … '+(AN.ret[168].q80*100).toFixed(1)+' %)':'—'}</span></b></div>`
    :`<div title="braucht mindestens ~40 Tage 30-min-Kerzen (klines30 oder bnc_bars)"><span>Analog-Suche</span><b>—<span class="d">noch zu wenig Kurshistorie für diesen Coin</span></b></div>`)
  +(MS?(()=>{ const D=Object.entries(MS).filter(([k])=>!k.startsWith('g:')), G=Object.entries(MS).filter(([k])=>k.startsWith('g:')); const MI=fc.magnet_info||{};
     const zeile=(k,v)=>`${k}: Lift ${v.lift!=null?v.lift.toFixed(2):'—'}${v.ci?' ('+(v.ci[0]*100).toFixed(0)+'–'+(v.ci[1]*100).toFixed(0)+')':''} n_eff ${v.n_eff!=null?v.n_eff:v.n}`;
     return `<div title="Aus Heatmap-Snapshots gemessen: Wahrscheinlichkeit, dass ein Liquidationscluster innerhalb 12 h erreicht wird — gegen ein Placebo-Niveau in gleichem Abstand auf der anderen Seite zum selben Zeitpunkt. Lift = Berührquote / Placebo: 1,0 heißt, das Cluster zieht nicht stärker an als der Zufall. Nach Abstand (nur Cluster über der Schwelle — die Population des Pfadmodells) und nach GRÖSSE als Anteil am HL-Stundenvolumen (alle ab 5 Mio) — aus der Größenklasse, ab der der Lift über 1 liegt, folgt die richtige Schwelle. Intervall auf n_eff (getrennte 12-h-Blöcke)."><span>Magnet-Statistik</span><b>${D.length?D.map(([k,v])=>`${k} %: ${(v.p_touch*100).toFixed(0)}${v.p_placebo!=null?' vs '+(v.p_placebo*100).toFixed(0):''} %`).join(' · '):'noch keine Cluster über der Schwelle mit 12-h-Ergebnis'}<span class="d">${D.map(([k,v])=>zeile(k+' %',v)).join(' · ')}${G.length?'<br>nach Größe (Anteil am Stundenvolumen): '+G.map(([k,v])=>zeile(k.slice(2),v)).join(' · '):''}<br>${MI.grund||(MU?`genutzt: Klasse ${MU.class}`:'')}${MU?` — Treffer ${(MU.p_touch*100).toFixed(0)} %, Überschuss ${(MU.overshoot*100).toFixed(2)} %, Rückkehr ${(MU.retrace*100).toFixed(0)} %`:''}${MI.schwelle!=null?` · Schwelle ${(MI.schwelle/1e6).toFixed(0)} Mio (${((MI.anteil||0.1)*100).toFixed(0)} % des HL-Stundenvolumens ${(MI.vol_1h_hl/1e6).toFixed(0)} Mio, mind. 5) · größter Cluster oben ${(MI.max_up/1e6).toFixed(1)} / unten ${(MI.max_dn/1e6).toFixed(1)} Mio`:''}${(()=>{ const V=Lr.magnet_var; if(!V) return ''; const z=(v,h)=>{ const c=(V[v]||{})[h]; return c&&c.z_delta!=null?`${h}h Δ${c.delta_pp>=0?'+':''}${c.delta_pp} pp (z ${c.z_delta}, Anz ${c.anziehung_pct>=0?'+':''}${c.anziehung_pct} %, t ${c.t}, n_eff ${c.n_eff})`:`${h}h —`; }; const ch=v=>{ const c=(V[v]||{}).cho15; return c?` · Cho15 ${(c.p_zum*100).toFixed(0)}/${(c.basis*100).toFixed(0)} %`:''; }; return `<br>Magnet-Varianten (ziehen Cluster an?): 0,5–1 %: ${z('0.5-1',4)} · ${z('0.5-1',24)}${ch('0.5-1')} | 1–2 %: ${z('1-2',4)} · ${z('1-2',24)}${ch('1-2')} — belegt erst bei z/t > 2 in mehreren Horizonten (Debug: Magnet-Varianten)`; })()}</span></b></div>`; })()
    :`<div title="braucht einige Tage Heatmap-Snapshots"><span>Magnet-Statistik</span><b>—<span class="d">noch zu wenige Cluster-Annäherungen gemessen</span></b></div>`)
  +`<div title="Volatilität je Wochentag und Stunde aus der Kurshistorie formt das Unsicherheitsband"><span>Zeitprofil</span><b>${fc.tprof_used?'aktiv':'—'}<span class="d">${fc.tprof_used?'Band je Stunde mit der typischen Volatilität dieser Stunde skaliert':'noch kein Profil'}${Lr.store?'<br>Ablage: '+Lr.store:''}</span></b></div>`
  +(sc.oos&&sc.oos.n?`<div title="Alle gespeicherten Prognosen sind walk-forward: ihre Gewichte stammen nur aus Daten VOR ihrem Zeitpunkt. Diese Kachel zeigt die engere Sicht — nur Fenster seit der aktuellen Gewichtsversion (24 h), mit Intervall auf n_eff."><span>Seit Gewichtsversion</span><b style="color:${sc.oos.ci?(sc.oos.ci[0]>0.5?'#3ba55d':sc.oos.ci[1]<0.5?'#e04b4b':'#d29922'):'#c9d1d9'}">${(sc.oos.hit_rate*100).toFixed(0)} %${sc.oos.ci?' ('+(sc.oos.ci[0]*100).toFixed(0)+'–'+(sc.oos.ci[1]*100).toFixed(0)+')':''}<span class="d">24 h · n_eff ${sc.oos.n_eff} seit der letzten Kalibrierung</span></b></div>`:'')
  +((Lr.errors||[]).length?`<div><span>Lernfehler</span><b style="color:#d29922">${Lr.errors.length}<span class="d">${Lr.errors.join(' · ').slice(0,160)}</span></b></div>`:'')
  +'</div>'+(()=>{ const P=Lr.plan; if(!P) return ''; const t=v=>v?hm(v):'—'; const rel=v=>{ if(!v) return ''; const m=Math.round((v-Date.now()/1000)/60); return m<=0?' (jetzt fällig)':m<60?` (in ${m} min)`:m<48*60?` (in ${(m/60).toFixed(1)} h)`:` (in ${(m/1440).toFixed(1)} Tagen)`; };
     const C=P.components||{};
     return `<div class="sub" style="margin:8px 0 4px"><b>Lernplan</b> — wann was passiert</div><div class="kpi" style="margin:0">`
      +`<div title="${(Lr.store||'forecasts.db')} — Prognosen dieses Coins (alle 15 min plus Sofortberechnungen bei Wal-/Leaderboard-Ereignissen); fürs Lernen zählt eine je 15-min-Fenster, damit Ereignis-Serien nicht dominieren"><span>Prognosen</span><b>${P.n_stored} gespeichert<span class="d">seit ${t(P.first_ts)} · ${P.n_windows||P.n_stored} Fenster à 15 min · bewertet: ${P.n_scored_4h} nach 4 h, ${P.n_scored_24h} Fenster nach 24 h</span></b></div>`
      +`<div title="Die Bewertung läuft mit jeder Berechnung; eine Prognose wird bewertet, sobald sie 4 bzw. 24 h alt ist"><span>Nächste Bewertung</span><b>${t(P.next_eval_4h)}${rel(P.next_eval_4h)}<span class="d">4-h-Prüfung · 24-h-Prüfung ${t(P.next_eval_24h)}${rel(P.next_eval_24h)}</span></b></div>`
      +`<div title="Das Lernen der Hauptspur (4 h) beginnt, sobald n_eff ${P.min_n_eff||40} unabhängige Fälle erreicht — das sind ${P.ziel_fenster||640} bewertete 15-min-Fenster (Fenster / 16), rund eine Woche. Früher wurde bei 40 Fenstern (zehn Stunden Daten) gestartet: Die Fenster überlappen sich in ihrem Ergebnis fast vollständig, 40 davon sind keine 40 Beobachtungen. Die 24-h-Spur braucht 96 Fenster je Fall und damit rund sechs Wochen."><span>Lernbeginn</span><b style="color:${P.learning?'#3ba55d':'#c9d1d9'}">${P.learning?'läuft (4 h)':t(P.learn_eta)+rel(P.learn_eta)}<span class="d">${P.learning?`n_eff 4 h: ${P.n_eff_4h} · 24 h: ${P.n_eff_24h}${P.learning_24h?' (läuft)':' (ab '+(P.min_n_eff||40)+')'}`:`noch ${P.fehlend!=null?P.fehlend:'?'} bewertete Fenster (n_eff ${P.n_eff_4h!=null?P.n_eff_4h:'—'} von ${P.min_n_eff||40})`}</span></b></div>`
      +`<div title="Alle 15 min werden die Gewichte neu berechnet; gespeichert wird nur, wenn sich eines um mehr als 0,02 ändert — das ist eine neue Gewichtsversion. Vor dem Lernbeginn ist die gespeicherte Version der Prior."><span>Gewichte</span><b>geprüft ${t(P.w_checked)}<span class="d">${P.learning?'zuletzt geändert':'Version (Prior) seit'} ${t(P.w_changed)} · nächste Prüfung ${t(P.next_w_check)}${rel(P.next_w_check)}</span></b></div>`
      +`<div title="Stündlich: Analog-Suche und Magnet-Statistik; alle 6 h: Zeitprofil — aus forecasts.db (Tabelle learned)"><span>Bausteine erneuert</span><b><span class="d" style="display:block;font-size:12px;color:#c9d1d9">Analog ${t(C.analog)} · Magneten ${t(C.magnets)} · Zeitprofil ${t(C.tprof)}</span><span class="d">nächste Prognose ${t(P.next_forecast)}${rel(P.next_forecast)} (früher bei Wal-/Leaderboard-Ereignis)</span></b></div>`
      +'</div>'; })()+(fc.analog_examples&&fc.analog_examples.length?`<div class="sub" style="margin-top:4px">Nächste Analoge: ${fc.analog_examples.map(e=>`${new Date(e.ts*1000).toLocaleDateString('de-DE')} (Abstand ${e.dist}, 24 h danach ${(e.r24*100).toFixed(1)} %)`).join(' · ')}</div>`:'');
 info.textContent=`Prognose von ${hm(fc.ts)} · Volatilität ${(fc.sigma_h*100).toFixed(2)} %/h · ${fc.n_directional_lb} direktionale Leaderboard-Konten berücksichtigt · nächste Berechnung in ≤ 15 min · Modell aus sichtbaren Daten, keine Vorhersage`;
}
fcInit(); loadForecast(); setInterval(()=>{ if(!SNAP_ACTIVE&&document.visibilityState!=='hidden') loadForecast(); }, 60000);
loadPool(); setInterval(()=>{ if(!SNAP_ACTIVE&&document.visibilityState!=='hidden') loadPool(); }, 300000);
loadProfis(); setInterval(()=>{ if(!SNAP_ACTIVE&&document.visibilityState!=='hidden') loadProfis(); }, 120000);

// ---- Systemüberwachung: alle 60 s -------------------------------------------------------
let LAST_SYS=null;
function tempColor(t){ return t==null?'#c9d1d9':t>=80?'#e04b4b':t>=70?'#d29922':t>=60?'#e3b341':'#3ba55d'; }
async function loadSystem(){
 try{ LAST_SYS=await getJSON('/system'); drawSystem(LAST_SYS); }catch(e){}
}
function drawSystem(S){
 const c=S.current||{}, k=$('syskpi'); if(!k) return;
 const up=c.uptime_s!=null?(c.uptime_s>=86400?(c.uptime_s/86400).toFixed(1)+' Tage':(c.uptime_s/3600).toFixed(1)+' h'):'—';
 const memPct=c.mem_total?(c.mem_total-c.mem_avail)/c.mem_total*100:null;
 const cpuCol=c.cpu_pct==null?'#c9d1d9':c.cpu_pct>=90?'#e04b4b':c.cpu_pct>=70?'#d29922':'#3ba55d';
 const flags=(c.throttle_flags||[]); const now=flags.filter(f=>/JETZT/.test(f)), past=flags.filter(f=>/seit Start/.test(f));
 k.innerHTML=`<div title="CPU-Temperatur aus der Thermal-Zone; Pi 5 drosselt ab 80 °C"><span>CPU-Temperatur</span><b style="color:${tempColor(c.temp)}">${c.temp!=null?c.temp.toFixed(1)+' °C':'—'}<span class="d">Maximum 24 h: ${S.max_24h!=null?S.max_24h.toFixed(1)+' °C':'—'}</span></b></div>`
  +`<div title="Drosselungsflags der Firmware (vcgencmd get_throttled). Temperaturlimit seit Start = der Pi hat seit dem Neustart mindestens einmal 85 °C erreicht und sich selbst gedrosselt: Kühlung prüfen."><span>Drosselung (Firmware)</span><b style="color:${now.length?'#e04b4b':past.length?'#d29922':'#3ba55d'}">${now.length?now.join(', '):past.length?'aktuell nicht':'keine'}<span class="d">${past.length?'seit Start: '+past.join(', '):(c.throttled_hex?'Flags '+c.throttled_hex:'kein vcgencmd — kein Raspberry?')}${past.some(f=>/Temperaturlimit|Unterspannung/.test(f))?' — <span style="color:#e04b4b">'+(past.some(f=>/Temperaturlimit/.test(f))?'85 °C erreicht: Kühlung unzureichend':'')+(past.some(f=>/Unterspannung/.test(f))?' Netzteil zu schwach':'')+'</span>':''}</span></b></div>`
  +`<div title="CPU-Takt jetzt"><span>CPU-Takt</span><b>${c.cpu_mhz!=null?Math.round(c.cpu_mhz)+' MHz':'—'}</b></div>`
  +`<div title="CPU-Auslastung aller Kerne zusammen in Prozent, gemittelt seit der letzten Messung (60 s); 100 % = alle ${c.n_cpu||'?'} Kerne voll"><span>CPU-Last gesamt (%)</span><b style="color:${cpuCol}">${c.cpu_pct!=null?c.cpu_pct.toFixed(1)+' %':'—'}<span class="d">Last 1 / 5 / 15 min: ${c.load?c.load.map(v=>v.toFixed(2)).join(' / '):'—'} (${c.n_cpu||'?'} Kerne)</span></b></div>`
  +`<div title="Projektversion (von Hand gepflegt) · Inhalts-Prüfsumme über alle Projektdateien (automatisch). Zum Abgleich mit dem gelieferten Paket: beide Werte müssen übereinstimmen."><span>Version</span><b style="font-size:15px">${esc(c.version||'—')}<span class="d">Version · Prüfsumme der Projektdateien</span></b></div>`
  +(c.cpu_by_service&&Object.keys(c.cpu_by_service).length?`<div title="CPU-Last je Dienst in Prozent EINES Kerns (utime+stime, Differenz zur letzten Messung); ${c.n_cpu||4} Kerne = ${(c.n_cpu||4)*100} % möglich. Rot ab 150 %, gelb ab 80 %"><span>CPU je Dienst</span><b style="font-size:14px">${Object.entries(c.cpu_by_service).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<span style="color:${v>=150?'#e04b4b':v>=80?'#d29922':'#c9d1d9'}">${k} ${v.toFixed(0)} %</span>`).join(' · ')}<span class="d">Summe ${Object.values(c.cpu_by_service).reduce((a,b)=>a+b,0).toFixed(0)} % von ${(c.n_cpu||4)*100} %</span></b></div>`:'')
  +`<div title="Arbeitsspeicher: gesamt und verfügbar (MemAvailable — wirklich nutzbar, inkl. freigebbarem Cache)"><span>RAM gesamt / frei</span><b style="color:${memPct==null?'#c9d1d9':memPct>=90?'#e04b4b':memPct>=75?'#d29922':'#c9d1d9'}">${c.mem_total?(c.mem_total/1e9).toFixed(2)+' GB / '+(c.mem_avail/1e9).toFixed(2)+' GB frei':'—'}<span class="d">${memPct!=null?'belegt '+memPct.toFixed(0)+' % · '+((c.mem_total-c.mem_avail)/1e9).toFixed(2)+' GB':''}</span></b></div>`
  +(c.disks||[]).map(d=>`<div title="${d.path}"><span>${d.label} frei</span><b style="color:${d.free/d.total<0.1?'#e04b4b':d.free/d.total<0.2?'#d29922':'#c9d1d9'}">${(d.free/1e9).toFixed(1)} GB<span class="d">von ${(d.total/1e9).toFixed(0)} GB · ${(d.free/d.total*100).toFixed(0)} % frei</span></b></div>`).join('')
  +`<div title="Laufzeit seit dem letzten Neustart"><span>Läuft seit</span><b>${up}</b></div>`
  +(()=>{ const th=LAST_CHART&&LAST_CHART.budget&&LAST_CHART.budget.thermal;
     const tip="Recorder: ab 70 °C 15 % weniger API-Gewicht und 15 % längere Takte, ab 75 °C 30 % / 45 %, ab 80 °C 50 % / 100 %; Hysterese 3 °C";
     if(!th||th.temp==null&&!th.level) return `<div title="${tip}"><span>Temperaturschutz Recorder</span><b style="color:#d29922">keine Meldung<span class="d">${LAST_CHART&&LAST_CHART.budget?'Recorder schreibt keine Temperaturwerte — Version vor dem Temperaturschutz oder noch kein Snapshot seit dem Neustart':'Recorder meldet kein Budget'}</span></b></div>`;
     const txt=th.level?`Stufe ${th.level} seit ${hm(th.since)}`:'inaktiv';
     const warn=(c.temp!=null&&c.temp>=70&&!th.level)?' · <span style="color:#e04b4b">Dashboard misst '+c.temp.toFixed(1)+' °C, Recorder drosselt nicht — Recorder-Version oder Messung prüfen</span>':'';
     return `<div title="${tip}"><span>Temperaturschutz Recorder</span><b style="color:${th.level?'#e04b4b':'#3ba55d'}">${txt}<span class="d">${th.level?`API-Gewicht ×${th.weight_factor.toFixed(2)} · Takte ×${th.interval_factor.toFixed(2)}`:'Schwellen 70 / 75 / 80 °C'}${th.temp!=null?` · Recorder misst ${th.temp.toFixed(1)} °C`:''}${warn}</span></b></div>`; })();
 const cv=$('syschart'); const [g,W,H]=fit(cv); g.clearRect(0,0,W,H); if(!W) return;
 const Hh=S.history||[];
 if(Hh.length<2){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText('Verlauf baut sich auf — eine Messung pro Minute',12,24); GEO.sys=null; return; }
 const L=44,R=44,T=10,B=24,pw=W-L-R,ph=H-T-B, t0=Hh[0][0], t1=Hh[Hh.length-1][0], X=t=>L+(t1>t0?(t-t0)/(t1-t0):0.5)*pw;
 const temps=Hh.map(h=>h[1]).filter(v=>v!=null); const lo=(temps.length?Math.min(30,...temps):30)-2, hi=(temps.length?Math.max(85,...temps):85)+2, Y=v=>T+(hi-v)/(hi-lo)*ph;
 g.strokeStyle='#161b22'; for(let k2=0;k2<=4;k2++){const y=T+ph*k2/4; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 [[70,'#d29922'],[80,'#e04b4b']].forEach(([v,col])=>{ g.strokeStyle=col; g.setLineDash([4,3]); g.beginPath(); g.moveTo(L,Y(v)); g.lineTo(W-R,Y(v)); g.stroke(); g.setLineDash([]); g.fillStyle=col; g.font='9px system-ui'; g.textAlign='left'; g.fillText(v+' °C',W-R+3,Y(v)+3); });
 g.strokeStyle='#e3b341'; g.lineWidth=1.6; g.beginPath(); let st=false; Hh.forEach((h,i)=>{ if(h[1]==null) return; st?g.lineTo(X(h[0]),Y(h[1])):g.moveTo(X(h[0]),Y(h[1])); st=true; }); g.stroke();
 g.strokeStyle='rgba(88,166,255,0.8)'; g.lineWidth=1; g.beginPath(); Hh.forEach((h,i)=>{ const y=T+ph-Math.min(100,Math.max(0,h[2]||0))/100*ph; i?g.lineTo(X(h[0]),y):g.moveTo(X(h[0]),y); }); g.stroke();
 g.fillStyle='#58a6ff'; g.font='9px system-ui'; g.textAlign='left'; g.fillText('100 %',W-R+3,T+ph*0.0+10); g.fillText('0 %',W-R+3,T+ph-2);
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right'; g.fillText(hi.toFixed(0)+'°',L-4,T+10); g.fillText(lo.toFixed(0)+'°',L-4,T+ph); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(t0),L,H-8); g.textAlign='right'; g.fillText(hm(t1),W-R,H-8); g.textAlign='left';
 GEO.sys={Hh,L,R,T,B,pw,ph,W,H};
 $('sysinfo').textContent=`${Hh.length} Messungen · Stand ${hm(c.ts)} · Farben: grün < 60, gelb < 70, orange < 80, rot ≥ 80 °C`;
}
loadSystem(); setInterval(()=>{ if(!SNAP_ACTIVE&&document.visibilityState!=='hidden') loadSystem(); }, 60000);
loadNetwork(); setInterval(()=>{ if(!SNAP_ACTIVE&&document.visibilityState!=='hidden') loadNetwork(); }, 30000);

// ---- Debug-Konsole ---------------------------------------------------------------
let DBG_JOB=null, DBG_TIMER=null, DBG_TEXT='';
let NET=null, NETKEY='';
const NETCOL={Poller:'#4a8cff', Orders:'#ff9f43', Fills:'#3ba55d', Leaderboard:'#c678dd', sonstiges:'#8b949e'};

async function loadNetwork(){
 try{ NET=await getJSON('/network'); }catch(e){ return; }
 drawNet(); fillNetJobs();
 try{ const w=+($('netextwin')?$('netextwin').value:30); NET_EXT=await getJSON('/network_ext?hours='+Math.max(1,Math.ceil(w/60))); NET_EXT.fenster_min=w; drawNetExt(); }catch(e){}
}
let NET_EXT=null;
const NETEXTCOL={Binance:'#ffd60a', Bybit:'#ff5c5c', OKX:'#b388ff', 'Crypto.com':'#2ec4ff', Coinbase:'#4ade80'};   // Gelb, Rot, Violett, Cyan, Grün -- keine zwei ähnlich
const NETEXT_REIHENFOLGE=['Binance','Bybit','OKX','Crypto.com','Coinbase'];
function drawNetExt(){
 const c=$('netext'); if(!c||!NET_EXT) return;
 const mins=NET_EXT.minutes||[], S=NET_EXT.series||{};
 const namen=NETEXT_REIHENFOLGE.filter(k=>S[k]&&S[k].some(v=>v>0));
 // Höhe nach Zahl der Spuren: je Börse eine Spur von 54 px, dazu Zeitachse
 const spur=54, hoehe=Math.max(120, namen.length*spur+26);
 if(c.dataset.h0!==String(hoehe)){ c.dataset.h0=String(hoehe); c.dataset.hm=String(hoehe); c.setAttribute('height', hoehe); }
 const [x,W,H]=fit(c); x.clearRect(0,0,W,H);
 const L=8,R=8,B=20;
 if(!mins.length||!namen.length){ x.fillStyle='#8b949e'; x.font='12px system-ui'; x.fillText('noch keine Zeilen der Fremdbörsen — Dienst hl-binance mit Sammler und hl-coinbase laufen?',L+44,H/2); return; }
 // Segmente: 30-min-Fenster = Minutenbalken, sonst 15-min-Balken; gleiche Segmentgrenzen für alle Spuren
 const fenster=NET_EXT.fenster_min||30, segS=fenster<=60?60:900, ende=mins[mins.length-1]+60, anfang=ende-fenster*60;
 const t0=Math.floor(anfang/segS)*segS, t1=mins[mins.length-1], nseg=Math.max(1, Math.ceil((ende-t0)/segS));
 const seg=k=>{ const a=new Array(nseg).fill(0); mins.forEach((m,i)=>{ if(m<t0) return; const j=Math.min(nseg-1, Math.floor((m-t0)/segS)); a[j]+=(S[k][i]||0); }); return a; };
 const jetzt=Date.now()/1000, T_=NET_EXT.totals||{}, La=NET_EXT.last||{};
 const erwartet={Binance:900, Bybit:600, OKX:600, 'Crypto.com':600, Coinbase:120};
 const alter=t=>{ if(!t) return 'nie'; const s_=jetzt-t; return s_<90?Math.round(s_)+' s':s_<5400?Math.round(s_/60)+' min':(s_/3600).toFixed(1)+' h'; };
 const pw=W-L-R, bw=pw/nseg;
 namen.forEach((k,row)=>{
  const top=row*spur, ph=spur-14, y0=top+12+ph;               // Kopfzeile 12 px, dann Balkenfeld
  const a=seg(k), ymax=Math.max(1, Math.max(...a)*1.25), col=NETEXTCOL[k]||'#8b949e';   // 25 % Luft nach oben
  // Feld
  x.fillStyle='#0d1117'; x.fillRect(L,top+12,pw,ph);
  x.strokeStyle='#21262d'; x.lineWidth=1; x.beginPath(); x.moveTo(L,y0+0.5); x.lineTo(W-R,y0+0.5); x.stroke();
  // Balken je 15-min-Segment (das laufende, unvollständige Segment gedämpft)
  const dicke=Math.max(1, bw*0.5);                                          // halbe Balkendicke, mittig im Segment
  a.forEach((v,j)=>{ const h=v/ymax*ph, unvoll=(j===nseg-1); x.fillStyle=col+(unvoll?'66':'cc'); x.fillRect(L+j*bw+(bw-dicke)/2, y0-h, dicke, h); });
  // Kopfzeile: Name, Zeilen/h, Alter, Skala
  const warn=!La[k]||(jetzt-La[k])>(erwartet[k]||900);
  x.font='bold 11px system-ui'; x.fillStyle=col; x.fillText(k, L, top+10);
  x.font='10px system-ui'; x.fillStyle=warn?'#d29922':'#8b949e';
  const info=`${T_[k]||0}/h · jüngste vor ${alter(La[k])}${warn?' — Fluss unterbrochen?':''}`;
  x.fillText(info, L+x.measureText(k).width+14, top+10);
  x.fillStyle='#6e7681'; const sk=`max ${Math.round(Math.max(...a))}/${segS===60?'min':'15 min'}`; x.fillText(sk, W-R-x.measureText(sk).width, top+10);
 });
 // Zeitachse: Stundenlinien nur in den Balkenfeldern (nicht durch die Kopfzeilen), kurze Uhrzeiten,
 // auf schmalen Bildschirmen nur jede zweite Stunde beschriftet; das Datum einmal links
 x.font='10px system-ui'; const kurz=t=>new Date(t*1000).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
 const linie=segS===60?5:4, schritt=segS===60?((W<600)?10:5):((W<600)?8:4);   // Linien alle 5 min bzw. jede Stunde
 for(let j=0;j<=nseg;j+=linie){ const xx=L+j*bw; x.strokeStyle='#30363d';
  namen.forEach((k,row)=>{ const top=row*spur, ph=spur-14; x.beginPath(); x.moveTo(xx+0.5,top+12); x.lineTo(xx+0.5,top+12+ph); x.stroke(); });
  if(j<nseg&&j%schritt===0){ const lbl=(j===0?hm(t0+j*segS):kurz(t0+j*segS)); if(xx+2>=(x._lblEnde||0)){ x.fillStyle='#8b949e'; x.fillText(lbl, xx+2, H-6); x._lblEnde=xx+2+x.measureText(lbl).width+8; } } }   // erstes Label mit Datum; überlappende Labels auslassen
 x._lblEnde=0;
 // Infozeile: Sammler-Zähler (die Spuren tragen die Börsenwerte schon im Kopf)
 const sm=NET_EXT.sammler||{};
 $('netextinfo').innerHTML=sm.events!=null?`Sammler: Binance-Stream ${(sm.events||0).toLocaleString('de-DE')} Ereignisse seit Start, Bybit-Stream ${(sm.ext_bybit_ws_events||0).toLocaleString('de-DE')} (${sm.ext_bybit_ws_reconnects||0} Reconnects) · Fehler ${sm.ext_fehler||0} · DB-Sperre ${sm.ext_db_retry||0} wiederholt / ${sm.ext_db_locked||0} verloren${sm.letzter_fehler?` · letzter Fehler: ${esc(sm.letzter_fehler)}`:''}`:'';
}

function drawNet(){
 const c=$('netchart'); if(!c||!NET) return;
 const [x,W,H]=fit(c);        // fit liefert Kontext, Breite und Höhe -- nicht nur die Breite
 x.clearRect(0,0,W,H);
 const L=52,R=10,T=10,B=22, rows=NET.load||[], quellen=NET.quellen||[];
 if(!rows.length){ x.fillStyle='#8b949e'; x.font='12px system-ui'; x.fillText('noch keine Lastdaten — der Recorder schreibt sie je Minute',L,H/2); return; }
 const budget=(NET.limit&&NET.limit.limit)||1200, deckel=(NET.limit&&NET.limit.budget)||budget;   // rote Linie = hartes Limit, gelbe = Deckel des Begrenzers
 const summen=rows.map(r=>quellen.reduce((a,q)=>a+(r[q]||0),0));
 const ymax=Math.max(budget*1.05, ...summen)||1;
 const t0=rows[0].ts, t1=rows[rows.length-1].ts||t0+1;
 const X=t=>L+(t-t0)/Math.max(t1-t0,1)*(W-L-R), Y=v=>T+(1-v/ymax)*(H-T-B);
 // Raster
 x.strokeStyle='#21262d'; x.fillStyle='#8b949e'; x.font='10px system-ui'; x.lineWidth=1;
 for(let i=0;i<=4;i++){ const v=ymax*i/4, y=Y(v); x.beginPath(); x.moveTo(L,y); x.lineTo(W-R,y); x.stroke(); x.fillText(Math.round(v),4,y+3); }
 // Grenze
 x.strokeStyle='#e04b4b'; x.setLineDash([4,3]); x.beginPath(); x.moveTo(L,Y(budget)); x.lineTo(W-R,Y(budget)); x.stroke(); x.setLineDash([]);
 x.fillStyle='#e04b4b'; x.fillText('Limit '+budget+'/min', L+4, Y(budget)-4);
 if(deckel<budget){ x.strokeStyle='#d29922'; x.setLineDash([2,3]); x.beginPath(); x.moveTo(L,Y(deckel)); x.lineTo(W-R,Y(deckel)); x.stroke(); x.setLineDash([]); x.fillStyle='#d29922'; x.fillText('Deckel '+deckel+'/min', L+4, Y(deckel)+11); }
 // Flächen je Verbraucher, aufeinander gestapelt
 const unten=rows.map(()=>0);
 quellen.forEach(q=>{
  x.beginPath();
  rows.forEach((r,i)=>{ const y=Y(unten[i]+(r[q]||0)); i?x.lineTo(X(r.ts),y):x.moveTo(X(r.ts),y); });
  for(let i=rows.length-1;i>=0;i--) x.lineTo(X(rows[i].ts),Y(unten[i]));
  x.closePath(); x.fillStyle=(NETCOL[q]||'#8b949e')+'55'; x.fill();
  x.strokeStyle=NETCOL[q]||'#8b949e'; x.lineWidth=1; x.beginPath();
  rows.forEach((r,i)=>{ const y=Y(unten[i]+(r[q]||0)); i?x.lineTo(X(r.ts),y):x.moveTo(X(r.ts),y); }); x.stroke();
  rows.forEach((r,i)=>unten[i]+=(r[q]||0));
 });
 // Zeitachse
 x.fillStyle='#8b949e';
 x.fillText(hm(t0),L,H-6); x.fillText(hm(t1),W-R-34,H-6);
 // Legende
 let lx=L+70;
 quellen.forEach(q=>{ x.fillStyle=NETCOL[q]||'#8b949e'; x.fillRect(lx,H-14,8,8); x.fillStyle='#c9d1d9'; x.fillText(q,lx+11,H-6); lx+=x.measureText(q).width+26; });
}

function fillNetJobs(){
 if(!NET) return;
 const Lm=NET.limit||{}, jetzt=Date.now()/1000;
 const limit=Lm.limit||1200, deckel=Lm.budget||limit, pctL=Lm.used/limit*100, pctD=Lm.used/deckel*100;
 const farbe=pctL>97?'#e04b4b':pctL>92?'#d29922':'#3ba55d';   // Farbe gegen das harte Limit; der Deckel (90 %) ist das Soll
 const lag=Lm.fills_lag;
 $('netlimit').innerHTML=`<b>Ratengrenze:</b> <span style="color:${farbe}" title="Deckel = Angebot des Begrenzers (90 % des Limits, thermisch skalierbar); Auslastung nahe 100 % des Deckels ist das Ziel">${Lm.used||0} je Minute = ${pctD.toFixed(0)} % des Deckels ${deckel} (${pctL.toFixed(0)} % des Limits ${limit})</span>`
  +` · abgewiesene Anfragen (429): ${Lm.rate_limited||0}`
  +(Lm.thermal_level?` · <span style="color:#d29922">Temperaturschutz Stufe ${Lm.thermal_level} bei ${Lm.thermal_temp} °C, Takte x${Lm.interval_factor}</span>`:'')
  +`<br><b>Gesperrt (Masterregel):</b> <span title="Konten mit mehr als 300 gebündelten Trades (je Coin, Minute und Richtung) in 24 h werden dauerhaft gesperrt: kein Verhaltenssignal, keine Order-Abfrage, keine Fill-Speicherung, Positionen nur alle 6 h für die Heatmap. Manuell: labels.json &quot;sperre&quot;: true/false">${Lm.gesperrt||0} Konten</span>`
  +`<br><b>Adress-Poller:</b> ${Lm.poller_batch||0} von ${Lm.poller_want||0} je Runde${Lm.poller_pool_anteil!=null?` · <span title="Anteil der Pool-Konten (Aktive Profis, alle 10 min) am Poller-Budget in den letzten 10 min -- der Pool konkurriert mit den heißen Konten um dieselben Runden">Pool-Anteil ${Lm.poller_pool_anteil} %</span>`:''}`
  +(Lm.poller_drossel&&Lm.poller_drossel<1?` <span style="color:#d29922">· auf ${(Lm.poller_drossel*100).toFixed(0)} % gedrosselt zugunsten der Fill-Abholung</span>`:'')
  +`${Lm.poller_want&&Lm.poller_batch>=Lm.poller_want?'':' <span style="color:#d29922">— Stapel nicht voll</span>'}`
  +(Lm.stream_fills_konten?` · <b>Fills live:</b> Trade-Stream für ${Lm.stream_fills_konten} Konten — ${Lm.stream_fills_min} in der letzten Minute, ${Lm.stream_fills_10min||0} in 10 min, ${Lm.stream_fills_total||0} seit Start (minütlich geschrieben, 0 Gewicht; Stream liefert ${Lm.stream_trades_min||0} Trades/min mit Adressen)`:'')
  +(NET.af&&NET.af.letzte_minute?`<br><b title="23.33: jeder Trade der verfolgten Coins je Minute und Adresse (Nehmer/Geber, Kauf/Verkauf, TWAP-Anteil) in adressfluss.db neben der Datenbank -- 0 Gewicht, nicht im Backup">Adress-Strom:</b> ${NET.af.trades_min} Trades in der letzten vollen Minute, davon ${NET.af.trades_min?(NET.af.nullhash_min/NET.af.trades_min*100).toFixed(1):'0'} % mit Null-Hash (vermutlich TWAP) · ${NET.af.adressen_min} Adressen je Minute${NET.af.adressen_h!=null?', '+NET.af.adressen_h.toLocaleString('de-DE')+' in der letzten Stunde':''} · ${NET.af.zeilen_min} Zeilen/min in adressfluss.db${NET.af.groesse_mb!=null?' ('+NET.af.groesse_mb.toLocaleString('de-DE')+' MB':' ('}, Vorhalt ${NET.af.tage} Tage, Deckel ${NET.af.max_gb} GB${NET.af.seit?', seit '+hm(NET.af.seit):''})${NET.af.schreib_ms!=null?' · Schreiben '+NET.af.schreib_ms+' ms':''}${NET.af.rueckstand?` · <span style="color:#d29922">${NET.af.rueckstand} Zeilen warten auf den nächsten Schreibversuch</span>`:''}${NET.af.fehler?` · <span style="color:#d29922">${esc(NET.af.fehler)}</span>`:''}`:(NET.af&&NET.af.tage?'<br><b>Adress-Strom:</b> wartet auf die erste volle Minute':''))
  +(NET.dwf&&NET.dwf.konten!=null?`<br><b title="23.34: Die Fills der Darwin-Liste werden ohne Mindestbetrag gesammelt (andere Konten ab 2.500 USD) -- sonst blieb eine in kleine Stücke zerlegte Eröffnung unsichtbar. Höchstens 200 kleine Fills je Konto, Stunde und Quelle.">Darwin-Fills:</b> ${NET.dwf.konten} Konten ohne Mindestbetrag · ${(NET.dwf.klein||0).toLocaleString('de-DE')} kleine Fills seit dem Start${NET.dwf.gedeckelt?` · <span style="color:#d29922">${NET.dwf.gedeckelt.toLocaleString('de-DE')} über dem Deckel verworfen</span>`:''}`:'')
  +(lag?` · <b>Nachtrag von closedPnl/fee/dir per REST:</b> ${lag.hinten?`<span style="color:#d29922">${lag.hinten} von ${lag.n} Konten im Rückstand</span>`:`alle ${lag.n} Konten`}, Median ${lag.median_h<1?Math.round(lag.median_h*60)+' min':lag.median_h.toFixed(1)+' h'}, schlechtestes ${lag.max_h.toFixed(1)} h${Lm.fills_takt_s?` (Takt ${Math.round(Lm.fills_takt_s/60)} min nach freiem Budget)`:''}${Lm.lb_takt_s?` · Leaderboard-Stände alle ${Lm.lb_takt_s} s`:''}`:'')
  +(Lm.deferred?` · ${Lm.deferred} Konten wegen Gewichtsbudget zurückgestellt`:'')
  +(Lm.wlock&&Object.keys(Lm.wlock).length?`<br><b>Schreibkoordination:</b> `+Object.entries(Lm.wlock).map(([n,v])=>`${n}: ${v.erwerbe||0} Transaktionen, wartet Ø ${v.wartezeit_mittel_ms||0} ms (max ${v.max_wartezeit_ms||0}), hält Ø ${v.haltezeit_mittel_ms||0} ms (max ${v.max_haltezeit_ms||0})${v.fristen?`, <span style="color:#d29922">${v.fristen} Fristen überschritten</span>`:''}${v.held_over_1s?`, ${v.held_over_1s}× über 1 s gehalten`:''}${v.laengste&&v.laengste.length?` — längste: `+v.laengste.slice(0,3).map(x=>`${x[0]} s „${esc(String(x[1]))}"`).join(', '):''}`).join(' · ')+` — eine Sperre für alle Schreiber (hl_dbcoord), Warten statt Scheitern`:'')
  +(Lm.db_locked?` · <span style="color:#d29922">${Lm.db_locked} Schreibversuche auf gesperrte Datenbank (abgewartet, nicht verloren)</span>`:'')
  +(Lm.alive&&jetzt-Lm.alive>180?`<br><span style="color:#e04b4b"><b>Recorder meldet sich nicht</b> — letztes Lebenszeichen ${hm(Lm.alive)}</span>`:'')
  +(Lm.cb_alive?`<br><b>Coinbase:</b> ${jetzt-Lm.cb_alive<180
      // Die tatsächlich abgerufenen Paare zeigen, nicht nur die Coin-Namen: Welches
      // Paar je Coin gewählt wurde, ist die eigentliche Information -- intern ordnet
      // der Dienst es ohnehin dem Coin zu, sichtbar war die Wahl bisher nicht.
      ?`aktiv: ${esc(Lm.cb_products||'—').split(',').join(' · ')}`
       +(Lm.cb_fehlend?` · <span class="lbl-dim">dort nicht gelistet: ${esc(Lm.cb_fehlend).split(',').join(', ')}</span>`:'')
      :`<span style="color:#e04b4b">meldet sich nicht, zuletzt ${hm(Lm.cb_alive)}</span>`} · eigene Grenze 10 Anfragen/s, unabhängig vom Hyperliquid-Budget`:'<br><b>Coinbase:</b> <span style="color:#8b949e">Dienst nicht eingerichtet</span>');

 const zeile=(name,j,quelle)=>{
  const last=j.last, next=j.next, takt=j.takt;
  const alt=last?jetzt-last:null, rest=next?next-jetzt:null;
  const spaet=takt&&alt!=null&&alt>takt*2.5;
  return `<tr><td>${name}</td><td class="n">${quelle}</td>`
   +`<td class="n" style="${spaet?'color:#d29922':''}">${last?(alt<90?Math.round(alt)+' s':alt<5400?Math.round(alt/60)+' min':(alt/3600).toFixed(1)+' h'):'—'}</td>`
   +`<td class="n">${j.dauer!=null?j.dauer+' s':'—'}</td>`
   +`<td class="n">${rest!=null?(rest<=0?'jetzt':rest<90?Math.round(rest)+' s':rest<5400?Math.round(rest/60)+' min':(rest/3600).toFixed(1)+' h'):(takt?'laufend':'—')}</td>`
   +`<td>${j.ok===false?'<span style="color:#e04b4b">Fehler</span> ':''}${esc(j.info||'')}</td></tr>`;
 };
 const key=JSON.stringify([NET.jobs,NET.forecast,NET.errors,(NET.datenquellen||[]).map(q=>[q.name,q.status])]);
 if(key===NETKEY) return;                      // unverändert: Tabelle stehen lassen
 NETKEY=key;
 const dauer=v=>v==null?'—':v<90?Math.round(v)+' s':v<5400?Math.round(v/60)+' min':(v/3600).toFixed(1)+' h';
 const FARBE={ok:'#3ba55d', still:'#d29922', fehlt:'#8b949e', fehler:'#e04b4b', wackelig:'#d29922'};
 const WORT={ok:'läuft', still:'keine neuen Daten', fehlt:'nicht eingerichtet', fehler:'Fehler', wackelig:'läuft, mit Aussetzern'};
 let qhtml='<div class="sub" style="margin:10px 0 4px"><b>Datenquellen</b> — woher die Zahlen kommen</div>'
  +'<table class="w"><tr><th>Quelle</th><th class="n">letzte Daten</th><th class="n">erwartet</th><th>Zustand</th><th>Hinweis</th></tr>';
 (NET.datenquellen||[]).forEach(q=>{ qhtml+=`<tr><td><b>${q.name}</b></td>`
   +`<td class="n">${q.status==='fehlt'?'—':'vor '+dauer(q.alter_s)}</td>`
   +`<td class="n">${q.erwartet_txt||(q.erwartet_s?'unter '+dauer(q.erwartet_s):'—')}</td>`
   +`<td style="color:${FARBE[q.status]||'#c9d1d9'}">${WORT[q.status]||q.status}</td>`
   +`<td class="lbl-dim">${esc(q.hinweis||'')}</td></tr>`; });
 qhtml+='</table>';
 $('netquellen').innerHTML=qhtml;

 let html='<div class="sub" style="margin:10px 0 4px"><b>Zeitplan</b> — was wann läuft (Angaben relativ zu jetzt)</div>'
  +'<table class="w"><tr><th>Aufgabe</th><th class="n">Quelle</th><th class="n">zuletzt vor</th><th class="n">Dauer</th><th class="n">nächste in</th><th>Ergebnis</th></tr>';
 Object.entries(NET.jobs||{}).sort((a,b)=>(a[1].takt||0)-(b[1].takt||0))
   .forEach(([k,v])=>html+=zeile(k,v,/^Coinbase/.test(k)?'Coinbase':/^Binance/.test(k)?'Binance':'Hyperliquid'));
 Object.entries(NET.forecast||{}).forEach(([k,v])=>html+=zeile(k,v,'lokal'));
 html+='</table>';
 $('netjobs').innerHTML=html;

 const E=NET.errors||{};
 const eintraege=Object.entries(E).filter(([k,v])=>v&&v.ts);
 $('neterr').innerHTML=eintraege.length
  ? '<div class="sub" style="margin:10px 0 4px"><b>Fehler</b></div>'
    +eintraege.map(([k,v])=>`<div class="sub" style="color:#ffb4b4">${k}: ${v.count}× · zuletzt ${hm(v.ts)} · ${esc(v.error)}</div>`).join('')
  : '<div class="sub" style="margin:10px 0 0;color:#3ba55d">Keine Aufgabe hat einen Fehler gemeldet.</div>';
}

async function dbgInit(){
 try{ const l=await getJSON('/debug/list'); const sel=$('dbgselect'); sel.innerHTML=Object.entries(l).map(([k,v])=>`<option value="${k}">${v}</option>`).join('');
  $('dbgrun').onclick=dbgRun; $('dbgcopy').onclick=dbgCopy; $('dbgsel').onclick=dbgSelectAll; $('dbgsave').onclick=dbgSave; }catch(e){}
 berichteLaden(); setInterval(berichteLaden, 120000);
}
// Berichtsplan (23.09.): geplante Debug-Läufe, gespeichert auf dem Pi unter berichte/ -- einzeln oder als Sammeldatei
async function berichteLaden(){
 let b; try{ b=await getJSON('/berichte'); }catch(e){ return; }
 const el=$('berichte'); if(!el) return;
 const esc=x=>String(x).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const dt=ts=>hm(ts);
 const WT=['Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag','Sonntag'];
 let h=`<div class="sub" style="margin:0 0 4px"><b>Berichtsplan</b> — läuft von selbst und speichert auf dem Pi unter berichte/${b.aktiv?'':' · <span style="color:#d29922">nicht aktiv</span>'}${b.laeuft?' · läuft gerade: '+esc(b.laeuft):''}</div>`;
 h+='<table style="width:100%;border-collapse:collapse;font-size:13px"><tr style="color:#8b949e;text-align:left"><th>Wann</th><th>Wofür</th><th>Stand</th></tr>';
 (b.plan||[]).forEach(p=>{ const wann=p.art==='woechentlich'?`jeden ${WT[p.woechentlich[0]]} ${p.woechentlich[1]}<br><span class="sub">nächster ${dt(p.naechster)}</span>`:(p.naechster?dt(p.naechster):'—');
   const stand=p.verpasst?'<span style="color:#d29922">verpasst</span>':p.letzter?'erledigt '+dt(p.letzter):'offen';
   h+=`<tr style="border-top:1px solid #21262d;vertical-align:top"><td style="padding:3px 6px 3px 0;white-space:nowrap">${wann}</td><td style="padding:3px 6px" title="${esc(p.laeufe.join(' · '))}">${esc(p.zweck)}</td><td style="padding:3px 0;white-space:nowrap">${stand}</td></tr>`; });
 h+='</table>';
 h+=`<div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:8px 0"><span class="sub">Zum Hochladen:</span><button class="tog ${b.neu?'on':'off'}"${b.neu?'':' disabled'} onclick="location.href='/berichte/neu';setTimeout(berichteLaden,2500)">Neue Berichte (${b.neu||0})</button>${b.letzter_abruf_n?`<button class="tog off" onclick="location.href='/berichte/letzter'">Letzten Abruf nochmal (${b.letzter_abruf_n})</button>`:''}<span class="sub">oder alle:</span><button class="tog off" onclick="location.href='/berichte/sammel?tage=1'">letzte 24 h</button><button class="tog off" onclick="location.href='/berichte/sammel?tage=7'">letzte 7 Tage</button></div>`;
 const d=b.dateien||[];
 h+=d.length?'<div class="sub" style="margin:4px 0">Gespeicherte Berichte, neueste zuerst:</div>'+d.slice(0,15).map(f=>`<div${f.abgeholt?' style="opacity:.55"':''}><a href="/bericht?name=${encodeURIComponent(f.name)}" target="_blank">${esc(f.name)}</a> <span class="sub">${f.kb} kB${f.abgeholt?' · abgeholt '+dt(f.abgeholt):''}</span></div>`).join(''):'<div class="sub">Noch keine gespeicherten Berichte.</div>';
 el.innerHTML=h;
}
function dbgSelectAll(){ const ta=$('dbgout'); ta.focus(); ta.select(); try{ ta.setSelectionRange(0, ta.value.length); }catch(e){} $('dbgstate').textContent='markiert — jetzt „Kopieren" im Handy-Menü antippen'; }
function dbgSave(){
 const t=DBG_TEXT||$('dbgout').value; const name=($('dbgselect').value||'debug')+'_'+new Date().toISOString().slice(0,16).replace(/[:T]/g,'-')+'.txt';
 const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([t],{type:'text/plain;charset=utf-8'})); a.download=name; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(a.href); a.remove();},1000);
 $('dbgstate').textContent='als '+name+' gespeichert — aus dem Download-Ordner teilen';
}
async function dbgRun(){
 const name=$('dbgselect').value; $('dbgrun').disabled=true; $('dbgcopy').disabled=true; $('dbgsel').disabled=true; $('dbgsave').disabled=true; $('dbgout').value=''; $('dbgstate').textContent='startet …';
 try{ const r=await fetch('/debug/run?name='+encodeURIComponent(name)+'&coin='+encodeURIComponent($('coin').value||'BTC'),{method:'POST',headers:{'X-HL-Request':'1'}}); const j=await r.json();
  if(!j.ok){ $('dbgstate').textContent=j.msg; $('dbgrun').disabled=false; return; }
  DBG_JOB=j.id; $('dbgout').value='$ '+j.cmd+'\\n'; dbgPoll();
 }catch(e){ $('dbgstate').textContent='Fehler: '+(e.message||e); $('dbgrun').disabled=false; }
}
async function dbgPoll(){
 try{ const st=await getJSON('/debug/status?id='+encodeURIComponent(DBG_JOB));
  if(!st.ok){ $('dbgstate').textContent=st.msg; $('dbgrun').disabled=false; return; }
  const head='$ '+st.cmd+'\\n'; $('dbgout').value=head+(st.output||''); $('dbgout').scrollTop=$('dbgout').scrollHeight;
  if(st.running){ $('dbgstate').textContent=`läuft … ${st.seconds} s`; DBG_TIMER=setTimeout(dbgPoll,1000); return; }
  $('dbgstate').textContent=`fertig nach ${st.seconds} s · Exit ${st.rc}`; $('dbgrun').disabled=false; $('dbgcopy').disabled=false; $('dbgsel').disabled=false; $('dbgsave').disabled=false;
  DBG_TEXT=`# ${st.label}\\n# ${new Date().toLocaleString('de-DE')} · Coin ${$('coin').value} · Quelle ${SRC_NAME[SRC()]} · Exit ${st.rc} · ${st.seconds} s\\n`+head+(st.output||'');
 }catch(e){ $('dbgstate').textContent='Verbindung verloren, versuche weiter …'; DBG_TIMER=setTimeout(dbgPoll,2000); }
}
async function dbgCopy(){
 // 1. Zwischenablage-API (nur HTTPS/localhost) · 2. execCommand über das sichtbare Textfeld (auch HTTP) · 3. markieren lassen
 const t=DBG_TEXT||$('dbgout').value; let ok=false;
 if(navigator.clipboard&&window.isSecureContext){ try{ await navigator.clipboard.writeText(t); ok=true; }catch(e){} }
 if(!ok){ try{ const ta=$('dbgout'); const keep=ta.value; ta.value=t; ta.readOnly=false; ta.focus(); ta.select(); ta.setSelectionRange(0,t.length); ok=document.execCommand('copy'); ta.readOnly=true; ta.value=keep; ta.blur(); }catch(e){} }
 if(ok){ $('dbgstate').textContent='in die Zwischenablage kopiert'; }
 else { dbgSelectAll(); $('dbgstate').textContent='Zwischenablage über HTTP gesperrt — Text ist markiert: „Kopieren" im Handy-Menü, oder „Als Datei"'; }
}
dbgInit();

// ---- Update-Knopf --------------------------------------------------------------
let updTimer=null;
async function pollUpdate(reloadWhenDone){
 const pre=$('updlog'); pre.style.display='block';
 try{ const r=await fetch('/update/status',{cache:'no-store'}); const st=await r.json();
  pre.textContent=(st.log||'(noch keine Ausgabe)')+(st.running?'\\n… läuft …':'');
  pre.scrollTop=pre.scrollHeight;
  if(st.done){ clearTimeout(updTimer); updTimer=null; $('updbtn').disabled=false;
   $('updbtn').textContent=st.ok_marker?'Update fertig — Seite lädt neu':'Update mit Fehler beendet';
   if(st.ok_marker&&reloadWhenDone) setTimeout(()=>location.reload(true),2500); return; }
 }catch(e){ pre.textContent=(pre.textContent||'')+'\\n… Dashboard startet neu, warte …'; }
 updTimer=setTimeout(()=>pollUpdate(reloadWhenDone),3000);
}
async function runUpdate(){
 if(!confirm('Update von GitHub laden und einspielen?\\nDienste werden neu gestartet, die Aufzeichnung pausiert etwa eine Minute.')) return;
 const b=$('updbtn'); b.disabled=true; b.textContent='Lade Archiv …';
 try{ const r=await fetch('/update',{method:'POST',headers:{'X-HL-Request':'1'}}); const j=await r.json();
  $('updlog').style.display='block'; $('updlog').textContent=j.msg;
  if(!j.ok){ b.disabled=false; b.textContent='Update von GitHub einspielen'; return; }
  b.textContent='Update läuft …'; pollUpdate(true);
 }catch(e){ b.disabled=false; b.textContent='Update von GitHub einspielen'; showErr('Update: '+e.message); }
}
// 23.22: Timing-Bilanz je Konto, Alter der Trades, gemeinsame Zeitleiste; Liste lädt sich jede Minute neu, solange sichtbar
function profisAlter(ts){ const m=Math.max(0,(Date.now()/1000-ts)/60); return m<60?`vor ${m.toFixed(0)} min`:m<1440?`vor ${(m/60).toFixed(1)} h`:`vor ${(m/1440).toFixed(1)} T`; }
function profisTiming(k){
 const B=k.bilanz||{}, Z=k.zuerst||{}, T=k.tempo||{};
 const q=x=>x==null?'—':(x*100).toFixed(0)+' %', f=(b,w)=>b&&b.n?`${b.n} → ${b.treffer} ${w} (Zufall ${q(b.zufall)})`:'—';
 const vs=x=>x&&x.n&&x.zufall!=null?(x.treffer/x.n-x.zufall)*100:null, pp=v=>v==null?'—':(v>=0?'+':'')+v.toFixed(0)+' pp';
 const TB=k.timing||{};
 return (TB.n?`<div class="sub" style="margin-top:4px" title="Alle Ein- und Ausstiege der letzten 14 Tage zusammen (gleichgerichtete im selben 4-h-Block einmal). Aufnahme: mindestens 6, Glück höchstens 1 %, Vorsprung mindestens 10 Punkte. Verbleib: mindestens 4, Glück höchstens 50 %. Die Reihenfolge nutzt eine Untergrenze, in der kleine Zahlen gedämpft sind.">Timing-Beleg 14 T: <b>${TB.treffer} von ${TB.n}</b> Ein-/Ausstiegen richtig (${TB.n_ein} Ein-, ${TB.n_aus} Ausstiege; Zufall ${q(TB.zufall)}) · Glückswahrscheinlichkeit <b>${TB.p_glueck!=null?(TB.p_glueck*100).toFixed(TB.p_glueck<0.01?1:0)+' %':'—'}</b></div>`:'')
  +`<div class="sub" style="margin-top:2px" title="Treffer = Kursbewegung ≥ 2 % in die richtige Richtung binnen 12 h. Richtig: Long auf vor Anstieg, Short auf vor Rückgang, Long zu vor Rückgang, Short zu vor Anstieg. Zufall = derselbe Coin, dieselbe Richtung, zufällige Zeitpunkte.">Timing-Bilanz: Einstiege Long ${f(B.long_ein,'gestiegen')} · Short ${f(B.short_ein,'gefallen')} · Ausstiege Long ${f(B.long_aus,'gefallen')} · Short ${f(B.short_aus,'gestiegen')}</div>`
  +`<div class="sub" title="Zuerst richtig: lief der Kurs nach dem Trade erst 2 % in die richtige Richtung, bevor er 2 % in die falsche lief? Vorsprung: Trefferquote minus Zufall nach 1, 4 und 12 h. Vorerst nur Anzeige.">Zuerst richtig ${Z.n?`${Z.richtig} von ${Z.n} (Zufall ${q(Z.zufall)})`:'—'}${Z.offen?` · offen ${Z.offen}`:''} · Vorsprung 1 h ${pp(vs(T['1h']))} · 4 h ${pp(vs(T['4h']))} · 12 h ${pp(vs(T['12h']))}</div>`;
}
function profisRegeltext(R){
 const p=v=>v==null?'—':(v*100).toFixed(0)+' %';
 return `Darwin-Liste, Regeln v${R.version||3} (23.38). Aufnahme (alles Pflicht): Kontowert ≥ 1 Mio, nicht gesperrt, ${R.min_trades||2}–${R.max_trades||150} gebündelte Trades/Tag in den verfolgten Coins (7 T), Gewinn 7 T und 30 T > 0, mindestens ${R.aufnahme_n||6} bewertbare Ein- und Ausstiege in ${R.timing_tage||14} T, deren Trefferbilanz (Bewegung ≥ 2 % in die richtige Richtung binnen 12 h) höchstens mit ${p(R.aufnahme_p)} Wahrscheinlichkeit Glück ist, Vorsprung vor dem Zufall mindestens ${((R.aufnahme_vorsprung||0.1)*100).toFixed(0)} Punkte; Einstiege ab 5 nur als Veto. Verbleib: ${R.verbleib_trades||1}–${R.max_trades||150} Trades/Tag, Gewinn 30 T > 0, mindestens ${R.verbleib_n||4} Ein-/Ausstiege, Glück höchstens ${p(R.verbleib_p)}. Entschieden wird einmal täglich (erste Bewertung nach 00 UTC); Abstieg erst nach ${R.abstieg_tage||3} Tagen in Folge ohne Verbleib. Diese Schonung gilt nur für Konten, die über die strenge Aufnahme kamen -- jeder Weg auf die Liste verlangt sie (v3, 23.38); beim Umstieg flog, wer ohne sie auf der Liste stand und sie nicht erfüllte.`;
}
function profisProtokoll(d){
 const ob=d.ohne_bewertung||[], zu=d.zugaenge||[], ab=d.abgaenge||[];
 const nm=e=>hsLink(e.addr, esc(e.name||e.addr.slice(0,6)+'…'+e.addr.slice(-4)));
 let h='';
 if(ob.length) h+=`<div class="sub" style="margin-top:8px;color:#d29922">Auf der Liste, aber ohne Bewertung: `+ob.map(e=>`${nm(e)} — ${esc(e.grund)}${e.verfehlt?` (Fehltag ${e.verfehlt})`:''}`).join(' · ')+'</div>';
 if(zu.length||ab.length){
  h+=`<div class="sub" style="margin:12px 0 4px"><b>Zu- und Abgänge</b> — letzte 7 Tage, neueste zuerst</div><div style="overflow-x:auto"><table class="w"><tr><th>Zeit</th><th></th><th>Konto</th><th>Grund</th></tr>`
   +[...zu.map(e=>Object.assign({art:'rein'},e)),...ab.map(e=>Object.assign({art:'raus'},e))].sort((a,b)=>b.ts-a.ts)
     .map(e=>`<tr><td class="mono">${hm(e.ts)}</td><td style="color:${e.art==='rein'?'#3fb950':'#f85149'}">${e.art==='rein'?'▲ rein':'▼ raus'}</td><td>${nm(e)}</td><td style="white-space:normal">${esc(e.grund||'')}</td></tr>`).join('')+'</table></div>';
 }
 return h;
}
function profisZeitleiste(d){
 const z=d.zeitleiste||[]; if(!z.length) return '';
 return `<div class="sub" style="margin:12px 0 4px"><b>Zeitleiste</b> — die jüngsten Trades aller Konten der Liste, neueste zuerst</div><table class="w"><tr><th>Zeit</th><th>Konto</th><th>Coin</th><th>Richtung</th><th class="n">Betrag</th><th class="n">Kurs</th><th class="n">seither</th></tr>`
  +z.map(t=>`<tr><td class="mono">${hm(t.ts)}<span class="d"> ${profisAlter(t.ts)}</span></td><td>#${t.rang} ${hsLink(t.addr, esc(t.name||t.addr.slice(0,6)+'…'+t.addr.slice(-4)))}</td><td><b>${esc(t.coin)}</b>${t.market==='spot'?' <span class="d">Spot</span>':''}</td><td style="color:${t.side==='B'?'#3ba55d':'#e04b4b'}">${esc(t.dir||(t.side==='B'?'Kauf':'Verkauf')).replace('*','')}</td><td class="n">${fmt(t.notional)}</td><td class="n">${t.px?px(t.px):'—'}</td><td class="n" style="color:${t.seither_pct>0?'#3ba55d':t.seither_pct<0?'#e04b4b':'#c9d1d9'}">${t.seither_pct!=null?(t.seither_pct>=0?'+':'')+t.seither_pct.toFixed(2)+' %':'—'}</td></tr>`).join('')+'</table>';
}
setInterval(()=>{ const el=$('profistab'); if(document.visibilityState==='visible'&&el&&el.offsetParent) loadProfis(); }, 60000);
// 23.23 Speicherorte: Datenbankpfad (Anzeige) und Backup-Pfad (Auswahl auf dem Pi, Prüfung, Übernehmen, Jetzt sichern)
let SP={wahl:null};
const spGB=v=>v==null?'—':(v/1e9).toFixed(1)+' GB';
async function speicherLaden(){
 if(SP.wahl!==null) return;
 let d; try{ d=await getJSON('/speicher'); }catch(e){ return; }
 const el=$('speicher'); if(!el) return;
 const B=d.backup, L=B.letztes||{}, DB=d.db;
 const med=m=>`${esc(m.mount)} · ${esc(m.fs)} · frei ${spGB(m.frei)} von ${spGB(m.gesamt)}${m.dauerhaft?'':' · <span style="color:#d29922">nicht in /etc/fstab</span>'}`;
 el.innerHTML=`<div class="sub" style="margin-bottom:4px"><b>Speicherorte</b></div>
  <div style="border:1px solid #21262d;border-radius:8px;padding:8px;margin:4px 0"><b>Datenbank</b> <span class="mono">${esc(DB.pfad)}</span><div class="sub">${med(DB)} · hl_liq.db ${spGB(DB.groesse_db)} · forecasts.db ${spGB(DB.groesse_prognosen)}</div><div class="sub">Umzug der Datenbank über die Oberfläche folgt in einem eigenen Paket; bis dahin im Terminal: <span class="mono">python3 migrate_db.py</span></div></div>
  <div style="border:1px solid ${B.systemkarte?'#d29922':'#21262d'};border-radius:8px;padding:8px;margin:4px 0"><b>Backup</b> <span class="mono">${esc(B.pfad)}</span> <span class="sub">(${esc(B.quelle)})</span>${B.systemkarte?' <span style="color:#d29922">— liegt auf der SD-Karte</span>':''}
   <div class="sub">${med(B)} · letztes Backup ${L.ts?hm(L.ts)+(L.ok?' ok':' FEHLER')+(L.size?' · '+spGB(L.size):''):'—'}${d.backup.jetzt_ts&&(!L.ts||L.ts<d.backup.jetzt_ts)?' · <span style="color:#d29922">Backup angestoßen …</span>':''}</div>
   <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px"><button class="tog off" onclick="speicherWaehlen('')">Backup-Pfad ändern</button><button class="tog off" onclick="speicherJetzt()">Jetzt sichern</button>${d.alt.loeschbar?`<button class="tog off" onclick="speicherAltLoeschen()">Alte Backups löschen (${spGB(d.alt.bytes)} in ${esc(d.alt.pfad)})</button>`:''}</div>
   <div id="spmsg" class="sub"></div></div><div id="spwahl"></div>`;
}
async function speicherWaehlen(pfad){
 SP.wahl=pfad; let d; try{ d=await getJSON('/speicher/ordner?pfad='+encodeURIComponent(pfad)); }catch(e){ return; }
 const el=$('spwahl'); if(!el) return;
 if(d.fehler){ el.innerHTML=`<div class="sub" style="color:#e04b4b">${esc(d.fehler)}</div>`; return; }
 const zeile=o=>`<div><a href="#" onclick="speicherWaehlen('${esc(o.pfad||o.name).replace(/'/g,"\\'")}');return false">📁 ${esc(o.name)}</a>${o.fs?` <span class="sub">${esc(o.fs)} · frei ${spGB(o.frei)}${o.systemkarte?' · SD-Karte':''}${o.dauerhaft?'':' · nicht in fstab'}</span>`:''}</div>`;
 el.innerHTML=`<div style="border:1px solid #30363d;border-radius:8px;padding:8px;margin:4px 0"><b>Ordner wählen</b> <span class="mono">${esc(d.pfad||'Medien')}</span>
  <div style="margin:6px 0">${d.pfad?`<a href="#" onclick="speicherWaehlen('${esc(d.eltern||'').replace(/'/g,"\\'")}');return false">⬆ zurück</a>`:''}</div>
  ${(d.ordner||[]).map(zeile).join('')||'<div class="sub">keine Unterordner</div>'}
  <div style="display:flex;gap:6px;margin-top:8px">${d.pfad?`<button class="tog on" onclick="speicherSetzen('${esc(d.pfad).replace(/'/g,"\\'")}')">Diesen Ordner übernehmen</button>`:''}<button class="tog off" onclick="SP.wahl=null;$('spwahl').innerHTML='';speicherLaden()">Abbrechen</button></div><div id="sppruef" class="sub"></div></div>`;
}
async function speicherSetzen(pfad){
 let r; try{ r=await getJSON('/speicher/backup_setzen?pfad='+encodeURIComponent(pfad)); }catch(e){ return; }
 const el=$('sppruef'); if(el) el.innerHTML=(r.pruefungen||[]).map(p=>`<div style="color:${p[1]?'#3ba55d':'#e04b4b'}">${p[1]?'✓':'✗'} ${esc(p[0])}: ${esc(String(p[2]))}</div>`).join('')+`<div><b>${esc(r.msg||'')}</b></div>`;
 if(r.ok){ setTimeout(()=>{ SP.wahl=null; speicherLaden(); }, 2500); }
}
async function speicherJetzt(){ try{ const r=await getJSON('/speicher/jetzt'); const el=$('spmsg'); if(el) el.textContent=r.msg; }catch(e){} setTimeout(speicherLaden, 3000); }
async function speicherAltLoeschen(){ if(!confirm('Alte Backups am bisherigen Ort löschen? Das neue Backup ist geprüft.')) return; try{ const r=await getJSON('/speicher/alt_loeschen?ok=1'); const el=$('spmsg'); if(el) el.textContent=r.msg; }catch(e){} setTimeout(speicherLaden, 1500); }
speicherLaden(); setInterval(speicherLaden, 60000);
// 23.25 Treiberfamilien (Parallelbetrieb): Kennzahlenkarte, Familien-Prognose, Chart der Familienwerte, Hygiene
const FAM_FARBEN={'Pool-Konten':'#a5d6ff','Kaskaden':'#ff9e64','Großkonten-Fluss':'#58a6ff','Trend lang':'#d2a8ff','Momentum kurz':'#ffa657','Orderfluss':'#3fb950','Funding':'#f778ba','ETF':'#79c0ff','Analog':'#8b949e','Profi-Flow':'#ffd33d','Stärke':'#ff7b72'};
let FAM={coin:null,ts:0,aus:{},d:null};
async function familienLaden(zwang){ const c=$('coin'); if(!c||!$('famtab')) return; const coin=c.value;
 if(!zwang&&coin===FAM.coin&&Date.now()-FAM.ts<600000) return; FAM.coin=coin; FAM.ts=Date.now();
 try{ FAM.d=await getJSON('/familien?coin='+encodeURIComponent(coin)); }catch(e){ return; } familienZeichnen(); }
function famUmschalten(f){ FAM.aus[f]=!FAM.aus[f]; familienChart(); }
function familienZeichnen(){ const d=FAM.d, el=$('famtab'); if(!el||!d) return;
 if(!d.bereit){ el.innerHTML=`<div class="sub">${esc(d.hinweis||'noch keine Daten')}</div>`; return; }
 const q=x=>x==null?'—':(x*100).toFixed(0)+' %', pp=x=>x==null?'—':(x>=0?'+':'')+(x*100).toFixed(1)+' pp', zz=x=>x==null?'—':(x>=0?'+':'')+x.toFixed(1);
 const sf={aufgestiegen:'#3ba55d','Bewährung':'#d29922',Kandidat:'#8b949e'};
 let h=`<div style="margin:4px 0 8px"><b>Familien-Prognose ${esc(d.coin)}</b> <span class="sub">(nur aufgestiegene Familien verschieben die Basisrate)</span>: `
  +Object.entries(d.prognose||{}).map(([hh,v])=>`${hh} h <b>${q(v.p)}</b> aufwärts <span class="sub">(Basis ${q(v.basis)}${(v.beitraege||[]).length?' · '+v.beitraege.map(b=>esc(b.familie)+' '+pp(b.beitrag)).join(', '):''})</span>`).join(' · ')+`</div><div id="famchart"></div>`;
 h+=`<table class="w"><tr><th>Familie</th><th class="n">jetzt</th><th class="n">Horizont</th><th>Stufe</th><th class="n" title="Trefferquote minus Zufall; je Block der Horizontlänge ein Fall">Vorsprung</th><th class="n" title="seit 23.46 exakt: Normalwert der Wahrscheinlichkeit, so viele Treffer rein zufällig zu bekommen (ab 2 belegt; höchstens etwa 7). Erst ab 3 Fällen">z</th><th class="n">n</th><th class="n" title="nur das letzte Drittel des Zeitraums">ungesehen</th><th class="n" title="Wochen mit positivem Vorsprung">Wochen +</th><th class="n" title="nur Fälle mit Betrag ab 0,5">Ereignisse</th><th>Überschneidung</th><th class="n" title="Wochen in Folge ohne positiven Vorsprung">ohne Nutzen</th></tr>`
  +(d.familien||[]).map(x=>{ const e=(x.dauer||{})[x.h]||{}, ev=x.ereignis||{}, o=e.oos||{}, w=e.wochen||{};
   return `<tr><td><span style="color:${FAM_FARBEN[x.familie]||'#c9d1d9'}">■</span> <b>${esc(x.familie)}</b>${x.art==='staerke'?' <span class="d">(große Bewegung ja/nein)</span>':''}<div class="d" style="font-size:11px">${esc((x.treiber||[]).join(', '))}</div></td>`
    +`<td class="n">${x.jetzt==null?'—':(x.art==='staerke'?x.jetzt.toFixed(2):(x.jetzt>=0?'+':'')+x.jetzt.toFixed(2))}${x.ereignis_jetzt?' <span style="color:#d29922" title="Ereignis: Betrag ab 0,5">●</span>':''}</td><td class="n">${x.h} h</td>`
    +`<td style="color:${sf[x.stufe]||'#c9d1d9'}">${esc(x.stufe)}${x.wackelt?' (wackelt)':''}${x.gewicht?' · '+pp(x.gewicht):''}</td>`
    +`<td class="n">${pp(e.lift)}</td><td class="n">${zz(e.z)}</td><td class="n">${e.n||0}</td><td class="n">${pp(o.lift)}</td><td class="n">${w.gesamt?w.positiv+'/'+w.gesamt:'—'}</td>`
    +`<td class="n">${ev.n?pp(ev.lift)+' (n '+ev.n+')':'—'}</td><td>${x.ueberschneidung?esc(x.ueberschneidung.mit)+' r '+x.ueberschneidung.r.toFixed(2):'—'}</td><td class="n">${e.ohne_nutzen!=null?e.ohne_nutzen+' W':'—'}</td></tr>`; }).join('')+'</table>';
 // 23.55 (U133): „kein Urteil“ statt „tot“ -- zu wenige Fälle oder kein Ausschlag ist kein Befund gegen den Treiber; nicht „auffällig“
 const H=d.hygiene||[], auff=H.filter(x=>x.flag==='nachlaufend'||x.flag==='umgekehrt?'), ohne=H.filter(x=>x.flag==='kein Urteil'), ausg=H.filter(x=>x.flag==='ausgeschlossen');
 const zuletzt=t=>{ if(!t) return '—'; const s=Date.now()/1000-t; return s<1800?'jetzt':s<172800?'vor '+Math.max(1,Math.round(s/3600))+' h':hm(t); };
 const hfarbe={ok:'#3ba55d','kein Urteil':'#8b949e'};
 const hr=(r,ci)=>r==null?'—':r.toFixed(2)+(ci?`<div class="d" style="font-size:10px" title="95-%-Intervall (Fisher-z): bei wenigen Fällen liegt auch ein großes r oft noch im Zufall">${ci[0].toFixed(2)}…${ci[1].toFixed(2)}</div>`:'');
 h+=`<details style="margin-top:8px"><summary class="sub">Treiber-Hygiene: ${auff.length} von ${H.length} auffällig${auff.length?' ('+auff.slice(0,4).map(x=>esc(x.treiber)+': '+esc(x.flag)).join(', ')+(auff.length>4?' …':'')+')':''}${ohne.length?' · '+ohne.length+' ohne Urteil':''}${ausg.length?' · '+ausg.length+' ausgeschlossen':''}</summary>`
  +`<div class="sub" style="margin:4px 0">„nachlaufend“: beschreibt vor allem die vergangene Bewegung · „umgekehrt?“: zeigt in beiden Hälften deutlich in die Gegenrichtung · „kein Urteil“: zu wenige Fälle oder der Wert bewegt sich kaum — kein Befund gegen den Treiber. Ereignis-Treiber haben nur bei einem Ereignis einen Wert; gemessen wird an ihren aktiven Zeiten, je Fall ein ganzes Horizontfenster davor und danach.</div>`
  +`<table class="w"><tr><th>Treiber</th><th>Befund</th><th class="n" title="Zusammenhang mit der KOMMENDEN Rendite; darunter das 95-%-Intervall">Zukunft r</th><th class="n" title="Zusammenhang mit der VERGANGENEN Rendite; darunter das 95-%-Intervall">Vergangenheit r</th><th class="n">Horizont</th><th class="n" title="Fälle: Zeitpunkte mit Wert im Abstand von mindestens einem Horizont (ab 8 ein Urteil)">Fälle</th><th class="n" title="Anteil der 15-min-Punkte im Zeitraum, an denen der Treiber einen Wert hatte">aktiv</th><th class="n" title="letzter Zeitpunkt mit Wert">zuletzt</th></tr>`
  +H.map(x=>`<tr><td>${esc(x.treiber)}${x.ereignis?' <span class="d">· Ereignis</span>':''}</td><td style="color:${hfarbe[x.flag]||'#d29922'};white-space:normal;min-width:110px;max-width:420px">${esc(x.flag)}${x.grund?'<div class="d" style="font-size:10.5px;line-height:1.35">'+esc(x.grund)+'</div>':''}</td><td class="n">${hr(x.corr_vor,x.ci_vor)}</td><td class="n">${hr(x.corr_nach,x.ci_nach)}</td><td class="n">${x.h?x.h+' h':'—'}</td><td class="n">${x.n!=null?x.n:'—'}</td><td class="n">${x.anteil!=null?q(x.anteil):'—'}</td><td class="n">${zuletzt(x.letzter)}</td></tr>`).join('')+'</table></details>';
 h+=`<div class="sub" style="margin-top:6px">${esc(d.hinweis||'')} · ${d.tage} Tage Daten seit ${hm(d.seit)}</div>`;
 el.innerHTML=h; familienChart(); }
function familienChart(){ const d=FAM.d, el=$('famchart'); if(!el||!d||!d.verlauf||!(d.verlauf.t||[]).length) return;
 const V=d.verlauf, W=Math.max(320,(el.clientWidth||600)), H=250, L=6, R=52, T=8, B=18, h1=82;
 const t0=V.t[0], t1=V.t[V.t.length-1], X=t=>L+(t-t0)/Math.max(1,t1-t0)*(W-L-R);
 const pv=V.px.filter(v=>v!=null); if(!pv.length) return;
 const pmin=Math.min(...pv), pmax=Math.max(...pv), Yp=v=>T+(pmax-v)/Math.max(1e-9,pmax-pmin)*(h1-6);
 const y0=T+h1+12, h2=H-B-y0, Yf=v=>y0+(1-v)/2*h2;
 const pfad=(arr,Y)=>{ let p='',an=false; arr.forEach((v,i)=>{ if(v==null){an=false;return;} p+=(an?'L':'M')+X(V.t[i]).toFixed(1)+','+Y(v).toFixed(1); an=true; }); return p; };
 let s=`<svg width="${W}" height="${H}" style="display:block"><path d="${pfad(V.px,Yp)}" fill="none" stroke="#c9d1d9" stroke-width="1.3"/>`
  +`<text x="${W-R+4}" y="${T+8}" fill="#8b949e" font-size="10">${px(pmax)}</text><text x="${W-R+4}" y="${T+h1-4}" fill="#8b949e" font-size="10">${px(pmin)}</text>`;
 [[0,'#30363d',''],[0.5,'#21262d','3,3'],[-0.5,'#21262d','3,3']].forEach(([v,c,da])=>{ s+=`<line x1="${L}" x2="${W-R}" y1="${Yf(v)}" y2="${Yf(v)}" stroke="${c}"${da?` stroke-dasharray="${da}"`:''}/><text x="${W-R+4}" y="${Yf(v)+3}" fill="#8b949e" font-size="10">${v>0?'+':v<0?'−':''}${Math.abs(v).toString().replace('.',',')}</text>`; });
 Object.entries(V.familien||{}).forEach(([f,arr])=>{ if(FAM.aus[f]) return; s+=`<path d="${pfad(arr,Yf)}" fill="none" stroke="${FAM_FARBEN[f]||'#8b949e'}" stroke-width="${f==='Stärke'?1.1:1.5}"${f==='Stärke'?' stroke-dasharray="4,3"':''}/>`; });
 [0,0.5,1].forEach(r=>{ const t=t0+(t1-t0)*r; s+=`<text x="${Math.min(W-R-60,Math.max(L,X(t)-30))}" y="${H-4}" fill="#8b949e" font-size="10">${hm(t)}</text>`; });
 s+='</svg>';
 const chips=Object.keys(V.familien||{}).map(f=>`<button class="tog ${FAM.aus[f]?'off':'on'}" style="border-color:${FAM_FARBEN[f]||'#8b949e'}" data-f="${esc(f)}" onclick="famUmschalten(this.dataset.f)">${esc(f)}</button>`).join(' ');
 el.innerHTML=`<div class="sub" style="margin:4px 0">Kurs oben · Familienwerte unten (−1 bis +1; Stärke gestrichelt, 0 bis 1) · letzte 72 h · Familien per Knopf ein/aus</div>`+s+`<div style="display:flex;flex-wrap:wrap;gap:4px;margin:4px 0 8px">${chips}</div>`; }
familienLaden(true); setInterval(()=>familienLaden(false), 30000);
// 23.28 Heatmap-Anker: Ungleichgewicht der Liquidationscluster über/unter dem Kurs (Abstand in σ, Größe relativ zum
// Stundenvolumen), Stand der Bilanz, Warnung bei starkem Cluster gegen den Bias -- ohne Einfluss auf die Prognose
let ANK={coin:null,ts:0};
async function ankerLaden(zwang){ const c=$('coin'), el=$('ankerbox'); if(!c||!el) return; const coin=c.value;
 if(!zwang&&ANK.coin===coin&&Date.now()-ANK.ts<300000) return; ANK.coin=coin; ANK.ts=Date.now();
 let d; try{ d=await getJSON('/anker?coin='+encodeURIComponent(coin)); }catch(e){ return; }
 const q=x=>x==null?'—':(x*100).toFixed(0)+' %';
 const cl=(k,z)=>z?`${fmt(z.usd)} ${k==='oben'?'Short':'Long'}-Liquidationen ${z.abstand_sigma.toFixed(1)} σ ${k==='oben'?'über':'unter'} dem Kurs (${z.abstand_pct>=0?'+':''}${z.abstand_pct.toFixed(1)} %), ${q(z.anteil_volumen)} des Stundenvolumens`:null;
 const B=d.bilanz||{}, bel=B.belegt?`<span style="color:#3ba55d">belegt in ${(B.belegt_in||[]).join(', ')} h</span>`:(B.ts?`nicht belegt (Bilanz ${hm(B.ts)}, ${B.tage} Tage)`:'Bilanz folgt (täglich)');
 const A=d.A, richt=A==null?'kein Anker (keine Cluster ab 5 % des Stundenvolumens zwischen 0,25 und 3 σ)':(A>=0.5?'Zug nach oben':A<=-0.5?'Zug nach unten':'ausgeglichen')+` (A ${A>=0?'+':''}${A.toFixed(2)})`;
 const teile=[cl('oben',d.oben), cl('unten',d.unten)].filter(Boolean);
 el.innerHTML=`<div style="border:1px solid ${d.gegen_bias?'#d29922':'#21262d'};border-radius:8px;padding:6px 8px"><b>Heatmap-Anker</b>: ${richt} · Beleg: ${bel}`
  +(teile.length?`<div>${teile.join(' · ')}</div>`:'')+(d.gegen_bias?`<div style="color:#d29922">⚠ ${esc(d.gegen_bias)}</div>`:'')
  +`<div style="font-size:11px">Auswertung ohne Einfluss auf die Prognose; ein Treiber wird daraus erst nach Beleg (trendbereinigt z ≥ 2 in zwei Horizonten).</div></div>`; }
ankerLaden(true); setInterval(()=>ankerLaden(false), 30000);
// 23.33 TradeLabor: simulierter Handel mit allen verarbeiteten Daten -- Signaltafel, Positionen, Strategien, Chart, Datenfluss,
// Ereignisse, Trades. Takt 15 s auf dem Pi; die Seite fragt nur, solange der Abschnitt offen und der Tab sichtbar ist.
let LAB={d:null, tab:'live', L:1, coin:'BTC', lcoin:(innerWidth<700?'BTC':''), sid:'', h:24, ev:'trades', tsid:'', tcoin:'', n:0, auf:{}};
try{ const s_=JSON.parse(localStorage.getItem('hl_labor')||'{}'); if(s_.tab) LAB.tab=s_.tab; if(s_.L) LAB.L=+s_.L; if(s_.coin) LAB.coin=s_.coin; if(s_.h) LAB.h=+s_.h; if(s_.lcoin!=null) LAB.lcoin=s_.lcoin; }catch(e){}
function labMerken(){ try{ localStorage.setItem('hl_labor', JSON.stringify({tab:LAB.tab, L:LAB.L, coin:LAB.coin, h:LAB.h, lcoin:LAB.lcoin})); }catch(e){} }
const LAB_TABS=[['live','Live'],['pos','Positionen'],['strat','Strategien'],['chart','Chart'],['daten','Datenfluss'],['ev','Ereignisse'],['trades','Trades']];
const LAB_GRUPPEN=['Händler','Prognose','Familien','Ereignisse','Grid','Kontrolle'];
function labIstGrid(k){ return !!k&&/^grid_/.test(k.name||k.sid||''); }   // 23.40 Grid-Bots
function labOffen(){ const p=$('sec-labor'); return !!p&&!p.classList.contains('closed')&&document.visibilityState!=='hidden'; }
function labUsd(x,dig){ if(x==null||isNaN(x)) return '—'; const a=Math.abs(x), n=dig==null?(a<1000?2:0):dig;
 return (x>0?'+':x<0?'−':'')+a.toLocaleString('de-DE',{minimumFractionDigits:n, maximumFractionDigits:n}); }
function labPc(x,dig){ if(x==null||isNaN(x)) return '—'; return (x>0?'+':x<0?'−':'')+Math.abs(x).toFixed(dig==null?2:dig).replace('.',',')+' %'; }
function labFarbe(x){ return x==null||x===0||isNaN(x)?'#c9d1d9':x>0?'#3fb950':'#f85149'; }
function labAlter(s){ if(s==null) return '—'; return s<90?Math.round(s)+' s':s<5400?Math.round(s/60)+' min':s<172800?(s/3600).toFixed(1).replace('.',',')+' h':Math.round(s/86400)+' T'; }
function labPx(x){ return x==null?'—':px(x); }
function labId(p,sid){ return p+String(sid).replace(/[^a-z0-9_]/gi,'_'); }
// Ergebnis eines Trades bei Hebel L (gleiche Marge): Rendite × L; liquidiert, wenn der Rückgang im Trade × L 90 % der Marge erreicht
function labHebel(pct, mae){ const L=LAB.L, g=(LAB.d&&LAB.d.liq_schwelle)||0.9; if(pct==null) return {pct:null, liq:false};
 if(mae!=null&&mae/100*L>=g) return {pct:-100, liq:true}; return {pct:pct*L, liq:false}; }
function labSumme(k){ const hv=(k.hebel||[]).find(x=>x.L===LAB.L); return hv&&hv.summe_usd!=null?hv.summe_usd:k.summe_usd*LAB.L; }
function labAuf(id){ LAB.auf[id]=!LAB.auf[id]; const e=$(id); if(e) e.style.display=LAB.auf[id]?'':'none'; }
function labSetzen(el, html){ const alt=[...el.querySelectorAll('.labscroll')].map(x=>x.scrollLeft); el.innerHTML=html;
 [...el.querySelectorAll('.labscroll')].forEach((x,i)=>{ if(alt[i]) x.scrollLeft=alt[i]; }); }
function labTabs(){ const el=$('labtabs'); if(!el) return;
 el.innerHTML=LAB_TABS.map(([k,n])=>`<button class="tog ${LAB.tab===k?'on':'off'}" onclick="labTab('${k}')">${n}</button>`).join('')
  +`<span style="margin-left:auto;display:flex;gap:6px;align-items:center"><label class="lbl" for="labhebel">Hebel</label><select id="labhebel" onchange="LAB.L=+this.value;labMerken();labZeigen()">`
  +(((LAB.d&&LAB.d.hebel)||[1,3,5,10]).map(L=>`<option value="${L}"${L===LAB.L?' selected':''}>${L}×</option>`).join(''))+`</select></span>`; }
function labTab(k){ LAB.tab=k; labMerken(); labTabs(); labZeigen(); }
async function laborLaden(zwang){
 if(!zwang&&!labOffen()) return;
 let d; try{ d=await getJSON('/labor'); }catch(e){ return; }
 const erst=!LAB.d; LAB.d=d; LAB.n++; labKopf(); if(erst) labTabs();
 // Tabs mit Auswahllisten nur jede Minute neu zeichnen (offene Liste bliebe sonst nicht offen)
 if(zwang||['live','pos','strat','ev','daten'].includes(LAB.tab)||LAB.n%4===0) labZeigen();
}
function labKopf(){ const d=LAB.d, el=$('labkpi'); if(!el||!d) return;
 if(d.fehler){ el.innerHTML=`<div><span>TradeLabor</span><b style="color:#d29922">${esc(d.fehler)}</b></div>`; return; }
 const g=d.gesamt||{}, T=d.takt||{}, lv=d.live||{}, st=g.stufen||{}, tage=d.start?((d.ts-d.start)/86400):0;
 let takt;
 if(T.aus) takt='<span style="color:#d29922">aus (HL_LABOR=0)</span>';
 else if(T.selbsttest) takt='ruht (Selbsttest-Datenbank)';
 else if(!T.laeuft) takt=T.gestartet?'startet …':'nicht gestartet';
 else takt=`${lv.letzter?hm(lv.letzter).slice(7):'—'}${lv.dauer_s!=null?' · '+Math.round(lv.dauer_s*1000)+' ms':''}`;
 const fr=Object.entries(lv.frische||{}).map(([c,f])=>`${esc(c)} ${f.frisch}/${f.frisch+f.alt+f.fehlt}`).join(' · ');
 const fehler=(lv.fehler||[]).concat(T.fehler?[T.fehler]:[]);
 el.innerHTML=[
  ['Laufzeit', d.start?`${tage.toFixed(1).replace('.',',')} Tage<span class="d">seit ${hm(d.start)}</span>`:'—<span class="d">noch kein Takt</span>'],
  ['Strategien', `${g.strategien||0} × ${(d.coins||[]).length} Coins<span class="d">${(d.notional||0).toLocaleString('de-DE')} USD je Trade</span>`],
  ['Offen', `${g.offen||0} <span style="color:${labFarbe(g.offen_usd)}">${labUsd(g.offen_usd)}</span><span class="d">${g.orders||0} Limit-Orders warten${(g.grid_lose||g.grid_orders)?` · Grid ${g.grid_lose||0} Lose (${labUsd(g.grid_bestand_usd)}), ${g.grid_orders||0} Orders; Summe inkl. Grid`:''}</span>`],
  ['24 Stunden', `${g.trades_24h||0} Trades <span style="color:${labFarbe(g.netto_24h)}">${labUsd(g.netto_24h)}</span><span class="d">netto nach allen Kosten</span>`],
  ['Gesamt', `<span style="color:${labFarbe(g.netto_usd)}">${labUsd(g.netto_usd)} USD</span><span class="d">${g.trades||0} Trades · Gebühren ${labUsd(-(g.gebuehren_usd||0))}</span>`],
  ['Stufen', `${st['bewährt']||0} bewährt<span class="d">${st['Bewährung']||0} auf Bewährung · ${st.negativ||0} negativ</span>`],
  ['Takt', `${takt}<span class="d" title="frische Eingänge je Coin">${fr||'Eingänge folgen'}</span>`],
 ].map(([k,v])=>`<div><span>${k}</span><b>${v}</b></div>`).join('')
  +(fehler.length?`<div style="flex-basis:100%;grid-column:1/-1"><span>Meldungen</span><b style="font-size:11px;color:#d29922;font-weight:500">${fehler.slice(-3).map(esc).join('<br>')}</b></div>`:''); }
async function labZeigen(){ const el=$('labbody'); if(!el||!LAB.d) return;
 try{
  if(LAB.tab==='live') labSetzen(el, labLive());
  else if(LAB.tab==='pos') labSetzen(el, labPositionen());
  else if(LAB.tab==='strat') labSetzen(el, labStrategien());
  else if(LAB.tab==='ev') labSetzen(el, labEreignisse());
  else if(LAB.tab==='daten') await labDaten(el);
  else if(LAB.tab==='chart') await labChart(el);
  else if(LAB.tab==='trades') await labTrades(el);
 }catch(e){ el.innerHTML=`<div class="sub" style="color:#d29922">Anzeigefehler: ${esc(e.message)}</div>`; } }
function labZelle(k,c,st,pos,ords){ let top='', bg='';
 if(pos){ const hv=labHebel(pos.netto_pct, pos.mae_pct); bg=pos.seite==='long'?'rgba(63,185,80,.12)':'rgba(248,81,73,.12)';
  top=`<b style="color:${pos.seite==='long'?'#3fb950':'#f85149'}">${pos.seite==='long'?'▲ Long':'▼ Short'}</b> <b style="color:${labFarbe(hv.pct)}">${hv.liq?'liquidiert':labPc(hv.pct)}</b><span class="lz">seit ${hm(pos.eroeffnet).slice(7)} zu ${labPx(pos.preis_ein)}</span>`; }
 else if(ords&&ords.length){ top=`<b style="color:#e3b341">◆ ${ords.map(o=>(o.seite==='long'?'Kauf ':'Verkauf ')+labPx(o.preis)).join(' · ')}</b>`; }
 else if(st&&st.signal&&st.blockiert){ top=`<span style="color:#8b949e">Signal ${st.signal.seite==='long'?'Long':'Short'} · ${esc(st.blockiert)}</span>`; }
 return `<td style="${bg?'background:'+bg:''}" title="${esc(st&&st.signal?st.signal.grund:(pos?pos.grund:''))}">${top}<span class="lz">${st?esc(st.text):'—'}</span></td>`; }
// 23.40: Grid-Zelle -- Modus, Lose von Stufen, Bestandswert (unrealisiert, nach Ausstiegsgebühr); Text: Range, Schritt, Notlinie bzw. Stop
function labGridZelle(st){ const g=(st&&st.grid)||null; let top='', bg='';
 if(g){ const lang=g.richtung==='long', fb=lang?'#3fb950':'#f85149', wert=g.bestand_usd==null?null:g.bestand_usd*LAB.L;
  if(g.modus==='aktiv'){ bg=lang?'rgba(63,185,80,.08)':'rgba(248,81,73,.08)';
   top=`<b style="color:${fb}">▦ ${g.lose}/${g.n||'—'} Lose</b>`+(g.lose?` <b style="color:${labFarbe(wert)}">${labUsd(wert)}</b>`:''); }
  else if(g.modus==='halten'){ bg='rgba(227,179,65,.14)';
   top=`<b style="color:#e3b341">${lang?'⇡':'⇣'} hält ${g.lose} Lose</b> <b style="color:${labFarbe(wert)}">${labUsd(wert)}</b>`; }
  else if(g.modus==='pause') top=`<span style="color:#d29922">⏸ Pause bis ${hm(g.pause_bis).slice(7)}</span>`;
  else top='<span style="color:#8b949e">wartet</span>'; }
 return `<td style="${bg?'background:'+bg:''}" title="${esc(st?st.text:'')}">${top}<span class="lz">${st?esc(st.text):'—'}</span></td>`; }
function labLive(){ const d=LAB.d, lv=d.live, alle=d.coins||[], coins=LAB.lcoin&&alle.includes(LAB.lcoin)?[LAB.lcoin]:alle;
 if(!lv) return `<div class="sub" style="margin:2px 0 8px">Das Labor rechnet gerade nicht (${esc((d.takt||{}).aus?'mit HL_LABOR=0 abgeschaltet':(d.takt||{}).gestartet?'startet 30 s nach dem Dashboard':'nicht gestartet')}) — gezeigt wird der gespeicherte Stand.</div>`+labPositionen();
 const S=lv.status||{}, offen={}, ords={};
 (d.offen||[]).forEach(p=>{ offen[p.sid+'|'+p.coin]=p; });
 (d.orders||[]).forEach(o=>{ const k=o.sid+'|'+o.coin; (ords[k]=ords[k]||[]).push(o); });
 const akt=(d.strategien||[]).filter(k=>k.aktiv), sp=coins.length+3;
 let h=`<div style="display:flex;gap:6px;flex-wrap:wrap;margin:2px 0 6px"><button class="tog ${!LAB.lcoin?'on':'off'}" onclick="LAB.lcoin='';labMerken();labZeigen()">alle Coins</button>`
  +alle.map(c=>`<button class="tog ${LAB.lcoin===c?'on':'off'}" onclick="LAB.lcoin='${esc(c)}';labMerken();labZeigen()">${esc(c)}</button>`).join('')+`</div>`;
 h+=`<div class="sub" style="margin:2px 0 6px">Was jede Strategie im letzten Takt (${lv.letzter?hm(lv.letzter):'—'}) je Coin sieht: <b>offene Position</b> mit Stand${LAB.L>1?' bei '+LAB.L+'× Hebel':''} · <b style="color:#e3b341">◆ wartende Limit-Order</b> · sonst ihr Eingangswert gegen die Schwelle. Zeile antippen: Regeln.</div>`;
 h+=`<div class="labscroll"><table class="w"><tr><th>Strategie</th>${coins.map(c=>{ const f=(lv.frische||{})[c]||{}; return `<th>${esc(c)}${f.preis?` <span style="text-transform:none;color:#c9d1d9">${labPx(f.preis)}</span>`:''}</th>`; }).join('')}<th class="n">Summe${LAB.L>1?' '+LAB.L+'×':''}</th><th class="n">Trades</th></tr>`;
 LAB_GRUPPEN.concat([...new Set(akt.map(k=>k.gruppe))].filter(g=>!LAB_GRUPPEN.includes(g))).forEach(g=>{ const ks=akt.filter(k=>k.gruppe===g); if(!ks.length) return;
  h+=`<tr class="grp"><td colspan="${sp}" style="color:#e3b341;font-weight:600;background:#1c2128">${esc(g)}</td></tr>`;
  ks.forEach(k=>{ const id=labId('labr_',k.sid);
   h+=`<tr onclick="labAuf('${id}')" style="cursor:pointer"><td style="white-space:normal;min-width:120px;max-width:170px"><b>${esc(k.titel)}</b><span class="lz">${esc(k.stufe)}${k.n?' · Ø '+labPc(k.mittel_pct,2):''}</span></td>`
    +coins.map(c=>labIstGrid(k)?labGridZelle((S[k.sid]||{})[c]):labZelle(k, c, (S[k.sid]||{})[c], offen[k.sid+'|'+c], ords[k.sid+'|'+c])).join('')
    +`<td class="n" style="color:${labFarbe(labSumme(k))}">${labUsd(labSumme(k),0)}</td><td class="n">${k.n}</td></tr>`
    +`<tr id="${id}" style="${LAB.auf[id]?'':'display:none'}"><td colspan="${sp}" style="white-space:normal"><span class="lz" style="max-width:none">${esc(k.beschreibung)}</span></td></tr>`; }); });
 return h+'</table></div>'; }
// 23.40: Grid-Lose und -Orders je Grid und Coin gebündelt (bis zu 12 Lose und Orders je Konto), Zustand aus dem letzten Takt
function labGridTabelle(){ const d=LAB.d, G=d.grids||{}, L=LAB.L, lose={}, ords={}, titel={};
 const keys=Object.keys(G).sort(); if(!keys.length) return '';
 (d.strategien||[]).forEach(k=>{ titel[k.sid]=k.titel; });
 (d.offen||[]).filter(p=>p.grid).forEach(p=>{ const k=p.sid+'|'+p.coin, e=lose[k]=lose[k]||{n:0,usd:0,wert:0,pxu:0};
  e.n++; e.usd+=p.notional||0; e.wert+=p.netto_usd||0; e.pxu+=(p.preis_ein||0)*(p.notional||0); });
 (d.orders||[]).filter(o=>o.grid).forEach(o=>{ const k=o.sid+'|'+o.coin, e=ords[k]=ords[k]||{n:0,lo:Infinity,hi:-Infinity,seite:o.seite};
  e.n++; e.lo=Math.min(e.lo,o.preis); e.hi=Math.max(e.hi,o.preis); });
 let h=`<div class="sub" style="margin:12px 0 6px"><b>Grid-Bots</b> — je Grid und Coin ein Konto über ${(d.notional||0).toLocaleString('de-DE')} USD, auf die Stufen verteilt. Bestand = unrealisiert zur Buchmitte nach Ausstiegsgebühr (Taker) und Funding${L>1?`, hochgerechnet auf ${L}× Hebel`:''}. Einzelne Lose: Reiter „Trades“ bzw. „Ereignisse → alles“.</div>`;
 h+=`<div class="labscroll"><table class="w"><tr><th>Grid</th><th>Coin</th><th>Modus</th><th class="n">Lose</th><th class="n">Einsatz USD</th><th class="n">Ø Einstieg</th><th class="n">Bestand USD</th><th>Range</th><th class="n">Schritt</th><th class="n">Notlinie / Stop</th><th>Orders</th></tr>`;
 keys.forEach(key=>{ const g=G[key], [sid,coin]=key.split('|'), e=lose[key]||{n:0,usd:0,wert:0,pxu:0}, o=ords[key], H=g.halten||{};
  const modus=g.modus==='aktiv'?`<span style="color:#3fb950">aktiv</span> seit ${hm(g.seit)}`:g.modus==='halten'?`<b style="color:#e3b341">hält</b> seit ${hm(H.start)}<span class="lz">${esc(H.grund||'')}</span>`
   :g.modus==='pause'?`<span style="color:#d29922">Pause</span> bis ${hm(g.pause_bis)}`:`<span style="color:#8b949e">wartet</span><span class="lz">${esc(g.hinweis||'prüft die Range')}</span>`;
  const aktiv=g.modus==='aktiv'||g.modus==='halten';
  h+=`<tr><td>${esc(titel[sid]||sid)}</td><td>${esc(coin)}</td><td style="white-space:normal;min-width:120px">${modus}</td><td class="n">${e.n}${aktiv&&g.n?'/'+g.n:''}</td>`
   +`<td class="n">${e.usd?labUsd(e.usd,0).replace('+',''):'—'}</td><td class="n">${e.usd?labPx(e.pxu/e.usd):'—'}</td><td class="n" style="color:${labFarbe(e.wert)}">${e.n?labUsd(e.wert*L):'—'}</td>`
   +`<td>${aktiv&&g.unten?labPx(g.unten)+' – '+labPx(g.oben):'—'}</td><td class="n">${aktiv&&g.schritt?labPc(g.schritt*100,2).replace('+',''):'—'}</td>`
   +`<td class="n">${g.modus==='halten'?'<span style="color:#e3b341">Stop '+labPx(H.stop)+'</span>':aktiv?labPx(g.notlinie):'—'}</td>`
   +`<td>${o?`${o.n} ${o.seite==='long'?'Kauf':'Verkauf'} ${labPx(o.lo)}${o.n>1?' – '+labPx(o.hi):''}`:'—'}</td></tr>`; });
 return h+'</table></div>'; }
function labPositionen(){ const d=LAB.d, O=(d.offen||[]).filter(p=>!p.grid), Od=(d.orders||[]).filter(o=>!o.grid);
 let h=`<div class="sub" style="margin:2px 0 6px"><b>${O.length} offene Positionen</b> — Stand zur Buchmitte nach Ausstiegsgebühr (Taker) und Funding${LAB.L>1?`, hochgerechnet auf ${LAB.L}× Hebel (Marge ${(d.notional||0).toLocaleString('de-DE')} USD)`:''}</div>`;
 if(O.length) h+=`<div class="labscroll"><table class="w"><tr><th>Strategie</th><th>Coin</th><th>Seite</th><th>seit</th><th class="n">Einstieg</th><th class="n">jetzt</th><th class="n">Stop</th><th class="n">Ziel</th><th>spätestens</th><th class="n">netto USD</th><th class="n">netto</th><th class="n" title="größter Rückgang / größter Vorsprung seit dem Einstieg">MAE / MFE</th><th>Grund</th></tr>`
  +O.map(p=>{ const hv=labHebel(p.netto_pct,p.mae_pct), usd=hv.pct==null?null:hv.pct/100*p.notional;
   return `<tr><td>${esc(p.titel)}</td><td>${esc(p.coin)}</td><td style="color:${p.seite==='long'?'#3fb950':'#f85149'}">${p.seite==='long'?'▲ Long':'▼ Short'}</td><td>${hm(p.eroeffnet)}</td><td class="n">${labPx(p.preis_ein)}</td><td class="n">${labPx(p.jetzt)}</td><td class="n">${labPx(p.sl)}</td><td class="n">${labPx(p.tp)}</td><td>${p.ablauf?hm(p.ablauf):'—'}</td>`
    +`<td class="n" style="color:${labFarbe(usd)}">${hv.liq?'liquidiert':labUsd(usd)}</td><td class="n" style="color:${labFarbe(hv.pct)}">${labPc(hv.pct)}</td><td class="n">${labPc(-(p.mae_pct||0))} / ${labPc(p.mfe_pct||0)}</td><td style="white-space:normal;min-width:220px"><span class="lz" style="max-width:420px">${esc(p.grund)}</span></td></tr>`; }).join('')+'</table></div>';
 h+=`<div class="sub" style="margin:12px 0 6px"><b>${Od.length} wartende Limit-Orders</b> — gefüllt nur, wenn der Kurs durch den Preis läuft (Maker, 0,015 %)</div>`;
 if(Od.length) h+=`<div class="labscroll"><table class="w"><tr><th>Strategie</th><th>Coin</th><th>Seite</th><th class="n">Limit</th><th class="n">jetzt</th><th class="n">Abstand</th><th>gesetzt</th><th>gültig bis</th><th>Grund</th></tr>`
  +Od.map(o=>`<tr><td>${esc(o.titel)}</td><td>${esc(o.coin)}</td><td style="color:${o.seite==='long'?'#3fb950':'#f85149'}">${o.seite==='long'?'Kauf':'Verkauf'}</td><td class="n">${labPx(o.preis)}</td><td class="n">${labPx(o.jetzt)}</td><td class="n">${o.jetzt?labPc((o.preis/o.jetzt-1)*100):'—'}</td><td>${hm(o.erstellt)}</td><td>${hm(o.gueltig_bis)}</td><td style="white-space:normal;min-width:220px"><span class="lz" style="max-width:420px">${esc(o.grund)}</span></td></tr>`).join('')+'</table></div>';
 return h+labGridTabelle(); }
function labStrategien(){ const d=LAB.d, K=d.strategien||[], L=LAB.L, sp=L>1?12:11;
 const sf={'bewährt':'#3fb950','Bewährung':'#d29922','Kandidat':'#8b949e','negativ':'#f85149'};
 let h=`<div class="sub" style="margin:2px 0 6px">Je Strategie alle Coins zusammen, nach allen Kosten. <b>Ø/Tag</b> = Ergebnis je Tag Laufzeit auf die Konten der Strategie (je Coin ${(d.notional||0).toLocaleString('de-DE')} USD)${L>1?`, bei ${L}× Hebel; <b>liquidiert</b> = Trades, deren Rückgang 90 % der Marge erreicht hätte`:''}. <b>Glück</b> = Wahrscheinlichkeit, dass die beste von ${K.filter(k=>k.aktiv).length} zufälligen Strategien so gut aussähe — erst unter 5 % ernst nehmen. <b>Trades (Blöcke)</b>: t, Glück und Stufe zählen Blöcke — gleichzeitig eröffnete Trades einer Strategie (dasselbe Signal in mehreren Coins) sind eine Beobachtung. Grid-Bots: Summe nach Bestandswert (realisiert + unrealisiert), Blöcke = Tage mit dem Tagesergebnis inkl. Bestandsänderung. Zeile antippen: Einzelheiten je Coin und Hebel.</div>`;
 h+=`<div class="labscroll"><table class="w"><tr><th>Strategie</th><th class="n">Summe USD</th><th class="n">Ø/Tag</th><th class="n" title="Trades (Blöcke): gleichzeitig eröffnete Trades der Strategie zählen für t, Glück und Stufe einmal">Trades (Bl.)</th><th class="n">Glück</th><th class="n">Treffer</th><th class="n">Ø netto</th><th class="n">t</th><th class="n">max DD</th><th class="n" title="Gewinne durch Verluste">PF</th>${L>1?'<th class="n">liquidiert</th>':''}<th>jetzt</th></tr>`;
 K.forEach(k=>{ const hv=(k.hebel||[]).find(x=>x.L===L)||{}, id=labId('labs_',k.sid);
  h+=`<tr onclick="labAuf('${id}')" style="cursor:pointer${k.aktiv?'':';opacity:.55'}"><td style="white-space:normal;min-width:120px;max-width:170px"><b>${esc(k.titel)}</b><span class="lz"><span style="color:${sf[k.stufe]||'#8b949e'}">${esc(k.stufe)}</span> · ${esc(k.gruppe)}${k.aktiv?'':' · alte Regelversion'}</span></td>`
   +`<td class="n" style="color:${labFarbe(hv.summe_usd)}">${labUsd(hv.summe_usd==null?k.summe_usd*L:hv.summe_usd,0)}</td><td class="n" style="color:${labFarbe(hv.tag_pct)}">${labPc(hv.tag_pct,3)}</td><td class="n">${k.n}${k.n?` <span style="color:#8b949e">(${k.n_eff!=null?k.n_eff:'—'})</span>`:''}</td><td class="n" style="color:${k.p_glueck!=null&&k.p_glueck<0.05?'#3fb950':'#c9d1d9'}">${k.p_glueck==null?'—':Math.round(k.p_glueck*100)+' %'}</td>`
   +`<td class="n">${k.treffer==null?'—':Math.round(k.treffer*100)+' %'}</td><td class="n" style="color:${labFarbe(k.mittel_pct)}">${labPc(k.mittel_pct==null?null:k.mittel_pct*L,3)}</td><td class="n">${k.t==null?'—':(k.t>=0?'+':'−')+Math.abs(k.t).toFixed(1).replace('.',',')}</td>`
   +`<td class="n">${labUsd(-(k.max_dd_usd||0)*L,0)}</td><td class="n">${k.pf==null?'—':k.pf.toFixed(2).replace('.',',')}</td>`
   +(L>1?`<td class="n" style="color:${hv.liquidiert?'#f85149':'#8b949e'}">${hv.liquidiert?hv.liquidiert+'×':'—'}</td>`:'')
   +`<td>${labIstGrid(k)&&k.grid?`▦ ${k.grid.lose} Lose · ${k.grid.orders} Orders${k.bestand_usd?' · Bestand <span style="color:'+labFarbe(k.bestand_usd)+'">'+labUsd(k.bestand_usd*L,0)+'</span>':''}`:(k.offen||[]).map(esc).join(', ')+((k.orders||[]).length?' <span style="color:#e3b341">◆ '+k.orders.map(esc).join(', ')+'</span>':'')}</td></tr>`
   +`<tr id="${id}" style="${LAB.auf[id]?'':'display:none'}"><td colspan="${sp}" style="white-space:normal">${labDetail(k)}</td></tr>`; });
 return h+'</table></div>'; }
function labDetail(k){ const L=LAB.L, jc=k.je_coin||{};
 const gt=labIstGrid(k)&&k.grid?`<span class="lz" style="max-width:none;margin:2px 0 6px"><b>Nach Bestandswert:</b> Summe ${labUsd(k.summe_usd*L)} = realisiert ${labUsd((k.realisiert_usd||0)*L)} + Bestand ${labUsd((k.bestand_usd||0)*L)} USD · `
  +`Tagesergebnis (realisiert + Änderung des Bestands, neueste zuletzt): ${(k.grid.tage||[]).slice(-14).map(([t,v])=>hm(t).slice(0,6)+' <span style="color:'+labFarbe(v)+'">'+labUsd(v*L,0)+'</span>').join(' · ')||'noch keine Tage'}</span>`:'';
 let h=gt+`<span class="lz" style="max-width:none;margin:2px 0 6px">${esc(k.beschreibung)} · Kennung ${esc(k.sid)} · seit ${hm(k.erstellt)}${k.slip_bps!=null?' · Ø Abstand zur Buchmitte Ein+Aus '+k.slip_bps.toFixed(1).replace('.',',')+' bps':''} · Gebühren ${labUsd(-(k.gebuehren_usd||0))} · Funding ${labUsd(-(k.funding_usd||0))}${k.block_h?' · Block '+(k.block_h>=24?(k.block_h/24).toFixed(0)+' T':k.block_h+' h'):''}${k.haelften?' · erste/zweite Hälfte (Blöcke) '+labPc(k.haelften[0],3)+' / '+labPc(k.haelften[1],3):''}${k.kelly!=null?' · Kelly '+k.kelly.toFixed(1).replace('.',',')+'×':''}</span>`;
 h+=`<table class="w" style="min-width:0;margin-top:4px"><tr><th>Coin</th><th class="n">Trades (Bl.)</th><th class="n">Treffer</th><th class="n">Ø netto</th><th class="n">t</th><th class="n">Summe USD</th><th class="n">Ø/Tag</th></tr>`
  +(Object.keys(jc).length?Object.entries(jc).map(([c,v])=>`<tr><td>${esc(c)}</td><td class="n">${v.n}${v.n_eff!=null&&v.n_eff!==v.n?' <span style="color:#8b949e">('+v.n_eff+')</span>':''}</td><td class="n">${v.treffer==null?'—':Math.round(v.treffer*100)+' %'}</td><td class="n" style="color:${labFarbe(v.mittel_pct)}">${labPc(v.mittel_pct==null?null:v.mittel_pct*L,3)}</td><td class="n">${v.t==null?'—':v.t.toFixed(1).replace('.',',')}</td><td class="n" style="color:${labFarbe(((v.hebel||{})[L]||{}).summe_usd)}">${labUsd(((v.hebel||{})[L]||{}).summe_usd,0)}</td><td class="n">${labPc(((v.hebel||{})[L]||{}).tag_pct,3)}${((v.hebel||{})[L]||{}).liquidiert?' <span style="color:#f85149">('+v.hebel[L].liquidiert+'× liquidiert)</span>':''}</td></tr>`).join(''):`<tr><td colspan="7" class="lz">noch keine geschlossenen Trades</td></tr>`)+'</table>';
 h+=`<table class="w" style="min-width:0;margin-top:6px"><tr><th>Hebel</th><th class="n">Summe USD</th><th class="n">Ø/Tag</th><th class="n" title="alle Trades nacheinander mit dem ganzen Konto">Kontofaktor</th><th class="n">größter Rückgang</th><th class="n">liquidiert</th><th class="n">schlechtester Trade</th></tr>`
  +(k.hebel||[]).map(x=>`<tr${x.L===L?' style="background:#1c2128"':''}><td>${x.L}×</td><td class="n" style="color:${labFarbe(x.summe_usd)}">${labUsd(x.summe_usd,0)}</td><td class="n" style="color:${labFarbe(x.tag_pct)}">${labPc(x.tag_pct,3)}</td><td class="n">${x.ausgeloescht?'<span style="color:#f85149">ausgelöscht bei Trade '+x.ausgeloescht+'</span>':'×'+x.faktor.toFixed(3).replace('.',',')}</td><td class="n">${labPc(-(x.max_dd||0)*100,1)}</td><td class="n">${x.liquidiert||0}</td><td class="n">${labPc(x.schlechtester_pct,2)}</td></tr>`).join('')+'</table>';
 return h; }
function labEreignisse(){ const d=LAB.d, roh=LAB.ev==='alles'?(d.ereignisse||[]).concat(d.ereignisse_grid||[]).sort((a,b)=>(b.ts-a.ts)||(b.id-a.id)):(d.ereignisse||[]);
 const E=roh.filter(e=>LAB.ev==='alles'||['eroeffnet','geschlossen','kaskade','verfallen','grid'].includes(e.art));
 const ic={eroeffnet:'▶',geschlossen:'■',kaskade:'⚡',limit:'◆',storno:'✕',verfallen:'⌛',grid:'▦',grid_los:'·'};
 let h=`<div style="display:flex;gap:6px;flex-wrap:wrap;margin:2px 0 8px"><button class="tog ${LAB.ev==='trades'?'on':'off'}" onclick="LAB.ev='trades';labZeigen()">Ein-/Ausstiege, Kaskaden, Grid</button><button class="tog ${LAB.ev==='alles'?'on':'off'}" onclick="LAB.ev='alles';labZeigen()">alles (auch Limits und einzelne Grid-Lose)</button></div>`;
 if(!E.length) return h+'<div class="sub">Noch keine Ereignisse.</div>';
 h+=`<div class="labscroll"><table class="w"><tr><th>Zeit</th><th>Strategie</th><th>Coin</th><th></th><th>Ereignis</th><th class="n">netto (1×)</th></tr>`
  +E.slice(0,150).map(e=>`<tr><td>${hm(e.ts)}</td><td>${esc(e.titel)}</td><td>${esc(e.coin||'')}</td><td style="color:${e.art==='kaskade'||e.art==='grid'?'#d29922':e.seite==='long'?'#3fb950':e.seite==='short'?'#f85149':'#8b949e'}">${ic[e.art]||'·'}</td><td style="white-space:normal;min-width:260px;font-size:11px">${esc(e.text)}</td><td class="n" style="color:${labFarbe(e.netto_usd)}">${e.netto_usd==null?'':labUsd(e.netto_usd)}</td></tr>`).join('')+'</table></div>';
 return h; }
function labCoinChips(){ return `<div style="display:flex;gap:6px;flex-wrap:wrap;margin:2px 0 8px">`+(((LAB.d&&LAB.d.coins)||[]).map(c=>`<button class="tog ${LAB.coin===c?'on':'off'}" onclick="LAB.coin='${esc(c)}';labMerken();labZeigen()">${esc(c)}</button>`).join(''))+`</div>`; }
async function labDaten(el){ const coins=LAB.d.coins||[]; if(coins.length&&!coins.includes(LAB.coin)) LAB.coin=coins[0];
 let r; try{ r=await getJSON('/labor/daten?coin='+encodeURIComponent(LAB.coin)); }catch(e){ return; }
 const farbe={frisch:'#3fb950',alt:'#d29922',fehlt:'#f85149'}, Z=r.zeilen||[];
 let h=labCoinChips()+`<div class="sub" style="margin:2px 0 6px">Alle Eingänge, die das Labor im letzten Takt für ${esc(r.coin)} gelesen hat (${r.ts?hm(r.ts):'noch kein Takt'}), mit Alter und den Strategien, die sie nutzen: <span style="color:#3fb950">●</span> frisch <span style="color:#d29922">●</span> alt <span style="color:#f85149">●</span> fehlt</div>`;
 if(!Z.length){ el.innerHTML=h+'<div class="sub">Noch keine Eingänge — das Labor startet 30 s nach dem Dashboard.</div>'; return; }
 let g0=''; h+=`<div class="labscroll"><table class="w"><tr><th>Eingang</th><th>Wert</th><th class="n">Alter</th><th>genutzt von</th></tr>`;
 Z.forEach(z=>{ if(z.gruppe!==g0){ g0=z.gruppe; h+=`<tr class="grp"><td colspan="4" style="color:#e3b341;font-weight:600;background:#1c2128">${esc(g0)}</td></tr>`; }
  h+=`<tr><td><span style="color:${farbe[z.status]||'#8b949e'}">●</span> ${esc(z.name)}${z.hinweis?`<span class="lz">${esc(z.hinweis)}</span>`:''}</td><td style="white-space:normal;min-width:160px;max-width:360px">${esc(z.wert)}</td><td class="n">${labAlter(z.alter)}</td><td style="white-space:normal;min-width:140px"><span class="lz">${esc((z.nutzer||[]).join(', '))}</span></td></tr>`; });
 labSetzen(el, h+'</table></div>'); }
async function labChart(el){ const coins=LAB.d.coins||[]; if(coins.length&&!coins.includes(LAB.coin)) LAB.coin=coins[0];
 let r, q; try{ [r,q]=await Promise.all([getJSON(`/labor/chart?coin=${encodeURIComponent(LAB.coin)}&sid=${encodeURIComponent(LAB.sid)}&h=${LAB.h}`), getJSON('/labor/equity')]); }catch(e){ return; }
 const K=(LAB.d.strategien||[]).filter(k=>k.aktiv);
 el.innerHTML=labCoinChips()+`<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0 0 6px"><select onchange="LAB.sid=this.value;labZeigen()"><option value="">alle Strategien</option>${K.map(k=>`<option value="${esc(k.sid)}"${k.sid===LAB.sid?' selected':''}>${esc(k.titel)}</option>`).join('')}</select>`
  +`<select onchange="LAB.h=+this.value;labMerken();labZeigen()">${[[24,'24 Stunden'],[72,'3 Tage'],[168,'7 Tage']].map(([v,n])=>`<option value="${v}"${v===LAB.h?' selected':''}>${n}</option>`).join('')}</select></div>`
  +`<div id="labkurs"></div><div class="sub" style="margin:12px 0 4px"><b>Bilanzverlauf</b> — kumuliertes Netto je Strategie (1×, alle Coins); Zufall gestrichelt, Halten grau</div><div id="labeq"></div><div id="labmarken"></div>`;
 labKursChart(r); labEquityChart(q); }
function labKursChart(r){ const el=$('labkurs'); if(!el) return; const K=r.kurs||[];
 if(r.fehler||K.length<2){ el.innerHTML=`<div class="sub">${esc(r.fehler||'Noch keine Kursdaten für diesen Zeitraum.')}</div>`; $('labmarken').innerHTML=''; return; }
 const W=Math.max(300,(el.clientWidth||600)), H=280, Lp=6, R=64, T=10, B=20, t0=r.von, t1=r.bis;
 const X=t=>Lp+(Math.max(t0,Math.min(t1,t))-t0)/Math.max(1,t1-t0)*(W-Lp-R);
 const M=r.marken||[], Lm=r.limits||[];
 let lo=Infinity, hi=-Infinity; const nimm=v=>{ if(v!=null&&isFinite(v)){ lo=Math.min(lo,v); hi=Math.max(hi,v); } };
 K.forEach(k=>nimm(k[1])); M.forEach(m=>{ if(m.ein_t>=t0) nimm(m.ein_px); if(m.aus_t&&m.aus_t>=t0) nimm(m.aus_px); });
 const sp0=(hi-lo)||hi*0.01, dazu=v=>{ if(v!=null&&v>lo-sp0*0.6&&v<hi+sp0*0.6) nimm(v); };
 r.sid_gewaehlt=!!LAB.sid; if(r.sid_gewaehlt) M.filter(m=>m.status==='offen').forEach(m=>{ dazu(m.sl); dazu(m.tp); }); Lm.forEach(o=>dazu(o.preis));
 const G=r.grid&&(r.grid.modus==='aktiv'||r.grid.modus==='halten')?r.grid:null;          // 23.40: Range und Notlinie des gewählten Grids
 if(G){ dazu(G.unten); dazu(G.oben); dazu(G.notlinie); if(G.halten) dazu(G.halten.stop); }
 const pad=(hi-lo)*0.05||1; lo-=pad; hi+=pad; const Y=v=>T+(hi-v)/(hi-lo)*(H-T-B);
 let s=`<svg width="${W}" height="${H}" style="display:block;background:#01030a;border:1px solid #21262d;border-radius:6px">`;
 for(let i=0;i<=4;i++){ const v=lo+(hi-lo)*i/4; s+=`<line x1="${Lp}" x2="${W-R}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}" stroke="#161b22"/><text x="${W-R+4}" y="${(Y(v)+3).toFixed(1)}" fill="#8b949e" font-size="10">${labPx(v)}</text>`; }
 if(G&&G.unten&&G.oben){ const y1=Y(G.oben), y2=Y(G.unten);
  s+=`<rect x="${Lp}" width="${(W-R-Lp).toFixed(1)}" y="${Math.min(y1,y2).toFixed(1)}" height="${Math.abs(y2-y1).toFixed(1)}" fill="#58a6ff" opacity=".08"><title>Grid-Range ${labPx(G.unten)} – ${labPx(G.oben)}, ${G.n} Stufen</title></rect>`;
  if(G.notlinie) s+=`<line x1="${Lp}" x2="${W-R}" y1="${Y(G.notlinie).toFixed(1)}" y2="${Y(G.notlinie).toFixed(1)}" stroke="#f85149" stroke-dasharray="8,4" opacity=".8"><title>Notlinie ${labPx(G.notlinie)}</title></line>`;
  if(G.halten&&G.halten.stop) s+=`<line x1="${X(G.halten.start).toFixed(1)}" x2="${W-R}" y1="${Y(G.halten.stop).toFixed(1)}" y2="${Y(G.halten.stop).toFixed(1)}" stroke="#e3b341" stroke-width="1.5"><title>Trailing-Stop ${labPx(G.halten.stop)} (Extrem ${labPx(G.halten.extrem)})</title></line>`; }
 s+=`<path d="${K.map((k,i)=>(i?'L':'M')+X(k[0]).toFixed(1)+','+Y(k[1]).toFixed(1)).join('')}" fill="none" stroke="#c9d1d9" stroke-width="1.2"/>`;
 Lm.forEach(o=>{ const y=Y(o.preis).toFixed(1); s+=`<line x1="${X(o.erstellt).toFixed(1)}" x2="${W-R}" y1="${y}" y2="${y}" stroke="#e3b341" stroke-dasharray="4,3"><title>${esc(o.titel)}: Limit ${o.seite==='long'?'Kauf':'Verkauf'} ${labPx(o.preis)}</title></line>`; });
 M.forEach(m=>{ const col=m.seite==='long'?'#3fb950':'#f85149', x1=X(m.ein_t), y1=Y(m.ein_px);
  if(m.status==='offen'){ s+=`<line x1="${x1.toFixed(1)}" x2="${W-R}" y1="${y1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke="${col}" stroke-dasharray="1,3" opacity=".6"/>`;
   if(r.sid_gewaehlt&&m.sl&&m.sl>lo&&m.sl<hi) s+=`<line x1="${x1.toFixed(1)}" x2="${W-R}" y1="${Y(m.sl).toFixed(1)}" y2="${Y(m.sl).toFixed(1)}" stroke="#f85149" stroke-dasharray="6,4" opacity=".7"><title>${esc(m.titel)}: Stop ${labPx(m.sl)}</title></line>`;
   if(r.sid_gewaehlt&&m.tp&&m.tp>lo&&m.tp<hi) s+=`<line x1="${x1.toFixed(1)}" x2="${W-R}" y1="${Y(m.tp).toFixed(1)}" y2="${Y(m.tp).toFixed(1)}" stroke="#3fb950" stroke-dasharray="6,4" opacity=".7"><title>${esc(m.titel)}: Ziel ${labPx(m.tp)}</title></line>`; }
  else if(m.aus_t){ const x2=X(m.aus_t), y2=Y(m.aus_px), c2=labFarbe(m.netto_usd);
   s+=`<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${c2}" stroke-dasharray="3,2" opacity=".55"/><circle cx="${x2.toFixed(1)}" cy="${y2.toFixed(1)}" r="3.5" fill="${c2}"><title>${esc(m.titel)}: Ausstieg ${labPx(m.aus_px)} (${hm(m.aus_t)}), netto ${labUsd(m.netto_usd)} USD</title></circle>`; }
  if(m.ein_t>=t0){ const d_=m.seite==='long'?`M${(x1-5).toFixed(1)},${(y1+7).toFixed(1)}L${(x1+5).toFixed(1)},${(y1+7).toFixed(1)}L${x1.toFixed(1)},${(y1-2).toFixed(1)}Z`:`M${(x1-5).toFixed(1)},${(y1-7).toFixed(1)}L${(x1+5).toFixed(1)},${(y1-7).toFixed(1)}L${x1.toFixed(1)},${(y1+2).toFixed(1)}Z`;
   s+=`<path d="${d_}" fill="${col}"><title>${esc(m.titel)}: ${m.seite==='long'?'Long':'Short'} zu ${labPx(m.ein_px)} (${hm(m.ein_t)})</title></path>`; } });
 [0,0.5,1].forEach(f=>{ const t=t0+(t1-t0)*f; s+=`<text x="${Math.min(W-R-64,Math.max(Lp,X(t)-30)).toFixed(1)}" y="${H-5}" fill="#8b949e" font-size="10">${hm(t)}</text>`; });
 el.innerHTML=`<div class="sub" style="margin:0 0 4px">${esc(r.coin)} · 5-min-Kurs · ▲ Long- / ▼ Short-Einstieg · ● Ausstieg (grün Gewinn, rot Verlust) · ${LAB.sid?'gestrichelt Stop/Ziel offener Positionen · ':''}gelb wartende Limits${G?' · blau die Grid-Range, rot gestrichelt die Notlinie'+(G.halten?', gelb der Trailing-Stop':''):''}${LAB.sid?'':' · Stop und Ziel erscheinen, wenn oben eine Strategie gewählt ist; Grid-Lose nur mit gewähltem Grid'}</div>`+s+'</svg>';
 const Lz=M.slice().reverse().slice(0,40);
 $('labmarken').innerHTML=Lz.length?`<div class="labscroll" style="margin-top:8px"><table class="w"><tr><th>Strategie</th><th>Seite</th><th>Einstieg</th><th class="n">zu</th><th>Ausstieg</th><th class="n">zu</th><th class="n">netto (1×)</th></tr>`
  +Lz.map(m=>`<tr><td>${esc(m.titel)}</td><td style="color:${m.seite==='long'?'#3fb950':'#f85149'}">${m.seite==='long'?'▲ Long':'▼ Short'}</td><td>${hm(m.ein_t)}</td><td class="n">${labPx(m.ein_px)}</td><td>${m.aus_t?hm(m.aus_t):'offen'}</td><td class="n">${labPx(m.aus_px)}</td><td class="n" style="color:${labFarbe(m.netto_usd)}">${m.netto_usd==null?'—':labUsd(m.netto_usd)}</td></tr>`).join('')+'</table></div>':'<div class="sub" style="margin-top:6px">Keine Trades in diesem Fenster.</div>'; }
function labEquityChart(q){ const el=$('labeq'); if(!el) return; const R=(q&&q.reihen)||[];
 if(!R.length){ el.innerHTML='<div class="sub">Noch keine geschlossenen Trades.</div>'; return; }
 const W=Math.max(300,(el.clientWidth||600)), H=220, Lp=6, Rr=64, T=10, B=20, t1=q.ts;
 let t0=Infinity, lo=0, hi=0; R.forEach(r=>r.punkte.forEach(([t,v])=>{ t0=Math.min(t0,t); lo=Math.min(lo,v); hi=Math.max(hi,v); }));
 if(LAB.d&&LAB.d.start) t0=Math.min(t0,LAB.d.start); if(hi===lo){ hi+=1; lo-=1; } const pad=(hi-lo)*0.05; hi+=pad; lo-=pad;
 const X=t=>Lp+(t-t0)/Math.max(1,t1-t0)*(W-Lp-Rr), Y=v=>T+(hi-v)/(hi-lo)*(H-T-B);
 const farben=['#58a6ff','#d29922','#a371f7','#3fb950','#f778ba','#79c0ff','#ffa657','#56d4dd'], kontrolle=r=>/^(zufall|halten_long)@/.test(r.sid);
 const top=R.filter(r=>!kontrolle(r)).sort((a,b)=>Math.abs(b.summe)-Math.abs(a.summe)).slice(0,8), alle=top.concat(R.filter(kontrolle));
 let s=`<svg width="${W}" height="${H}" style="display:block;background:#01030a;border:1px solid #21262d;border-radius:6px"><line x1="${Lp}" x2="${W-Rr}" y1="${Y(0).toFixed(1)}" y2="${Y(0).toFixed(1)}" stroke="#30363d"/>`;
 [lo,0,hi].forEach(v=>{ s+=`<text x="${W-Rr+4}" y="${(Y(v)+3).toFixed(1)}" fill="#8b949e" font-size="10">${labUsd(v,0)}</text>`; });
 alle.forEach((r,i)=>{ const c=kontrolle(r)?'#8b949e':farben[i%farben.length]; let d_=`M${X(t0).toFixed(1)},${Y(0).toFixed(1)}`, yv=0;
  r.punkte.forEach(([t,v])=>{ d_+=`L${X(t).toFixed(1)},${Y(yv).toFixed(1)}L${X(t).toFixed(1)},${Y(v).toFixed(1)}`; yv=v; }); d_+=`L${X(t1).toFixed(1)},${Y(yv).toFixed(1)}`;
  s+=`<path d="${d_}" fill="none" stroke="${c}" stroke-width="1.4"${/^zufall@/.test(r.sid)?' stroke-dasharray="4,3"':''}><title>${esc(r.titel)}: ${labUsd(r.summe)} USD</title></path>`; r._c=c; });
 [0,0.5,1].forEach(f=>{ const t=t0+(t1-t0)*f; s+=`<text x="${Math.min(W-Rr-64,Math.max(Lp,X(t)-30)).toFixed(1)}" y="${H-5}" fill="#8b949e" font-size="10">${hm(t)}</text>`; });
 el.innerHTML=s+'</svg>'+`<div style="display:flex;flex-wrap:wrap;gap:4px 12px;margin:4px 0 0;font-size:11px">${alle.map(r=>`<span><span style="color:${r._c}">■</span> ${esc(r.titel)}${r.grid?' (inkl. Bestand, je Tag)':''} <span style="color:${labFarbe(r.summe)}">${labUsd(r.summe,0)}</span></span>`).join('')}</div>`; }
async function labTrades(el){ const K=LAB.d.strategien||[], coins=LAB.d.coins||[], L=LAB.L;
 let r; try{ r=await getJSON(`/labor/trades?sid=${encodeURIComponent(LAB.tsid)}&coin=${encodeURIComponent(LAB.tcoin)}&n=200`); }catch(e){ return; }
 const T=r.trades||[];
 let h=`<div style="display:flex;gap:8px;flex-wrap:wrap;margin:2px 0 8px"><select onchange="LAB.tsid=this.value;labZeigen()"><option value="">alle Strategien</option>${K.map(k=>`<option value="${esc(k.sid)}"${k.sid===LAB.tsid?' selected':''}>${esc(k.titel)}${k.aktiv?'':' (alte Regeln)'}</option>`).join('')}</select>`
  +`<select onchange="LAB.tcoin=this.value;labZeigen()"><option value="">alle Coins</option>${coins.map(c=>`<option value="${esc(c)}"${c===LAB.tcoin?' selected':''}>${esc(c)}</option>`).join('')}</select></div>`;
 h+=`<div class="sub" style="margin:0 0 6px">${T.length} geschlossene Trades, neueste zuerst${L>1?` · Ergebnis bei ${L}× Hebel (liquidiert, wenn der Rückgang im Trade 90 % der Marge erreicht)`:''} · Kosten = Gebühren Ein- und Ausstieg · Abstand = zur Buchmitte bei Markt-Orders</div>`;
 if(!T.length){ el.innerHTML=h+'<div class="sub">Noch keine geschlossenen Trades.</div>'; return; }
 h+=`<div class="labscroll"><table class="w"><tr><th>Ausstieg</th><th>Strategie</th><th>Coin</th><th>Seite</th><th class="n">Einstieg</th><th class="n">Ausstieg</th><th>Art</th><th class="n">Dauer</th><th class="n">Kosten</th><th class="n">Abstand</th><th class="n">Funding</th><th class="n">netto USD</th><th class="n">netto</th><th class="n">MAE / MFE</th><th>Grund</th></tr>`
  +T.map(t=>{ const hv=labHebel(t.netto_pct,t.mae_pct), usd=hv.pct==null?null:hv.pct/100*(t.notional||LAB.d.notional||10000);
   return `<tr><td>${hm(t.geschlossen)}</td><td>${esc(t.titel||t.sid)}</td><td>${esc(t.coin)}</td><td style="color:${t.seite==='long'?'#3fb950':'#f85149'}">${t.seite==='long'?'▲ Long':'▼ Short'}</td><td class="n">${labPx(t.preis_ein)}</td><td class="n">${labPx(t.preis_aus)}</td><td><span class="lz">${esc(t.art_ein)} → ${esc(t.art_aus)}</span></td><td class="n">${labAlter(t.geschlossen-t.eroeffnet)}</td>`
    +`<td class="n">${labUsd(-(t.gebuehren||0)*L)}</td><td class="n">${t.slip_ein!=null?((t.slip_ein||0)+(t.slip_aus||0)).toFixed(1).replace('.',',')+' bps':'—'}</td><td class="n">${labUsd(-(t.funding||0)*L)}</td><td class="n" style="color:${labFarbe(usd)}">${hv.liq?'liquidiert':labUsd(usd)}</td><td class="n" style="color:${labFarbe(hv.pct)}">${labPc(hv.pct)}</td><td class="n">${labPc(-(t.mae_pct||0))} / ${labPc(t.mfe_pct||0)}</td><td style="white-space:normal;min-width:260px"><span class="lz" style="max-width:460px">${esc(t.grund)} → ${esc(t.grund_aus)}</span></td></tr>`; }).join('')+'</table></div>';
 labSetzen(el, h); }
if($('sec-labor')){ labTabs(); laborLaden(true); setInterval(()=>laborLaden(false), 15000); }
async function loadProfis(){
 try{ const d=await getJSON('/profis'); const el=$('profistab'); if(!el) return;
  const mio=v=>v==null?'—':(v/1e6).toFixed(1)+' M', pc=(v,dig=1)=>v==null?'—':`<span style="color:${v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9'}">${(v*100).toFixed(dig)} %</span>`;
  if(!d.bereit){ el.innerHTML=`<div class="sub">Bewertung noch nicht bereit${d.fehler?' — '+esc(d.fehler):''}. ${esc(d.hinweis||'')}</div>`; return; }
  const R=d.regeln||{}, pz=v=>v==null?'—':(v*100).toFixed(0)+' %';
  const kopf=`<div class="sub" style="margin-bottom:6px" title="${esc(profisRegeltext(R))} ${esc(d.rang_basis||'')}">Pool ${d.n_pool} (gesperrt ${d.n_gesperrt}) · aktiv mit Gewinn 7 T und 30 T ${d.n_aktiv}${d.quellen?` <span title="bewertbare Ein-/Ausstiege der Aktiven in 14 Tagen je Quelle (dieselbe Entscheidung aus mehreren Quellen binnen 15 min einmal): ${esc(Object.entries(d.quellen).map(([k,v])=>k+' '+v).join(', '))}">(${Object.values(d.quellen).reduce((a,b)=>a+b,0)} Ein-/Ausstiege, ${d.n_mit_ereignissen!=null?d.n_mit_ereignissen:'—'} Konten)</span>`:''} · <b title="erfüllen jetzt die Aufnahme-Regel">aufnahmefähig ${d.n_qualifiziert}</b> · Darwin-Liste ${d.n_liste!=null?d.n_liste:d.top.length} Konten${d.n_verbleib!=null?`, davon ${d.n_verbleib} mit erfülltem Verbleib`:''}, Tagesentscheidung ${d.stempel?hm(d.stempel):'—'} · Bewertung ${d.ts?hm(d.ts):'—'} (stündlich) · Coins ${(d.coins||[]).join(', ')}<div class="d" style="margin-top:2px">Regeln v${R.version||3}: rein nur bei Glück ≤ ${pz(R.aufnahme_p)}, ≥ ${R.aufnahme_n||6} Ein-/Ausstiegen in ${R.timing_tage||14} T, Vorsprung ≥ ${((R.aufnahme_vorsprung||0.1)*100).toFixed(0)} Punkte, Gewinn 7 T und 30 T positiv · wer so hineinkam, bleibt, solange Timing über Zufall (Glück ≤ ${pz(R.verbleib_p)}) und Gewinn 30 T positiv · raus nach ${R.abstieg_tage||3} Tagen in Folge ohne Verbleib</div></div>`;
  if(!d.top.length){ const gz=Object.entries(d.gruende||{}); el.innerHTML=kopf+`<div class="sub">Die Darwin-Liste ist leer${gz.length?' — Gründe gegen die Aufnahme (erster je Konto): '+gz.map(([k,v])=>esc(k)+' '+v).join(' · '):''}. Ein- und Ausstiege kommen aus den Wal-, Leaderboard- und Pool-Positionen.</div>`+profisProtokoll(d); return; }
  el.innerHTML=kopf+d.top.map((k,i)=>`<div style="border:1px solid #21262d;border-radius:8px;padding:8px 10px;margin:6px 0;background:#0d1117">
   <div style="display:flex;flex-wrap:wrap;gap:6px 14px;align-items:baseline">
    <b style="font-size:15px">#${i+1}</b> ${hsLink(k.addr, `<b>${esc(k.name||k.addr.slice(0,6)+'…'+k.addr.slice(-4))}</b>`)}${k.bot?' <span class="lbl-ev" style="background:#1f2a44;color:#9cc4ff" title="24-h-Handel: über 7 Tage nie länger als 4 h ohne Trade">[bot trader]</span>':''}${k.seit_tage!=null?` <span class="d" title="seit Aufnahme in die Darwin-Liste">seit ${Math.floor(k.seit_tage)} T</span>`:''}${k.bewaehrung?` <span class="lbl-ev" style="background:#3a2f12;color:#d29922" title="Bei ${k.bewaehrung} Tagesentscheidung(en) in Folge Verbleib verfehlt${k.grund_tag?': '+esc(k.grund_tag):''} -- Abstieg nach ${R.abstieg_tage||3}">Fehltag ${k.bewaehrung} von ${R.abstieg_tage||3}</span>`:''}${k.lcb!=null?` <span class="d" title="vorsichtige Untergrenze des Exit-Lifts (Lift minus Standardfehler) -- danach richtet sich die Reihenfolge">Beleg ≥ ${(k.lcb*100).toFixed(0)} pp</span>`:''}
    <span class="d">Kontowert ${mio(k.account_value)}</span>
    <span title="Rang-Kennzahl: ${esc(k.rang_quelle||'')}">${k.roi_12h!=null?'ROI 12 h '+pc(k.roi_12h):'ROI 1 T '+pc(k.roi_1d)}</span> <span class="d">${k.roi_12h!=null?'ROI 1 T '+pc(k.roi_1d)+' · ':''}ROI 7 T ${pc(k.roi_7d)} · PnL 7 T ${mio(k.pnl_7d)}</span>
    <span class="d">Trades/T ${k.trades_tag}</span>
    <span class="d" title="Ausstiege vor Korrekturen ≥ 2 % binnen 12 h, gegen Placebo; t auf 12-h-Blöcken">Exit-Lift ${k.exit_lift!=null?(k.exit_lift*100).toFixed(0)+' pp (t '+(k.exit_t||0).toFixed(1)+', n '+k.n_exits+')':'—'}</span>
    <span class="d" title="Einstiege vor Bewegungen ≥ 2 % in die eigene Richtung">Entry-Lift ${k.entry_lift!=null?(k.entry_lift*100).toFixed(0)+' pp (t '+(k.entry_t||0).toFixed(1)+')':'—'}</span>
    ${k.reaktion_min!=null?`<span class="d" title="Median: Minuten von einer Bewegung ≥ 1 % in 15 min bis zum nächsten Trade">Reaktion ${k.reaktion_min.toFixed(0)} min</span>`:''}
    ${k.bester_coin?`<span class="d">bester Coin ${esc(k.bester_coin)}</span>`:''}
   </div>
   ${k.verbleib?`<div class="sub" style="margin-top:4px;color:#3fb950" title="Stand der stündlichen Bewertung; entschieden wird einmal täglich">Verbleib erfüllt${k.aufnahme?' · würde auch neu aufgenommen':''}</div>`:`<div class="sub" style="margin-top:4px;color:#d29922" title="Stand der stündlichen Bewertung; entschieden wird einmal täglich, Abstieg erst nach ${R.abstieg_tage||3} Tagen in Folge">Verbleib jetzt verfehlt: ${esc((k.gruende_verbleib||[])[0]||'—')}</div>`}
   ${profisTiming(k)}
   ${k.trades&&k.trades.length?`<table class="w" style="margin-top:6px"><tr><th>Zeit</th><th>Coin</th><th>Richtung</th><th class="n">Betrag</th><th class="n">Kurs</th><th class="n" title="Kursentwicklung seit dem Trade aus Sicht des Traders">seither</th><th class="n">Real. PnL</th></tr>`
    +k.trades.map((t,ti)=>`<tr${ti>=10?' data-mehr="1" style="display:none"':''}><td class="mono">${hm(t.ts)}<span class="d"> ${profisAlter(t.ts)}</span></td><td><b>${esc(t.coin)}</b>${t.market==='spot'?' <span class="d">Spot</span>':''}</td><td style="color:${t.side==='B'?'#3ba55d':'#e04b4b'}">${esc(t.dir||(t.side==='B'?'Kauf':'Verkauf')).replace('*','')}</td><td class="n">${fmt(t.notional)}</td><td class="n">${t.px?px(t.px):'—'}</td><td class="n" style="color:${t.seither_pct>0?'#3ba55d':t.seither_pct<0?'#e04b4b':'#c9d1d9'}">${t.seither_pct!=null?(t.seither_pct>=0?'+':'')+t.seither_pct.toFixed(2)+' %':'—'}</td><td class="n">${t.closed_pnl?fmt(t.closed_pnl):'—'}</td></tr>`).join('')+'</table>'+(k.trades.length>10?`<a href="#" class="sub" onclick="this.previousElementSibling.querySelectorAll('tr[data-mehr]').forEach(r=>r.style.display='');this.remove();return false">alle ${k.trades.length} Trades zeigen</a>`:''):'<div class="sub">noch keine Trades gespeichert</div>'}
  </div>`).join('')+profisProtokoll(d)+profisZeitleiste(d);
 }catch(e){}
}
async function loadPool(){
 try{ const win=$('poolwin')?$('poolwin').value:'roi_7d', n=$('pooln')?$('pooln').value:'500'; const d=await getJSON('/pool?win='+win+'&n='+n); const el=$('pooltab'); if(!el) return;
  $('poolinfo').textContent=`· ${d.n_pool} Konten im Pool · Stand ${d.stand?hm(d.stand):'—'} · Phase 1: Vorschau ohne Aktivitätsprüfung · Trades/T aus ${d.trades_stunden||0} von 24 Stunden${(d.trades_stunden||0)<24?' (Aufbau läuft, „—" = noch kein Trade gesehen)':''}`;
  if(!d.rows||!d.rows.length){ el.innerHTML='<div class="sub">Noch keine Pool-Konten -- die erste stündliche Leaderboard-Datei nach dem Start füllt die Tabelle.</div>'; return; }
  const col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9', pct=v=>v==null?'—':`<span style="color:${col(v)}">${(v*100).toFixed(1)} %</span>`, mio=v=>v==null?'—':(v/1e6).toFixed(1)+' M';
  const th=(k,t,extra='')=>`<th class="n"${extra} style="${win===k?'color:#e6edf3;text-decoration:underline':''}">${t}</th>`;
  el.innerHTML=`<table class="w"><tr><th>#</th><th>Konto</th><th class="n">Kontowert</th>${th('roi_1d','ROI 1 T')}${th('roi_7d','ROI 7 T')}${th('pnl_7d','PnL 7 T')}${th('roi_30d','ROI 30 T')}<th class="n">Umsatz 1 T</th><th class="n" title="Wochenumsatz je Kontowert: < 0,5× Halter, > 50× Hochfrequenz">Umschlag</th><th class="n" title="gebündelte Trades je Tag aus dem Stundenaggregat (Phase 1), hochgerechnet auf 24 h; Aufnahme: 2 bis 150">Trades/T</th><th title="Warum das Konto (nicht) qualifiziert ist -- aus der stündlichen Bewertung">Status</th></tr>`
   +d.rows.map((r,i)=>`<tr><td>${i+1}</td><td><a href="https://hypurrscan.io/address/${esc(r.addr)}" target="_blank" rel="noopener" style="color:#58a6ff;text-decoration:none" title="Konto auf HypurrScan öffnen${r.behavior?' · '+esc(r.behavior):''}"><b>${esc(r.name||r.addr.slice(0,6)+'…'+r.addr.slice(-4))}</b></a>${r.gesperrt?' <span class="lbl-ev" title="Masterregel: mehr als 300 gebündelte Trades in 24 h (Fills ab 2.500 USD und Stream der verfolgten Coins) -- kein Signal">GESPERRT</span>':''}</td><td class="n">${mio(r.account_value)}</td><td class="n">${pct(r.roi_1d)}</td><td class="n">${pct(r.roi_7d)}</td><td class="n" style="color:${col(r.pnl_7d||0)}">${mio(r.pnl_7d)}</td><td class="n">${pct(r.roi_30d)}</td><td class="n">${mio(r.vlm_1d)}</td><td class="n">${r.umschlag!=null?r.umschlag.toFixed(1)+'×':'—'}</td><td class="n" style="color:${r.trades_tag==null?'#6e7681':(r.trades_tag<2||r.trades_tag>150)?'#d29922':'#c9d1d9'}">${r.trades_tag!=null?r.trades_tag:'—'}</td><td style="font-size:12px;color:${r.status==='aufnahmefähig'||String(r.status||'').endsWith('Verbleib erfüllt')?'#3ba55d':String(r.status||'').startsWith('auf der Darwin')?'#d29922':'#8b949e'}" title="${esc(r.status||'noch nicht bewertet')}">${r.status==null?'—':esc(String(r.status).split('; ')[0])}</td></tr>`).join('')+'</table>';
 }catch(e){}
}
if($('poolwin')){ $('poolwin').onchange=loadPool; } if($('pooln')){ $('pooln').onchange=loadPool; }
async function restoreInfo(){
 try{ const j=await getJSON('/restore/info'); const el=$('restinfo'); if(!el) return;
  if(!j.vorhanden){ el.textContent='Kein Backup vorhanden (updates/vor_* entsteht beim ersten Update).'; $('restbtn').disabled=true; return; }
  el.textContent=`Jüngstes Backup: ${j.ordner} vom ${new Date(j.zeit*1000).toLocaleString('de-DE')} · ${j.dateien} Projektdateien · Datenbanken werden nicht berührt`+(j.uebersprungen&&j.uebersprungen.length?` · übersprungen: ${j.uebersprungen.slice(0,6).join(', ')}`:'');
 }catch(e){}
}
async function runRestore(){
 let j0=null; try{ j0=await getJSON('/restore/info'); }catch(e){}
 const wer=j0&&j0.ordner?`${j0.ordner} vom ${new Date(j0.zeit*1000).toLocaleString('de-DE')} (${j0.dateien} Projektdateien)`:'das jüngste Backup';
 if(!confirm(`Projektdateien aus ${wer} zurückspielen?\\nDatenbanken bleiben unberührt. Der jetzige Stand wird vorher gesichert. Dienste starten neu.`)) return;
 const b=$('restbtn'); b.disabled=true; b.textContent='Wiederherstellung läuft …'; $('updbtn').disabled=true;
 try{ const r=await fetch('/restore',{method:'POST',headers:{'X-HL-Request':'1'}}); const j=await r.json();
  $('updlog').style.display='block'; $('updlog').textContent=j.msg;
  if(!j.ok){ b.disabled=false; b.textContent='Letztes Backup wiederherstellen'; $('updbtn').disabled=false; return; }
  pollUpdate(true);
 }catch(e){ b.disabled=false; b.textContent='Letztes Backup wiederherstellen'; $('updbtn').disabled=false; showErr('Wiederherstellung: '+e.message); }
}
if($('restbtn')){ $('restbtn').onclick=runRestore; restoreInfo(); }
async function loadHealth(){
 try{LAST_HEALTH=await getJSON('/health'); fillHealth(LAST_HEALTH);}catch(e){}
 // solange die Prüfung läuft, alle 30 s nachsehen statt erst in einer Stunde
 if(healthTimer){clearTimeout(healthTimer);healthTimer=null;}
 if(LAST_HEALTH&&(LAST_HEALTH.checking||LAST_HEALTH.db_ok==null)) healthTimer=setTimeout(loadHealth,30000);
}
function fillCbTile(){
 const el=$('kpi_cb'); if(!el) return;
 const C=LAST_CHART&&LAST_CHART.cb;
 if(!C||!C.aktiv){ el.textContent='—'; el.style.color='';
  el.nextElementSibling; el.innerHTML='—<span class="d">'+(C&&C.alter_min!=null?`Daten ${C.alter_min} min alt`:'Dienst läuft nicht')+'</span>'; return; }
 const p=C.premium_bps, z=C.premium_z, F=C.flow60||{};
 const farbe=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 el.innerHTML=`<span style="color:${p!=null?farbe(p):'#8b949e'}">${p!=null?(p>=0?'+':'')+p.toFixed(1)+' bps':'—'}</span>`
  +(z!=null?` <span class="d" style="display:inline">Z ${z.toFixed(1)}</span>`:'')
  +`<span class="d">Taker 60 min <span style="color:${farbe(F.net_usd)}">${F.net_usd>=0?'+':'−'}${fmt(Math.abs(F.net_usd||0))}</span>`
  +` (${fmt(F.buy_usd||0)} gekauft / ${fmt(F.sell_usd||0)} verkauft)`
  +(C.vol_rel?` · Volumen ${C.vol_rel.toFixed(1)}x des Schnitts`:'')
  +(C.book&&C.book.imbalance!=null?` · Buch ${(C.book.imbalance*100).toFixed(0)} %`:'')+`</span>`;
}

function taskWarn(b){
 // Absturz einer Recorder-Aufgabe sichtbar machen: vorher stand so etwas nur im Journal
 const P=(b&&b.poller)||{}, T=P.task_errors||{}, now=Date.now()/1000;
 const recent=Object.entries(T).filter(([k,v])=>v&&v.ts&&now-v.ts<6*3600);
 const stale=P.alive&&now-P.alive>180;
 const el=$('taskbar'); if(!el) return;
 if(!recent.length&&!stale){ el.style.display='none'; el.innerHTML=''; return; }
 el.style.display='block';
 el.innerHTML=(stale?`<b>Recorder meldet sich nicht</b> \u2014 letztes Lebenszeichen ${hm(P.alive)}.<br>`:'')
  +recent.map(([k,v])=>`<b>Aufgabe ${k} abgest\u00fcrzt</b> (${v.count}\u00d7 \u00b7 zuletzt ${hm(v.ts)}): ${esc(v.error)}`).join('<br>')
  +(recent.length?'<br><span class="lbl-dim">wird automatisch neu gestartet \u2014 Details unter Debug \u2192 Journal hl-recorder</span>':'');
}
function fillLbActTile(){
 const el=$('kpi_lbact'); if(!el) return; const A=LAST_CHART&&LAST_CHART.lb_act, S=A&&A.selected; $('kpi_lbact_coin').textContent=$('coin').value;
 if(!A){ el.textContent='lädt … (erster Lauf ~90 s nach Recorder-Start)'; return; }
 if(!S){ el.textContent='keine Trades der Top 50 in '+$('coin').value+' in 3 Tagen'; return; }
 const n24=S.net_usd_24h, n3=S.net_usd, c24=n24>0?'#3ba55d':n24<0?'#e04b4b':'#c9d1d9';
 el.innerHTML=`<span style="color:${c24}">24 h: netto ${n24>=0?'+':'−'}${fmt(Math.abs(n24))}</span><span class="d">3 Tage: netto ${n3>=0?'+':'−'}${fmt(Math.abs(n3))} · Käufe ${fmt(S.buy_usd)} (${S.n_buyers} Konten) · Verkäufe ${fmt(S.sell_usd)} (${S.n_sellers} Konten) · Spot ${fmt(S.spot_usd)}</span>`;
}
function drawLbActivity(A){
 const box=$('lbactcoins'); if(!box) return;
 if(!A){ box.innerHTML='<div class="sub">noch keine Fills — der Recorder holt sie etwa 90 s nach dem Start, dann stündlich.</div>'; $('lbactinfo').textContent=''; $('lbactbig').innerHTML=''; $('lbactspot').innerHTML=''; return; }
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4), sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 box.innerHTML=`<table class="w"><tr><th>Coin</th><th class="n">Käufe 3 T</th><th class="n">Konten</th><th class="n">Verkäufe 3 T</th><th class="n">Konten</th><th class="n">netto 3 T</th><th class="n">netto 24 h</th><th class="n">Spot-Anteil</th><th class="n">real. PnL</th><th class="n">Trades</th></tr>`
  +A.coins.slice(0,14).map(d=>`<tr${d.coin===coin?' style="background:#161b22"':''}><td><b>${d.coin}</b></td><td class="n" style="color:#3ba55d">${fmt(d.buy_usd)}</td><td class="n">${d.n_buyers}</td><td class="n" style="color:#e04b4b">${fmt(d.sell_usd)}</td><td class="n">${d.n_sellers}</td><td class="n" style="color:${col(d.net_usd)}"><b>${sg(d.net_usd)}</b></td><td class="n" style="color:${col(d.net_usd_24h)}">${sg(d.net_usd_24h)}</td><td class="n">${(d.buy_usd+d.sell_usd)?((d.spot_usd/(d.buy_usd+d.sell_usd))*100).toFixed(0):0} %</td><td class="n" style="color:${col(d.closed_pnl)}">${sg(d.closed_pnl)}</td><td class="n">${d.n}</td></tr>`).join('')+'</table>';
 $('lbactinfo').textContent=`Fills seit ${hm(A.since)} · jüngster Fill ${hm(A.last_fill)} · ${A.coins.length} Coins gehandelt · Kaufdruck = Open Long + Close Short + Spot-Kauf`;
 const B=A.big||[];
 $('lbactbig').innerHTML=B.length?`<div class="sub" style="margin:6px 0 4px"><b>Größte Trades in ${coin}</b> (die 25 größten der letzten 3 Tage, neueste zuerst · ab 50k je Minute gebündelt · Kursentwicklung seit dem Trade aus Sicht des Traders)</div><table class="w"><tr><th>Zeit</th><th>Konto</th><th>Markt</th><th>Richtung</th><th class="n">Notional</th><th class="n">Preis</th><th class="n" title="Kursentwicklung seit dem Trade aus Sicht des Traders: Kauf → Kurs gestiegen = plus; Verkauf → Kurs gefallen = plus">seither</th><th class="n" title="realisierter Gewinn des Fills gegen den Einstiegspreis der Position (Hyperliquid closedPnl), vor Gebühren; nur beim Schließen">real. PnL</th></tr>`
  +B.map(t=>`<tr><td class="mono">${hm(t.ts)}</td><td class="mono">${t.rank?'#'+t.rank+' ':''}${hsLink(t.addr, t.name?`<span class="lbl-name">${esc(t.name)}</span>`:short(t.addr))}</td><td>${esc(t.market)}</td><td style="color:${t.buy?'#3ba55d':'#e04b4b'}" title="${t.dir==='stream'?'live aus dem Trade-Stream; Richtung noch unbekannt (keine Position bekannt), closedPnl und Gebühr kommen mit dem REST-Nachtrag':(/[*]$/.test(t.dir||'')?'live aus dem Trade-Stream; Richtung aus der bekannten Position abgeleitet; closedPnl und Gebühr kommen mit dem REST-Nachtrag -- bei Konten mit tausenden Fills je Stunde bleibt es bei der Ableitung':'')}">${t.dir==='stream'?(t.buy?'Kauf':'Verkauf')+' <span style="opacity:.6">live</span>':(/[*]$/.test(t.dir||'')?esc(t.dir.slice(0,-1))+' <span style="opacity:.6">live</span>':esc(t.dir))}</td><td class="n"><b>${fmt(t.notional)}</b>${t.n>1?`<span class="lbl-dim"> ${t.n}×</span>`:''}</td><td class="n">${px(t.px)}</td><td class="n" style="color:${t.since_pct==null?'#8b949e':col(t.since_pct)}">${t.since_pct==null?'—':(t.since_pct>=0?'+':'')+t.since_pct.toFixed(2)+' %'}</td><td class="n" style="color:${t.closed_pnl?col(t.closed_pnl):'#8b949e'}" title="${(t.dir==='stream'||/[*]$/.test(t.dir||''))?'kommt mit dem REST-Nachtrag (bei sehr aktiven Konten nie)':(/open/i.test(t.dir||'')?'Eröffnung: es wird nichts realisiert -- PnL entsteht erst beim Schließen':'realisierter PnL dieses Fills (Hyperliquid closedPnl)')}">${(t.dir==='stream'||/[*]$/.test(t.dir||''))?'…':(t.closed_pnl?sg(t.closed_pnl):(/open/i.test(t.dir||'')?'—':'0'))}</td></tr>`).join('')+'</table>'
  :`<div class="sub">keine Trades ab 50k in ${coin} in den letzten 3 Tagen.</div>`;
 const SP=A.spot||[];
 $('lbactspot').innerHTML=SP.length?`<div class="sub" style="margin:6px 0 4px"><b>Spot-Bestände der Top 50</b> (jüngster Stundenstand)</div><table class="w"><tr><th>Token</th><th>Coin</th><th class="n">Konten</th><th class="n">Menge</th><th class="n">Wert (USD)</th><th class="n">Einstand</th><th class="n">seit Einstand</th></tr>`
  +SP.slice(0,12).map(r=>`<tr${r.coin===coin?' style="background:#161b22"':''}><td><b>${r.token}</b></td><td>${r.coin}</td><td class="n">${r.n}</td><td class="n">${r.total.toLocaleString('de-DE',{maximumFractionDigits:2})}</td><td class="n"><b>${r.usd?fmt(r.usd):'—'}</b></td><td class="n">${r.entry?fmt(r.entry):'—'}</td><td class="n" style="color:${r.usd&&r.entry?col(r.usd-r.entry):'#8b949e'}">${r.usd&&r.entry?((r.usd/r.entry-1)*100).toFixed(1)+' %':'—'}</td></tr>`).join('')+'</table>'
  :'<div class="sub">keine Spot-Bestände erfasst.</div>';
}
function drawLbAct48(A){
 const c=$('lbact48chart'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H); if(!W) return;
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4), sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 const S=A&&A.series||[];
 if(!A||!S.length){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText(A?'keine Trades der Top 50 in '+coin+' in 48 h':'noch keine Fills — der Recorder holt sie etwa 90 s nach dem Start',12,24);
  $('lbact48info').textContent=''; $('lbact48coins').innerHTML=''; $('lbact48big').innerHTML=''; GEO.lbact48=null; return; }
 const Lm=64,R=64,Tp=12,B=26,pw=W-Lm-R,ph=H-Tp-B, n=S.length, cw=pw/n;
 const mx=Math.max(1,...S.map(r=>Math.max(r.buy,r.sell))), cumMax=Math.max(1,...S.map(r=>Math.abs(r.cum)));
 const mid=Tp+ph/2, Yb=v=>(v/mx)*(ph/2), Yc=v=>mid-(v/cumMax)*(ph/2);
 g.strokeStyle='#161b22'; for(let k=0;k<=4;k++){const y=Tp+ph*k/4; g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke();}
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(Lm,mid); g.lineTo(W-R,mid); g.stroke();
 S.forEach((r,i)=>{ const x=Lm+i*cw+1, w=Math.max(1,cw-2); g.fillStyle='rgba(59,165,93,0.8)'; g.fillRect(x,mid-Yb(r.buy),w,Yb(r.buy)); g.fillStyle='rgba(224,75,75,0.8)'; g.fillRect(x,mid,w,Yb(r.sell)); });
 g.strokeStyle='#58a6ff'; g.lineWidth=1.8; g.beginPath(); S.forEach((r,i)=>{ const x=Lm+i*cw+cw/2; i?g.lineTo(x,Yc(r.cum)):g.moveTo(x,Yc(r.cum)); }); g.stroke();
 const P=S.filter(r=>r.px); if(P.length>1){ const lo=Math.min(...P.map(r=>r.px)), hi=Math.max(...P.map(r=>r.px)); const Yp=v=>Tp+ph-(v-lo)/Math.max(1e-9,hi-lo)*ph;
  g.strokeStyle='rgba(255,255,255,0.7)'; g.lineWidth=1; g.beginPath(); let started=false; S.forEach((r,i)=>{ if(!r.px) return; const x=Lm+i*cw+cw/2; started?g.lineTo(x,Yp(r.px)):g.moveTo(x,Yp(r.px)); started=true; }); g.stroke();
  g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='left'; g.fillText(px(hi),W-R+4,Tp+10); g.fillText(px(lo),W-R+4,Tp+ph); }
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right'; g.fillText('+'+fmt(mx)+'/h',Lm-4,Tp+10); g.fillText('0',Lm-4,mid+3); g.fillText('−'+fmt(mx)+'/h',Lm-4,Tp+ph); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(S[0].ts),Lm,H-8); g.textAlign='right'; g.fillText(hm(S[n-1].ts),W-R,H-8); g.textAlign='left';
 GEO.lbact48={S,Lm,R,Tp,B,pw,ph,W,H};
 const sel=A.selected||{buy_usd:0,sell_usd:0,net_usd:0,n_buyers:0,n_sellers:0,buy_usd_24h:0,sell_usd_24h:0};
 $('lbact48info').innerHTML=`${coin} 48 h: Käufe <span style="color:#3ba55d">${fmt(sel.buy_usd)}</span> (${sel.n_buyers} Konten) · Verkäufe <span style="color:#e04b4b">${fmt(sel.sell_usd)}</span> (${sel.n_sellers} Konten) · netto <b style="color:${col(sel.net_usd)}">${sg(sel.net_usd)}</b> · 24 h netto <b style="color:${col(sel.buy_usd_24h-sel.sell_usd_24h)}">${sg(sel.buy_usd_24h-sel.sell_usd_24h)}</b> · jüngster Fill ${hm(A.last_fill)}`;
 $('lbact48coins').innerHTML=`<table class="w"><tr><th>Coin</th><th class="n">Käufe 48 h</th><th class="n">Konten</th><th class="n">Verkäufe 48 h</th><th class="n">Konten</th><th class="n">netto 48 h</th><th class="n">netto 24 h</th><th class="n">Spot-Anteil</th><th class="n">Trades</th></tr>`
  +A.coins.slice(0,12).map(d=>`<tr${d.coin===coin?' style="background:#161b22"':''}><td><b>${d.coin}</b></td><td class="n" style="color:#3ba55d">${fmt(d.buy_usd)}</td><td class="n">${d.n_buyers}</td><td class="n" style="color:#e04b4b">${fmt(d.sell_usd)}</td><td class="n">${d.n_sellers}</td><td class="n" style="color:${col(d.net_usd)}"><b>${sg(d.net_usd)}</b></td><td class="n" style="color:${col(d.net_usd_24h)}">${sg(d.net_usd_24h)}</td><td class="n">${(d.buy_usd+d.sell_usd)?((d.spot_usd/(d.buy_usd+d.sell_usd))*100).toFixed(0):0} %</td><td class="n">${d.n}</td></tr>`).join('')+'</table>';
 const Bg=A.big||[];
 $('lbact48big').innerHTML=Bg.length?`<div class="sub" style="margin:6px 0 4px"><b>Trades in ${coin}, letzte 48 h</b> (ab 25k je Minute gebündelt, neueste zuerst · „seither" = Kurs seit dem Trade aus Sicht des Traders: bei einem Verkauf heißt minus, der Kurs ist danach gestiegen · „real. PnL" = Hyperliquids closedPnl gegen den Einstieg, vor Gebühren)</div><table class="w"><tr><th>Zeit</th><th>Konto</th><th>Markt</th><th>Richtung</th><th class="n">Notional</th><th class="n">Preis</th><th class="n" title="Kursentwicklung seit dem Trade aus Sicht des Traders: Kauf → Kurs gestiegen = plus; Verkauf → Kurs gefallen = plus">seither</th><th class="n" title="realisierter Gewinn des Fills gegen den Einstiegspreis der Position (Hyperliquid closedPnl), vor Gebühren; nur beim Schließen">real. PnL</th></tr>`
  +Bg.map(t=>`<tr><td class="mono">${hm(t.ts)}</td><td class="mono">${t.rank?'#'+t.rank+' ':''}${hsLink(t.addr, t.name?`<span class="lbl-name">${esc(t.name)}</span>`:short(t.addr))}</td><td>${esc(t.market)}</td><td style="color:${t.buy?'#3ba55d':'#e04b4b'}" title="${t.dir==='stream'?'live aus dem Trade-Stream; Richtung noch unbekannt (keine Position bekannt), closedPnl und Gebühr kommen mit dem REST-Nachtrag':(/[*]$/.test(t.dir||'')?'live aus dem Trade-Stream; Richtung aus der bekannten Position abgeleitet; closedPnl und Gebühr kommen mit dem REST-Nachtrag -- bei Konten mit tausenden Fills je Stunde bleibt es bei der Ableitung':'')}">${t.dir==='stream'?(t.buy?'Kauf':'Verkauf')+' <span style="opacity:.6">live</span>':(/[*]$/.test(t.dir||'')?esc(t.dir.slice(0,-1))+' <span style="opacity:.6">live</span>':esc(t.dir))}</td><td class="n"><b>${fmt(t.notional)}</b>${t.n>1?`<span class="lbl-dim"> ${t.n}×</span>`:''}</td><td class="n">${px(t.px)}</td><td class="n" style="color:${t.since_pct==null?'#8b949e':col(t.since_pct)}">${t.since_pct==null?'—':(t.since_pct>=0?'+':'')+t.since_pct.toFixed(2)+' %'}</td><td class="n" style="color:${t.closed_pnl?col(t.closed_pnl):'#8b949e'}" title="${(t.dir==='stream'||/[*]$/.test(t.dir||''))?'kommt mit dem REST-Nachtrag (bei sehr aktiven Konten nie)':(/open/i.test(t.dir||'')?'Eröffnung: es wird nichts realisiert -- PnL entsteht erst beim Schließen':'realisierter PnL dieses Fills (Hyperliquid closedPnl)')}">${(t.dir==='stream'||/[*]$/.test(t.dir||''))?'…':(t.closed_pnl?sg(t.closed_pnl):(/open/i.test(t.dir||'')?'—':'0'))}</td></tr>`).join('')+'</table>'
  :`<div class="sub">keine Trades ab 25k in ${coin} in den letzten 48 h.</div>`;
}
function fillLbTile(){
 const el=$('kpi_lbbtc'); if(!el) return; const L=LAST_CHART&&LAST_CHART.lb, B=L&&L.btc;
 if(!B||(!B.n_long&&!B.n_short)){ el.textContent=L&&L.ts?'keine BTC-Position unter den Top 20':'lädt … (Recorder fragt alle 10 min)'; el.style.color=''; return; }
 const tot=B.usd_long+B.usd_short, pl=tot?B.usd_long/tot*100:0, net=B.net_usd, col=net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9';
 const d24=B.delta_24h, d7=B.delta_7d, arrow=v=>v==null?'—':(v>0?'▲ +':v<0?'▼ ':'')+fmt(Math.abs(v));
 el.innerHTML=`<span style="color:#3ba55d">${B.n_long} LONG ${fmt(B.usd_long)} [${pl.toFixed(0)} %]</span> <span style="color:#8b949e">vs.</span> <span style="color:#e04b4b">${B.n_short} SHORT ${fmt(B.usd_short)} [${(100-pl).toFixed(0)} %]</span>`
  +`<span class="d" style="color:${col}">netto ${net>0?'long':net<0?'short':'neutral'} ${fmt(Math.abs(net))}</span><span class="d">24 h: ${arrow(d24)} · 7 T: ${arrow(d7)} — Trend: ${d24==null?'noch keine Historie':d24>0?'Longs bauen auf':d24<0?'Shorts bauen auf / Longs ab':'unverändert'}</span>`;
 el.style.color='';
}
function drawLbChart(L){
 const c=$('lbchart'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H); if(!W) return;
 const T=L&&L.trend||[];
 if(!T.length){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText(L&&L.ts?'noch keine Trendzeile — die erste kommt zur vollen Stunde':'noch keine Leaderboard-Abfrage — der Recorder fragt alle 10 min',12,24); GEO.lb=null; return; }
 const Lm=64,R=64,Tp=12,B=26,pw=W-Lm-R,ph=H-Tp-B;
 const t0=T[0].ts, t1=T[T.length-1].ts, X=t=>Lm+(t1>t0?(t-t0)/(t1-t0):0.5)*pw;
 const mx=Math.max(1,...T.map(r=>Math.max(r.usd_long,r.usd_short))), Y=v=>Tp+ph/2-(v/mx)*(ph/2);
 const Yn=v=>Tp+ph/2-(v/mx)*(ph/2);
 g.strokeStyle='#161b22'; for(let k=0;k<=4;k++){const y=Tp+ph*k/4; g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke();}
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(Lm,Tp+ph/2); g.lineTo(W-R,Tp+ph/2); g.stroke();
 const bw=Math.max(2,Math.min(14,pw/Math.max(T.length,1)*0.4));
 T.forEach(r=>{ const x=X(r.ts); g.fillStyle='rgba(59,165,93,0.75)'; g.fillRect(x-bw,Tp+ph/2-(r.usd_long/mx)*(ph/2),bw,(r.usd_long/mx)*(ph/2));
   g.fillStyle='rgba(224,75,75,0.75)'; g.fillRect(x,Tp+ph/2,bw,(r.usd_short/mx)*(ph/2)); });
 g.strokeStyle='#58a6ff'; g.lineWidth=1.8; g.beginPath(); T.forEach((r,i)=>{ const y=Yn(r.net_usd); i?g.lineTo(X(r.ts),y):g.moveTo(X(r.ts),y); }); g.stroke();
 const P=T.filter(r=>r.mark_px); if(P.length>1){ const lo=Math.min(...P.map(r=>r.mark_px)), hi=Math.max(...P.map(r=>r.mark_px)); const Yp=v=>Tp+ph-(v-lo)/Math.max(1e-9,hi-lo)*ph;
  g.strokeStyle='rgba(255,255,255,0.7)'; g.lineWidth=1; g.beginPath(); P.forEach((r,i)=>i?g.lineTo(X(r.ts),Yp(r.mark_px)):g.moveTo(X(r.ts),Yp(r.mark_px))); g.stroke();
  g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='left'; g.fillText(px(hi),W-R+4,Tp+10); g.fillText(px(lo),W-R+4,Tp+ph); }
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right'; g.fillText('+'+fmt(mx),Lm-4,Tp+10); g.fillText('0',Lm-4,Tp+ph/2+3); g.fillText('−'+fmt(mx),Lm-4,Tp+ph); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(t0),Lm,H-8); g.textAlign='right'; g.fillText(hm(t1),W-R,H-8); g.textAlign='left';
 GEO.lb={T,Lm,R,Tp,B,pw,ph,W,H,mx};
}
function drawLbTable(L){
 const box=$('lbtable'); if(!box) return; const A=L&&L.accounts||[]; const coin=$('coin').value;
 if(!A.length){ box.innerHTML='<div class="sub">noch keine Leaderboard-Abfrage.</div>'; return; }
 const short=a=>a.slice(0,6)+'…'+a.slice(-4);
 const head=a=>{ const net=a.positions.reduce((s,p)=>s+(p.side==='long'?1:-1)*(p.pos_value||0),0), col=net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9';
  return `<tr class="grp"><td class="mono" colspan="3"><b>#${a.rank}</b> ${a.name?`${hsLink(a.addr, `<span class="lbl-name">${esc(a.name)}</span>`)} · `:''}${hsLink(a.addr, short(a.addr))} · ${a.positions.length} Position${a.positions.length!==1?'en':''}<br><span class="lbl-beh">Kontowert ${fmt(a.account_value)} · PnL 30 T <span style="color:#3ba55d">+${fmt(a.pnl_30d)}</span> (${(a.roi_30d*100).toFixed(0)} %) · 7 T ${a.pnl_7d>=0?'+':''}${fmt(a.pnl_7d)}</span></td>`
   +`<td class="n"><b>${fmt(a.pos_total)}</b></td><td colspan="4" style="color:${col}">netto ${net>0?'long':net<0?'short':'—'} ${fmt(Math.abs(net))}</td><td class="n" style="color:${a.upnl>=0?'#3ba55d':'#e04b4b'}">${a.upnl>=0?'+':''}${fmt(a.upnl)}</td><td></td></tr>`; };
 box.innerHTML=`<table class="w"><tr><th>Rang / Konto</th><th>Coin</th><th>Seite</th><th class="n">Wert</th><th class="n">Hebel</th><th class="n">Einstieg</th><th class="n">Liq.-Preis</th><th class="n">Abstand</th><th class="n">unreal. PnL</th><th>Kurs</th></tr>`
  +A.map(a=>head(a)+a.positions.map(p=>{ const dist=p.mark_px?(p.liq_px-p.mark_px)/p.mark_px*100:0, dc=Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':'#c9d1d9';
    return `<tr${p.coin===coin?' style="background:#161b22"':''}><td class="mono" style="color:#6e7681;padding-left:18px">└ #${a.rank}</td><td><b>${p.coin}</b></td><td style="color:${p.side==='long'?'#3ba55d':'#e04b4b'}">${p.side}</td><td class="n"><b>${fmt(p.pos_value)}</b></td><td class="n">${(p.leverage||0)}x</td><td class="n">${px(p.entry_px||0)}</td><td class="n">${p.liq_px?px(p.liq_px):'—'}</td><td class="n" style="color:${dc}">${p.liq_px?(dist>0?'+':'')+dist.toFixed(1)+' %':'—'}</td><td class="n" style="color:${p.upnl>=0?'#3ba55d':'#e04b4b'}">${p.upnl>=0?'+':''}${fmt(p.upnl)}</td><td class="mono">${p.mark_px?px(p.mark_px):'—'}</td></tr>`; }).join('')).join('')+'</table>';
 const S=L.summary||{}; const F=L.flow||{}, w=F.w60||{}, w3=F.w180||{}, sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v||0)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 const LG=L.lag;
 $('lbinfo').innerHTML=`Stand ${hm(L.ts)} · ${A.length} Konten · in ${coin}: ${S.n_long||0} long ${fmt(S.usd_long||0)}, ${S.n_short||0} short ${fmt(S.usd_short||0)}, netto ${S.net_usd>0?'long':S.net_usd<0?'short':'—'} ${fmt(Math.abs(S.net_usd||0))} · Trendzeilen ${L.trend.length} (stündlich)`

  +(F.w60?`<br><b>Leaderboard-Flow live</b> (nur direktionale Konten, Stände alle 5 min verglichen): 60 min <span style="color:${col(w.net_usd)}">${sg(w.net_usd)}</span> (${w.n_buy||0}/${w.n_sell||0} Konten) · 3 h <span style="color:${col(w3.net_usd)}">${sg(w3.net_usd)}</span> (${w3.n_buy||0}/${w3.n_sell||0})${F.z60!=null?' · Z '+F.z60.toFixed(1):''}${F.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''} · ${F.n_directional||0} direktionale Konten`:'')
  +((L.events||[]).length?`<br><b>Letzte Änderungen der Top-Konten:</b> <span class="lbl-dim">(grau = nicht direktional)</span><br>`+L.events.slice(0,15).map(e=>{ const nm={open:'eröffnet',add:'stockt auf',reduce:'reduziert',close:'schließt',flip:'dreht auf'}[e.event]||e.event;
     return `<span style="${e.directional?'':'color:#6e7681'}">${hm(e.ts)} · ${e.rank?'#'+e.rank+' ':''}${hsLink(e.addr, e.name?`<span class="lbl-name">${esc(e.name)}</span>`:e.addr.slice(0,6)+'…'+e.addr.slice(-4))} ${nm} <span style="color:${e.directional?(e.side==='long'?'#3ba55d':'#e04b4b'):'#6e7681'}">${e.side}</span> ${e.delta_usd>=0?'+':''}${fmt(e.delta_usd)} USD${e.mark_px?' bei '+px(e.mark_px):''}</span>`; }).join('<br>'):'');
}
function fillFcLive(){
 const el=$('fclive'); if(!el) return; const F=LAST_WHALES&&LAST_WHALES.flow, fc=LAST_FC; if(!F||!F.w30){ el.textContent=''; return; }
 const w=F.w30, w60=F.w60, sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 const agree=fc&&Math.abs(fc.bias)>0.12&&Math.abs(w60.net_usd)>=1e6?(Math.sign(fc.bias)===Math.sign(w60.net_usd)?'bestätigt die Prognoserichtung':'<span style="color:#ff9f43">läuft gegen die Prognoserichtung — nächste Neuberechnung binnen 30 s</span>'):'';
 el.innerHTML=`<b>Wal-Flow live</b> (alle 20 s, nur direktionale Wale): 30 min <span style="color:${col(w.net_usd)}">${sg(w.net_usd)}</span> (${w.n_buy}/${w.n_sell} Wale) · 60 min <span style="color:${col(w60.net_usd)}">${sg(w60.net_usd)}</span> (${w60.n_buy}/${w60.n_sell})${F.z30!=null?' · Z '+F.z30.toFixed(1):''}${F.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''}${agree?' · '+agree:''}`
   +((LAST_CHART&&LAST_CHART.lb&&LAST_CHART.lb.flow&&LAST_CHART.lb.flow.w60)?(()=>{ const LF=LAST_CHART.lb.flow, l60=LF.w60; return `<br><b>Leaderboard-Flow live</b> (direktionale Top-Konten, 5-min-Stände): 60 min <span style="color:${col(l60.net_usd)}">${sg(l60.net_usd)}</span> (${l60.n_buy}/${l60.n_sell} Konten)${LF.z60!=null?' · Z '+LF.z60.toFixed(1):''}${LF.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''}`; })():'')
   +(fc&&fc.trigger?`<br>letzte Prognose ausgelöst durch ${fc.trigger}`:'');
}
function fillFlow(){
 const el=$('kpi_flow'); if(!el) return; const F=LAST_WHALES&&LAST_WHALES.flow; if(!F||!F.w30){ el.textContent='—'; return; }
 const w=F.w30, w60=F.w60, col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9', sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v));
 const G=F.groups||{}, NM=F.group_names||{}, SZ=F.sizes||{};
 const line=g=>{ const gf=G[g]; if(!gf) return ''; const a=gf.w60||{}; if(!a.n_buy&&!a.n_sell) return `${NM[g]||g} ruhig`;
   return `${NM[g]||g} ${a.net_usd>=0?'+':'−'}${fmt(Math.abs(a.net_usd))} (${a.n_buy}/${a.n_sell})`; };
 el.innerHTML=`<span style="color:${col(w.net_usd)}">${sg(w.net_usd)}</span>${F.event_signal?' <span style="color:#ff9f43">⚡ Ereignis</span>':''}`
  +`<span class="d">direktional: ${w.n_buy} kaufen ${fmt(w.buy_usd)} · ${w.n_sell} verkaufen ${fmt(w.sell_usd)}${F.z30!=null?' · Z '+F.z30.toFixed(1):''} · 60 min ${sg(w60.net_usd)}`
  +`<br>60 min je Gruppe: ${['hedge','mm','mixed'].map(line).filter(Boolean).join(' · ')||'keine weiteren Gruppen'}`
  +`<br>${Object.entries(SZ).map(([g,n])=>`${n} ${NM[g]||g}`).join(' · ')} (Klasse je Coin)</span>`;
}
function fillDirectional(){
 const el=$('kpi_dirn'); if(!el) return; const D=LAST_WHALES&&LAST_WHALES.directional;
 if(!D||!D.n_directional){ el.textContent='—'; el.style.color=''; el.title=D?`${D.n_whales} Wale erfasst, keiner direktional`:''; return; }
 const tot=D.usd_long+D.usd_short, pl=tot?D.usd_long/tot*100:0, ps=tot?D.usd_short/tot*100:0;
 el.innerHTML=`<span style="color:#3ba55d">${D.n_long} LONG ${fmt(D.usd_long)} [${pl.toFixed(0)} %]</span> <span style="color:#8b949e">vs.</span> <span style="color:#e04b4b">${D.n_short} SHORT ${fmt(D.usd_short)} [${ps.toFixed(0)} %]</span>`
  +`<span class="d">${D.n_directional} von ${D.n_whales} Walen direktional · übrige: Hedge, Market Maker, gemischt</span>`;
 el.style.color='';
}
function fillMAs(d){
 const m=d.mas||{}, a=$('kpi_ma50w'), b=$('kpi_ma200d'); if(!a||!b) return;
 const all=`MA 50 T ${m.ma50d?px(m.ma50d):'—'} · MA 200 T ${m.ma200d?px(m.ma200d):'—'}\\nMA 50 W ${m.ma50w?px(m.ma50w):'—'} · MA 200 W ${m.ma200w?px(m.ma200w):'—'}`
  +`\\n${m.days} Tageskerzen, ${m.weeks} Wochen · Quelle ${m.source||'—'}`
  +(m.cross?`\\n${m.cross==='golden'?'Golden Cross (MA50 T über MA200 T)':'Death Cross (MA50 T unter MA200 T)'}`:'');
 const set=(el,v,dist)=>{ if(v==null){el.textContent='—';el.style.color='';el.title=all+'\\nZu wenig Tageskerzen — hl_binance.py --backfill-daily';return;}
  el.innerHTML=px(v)+' <span class="d">'+(dist>=0?'▲':'▼')+' '+(Math.abs(dist)*100).toFixed(1)+' %</span>';
  el.style.color=dist>=0?'#3ba55d':'#e04b4b'; el.title=all+`\\nKurs ${dist>=0?'über':'unter'} dem Durchschnitt (${(dist*100).toFixed(2)} %)`; };
 set(a,m.ma50w,m.ma50w_dist); set(b,m.ma200d,m.ma200d_dist);
}
function fillIndicators(d){
 fillMAs(d);
 const t=$('kpi_trend'), r=$('kpi_rsi'), l=$('kpi_rsi_lbl');
 if(!t||!r) return;
 if(d.trend_60m==null){t.textContent='—';t.style.color='';}
 else{const v=d.trend_60m*100;
  t.textContent=(v>=0?'▲ +':'▼ ')+v.toFixed(2)+' %';
  t.style.color=Math.abs(v)<0.15?'#c9d1d9':v>0?'#3ba55d':'#e04b4b';}
 if(d.rsi14==null){r.textContent='—';r.style.color='';}
 else{const v=d.rsi14; r.textContent=v.toFixed(1);
  r.style.color=v>=70?'#e04b4b':v<=30?'#3ba55d':'#c9d1d9';
  r.title=v>=70?'überkauft':v<=30?'überverkauft':'neutral';}
 if(l) l.textContent='RSI 14 · '+(d.rsi_tf||'');
}
function fit(c){
 // Höhe immer aus dem HTML-Attribut ableiten. Vorher wurde c.height bei jedem
 // Zeichnen erneut mit der Pixeldichte multipliziert -- auf Handys (Dichte 2-3)
 // wuchs der Chart damit alle 5 s um den Faktor der Dichte.
 const d=EXPORT_DPR||devicePixelRatio||1;
 // Basis-Höhe EINMAL aus dem HTML-Attribut nehmen und in data-h0 merken:
 // c.height=... schreibt das Attribut zurück, sonst wächst es mit jeder Zeichnung.
 if(!c.dataset.h0) c.dataset.h0=c.getAttribute('height')||'400';
 const base=+(innerWidth<700&&c.dataset.hm?c.dataset.hm:c.dataset.h0)||400;
 const r=c.getBoundingClientRect();
 if(r.width===0){ return [c.getContext('2d'),0,base]; }   // eingeklappter Abschnitt: nichts zu zeichnen
 c.style.height=base+'px';
 c.width=Math.round(r.width*d); c.height=Math.round(base*d);
 const x=c.getContext('2d'); x.setTransform(d,0,0,d,0,0);
 return [x,r.width,base];}
function esc(v){
 // Objekte NICHT still zu "[object Object]" machen. Genau das ist am 13.09. passiert und
 // ließ sich nicht zurückverfolgen: Man sah das Symptom, aber nicht, welcher Wert es war.
 // Mit der Kurzfassung des Objekts steht die Ursache direkt auf dem Bildschirm.
 if(v&&typeof v==='object'){ try{ v='{'+Object.keys(v).slice(0,6).join(',')+'}'; }catch(e){ v='[Objekt]'; } }
 // Namen kommen aus fremder Hand: Hyperliquid-Anzeigenamen sind frei wählbar, ebenso
 // Vault-Namen und Arkham-Tags. Unmaskiert per innerHTML eingesetzt, führt
 // displayName = "<img src=x onerror=...>" Code im Dashboard aus -- und könnte von dort
 // die Update-Schaltfläche auslösen. Jede Zeichenkette aus einer externen Quelle läuft
 // deshalb hier durch.
 return String(v==null?'':v).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function fmt(n){ if(n<0) return '-'+fmt(-n);   // negative Werte (PnL) mit Vorzeichen, gleiche Einheiten
 return n>=1e9?(n/1e9).toFixed(2)+' Mrd':n>=1e6?(n/1e6).toFixed(1)+' Mio'
 :n>=1e3?(n/1e3).toFixed(0)+'k':(+n).toFixed(0);}
function px(n){return n>=1000?n.toLocaleString('de-DE',{maximumFractionDigits:2})
 :(+n).toFixed(4);}
function hm(ts){const d=new Date(ts*1000);
 return String(d.getDate()).padStart(2,'0')+'.'+String(d.getMonth()+1).padStart(2,'0')
  +'. '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');}
function dmy(ts){const d=new Date(ts*1000);
 return String(d.getDate()).padStart(2,'0')+'.'+String(d.getMonth()+1).padStart(2,'0')+'.'+String(d.getFullYear()).slice(2);}
// Zeitbeschriftung passend zum Raster: bei Tagen und Wochen nur das Datum
function tlabel(ts){ return (LAST_CHART&&LAST_CHART.agg>=1440)?dmy(ts):hm(ts); }

// Farbverlauf dunkelblau -> blau -> cyan -> gelb -> weiss.
// Der dunkle Fuss ist entscheidend: ohne ihn leuchtet die ganze Flaeche.
const RAMP=[[0,4,10,32],[.22,10,40,140],[.45,0,150,200],
            [.68,60,220,180],[.85,255,214,10],[1,255,255,235]];
function heatColor(p){
 for(let i=1;i<RAMP.length;i++){
  if(p<=RAMP[i][0]){const a=RAMP[i-1],b=RAMP[i],t=(p-a[0])/(b[0]-a[0]||1);
   return [Math.round(a[1]+(b[1]-a[1])*t),Math.round(a[2]+(b[2]-a[2])*t),
           Math.round(a[3]+(b[3]-a[3])*t)];}}
 return [255,255,235];
}
// Perzentil-Zuordnung: entscheidend ist der Rang unter allen Zellen.
function makeScale(values){
 const v=values.filter(x=>x>0); if(!v.length) return null;
 const step=Math.max(1,Math.floor(v.length/20000)), s=[];
 for(let i=0;i<v.length;i+=step) s.push(v[i]);
 s.sort((a,b)=>a-b);
 const BINS=256, brk=new Float64Array(BINS);
 for(let i=0;i<BINS;i++) brk[i]=s[Math.min(s.length-1,Math.floor(i/BINS*s.length))];
 return {brk,min:s[0],max:s[s.length-1],
  pct(x){let lo=0,hi=BINS-1; if(x<=this.brk[0])return 0;
   while(lo<hi){const m=(lo+hi+1)>>1; if(this.brk[m]<=x)lo=m;else hi=m-1;}
   return lo/(BINS-1);}};
}

function drawChart(d){
 const [g,W,H]=fit($('chart')); g.clearRect(0,0,W,H);
 if(!d||!d.candles.length){g.fillStyle='#8b949e';
  g.fillText('noch keine Kursdaten — der Recorder muss erst laufen',12,24);return;}
 const C=d.candles, L=(d.levels||[]);
 const narrow=W<600, R=narrow?56:68,Lm=8,T=12,B=26, pw=W-Lm-R, ph=H-T-B;
 let lo=Math.min(...C.map(c=>c.l)), hi=Math.max(...C.map(c=>c.h));
 L.forEach(l=>{if(Math.abs(l.dist)<0.035){lo=Math.min(lo,l.px);hi=Math.max(hi,l.px);}});
 { const M0=d.mas||{}, p0=C[C.length-1].c;
   ['ma50w','ma200d','ma50d','ma200w'].forEach(k=>{const v=M0[k]; if(v&&Math.abs(v/p0-1)<0.035){lo=Math.min(lo,v);hi=Math.max(hi,v);}});
   const K0=keyLevels(d)||{}; Object.keys(KEY_STYLE).forEach(k=>{const s=K0[k]; if(s&&Math.abs(s.px/p0-1)<0.035){lo=Math.min(lo,s.px);hi=Math.max(hi,s.px);}}); }
 if(SIGNAL&&SIGNAL.zone){const z=SIGNAL.zone, p0=C[C.length-1].c;
  if(Math.abs(z.bot/p0-1)<0.035&&Math.abs(z.top/p0-1)<0.035){lo=Math.min(lo,z.bot);hi=Math.max(hi,z.top);}}
 const pad=(hi-lo)*0.08||1; lo-=pad; hi+=pad;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 const cw=Math.max(1.5,pw/C.length), bw=Math.max(1,cw*0.62);
 const FV=FVG_ON?(d.fvgs||[]):[];
 GEO.chart={C,L,Lm,T,pw,ph,cw,lo,hi,H,B,R,W,FV};

 g.strokeStyle='#161b22';g.lineWidth=1;
 for(let k=0;k<=5;k++){const y=T+ph*k/5;g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();}

 // Fair Value Gaps: von der mittleren Kerze bis zur Füllung, sonst bis zum Rand
 FV.forEach(f=>{const x0=Lm+f.i*cw, x1=f.fill_i!=null?Lm+f.fill_i*cw+cw:W-R;
  const y0=Y(f.top), y1=Y(f.bot); if(y1<T||y0>H-B) return;
  const open=f.fill_i==null, a=open?0.28:0.09;
  g.fillStyle=f.kind==='bull'?`rgba(57,255,20,${a})`:`rgba(224,75,75,${a})`;
  g.fillRect(x0,Math.max(T,y0),Math.max(1,x1-x0),Math.min(H-B,y1)-Math.max(T,y0));
  if(open){g.strokeStyle=f.kind==='bull'?'rgba(57,255,20,.95)':'rgba(224,75,75,.7)';
   g.lineWidth=1;g.setLineDash([2,3]);g.strokeRect(x0,y0,x1-x0,y1-y0);g.setLineDash([]);
   // Teilfüllung als Balken an der Innenkante
   if(f.fill_pct>0){g.fillStyle='rgba(255,255,255,.12)';
    const fh=(y1-y0)*f.fill_pct; g.fillRect(x0,f.kind==='bull'?y0:y1-fh,x1-x0,fh);}}});

 // Eingetretene Liquidationen als Marker (Binance orange, Hyperliquid magenta) -- Binance- und Fusionsmodus
 if(d.liq_marks&&d.liq_marks.length){ const t0=C[0].t, t1=C[C.length-1].t, step=C.length>1?(C[1].t-C[0].t):60;
  d.liq_marks.forEach(m=>{ const [t,p,usd,side,src]=m; if(t<t0||t>t1+step) return;
   const i=Math.min(C.length-1,Math.floor((t-t0)/step)), x=Lm+i*cw+cw/2, y=Y(p); if(y<T||y>H-B) return;
   g.fillStyle=src==='bnc'?'rgba(255,159,67,0.9)':'rgba(255,59,107,0.9)';
   g.beginPath(); if(side==='long'){ g.moveTo(x-3,y-3); g.lineTo(x+3,y-3); g.lineTo(x,y+3);} else { g.moveTo(x-3,y+3); g.lineTo(x+3,y+3); g.lineTo(x,y-3);} g.closePath(); g.fill(); }); }

 // Kaskadenprognose: Auslöser (orange, gestrichelt) und Ziel (orange, gepunktet) je Richtung, wenn der Auslöser innerhalb 3 % liegt
 if(LAST_CASCADE&&d.price){ for(const dir of ['down','up']){ const C=LAST_CASCADE[dir]; if(!C) continue; if(Math.abs(C.trigger.px/d.price-1)>0.03) continue;
  const yT=Y(C.trigger.px), yZ=Y(C.target.px); g.strokeStyle='rgba(255,159,67,0.9)'; g.lineWidth=1.2;
  if(yT>T&&yT<H-B){ g.setLineDash([6,3]); g.beginPath(); g.moveTo(Lm,yT); g.lineTo(W-R,yT); g.stroke(); g.setLineDash([]);
   g.fillStyle='#ff9f43'; g.font='bold 10px system-ui'; g.textAlign='left'; g.fillText(`KASKADE ${dir==='down'?'▼':'▲'} ab ${px(C.trigger.px)} · ${C.type}`, Lm+6, yT+(dir==='down'?12:-4)); }
  if(yZ>T&&yZ<H-B){ g.setLineDash([2,3]); g.beginPath(); g.moveTo(Lm,yZ); g.lineTo(W-R,yZ); g.stroke(); g.setLineDash([]);
   g.fillStyle='#ff9f43'; g.font='10px system-ui'; g.fillText(`Ziel ≈ ${px(C.target.px)} (Druck ${fmt(C.target.cumP)} / Aufnahme ${fmt(C.target.cumA)})`, Lm+6, yZ+(dir==='down'?12:-4)); } } }

 // Gleitende Durchschnitte als waagerechte Linien, sofern im Preisbereich
 const M=d.mas||{};
 [['ma50w','MA 50 W','#e3b341'],['ma200d','MA 200 T','#a371f7'],['ma50d','MA 50 T','#79c0ff'],['ma200w','MA 200 W','#f778ba']].forEach(([k,lab,col])=>{
  const v=M[k]; if(!v) return; const y=Y(v); if(y<T||y>H-B) return;
  g.strokeStyle=col; g.lineWidth=1.2; g.setLineDash([6,4]); g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
  g.fillStyle=col; g.font='bold 10px system-ui'; g.fillText(lab+' '+px(v), Lm+6, y-3);});

 // Schlüsselniveaus aus den Orders der Großkonten: Support, Resistance, Take-Profits, Stops
 { const K=keyLevels(d)||{}; let usedY=[];
   Object.entries(KEY_STYLE).forEach(([k,[label,color]])=>{ const s=K[k]; if(!s) return; const y=Y(s.px); if(y<T||y>H-B) return;
    g.strokeStyle=color; g.lineWidth=k==='support'||k==='resistance'?2:1.2; g.setLineDash(k.startsWith('stop')?[3,3]:k.startsWith('tp')?[8,4]:[]);
    g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
    // Beschriftung links, ohne Kollision
    let ly=y-4; while(usedY.some(u=>Math.abs(u-ly)<11)) ly-=11; usedY.push(ly);
    const txt=label+' '+px(s.px)+' · '+fmt(s.notional); g.font='bold 10px system-ui';
    const tw=g.measureText(txt).width+8; g.fillStyle='rgba(13,17,23,0.85)'; g.fillRect(Lm+4,ly-9,tw,12);
    g.fillStyle=color; g.fillText(txt, Lm+8, ly); }); }

 // Konfluenz-Zone: ein AKTUELLES Fenster -- Kasten am rechten Rand über die
 // letzten Kerzen, nicht ein Band über die ganze Historie
 if(SIGNAL&&SIGNAL.zone){const z=SIGNAL.zone, y0=Y(z.top), y1=Y(z.bot);
  if(y1>T&&y0<H-B){const c=z.kind==='buy'?'57,255,20':'224,75,75';
   const zw=Math.max(cw*10, pw*0.09), x0=W-R-zw, x1=W-R;
   const yy0=Math.max(T,y0), yy1=Math.min(H-B,y1);
   g.fillStyle=`rgba(${c},0.22)`; g.fillRect(x0,yy0,zw,yy1-yy0);
   g.strokeStyle=`rgba(${c},0.95)`; g.lineWidth=2; g.strokeRect(x0,yy0,zw,yy1-yy0);
   // linke Kante als Beginn des Fensters betonen
   g.fillStyle=`rgba(${c},0.9)`; g.fillRect(x0-1,yy0,3,yy1-yy0);
   const label=(z.kind==='buy'?'KAUFZONE':'VERKAUFSZONE'), sub=z.text;
   g.font='bold 11px system-ui'; const lw=Math.max(g.measureText(label).width,g.measureText(sub).width)+12;
   const lx=Math.max(Lm, x1-lw), ly=(z.kind==='buy'? Math.max(T+2, yy0-30) : Math.min(H-B-30, yy1+4));
   g.fillStyle='rgba(13,17,23,0.85)'; g.fillRect(lx,ly,lw,28);
   g.strokeStyle=`rgba(${c},0.95)`; g.lineWidth=1; g.strokeRect(lx,ly,lw,28);
   g.fillStyle=`rgb(${c})`; g.fillText(label, lx+6, ly+12);
   g.font='10px system-ui'; g.fillStyle='#c9d1d9'; g.fillText(sub, lx+6, ly+24);}}
 const mxN=Math.max(...L.map(l=>l.notional),1);
 L.forEach(l=>{const y=Y(l.px); if(y<T||y>H-B)return;
  const a=0.25+0.65*(l.notional/mxN);
  g.strokeStyle=l.side==='long'?`rgba(224,75,75,${a})`:`rgba(59,165,93,${a})`;
  g.lineWidth=l.x_vol>=0.5?2:1; g.setLineDash(l.x_vol>=0.5?[]:[3,3]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle=l.side==='long'?'#e04b4b':'#3ba55d';g.font='9px system-ui';
  g.fillText(fmt(l.notional),W-R+3,y-2);
  g.fillStyle='#6e7681';g.fillText((l.dist*100).toFixed(1)+'%',W-R+3,y+8);});
 C.forEach((c,i)=>{const x=Lm+i*cw+cw/2, up=c.c>=c.o;
  g.strokeStyle=up?'#3ba55d':'#e04b4b'; g.fillStyle=g.strokeStyle; g.lineWidth=1;
  g.beginPath();g.moveTo(x,Y(c.h));g.lineTo(x,Y(c.l));g.stroke();
  const y1=Y(Math.max(c.o,c.c)),y2=Y(Math.min(c.o,c.c));
  g.fillRect(x-bw/2,y1,bw,Math.max(1,y2-y1));});
 if(d.price){const y=Y(d.price);
  g.strokeStyle='#00e5ff';g.lineWidth=1;g.setLineDash([5,4]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle='#00e5ff';g.fillRect(W-R,y-7,R,14);
  g.fillStyle='#010409';g.font='bold 10px system-ui';g.fillText(px(d.price),W-R+3,y+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 for(let k=0;k<4;k++){const i=Math.floor(k/3*(C.length-1));
  g.fillText(tlabel(C[i].t), Lm+i*cw, H-8);}
 g.fillText('Preis (USD) rechts · Zeit unten', Lm, T+10);
 const te=(d.tick_events||[]);
 const openF=FV.filter(f=>f.fill_i==null);
 const nearest=openF.slice().sort((a,b)=>Math.abs(a.dist)-Math.abs(b.dist))[0];
 const fvtxt=FV.length?` · <b>FVG:</b> ${openF.length} offen (${openF.filter(f=>f.kind==='bull').length} bull / `
   +`${openF.filter(f=>f.kind==='bear').length} bear), ${FV.length-openF.length} gefüllt`
   +(nearest?` · nächstes ${nearest.kind} ${px(nearest.bot)}–${px(nearest.top)} `
     +`(${(nearest.dist*100).toFixed(2)} %, ${(nearest.fill_pct*100).toFixed(0)} % gefüllt)`:''):'';
 $('chartinfo').innerHTML=(d.agg>=240?`Quelle: ${d.source} · `:'')+`${C.length} Kerzen · ${L.length} Liquidationsmarken`
  +` · Stundenvolumen ${fmt(d.vol_1h||0)} USD`+fvtxt
  +(te.length?`<br><b>Tick-Aufzeichnungen:</b> `+te.map(e=>
    `${hm(e.t_trigger/1000)} <span style="color:${e.move_pct<0?'#e04b4b':'#3ba55d'}">`
    +`${(e.move_pct*100).toFixed(2)} %</span> (${e.reason}, ${e.n_ticks.toLocaleString('de-DE')} Ticks, `
    +`${e.n_liqs} Liqs)`).join(' · '):'');
}

function drawHeat(d){
 const [g,W,H]=fit($('heat')); g.clearRect(0,0,W,H);
 if(!d||!d.times.length||!d.price||!d.price.length){g.fillStyle='#8b949e';g.fillText('keine Daten',12,22); $('heatinfo').textContent=''; GEO.heat=null; return;}
 const P=d.price.map(p=>p[1]), lo=Math.min(...P)*0.94, hi=Math.max(...P)*1.06;
 const L=52,R=12,T=10,B=26, pw=W-L-R, ph=H-T-B;
 const t0=d.times[0], t1=d.times[d.times.length-1];
 const X=t=>L+(t-t0)/(t1-t0+1)*pw, Y=p=>T+(hi-p)/(hi-lo)*ph;
 g.fillStyle='#01030a'; g.fillRect(L,T,pw,ph);
 const flat=[]; d.grid.forEach(r=>r.forEach(v=>{if(v>0)flat.push(v)}));
 const sc=makeScale(flat), thr=(+$('thr').value)/100;
 const cw=Math.max(1.5,pw/d.times.length), chh=Math.max(1.5,ph*0.0025/((hi-lo)/hi));
 GEO.heat={d,L,T,pw,ph,lo,hi,t0,t1,sc,thr,H,B,W,R};
 let shown=0;
 d.grid.forEach((row,i)=>{const y=Y(d.levels[i]); if(y<T-4||y>H-B+4)return;
  row.forEach((v,j)=>{ if(v<=0||!sc)return;
   const p=sc.pct(v); if(p<thr)return;
   const q=Math.pow((p-thr)/(1-thr||1),2.6);
   const c=heatColor(q);
   g.fillStyle=`rgba(${c[0]},${c[1]},${c[2]},${0.35+0.65*q})`;
   g.fillRect(X(d.times[j]),y-chh/2,cw,chh); shown++;});});
 g.strokeStyle='#ffffff';g.lineWidth=1.6;g.beginPath();
 d.price.forEach((p,i)=>{const x=X(p[0]),y=Y(p[1]);i?g.lineTo(x,y):g.moveTo(x,y)});
 g.stroke();
 g.strokeStyle='#ff3b6b';g.lineWidth=1.2;
 // Eingetretene Liquidationen: die betroffene Zelle wird magenta, wie in der Legende.
 // Mehrere im selben Zeit-/Preisfeld werden zusammengefasst; die Deckkraft folgt dem Notional.
 { const cells=new Map();
   d.liqs.forEach(l=>{ const col=Math.floor((l[0]-t0)/Math.max(1,(t1-t0)/d.times.length)), row=Math.round(Math.log(l[1]/lo)/Math.log(1.0025));
     const k=col+':'+row; const c=cells.get(k)||{x:X(l[0]),y:Y(l[1]),usd:0,n:0}; c.usd+=l[2]; c.n++; cells.set(k,c); });
   cells.forEach(c=>{ if(c.y<T-4||c.y>H-B+4) return;
     const a=Math.min(1,0.45+c.usd/2e6*0.55), h=Math.max(chh,3), w=Math.max(cw,3);
     g.fillStyle=`rgba(255,59,107,${a})`; g.fillRect(Math.floor(c.x),Math.round(c.y-h/2),Math.ceil(w),Math.ceil(h));
     g.strokeStyle='#ff3b6b'; g.lineWidth=1; g.strokeRect(Math.floor(c.x)+0.5,Math.round(c.y-h/2)+0.5,Math.ceil(w),Math.ceil(h)); }); }
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=4;k++){const p=lo+(hi-lo)*k/4;g.fillText(px(p).slice(0,9),4,Y(p)+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 const nx=W<600?2:4;   // auf schmalen Bildschirmen weniger Zeitmarken, sonst überlappen sie
 for(let k=0;k<=nx;k++){const t=t0+(t1-t0)*k/nx;
  g.fillText(hm(t), Math.min(X(t),W-R-52), H-8);}
 g.fillStyle='#8b949e';g.font='9px system-ui';
 g.save();g.translate(11,T+ph/2);g.rotate(-Math.PI/2);
 g.textAlign='center';g.fillText('Preis (USD)',0,0);g.restore();
 let extra='';
 if(SRC()==='fusion'&&LAST_DATA&&LAST_DATA.bnc&&LAST_DATA.bnc.grid_liqs){
  // Binance-Liquidationen als HOTSPOTS: Summe je 10-min-Spalte und 0,25-%-Preisstufe, nur ab
  // der gewählten Schwelle (Vorgabe 20 Mio). Einzelne Orders rahmten sonst die Kurslinie ein,
  // ohne etwas zu bedeuten -- ein Hotspot der Heatmap ist ebenfalls eine Summe je Stufe.
  const minUsd=(+($('bncliqmin')?$('bncliqmin').value:20))*1e6; $('bncliqleg').style.display='';
  const cells=(LAST_DATA.bnc.liq_cells||[]).filter(c=>c[2]>=minUsd); const cw2=Math.max(2,pw/d.times.length*(600/((d.times[1]||900)-(d.times[0]||0))));
  const mx=Math.max(minUsd, ...cells.map(c=>c[2])); let gross=0;
  cells.forEach(c=>{const x=X(c[0]), y=Y(c[1]); if(y<T||y>H-B||x<L||x>W-R) return; const k=Math.min(1,(c[2]-minUsd)/(mx-minUsd+1e-9));
   g.fillStyle=`rgba(255,${Math.round(159+60*k)},${Math.round(67+120*k)},${(0.55+0.45*k).toFixed(2)})`; g.fillRect(Math.floor(x),Math.round(y-3),Math.max(cw2,4),6); gross=Math.max(gross,c[2]);});
  extra=` · Binance-Liquidationen ab ${(minUsd/1e6).toFixed(0)} Mio: ${cells.length} Hotspots${cells.length?` (größter ${fmt(gross)})`:''} von ${(LAST_DATA.bnc.liq_cells||[]).length} Zellen`;
 }
 $('heatinfo').textContent=(d.realized?`Eingetretene Binance-Liquidationen: ${flat.length.toLocaleString('de-DE')} Zellen · Notional je Zelle bis ${fmt(sc?sc.max:0)} USD`
  :(sc? `${shown.toLocaleString('de-DE')} von ${flat.length.toLocaleString('de-DE')} Zellen `
    +`sichtbar · unterhalb Perzentil ${Math.round(thr*100)} ausgeblendet `
    +`· Notional je Zelle ${fmt(sc.min)}–${fmt(sc.max)} USD` : ''))+extra;
}

function drawDepth(d){
 const [g,W,H]=fit($('depth')); g.clearRect(0,0,W,H);
 const di=$('depthinfo');
 if(!d||!d.rows.length){g.fillStyle='#8b949e';g.fillText(d&&d.realized?'keine eingetretenen Binance-Liquidationen im Zeitraum':'kein Snapshot',12,22);
  if(di) di.textContent=d&&d.realized?'Binance: keine eingetretenen Liquidationen in den letzten 24 h — oder hl_binance läuft nicht':''; GEO.depth=null; return;}
 const p0=d.price, rows=d.rows.filter(r=>r.bucket_px>p0*0.85&&r.bucket_px<p0*1.18);
 if(!rows.length){g.fillStyle='#8b949e';g.fillText('keine Cluster im Bereich',12,22); if(di) di.textContent=''; GEO.depth=null; return;}
 const lo=p0*0.85, hi=p0*1.18, mx=Math.max(...rows.map(r=>r.notional));
 const L=62,R=10,T=10,B=26, pw=W-L-R, ph=H-T-B;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 GEO.depth={rows,L,T,pw,ph,lo,hi,mx,p0,vol:d.vol_1h,H,B,W,R};
 rows.forEach(r=>{const w=r.notional/mx*pw, y=Y(r.bucket_px);
  g.fillStyle=r.side==='long'?'rgba(224,75,75,.85)':'rgba(59,165,93,.85)';
  g.fillRect(L,y-2,w,4);});
 if(d.vol_1h>0){const x=L+(d.vol_1h*0.5)/mx*pw;
  if(x<W-R){g.strokeStyle='#8b949e';g.setLineDash([4,4]);g.beginPath();
   g.moveTo(x,T);g.lineTo(x,H-B);g.stroke();g.setLineDash([]);
   g.fillStyle='#8b949e';g.font='9px system-ui';g.fillText('halbes Stundenvolumen',x+3,T+10);}}
 g.strokeStyle='#00e5ff';g.lineWidth=2;g.beginPath();
 g.moveTo(L,Y(p0));g.lineTo(W-R,Y(p0));g.stroke();
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=6;k++){const p=lo+(hi-lo)*k/6;g.fillText(px(p).slice(0,9),4,Y(p)+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 for(let k=0;k<=3;k++){const v=mx*k/3;g.fillText(fmt(v),L+pw*k/3,H-8);}
 g.fillText('Notional (USD)',L+pw/2-30,H-16);
 const up=rows.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
 const dn=rows.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0);
 // Fusion: eingetretene Binance-Liquidationen der letzten 24 h als Overlay (orange), NICHT addiert --
 // erwartete Cluster und eingetretene Liquidationen sind verschiedene Größen.
 let extra='';
 if(SRC()==='fusion'&&LAST_DATA&&LAST_DATA.bnc&&LAST_DATA.bnc.depth){
  const R2=LAST_DATA.bnc.depth.rows.filter(r=>r.bucket_px>lo&&r.bucket_px<hi);
  const mx2=Math.max(...R2.map(r=>r.notional),1);
  R2.forEach(r=>{const w=r.notional/mx2*pw*0.6, y=Y(r.bucket_px); g.fillStyle='rgba(255,159,67,0.7)'; g.fillRect(L,y-1.5,w,3);});
  const bl=R2.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0), bs=R2.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
  extra=` · Binance eingetreten 24 h (orange): Longs ${fmt(bl)}, Shorts ${fmt(bs)}`;
 }
 $('depthinfo').textContent=(d.realized?`Eingetretene Liquidationen (Binance, ${d.hours||24} h): ${rows.length} Preisstufen · Longs liquidiert ${fmt(dn)} USD · Shorts liquidiert ${fmt(up)} USD · Stand ${hm(d.ts)}`
  :`${rows.length} Cluster · über dem Kurs ${fmt(up)} USD · darunter ${fmt(dn)} USD · Stand ${hm(d.ts)}`)+extra;
}

function drawMetrics(m){
 const box=$('bncmetrics'); if(!box) return; if(!m||!m.series){ box.style.display='none'; return; }
 box.style.display='block';
 const c=$('metricschart'); const [g,W,H]=fit(c); g.clearRect(0,0,W,H); if(!W) return;
 const L=56,R=56,T=12,B=24, pw=W-L-R, ph=H-T-B;
 const S=m.series; const keys=[['oi_notional','#58a6ff'],['global_ls_account','#d29922'],['top_ls_position','#c678dd'],['taker_ls','#3ba55d']];
 const all=keys.flatMap(([k])=>S[k]||[]); if(!all.length){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText('noch keine Binance-Kennzahlen — kommen mit hl_binance (Backfill und alle 10 min)',12,24); return; }
 const t0=Math.min(...all.map(p=>p[0])), t1=Math.max(...all.map(p=>p[0])), X=t=>L+(t-t0)/Math.max(1,t1-t0)*pw;
 // OI links (absolut), Verhältnisse rechts (gemeinsame Skala um 1)
 const oi=S.oi_notional||[]; const ratios=keys.slice(1).flatMap(([k])=>S[k]||[]).map(p=>p[1]);
 const rlo=Math.min(0.5,...ratios), rhi=Math.max(1.5,...ratios);
 const Yr=v=>T+(rhi-v)/(rhi-rlo)*ph;
 g.strokeStyle='#161b22'; for(let k=0;k<=4;k++){const y=T+ph*k/4; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 g.strokeStyle='#30363d'; g.setLineDash([3,3]); g.beginPath(); g.moveTo(L,Yr(1)); g.lineTo(W-R,Yr(1)); g.stroke(); g.setLineDash([]);
 if(oi.length){ const lo=Math.min(...oi.map(p=>p[1])), hi=Math.max(...oi.map(p=>p[1])); const Yo=v=>T+(hi-v)/Math.max(1e-9,hi-lo)*ph;
  g.strokeStyle='#58a6ff'; g.lineWidth=1.6; g.beginPath(); oi.forEach((p,i)=>i?g.lineTo(X(p[0]),Yo(p[1])):g.moveTo(X(p[0]),Yo(p[1]))); g.stroke();
  g.fillStyle='#58a6ff'; g.font='10px system-ui'; g.textAlign='right'; g.fillText(fmt(hi),L-4,T+8); g.fillText(fmt(lo),L-4,H-B); g.textAlign='left'; }
 keys.slice(1).forEach(([k,col])=>{ const ser=S[k]||[]; if(!ser.length) return; g.strokeStyle=col; g.lineWidth=1.4; g.beginPath();
  ser.forEach((p,i)=>i?g.lineTo(X(p[0]),Yr(p[1])):g.moveTo(X(p[0]),Yr(p[1]))); g.stroke(); });
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='left';
 [rhi,1,rlo].forEach(v=>g.fillText(v.toFixed(2),W-R+4,Yr(v)+3));
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(t0),L,H-8); g.textAlign='right'; g.fillText(hm(t1),W-R,H-8); g.textAlign='left';
 const l=m.latest||{};
 $('metricsinfo').innerHTML=`Binance-Kennzahlen · Open Interest ${l.oi_notional?fmt(l.oi_notional)+' USD':'—'} · L/S Konten ${l.global_ls_account?(+l.global_ls_account).toFixed(2):'—'} `
  +`· L/S Top-Trader ${l.top_ls_position?(+l.top_ls_position).toFixed(2):'—'} · Taker ${l.taker_ls?(+l.taker_ls).toFixed(2):'—'} — Verhältnisse rechts skaliert, 1,00 = ausgeglichen (gestrichelt)`
  +(LAST_CHART&&LAST_CHART.cdc?` · Crypto.com: OI ${fmt(LAST_CHART.cdc.oi_usd||0)} USD, Taker ${LAST_CHART.cdc.taker_ls!=null?(+LAST_CHART.cdc.taker_ls).toFixed(2):'—'}, Prämie ${LAST_CHART.cdc.premium!=null?(LAST_CHART.cdc.premium*100).toFixed(3)+' %':'—'}`:'')
  +` · <a class="lbl-links" style="cursor:pointer" onclick="exportChart('metricschart')">⤓ PNG</a>`;
}

function drawWhales(d){
 const [g,W,H]=fit($('whalechart')); g.clearRect(0,0,W,H);
 const E=d.exposure||[], P=d.price||[], coin=$('coin').value;
 const C=d.current||[];
 if(!E.length){g.fillStyle='#8b949e';g.font='12px system-ui';
  g.fillText(C.length
   ? `Zeitreihe für ${coin} entsteht mit den nächsten Snapshots — die Tabelle unten ist schon gefüllt`
   : 'noch keine Wal-Positionen erfasst — Wale ab 20 Mio. USD erscheinen hier, sobald der Recorder sie findet',12,24);
  drawWhaleTable(d); return;}
 const L=8,R=64,T=10,B=24, pw=W-L-R, ph=H-T-B;
 const t0=E[0].ts, t1=E[E.length-1].ts;
 const X=t=>L+(t-t0)/(t1-t0+1)*pw;
 const mxE=Math.max(...E.map(e=>Math.max(e.long_usd,e.short_usd)),1);
 const Ye=v=>T+ph/2-v/mxE*(ph/2-4);
 // Exposure als gespiegelte Flaechen um die Mittellinie
 g.fillStyle='rgba(59,165,93,.55)'; g.beginPath(); g.moveTo(X(t0),Ye(0));
 E.forEach(e=>g.lineTo(X(e.ts),Ye(e.long_usd))); g.lineTo(X(t1),Ye(0)); g.fill();
 g.fillStyle='rgba(224,75,75,.55)'; g.beginPath(); g.moveTo(X(t0),Ye(0));
 E.forEach(e=>g.lineTo(X(e.ts),Ye(-e.short_usd))); g.lineTo(X(t1),Ye(0)); g.fill();
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(L,Ye(0)); g.lineTo(W-R,Ye(0)); g.stroke();
 // Kurs auf eigener Skala rechts
 if(P.length){const pv=P.map(p=>p[1]), plo=Math.min(...pv), phi=Math.max(...pv);
  const Yp=p=>T+(phi-p)/(phi-plo||1)*ph;
  g.strokeStyle='#fff';g.lineWidth=1.3;g.beginPath();
  P.forEach((p,i)=>{const x=X(p[0]),y=Yp(p[1]); if(x<L||x>W-R)return; i?g.lineTo(x,y):g.moveTo(x,y)});
  g.stroke();
  g.fillStyle='#8b949e';g.font='9px system-ui';
  g.fillText(px(phi),W-R+3,T+9); g.fillText(px(plo),W-R+3,T+ph);
  // Ereignismarker
  (d.events||[]).forEach(ev=>{const x=X(ev.ts); if(x<L||x>W-R)return;
   const up=ev.event==='open'||ev.event==='add'||(ev.event==='flip');
   const near=P.reduce((a,b)=>Math.abs(b[0]-ev.ts)<Math.abs(a[0]-ev.ts)?b:a);
   const y=Yp(near[1]);
   g.fillStyle=ev.side==='long'?'#3ba55d':'#e04b4b';
   g.beginPath(); if(up){g.moveTo(x,y-9);g.lineTo(x-5,y-1);g.lineTo(x+5,y-1);}
   else{g.moveTo(x,y+9);g.lineTo(x-5,y+1);g.lineTo(x+5,y+1);} g.fill();});}
 g.fillStyle='#8b949e';g.font='9px system-ui';
 g.fillText('+'+fmt(mxE),L+2,T+9); g.fillText('-'+fmt(mxE),L+2,T+ph-2);
 g.fillStyle='#6e7681'; g.fillText(hm(t0),L,H-8); g.fillText(hm(t1),W-R-60,H-8);
 drawWhaleTable(d);
}

let LABELS={}, LABELS_AT=0, LB_TABLE_KEY='', LBACT_KEY='', LAST_CASCADE=null;
async function loadLabels(addrs){
 if(!addrs.length) return;
 try{ const r=await getJSON('/labels?addrs='+addrs.slice(0,200).join(',')); LABELS=Object.assign(LABELS,r); LABELS_AT=Date.now();
  if(LAST_WHALES) drawWhaleTable(LAST_WHALES, true); }catch(e){}
}
let WH_TABLE_KEY='';
function drawWhaleTable(d, force){
 const C=d.current||[], coin=$('coin').value;
 const need=[...new Set(C.map(w=>w.addr.toLowerCase()))].filter(a=>!LABELS[a]||LABELS[a].pending);
 if(need.length&&Date.now()-LABELS_AT>15000){ LABELS_AT=Date.now(); loadLabels(need); }
 // nur neu bauen, wenn sich der Stand geändert hat -- sonst springt die Seite beim Lesen
 const key=coin+'|'+C.length+'|'+Math.max(0,...C.map(w=>w.ts||0))+'|'+Object.keys(LABELS).length+'|'+Object.values(LABELS).filter(l=>l&&l.name).length;
 if(!force&&key===WH_TABLE_KEY) return; WH_TABLE_KEY=key;
 const short=a=>a.slice(0,6)+'…'+a.slice(-4);
 const age=s=>{const h=(Date.now()/1000-s)/3600; return h<1?Math.round(h*60)+' min':h<48?h.toFixed(1)+' h':(h/24).toFixed(1)+' T';};
 // Nach Wallet gruppiert: alle Positionen einer Adresse als Block, Wallets nach Gesamtwert,
 // innerhalb des Blocks nach Positionswert. Der Blockkopf nennt Summe und Netto-Ausrichtung.
 const groups=new Map();
 C.forEach(w=>{ const g=groups.get(w.addr)||{addr:w.addr,rows:[],total:0,long:0,short:0,upnl:0};
   g.rows.push(w); g.total+=w.pos_value||0; g.upnl+=w.upnl||0; if(w.side==='long') g.long+=w.pos_value||0; else g.short+=w.pos_value||0; groups.set(w.addr,g); });
 const ordered=[...groups.values()].sort((a,b)=>b.total-a.total);
 ordered.forEach(g=>g.rows.sort((a,b)=>(b.pos_value||0)-(a.pos_value||0)));
 const head=g=>{ const net=g.long-g.short, col=net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9';
   const L=(LABELS||{})[g.addr.toLowerCase()]||{};
   const name=L.name?`<span class="lbl-name" title="${esc(L.source||'')}">${esc(L.name)}</span>`:(L.pending?'<span class="lbl-dim">Zuordnung läuft …</span>':'<span class="lbl-dim">unbekannt</span>');
   const beh=L.behavior?` <span class="lbl-beh" title="Verhaltensklasse aus den eigenen Daten">${esc(L.behavior)}</span>`:'';
   const links=L.links?` <span class="lbl-links"><a href="${esc(L.links.hypurrscan)}" target="_blank" rel="noopener">HypurrScan</a> · <a href="${esc(L.links.arbiscan)}" target="_blank" rel="noopener">Arbiscan</a> · <a href="${L.links.arkham}" target="_blank" rel="noopener">Arkham</a></span>`:'';
   return `<tr class="grp"><td class="mono" colspan="3"><b>${hsLink(g.addr, short(g.addr))}</b> · ${g.rows.length} Position${g.rows.length>1?'en':''}<br>${name}${beh}${links}</td>`
    +`<td class="n"><b>${fmt(g.total)}</b></td><td colspan="4" style="color:${col}">netto ${net>0?'long':net<0?'short':'neutral'} ${fmt(Math.abs(net))}</td>`
    +`<td class="n" style="color:${g.upnl>=0?'#3ba55d':'#e04b4b'}">${g.upnl>=0?'+':''}${fmt(g.upnl)}</td><td colspan="2"></td></tr>`; };
 $('whaletable').innerHTML=C.length?`<table class="w"><tr>
  <th>Wallet</th><th>Coin</th><th>Seite</th><th class="n">Wert</th><th class="n">Hebel</th>
  <th class="n">Einstieg</th><th class="n">Liq.-Preis</th><th class="n">Abstand</th>
  <th class="n">unreal. PnL</th><th>offen seit</th><th>Stand</th></tr>`
  +ordered.map(g=>head(g)+g.rows.map(w=>{const dist=w.mark_px?(w.liq_px-w.mark_px)/w.mark_px*100:0;
   const dc=Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':'#c9d1d9';
   const hl=w.coin===coin?' style="background:#161b22"':'';
   return `<tr${hl}><td class="mono" style="color:#6e7681;padding-left:18px">${g.rows.length>1?'└':''} ${hsLink(w.addr, short(w.addr))}</td>
    <td><b>${w.coin}</b></td>
    <td style="color:${w.side==='long'?'#3ba55d':'#e04b4b'}">${w.side}</td>
    <td class="n"><b>${fmt(w.pos_value)}</b></td><td class="n">${(+w.leverage).toFixed(0)}x</td>
    <td class="n">${px(w.entry_px)}</td><td class="n">${px(w.liq_px)}</td>
    <td class="n" style="color:${dc}">${dist>0?'+':''}${dist.toFixed(1)} %</td>
    <td class="n" style="color:${w.upnl>=0?'#3ba55d':'#e04b4b'}">${w.upnl>=0?'+':''}${fmt(w.upnl)}</td>
    <td>${w.opened_at?age(w.opened_at):'—'}</td><td class="mono">${age(w.ts)} alt</td></tr>`}).join('')).join('')
  +'</table>':'<div class="sub">Aktuell keine offene Position über der Schwelle.</div>';
 const other=C.filter(w=>w.coin!==coin).length;
 if(C.length&&!C.some(w=>w.coin===coin))
  $('whaletable').innerHTML=`<div class="sub" style="margin-bottom:6px">Kein Wal in ${coin} — `
   +`die ${other} unten halten ihre großen Positionen in anderen Coins.</div>`+$('whaletable').innerHTML;

 const ev=(d.events||[]).slice(-12).reverse();
 const name={open:'eröffnet',add:'stockt auf',reduce:'reduziert',close:'schließt',flip:'dreht auf'};
 const PC=(d.flow&&d.flow.per_coin)||{}, NM=(d.flow&&d.flow.group_names)||{};
 const grp=a=>(PC[a.toLowerCase()]||'dir');
 const cls=a=>NM[grp(a)]||((LABELS||{})[a.toLowerCase()]||{}).behavior||'';
 const isDir=a=>grp(a)==='dir';
 const GCOL={dir:null, hedge:'#8b949e', mm:'#8b949e', mixed:'#c9a227'};
 const F=d.flow||{}; const w=F.w30||{}, w60=F.w60||{};
 $('whaleevents').innerHTML=(F.w30?`<div class="sub" style="margin:0 0 6px"><b>Wal-Flow live</b> (nur direktionale Wale): 30 min <span style="color:${w.net_usd>0?'#3ba55d':w.net_usd<0?'#e04b4b':'#c9d1d9'}">${w.net_usd>=0?'+':'−'}${fmt(Math.abs(w.net_usd||0))}</span> (${w.n_buy||0} kaufen / ${w.n_sell||0} verkaufen) · 60 min <span style="color:${w60.net_usd>0?'#3ba55d':w60.net_usd<0?'#e04b4b':'#c9d1d9'}">${w60.net_usd>=0?'+':'−'}${fmt(Math.abs(w60.net_usd||0))}</span> (${w60.n_buy||0}/${w60.n_sell||0})${F.z30!=null?' · Z '+F.z30.toFixed(1):''}${F.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''} — jede Änderung eines direktionalen Wals löst binnen 30 s eine neue Prognose aus</div>`:'')
  +(ev.length?'<b>Letzte Änderungen:</b> <span class="lbl-dim">(Klasse je Coin — jede Gruppe wird eigenständig ausgewertet)</span><br>'+ev.map(e=>{ const g=grp(e.addr), dir=g==='dir', c=cls(e.addr), dim=GCOL[g];
   return `<span style="${dim?'color:'+dim:''}">${hm(e.ts)} · <span class="mono">${hsLink(e.addr, short(e.addr))}</span> ${name[e.event]||e.event} `
  +`<span style="color:${dir?(e.side==='long'?'#3ba55d':'#e04b4b'):(dim||'#6e7681')}">${e.side}</span> `
  +`${e.delta_usd>=0?'+':''}${fmt(e.delta_usd)} USD bei ${px(e.mark_px)}${c?` <span class="lbl-beh">${c.split(' (')[0]}</span>`:''}</span>`; }).join('<br>')
  :'noch keine Änderungen im Zeitraum');
}

// ---- Tooltip -------------------------------------------------------------
function showTip(ev, title, rows){
 const t=$('tip');
 t.innerHTML=`<div class="t">${title}</div>`+rows.map(
  r=>`<div class="r"><i>${r[0]}</i><b style="color:${r[2]||'#c9d1d9'}">${r[1]}</b></div>`).join('');
 t.style.display='block';
 const w=t.offsetWidth,h=t.offsetHeight;
 let x=ev.clientX+14, y=ev.clientY-h-10;
 if(x+w>innerWidth-8) x=ev.clientX-w-14;
 if(y<8) y=ev.clientY+18;
 // auf schmalen Bildschirmen: nie über den Rand hinaus, unter dem Finger platzieren
 x=Math.max(6, Math.min(x, innerWidth-w-6));
 if(innerWidth<700){ y=ev.clientY+24; if(y+h>innerHeight-8) y=ev.clientY-h-24; }
 t.style.left=x+'px'; t.style.top=y+'px';
}
function hideTip(){ $('tip').style.display='none'; }

function pos(ev,c){const r=c.getBoundingClientRect();
 return {x:ev.clientX-r.left, y:ev.clientY-r.top};}

function tipHeat(ev){
 const G=GEO.heat; if(!G) return hideTip();
 const {x,y}=pos(ev,$('heat'));
 if(x<G.L||x>G.L+G.pw||y<G.T||y>G.T+G.ph) return hideTip();
 if(LAST){ drawHeat(LAST); crosshair($('heat'),G,x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const d=G.d;
 const t=G.t0+(x-G.L)/G.pw*(G.t1-G.t0);
 let j=0,best=1e18; d.times.forEach((tt,k)=>{const e=Math.abs(tt-t);if(e<best){best=e;j=k}});
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 let i=0,bp=1e18; d.levels.forEach((lv,k)=>{const e=Math.abs(lv-p);if(e<bp){bp=e;i=k}});
 const v=d.grid[i][j], side=d.sides[i]?d.sides[i][j]:'';
 const pr=d.price.reduce((a,b)=>Math.abs(b[0]-t)<Math.abs(a[0]-t)?b:a);
 const rows=[['Zeit',hm(d.times[j])],['Preisniveau',px(d.levels[i])+' USD'],
             ['Kurs damals',px(pr[1])+' USD']];
 if(v>0){
  rows.push(['Notional',fmt(v)+' USD']);
  if(G.sc) rows.push(['Rang',(G.sc.pct(v)*100).toFixed(0)+'. Perzentil']);
  if(side) rows.push(['Art', side==='long'?'Long-Liquidationen':'Short-Liquidationen',
                      side==='long'?'#e04b4b':'#3ba55d']);
 } else rows.push(['Notional','kein Cluster','#6e7681']);
 showTip(ev,'Heatmap',rows);
}

function tipChart(ev){
 const G=GEO.chart; if(!G) return hideTip();
 const {x,y}=pos(ev,$('chart'));
 if(x<G.Lm||x>G.Lm+G.pw||y<G.T||y>G.T+G.ph) return hideTip();
 if(LAST_CHART){ drawChart(LAST_CHART); crosshair($('chart'),{L:G.Lm,R:G.R,T:G.T,B:G.B,W:G.W,H:G.H},x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const i=Math.max(0,Math.min(G.C.length-1,Math.floor((x-G.Lm)/G.cw)));
 const c=G.C[i];
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 const rows=[['Eröffnung',px(c.o)],['Hoch',px(c.h)],['Tief',px(c.l)],
             ['Schluss',px(c.c),c.c>=c.o?'#3ba55d':'#e04b4b'],
             ['Volumen',fmt(c.v)]];
 const near=G.L.filter(l=>Math.abs(l.px-p)/p<0.004)
             .sort((a,b)=>Math.abs(a.px-p)-Math.abs(b.px-p))[0];
 if(near) rows.push(['Marke '+px(near.px),fmt(near.notional)+' USD · '
   +near.x_vol.toFixed(2)+'x Vol', near.side==='long'?'#e04b4b':'#3ba55d']);
 const inGap=(G.FV||[]).filter(f=>p>=f.bot&&p<=f.top&&i>=f.i&&(f.fill_i==null||i<=f.fill_i))[0];
 if(inGap) rows.push(['FVG '+(inGap.kind==='bull'?'bullisch':'bärisch'),
   px(inGap.bot)+'–'+px(inGap.top)+' · '+(inGap.size_pct*100).toFixed(2)+' % · '
   +(inGap.fill_i==null?(inGap.fill_pct*100).toFixed(0)+' % gefüllt, offen':'gefüllt'),
   inGap.kind==='bull'?'#39ff14':'#e04b4b']);
 showTip(ev,tlabel(c.t)+(LAST_CHART&&LAST_CHART.agg>=1440?'':''),rows);
}

function tipDepth(ev){
 const G=GEO.depth; if(!G) return hideTip();
 const {x,y}=pos(ev,$('depth'));
 if(y<G.T||y>G.T+G.ph) return hideTip();
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 if(LAST){ drawDepth(LAST_DEPTH||{rows:G.rows,price:G.p0,vol_1h:G.vol}); crosshair($('depth'),G,x,y,p); }
 const r=G.rows.reduce((a,b)=>Math.abs(b.bucket_px-p)<Math.abs(a.bucket_px-p)?b:a);
 const dist=(r.bucket_px-G.p0)/G.p0;
 showTip(ev,'Cluster bei '+px(r.bucket_px)+' USD',[
  ['Notional',fmt(r.notional)+' USD'],
  ['Positionen',r.n_pos],
  ['Abstand zum Kurs',(dist*100).toFixed(2)+' %'],
  ['Anteil Stundenvol.',G.vol?(r.notional/G.vol).toFixed(2)+'x':'—'],
  ['Art',r.side==='long'?'Long-Liquidationen':'Short-Liquidationen',
   r.side==='long'?'#e04b4b':'#3ba55d']]);
}

for(const [id,fn] of [['heat',tipHeat],['chart',tipChart],['depth',tipDepth],['stops',tipStops]]){
 const c=$(id);
 c.addEventListener('mousemove',fn);
 const redraw=()=>{ if(LAST_CHART){ if(c.id==='stops') drawStops(LAST_CHART); if(c.id==='chart') drawChart(LAST_CHART); }
  if(LAST&&c.id==='heat') drawHeat(LAST); if(LAST_DEPTH&&c.id==='depth') drawDepth(LAST_DEPTH); };
 c.addEventListener('mouseleave',()=>{hideTip(); redraw();});
 c.addEventListener('click',fn);
 c.addEventListener('touchstart',e=>{e.preventDefault();fn(e.touches[0]);},{passive:false});
 c.addEventListener('touchmove',e=>{e.preventDefault();fn(e.touches[0]);},{passive:false});
 c.addEventListener('touchend',()=>setTimeout(()=>{hideTip(); redraw();},2500));
}

async function loadChart(){
 const coin=$('coin').value, [agg,mins]=$('tf').value.split('|');
 const fvg=$('fvg')?$('fvg').value:'0.0005';
 try{LAST_CHART=await getJSON(`/chart?coin=${coin}&agg=${agg}&minutes=${mins}&fvg=${fvg}&src=${SRC()}`);
  if(LAST_DATA) renderKpi();
  { const k=(LAST_CHART.lb_act?LAST_CHART.lb_act.last_fill:0)+'|'+coin; if(k!==LBACT_KEY){ LBACT_KEY=k; drawLbActivity(LAST_CHART.lb_act); drawLbAct48(LAST_CHART.lb_act48); } }
  if(LAST_SYS&&!LAST_SYS._thermalDrawn){ LAST_SYS._thermalDrawn=true; drawSystem(LAST_SYS); }
  if(LAST_CHART.lb){ drawLbChart(LAST_CHART.lb);
   const key=(LAST_CHART.lb.ts||0)+'|'+coin+'|'+(LAST_CHART.lb.accounts||[]).length;   // Tabelle nur bei neuem Stand neu bauen (sonst springt die Seite)
   if(key!==LB_TABLE_KEY){ LB_TABLE_KEY=key; drawLbTable(LAST_CHART.lb); } }
  computeSignal();
  drawChart(LAST_CHART);
  drawStops(LAST_CHART);
  fillIndicators(LAST_CHART);
 }catch(e){ console.error('Chart:', e);
  showErr('Chart: '+(e&&e.message||e)); }
}
function renderKpi(){
 const d=LAST_DATA; if(!d) return;
 const dp=d.depth||{rows:[]};
 const up=dp.rows.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
 const dn=dp.rows.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0);
 const B=(LAST_CHART&&LAST_CHART.bnc)||{}, M=B.metrics||{}, src=SRC(), CD=(LAST_CHART&&LAST_CHART.cdc)||null;
 const cdcTiles=CD?ratioTile('Taker Kauf/Verkauf Crypto.com (Verhältnis)', CD.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', `Volumen der Market-Käufe geteilt durch Market-Verkäufe aus den letzten ${CD.taker_n||0} Trades (${Math.round(CD.taker_span_s||0)} s) auf Crypto.com`)
  +`<div title="Open Interest auf Crypto.com: ${(CD.oi||0).toFixed(1)} ${$('coin').value} × Kurs; darunter die Prämie des Perpetuals gegen den Index (Funding-Näherung)"><span>Open Interest Crypto.com (USD)</span><b>${fmt(CD.oi_usd||0)}<span class="d">Prämie ${CD.premium!=null?(CD.premium*100).toFixed(3)+' %':'—'} · 24 h ${fmt(CD.vol_24h_usd||0)}</span></b></div>`
  :`<div title="Crypto.com derzeit nicht abrufbar oder Coin dort nicht gehandelt"><span>Crypto.com</span><b>—</b></div>`;
 const D={
  liqAbove:'Summe des Notionals (USD) aller Short-Positionen, die laut Positionsdaten über dem aktuellen Kurs liquidiert würden — eine Erwartung, kein Ereignis.',
  liqBelow:'Summe des Notionals (USD) aller Long-Positionen, die unter dem aktuellen Kurs liquidiert würden — Erwartung.',
  liqL:'USD-Notional der in der letzten Stunde auf Binance zwangsliquidierten LONG-Positionen (Verkaufs-Fills).',
  liqS:'USD-Notional der in der letzten Stunde auf Binance zwangsliquidierten SHORT-Positionen (Kauf-Fills).',
  oi:'Open Interest: Gesamtwert aller offenen Perpetual-Positionen auf Binance in USD (sumOpenInterestValue).',
  lsAcc:'Zahl der Konten mit Netto-Long geteilt durch Zahl der Konten mit Netto-Short, alle Binance-Konten (globalLongShortAccountRatio). 1,00 : 1 = ausgeglichen.',
  lsTop:'Positionsgröße long geteilt durch Positionsgröße short der größten Binance-Konten (topLongShortPositionRatio). Gewichtet nach USD, nicht nach Kontenzahl.',
  taker:'Volumen der aggressiven Market-Käufe geteilt durch Volumen der Market-Verkäufe (takerlongshortRatio, 5-min-Fenster). Über 1: Käufer nehmen Liquidität.',
  vol:'Gehandeltes Volumen der letzten Stunde in USD (Kerzenvolumen × Preis).',
  addr:'Anzahl der Hyperliquid-Adressen, die der Recorder aus den Trade-Feeds gesammelt hat.',
  pos:'Anzahl dieser Adressen mit mindestens einer offenen Perpetual-Position (nach der letzten Abfrage).',
 };
 const liqTiles=src==='hl'?`
  <div title="${D.liqAbove}"><span>Short-Liqs darüber (USD)</span><b style="color:#3ba55d">${fmt(up)}</b></div>
  <div title="${D.liqBelow}"><span>Long-Liqs darunter (USD)</span><b style="color:#e04b4b">${fmt(dn)}</b></div>`
  :src==='bnc'?`
  <div title="${D.liqL}"><span>Long-Liquidationen 1 h (Binance, USD)</span><b style="color:#e04b4b">${fmt((B.liqs_1h||{}).long||0)}</b></div>
  <div title="${D.liqS}"><span>Short-Liquidationen 1 h (Binance, USD)</span><b style="color:#3ba55d">${fmt((B.liqs_1h||{}).short||0)}</b></div>
  <div title="${D.oi}"><span>Open Interest (Binance, USD)</span><b>${M.oi_notional?fmt(M.oi_notional):'—'}</b></div>`
  +ratioTile('Long/Short Konten (Verhältnis)', M.global_ls_account, 'der Konten long', 'short', D.lsAcc)
  +ratioTile('Long/Short Top-Trader (Verhältnis)', M.top_ls_position, 'des Positionswerts long', 'short', D.lsTop)
  +ratioTile('Taker Kauf/Verkauf Binance (Verhältnis)', M.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', D.taker)+cdcTiles
  :`
  <div title="${D.liqAbove}"><span>Short-Liqs darüber (HL erwartet, USD)</span><b style="color:#3ba55d">${fmt(up)}</b></div>
  <div title="${D.liqBelow}"><span>Long-Liqs darunter (HL erwartet, USD)</span><b style="color:#e04b4b">${fmt(dn)}</b></div>
  <div title="${D.liqL} + ${D.liqS}"><span>Liquidationen 1 h (Binance, Long + Short, USD)</span><b>${fmt(((B.liqs_1h||{}).long||0)+((B.liqs_1h||{}).short||0))}</b></div>
  <div title="${D.oi}"><span>Open Interest (Binance, USD)</span><b>${M.oi_notional?fmt(M.oi_notional):'—'}</b></div>`
  +ratioTile('Taker Kauf/Verkauf Binance (Verhältnis)', M.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', D.taker)+cdcTiles;
 const vol=src==='fusion'?((dp.vol_1h||0)+(B.vol_1h||0)+((CD&&CD.vol_1h)||0)):src==='bnc'?(B.vol_1h||dp.vol_1h||0):(dp.vol_1h||0);
 // Börsenübergreifende Kacheln (Binance-Modus und Fusion): OI, Taker, Long/Short-Konten, Funding
 const BY=(LAST_CHART&&LAST_CHART.bybit)||null, OK=(LAST_CHART&&LAST_CHART.okx)||null;
 let exTiles='';
 if(src!=='hl'){
  const ex=[['Binance',{oi:M.oi_notional,taker:M.taker_ls,ls:M.global_ls_account,fund:B.funding,vol:B.vol_1h}],['Bybit',BY&&{oi:BY.oi_usd,taker:BY.taker_ls,ls:BY.ls_account,fund:BY.funding,vol:BY.vol_1h}],
            ['OKX',OK&&{oi:OK.oi_usd,taker:OK.taker_ls,ls:OK.ls_account,fund:OK.funding,vol:OK.vol_1h}],['Crypto.com',CD&&{oi:CD.oi_usd,taker:CD.taker_ls,ls:null,fund:CD.premium!=null?CD.premium/8:null,vol:CD.vol_1h}]].filter(e=>e[1]);
  const oiSum=ex.reduce((a,e)=>a+(e[1].oi||0),0), oiTxt=ex.filter(e=>e[1].oi).map(e=>`${e[0]} ${fmt(e[1].oi)}`).join(' · ');
  const spanOf={Bybit:BY&&BY.taker_span_s,'Crypto.com':CD&&CD.taker_span_s};
  const tk=ex.filter(e=>e[1].taker!=null&&e[1].taker<9&&(spanOf[e[0]]==null||spanOf[e[0]]>=60)), wsum=tk.reduce((a,e)=>a+Math.max(e[1].vol||0,1),0), tkAvg=tk.length?tk.reduce((a,e)=>a+e[1].taker*Math.max(e[1].vol||0,1),0)/wsum:null;
  const ls=ex.filter(e=>e[1].ls!=null), fu=ex.filter(e=>e[1].fund!=null), fuAvg=fu.length?fu.reduce((a,e)=>a+e[1].fund,0)/fu.length:null;
  exTiles=`<div title="Summe des Open Interest der erreichbaren Börsen in USD: ${oiTxt}"><span>Open Interest ${ex.filter(e=>e[1].oi).length} Börsen (USD)</span><b>${fmt(oiSum)}<span class="d">${oiTxt}</span></b></div>`
   +(tkAvg!=null?`<div title="Taker Kauf/Verkauf nach Stundenvolumen gewichtet über ${tk.map(e=>e[0]).join(', ')} — über 1: aggressive Käufer überwiegen"><span>Taker börsenübergreifend (Verhältnis)</span><b style="color:${tkAvg>1.15?'#3ba55d':tkAvg<0.87?'#e04b4b':'#c9d1d9'}">${tkAvg.toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2})} : 1<span class="d">${ex.filter(e=>e[1].taker!=null&&e[1].taker<9).map(e=>`${e[0]} ${(+e[1].taker).toFixed(2)}${spanOf[e[0]]!=null&&spanOf[e[0]]<60?' (nur '+Math.round(spanOf[e[0]])+' s, nicht gewertet)':''}`).join(' · ')}</span></b></div>`:'')
   +(ls.length?`<div title="Verhältnis Long- zu Short-Konten je Börse (Binance global, Bybit, OKX); über 1 = mehr Konten long"><span>Long/Short Konten je Börse</span><b>${ls.map(e=>`${e[0]} ${(+e[1].ls).toFixed(2)}`).join(' · ')}</b></div>`:'')
   +(fuAvg!=null?`<div title="Funding je Stunde (Binance, Bybit, OKX aus 8-h-Sätzen; Crypto.com aus der Prämie); Durchschnitt und Einzelwerte in % pro Stunde"><span>Funding Ø Börsen (%/h)</span><b style="color:${fuAvg>0.0001?'#e04b4b':fuAvg<-0.00005?'#3ba55d':'#c9d1d9'}">${(fuAvg*100).toFixed(4)} %<span class="d">${fu.map(e=>`${e[0]} ${(e[1].fund*100).toFixed(4)}`).join(' · ')}</span></b></div>`:'');
 }
 // ETF-Flows und Smart Money in jeder Quelle
 const E=(LAST_CHART&&LAST_CHART.etf)||null, SMd=(LAST_CHART&&LAST_CHART.smart)||null;
 const etfTile=(['BTC','ETH'].includes($('coin').value))?(E?`<div title="Tägliche Netto-Zu-/Abflüsse der US-Spot-ETFs in Mio USD (Quelle ${E.source}); Serie = Tage in Folge mit gleichem Vorzeichen"><span>ETF-Flows ${$('coin').value} (Mio USD/Tag)</span><b style="color:${E.last>0?'#3ba55d':E.last<0?'#e04b4b':'#c9d1d9'}">${E.last>0?'+':''}${E.last.toFixed(1)}<span class="d">${E.last_date} · 5 Tage ${E.sum5>0?'+':''}${E.sum5.toFixed(0)} Mio · Serie ${Math.abs(E.streak)} Tag${Math.abs(E.streak)!==1?'e':''} ${E.streak>0?'Zufluss':E.streak<0?'Abfluss':''}</span></b></div>`
   :`<div title="ETF-Flows werden geladen (Farside, einmal pro Stunde)"><span>ETF-Flows ${$('coin').value}</span><b>lädt …</b></div>`):'';
 const smTile=SMd?(()=>{ const c=SMd.coin, a=SMd.all, use=(c.n_long+c.n_short)>=5?c:a, scope=(c.n_long+c.n_short)>=5?$('coin').value:'alle Coins';
   const tot=use.usd_long+use.usd_short, pl=tot?use.usd_long/tot*100:0;
   return `<div title="Die ${SMd.n_accounts} Konten mit dem höchsten 30-Tage-PnL im Hyperliquid-Leaderboard (Kontowert ab 500k): Netto-Ausrichtung ihrer Positionen je Konto, ${scope}; Positionen vom Recorder alle 10 min abgefragt"><span>Smart Money HL Top ${SMd.n_accounts} (${scope}, USD)</span><b><span style="color:#3ba55d">${use.n_long} LONG ${fmt(use.usd_long)} [${pl.toFixed(0)} %]</span> <span style="color:#8b949e">vs.</span> <span style="color:#e04b4b">${use.n_short} SHORT ${fmt(use.usd_short)} [${(100-pl).toFixed(0)} %]</span><span class="d">Konten mit den besten 30-Tage-Ergebnissen · Stand ${hm(SMd.ts)}</span></b></div>`; })()
  :`<div title="Smart Money kommt vom Recorder (Leaderboard alle 10 min); bis zur ersten Abfrage leer"><span>Smart Money HL Top 50</span><b>lädt …</b></div>`;
 $('kpi').innerHTML=`
  <div title="Letzter Handelspreis in USD${src==='bnc'?' (Binance-Kerze)':' (Hyperliquid-Trade-Feed)'}"><span>Kurs${src==='bnc'?' (Binance)':''} (USD)</span><b>${dp.price?px(dp.price):'—'}</b></div>`+liqTiles+`
  <div title="${D.vol}${src==='fusion'&&LAST_CHART&&LAST_CHART.vol_split?` — HL ${fmt(LAST_CHART.vol_split.hl||0)}, Binance ${fmt(LAST_CHART.vol_split.bnc||0)}, Crypto.com ${fmt(LAST_CHART.vol_split.cdc||0)}`:''}"><span>Volumen 1 h${src==='fusion'?' (HL + Binance + Crypto.com)':src==='bnc'?' (Binance)':''} (USD)</span><b>${fmt(vol)}</b></div>`+exTiles+etfTile+smTile
  +(src!=='bnc'?`
  <div title="${D.addr}"><span>Adressen erfasst (Anzahl)</span><b>${d.stats.addresses.toLocaleString('de-DE')}</b></div>
  <div title="${D.pos}"><span>mit offener Position (Anzahl)</span><b>${d.stats.positions.toLocaleString('de-DE')}</b></div>`:'')+`
  <div title="Kursänderung der letzten 60 Minuten in Prozent (Schluss jetzt gegen Schluss vor 60 Minutenkerzen)"><span>60-Minuten-Trend (%)</span><b id="kpi_trend">—</b></div>
  <div title="Relative-Stärke-Index nach Wilder über 14 Kerzen des gewählten Rasters, Skala 0–100: unter 30 überverkauft, über 70 überkauft"><span id="kpi_rsi_lbl">RSI 14</span><b id="kpi_rsi">—</b></div>
  <div title="Gleitender Durchschnitt der Wochenschlusskurse über 50 Wochen (USD); darunter der Abstand des Kurses in Prozent — ▲ Kurs darüber, ▼ Kurs darunter"><span>MA 50 Wochen (USD · Abstand %)</span><b id="kpi_ma50w">—</b></div>
  <div title="Gleitender Durchschnitt der Tagesschlusskurse über 200 Tage (USD); darunter der Abstand des Kurses in Prozent"><span>MA 200 Tage (USD · Abstand %)</span><b id="kpi_ma200d">—</b></div>
  <div title="Zeitpunkt des letzten verifizierten Datenbank-Backups"><span>Letztes Backup</span><b id="kpi_backup">—</b></div>
  <div title="Ergebnis der letzten SQLite-Integritätsprüfung (quick_check)"><span>Datenbank</span><b id="kpi_db">—</b></div>
  <div title="Nur direktionale Wale (eine Seite, kein Hedge-, kein Market-Maker-Muster), Konten ab 10 Mio USD Gesamtwert, alle Coins: Anzahl Konten und Positionswert je Seite, Prozent = Anteil am Wert beider Seiten"><span>Wal-Position (nur direktional, USD)</span><b id="kpi_dirn">—</b></div>
  <div title="Käufe minus Verkäufe der Top-50-Konten im gewählten Coin (Perp und Spot, Notional USD) in den letzten 24 h und 3 Tagen; Konten = Käufer / Verkäufer im Zeitraum"><span>Leaderboard Käufe/Verkäufe <span id="kpi_lbact_coin"></span> (USD)</span><b id="kpi_lbact">—</b></div>
  <div title="Netto-Positionsänderung der direktionalen Wale im gewählten Coin in den letzten 30 min (Long auf/Short ab = Kauf; Z = Abweichung von der eigenen 7-Tage-Verteilung der Stundenflüsse); Ereignis-Signal ab Z 2,5 und 4 Walen in dieselbe Richtung"><span>Wal-Flow 30 min (direktional, USD)</span><b id="kpi_flow">—</b></div>
  <div title="Positionierung der 20 profitabelsten Leaderboard-Konten (30-Tage-PnL) in BTC: Konten und Positionswert je Seite, Netto-Wert und dessen Veränderung gegen 24 h und 7 Tage zuvor (aus der stündlichen Aufzeichnung lb_trend)"><span>Leaderboard Top 20 — BTC-Trend (USD)</span><b id="kpi_lbbtc">—</b></div>
  <div title="Coinbase-Spot: Prämie gegenüber dem Perp-Kurs in Basispunkten mit Z-Wert gegen sieben Tage, dazu der Taker-Flow der letzten Stunde. Spot muss ohne Hebel bezahlt werden — Nachfrage dort wiegt schwerer."><span>Coinbase-Spot (Prämie · Flow)</span><b id="kpi_cb">—</b></div>
  <div title="Netto-Summe der Konfluenz-Punkte: Kauf-Punkte minus Verkaufs-Punkte; ab ±3 Konfluenz, Details im Abschnitt Konfluenz"><span>Konfluenz</span><b id="kpi_signal">—</b></div>`;
 if(LAST_CHART){ fillIndicators(LAST_CHART); }
 if(LAST_HEALTH) fillHealth(LAST_HEALTH);
 fillDirectional(); fillFlow(); fillFcLive(); fillLbTile(); fillLbActTile(); fillCbTile();
 if(LAST_CHART&&LAST_CHART.budget) taskWarn(LAST_CHART.budget);
}

let SNAP_ACTIVE=false;                                 // während des Snapshots keine Live-Aktualisierung
async function load(){
 if(SNAP_ACTIVE&&!load.erzwungen) return;
 loadChart();
 const coin=$('coin').value, h=$('hours').value;
 const d=await getJSON(`/data?coin=${coin}&hours=${h}&src=${SRC()}`);
 LAST=d.grid; LAST_DEPTH=d.depth; LAST_DATA=d; drawHeat(d.grid); drawDepth(d.depth);
 if(SRC()==='bnc'){ LAST_WHALES={exposure:[],current:[],events:[],price:[]}; drawWhales(LAST_WHALES); drawMetrics(d.metrics); computeSignal(); if(LAST_CHART) drawChart(LAST_CHART); }
 else { try{LAST_WHALES=await getJSON(`/whales?coin=${coin}&hours=${Math.max(72,h)}`); drawWhales(LAST_WHALES); computeSignal();
  if(LAST_CHART) drawChart(LAST_CHART);}catch(e){}
  if(SRC()==='fusion'&&d.bnc) drawMetrics(d.bnc.metrics); else $('bncmetrics').style.display='none'; }
 renderKpi();
 if(LAST_CHART) computeSignal();
 if(LAST_CHART) fillIndicators(LAST_CHART);
 if(LAST_HEALTH) fillHealth(LAST_HEALTH);
 $('warn').textContent=d.stats.days<14
  ? `Aufzeichnung läuft erst ${d.stats.days.toFixed(1)} Tage — die Abdeckung der `
    +`Adressen ist noch unvollständig, absolute Zahlen fallen zu niedrig aus.`:'';
}
$('thr').oninput=()=>{$('thrval').textContent='Perzentil '+$('thr').value;
                      if(LAST) drawHeat(LAST);};
if($('bncliqmin')) $('bncliqmin').onchange=()=>{ if(LAST) drawHeat(LAST); };
if($('netextwin')) $('netextwin').onchange=()=>loadNetwork();
getJSON('/coins').then(cs=>{
 if(!Array.isArray(cs)||!cs.length){showErr('/coins: leere Liste — Datenbank ohne Kerzen? Pfad in der Unit prüfen');return;}
 $('coin').innerHTML=cs.map(c=>`<option>${c}</option>`).join('');
 load(); loadHealth();
 // 21.09.: acht offene Tabs brachten den Pi auf 99 % CPU -- unsichtbare Tabs fragen nichts mehr ab und
 // laden beim Sichtbarwerden einmal komplett nach
 const sichtbar=()=>document.visibilityState!=='hidden';
 setInterval(()=>{ if(!SNAP_ACTIVE&&sichtbar()) load(); },20000); setInterval(()=>{ if(!SNAP_ACTIVE&&sichtbar()) loadChart(); },5000); setInterval(loadHealth,3600000);
 document.addEventListener('visibilitychange',()=>{ if(sichtbar()&&!SNAP_ACTIVE){ load(); loadChart(); if(typeof loadNetwork==='function') loadNetwork(); if(typeof loadForecast==='function') loadForecast(); if(typeof loadSystem==='function') loadSystem(); } });
 $('coin').onchange=()=>{ load(); loadForecast(); }; $('hours').onchange=load;
 try{ const sv=localStorage.getItem('hl_src'); if(sv&&$('src').querySelector(`option[value="${sv}"]`)) $('src').value=sv; }catch(e){}
 $('src').onchange=()=>{ try{localStorage.setItem('hl_src',SRC());}catch(e){} applySrcLabels(); load(); };
 applySrcLabels();
 $('tf').onchange=loadChart; $('fvg').onchange=loadChart;
 $('fvgtoggle').onclick=()=>setFvg(!FVG_ON);
 $('updbtn').onclick=runUpdate;
 let rsz=null; addEventListener('resize',()=>{clearTimeout(rsz); rsz=setTimeout(load,300);});   // Drehung: alle Panels neu
}).catch(()=>{});   // Fehler wurde von getJSON bereits in der Leiste gemeldet
</script>
<script src="/makro.js"></script></body></html>"""


# ---------------------------------------------------------------------------
# Update per Knopf: Archiv von GitHub laden, update.py in eigener systemd-Einheit
# starten (ein Kind des Dashboards stürbe mit dem Dashboard-Neustart).
# ---------------------------------------------------------------------------

UPDATE_URL = "https://raw.githubusercontent.com/lll174/Seed/main/hl_liq_project.zip"
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
UPDATE_LOG = os.path.join(ROOT_DIR, "updates", "last_update.log")


def raw_github(url: str) -> str:
    """blob-Links der GitHub-Oberfläche auf den Rohdownload umschreiben."""
    m = re.match(r"https?://github\.com/([^/]+)/([^/]+)/blob/(.+)", url)
    return f"https://raw.githubusercontent.com/{m.group(1)}/{m.group(2)}/{m.group(3)}" if m else url


def sudo_password() -> tuple[str | None, str]:
    f = os.path.join(ROOT_DIR, "sudo.txt")
    if not os.path.exists(f):
        return None, "sudo.txt fehlt im Projektordner"
    mode = os.stat(f).st_mode & 0o777
    if mode & 0o077:
        return None, f"sudo.txt hat Rechte {oct(mode)} — bitte chmod 600 sudo.txt"
    pw = open(f, errors="replace").read().strip()
    return (pw, "") if pw else (None, "sudo.txt ist leer")


def start_update(url: str) -> dict:
    """Archiv laden, prüfen, update.py abgekoppelt starten. Liefert Status für die Seite."""
    import urllib.request, zipfile
    pw, why = sudo_password()
    if not pw:
        return {"ok": False, "msg": why}
    os.makedirs(os.path.dirname(UPDATE_LOG), exist_ok=True)
    target = os.path.join(ROOT_DIR, "updates", "hl_liq_project.zip")
    try:
        req = urllib.request.Request(raw_github(url), headers={"User-Agent": "hl-dashboard-update/1.0",
                                                               "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=60) as r:
            # Deckel gegen ein übergroßes Archiv: ohne Grenze läuft der Pi beim Lesen in
            # den Arbeitsspeicher und wird vom Kernel abgeschossen. Das Projektarchiv
            # liegt bei wenigen Megabyte.
            grenze = 80 * 1024 * 1024
            laenge = r.headers.get("Content-Length")
            if laenge and int(laenge) > grenze:
                return {"ok": False, "error": f"Archiv zu groß: {int(laenge)/1e6:.0f} MB"}
            data = r.read(grenze + 1)
            if len(data) > grenze:
                return {"ok": False, "error": "Archiv überschreitet 80 MB — abgebrochen"}
    except Exception as e:
        return {"ok": False, "msg": f"Download fehlgeschlagen: {e}"}
    if data[:2] != b"PK":
        return {"ok": False, "msg": "Download ist kein ZIP — GitHub-Link prüfen (Rohdatei, nicht HTML-Seite)"}
    with open(target, "wb") as f:
        f.write(data)
    try:
        with zipfile.ZipFile(target) as z:
            names = {n.split("/")[-1] for n in z.namelist()}
        if not {"hl_recorder.py", "hl_viz.py", "update.py"} <= names:
            return {"ok": False, "msg": "Archiv unvollständig"}
    except zipfile.BadZipFile as e:
        return {"ok": False, "msg": f"ZIP defekt: {e}"}
    py = os.path.join(ROOT_DIR, ".venv", "bin", "python")
    if not os.path.exists(py):
        py = sys.executable
    uid, gid = os.getuid(), os.getgid()
    with open(UPDATE_LOG, "w") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] Archiv geladen ({len(data)//1024} kB), starte update.py …\n")
    if shutil.which("systemd-run") and os.path.exists("/run/systemd/system"):
        # Läuft noch ein Update? Dann nicht doppelt starten.
        active = subprocess.run(["systemctl", "list-units", "--no-legend", "--plain", "--state=active,activating",
                                 "hl-update*"], capture_output=True, text=True).stdout.strip()
        if active:
            return {"ok": False, "msg": "Ein Update läuft noch: " + active.split()[0]}
        # Reste gescheiterter Läufe freigeben (sonst: 'Unit ... was already loaded')
        subprocess.run(["sudo", "-S", "-p", "", "systemctl", "reset-failed", "hl-update.service", "hl-update-*.service"],
                       input=pw + "\n", capture_output=True, text=True)
        # eigene, kurzlebige Einheit mit eindeutigem Namen: überlebt den Dashboard-Neustart
        unit = "hl-update-" + time.strftime("%Y%m%d-%H%M%S")
        cmd = ["sudo", "-S", "-p", "", "systemd-run", f"--unit={unit}", "--collect",
               f"--uid={uid}", f"--gid={gid}", f"--working-directory={ROOT_DIR}",
               f"--property=StandardOutput=append:{UPDATE_LOG}",
               f"--property=StandardError=append:{UPDATE_LOG}",
               py, os.path.join(ROOT_DIR, "update.py"), target, "--yes"]
        r = subprocess.run(cmd, input=pw + "\n", capture_output=True, text=True)
        if r.returncode != 0:
            return {"ok": False, "msg": "systemd-run fehlgeschlagen: " + (r.stderr.strip()[-200:] or "unbekannt")}
        with open(os.path.join(ROOT_DIR, "updates", "last_unit.txt"), "w") as f:
            f.write(unit)
        return {"ok": True, "msg": f"Update gestartet (Einheit {unit}). Das Dashboard startet gleich neu."}
    # ohne systemd: abgekoppelter Prozess
    with open(UPDATE_LOG, "a") as logf:
        subprocess.Popen([py, os.path.join(ROOT_DIR, "update.py"), target, "--yes"],
                         cwd=ROOT_DIR, stdout=logf, stderr=subprocess.STDOUT, start_new_session=True)
    return {"ok": True, "msg": "Update gestartet."}


def start_restore() -> dict:
    """update.py --restore-last abgekoppelt starten (wie das Update: eigene systemd-Einheit, Log)."""
    py = os.path.join(ROOT_DIR, ".venv", "bin", "python") if os.path.exists(os.path.join(ROOT_DIR, ".venv")) else sys.executable
    os.makedirs(os.path.join(ROOT_DIR, "updates"), exist_ok=True)
    try:
        out = subprocess.run([py, os.path.join(ROOT_DIR, "update.py"), "--backup-info"], capture_output=True, text=True, timeout=20).stdout
        info = json.loads((out.strip().splitlines() or ["{}"])[-1])        # letzte Zeile: JSON (davor evtl. Hinweise)
    except (ValueError, subprocess.SubprocessError):
        info = {}
    if not info.get("vorhanden"):
        return {"ok": False, "msg": "Kein Backup-Ordner updates/vor_* vorhanden."}
    with open(UPDATE_LOG, "a") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] Wiederherstellung aus {info.get('ordner')} ({info.get('dateien')} Dateien, Datenbanken ausgenommen) …\n")
    if shutil.which("systemd-run") and os.path.exists("/run/systemd/system"):
        pw, why = sudo_password()
        if pw is None:
            return {"ok": False, "msg": why}
        active = subprocess.run(["systemctl", "list-units", "--no-legend", "--plain", "--state=active,activating", "hl-update*"],
                                capture_output=True, text=True).stdout.strip()
        if active:
            return {"ok": False, "msg": "Ein Update/Restore läuft noch: " + active.split()[0]}
        subprocess.run(["sudo", "-S", "-p", "", "systemctl", "reset-failed", "hl-update.service", "hl-update-*.service"],
                       input=pw + "\n", capture_output=True, text=True)
        uid, gid = os.getuid(), os.getgid()
        unit = "hl-update-rueck-" + time.strftime("%Y%m%d-%H%M%S")
        cmd = ["sudo", "-S", "-p", "", "systemd-run", f"--unit={unit}", "--collect", f"--uid={uid}", f"--gid={gid}",
               f"--working-directory={ROOT_DIR}", f"--property=StandardOutput=append:{UPDATE_LOG}",
               f"--property=StandardError=append:{UPDATE_LOG}", py, os.path.join(ROOT_DIR, "update.py"), "--restore-last", "--yes"]
        r = subprocess.run(cmd, input=pw + "\n", capture_output=True, text=True)
        if r.returncode != 0:
            return {"ok": False, "msg": "systemd-run fehlgeschlagen: " + (r.stderr.strip()[-200:] or "unbekannt")}
        with open(os.path.join(ROOT_DIR, "updates", "last_unit.txt"), "w") as f:
            f.write(unit)
        return {"ok": True, "msg": f"Wiederherstellung aus {info.get('ordner')} gestartet. Das Dashboard startet gleich neu."}
    with open(UPDATE_LOG, "a") as logf:
        subprocess.Popen([py, os.path.join(ROOT_DIR, "update.py"), "--restore-last", "--yes"], cwd=ROOT_DIR, stdout=logf,
                         stderr=subprocess.STDOUT, start_new_session=True)
    return {"ok": True, "msg": "Wiederherstellung gestartet."}


def restore_info() -> dict:
    py = os.path.join(ROOT_DIR, ".venv", "bin", "python") if os.path.exists(os.path.join(ROOT_DIR, ".venv")) else sys.executable
    try:
        out = subprocess.run([py, os.path.join(ROOT_DIR, "update.py"), "--backup-info"], capture_output=True, text=True, timeout=20).stdout
        return json.loads((out.strip().splitlines() or ["{}"])[-1])
    except (ValueError, subprocess.SubprocessError) as e:
        return {"vorhanden": False, "fehler": str(e)}


def update_status() -> dict:
    running = False
    if shutil.which("systemctl"):
        unit = "hl-update"
        try:
            with open(os.path.join(ROOT_DIR, "updates", "last_unit.txt")) as f:
                unit = f.read().strip() or unit
        except OSError:
            pass
        running = subprocess.run(["systemctl", "is-active", unit], capture_output=True,
                                 text=True).stdout.strip() in ("active", "activating")
    log = ""
    try:
        with open(UPDATE_LOG, errors="replace") as f:
            log = "".join(f.readlines()[-40:])
    except OSError:
        pass
    done = ("Fertig." in log) or ("FEHLER" in log and not running) or ("Abbruch" in log)
    return {"running": running, "done": done and not running, "log": log,
            "ok_marker": "Fertig." in log}


# ---------------------------------------------------------------------------
# Wallet-Zuordnung: wer steckt hinter einer Adresse?
#   1. labels.json         -- eigene Pflege, hat Vorrang, wird nie überschrieben
#   2. Hyperliquid-Leaderboard  -- selbst gewählte Anzeigenamen (kein API-Gewicht)
#   3. vaultDetails        -- ist die Adresse ein Vault? (Gewicht 20, 1 Abfrage/min, 7 Tage Cache)
#   4. Etherscan-Namenstags (octal.art) und Arbiscan-Tags (Datensatz) -- Börsen, Fonds, Market Maker
#   5. Verhaltensklasse aus den eigenen Daten -- Hedge, Market-Maker-Muster, direktional
# Treffer und Fehlschläge landen in labels_cache.json, damit nichts doppelt gefragt wird.
# ---------------------------------------------------------------------------

LABELS_FILE = os.path.join(ROOT_DIR, "labels.json")
LABELS_CACHE = os.path.join(ROOT_DIR, "labels_cache.json")
ARB_LABELS_URL = "https://raw.githubusercontent.com/brianleect/etherscan-labels/main/data/arbiscan/combined/combinedAllLabels.json"
_LBL_LOCK = threading.Lock()
_LBL: dict = {"own": {}, "own_mtime": 0, "cache": None, "queue": [], "queued": set(), "worker": None,
              "leaderboard": None, "leaderboard_ts": 0, "arb": None, "arb_ts": 0, "last_vault_call": 0}
_LBL_TTL = 7 * 86_400
_LBL_NEG_TTL = 2 * 86_400


def _lbl_load_cache() -> dict:
    with _LBL_LOCK:
        if _LBL["cache"] is None:
            try:
                with open(LABELS_CACHE) as f:
                    _LBL["cache"] = json.load(f)
            except (OSError, ValueError):
                _LBL["cache"] = {}
        return _LBL["cache"]


def _lbl_save_cache() -> None:
    with _LBL_LOCK:
        try:
            tmp = LABELS_CACHE + ".tmp"
            with open(tmp, "w") as f:
                json.dump(_LBL["cache"], f, ensure_ascii=False)
            os.replace(tmp, LABELS_CACHE)
        except OSError:
            pass


def _lbl_own() -> dict:
    try:
        m = os.path.getmtime(LABELS_FILE)
    except OSError:
        return {}
    with _LBL_LOCK:
        if m != _LBL["own_mtime"]:
            try:
                with open(LABELS_FILE) as f:
                    raw = json.load(f)
                _LBL["own"] = {k.lower(): v for k, v in raw.items() if isinstance(v, dict) and k.startswith("0x")}
            except (OSError, ValueError):
                _LBL["own"] = {}
            _LBL["own_mtime"] = m
        return _LBL["own"]


def _http_json(url: str, timeout: int = 20, data: bytes | None = None):
    import urllib.request
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "hl-dashboard/1.0",
                                                          **({"Content-Type": "application/json"} if data else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _lbl_leaderboard() -> dict:
    """Adresse -> displayName: aus lb_names (schreibt der Recorder stündlich) -- kein 40-MB-Download im Dashboard.
    Rückfall auf den Download nur, wenn die Tabelle fehlt oder leer ist."""
    with _LBL_LOCK:
        if _LBL["leaderboard"] is not None and time.time() - _LBL["leaderboard_ts"] < 3600:
            return _LBL["leaderboard"]
    names: dict = {}
    try:
        con = connect(Handler.db)
        for r in con.execute("SELECT addr, name, account_value FROM lb_names"):
            names[r["addr"].lower()] = {"name": r["name"], "value": r["account_value"] or 0}
        con.close()
    except Exception:
        names = {}
    if names:
        with _LBL_LOCK:
            _LBL["leaderboard"] = names; _LBL["leaderboard_ts"] = time.time()
        return names
    try:
        d = _http_json("https://stats-data.hyperliquid.xyz/Mainnet/leaderboard", timeout=60)
        rows = d.get("leaderboardRows") if isinstance(d, dict) else d
        for r in rows or []:
            a, n = str(r.get("ethAddress", "")).lower(), r.get("displayName")
            if a and n:
                names[a] = {"name": str(n), "value": float(r.get("accountValue") or 0)}
    except Exception:
        pass
    with _LBL_LOCK:
        if names or _LBL["leaderboard"] is None:
            _LBL["leaderboard"] = names; _LBL["leaderboard_ts"] = time.time()
        return _LBL["leaderboard"]


def _lbl_arbiscan() -> dict:
    """Arbiscan-Namenstags aus dem offenen Datensatz, einmal geladen und lokal gehalten."""
    with _LBL_LOCK:
        if _LBL["arb"] is not None:
            return _LBL["arb"]
    out: dict = {}
    path = os.path.join(ROOT_DIR, "updates", "arbiscan_labels.json")
    try:
        if not os.path.exists(path) or time.time() - os.path.getmtime(path) > 30 * 86_400:
            d = _http_json(ARB_LABELS_URL, timeout=60)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                json.dump(d, f)
        with open(path) as f:
            d = json.load(f)
        if isinstance(d, dict):
            for addr, info in d.items():
                if isinstance(info, dict):
                    out[addr.lower()] = info.get("name") or info.get("Name Tag") or ",".join(info.get("labels", []) or [])
        elif isinstance(d, list):
            for row in d:
                if isinstance(row, dict) and row.get("address"):
                    out[str(row["address"]).lower()] = row.get("name") or row.get("nameTag") or ""
    except Exception:
        pass
    with _LBL_LOCK:
        _LBL["arb"] = out
    return out


def _lbl_lookup_one(addr: str, prev: dict | None = None) -> dict:
    """
    Alle automatischen Quellen für eine Adresse. Je Quelle wird gemerkt, wann sie
    geprüft wurde (checked), damit offene Vault-Prüfungen nicht die anderen Quellen
    erneut anstoßen. Liefert {name, category, source, checked, pending_vault}.
    """
    a = addr.lower(); now = time.time()
    checked = dict((prev or {}).get("checked") or {})
    lb = _lbl_leaderboard().get(a)
    if lb:
        return {"name": lb["name"], "category": "leaderboard", "source": "Hyperliquid-Leaderboard (selbst gewählter Name)", "checked": checked}
    if now - checked.get("octal", 0) > _LBL_NEG_TTL:
        try:
            d = _http_json(f"https://octal.art/etherscan-labels/addresses/{a}.json", timeout=15)
            labels = d.get("Labels") or {}
            tag = next((v.get("Name Tag") for v in labels.values() if isinstance(v, dict) and v.get("Name Tag")), None)
            checked["octal"] = now
            if tag:
                return {"name": tag, "category": ", ".join(sorted(labels.keys())) or "etherscan", "source": "Etherscan-Namenstag", "checked": checked}
        except Exception as e:
            if "404" in str(e):          # sicher unbekannt; Netzfehler -> später erneut
                checked["octal"] = now
    arb = _lbl_arbiscan().get(a)
    if arb:
        return {"name": arb, "category": "arbiscan", "source": "Arbiscan-Tag (Datensatz 2023)", "checked": checked}
    if now - checked.get("vault", 0) > _LBL_TTL:
        with _LBL_LOCK:                   # Vault? Gewicht 20 -- höchstens eine Abfrage pro Minute
            may = time.time() - _LBL["last_vault_call"] >= 60
            if may:
                _LBL["last_vault_call"] = time.time()
        if not may:
            return {"checked": checked, "pending_vault": True}
        try:
            d = _http_json("https://api.hyperliquid.xyz/info", timeout=15,
                           data=json.dumps({"type": "vaultDetails", "vaultAddress": a}).encode())
            checked["vault"] = now
            if isinstance(d, dict) and d.get("name"):
                return {"name": f"Vault „{d['name']}“", "category": "vault", "checked": checked,
                        "source": f"Hyperliquid vaultDetails · Leader {str(d.get('leader',''))[:10]}… · TVL {float(d.get('tvl') or 0)/1e6:.1f} Mio"}
        except Exception:
            return {"checked": checked, "pending_vault": True}
    return {"checked": checked}


def _lbl_worker() -> None:
    while True:
        with _LBL_LOCK:
            if not _LBL["queue"]:
                _LBL["worker"] = None
                return
            addr = _LBL["queue"].pop(0)
        cache = _lbl_load_cache()
        res = _lbl_lookup_one(addr, cache.get(addr))
        with _LBL_LOCK:
            cache[addr] = {"ts": time.time(), **res}
            _LBL["queued"].discard(addr)
        _lbl_save_cache()
        time.sleep(1.5)


_BEH_CACHE: dict = {"ts": 0, "map": {}, "rechnet": False}
_BEH_LOCK = threading.Lock()
_BEH_FERTIG = threading.Event()
WAL_FENSTER_S = 6 * 3600        # 23.35: jüngster Stand je Wal-Position aus den letzten 6 h (Snapshot jeder offenen Position alle 10 min)


def behavior_map(con) -> dict:
    """
    Verhaltensklasse aller Wale in EINEM Durchgang, 60 s im Speicher.
    Je Adresse: letzter Stand je Coin aus whale_positions, dazu die
    ruhenden Limits aus der jüngsten Order-Abfrage (nur letzte 6 h, ein Scan).
    Vorher lief je Wal eine Abfrage mit lower(addr) -- ohne Index, mit verschachteltem
    Vollscan: bei 40.000 Zeilen und 150 Walen antwortete der Server nicht mehr.
    23.35 (Dauerlast 29./30.09., hl_viz 366 %): Der Durchgang las die GANZE Tabelle (auf dem Pi gut 2 Mio Zeilen, sie wächst
    um ~60.000 je Tag), und jeder Aufrufer nach Ablauf der 60 s rechnete selbst -- sieben gleichzeitige Durchgänge im
    Thread-Abzug. Jetzt nur die letzten 6 h (offene Positionen haben alle 10 min einen Snapshot; was 6 h keine Zeile
    hat, ist geschlossen oder der Recorder steht) und höchstens EINE Berechnung zugleich: Wer währenddessen fragt, bekommt den
    vorigen Stand.
    """
    with _BEH_LOCK:
        if time.time() - _BEH_CACHE["ts"] < 60:
            return _BEH_CACHE["map"]
        if _BEH_CACHE["rechnet"]:
            if _BEH_CACHE["ts"]:
                return _BEH_CACHE["map"]                    # läuft schon: vorigen Stand liefern, nicht doppelt rechnen
            warten = True
        else:
            _BEH_CACHE["rechnet"] = True; warten = False
    if warten:                                              # allererste Berechnung läuft: auf sie warten
        _BEH_FERTIG.wait(90)
        with _BEH_LOCK:
            return _BEH_CACHE["map"]
    try:
        return _behavior_rechnen(con)
    finally:
        with _BEH_LOCK:
            _BEH_CACHE["rechnet"] = False
        _BEH_FERTIG.set()


def _behavior_rechnen(con) -> dict:
    latest: dict = {}
    try:
        cur_ = con.cursor(); cur_.row_factory = None
        for addr, coin, event, side, val, lev, ts in cur_.execute(
                "SELECT addr, coin, event, side, pos_value, leverage, ts FROM whale_positions WHERE ts>=? ORDER BY ts",
                (int(time.time()) - WAL_FENSTER_S,)):
            v_ = latest.get((addr, coin))
            if v_ is not None and v_[4] == ts and v_[0] == "close":
                continue                                        # gleicher Zeitstempel: das Schließen gewinnt (sonst Scheinposition)
            latest[(addr, coin)] = (event, side, val or 0, lev or 0, ts)
    except sqlite3.OperationalError:
        return {}
    per_addr: dict = {}
    for (addr, coin), (event, side, val, lev, _ts) in latest.items():
        if event == "close" or val <= 0:
            continue
        per_addr.setdefault(addr, []).append((coin, side, val, lev))
    orders: dict = {}
    try:
        since = int(time.time()) - 6 * 3600
        last_ts: dict = {}
        rows = con.execute("SELECT addr, ts, kind FROM trigger_orders WHERE ts>=? AND kind IN ('limit_buy','limit_sell')",
                           (since,)).fetchall()
        for addr, ts, kind in rows:
            last_ts[addr] = max(last_ts.get(addr, 0), ts)
        for addr, ts, kind in rows:
            if ts == last_ts[addr]:
                orders.setdefault(addr, {}).setdefault(kind, 0); orders[addr][kind] += 1
    except sqlite3.OperationalError:
        pass
    out = {}
    try:
        akt_mm = hl_forecast.mm_aus_handel(con)                             # 23.29 (U15): Market-Maker aus dem Handel
    except Exception:
        akt_mm = set()
    for addr, ps in per_addr.items():
        coins = {c for c, _, _, _ in ps}; sides = {sd for _, sd, _, _ in ps}
        lev = max(l for _, _, _, l in ps); n = len(coins); ob = orders.get(addr, {})
        if ob.get("limit_buy", 0) >= 5 and ob.get("limit_sell", 0) >= 5:
            cls = "Market-Maker-Muster (beidseitig viele ruhende Limits)"
        elif addr.lower() in akt_mm:
            cls = "Market-Maker-Muster (Handel: viele Trades rund um die Uhr, kaum Netto-Richtung)"
        elif len(sides) == 2:
            cls = "gemischt (long und short)"
        elif n >= 3 and lev <= 10:
            cls = f"Hedge-Muster ({n} Coins, eine Seite, Hebel ≤ 10)"
        elif n >= 3:
            cls = f"direktional ({n} Coins, eine Seite, Hebel bis {lev:.0f}×)"
        elif n == 1 and lev >= 15:
            cls = "direktional (ein Coin, hoher Hebel)"
        else:
            cls = f"direktional ({n} Coin{'s' if n > 1 else ''}, Hebel bis {lev:.0f}×)"
        out[addr.lower()] = cls
    # Klasse JE COIN: Ein Konto kann in BTC klar positioniert sein und in ETH die Gegenseite
    # halten -- kontoweit "gemischt", für BTC aber eine Meinung. Entscheidend für das Signal
    # ist, wie sich das Konto IN DIESEM COIN verhält, nicht sein Gesamtbild.
    per_coin = {}
    for addr, ps in per_addr.items():
        ob = orders.get(addr, {})
        mm = (ob.get("limit_buy", 0) >= 5 and ob.get("limit_sell", 0) >= 5) or addr.lower() in akt_mm
        coins = {c for c, _, _, _ in ps}
        sides_all = {sd for _, sd, _, _ in ps}
        lev_max = max((l for _, _, _, l in ps), default=0)      # kontoweit, wie in behavior_map
        for coin, side, val, lev in ps:
            if mm:
                grp = "mm"
            elif len(coins) >= 3 and len(sides_all) == 1 and lev_max <= 10:
                grp = "hedge"                       # viele Coins, eine Seite, wenig Hebel
            elif len(sides_all) == 2 and len(coins) >= 2:
                grp = "mixed"                       # trägt beide Seiten -- in diesem Coin aber eine
            else:
                grp = "dir"
            per_coin[(addr.lower(), coin)] = {"group": grp, "side": side, "val": val, "lev": lev,
                                              "coins": len(coins), "both_sides": len(sides_all) == 2}
    with _BEH_LOCK:
        _BEH_CACHE.update(ts=time.time(), map=out, per_coin=per_coin)
    return out


GROUPS = {"dir": "direktional", "hedge": "Hedge", "mm": "Market Maker", "mixed": "gemischt"}


def score_klasse(con, coin: str):
    """
    Klasse je Konto für den Konto-Score (hl_score.compute_scores): Verhalten im Coin vor kontoweitem Verhalten (Market-Maker, Hedge,
    gemischt) vor Leaderboard-Gruppe; unbekannt = neutral 0,5, nicht „dir“ (N7, Audit v10). 23.39: aus dem Lernzyklus herausgezogen,
    damit check_elite genau so einstuft (bis 23.38 stufte das Werkzeug Unbekannte als direktional ein und kannte das Verhalten je Coin nicht).
    """
    bmap = behavior_map(con); pcoin = behavior_per_coin(con); lbg = hl_forecast.lb_groups(con, coin)

    def klasse_of(a: str) -> str:
        e = pcoin.get((a, coin))
        if e:
            return e["group"]
        cls = bmap.get(a, "")
        if cls.startswith("Market-Maker"):
            return "mm"
        if cls.startswith("Hedge"):
            return "hedge"
        if cls.startswith("gemischt"):
            return "mixed"
        return lbg.get(a, "unbekannt")
    return klasse_of


def behavior_per_coin(con) -> dict:
    """Klasse je (Adresse, Coin) -- füllt denselben Zwischenspeicher wie behavior_map."""
    behavior_map(con)
    with _BEH_LOCK:
        return _BEH_CACHE.get("per_coin") or {}


def behavior_class(con, addr: str) -> str:
    return behavior_map(con).get(addr.lower(), "")


def labels_for(con, addrs: list[str]) -> dict:
    """Für jede Adresse: Name/Quelle (eigen > Cache), Verhaltensklasse, Links; Unbekannte in die Warteschlange."""
    own = _lbl_own(); cache = _lbl_load_cache(); out = {}; now = time.time(); bmap = behavior_map(con)
    G_ = gesperrte_konten(con)
    for addr in addrs:
        a = addr.lower()
        rec = {"links": {"hypurrscan": f"https://hypurrscan.io/address/{a}",
                         "arbiscan": f"https://arbiscan.io/address/{a}",
                         "arkham": f"https://intel.arkm.com/explorer/address/{a}",
                         "hyperliquid": f"https://app.hyperliquid.xyz/explorer/address/{a}"},
               "behavior": ("GESPERRT — Masterregel (> 300 Trades/24 h): kein Signal" if a in G_ else bmap.get(a, "")), "gesperrt": a in G_}
        if a in own:
            o = own[a]; rec.update({"name": o.get("name", ""), "category": o.get("kategorie") or o.get("category", "eigen"),
                                    "source": o.get("quelle") or o.get("source", "labels.json")})
        else:
            c = cache.get(a)
            fresh = c and (now - c.get("ts", 0) < (_LBL_TTL if c.get("name") else _LBL_NEG_TTL)) and not (c.get("pending_vault") and now - c.get("ts", 0) > 90)
            if c and c.get("name"):
                rec.update({"name": c["name"], "category": c.get("category", ""), "source": c.get("source", "")})
            if not fresh:
                with _LBL_LOCK:
                    if a not in _LBL["queued"]:
                        _LBL["queue"].append(a); _LBL["queued"].add(a)
                        if _LBL["worker"] is None:
                            _LBL["worker"] = threading.Thread(target=_lbl_worker, daemon=True); _LBL["worker"].start()
                rec["pending"] = True
        out[a] = rec
    return out


# ---------------------------------------------------------------------------
# Debug-Konsole: feste Liste von Diagnoseläufen (kein freies Kommando), läuft als
# Dashboard-Benutzer ohne sudo, Ausgabe wird abgeholt und lässt sich kopieren.
# ---------------------------------------------------------------------------

def _py() -> str:
    v = os.path.join(ROOT_DIR, ".venv", "bin", "python")
    return v if os.path.exists(v) else sys.executable


_SERVE: dict = {"port": None}


# Debug "Dashboard-Threads": drei Stack-Proben über 10 s, CPU je dauerhaftem Thread und (23.36) des ganzen Prozesses.
# Kurze Anfragen leben nur Sekundenbruchteile und fehlen in der Liste je Thread -- "Prozess gesamt" minus "dauerhafte
# Threads" ist ihr Anteil, dazu die Zahl neuer Threads (je Anfrage einer). PORT_ wird beim Aufruf ersetzt.
_VIZ_THREADS_SKRIPT = r"""import urllib.request,json,time,collections,re
c=collections.Counter(); cpu0={}; cpu1={}; name={}; pz=[]; nr=[]
for i in range(3):
  d=json.loads(urllib.request.urlopen('http://127.0.0.1:PORT_/debug/threads',timeout=30).read())
  print('Probe',i+1,':',len(d['threads']),'Threads')
  for t in d['threads']:
    print('   ',t['thread'],'->',' < '.join(reversed(t['stack'][-3:])))
    c[t['stack'][-1]]+=1; name[t.get('tid')]=t['thread']+' | '+t['stack'][-1]
    if t.get('cpu_s') is not None:
      (cpu0 if i==0 else cpu1)[t.get('tid')]=(t['cpu_s'],d['ts'])
  if d.get('prozess_cpu_s') is not None:
    pz.append((d['prozess_cpu_s'],d['ts']))
  nr.append(max([int(m.group(1)) for m in (re.match(r'Thread-(\d+)',t['thread']) for t in d['threads']) if m] or [0]))
  if i<2:
    time.sleep(5)
print()
print('Haeufigste Stellen:')
[print('  ',n,'x',k) for k,n in c.most_common(8)]
print()
print('CPU zwischen Probe 1 und 3 (Prozent eines Kerns):')
z=[(100*(cpu1[k][0]-cpu0[k][0])/max(0.1,cpu1[k][1]-cpu0[k][1]),name.get(k,'?')) for k in cpu1 if k in cpu0]
s=sum(p for p,n in z)
if len(pz)>=2:
  dt=max(0.1,pz[-1][1]-pz[0][1]); g=100*(pz[-1][0]-pz[0][0])/dt
  print('   Prozess gesamt        %5.0f %%   (alle Threads, auch inzwischen beendete)' % g)
  print('   davon dauerhafte      %5.0f %%' % s)
  print('   Rest, kurze Anfragen  %5.0f %%   (%d neue Threads in %.0f s, etwa %.1f je Sekunde)' % (max(0.0,g-s),nr[-1]-nr[0],dt,(nr[-1]-nr[0])/dt))
else:
  print('   Summe der dauerhaften Threads %5.0f %%' % s)
print('Dauerhafte Threads ab 1 %:')
[print('   %5.0f %%  %s' % (p,n)) for p,n in sorted(z,reverse=True)[:12] if p>=1]
"""


def debug_commands(db: str) -> dict:
    py = _py()
    return {
        "report": ("★ VOLLBERICHT (2 min) — alles auf einmal, zum Einfügen in den Chat", [py, "check_report.py", "--db", db, "--minutes", "2"]),
        "check_leaderboard": ("Leaderboard-Diagnose (Konten, Rohformat, Live-Gegenprobe, warum keine Ereignisse)", [py, "check_leaderboard.py", "--db", db]),
        "check_forecast": ("Prognose-Diagnose (vollständiger Traceback, Lernstand)", [py, "check_forecast.py", "--db", db]),
        "check_writes": ("Schreiblast messen (5 min): je Tabelle, je Laufwerk, je Prozess", [py, "check_writes.py", "--db", db, "--seconds", "300"]),
        "check_writes_short": ("Schreiblast messen (60 s, schnelle Stichprobe)", [py, "check_writes.py", "--db", db, "--seconds", "60"]),
        "check_coinbase": ("Coinbase-Spot: Stand, Kerzen, Buch, Taker-Flow", [py, "hl_coinbase.py", "--db", db, "--status"]),
        "check_live": ("Live-Quellen prüfen (Crypto.com, Bybit, OKX — je Endpunkt)",
                       [py, "-c", "import sys; sys.path.insert(0, '.'); import hl_viz; print(hl_viz.pruefe_livequellen())"]),
        "profile": ("★ Ereignis-Profile (U43): Treiber in den 12 h vor Rutschen und Anstiegen — Vorläufer oder Mitläufer?", [py, "hl_konstellation.py", "--profile", "--db", db]),
        "vorbedingungen": ("★ Vorbedingungen: Ereignisliste (U131) — welche Rückgänge und Anstiege ≥ 3 % binnen 24 h erfasst wurden, je Coin, mit Abgleich gegen die Kursdaten und der bisherigen Zählung", [py, "hl_konstellation.py", "--vorbedingungen", "--db", db]),
        "anker": ("Heatmap als Richtungsanker je Coin mit Kursen: Trefferquote trendbereinigt, Berührung gegen Spiegel-Niveau, überhitzt/normal (dauert 1–2 Minuten)", [py, "hl_anker.py", "--bericht", "--db", db]),
        "selbsttest": ("Selbsttest wie bei der Installation -- in einer KOPIE des Projektordners mit eigenem Prognosespeicher, berührt keine echten Daten (3–5 min)",
                       [py, "install.py", "--selftest-isoliert"]),
        "familien": ("Treiberfamilien: Kennzahlenkarte je Coin (Parallelbetrieb) -- Vorsprung, ungesehene Daten, Wochen, Überschneidung, Hygiene", [py, "hl_familien.py", "--bericht", "--db", db]),
        "labor": ("★ TradeLabor: alle simulierten Strategien -- Kennzahlen (Blöcke), Glück, beste je Coin, Grid-Bots je Coin, Darwin-, Elite- und Gebühren-Prüfung, alle offenen Positionen, letzte Ein-/Ausstiege",
                  [py, "hl_labor.py", "--bericht", "--db", db]),
        "labor_selbsttest": ("TradeLabor-Selbsttest (synthetischer Markt: Ausführung, Gebühren, Kontrollen, Kaskade, Darwin v2, Elite-Kopie, Docht, Blockstatistik, Kontotage, Grid Long/Short: Range, Kapital, Rallye, Crash, Trend, Neustart)", [py, "hl_labor.py", "--selbsttest"]),
        "recorder_fills": ("Recorder-Selbsttest: Fills der Darwin-Liste ohne Mindestbetrag, Deckel, Richtung (temporäre Datenbank)", [py, "hl_recorder.py", "--selbsttest-fills"]),
        "viz_last": ("Dashboard-Selbsttest Last-Schutz: Wal-Stand im 6-h-Fenster, gleiche Anfragen rechnen nur einmal (temporäre Datenbank)", [py, "hl_viz.py", "--selbsttest-last"]),
        "adressstrom": ("Adress-Strom (Trade-Feed mit Adressen): Aufzeichnung, Null-Hash-Anteil (TWAP), TWAP-Netto, größte TWAP-Adressen", [py, "hl_adressfluss.py", "--bericht", "--db", db]),
        "konfluenz": ("Bilanz der Konfluenz (Chart-Signal): wie oft lagen Richtung und Zonen richtig, gegen den Zufall", [py, "hl_forecast.py", "--konfluenz", "--db", db]),
        "empfehlungen": ("★ Bilanz der Kauf-/Verkaufsempfehlungen (U8): gefüllt, Rendite nach Kosten gegen Markt und nie/halten, je Coin", [py, "hl_forecast.py", "--empfehlungen", "--db", db]),
        "cb_seite": ("Coinbase: Seiten-Umstellung (U41) — ab wann der Spot-Taker-Flow stimmt (vorher buy/sell vertauscht)", [py, "hl_coinbase.py", "--db", db, "--seite-umstellung"]),
        "coinbase_selftest": ("Coinbase-Selbsttest (Rechenwege ohne Netz)", [py, "hl_coinbase.py", "--selftest"]),
        "browser_cache": ("Browser auf dem Pi: Cache-Größe und Schreiblast (Firefox/Chromium)", ["sh", "-c",
            "echo '--- Firefox-Profile:'; du -shc ~/.mozilla/firefox/*/ ~/.cache/mozilla/firefox/*/ 2>/dev/null | tail -20; "
            "echo; echo '--- Chromium:'; du -shc ~/.config/chromium ~/.cache/chromium 2>/dev/null | tail -5; "
            "echo; echo 'Firefox schreibt seinen Cache auf die SD-Karte. Abstellen: about:config ->'; "
            "echo '  browser.cache.disk.enable = false   (Cache nur im RAM)'; "
            "echo '  browser.sessionstore.interval = 600000   (Sitzung alle 10 min statt alle 15 s)'; "
            "echo 'Alternative: Dashboard vom Handy oder PC aus ansehen statt vom Pi.'"]),
        "ram_prozesse": ("RAM je Prozess: wer belegt wie viel (RSS), Laufzeit, Python-Dienste zuerst", ["sh", "-c",
            "echo '--- Speicher gesamt (MemAvailable = wirklich nutzbar):'; free -h; echo; "
            "echo '--- Prozesse nach belegtem Speicher (RSS in MB, Laufzeit in h):'; "
            "ps -eo rss,etimes,pid,cmd --sort=-rss | awk 'NR==1{print \"   MB   Std   PID  Kommando\"; next} NR<=16{printf \"%5d %5.1f %6d  %s\\n\", $1/1024, $2/3600, $3, substr($0, index($0,$4), 90)}'; echo; "
            "echo '--- Projekt-Dienste (RSS in MB):'; for u in hl-recorder hl-dashboard hl-binance hl-coinbase hl-watchdog; do "
            "p=$(systemctl show -p MainPID --value $u 2>/dev/null); [ -n \"$p\" ] && [ \"$p\" != 0 ] && printf '%-14s %6d MB\\n' $u $(( $(awk '/VmRSS/{print $2}' /proc/$p/status 2>/dev/null || echo 0) / 1024 )); done; echo; "
            "echo 'Lesart: Der Recorder hält die Metadaten von ~140.000 Adressen im Speicher (einige Dutzend MB) und wächst in den ersten Stunden;'; "
            "echo 'ein Dienst, der über Tage stetig weiter wächst, hat ein Leck. Zweimal im Abstand von Stunden ausführen und vergleichen.'"]),
        "sd_usage": ("SD-Karte: Belegung, größte Ordner, Journal, Swap", ["sh", "-c",
            "df -h / ; echo; echo '--- größte Ordner auf /:'; du -xhd2 / 2>/dev/null | sort -rh | head -20; "
            "echo; echo '--- Journal:'; journalctl --disk-usage 2>/dev/null; "
            "echo; echo '--- Swap:'; swapon --show; free -h | head -3; "
            "echo; echo '--- Logdateien des Projekts:'; ls -la logs/ 2>/dev/null | head; ls -la updates/ 2>/dev/null | head"]),
        # Neue Werkzeuge der Sitzung 2 (13.09.): Messen vor Ändern -- alle nur lesend
        "check_fills": ("Fill-Abholstand: welche Konten hängen, welche Klasse, wie viele Fills je Tag", [py, "check_fills.py", "--db", db]),
        "check_magnet_60": ("Magnet-Varianten, 60 Tage und Horizont bis 48 h (dauert einige Minuten; Anzeige im Dashboard bleibt bei 14 Tagen / 24 h)",
                            [py, "check_magnet.py", "--db", db, "--days", "60", "--horizonte", "4,8,12,24,48"]),
        "fusion_stand": ("★ Fusion und v3 (Schatten): Stand je Coin -- Kostenschwelle, Gewichte der Experten, Bilanz gegen die Basisrate, v3-Modell",
                         [py, "hl_fusion.py", "--stand", "--db", db]),
        "fusion_test": ("Fusion, v3 und Kostenschwelle: Selbsttest (v3-Tor, Grenze ln M der Mischung, Teilen über Coins, kein Blick in die Zukunft)",
                        [py, "hl_fusion.py", "--nulltest"]),
        "kaskade_stand": ("★ Kaskaden-Gleichung (Schatten): Stand je Coin -- Kipppunkt, Reichweite, Kalibrierung Y, Placebo, Seitenspiegel",
                          [py, "hl_kaskade.py", "--stand", "--db", db]),
        "kaskade_kalib": ("Kaskaden-Gleichung: jetzt kalibrieren und Stand zeigen (sonst alle 6 h)", [py, "hl_kaskade.py", "--kalibrieren", "--db", db]),
        "kaskade_test": ("Kaskaden-Gleichung: Selbsttest (geschlossene Form, Positivkontrolle, Nulltest, Störfaktor, Live)",
                         [py, "hl_kaskade.py", "--nulltest"]),
        "magnet_stand": ("★ Magnet-Test (U110): berührt der Kurs Cluster öfter als der Zufall? Überschuss je Größenklasse, Spiegel, Placebo",
                         [py, "hl_magnet.py", "--stand", "--db", db]),
        "makro_stand": ("★ Makro: Stand und Quellen (U121) -- Abrufe je Quelle, Frische je Reihe, BGeometrics-Budget, OI-Archiv, Zonenkarte, Power-Law-Exponent, "
                        "Signale je Chart mit Bilanz und Prognose, Live gegen Nachrechnung (U126)",
                        [py, "hl_makro.py", "--stand", "--db", db]),
        "makro_abruf": ("Makro: jetzt abrufen -- alle Quellen sofort (BGeometrics nur im Budget: ein Endpunkt je Lauf), danach Stand",
                        [py, "hl_makro.py", "--abrufen", "--erzwingen", "--db", db]),
        "makro_test": ("Makro: Selbsttest -- je Treiber Positivkontrolle und Nulltest, Kausalität, Parser, Zeitplan, Nutzlast (ohne Netz)",
                       [py, "hl_makro.py", "--selbsttest"]),
        "makro_signal_test": ("Makro: Selbsttest der Signale (U126) -- Perzentile kausal, Rückblick, Bilanz gegen Zufall (Positivkontrolle, Nulltest), "
                              "Prognose mit Band, Live gegen Nachrechnung (ohne Netz)",
                              [py, "hl_makro_signal.py", "--selbsttest"]),
        "makro_korr": ("★ Makro × Kurs (U130, Teil A) -- 15 Makro-Merkmale gegen die BTC-Rendite der folgenden 1, 7 und 30 Tage: ρ, ρ², "
                       "Phasen-Null, Benjamini-Hochberg, beide Hälften (vorab festgelegt, KONZEPT_Makro.md Abschnitt 10)",
                       [py, "hl_makro_korr.py", "--db", db]),
        "makro_korr_test": ("Makro × Kurs: Selbsttest -- Phasen-Null (Nulltest auf Zufallswegen), Positivkontrolle, Ära, Hälften, Nachrechnung (ohne Netz)",
                            [py, "hl_makro_korr.py", "--selbsttest"]),
        # 23.59 (U138): Regime-Modul Phase 0 -- nur Bericht, eigene Datei regime.db (Kerzen-Zwischenspeicher), berührt nichts sonst
        "regime_vorpruefung": ("★ Regime: Vorprüfung auf der Historie (U138, Phase 0) -- Zwei-Uhren-Profil, Bewegungsgröße (HAR), Beine gegen die "
                               "Zufallsgeometrie, Beinende, Kalender K1–K3, Wochenmomentum, Fenster, Regime-Analog, Bruchmelder; vorab festgelegt "
                               "(KONZEPT_Regime.md 9.1a); erster Lauf lädt rund 3 Jahre 30-min-Kerzen je Coin (einige Minuten)",
                               [py, "hl_regime.py", "--vorpruefung", "--db", db]),
        "regime_laden": ("Regime: Historie laden bzw. ergänzen -- 30-min-Kerzen je Coin von Binance-Futures oder Bybit, nur in regime.db",
                         [py, "hl_regime.py", "--laden", "--db", db]),
        "regime_test": ("Regime: Selbsttest -- Bausteine, Laden ohne Netz, Kausalität, Nulltests und Positivkontrollen P0.1–P0.9 (ohne Netz, rund 1 min)",
                        [py, "hl_regime.py", "--selbsttest"]),
        "magnet_kalib": ("Magnet-Test: jetzt rechnen und Stand zeigen (sonst alle 6 h)", [py, "hl_magnet.py", "--kalibrieren", "--db", db]),
        "magnet_test": ("Magnet-Test: Selbsttest (Positivkontrolle Anziehung, Nulltest, Fallen für Spiegel, Placebo und Seitenausgleich, Grenze)",
                        [py, "hl_magnet.py", "--nulltest"]),
        "kalib2_stand": ("Kalibrierung v2: Stand je Coin -- Fälle, Achsenabschnitt, Zuverlässigkeit, Beiträge der Treiber zur aktuellen p_up",
                         [py, "hl_kalib.py", "--stand"]),
        "check_magnet": ("Magnet-Varianten: ziehen Liquidationscluster bei 0,5-1 % und 1-2 % den Kurs an (4-24 h)? Alle Coins", [py, "check_magnet.py", "--db", db]),
        "konstellation": ("Konstellationen und Vorbedingungen: Nulltest (Rauschen ohne Lift) und Probe der Ereigniserkennung (U131: Szenarien mit bekannter Zahl von Bewegungen, Abgleich mit den Kursdaten, Positivkontrolle)", [py, "hl_konstellation.py", "--nulltest"]),
        "kalib2_status": ("Kalibrierung v2 (K2-Neubau): Positivkontrolle/Nulltest v2 ausführen (Tor: Kante 0,65 → p 0,60–0,70)", [py, "hl_kalib.py", "--nulltest"]),
        "kalib2_an": ("Kalibrierung v2 AKTIVIEREN -- die Prognose nutzt ab der nächsten Berechnung p_up_v2 (Schalter in forecasts.db; rückgängig mit dem nächsten Eintrag)", [py, "hl_kalib.py", "--aktivieren"]),
        "kalib2_aus": ("Kalibrierung v2 zurück in den Schatten -- die Prognose nutzt wieder das alte Modell", [py, "hl_kalib.py", "--deaktivieren"]),
        "check_profis": ("★ Aktive Profis: Darwin-Liste (Mitglieder mit Verbleib und Fehltagen, Zu- und Abgänge der letzten 7 Tage mit Grund) und Bewertung des Pools mit allen Gründen", [py, "check_profis.py", "--db", db, "--alle"]),
        "check_sperre": ("Masterregel Sperre: vorläufig und dauerhaft gesperrte Konten mit Namen und Grund, Freigaben (auch die Neubewertung 23.37 und ihre Korrektur 23.38), die aktivsten Konten nahe der Grenze (300 gebündelte Trades/24 h)", [py, "check_sperre.py", "--db", db]),
        "check_pool": ("★ Aktive Profis: Pool zählen -- Kandidaten aus der Leaderboard-Datei, und ab Phase 1 die echten gebündelten Trades/Tag je Pool-Konto (Grenze 150)", [py, "check_pool.py", "--db", db]),
        "viz_threads": ("Dashboard-Threads: was rechnet hl_viz gerade? (drei Stack-Proben über 10 s, CPU je Thread und des ganzen Prozesses, Anfragen je Sekunde)",
                        [py, "-c", _VIZ_THREADS_SKRIPT.replace("PORT_", str(_SERVE.get("port") or 8765))]),
        "check_treiber": ("★ Treiber-Funktionstest: alle 30 Treiber und Regime-Flags mit Soll-Szenarien (synthetisch), danach Plausibilität auf der echten Datenbank", [py, "check_treiber.py", "--db", db]),
        "check_elite": ("Elite-Positionierung prüfen (gewählter Coin): Elite-Konten, Klassen, Positionen beider Quellen, Dominanz, Vergleich mit Smart Money, Live-Abfrage (20 Gewicht)", [py, "check_elite.py", "--db", db, "--coin", "{coin}", "--live"]),
        "check_m9": ("Ereignis-Signal M9: Feuerraten alt (Z-Wert) gegen neu (Rang) der letzten 7 Tage", [py, "check_m9.py", "--db", db]),
        "nulltest": ("Nulltest der Statistik: gesamte Strecke auf reinem Rauschen (Soll aus der Mathematik)", [py, "hl_forecast.py", "--nulltest"]),
        "score_selftest": ("Konto-Score-Selbsttest (synthetische Konten mit echtem Vorlauf)", [py, "hl_score.py"]),
        "check_orders": ("Order-Abfragen: wie viele, wie stimmig", [py, "check_orders.py", "--db", db]),
        "check_daily": ("Tageskerzen / MA-Kacheln", [py, "check_daily.py", "--db", db]),
        "db_size": ("Speicherbelegung je Tabelle", [py, "db_size.py", db]),
        "audit": ("Recorder --audit (Gesamtstatus)", [py, "hl_recorder.py", "--db", db, "--audit"]),
        "status": ("Recorder --status", [py, "hl_recorder.py", "--db", db, "--status"]),
        "binance_status": ("Binance-Modul --status", [py, "hl_binance.py", "--db", db, "--status"]),
        "binance_probe": ("Binance-Stream-Probe (15 s): DNS, TCP, TLS, WebSocket, Nachrichten -- warum kommen keine Liquidationen?",
                          [py, "hl_binance.py", "--probe-stream", "15"]),
        "check_sources": ("★ Rundum-Funktionstest aller Quellen (langsam, ~3 min): jede Börse, jeder benutzte Aufruf, Felder, Streams",
                          [py, "check_sources.py", "--db", db, "--ws-sekunden", "20"]),
        # Die Dienste schreiben ihre Ausgabe in LOGDATEIEN (StandardOutput=append:...), nicht ins
        # Journal -- dort stehen nur die Start/Stop-Zeilen von systemd. Der Pfad kommt aus der Unit.
        **{f"log_{u.split('-')[1]}": (f"Logdatei {u} (letzte 120 Zeilen: echte Ausgabe des Dienstes)", ["sh", "-c",
            f"echo '--- Unit-Datei:'; systemctl cat {u} 2>/dev/null | grep -v '^#' | grep -i 'ExecStart\\|StandardOutput\\|StandardError\\|Environment\\|WorkingDirectory'; "
            f"so=$(systemctl show {u} -p StandardOutput --value 2>/dev/null); echo \"--- StandardOutput laut systemd: ${{so:-<leer>}}\"; "
            f"f=$(echo \"$so\" | sed 's/^append://; s/^truncate://'); "
            f"if [ -n \"$f\" ] && [ -f \"$f\" ]; then echo \"--- $f ($(du -h \"$f\" | cut -f1)):\"; tail -n 120 \"$f\"; "
            f"else wd=$(systemctl show {u} -p WorkingDirectory --value 2>/dev/null); "
            f"for c in \"$wd/logs/{u.split('-')[1]}.log\" \"$wd/{u.split('-')[1]}.log\" \"$HOME/logs/{u.split('-')[1]}.log\"; do "
            f"[ -f \"$c\" ] && {{ echo \"--- gefunden: $c ($(du -h \"$c\" | cut -f1)):\"; tail -n 120 \"$c\"; exit 0; }}; done; "
            f"echo '--- keine Logdatei gefunden; Journal (Programmzeilen, ohne systemd-Meldungen):'; journalctl -u {u} -n 200 --no-pager -o cat 2>/dev/null | grep -v '^$' | tail -n 60; "
            f"echo; echo 'Hinweis: Erscheint hier nichts außer Start/Stop, ist die Ausgabe gepuffert (PYTHONUNBUFFERED fehlt in der Unit) -- install.py --systemd erneuert die Units.'; fi"])
           for u in ("hl-binance", "hl-recorder", "hl-dashboard", "hl-coinbase", "hl-watchdog")},
        "journal_recorder": ("Journal hl-recorder (letzte 80 Zeilen)", ["journalctl", "-u", "hl-recorder", "-n", "80", "--no-pager", "-o", "short-iso"]),
        "journal_dashboard": ("Journal hl-dashboard (letzte 80 Zeilen)", ["journalctl", "-u", "hl-dashboard", "-n", "80", "--no-pager", "-o", "short-iso"]),
        "journal_binance": ("Journal hl-binance (letzte 80 Zeilen)", ["journalctl", "-u", "hl-binance", "-n", "80", "--no-pager", "-o", "short-iso"]),
        "journal_update": ("Update-Log (updates/last_update.log)", ["tail", "-n", "120", UPDATE_LOG]),
        "services": ("Dienste: systemctl status", ["systemctl", "status", "hl-recorder", "hl-dashboard", "hl-binance", "--no-pager", "-l"]),
        "disk": ("Datenträger und Speicher", ["sh", "-c", "df -h / /mnt/* 2>/dev/null; echo; free -h; echo; uptime; echo; vcgencmd measure_temp 2>/dev/null"]),
    }


_DBG: dict = {"lock": threading.Lock(), "jobs": {}}


def debug_run(name: str, db: str, coin: str = "BTC") -> dict:
    cmds = debug_commands(db)
    if name not in cmds:
        return {"ok": False, "msg": "unbekannter Lauf"}
    label, cmd = cmds[name]
    cmd = [c.replace("{coin}", coin.upper()) if isinstance(c, str) else c for c in cmd]   # gewählter Coin des Dashboards
    job_id = f"{name}-{int(time.time())}"
    job = {"id": job_id, "name": name, "label": label, "cmd": " ".join(cmd), "started": time.time(), "running": True,
           "output": "", "rc": None}
    with _BER["lock"]:
        if _BER["laeuft"]:
            return {"ok": False, "msg": f"Es läuft gerade ein geplanter Bericht ({_BER['laeuft']}) — bitte kurz warten."}
    with _DBG["lock"]:
        if any(j["running"] for j in _DBG["jobs"].values()):
            return {"ok": False, "msg": "Es läuft schon ein Diagnoselauf — bitte warten."}
        _DBG["jobs"] = {job_id: job}                  # nur der jüngste Lauf wird gehalten

    def run():
        try:
            env = dict(os.environ, PYTHONUNBUFFERED="1")
            p = subprocess.Popen(cmd, cwd=ROOT_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env)
            buf = []
            for line in p.stdout:
                buf.append(line)
                if sum(len(x) for x in buf) > 200_000:
                    buf.append("\n… Ausgabe gekürzt (200 kB) …\n"); p.kill(); break
                with _DBG["lock"]:
                    job["output"] = "".join(buf)
            rc = p.wait(timeout=600)
            with _DBG["lock"]:
                job["output"] = "".join(buf); job["rc"] = rc
        except FileNotFoundError as e:
            with _DBG["lock"]:
                job["output"] += f"\nBefehl nicht verfügbar: {e}\n"; job["rc"] = 127
        except Exception as e:
            with _DBG["lock"]:
                job["output"] += f"\nFehler: {e}\n"; job["rc"] = 1
        finally:
            with _DBG["lock"]:
                job["running"] = False
            try:                                        # 23.33: jeder Handlauf auch unter berichte/ -- erscheint bei „Neue Berichte“
                out_ = job["output"] or ""
                if out_.strip():
                    kopf = (f"# {label}\n# {time.strftime('%d.%m.%Y, %H:%M:%S', time.localtime(job['started']))} · Coin {coin.upper()} · "
                            f"manueller Lauf · Exit {job['rc']} · {time.time() - job['started']:.1f} s\n$ {job['cmd']}\n")
                    os.makedirs(BERICHTE_DIR, exist_ok=True)
                    datei = f"{time.strftime('%Y-%m-%d_%H-%M', time.localtime(job['started']))}_{name}_manuell.txt"
                    with open(os.path.join(BERICHTE_DIR, datei), "w", encoding="utf-8") as f:
                        f.write(kopf + out_)
            except OSError:
                pass
    threading.Thread(target=run, daemon=True).start()
    return {"ok": True, "id": job_id, "label": label, "cmd": job["cmd"]}


def debug_status(job_id: str) -> dict:
    with _DBG["lock"]:
        job = _DBG["jobs"].get(job_id)
        if not job:
            return {"ok": False, "msg": "kein solcher Lauf"}
        return {"ok": True, "running": job["running"], "output": job["output"], "rc": job["rc"],
                "label": job["label"], "cmd": job["cmd"], "seconds": round(time.time() - job["started"], 1)}


# ---------------------------------------------------------------------------
# Berichtsplan (23.09., Entscheidung des Nutzers: nur lokal speichern). Debug-Einträge laufen zu festen Zeiten von
# selbst; die Ausgaben landen als Textdateien in berichte/ im Projektordner und sind im Debug-Bereich abrufbar --
# einzeln oder als Sammeldatei zum Hochladen in den Chat. Termine pflegt Claude mit jedem Paket (Liste unten).
# ---------------------------------------------------------------------------
BERICHTE_DIR = os.path.join(ROOT_DIR, "berichte")
BERICHTSPLAN = [
    {"id": "u43-erstlauf", "einmal": "2026-09-23 20:30", "laeufe": ["profile"],
     "zweck": "Ereignis-Profile, erstmals mit dem Rutsch vom 23.09. gegen 16:15"},
    {"id": "u31-neubewertung", "einmal": "2026-09-24 13:15", "laeufe": ["check_sperre"],
     "zweck": "Masterregel: Ergebnis der einmaligen Neubewertung der alten Sperren (U31)"},
    {"id": "u31-neubewertung-2", "einmal": "2026-09-24 14:00", "laeufe": ["check_sperre"],
     "zweck": "Masterregel: zweiter Blick, falls die Neubewertung um 13:15 noch nicht durch war"},
    {"id": "u7b-vorbereitung", "einmal": "2026-09-30 19:30", "laeufe": ["kalib2_status"],
     "zweck": "Kalibrierung v2: Positivkontrolle und Nulltest vor dem Umschalten (U7b, erst nach U29/U35)"},
    {"id": "u3b-profis", "einmal": "2026-10-06 19:00", "laeufe": ["check_profis"],
     "zweck": "Aktive Profis: strengere Qualifikation? (U3b)"},
    {"id": "u72-adressstrom", "einmal": "2026-09-28 12:00", "laeufe": ["adressstrom", "labor"],
     "zweck": "Adress-Strom und TradeLabor nach dem ersten Tag: Null-Hash-Anteil, Dateigröße, erste Trades (U71/U72)"},
    {"id": "u77-profis-darwin", "einmal": "2026-09-30 12:00", "laeufe": ["check_profis", "labor"],
     "zweck": "23.34: Aktive Profis mit Pool-Positionen als Quelle (wie viele qualifiziert, Quellen je Tabelle), Darwin-Prüfung und XMR im TradeLabor (U77–U80)"},
    {"id": "woche", "woechentlich": [2, "19:00"], "ab": "2026-09-30",
     "laeufe": ["report", "check_elite", "check_pool", "check_sperre", "empfehlungen", "profile", "vorbedingungen", "kalib2_stand", "fusion_stand", "kaskade_stand", "magnet_stand", "makro_stand", "check_magnet_60", "konfluenz",
                "familien", "anker", "labor", "adressstrom", "check_profis"],
     "zweck": "Wochenprüfung: VOLLBERICHT (Abschnitt A), Elite (W1), Pool und Sperren (W2), Empfehlungen (W7), Ereignis-Profile und Vorbedingungen-Ereignisliste (W8), v2-Stand, Fusion und v3 (W11), Kaskaden-Gleichung (W12), Magnet-Test (W13), Makro-Chart: Quellen, Frische und Signale (W14), Magnete 60 Tage, TradeLabor und Adress-Strom (W9), Aktive Profis (W10)"},
    {"id": "u106-fusion-woche1", "einmal": "2026-10-11 19:30", "laeufe": ["fusion_stand", "fusion_test", "labor"],
     "zweck": "Fusion, v3 und Kostenschwelle nach der ersten Woche (U104–U107): Gewichte, Bilanz gegen die Basisrate, v3-Modell, Labor-Strategien der Fusion"},
    {"id": "u113-kaskade-woche1", "einmal": "2026-10-11 19:45", "laeufe": ["kaskade_stand", "kaskade_test"],
     "zweck": "Kaskaden-Gleichung nach der ersten Woche (U113): Y je Coin und Horizont, Placebo, Seitenspiegel, Zuverlässigkeit, Richtungsprobe"},
    {"id": "u115-kaskade-auswertung", "einmal": "2026-10-25 19:45", "laeufe": ["kaskade_stand"],
     "zweck": "Auswertung U115 (KONZEPT_Fusion.md 4b.4): Y je Coin und Horizont belegt (alle vier Bedingungen), Zuverlässigkeit der "
              "≥ 2-σ-Vorhersagen, Richtungsprobe der Asymmetrie; „Kaskaden-Kipppunkt“ gegen „Kaskaden-Fortsetzung“ im Labor-Bericht von 19:30"},
    {"id": "u121-makro-erstlauf", "einmal": "2026-10-06 20:15", "laeufe": ["makro_stand", "makro_test"],
     "zweck": "Makro-Chart nach dem ersten Tag (U121): jede Quelle abgerufen? Formate (BGeometrics-Felder, Binance-Archiv), Rückrechnung "
              "gegen den Bericht (Realized Price, MVRV, Power Law), Budget und Archiv"},
    {"id": "u126-makro-signale", "einmal": "2026-10-08 20:15", "laeufe": ["makro_stand", "makro_signal_test"],
     "zweck": "Makro-Signale nach den ersten Tagen (U126): Rechenzeit auf dem Pi, Lage, Live-Signal, Bilanz und Prognose je Chart und Zeitraum, "
              "Live gegen Nachrechnung ab dem zweiten Archivtag (ändern die Quellen alte Werte?)"},
    {"id": "u131-vorbedingungen", "einmal": "2026-10-06 20:45", "laeufe": ["vorbedingungen", "konstellation"],
     "zweck": "Vorbedingungen nach der Umstellung (U131): welche Rückgänge und Anstiege ≥ 3 % je Coin erfasst sind, Abgleich mit den "
              "Kursdaten (was zeigt der Chart, was wurde nicht erfasst und warum), bisherige Zählung zum Vergleich; Probe der Erkennung"},
    {"id": "u130-makro-korr", "einmal": "2026-10-06 20:30", "laeufe": ["makro_korr"],
     "zweck": "Makro × Kurs (U130, Teil A) zum ersten Mal mit allen Quellen: 15 Makro-Merkmale gegen die BTC-Rendite der folgenden "
              "1, 7 und 30 Tage -- wie stark ist die Wechselwirkung? (vorab festgelegt, KONZEPT_Makro.md Abschnitt 10)"},
    {"id": "u130-makro-korr-2510", "einmal": "2026-10-25 20:15", "laeufe": ["makro_korr", "makro_stand"],
     "zweck": "Makro × Kurs (U130) zum vereinbarten Termin: Teil A erneut (OI-Archiv fertig, FRED mit Schlüssel?), dazu der Stand; "
              "Teil B (Makro-Regime gegen die 4-h-Prognosen) als erster Blick nach U108"},
    {"id": "u138-vorpruefung", "einmal": "2026-10-08 21:00", "laeufe": ["regime_laden", "regime_vorpruefung"],
     "zweck": "Regime-Modul Phase 0 (U138): Historie laden (eigene regime.db), dann die vorab festgelegten Prüfungen P0.1–P0.9 auf rund "
              "drei Jahren 30-min-Kerzen je Coin -- welche Bausteine tragen auf unseren Daten? (KONZEPT_Regime.md 9.1a; bitte hochladen)"},
    {"id": "u136-darwin-schatten", "einmal": "2026-11-18 19:15", "laeufe": ["check_profis"],
     "zweck": "Schatten der Darwin-Liste (U136): vorab festgelegtes Urteil -- treffen Beinahe-Aufnahmen (Glück 1–3 %) nach ihrem Eintritt "
              "öfter als die Kontrollgruppe (≥ 5 Punkte, p < 0,05, ≥ 60 Entscheidungen aus ≥ 3 Konten, ohne jedes einzelne Konto)?"},
    {"id": "u136-darwin-schatten-2", "einmal": "2026-12-16 19:15", "laeufe": ["check_profis"],
     "zweck": "Schatten der Darwin-Liste (U136), zweiter Termin -- nur nötig, wenn am 18.11. zu wenige Entscheidungen oder Konten da waren"},
    {"id": "u127-makro-nachrechnung", "einmal": "2026-11-05 20:15", "laeufe": ["makro_stand"],
     "zweck": "Live gegen Nachrechnung nach einem Monat (U127): weichen archivierte Live-Signale von der Nachrechnung ab (Revisionen bei Coin Metrics, "
              "BGeometrics)? Erst wenn sie gleich bleiben, ist die Bilanz die Bilanz dessen, was live zu sehen war"},
    {"id": "u110-magnet-woche1", "einmal": "2026-10-11 20:00", "laeufe": ["magnet_stand", "magnet_test"],
     "zweck": "Magnet-Test nach der ersten Woche (U110): Überschuss je Größenklasse mit Spiegel und Placebo, Nullmodell an Zufallsniveaus"},
    {"id": "u110-magnet-auswertung", "einmal": "2026-10-25 20:00", "laeufe": ["magnet_stand"],
     "zweck": "Magnet-Test nach drei Wochen (U110): belegt nur, was in mehreren Wochen bleibt (36 Tests je Lauf); dann Treiber „Zug“"},
    {"id": "u108-fusion-auswertung", "einmal": "2026-10-25 19:30", "laeufe": ["fusion_stand", "kalib2_stand", "labor"],
     "zweck": "Auswertung U108 nach drei Wochen live: Fusion gegen Basisrate und jeden Experten über alle Coins (nur live gestellt, Zeitblöcke als "
              "Klumpen), v3-Modell, v2-Stand, Labor „Prognose Fusion“ gegen „Fusion mit Kostenschwelle“ (KONZEPT_Fusion.md, Abschnitt 6)"},
]
BERICHTE_NACHHOLEN_S = 12 * 3600               # verpasste Termine (Dienst aus, Update) bis 12 h später nachholen
BERICHTE_AUFHEBEN_TAGE = 365
_BER: dict = {"lock": threading.Lock(), "laeuft": None, "gestartet": False, "aufgeraeumt": 0}
_BER_NAME = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}_[a-z0-9_]+\.txt$")


def _plan_termine(e: dict, now: int) -> tuple:
    """(letzter fälliger Termin <= now oder None, nächster Termin > now oder None) in Ortszeit des Pi, sommerzeitfest."""
    import datetime as _dt
    if "einmal" in e:
        t = int(_dt.datetime.strptime(e["einmal"], "%Y-%m-%d %H:%M").timestamp())
        return (t if t <= now else None), (t if t > now else None)
    wt, hhmm = e["woechentlich"]; h, m = (int(x) for x in hhmm.split(":"))
    d = _dt.datetime.fromtimestamp(now)
    k = d.replace(hour=h, minute=m, second=0, microsecond=0) - _dt.timedelta(days=(d.weekday() - wt) % 7)
    if k.timestamp() > now:
        k -= _dt.timedelta(days=7)
    ab = int(_dt.datetime.strptime(e["ab"], "%Y-%m-%d").timestamp()) if e.get("ab") else 0
    naechster = k + _dt.timedelta(days=7)
    while naechster.timestamp() < ab:
        naechster += _dt.timedelta(days=7)
    return (int(k.timestamp()) if k.timestamp() >= ab else None), int(naechster.timestamp())


def _berichte_stand() -> dict:
    try:
        with open(os.path.join(BERICHTE_DIR, ".stand.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _berichte_stand_speichern(stand: dict) -> None:
    os.makedirs(BERICHTE_DIR, exist_ok=True)
    tmp = os.path.join(BERICHTE_DIR, ".stand.json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(stand, f)
    os.replace(tmp, os.path.join(BERICHTE_DIR, ".stand.json"))


def bericht_laufen(name: str, db: str, coin: str = "BTC") -> str | None:
    """Einen Debug-Eintrag ausführen und mit Kopfzeile wie beim Herunterladen in berichte/ speichern; Pfad oder None."""
    cmds = debug_commands(db)
    if name not in cmds:
        return None
    label, cmd = cmds[name]
    cmd = [c.replace("{coin}", coin) if isinstance(c, str) else c for c in cmd]
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=ROOT_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=900,
                           env=dict(os.environ, PYTHONUNBUFFERED="1"))
        out, rc = p.stdout or "", p.returncode
    except subprocess.TimeoutExpired as e:
        out = e.stdout if isinstance(e.stdout, str) else (e.stdout or b"").decode("utf-8", "replace")
        out, rc = out + "\n… abgebrochen nach 15 min …\n", "Zeit"
    except (OSError, subprocess.SubprocessError) as e:
        out, rc = f"Fehler: {e}\n", 1
    if len(out) > 400_000:
        out = out[:400_000] + "\n… Ausgabe gekürzt (400 kB) …\n"
    kopf = (f"# {label}\n# {time.strftime('%d.%m.%Y, %H:%M:%S')} · Coin {coin} · geplanter Bericht · Exit {rc} · "
            f"{time.time() - t0:.1f} s\n$ {' '.join(cmd)}\n")
    os.makedirs(BERICHTE_DIR, exist_ok=True)
    pfad = os.path.join(BERICHTE_DIR, f"{time.strftime('%Y-%m-%d_%H-%M', time.localtime(t0))}_{name}.txt")
    with open(pfad, "w", encoding="utf-8") as f:
        f.write(kopf + out)
    return pfad


def berichte_pruefen(db: str, now: int | None = None) -> list:
    """Fällige Einträge ausführen (je Termin einmal, verpasste bis 12 h nachholen, ältere als verpasst vermerken)."""
    now = int(now or time.time()); stand = _berichte_stand(); gelaufen = []
    for e in BERICHTSPLAN:
        letzter, _ = _plan_termine(e, now)
        if letzter is None or stand.get(e["id"], 0) >= letzter:
            continue
        if now - letzter > BERICHTE_NACHHOLEN_S:
            stand[e["id"]] = letzter; stand[e["id"] + ":verpasst"] = letzter
            _berichte_stand_speichern(stand)
            continue
        with _DBG["lock"]:
            if any(j["running"] for j in _DBG["jobs"].values()):
                return gelaufen                                     # Handlauf läuft: in einer Minute wieder
        for name in e["laeufe"]:
            with _BER["lock"]:
                _BER["laeuft"] = name
            try:
                pfad = bericht_laufen(name, db)
                if pfad:
                    gelaufen.append(pfad)
            finally:
                with _BER["lock"]:
                    _BER["laeuft"] = None
        stand[e["id"]] = letzter
        _berichte_stand_speichern(stand)
    if now - _BER["aufgeraeumt"] > 86_400:
        _BER["aufgeraeumt"] = now
        try:
            for f in os.listdir(BERICHTE_DIR):
                p = os.path.join(BERICHTE_DIR, f)
                if _BER_NAME.match(f) and now - os.path.getmtime(p) > BERICHTE_AUFHEBEN_TAGE * 86_400:
                    os.remove(p)
        except OSError:
            pass
    return gelaufen


def berichte_start(db: str) -> None:
    """Hintergrund-Thread des Berichtsplans -- nicht im Selbsttest (Datenbank _selftest.db) und nicht mit HL_BERICHTE=0."""
    if _BER["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_BERICHTE") == "0":
        return
    _BER["gestartet"] = True

    def schleife():
        time.sleep(90)                                              # erst die Dienste hochkommen lassen
        while True:
            try:
                berichte_pruefen(db)
            except Exception as e:
                print(f"Berichtsplan: {type(e).__name__}: {e}", flush=True)
            time.sleep(60)
    threading.Thread(target=schleife, daemon=True, name="berichtsplan").start()


def berichte_uebersicht(db: str, now: int | None = None) -> dict:
    now = int(now or time.time()); stand = _berichte_stand(); cmds = debug_commands(db); plan = []
    for e in BERICHTSPLAN:
        letzter, naechster = _plan_termine(e, now)
        erledigt = bool(letzter) and stand.get(e["id"], 0) >= letzter
        if "einmal" in e and not naechster and now - (letzter or 0) > 7 * 86_400:
            continue                                                # erledigte Einzeltermine eine Woche zeigen
        plan.append({"id": e["id"], "zweck": e["zweck"], "art": "einmal" if "einmal" in e else "woechentlich",
                     "woechentlich": e.get("woechentlich"), "naechster": naechster, "letzter": letzter if erledigt else None,
                     "verpasst": bool(letzter) and stand.get(e["id"] + ":verpasst") == letzter,
                     "laeufe": [cmds.get(n, (n,))[0] for n in e["laeufe"]]})
    dateien = []
    try:
        for f in sorted((f for f in os.listdir(BERICHTE_DIR) if _BER_NAME.match(f)), reverse=True)[:40]:
            p = os.path.join(BERICHTE_DIR, f)
            dateien.append({"name": f, "ts": int(os.path.getmtime(p)), "kb": round(os.path.getsize(p) / 1024, 1)})
    except OSError:
        pass
    with _BER["lock"]:
        laeuft = _BER["laeuft"]
    ab = _abgeholt_laden(); abg = ab.get("abgeholt") or {}
    for d_ in dateien:
        d_["abgeholt"] = abg.get(d_["name"])
    try:
        neu = sum(1 for f in os.listdir(BERICHTE_DIR) if _BER_NAME.match(f) and f not in abg)
    except OSError:
        neu = 0
    return {"plan": sorted(plan, key=lambda x: x["naechster"] or 0), "dateien": dateien, "ordner": BERICHTE_DIR, "neu": neu,
            "letzter_abruf_ts": ab.get("letzter_abruf_ts"), "letzter_abruf_n": len(ab.get("letzter_abruf") or []),
            "laeuft": cmds.get(laeuft, (laeuft,))[0] if laeuft else None, "aktiv": _BER["gestartet"]}


def bericht_lesen(name: str) -> bytes | None:
    if not _BER_NAME.match(name or ""):
        return None
    try:
        with open(os.path.join(BERICHTE_DIR, name), "rb") as f:
            return f.read()
    except OSError:
        return None


def _abgeholt_laden() -> dict:
    try:
        with open(os.path.join(BERICHTE_DIR, ".abgeholt.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def berichte_neu(nochmal: bool = False) -> tuple:
    """
    23.21: Sammeldatei nur mit Berichten, die noch in keiner „Neue Berichte“-Datei waren; sie gelten danach als abgeholt.
    nochmal=True liefert genau den letzten Abruf erneut (falls ein Download schiefging). Zustand in berichte/.abgeholt.json.
    """
    with _BER["lock"]:
        ab = _abgeholt_laden()
        try:
            namen = sorted(f for f in os.listdir(BERICHTE_DIR) if _BER_NAME.match(f))
        except OSError:
            namen = []
        abgeholt = {k: v for k, v in (ab.get("abgeholt") or {}).items() if k in namen}      # verschwundene Dateien vergessen
        if nochmal:
            wahl = [f for f in (ab.get("letzter_abruf") or []) if f in namen]
        else:
            wahl = [f for f in namen if f not in abgeholt]
            if wahl:
                jetzt = int(time.time())
                abgeholt.update({f: jetzt for f in wahl})
                ab.update(abgeholt=abgeholt, letzter_abruf=wahl, letzter_abruf_ts=jetzt)
                os.makedirs(BERICHTE_DIR, exist_ok=True)
                tmp = os.path.join(BERICHTE_DIR, ".abgeholt.json.tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(ab, f)
                os.replace(tmp, os.path.join(BERICHTE_DIR, ".abgeholt.json"))
    teile = []
    for f in wahl:
        try:
            with open(os.path.join(BERICHTE_DIR, f), encoding="utf-8", errors="replace") as fh:
                teile.append(f"\n\n{'=' * 24} {f} {'=' * 24}\n" + fh.read())
        except OSError:
            pass
    art = "letzter Abruf erneut" if nochmal else "neue Berichte"
    kopf = f"# Sammeldatei · {art} · {len(teile)} Berichte · erstellt {time.strftime('%d.%m.%Y %H:%M')}\n"
    return (kopf + ("".join(teile) if teile else "\n(keine Berichte)\n")).encode("utf-8"), \
        f"berichte_{'nochmal' if nochmal else 'neu'}_{time.strftime('%Y-%m-%d_%H-%M')}.txt"


def berichte_sammel(tage: int, now: int | None = None) -> tuple:
    """Alle Berichte der letzten `tage` Tage in einer Datei, älteste zuerst -- zum Hochladen in den Chat."""
    now = int(now or time.time()); teile = []
    try:
        namen = sorted(f for f in os.listdir(BERICHTE_DIR) if _BER_NAME.match(f))
    except OSError:
        namen = []
    for f in namen:
        p = os.path.join(BERICHTE_DIR, f)
        if now - os.path.getmtime(p) <= tage * 86_400:
            with open(p, encoding="utf-8", errors="replace") as fh:
                teile.append(f"\n\n{'=' * 24} {f} {'=' * 24}\n" + fh.read())
    try:
        import version as _v
        ver = f"{_v.VERSION} · {_v.pruefsumme()}"
    except Exception:
        ver = "?"
    kopf = (f"# Sammeldatei der geplanten Berichte · letzte {tage} Tage · {len(teile)} Berichte · erstellt "
            f"{time.strftime('%d.%m.%Y %H:%M')} · Version {ver}\n")
    return (kopf + ("".join(teile) if teile else "\n(keine Berichte in diesem Zeitraum)\n")).encode("utf-8"), \
        f"berichte_{time.strftime('%Y-%m-%d_%H-%M')}_{tage}d.txt"


# ---------------------------------------------------------------------------
# Systemüberwachung des Pi: Temperatur, Drosselung, Last, Speicher, Datenträger --
# ein Hintergrund-Thread misst alle 60 s, hält 24 h Verlauf, das Dashboard fragt ab.
# ---------------------------------------------------------------------------

_SYS: dict = {"lock": threading.Lock(), "hist": [], "cur": None, "started": False}


def _read(path: str) -> str | None:
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return None


_DIENSTE = (("recorder", "hl-recorder.service", "hl_recorder.py"), ("viz", "hl-viz.service", "hl_viz.py"),
            ("binance", "hl-binance.service", "hl_binance.py"), ("coinbase", "hl-coinbase.service", "hl_coinbase.py"),
            ("watchdog", "hl-watchdog.service", "hl_watchdog.py"))


def _dienst_pids() -> dict:
    """PID je Dienst: über systemd (MainPID), sonst über /proc-Kommandozeilen (auch ohne systemd)."""
    pids: dict = {}
    for name, unit, skript in _DIENSTE:
        try:
            r = subprocess.run(["systemctl", "show", "-p", "MainPID", "--value", unit], capture_output=True, text=True, timeout=3)
            pid = int((r.stdout or "0").strip() or 0)
            if pid > 0:
                pids[name] = pid; continue
        except (subprocess.SubprocessError, ValueError, OSError):
            pass
        try:
            for d in os.listdir("/proc"):
                if not d.isdigit():
                    continue
                try:
                    with open(f"/proc/{d}/cmdline", "rb") as f:
                        cmd = f.read().replace(b"\0", b" ")
                except OSError:
                    continue
                if skript.encode() in cmd and b"--selftest" not in cmd and b"--simulate" not in cmd and b"--nulltest" not in cmd:
                    pids[name] = int(d); break
        except OSError:
            pass
    return pids


def cpu_je_dienst() -> dict:
    """
    CPU-Last je Dienst in Prozent EINES Kerns (utime + stime aus /proc/<pid>/stat, Differenz zur
    letzten Messung). 21.09.: Acht offene Browser-Tabs brachten den Pi auf 99 % -- mit dieser Zeile
    wäre in einem Blick klar gewesen, dass es hl_viz war.
    """
    tick = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
    jetzt = time.time(); out: dict = {}
    prev = _SYS.setdefault("proc_prev", {})
    for name, pid in _dienst_pids().items():
        try:
            with open(f"/proc/{pid}/stat") as f:
                felder = f.read().rsplit(")", 1)[1].split()
            ticks = int(felder[11]) + int(felder[12])                 # utime + stime (Felder 14/15 der Manpage)
        except (OSError, ValueError, IndexError):
            continue
        p_ = prev.get(name)
        if p_ and p_[0] == pid and jetzt > p_[2]:
            out[name] = round(100.0 * (ticks - p_[1]) / tick / (jetzt - p_[2]), 1)
        prev[name] = (pid, ticks, jetzt)
    return out


def sys_sample(db_path: str | None = None) -> dict:
    now = int(time.time()); out: dict = {"ts": now}
    # Temperatur: Thermal-Zone (alle Pis), sonst vcgencmd
    t = _read("/sys/class/thermal/thermal_zone0/temp")
    temp = None
    if t and t.lstrip("-").isdigit():
        temp = int(t) / 1000
    else:
        try:
            r = subprocess.run(["vcgencmd", "measure_temp"], capture_output=True, text=True, timeout=3)
            m = re.search(r"temp=([\d.]+)", r.stdout)
            temp = float(m.group(1)) if m else None
        except Exception:
            temp = None
    out["temp"] = temp
    # Drosselung (Raspberry-Firmware): Bitmaske von vcgencmd get_throttled
    flags = []
    try:
        r = subprocess.run(["vcgencmd", "get_throttled"], capture_output=True, text=True, timeout=3)
        m = re.search(r"0x([0-9a-fA-F]+)", r.stdout)
        if m:
            v = int(m.group(1), 16); out["throttled_hex"] = f"0x{v:x}"
            bits = {0: "Unterspannung JETZT", 1: "Takt begrenzt JETZT", 2: "gedrosselt JETZT", 3: "Temperaturlimit JETZT",
                    16: "Unterspannung seit Start", 17: "Takt begrenzt seit Start", 18: "gedrosselt seit Start", 19: "Temperaturlimit seit Start"}
            flags = [name for bit, name in bits.items() if v & (1 << bit)]
    except Exception:
        out["throttled_hex"] = None
    out["throttle_flags"] = flags
    # Takt
    f = _read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
    out["cpu_mhz"] = int(f) / 1000 if f and f.isdigit() else None
    # Last, Speicher, Laufzeit
    try:
        out["load"] = list(os.getloadavg())
    except OSError:
        out["load"] = None
    # CPU-Auslastung gesamt in %: aus /proc/stat, Differenz zur letzten Messung
    # (erste Messung: kurzes Fenster von 0,5 s)
    def cpu_times():
        st = _read("/proc/stat") or ""
        m = re.match(r"cpu\s+(.*)", st)
        if not m:
            return None
        v = [int(x) for x in m.group(1).split()[:8]]
        idle = v[3] + (v[4] if len(v) > 4 else 0)
        return idle, sum(v)
    cur_t = cpu_times(); prev_t = _SYS.get("cpu_prev")
    if cur_t and not prev_t:
        time.sleep(0.5); prev_t, cur_t = cur_t, cpu_times()
    if cur_t and prev_t and cur_t[1] > prev_t[1]:
        out["cpu_pct"] = round(100 * (1 - (cur_t[0] - prev_t[0]) / (cur_t[1] - prev_t[1])), 1)
    else:
        out["cpu_pct"] = None
    _SYS["cpu_prev"] = cur_t
    out["n_cpu"] = os.cpu_count()
    out["cpu_by_service"] = cpu_je_dienst()
    try:
        import version as _v
        if not _SYS.get("version") or time.time() - _SYS.get("version_ts", 0) > 300:
            _SYS["version"] = _v.stand(ROOT_DIR); _SYS["version_ts"] = time.time()
        out["version"] = _SYS["version"]
    except Exception as e:
        out["version"] = f"unbekannt ({type(e).__name__})"
    mem = _read("/proc/meminfo") or ""
    def kb(key):
        m = re.search(rf"^{key}:\s+(\d+)", mem, re.M); return int(m.group(1)) * 1024 if m else None
    out["mem_total"], out["mem_avail"] = kb("MemTotal"), kb("MemAvailable")
    up = _read("/proc/uptime"); out["uptime_s"] = float(up.split()[0]) if up else None
    # Datenträger: Wurzel und der Datenträger der Datenbank
    disks = []
    for label, path in (("System", "/"), ("Datenbank", os.path.dirname(os.path.abspath(db_path)) if db_path else None)):
        if not path or not os.path.exists(path):
            continue
        try:
            u = shutil.disk_usage(path); disks.append({"label": label, "path": path, "total": u.total, "free": u.free})
        except OSError:
            pass
    out["disks"] = disks
    return out


def _sys_hist_file() -> str:
    """Systemverlauf neben der Hauptdatenbank (schont die SD-Karte), sonst im Projektordner."""
    import hl_forecast as _hf                      # lokal: das Modul wird weiter unten importiert
    d = os.path.dirname(os.path.abspath(_hf.STORE))
    if os.path.isdir(d) and os.access(d, os.W_OK):
        return os.path.join(d, "sys_history.json")
    return os.path.join(ROOT_DIR, "updates", "sys_history.json")


SYS_HIST_FILE = _sys_hist_file()


def sys_monitor_start(db_path: str) -> None:
    with _SYS["lock"]:
        if _SYS["started"]:
            return
        _SYS["started"] = True
        try:                                                        # Verlauf des letzten Laufs übernehmen (Neustart, Update)
            with open(SYS_HIST_FILE) as f:
                old = json.load(f)
            cut = time.time() - 86_400
            _SYS["hist"] = [tuple(h) for h in old if isinstance(h, list) and len(h) == 3 and h[0] >= cut]
        except (OSError, ValueError):
            pass
    def run():
        n = 0
        while True:
            try:
                smp = sys_sample(db_path)
                with _SYS["lock"]:
                    _SYS["cur"] = smp
                    if smp.get("temp") is not None or smp.get("cpu_pct") is not None:
                        _SYS["hist"].append((smp["ts"], smp.get("temp"), smp.get("cpu_pct") or 0))
                        _SYS["hist"] = _SYS["hist"][-1440:]          # 24 h bei 60 s
                    hist = list(_SYS["hist"])
                n += 1
                if n % 5 == 0:                                       # alle 5 min sichern
                    os.makedirs(os.path.dirname(SYS_HIST_FILE), exist_ok=True)
                    tmp = SYS_HIST_FILE + ".tmp"
                    with open(tmp, "w") as f:
                        json.dump(hist, f)
                    os.replace(tmp, SYS_HIST_FILE)
            except Exception:
                pass
            time.sleep(60)
    threading.Thread(target=run, daemon=True).start()


_CB_CACHE: dict = {"ts": 0, "data": {}}
_CB_LOCK = threading.Lock()


def load_coinbase(con, coin: str, perp_px: float | None = None) -> dict:
    """
    Coinbase-Spot als eigenständiges Signal.

    Vier Größen, alle gegen die eigene Vorgeschichte gemessen statt gegen absolute Werte:

      * Prämie   -- Spotpreis gegen den Perp-Kurs in Basispunkten. Positiv heißt, im
                    US-Spot wird ein Aufschlag gezahlt; das gilt als Zeichen echter
                    Nachfrage, weil Spot ohne Hebel bezahlt werden muss. Z-Wert gegen
                    die Verteilung der letzten sieben Tage, denn die Prämie hat je nach
                    Marktlage einen eigenen Ruhewert -- der Abstand davon zählt.
      * Taker-Flow -- aggressiv gekauft minus aggressiv verkauft in 15 und 60 Minuten.
      * Orderbuch  -- Tiefe innerhalb 25 Basispunkten, Gebot gegen Angebot.
      * Volumen    -- letzte Stunde gegen den Schnitt der letzten sieben Tage, als
                    Einordnung "ruhig oder lebhaft", nicht als Richtung.
    """
    now = int(time.time())
    out = {"aktiv": False}
    try:
        letzte = con.execute("SELECT MAX(ts) FROM cb_bars WHERE coin=?", (coin,)).fetchone()[0]
    except sqlite3.OperationalError:
        return out                                    # Dienst läuft (noch) nicht
    if not letzte or now - letzte > 1800:
        out["alter_min"] = (now - letzte) // 60 if letzte else None
        return out
    out["aktiv"] = True

    # -- Taker-Flow und Volumen aus den Minutenkerzen ------------------------
    t_ab = hl_forecast.cb_seite_ab(con) or 0                         # U41: vor der Seiten-Umstellung buy/sell vertauscht gespeichert
    for fenster in (15, 60):
        r = con.execute("""SELECT COALESCE(SUM(CASE WHEN ts < ? THEN sell_usd ELSE buy_usd END),0),
                                  COALESCE(SUM(CASE WHEN ts < ? THEN buy_usd ELSE sell_usd END),0),
                                  COALESCE(SUM(volume*close),0), COALESCE(SUM(trades),0)
                           FROM cb_bars WHERE coin=? AND ts > ?""", (t_ab, t_ab, coin, now - fenster * 60)).fetchone()
        out[f"flow{fenster}"] = {"buy_usd": r[0], "sell_usd": r[1], "net_usd": r[0] - r[1],
                                 "vol_usd": r[2], "trades": r[3]}
    stunden = [r[0] for r in con.execute(
        """SELECT SUM(volume*close) FROM cb_bars WHERE coin=? AND ts > ?
           GROUP BY ts/3600 ORDER BY ts""", (coin, now - 7 * 86_400)) if r[0]]
    if len(stunden) >= 24:
        # Schnitt nur über volle Stunden (die letzte Gruppe ist die laufende, unvollständige);
        # verglichen wird die GLEITENDE letzte Stunde (flow60), nicht der angebrochene Block --
        # sonst ist das Verhältnis systematisch zu niedrig (Re-Audit N4).
        schnitt = sum(stunden[:-1]) / max(len(stunden) - 1, 1)
        letzte = (out.get("flow60") or {}).get("vol_usd") or stunden[-1]
        out["vol_1h"] = letzte
        out["vol_schnitt"] = schnitt
        out["vol_rel"] = letzte / schnitt if schnitt > 0 else None
    # Netto-Flüsse je Stunde für den Z-Wert
    netto = [r[0] for r in con.execute(
        """SELECT SUM(CASE WHEN ts < ? THEN sell_usd - buy_usd ELSE buy_usd - sell_usd END) FROM cb_bars WHERE coin=? AND ts > ?
           GROUP BY ts/3600 ORDER BY ts""", (t_ab, coin, now - 7 * 86_400)) if r[0] is not None]
    if len(netto) >= 20:
        m = sum(netto) / len(netto)
        sd = (sum((x - m) ** 2 for x in netto) / max(1, len(netto) - 1)) ** 0.5
        out["flow_z"] = ((out["flow60"]["net_usd"] - m) / sd) if sd > 0 else 0.0

    # -- Orderbuch ----------------------------------------------------------
    b = con.execute("""SELECT ts, bid, ask, bid5, ask5, bid25, ask25, bid100, ask100, walls
                       FROM cb_book WHERE coin=? ORDER BY ts DESC LIMIT 1""", (coin,)).fetchone()
    if b and now - b["ts"] < 600:
        mid = (b["bid"] + b["ask"]) / 2 if b["bid"] and b["ask"] else None
        tief = (b["bid25"] or 0) + (b["ask25"] or 0)
        out["book"] = {"ts": b["ts"], "bid": b["bid"], "ask": b["ask"], "mid": mid,
                       "spread_bps": ((b["ask"] - b["bid"]) / mid * 10_000) if mid else None,
                       "bid25": b["bid25"], "ask25": b["ask25"],
                       "imbalance": (((b["bid25"] or 0) - (b["ask25"] or 0)) / tief) if tief > 0 else None,
                       "bid100": b["bid100"], "ask100": b["ask100"]}
        try:
            out["walls"] = json.loads(b["walls"] or "[]")
        except ValueError:
            out["walls"] = []

    # -- Prämie -------------------------------------------------------------
    spot = (out.get("book") or {}).get("mid")
    if not spot:
        r = con.execute("SELECT close FROM cb_bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        spot = r[0] if r else None
    if spot and perp_px:
        out["spot"] = spot
        out["premium_bps"] = (spot / perp_px - 1) * 10_000
        # Vorgeschichte: Spot-Schluss je Minute gegen Perp-Schluss derselben Minute
        # Beide Reihen getrennt holen und im Speicher über die Minute verbinden.
        # Ein SQL-Join über b.ts/60 = c.ts/60 kann keinen Index nutzen und brauchte
        # bei sieben Tagen Minutendaten über zehn Sekunden; so sind es Millisekunden.
        seit = now - 7 * 86_400
        cb_px = {r[0] // 60: r[1] for r in con.execute(
            "SELECT ts, close FROM cb_bars WHERE coin=? AND ts > ?", (coin, seit)) if r[1]}
        hl_px = {r[0] // 60: r[1] for r in con.execute(
            "SELECT ts, close FROM bars WHERE coin=? AND ts > ?", (coin, seit)) if r[1]}
        reihe = [(c / h - 1) * 10_000 for m, c in cb_px.items()
                 for h in (hl_px.get(m),) if h and h > 0]
        if len(reihe) >= 60:
            m = sum(reihe) / len(reihe)
            sd = (sum((x - m) ** 2 for x in reihe) / max(1, len(reihe) - 1)) ** 0.5
            out["premium_mittel"] = m
            out["premium_z"] = ((out["premium_bps"] - m) / sd) if sd > 0 else 0.0
            out["premium_n"] = len(reihe)
    try:
        out["meta"] = dict(con.execute("SELECT k, v FROM cb_meta"))
    except sqlite3.OperationalError:
        out["meta"] = {}
    return out


def coinbase_cached(db: str, coin: str, perp_px: float | None) -> dict:
    """30 s Zwischenspeicher -- die Daten ändern sich minütlich, mehrere Browser sollen teilen."""
    with _CB_LOCK:
        if time.time() - _CB_CACHE["ts"] < 30 and _CB_CACHE.get("coin") == coin:
            return _CB_CACHE["data"]
    try:
        con = connect(db)
        d = load_coinbase(con, coin, perp_px)
        con.close()
    except sqlite3.Error:
        d = {"aktiv": False}
    with _CB_LOCK:
        _CB_CACHE.update(ts=time.time(), coin=coin, data=d)
    return d


def pruefe_livequellen(coin: str = "BTC", runden: int = 3) -> str:
    """
    Jeden Endpunkt der Live-Quellen einzeln anfragen und berichten, was zurückkommt.

    Im Dashboard steht bei einem Fehlschlag nur "Fehler" -- das kann heißen: Gegenstelle
    langsam, Coin dort nicht gehandelt, Schnittstelle geändert, Netz gestört. Diese
    Prüfung trennt die Fälle, indem sie jede Anfrage einzeln macht und Dauer sowie
    Antwort protokolliert. Mehrere Runden, weil Aussetzer selten sind: Ein einzelner
    erfolgreicher Versuch beweist nichts.
    """
    zeilen = [f"Live-Quellen-Prüfung für {coin} · {runden} Runden · {time.strftime('%d.%m. %H:%M:%S')}", "=" * 70]
    inst = f"{coin}USD-PERP"
    proben = [
        ("Crypto.com", "get-tickers", lambda: cdc_get("get-tickers", {"instrument_name": inst})),
        ("Crypto.com", "get-candlestick", lambda: cdc_get("get-candlestick", {"instrument_name": inst, "timeframe": "H1"})),
        ("Crypto.com", "get-trades", lambda: cdc_get("get-trades", {"instrument_name": inst, "count": 150})),
        ("Crypto.com", "get-valuations mark", lambda: cdc_get("get-valuations", {"instrument_name": inst, "valuation_type": "mark_price", "count": 1})),
        ("Crypto.com", "get-valuations index", lambda: cdc_get("get-valuations", {"instrument_name": f"{coin}USD-INDEX", "valuation_type": "index_price", "count": 1})),
        ("Crypto.com", "get-book", lambda: cdc_get("get-book", {"instrument_name": inst, "depth": 50})),
    ]
    stat: dict = {}
    for runde in range(runden):
        if runde:
            time.sleep(2)
        zeilen.append(f"\n--- Runde {runde + 1} ---")
        for quelle, name, fn in proben:
            t0 = time.time()
            try:
                d = fn()
                dauer = time.time() - t0
                menge = len(d.get("data") or []) if isinstance(d, dict) else 0
                zeilen.append(f"  [ok]     {name:<22} {dauer * 1000:6.0f} ms · {menge} Einträge")
                stat.setdefault(name, []).append(("ok", dauer))
            except Exception as e:
                dauer = time.time() - t0
                zeilen.append(f"  [FEHLER] {name:<22} {dauer * 1000:6.0f} ms · {type(e).__name__}: {e}")
                stat.setdefault(name, []).append(("fehler", dauer))
    zeilen.append("\n--- Zusammenfassung ---")
    for name, werte in stat.items():
        n_ok = sum(1 for z, _ in werte if z == "ok")
        d_max = max(d for _, d in werte)
        zeilen.append(f"  {name:<22} {n_ok}/{len(werte)} erfolgreich · langsamste Antwort {d_max * 1000:.0f} ms")
    fehlend = [n for n, w in stat.items() if not any(z == "ok" for z, _ in w)]
    zeilen.append("")
    if not fehlend:
        zeilen.append("Alle Endpunkte antworten. Treten im Dashboard trotzdem Aussetzer auf, sind es")
        zeilen.append("einzelne Zeitüberschreitungen — der Abruf wartet je Anfrage bis zu 12 Sekunden,")
        zeilen.append("und der Schnappschuss macht sechs davon nacheinander.")
    else:
        zeilen.append(f"Dauerhaft ohne Antwort: {', '.join(fehlend)}")
        if len(fehlend) == len(stat):
            zeilen.append(f"ALLE Endpunkte ohne Antwort: {coin} wird bei Crypto.com nicht als")
            zeilen.append(f"Perpetual gehandelt ({inst} existiert dort nicht). Das ist keine Störung.")
            zeilen.append("Das Dashboard merkt sich das jetzt und fragt sechs Stunden lang nicht erneut.")
        else:
            zeilen.append("Ist 'get-valuations index' darunter, gibt es für diesen Coin dort keinen Index —")
            zeilen.append("das ist kein Fehler, sondern eine Lücke des Anbieters.")
    # Bybit und OKX zum Vergleich
    zeilen.append("\n--- Vergleich ---")
    for name, fn in (("Bybit", lambda: bybit_snapshot(coin)), ("OKX", lambda: okx_snapshot(coin))):
        t0 = time.time()
        try:
            d = fn()
            zeilen.append(f"  {name:<12} {'Daten' if d else 'kein Ergebnis'} · {(time.time() - t0) * 1000:.0f} ms")
        except Exception as e:
            zeilen.append(f"  {name:<12} FEHLER {type(e).__name__}: {e}")
    return "\n".join(zeilen)


_PROFIS: dict = {"lock": threading.Lock(), "data": None, "ts": 0.0, "rang": None, "rang_stempel": None, "started": False, "fehler": None}


def _darwin_stand() -> dict:
    return hl_forecast.learned_load("*", "darwin", 10 ** 9) or {}


def _darwin(r: dict) -> dict:
    """
    Darwin-Liste (Entscheidung des Nutzers 24.09.; Regeln v2 ab 23.37, v3 ab 23.38): Entscheidung in hl_profis.darwin_tag -- einmal
    täglich (erste Bewertung nach 00 UTC) Verbleib der Mitglieder (Abstieg nach 3 Tagen in Folge ohne; die Schonung nur für streng
    Aufgenommene) und Aufnahme der übrigen; beim Umstieg und bei der Rückkehr zu Unrecht Gesperrter sofort. Stand im
    Prognosespeicher (learned, Schlüssel „*“/„darwin“).
    """
    import hl_profis
    st = hl_profis.darwin_tag(_darwin_stand(), r)
    if st.pop("_geaendert", False):
        try:
            hl_forecast.learned_save("*", "darwin", st)
        except Exception as e:
            print(f"Darwin-Liste nicht gespeichert: {e}", flush=True)
    return st


def _schatten(db: str, r: dict, mitglieder) -> None:
    """
    U136 (23.57): Schatten der Darwin-Liste -- einmal täglich (erste Bewertung nach 00 UTC; nach dem Update sofort beim ersten Lauf) erst
    die Vorwärts-Bilanz bis now − 12 h
    fortschreiben, dann die Gruppen von heute eintragen (Bänder 1/3/5 % und Kontrolle, hl_profis.schatten_tag). Eigener Stand
    (learned „*“/„darwin_schatten“); Liste, Labor und Familien lesen ihn nicht. Ein Fehler hält die Bewertung nicht an.
    """
    import hl_profis
    try:
        sch = hl_forecast.learned_load("*", "darwin_schatten", 10 ** 9) or {}
        if sch.get("tag") == int(time.time()) // 86_400:
            return
        con = connect(db)
        try:
            sch = hl_profis.schatten_entscheidungen(con, sch)
        finally:
            con.close()
        sch = hl_profis.schatten_tag(sch, r, mitglieder=mitglieder)
        if sch.pop("_geaendert", False):
            hl_forecast.learned_save("*", "darwin_schatten", sch)
    except Exception as e:
        print(f"Schatten der Darwin-Liste: {type(e).__name__}: {e}", flush=True)


def _profis_rechnen(db: str) -> None:
    """Phase 2/3: Bewertung stündlich; die Mitglieder der Liste ändern sich einmal täglich (Darwin-Liste, 23.22; Regeln v2 23.37, v3 23.38)."""
    import hl_profis
    try:
        st0 = _darwin_stand()
        mitglieder = list(st0.get("liste") or [])                       # 23.37: Mitglieder bekommen ihr Verbleib-Urteil in jedem Fall
        con = connect(db)
        r = hl_profis.bewerten(con, mitglieder=mitglieder)              # 23.38: keine Suche nach „ehemaligen“ mehr (v3: nur strenge Aufnahme)
        con.close()
    except Exception as e:
        with _PROFIS["lock"]:
            _PROFIS["fehler"] = f"{type(e).__name__}: {e}"
        return
    st = _darwin(r)
    _schatten(db, r, st.get("liste") or [])                                    # 23.57 (U136): Beinahe-Aufnahmen vorwärts
    try:                                                                       # 23.27: für den Schatten-Treiber Pool-Timing-Flow
        hl_forecast.learned_save("*", "timing_positiv", [k["addr"] for k in (r.get("alle") or [])    # 23.32: Glück ≤ 20 %, Vorsprung > 0
                                                         if ((k.get("timing") or {}).get("lift_s") or 0) > 0 and ((k.get("timing") or {}).get("p_glueck") or 1) <= 0.2])
    except Exception:
        pass
    alle_ = {k["addr"]: k for k in (r.get("alle") or [])}              # 23.23: Reihenfolge für die Echtzeit-Plätze des Recorders

    def lcb_(a):
        k = alle_.get(a) or {}; t_ = (k.get("timing") or {}).get("lcb")          # 23.32: wie in der Anzeige
        if t_ is not None:
            return t_
        el, et = k.get("exit_lift"), k.get("exit_t")
        return (el - el / et) if (el is not None and et and et > 0) else -9.0
    reihe = sorted([a for a in st.get("liste", []) if a in alle_], key=lambda a: -lcb_(a))
    if reihe != st.get("reihe"):
        st["reihe"] = reihe
        try:
            hl_forecast.learned_save("*", "darwin", st)
        except Exception:
            pass
    with _PROFIS["lock"]:
        _PROFIS["data"] = r; _PROFIS["ts"] = time.time(); _PROFIS["fehler"] = None; _PROFIS["darwin"] = st


def _kleinfill_neu(db: str) -> bool:
    """23.37: Hat der Recorder seit der letzten Bewertung Sperren neu bewertet (Zählfehler 23.34–23.36)? Dann sofort rechnen."""
    try:
        con = connect(db)
        try:
            row = con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()
        finally:
            con.close()
        if not row or not row[0]:
            return False
        return int(json.loads(row[0]).get("ts") or 0) != int(_darwin_stand().get("kleinfill_ts") or 0)
    except Exception:
        return False


def _profis_start(db: str) -> None:
    if _PROFIS["started"]:
        return
    _PROFIS["started"] = True

    def run():
        time.sleep(90)
        while True:
            _profis_rechnen(db)
            for _ in range(12):                                         # stündlich; 23.37: alle 5 min nachsehen, ob Freigaben warten
                time.sleep(300)
                if _kleinfill_neu(db):
                    break
    threading.Thread(target=run, daemon=True, name="profis").start()


def profis_payload(db: str) -> dict:
    """
    Darwin-Liste (23.22): Mitglieder täglich, Reihenfolge nach der vorsichtigen Untergrenze des Exit-Lifts (Lift minus
    Standardfehler), Kennzahlen frisch aus der stündlichen Bewertung; je Konto die letzten 30 Trades (gebündelt je Minute,
    Coin und Richtung) und eine gemeinsame Zeitleiste der jüngsten 40 Trades aller Mitglieder.
    """
    _profis_start(db)
    with _PROFIS["lock"]:
        r = _PROFIS["data"]; st = dict(_PROFIS.get("darwin") or {}); fehler = _PROFIS["fehler"]; ts = _PROFIS["ts"]
    if not r:
        return {"bereit": False, "fehler": fehler, "hinweis": "Bewertung läuft nach dem Start (90 s), danach stündlich"}
    alle = {k["addr"]: k for k in (r.get("alle") or [])}
    reihe = []; ohne_bewertung = []
    for a in (st.get("liste") or [k["addr"] for k in r["top"]]):
        k0 = alle.get(a)
        if not k0:                                                      # gesperrt oder aus dem Pool gefallen -- 23.37: mit Grund zeigen
            ohne_bewertung.append({"addr": a, "grund": (r.get("fehlend") or {}).get(a) or "nicht bewertet",
                                   "verfehlt": int((st.get("verfehlt") or {}).get(a, 0))})
            continue
        k = dict(k0)
        el, et = k.get("exit_lift"), k.get("exit_t")
        k["lcb"] = (k.get("timing") or {}).get("lcb")                       # 23.32: gedämpfte Untergrenze aller Ein-/Ausstiege
        if k["lcb"] is None:
            k["lcb"] = (el - el / et) if (el is not None and et and et > 0) else None
        k["seit_tage"] = ((ts - st["seit"][a]) / 86_400) if (st.get("seit") or {}).get(a) else None
        k["bewaehrung"] = int((st.get("verfehlt") or {}).get(a, 0))
        k["grund_tag"] = (st.get("grund") or {}).get(a)                    # 23.37: Grund des letzten Fehltags (Tagesentscheidung)
        reihe.append(k)
    reihe.sort(key=lambda k: -(k["lcb"] if k["lcb"] is not None else -9.0))
    reihe = reihe[:20]
    con = connect(db); now = int(time.time())
    preise = {c: p_ for c, p_ in con.execute("SELECT coin, close FROM bars WHERE ts >= ? GROUP BY coin HAVING ts = MAX(ts)", (now - 3600,))}
    lbl = labels_for(con, [k["addr"] for k in reihe])
    zeit = []
    for i, k in enumerate(reihe):
        # 23.35: addr=? nutzt den Primärschlüssel (addr, tid); lower(addr)=? lief rückwärts durch den ganzen Zeitindex -- bei einem
        # Konto, dessen letzte Fills Tage alt sind, durch Millionen Zeilen
        rows = con.execute("SELECT ts, coin, market, dir, side, px, sz, notional, closed_pnl FROM lb_fills WHERE addr=? ORDER BY ts DESC LIMIT 400",
                           (k["addr"],)).fetchall()
        b: dict = {}
        for ts_, coin, market, dir_, side, px, sz, notional, cp in rows:            # bündeln je Minute, Coin und Richtung
            key = (ts_ // 60, coin, market, side)
            e = b.setdefault(key, {"ts": ts_, "coin": coin, "market": market, "dir": dir_ or "", "side": side, "px": px, "notional": 0.0, "closed_pnl": 0.0})
            e["notional"] += notional or 0.0; e["closed_pnl"] += cp or 0.0; e["ts"] = max(e["ts"], ts_)
        trades = sorted(b.values(), key=lambda e: -e["ts"])[:30]
        for e in trades:
            p_now = preise.get(e["coin"])
            e["seither_pct"] = ((p_now / e["px"] - 1.0) * (1 if e["side"] == "B" else -1) * 100.0) if (p_now and e["px"]) else None
        k["trades"] = trades
        L = lbl.get(k["addr"]) or {}
        k["name"] = k.get("name") or (L.get("name") if isinstance(L, dict) else "") or ""
        k["gesperrt"] = bool(L.get("gesperrt")) if isinstance(L, dict) else False
        zeit += [dict(e, rang=i + 1, addr=k["addr"], name=k["name"]) for e in trades]
    con.close()
    zeit.sort(key=lambda e: -e["ts"])
    import hl_profis as P_
    if ohne_bewertung:                                                  # Namen aus dem Pool (die Bewertung kennt Gesperrte nicht)
        con = connect(db)
        try:
            marks = ",".join("?" * len(ohne_bewertung))
            nm = {r_[0].lower(): r_[1] for r_ in con.execute(f"SELECT addr, name FROM pool_accounts WHERE lower(addr) IN ({marks})",
                                                             [e["addr"] for e in ohne_bewertung])}
        except sqlite3.OperationalError:
            nm = {}
        finally:
            con.close()
        for e in ohne_bewertung:
            e["name"] = nm.get(e["addr"]) or ""
    sieben = int(ts) - 7 * 86_400
    return {"bereit": True, "ts": int(ts), "stempel": int(st.get("tag") or 0) * 86_400,
            "rang_basis": f"Darwin-Liste (Regeln v{P_.REGEL_VERSION}): Aufnahme streng, Verbleib großzügig -- nur für streng Aufgenommene --, "
                          "Abstieg nach 3 Tagen in Folge ohne Verbleib; "
                          "Reihenfolge nach der vorsichtigen Untergrenze des Timing-Vorsprungs",
            "regeln": {"timing_tage": P_.TIMING_TAGE, "aufnahme_p": P_.AUFNAHME_P_GLUECK, "aufnahme_n": P_.AUFNAHME_MIN_ENTSCH,
                       "aufnahme_vorsprung": P_.AUFNAHME_MIN_VORSPRUNG, "verbleib_p": P_.VERBLEIB_P_GLUECK, "verbleib_n": P_.VERBLEIB_MIN_ENTSCH,
                       "verbleib_trades": P_.VERBLEIB_MIN_TRADES, "abstieg_tage": P_.DARWIN_ABSTIEG_TAGE, "min_trades": P_.PROFI_MIN_TRADES,
                       "max_trades": P_.PROFI_MAX_TRADES, "version": P_.REGEL_VERSION},
            "ohne_bewertung": ohne_bewertung,
            "zugaenge": [e for e in (st.get("zugaenge") or []) if int(e.get("ts") or 0) >= sieben][::-1],
            "abgaenge": [e for e in (st.get("abgaenge") or []) if int(e.get("ts") or 0) >= sieben][::-1],
            "n_mitglieder": len(st.get("liste") or []), "n_verbleib": r.get("n_verbleib"),
            "n_pool": r["n_pool"], "n_gesperrt": r["n_gesperrt"], "n_aktiv": r["n_aktiv"], "n_qualifiziert": r["n_qualifiziert"],
            "quellen": r.get("quellen") or {}, "gruende": r.get("gruende") or {}, "n_mit_ereignissen": r.get("n_mit_ereignissen"),   # 23.34
            "n_liste": len(st.get("liste") or []), "coins": r["coins"], "top": reihe, "zeitleiste": zeit[:40]}

# ---------------------------------------------------------------------------
# Speicherorte (23.23, Wunsch des Nutzers): Datenbankpfad anzeigen, Backup-Pfad im Dashboard wählen. Die Einstellung liegt in
# speicherorte.json im Projektordner (von Updates nicht berührt); der Recorder liest sie vor jedem Backup-Durchgang.
# ---------------------------------------------------------------------------
SPEICHER_WURZELN = ("/media/", "/mnt/", "/home/")


def _speicher_datei() -> str:
    return os.path.join(ROOT_DIR, "speicherorte.json")


def _speicher_lesen() -> dict:
    try:
        with open(_speicher_datei(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _speicher_schreiben(d: dict) -> None:
    tmp = _speicher_datei() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1)
    os.replace(tmp, _speicher_datei())


def _medium(pfad: str) -> dict:
    """Einhängepunkt, Gerät, Dateisystem, freier Platz, fstab-Eintrag und ob es die Systemkarte (SD) ist."""
    p = os.path.abspath(pfad); q = p
    while not os.path.exists(q) and os.path.dirname(q) != q:
        q = os.path.dirname(q)
    mounts = []
    try:
        for l in open("/proc/mounts", encoding="utf-8"):
            t = l.split()
            if len(t) >= 3:
                mounts.append((t[1].replace("\\040", " "), t[0], t[2]))
    except OSError:
        pass
    mp = max((m for m in mounts if q == m[0] or q.startswith(m[0].rstrip("/") + "/")), key=lambda m: len(m[0]), default=("/", "?", "?"))
    try:
        du = shutil.disk_usage(q); frei, gesamt = du.free, du.total
    except OSError:
        frei = gesamt = None
    try:
        fstab = [l.split() for l in open("/etc/fstab", encoding="utf-8") if l.strip() and not l.lstrip().startswith("#")]
    except OSError:
        fstab = []
    try:
        dev = os.stat(q).st_dev; sd = dev == os.stat("/").st_dev
    except OSError:
        dev = None; sd = False
    return {"pfad": p, "mount": mp[0], "geraet": mp[1], "fs": mp[2], "frei": frei, "gesamt": gesamt,
            "dauerhaft": mp[0] == "/" or any(len(t) > 1 and t[1] == mp[0] for t in fstab), "systemkarte": sd}


def _groesse(p: str):
    try:
        return os.path.getsize(p)
    except OSError:
        return None


def speicher_status(db: str) -> dict:
    import hl_recorder as _R
    ein = _speicher_lesen(); meta_dir = None
    try:
        con = connect(db)
        r = con.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone(); meta_dir = r[0] if r else None
        con.close()
    except sqlite3.Error:
        pass
    gueltig = ein.get("backup_dir") or meta_dir or os.path.join(os.path.dirname(os.path.abspath(db)), "dbbackup")
    quelle = "Dashboard" if ein.get("backup_dir") else "Recorder (Startparameter/meta)" if meta_dir else "Vorgabe neben der Datenbank"
    st = _R.backup_status(gueltig) or {}
    alt = ein.get("alt") if ein.get("alt") and os.path.abspath(ein.get("alt")) != os.path.abspath(gueltig) else None
    alt_bytes = sum(_groesse(os.path.join(alt, n)) or 0 for n in _BACKUP_DATEIEN) if alt else 0
    neu_ok = bool(st.get("ok")) and float(st.get("ts") or 0) > float(ein.get("gesetzt") or 0)
    return {"db": dict(_medium(db), groesse_db=_groesse(db), groesse_prognosen=_groesse(hl_forecast.STORE), prognosen=hl_forecast.STORE),
            "backup": dict(_medium(gueltig), quelle=quelle, recorder_sieht=meta_dir, letztes=st, jetzt_ts=ein.get("jetzt_ts")),
            "alt": {"pfad": alt, "bytes": alt_bytes, "loeschbar": bool(alt and alt_bytes and neu_ok)}}


_BACKUP_DATEIEN = ("hl_liq_backup.db", "hl_liq_backup.db.1", "hl_liq_backup.db.tmp", "forecasts_backup.db", "forecasts_backup.db.1",
                   "forecasts_backup.db.tmp", "backup.json")


def speicher_ordner(pfad: str) -> dict:
    """Ordnerauswahl auf dem Pi (ein Browser kann die Ordner des Pi nicht öffnen): Wurzeln = eingehängte Medien + Home."""
    if not pfad:
        wurzeln = []
        try:
            for l in open("/proc/mounts", encoding="utf-8"):
                t = l.split()
                if len(t) >= 3 and (t[1].startswith("/media/") or t[1].startswith("/mnt/")):
                    wurzeln.append(dict(_medium(t[1]), name=t[1]))
        except OSError:
            pass
        home = os.path.expanduser("~")
        wurzeln.append(dict(_medium(home), name=home))
        return {"pfad": "", "eltern": None, "ordner": wurzeln}
    p = os.path.realpath(pfad)
    if not p.startswith(SPEICHER_WURZELN) or not os.path.isdir(p):
        return {"fehler": "Ordner nicht erlaubt oder nicht vorhanden", "pfad": p}
    try:
        namen = sorted(n for n in os.listdir(p) if not n.startswith(".") and os.path.isdir(os.path.join(p, n)))[:200]
    except OSError as e:
        return {"fehler": str(e), "pfad": p}
    eltern = os.path.dirname(p)
    return {"pfad": p, "eltern": eltern if eltern.startswith(SPEICHER_WURZELN) else "", "medium": _medium(p),
            "ordner": [{"name": n, "pfad": os.path.join(p, n)} for n in namen]}


def speicher_backup_setzen(db: str, pfad: str) -> dict:
    """Prüfen und übernehmen: erlaubter Ort, anlegbar, beschreibbar, anderes Gerät als die Datenbank, Platz für 2 Generationen."""
    import hl_recorder as _R
    p = os.path.realpath(pfad or "")
    pruef = []
    ok_ort = p.startswith(SPEICHER_WURZELN); pruef.append(["Ort", ok_ort, p if ok_ort else "nur unter /media, /mnt oder /home"])
    try:
        os.makedirs(p, exist_ok=True); ok_da = os.path.isdir(p)
    except OSError as e:
        ok_da = False; pruef.append(["anlegbar", False, str(e)])
    if ok_da:
        try:
            t = os.path.join(p, ".schreibtest"); open(t, "w").write("ok"); os.remove(t); pruef.append(["beschreibbar", True, "ja"])
        except OSError as e:
            pruef.append(["beschreibbar", False, str(e)])
        anders = not _R.same_device(os.path.dirname(os.path.abspath(db)), p)
        pruef.append(["anderes Gerät als die Datenbank", anders, "ja" if anders else "nein -- ein Backup auf demselben Medium schützt nicht vor dessen Ausfall"])
        bedarf = 2.2 * ((_groesse(db) or 0) + (_groesse(hl_forecast.STORE) or 0)); m = _medium(p)
        pruef.append(["Platz für 2 Generationen", (m["frei"] or 0) >= bedarf, f"frei {(m['frei'] or 0) / 1e9:.1f} GB, nötig {bedarf / 1e9:.1f} GB"])
        pruef.append(["dauerhaft eingehängt (fstab)", True, "ja" if m["dauerhaft"] else "NEIN -- nach einem Neustart fehlt das Laufwerk womöglich (Hinweis, kein Abbruch)"])
    ok = all(x[1] for x in pruef)
    if ok:
        ein = _speicher_lesen(); vorher = speicher_status(db)["backup"]["pfad"]
        ein.update(backup_dir=p, gesetzt=int(time.time()), alt=(vorher if os.path.abspath(vorher) != p else ein.get("alt")))
        _speicher_schreiben(ein)
    return {"ok": ok, "pruefungen": pruef, "msg": "Übernommen -- gilt ab dem nächsten Backup, der Recorder schaut binnen Sekunden nach."
            if ok else "Nicht übernommen -- siehe Prüfungen."}


def speicher_jetzt() -> dict:
    ein = _speicher_lesen(); ein["jetzt_ts"] = int(time.time()); _speicher_schreiben(ein)
    return {"ok": True, "msg": "Backup angestoßen -- der Recorder beginnt binnen etwa 10 s; die Sicherung selbst dauert einige Minuten."}


def speicher_alt_loeschen(db: str) -> dict:
    s_ = speicher_status(db)
    if not s_["alt"]["loeschbar"]:
        return {"ok": False, "msg": "Noch nicht: erst nach einem erfolgreichen Backup am neuen Ort."}
    frei = 0
    for n in _BACKUP_DATEIEN:
        p = os.path.join(s_["alt"]["pfad"], n)
        if os.path.isfile(p):
            frei += _groesse(p) or 0; os.remove(p)
    ein = _speicher_lesen(); ein.pop("alt", None); _speicher_schreiben(ein)
    return {"ok": True, "msg": f"{frei / 1e9:.1f} GB freigegeben in {s_['alt']['pfad']}."}


def konfluenz_loggen(qq: dict) -> dict:
    """24.09.: eine Konfluenz-Meldung des Browsers speichern (je Coin und 15 min die erste)."""
    g = lambda k: (qq.get(k) or [""])[0]
    def zahl(k):
        v = g(k)
        try:
            return float(v) if v not in ("", "null", "undefined", "NaN") else None
        except ValueError:
            return None
    coin = g("coin").upper()
    if not re.match(r"^[A-Z0-9]{2,12}$", coin) or not zahl("px"):
        return {"ok": False}
    now = int(time.time())
    try:
        st = hl_forecast.store_connect(hl_forecast.STORE)
        st.execute("CREATE TABLE IF NOT EXISTS konfluenz_log (coin TEXT, slot INTEGER, ts INTEGER, label TEXT, net REAL, dir TEXT, "
                   "zone_kind TEXT, zone_bot REAL, zone_top REAL, zone_text TEXT, px REAL, PRIMARY KEY (coin, slot))")
        st.execute("INSERT OR IGNORE INTO konfluenz_log VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                   (coin, now // 900, now, g("label")[:40], zahl("net"), g("dir")[:4], g("zk")[:4], zahl("zb"), zahl("zt"), g("ztx")[:60], zahl("px")))
        st.commit(); st.close()
        return {"ok": True}
    except sqlite3.Error as e:
        return {"ok": False, "fehler": str(e)}


# ---------------------------------------------------------------------------
# Treiberfamilien (23.25): Bericht je Coin (10 min zwischengespeichert) und ein 15-min-Takt, der den Profi-Flow der
# Darwin-Liste aufzeichnet und alle 6 h die Wochenstufen der Familien fortschreibt.
# ---------------------------------------------------------------------------
_FAM: dict = {"cache": {}, "lock": threading.Lock(), "gestartet": False}


def _ohne_nan(o):
    if isinstance(o, float):
        return None if (o != o or o in (float("inf"), float("-inf"))) else o
    if isinstance(o, dict):
        return {str(k): _ohne_nan(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_ohne_nan(v) for v in o]
    return o


_ANK: dict = {"cache": {}, "lock": threading.Lock()}


def anker_payload(db: str, coin: str) -> bytes:
    """23.28: aktueller Heatmap-Anker (5 min zwischengespeichert) und Hinweis, wenn ein starkes Cluster gegen den Bias steht."""
    import hl_anker
    with _ANK["lock"]:
        c = _ANK["cache"].get(coin)
        if c and time.time() - c[0] < 300:
            return c[1]
    con = connect(db)
    try:
        d = hl_anker.jetzt(con, coin)
    except Exception as e:
        d = {"coin": coin, "fehler": f"{type(e).__name__}: {e}"}
    finally:
        con.close()
    try:
        st = hl_forecast.store_connect(hl_forecast.STORE)
        r = st.execute("SELECT bias FROM forecast WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone(); st.close()
        bias = float(r[0]) if r and r[0] is not None else None
    except sqlite3.Error:
        bias = None
    d["bias"] = bias; d["gegen_bias"] = None
    A = d.get("A")
    if A is not None and bias is not None and abs(A) >= 0.5 and abs(bias) >= 0.1 and (A > 0) != (bias > 0):
        dom = d.get("oben") if A > 0 else d.get("unten")
        if dom and (dom.get("anteil_volumen") or 0) >= 0.25:
            usd_ = dom["usd"]; betrag = f"{usd_ / 1e6:.1f} Mio" if usd_ >= 1e6 else f"{usd_ / 1e3:.0f}k"
            d["gegen_bias"] = (f"Starkes Cluster gegen den Bias ({'bullisch' if bias > 0 else 'bärisch'} {bias:+.2f}): {betrag} "
                               f"{'Short' if A > 0 else 'Long'}-Liquidationen {dom['abstand_sigma']:.1f} σ {'über' if A > 0 else 'unter'} dem Kurs")
    body = json.dumps(_ohne_nan(d), default=float).encode()
    with _ANK["lock"]:
        _ANK["cache"][coin] = (time.time(), body)
    return body


def familien_payload(db: str, coin: str) -> bytes:
    import hl_familien
    familien_start(db)
    with _FAM["lock"]:
        c = _FAM["cache"].get(coin)
        if c and time.time() - c[0] < 600:
            return c[1]
    con = connect(db)
    try:
        b = hl_familien.bericht(con, coin)
    except Exception as e:
        b = {"coin": coin, "bereit": False, "hinweis": f"Fehler: {type(e).__name__}: {e}"}
    finally:
        con.close()
    body = json.dumps(_ohne_nan(b), default=float).encode()
    with _FAM["lock"]:
        _FAM["cache"][coin] = (time.time(), body)
    return body


def _familien_takt(db: str) -> None:
    import hl_familien
    letzte = 0; letzte_anker = time.time() - 86_400 + 600              # 23.28: Anker-Bilanz täglich, erstmals 10 min nach dem Start
    letzte_v3 = time.time() - 3600 + 300                                # 23.42: Kalibrierung v3 stündlich, erstmals 5 min nach dem Start
    letzte_kaskade = time.time() - 6 * 3600 + 900                       # 23.43: Kaskaden-Gleichung alle 6 h, erstmals 15 min nach dem Start
    letzte_magnet = time.time() - 6 * 3600 + 1200                       # 23.45: Magnet-Test alle 6 h, erstmals 20 min nach dem Start
    while True:
        try:
            now = int(time.time())
            st = hl_forecast.store_connect(hl_forecast.STORE)
            st.execute("CREATE TABLE IF NOT EXISTS familien_log (coin TEXT, slot INTEGER, ts INTEGER, familie TEXT, value REAL, "
                       "PRIMARY KEY (coin, familie, slot))")
            coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ?", (now - 86_400,))]
            try:
                r = st.execute("SELECT value FROM learned WHERE coin='*' AND key='darwin'").fetchone()
                liste = [str(a).lower() for a in ((json.loads(r[0]) if r and r[0] else {}).get("liste") or [])]
            except (sqlite3.Error, ValueError):
                liste = []
            con = connect(db)
            for c in coins:
                st.execute("INSERT OR REPLACE INTO familien_log VALUES (?,?,?,?,?)", (c, now // 900, now, "Profi-Flow", hl_familien.profi_jetzt(con, c, liste, now)))
            st.commit(); st.close()
            if now - letzte >= 6 * 3600:
                letzte = now
                for c in coins:
                    try:
                        hl_familien.bericht(con, c)             # schreibt die Wochenstufen fort (ändert sie nur beim Wochenwechsel)
                    except Exception as e:
                        print(f"Treiberfamilien {c}: {type(e).__name__}: {e}", flush=True)
            if now - letzte_anker >= 86_400:
                letzte_anker = now
                import hl_anker
                for c in coins:
                    try:
                        hl_anker.bilanz(con, c)                          # speichert learned coin/„anker_bilanz“
                    except Exception as e:
                        print(f"Heatmap-Anker {c}: {type(e).__name__}: {e}", flush=True)
            if now - letzte_v3 >= 3600:
                letzte_v3 = now
                try:
                    import hl_fusion
                    hl_fusion.v3_takt(con)                               # speichert learned */„kalib3_4“, „kalib3_24“ (Fehler sichtbar)
                except Exception as e:
                    print(f"Kalibrierung v3: {type(e).__name__}: {e}", flush=True)
            if now - letzte_kaskade >= 6 * 3600:
                letzte_kaskade = now
                try:
                    import hl_kaskade
                    hl_kaskade.takt(con)                                 # speichert learned coin/„kaskade“ (Y, c, Bilanz, Placebo, Seitenspiegel)
                except Exception as e:
                    print(f"Kaskaden-Gleichung: {type(e).__name__}: {e}", flush=True)
            if now - letzte_magnet >= 6 * 3600:
                letzte_magnet = now
                try:
                    import hl_magnet
                    hl_magnet.takt(con)                                  # speichert learned coin/„magnet“ (Überschuss je Klasse, Spiegel, Placebo)
                except Exception as e:
                    print(f"Magnet-Test: {type(e).__name__}: {e}", flush=True)
            con.close()
        except Exception as e:
            print(f"Treiberfamilien-Takt: {type(e).__name__}: {e}", flush=True)
        time.sleep(900)


def familien_start(db: str) -> None:
    if _FAM["gestartet"] or os.path.basename(db).startswith("_selftest"):
        return
    _FAM["gestartet"] = True
    threading.Thread(target=_familien_takt, args=(db,), daemon=True, name="familien").start()


# ---------------------------------------------------------------------------
# 23.33 TradeLabor (Wunsch des Nutzers 27.09.): simulierter Handel mit allen verarbeiteten Daten, Takt 15 s im Hintergrund
# (hl_labor.Labor), Stand im Prognosespeicher (Tabellen labor_*). Wirkt auf nichts anderes: keine Order, kein Gewicht, keine
# Prognose. Anzeige im Abschnitt „TradeLabor“; Aus mit HL_LABOR=0.
# ---------------------------------------------------------------------------
_LAB: dict = {"lock": threading.Lock(), "labor": None, "gestartet": False, "fehler": None, "cache": {}, "letzter": None}


def _labor_takt(db: str) -> None:
    import hl_labor
    time.sleep(30)                                                  # erst Dashboard und Prognose anlaufen lassen
    try:
        L = hl_labor.Labor(db, hl_forecast.STORE)
    except Exception as e:
        _LAB["fehler"] = f"Start: {type(e).__name__}: {e}"
        print(f"TradeLabor: {_LAB['fehler']}", flush=True)
        return
    _LAB["labor"] = L
    while True:
        t0 = time.time()
        try:
            _LAB["letzter"] = L.zyklus(); _LAB["fehler"] = None
        except Exception as e:
            _LAB["fehler"] = f"{time.strftime('%d.%m. %H:%M:%S')} {type(e).__name__}: {e}"
            print(f"TradeLabor-Takt: {_LAB['fehler']}", flush=True)
        time.sleep(max(2.0, hl_labor.TAKT_S - (time.time() - t0)))


def labor_start(db: str) -> None:
    if _LAB["gestartet"] or os.path.basename(db).startswith("_selftest") or os.environ.get("HL_LABOR") == "0":
        return
    _LAB["gestartet"] = True
    threading.Thread(target=_labor_takt, args=(db,), daemon=True, name="labor").start()


def makro_start(db: str) -> None:
    """23.47 Makro-Chart (U121): Takt im Hintergrund (hl_makro.starten -- nicht für Selbsttest-Datenbanken, aus mit HL_MAKRO=0)."""
    try:
        import hl_makro
        if hl_makro.starten(db):
            print(f"Makro-Takt gestartet: {hl_makro.makro_pfad(db)}", flush=True)
    except Exception as e:
        print(f"Makro-Takt: {type(e).__name__}: {e}", flush=True)


def makro_live(db: str) -> dict | None:
    """Live-Kurs BTC für die Zonenkarte („jetzt“): jüngste Kerze der Hauptdatenbank, höchstens 15 min alt (nur lesen)."""
    try:
        con = connect(db)
        try:
            r = con.execute("SELECT ts, close FROM bars WHERE coin='BTC' ORDER BY ts DESC LIMIT 1").fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        return None
    if not r or not r[1] or time.time() - float(r[0]) > 900:
        return None
    return {"btc": float(r[1]), "ts": int(r[0])}


def makro_fred_schluessel(handler) -> dict:
    """
    23.48: POST /makro/fred_schluessel mit Körper {"schluessel": "..."} (höchstens 1 kB) aus dem Tab „Daten“: prüfen, in
    accesstokens.json eintragen, FRED-Pausen zurücksetzen (hl_makro.fred_schluessel_einrichten). Der Schlüssel steht nie in der
    Adresse (Protokolle, Verlauf) und nie in der Antwort. Schutz wie alle POST-Aufrufe (_post_erlaubt).
    """
    k = ""
    try:
        n = int(handler.headers.get("Content-Length") or 0)
        if n <= 0 or n > 1024:
            return {"ok": False, "meldung": "Anfrage leer oder zu groß."}
        d = json.loads(handler.rfile.read(n).decode("utf-8", "replace"))
        k = str((d or {}).get("schluessel") or "") if isinstance(d, dict) else ""
        import hl_makro
        ok, meldung = hl_makro.fred_schluessel_einrichten(k, hl_makro.makro_pfad(handler.db))
        if ok:
            with _RESP["lock"]:                                            # Tab „Daten“ nicht 60 s aus dem Antwort-Cache
                for key_ in [x for x in _RESP["items"] if x.startswith("/makro")]:
                    _RESP["items"].pop(key_, None)
        return {"ok": bool(ok), "meldung": meldung}
    except Exception as e:
        text = f"{type(e).__name__}: {e}"
        return {"ok": False, "meldung": (text.replace(k, "***") if k else text)[:200]}


def labor_payload(db: str, was: str, qq: dict) -> bytes:
    """/labor (Übersicht + Signaltafel), /labor/daten?coin=, /labor/chart?coin=&sid=&h=, /labor/trades?sid=&coin=&n=, /labor/equity."""
    import hl_labor
    arg = lambda k, d="": (qq.get(k) or [d])[0]
    key = (was, arg("coin"), arg("sid"), arg("h"), arg("n"))
    ttl = {"": 5, "daten": 5, "chart": 15, "trades": 15, "equity": 30}.get(was, 10)
    with _LAB["lock"]:
        c = _LAB["cache"].get(key)
        if c and time.time() - c[0] < ttl:
            return c[1]
    L = _LAB.get("labor"); now = int(time.time())
    coin = (arg("coin", "BTC") or "BTC").upper()[:12]; sid = arg("sid")[:80]
    try:
        if was == "":
            preise = {c_: ((v.get("E") or {}).get("preis") or {}) for c_, v in list(L.letzte.items())} if L else {}
            d = hl_labor.uebersicht(hl_forecast.STORE, preise, now)
            d["live"] = hl_labor.live(L, now) if L else None
            d["takt"] = {"gestartet": _LAB["gestartet"], "laeuft": L is not None, "fehler": _LAB.get("fehler"), "takt_s": hl_labor.TAKT_S,
                         "aus": os.environ.get("HL_LABOR") == "0", "selbsttest": os.path.basename(db).startswith("_selftest")}
            d["hebel"] = list(hl_labor.HEBEL); d["liq_schwelle"] = hl_labor.LIQ_SCHWELLE
        elif was == "daten":
            v = (L.letzte.get(coin) or {}) if L else {}
            d = {"coin": coin, "ts": v.get("ts"), "zeilen": hl_labor.datenfluss(v.get("E"), L.strategien if L else hl_labor.strategien(), now)}
        elif was == "chart":
            d = hl_labor.chart(db, hl_forecast.STORE, coin, sid or None, _grenze(arg("h", "24"), 6, 168, 24), now)
        elif was == "trades":
            d = {"trades": hl_labor.trades(hl_forecast.STORE, sid or None, arg("coin").upper()[:12] or None, _grenze(arg("n", "150"), 10, 500, 150))}
        elif was == "equity":
            d = hl_labor.equity(hl_forecast.STORE, now)
        else:
            d = {"fehler": "unbekannt"}
    except Exception as e:
        d = {"fehler": f"{type(e).__name__}: {e}"}
    body = json.dumps(_ohne_nan(d), default=float).encode()
    with _LAB["lock"]:
        _LAB["cache"][key] = (time.time(), body)
        if len(_LAB["cache"]) > 64:
            _LAB["cache"].pop(min(_LAB["cache"], key=lambda k: _LAB["cache"][k][0]), None)
    return body


def pool_vorschau(db: str, win: str = "roi_7d", n: int = 500) -> dict:
    """Aktive Profis, Vorschau: die 20 Pool-Konten mit der besten ROI laut Hyperliquid (Phase 1, ohne Phase-2-Prüfungen)."""
    win = win if win in ("roi_7d", "roi_1d", "roi_30d", "pnl_7d") else "roi_7d"
    out = {"win": win, "rows": [], "n_pool": 0, "stand": None}
    try:
        con = connect(db)
        now = int(time.time())
        cols = {r[1] for r in con.execute("PRAGMA table_info(pool_accounts)")}
        if not cols:
            con.close(); return out
        hat_tag = "roi_1d" in cols
        sel = "addr, name, account_value, vlm_1d, vlm_7d, pnl_7d, roi_7d, seit, aktualisiert" + (", pnl_1d, roi_1d, pnl_30d, roi_30d" if hat_tag else ", NULL, NULL, NULL, NULL")
        order = win if (hat_tag or win in ("roi_7d", "pnl_7d")) else "roi_7d"
        rows = con.execute(f"SELECT {sel} FROM pool_accounts WHERE zuletzt_erfuellt >= ? ORDER BY {order} DESC LIMIT ?",
                           (now - 7 * 86400, int(n))).fetchall()
        out["n_pool"] = con.execute("SELECT COUNT(*) FROM pool_accounts WHERE zuletzt_erfuellt >= ?", (now - 7 * 86400,)).fetchone()[0]
        out["stand"] = con.execute("SELECT MAX(aktualisiert) FROM pool_accounts").fetchone()[0]
        lbl = labels_for(con, [r[0] for r in rows]) if "labels_for" in globals() else {}
        # Trades/Tag aus dem Stundenaggregat (Phase 1), sobald vorhanden
        tpd = {}; std = 0
        try:
            std = con.execute("SELECT COUNT(DISTINCT stunde) FROM pool_fills_hourly WHERE stunde >= ?", (now - 24 * 3600,)).fetchone()[0]
            for a, n in con.execute("SELECT lower(addr), SUM(n_trades) FROM pool_fills_hourly WHERE stunde >= ? GROUP BY 1", (now - 24 * 3600,)):
                tpd[a] = round(n * 24 / max(std, 1))
        except sqlite3.OperationalError:
            pass
        out["trades_stunden"] = int(std or 0)                        # Abdeckung: aus wie vielen der letzten 24 Stunden stammen die Trades/T
        for r in rows:
            av = r[2] or 0.0
            l_ = lbl.get(r[0].lower()) or {}
            out["rows"].append({"addr": r[0], "name": r[1] or (l_.get("name") if isinstance(l_, dict) else "") or "", "account_value": av, "vlm_1d": r[3], "vlm_7d": r[4],
                                "behavior": (l_.get("behavior") if isinstance(l_, dict) else "") or "", "gesperrt": bool(l_.get("gesperrt")) if isinstance(l_, dict) else False,
                                "pnl_7d": r[5], "roi_7d": r[6], "seit": r[7], "pnl_1d": r[9], "roi_1d": r[10], "pnl_30d": r[11], "roi_30d": r[12],
                                "umschlag": (r[4] or 0) / av if av else None, "trades_tag": tpd.get(r[0].lower())})
        con.close()
    except sqlite3.Error as e:
        out["fehler"] = str(e)
    with _PROFIS["lock"]:                                               # 23.21: warum (nicht) qualifiziert -- aus der stündlichen Bewertung
        alle_ = {str(k.get("addr", "")).lower(): k for k in ((_PROFIS.get("data") or {}).get("alle") or [])}
    for r_ in out.get("rows") or []:
        k_ = alle_.get(str(r_.get("addr", "")).lower())
        if k_ is None:
            r_["status"] = None
        elif k_.get("mitglied"):                                       # 23.37: Mitglieder nach der Verbleib-Regel
            r_["status"] = "auf der Darwin-Liste · " + ("Verbleib erfüllt" if k_.get("verbleib") else "Verbleib verfehlt: " + "; ".join(k_.get("gruende_verbleib") or []))
        else:
            r_["status"] = "aufnahmefähig" if k_.get("aufnahme") else ("; ".join(k_.get("gruende") or []) or "nicht bewertet")
    return out


def network_ext(db: str, hours: int = 3) -> dict:
    """
    Datenströme der Fremdbörsen: gespeicherte Zeilen je Minute je Börse (kein Gewichtsbudget wie
    bei Hyperliquid, aber der Fluss ist messbar). Binance = Liquidations-Stream + Kennzahlen +
    Orderbuch; Bybit/OKX = Liquidationen + Kennzahlen; Crypto.com = Kennzahlen; Coinbase = Kerzen +
    Buch. Dazu je Börse Summe je Stunde, Alter der jüngsten Zeile und die Zähler des Sammlers.
    """
    now = int(time.time()); since = now - hours * 3600
    quellen = (("Binance", "bnc_liquidations", None), ("Binance", "bnc_metrics", None), ("Binance", "bnc_book", None),
               ("Bybit", "ext_liquidations", "bybit"), ("Bybit", "ext_metrics", "bybit"),
               ("OKX", "ext_liquidations", "okx"), ("OKX", "ext_metrics", "okx"),
               ("Crypto.com", "ext_metrics", "cdc"),
               ("Coinbase", "cb_bars", None), ("Coinbase", "cb_book", None))
    out = {"minutes": [], "series": {}, "totals": {}, "last": {}, "fehler": None}
    try:
        con = connect(db)
        minuten = list(range(since // 60 * 60, now // 60 * 60 + 60, 60))
        idx = {m: i for i, m in enumerate(minuten)}
        series = {}
        for name, tab, ex in quellen:
            arr = series.setdefault(name, [0] * len(minuten))
            try:
                if ex:
                    rows = con.execute(f"SELECT (ts/60)*60, COUNT(*) FROM {tab} WHERE exchange=? AND ts>=? GROUP BY 1", (ex, since)).fetchall()
                    mx = con.execute(f"SELECT MAX(ts) FROM {tab} WHERE exchange=?", (ex,)).fetchone()[0]
                else:
                    rows = con.execute(f"SELECT (ts/60)*60, COUNT(*) FROM {tab} WHERE ts>=? GROUP BY 1", (since,)).fetchall()
                    mx = con.execute(f"SELECT MAX(ts) FROM {tab}").fetchone()[0]
            except sqlite3.OperationalError:
                continue                                    # Tabelle noch nicht vorhanden (Dienst nie gelaufen)
            for m, n in rows:
                i = idx.get(int(m))
                if i is not None:
                    arr[i] += n
            if mx:
                out["last"][name] = max(out["last"].get(name, 0), int(mx))
        out["minutes"] = minuten
        out["series"] = series
        out["totals"] = {k: sum(v[-60:]) for k, v in series.items()}   # letzte Stunde
        try:
            meta = dict(con.execute("SELECT k, v FROM meta"))
            st = json.loads(meta.get("bnc_stats") or "{}")
            out["sammler"] = {k: st.get(k) for k in ("ext_fehler", "ext_db_locked", "ext_db_retry", "ext_bybit_ws_events", "ext_bybit_ws_reconnects", "events", "stored")}
            out["sammler"]["letzter_fehler"] = meta.get("ext_letzter_fehler") or ""
        except (sqlite3.OperationalError, ValueError):
            pass
        con.close()
    except sqlite3.Error as e:
        out["fehler"] = str(e)
    return out


def network_status(db: str, hours: int = 3) -> dict:
    """
    Alles, was den Netzverkehr betrifft, an einer Stelle: verbrauchtes API-Gewicht je Minute
    und Verbraucher, der Zeitplan aller wiederkehrenden Aufgaben mit letzter und nächster
    Ausführung, der Stand der Ratengrenze und aufgetretene Fehler.

    Vorher war das über ein Dutzend Stellen im Dashboard verteilt -- eine Kachel hier, eine
    Zeile dort -- und der Zeitplan gar nicht sichtbar. Wer wissen wollte, wann die Fills das
    nächste Mal laufen, musste den Quelltext lesen.
    """
    out = {"load": [], "quellen": [], "jobs": {}, "limit": {}, "errors": {}, "forecast": {}}
    try:
        con = connect(db)
    except sqlite3.Error as e:
        out["fehler"] = str(e)
        return out
    now = int(time.time())
    try:
        rows = con.execute("SELECT ts, quelle, weight FROM api_load WHERE ts >= ? ORDER BY ts",
                           (now - hours * 3600,)).fetchall()
        quellen = sorted({r["quelle"] for r in rows})
        je_minute: dict = {}
        for r in rows:
            je_minute.setdefault(r["ts"], {})[r["quelle"]] = r["weight"]
        out["quellen"] = quellen
        out["load"] = [{"ts": t, **{q: je_minute[t].get(q, 0) for q in quellen}} for t in sorted(je_minute)]
    except sqlite3.OperationalError:
        pass
    try:
        meta = dict(con.execute("SELECT k, v FROM meta"))
    except sqlite3.Error:
        meta = {}
    for schluessel, ziel in (("jobs", "jobs"), ("task_errors", "errors"), ("adressstrom", "af"), ("darwin_fills", "dwf")):   # 23.34 dwf
        try:
            out[ziel] = json.loads(meta.get(schluessel) or "{}")
        except ValueError:
            out[ziel] = {}
    out["limit"] = {"used": int(meta.get("api_weight_1m") or 0),
                    "budget": int(meta.get("api_weight_budget") or 1200),          # effektiver Deckel des Recorders (90 %, thermisch skaliert)
                    "limit": int(meta.get("api_weight_limit") or 1200),           # hartes API-Limit
                    "ts": int(meta.get("api_weight_ts") or 0),
                    "rate_limited": int(meta.get("rate_limited") or 0),
                    "alive": int(meta.get("recorder_alive") or 0),
                    "thermal_level": int(meta.get("thermal_level") or 0),
                    "thermal_temp": meta.get("thermal_temp"),
                    "interval_factor": float(meta.get("thermal_interval_factor") or 1),
                    "poller_batch": int(meta.get("poller_batch") or 0),
                    "poller_pool_anteil": float(meta.get("poller_pool_anteil")) if meta.get("poller_pool_anteil") not in (None, "") else None,
                    "pool_konten": int(meta.get("pool_konten") or 0),
                    "gesperrt": int(meta.get("gesperrt") or 0),
                    "poller_want": int(meta.get("poller_want") or 0),
                    "deferred": int(meta.get("lb_fills_deferred") or 0),
                    "db_locked": int(meta.get("db_locked") or 0),
                    "poller_drossel": float(meta.get("poller_drossel") or 1),
                    "stream_fills_min": int(meta.get("stream_fills_min") or 0), "stream_fills_konten": int(meta.get("stream_fills_konten") or 0),
                    "stream_fills_10min": int(meta.get("stream_fills_10min") or 0), "stream_fills_total": int(meta.get("stream_fills_total") or 0),
                    "stream_trades_min": int(meta.get("stream_trades_min") or 0),
                    "fills_takt_s": int(meta.get("fills_takt_s") or 0), "lb_takt_s": int(meta.get("lb_takt_s") or 0)}
    # Abholstand der Fills -- nur Konten der AKTUELLEN Auswahl: Stände ausgeschiedener Konten
    # veralten für immer, ohne dass etwas fehlt; sie zählten bisher mit (33 statt 25 im Rückstand).
    try:
        c = [r[0] or 0 for r in con.execute(
            """SELECT c.ts FROM lb_cursor c JOIN lb_accounts a ON a.addr = c.addr
               WHERE a.ts = (SELECT MAX(ts) FROM lb_accounts)""")]
        if c:
            r = sorted((now - t) / 3600 for t in c)
            out["limit"]["fills_lag"] = {"n": len(r), "median_h": r[len(r) // 2], "max_h": r[-1],
                                         "hinten": sum(1 for x in r if x > 3)}
    except sqlite3.OperationalError:
        pass
    # Quellen-Übersicht: NICHT aus Selbstauskünften der Dienste, sondern aus dem Alter
    # der Daten selbst. So erscheint auch eine Quelle, die gar nichts meldet -- und eine,
    # die meldet, aber nichts mehr schreibt, fällt auf.
    quellen = []

    def alter(tab: str, spalte: str = "ts", wo: str = "") -> int | None:
        try:
            r = con.execute(f"SELECT MAX({spalte}) FROM {tab} {wo}").fetchone()[0]
        except sqlite3.OperationalError:
            return None
        if not r:
            return None
        return now - (int(r) // 1000 if r > 1e11 else int(r))

    def zeilen_pro_stunde(tabellen: list) -> int:
        """Wie viele Datensätze hat diese Quelle in der letzten Stunde geschrieben?"""
        n = 0
        for t in tabellen:
            try:
                probe = con.execute(f"SELECT MAX(ts) FROM {t}").fetchone()[0]
                teiler = 1000 if probe and probe > 1e11 else 1        # 1e11 trennt Sekunden (max 5138) von Millisekunden sicher
                n += con.execute(f"SELECT COUNT(*) FROM {t} WHERE ts > ?",
                                 ((now - 3600) * teiler,)).fetchone()[0]
            except sqlite3.OperationalError:
                continue
        return n

    # Die Zähler jeder Quelle. Ohne sie stand bei den Diensten nur, wer sie liefert --
    # aber nicht, ob sie viel oder wenig tun, und ob dabei Fehler auftreten.
    def zaehler_hl() -> str:
        gewicht = int(meta.get("api_weight_1m") or 0)
        budget = int(meta.get("api_weight_budget") or 1200)
        r429 = int(meta.get("rate_limited") or 0)
        return (f"Recorder-Dienst · {gewicht}/{budget} Gewicht je Minute "
                f"({gewicht / max(budget, 1) * 100:.0f} % des Deckels) · {r429} abgewiesen (429)")

    def zaehler_bnc() -> str:
        try:
            st = json.loads(meta.get("bnc_stats") or "{}")
        except ValueError:
            st = {}
        teile = [f"{k} {v:,}" for k, v in st.items() if isinstance(v, int)]
        # Der Liquidations-Stream getrennt: Die Zeile wäre sonst auch dann "grün", wenn nur noch
        # die 10-min-Abfrage des Open Interest schreibt (6 Symbole x 6 = 36 Zeilen je Stunde) und
        # der Stream still gestorben ist. Bei BTC/ETH sind null Liquidationen in einer Stunde unwahrscheinlich.
        try:
            r = con.execute("SELECT MAX(ts), SUM(ts > ?) FROM bnc_liquidations", (now - 3600,)).fetchone()
            if r and r[0]:
                alt_min = (now - r[0]) / 60
                liq = f"Liquidationen: {int(r[1] or 0)}/h, letzte vor {alt_min:.0f} min" + (" — STREAM PRÜFEN (Journal hl-binance)" if alt_min > 120 else "")
            else:
                liq = "Liquidationen: noch keine"
        except sqlite3.OperationalError:
            liq = ""
        return "Dienst hl-binance" + (" · " + " · ".join(teile[:3]) if teile else "") + (" · " + liq if liq else "")

    def zaehler_cb() -> str:
        try:
            m = dict(con.execute("SELECT k, v FROM cb_meta"))
            st = json.loads(m.get("stats") or "{}")
        except (sqlite3.OperationalError, ValueError):
            m, st = {}, {}
        teile = []
        if st.get("ticks"):
            teile.append(f"{st['ticks']:,} Ticks")
        if st.get("books"):
            teile.append(f"{st['books']:,} Buch-Abrufe")
        if st.get("reconnects"):
            teile.append(f"{st['reconnects']} Neuverbindungen")
        teile.append(f"{st.get('errors', 0)} Fehler")
        return ("Dienst hl-coinbase" + (f" ({m.get('products', '')})" if m.get("products") else "")
                + (" · " + " · ".join(teile) if teile else ""))

    def zaehler_ext() -> str:
        try:
            st = json.loads(meta.get("bnc_stats") or "{}")
        except ValueError:
            st = {}
        teile = []
        try:
            teile = [f"{e} {n} Coins" for e, n in con.execute("SELECT exchange, COUNT(DISTINCT coin) FROM ext_metrics WHERE ts > ? GROUP BY exchange", (now - 3600,))]
            liq = [f"{e} {n}" for e, n in con.execute("SELECT exchange, COUNT(*) FROM ext_liquidations WHERE ts > ? GROUP BY exchange", (now - 3600,))]
            if liq:
                teile.append("Liquidationen/h: " + ", ".join(liq))
        except sqlite3.OperationalError:
            pass
        if st.get("ext_fehler") is not None:
            teile.append(f"Fehler {st.get('ext_fehler')} · DB-Sperre: {st.get('ext_db_retry', 0)} wiederholt, {st.get('ext_db_locked', 0)} verloren")
        return "Sammler im Dienst hl-binance (alle 5 min; Liquidationen live/2 min)" + (" · " + " · ".join(teile) if teile else "")

    for name, tabellen, erwartet, zaehler in (
            ("Hyperliquid", ["bars", "heatmap", "trigger_orders", "whale_positions"], 300, zaehler_hl),
            ("Binance", ["bnc_bars", "bnc_metrics", "bnc_liquidations"], 900, zaehler_bnc),
            ("Coinbase", ["cb_bars", "cb_book"], 300, zaehler_cb),
            ("Bybit/OKX/Crypto.com gespeichert", ["ext_metrics", "bnc_book", "ext_liquidations"], 900, zaehler_ext)):
        werte = [a for a in (alter(t) for t in tabellen) if a is not None]
        try:
            hinweis = zaehler()
        except Exception:
            hinweis = name
        if not werte:
            quellen.append({"name": name, "status": "fehlt",
                            "hinweis": hinweis.split(" · ")[0] + " nicht eingerichtet"})
            continue
        j = min(werte)
        quellen.append({"name": name, "alter_s": j, "erwartet_s": erwartet,
                        "status": "ok" if j <= erwartet else "still",
                        "hinweis": f"{zeilen_pro_stunde(tabellen):,} Datensätze/h · {hinweis}",
                        "tabellen": {t: alter(t) for t in tabellen}})
    with _EXT_LOCK:
        for name, e in sorted(_EXT_CALLS.items()):
            quote = (e.get("fehler", 0) / max(e.get("n", 1), 1)) * 100
            zustand = "ok" if e.get("ok") else "fehler"
            if e.get("ok") and e.get("fehler"):
                zustand = "wackelig" if quote >= 10 else "ok"
            ohne = sorted(e.get("ohne") or [])
            quellen.append({"name": name, "alter_s": now - e.get("ts", now),
                            "erwartet_s": None, "erwartet_txt": "beim Chart-Abruf", "status": zustand,   # U42
                            "hinweis": f"live beim Chart-Abruf · {e.get('n', 0)} Abrufe, "
                                       f"{e.get('fehler', 0)} Fehlschläge ({quote:.0f} %) · "
                                       f"zuletzt {e.get('dauer', '?')} s"
                                       + (f" · dort nicht gelistet: {', '.join(ohne)}" if ohne else "")
                                       + (f" · letzter Grund ({e.get('grund_coin', '?')}): {e['grund']}"
                                          if e.get("grund") else "")})
    # ACHTUNG: NICHT "quellen" -- diesen Schlüssel belegt bereits die Liste der
    # Gewichtsverbraucher für das Chart (Zeichenketten). Ihn hier mit Objekten zu
    # überschreiben hat das Chart geleert und "[object Object]" in die Legende geschrieben.
    out["datenquellen"] = quellen

    # Binance meldet sich über die gemeinsame meta-Tabelle
    try:
        for k, v in json.loads(meta.get("bnc_jobs") or "{}").items():
            out["jobs"][k] = v
        out["limit"]["bnc_alive"] = int(meta.get("bnc_alive") or 0)
        wl = {}
        for k in ("wlock_recorder", "wlock_binance"):
            try:
                v = json.loads(meta.get(k) or "{}")
                if v:
                    wl[k.split("_", 1)[1]] = {kk: v.get(kk) for kk in ("erwerbe", "wartezeit_mittel_ms", "max_wartezeit_ms", "haltezeit_mittel_ms", "max_haltezeit_ms", "fristen", "held_over_1s", "laengste")}
            except ValueError:
                pass
        out["limit"]["wlock"] = wl
    except ValueError:
        pass

    # Coinbase läuft als eigener Dienst mit eigener Meta-Tabelle
    try:
        cbm = dict(con.execute("SELECT k, v FROM cb_meta"))
        cbj = json.loads(cbm.get("jobs") or "{}")
        for k, v in cbj.items():
            out["jobs"][k] = v
        out["limit"]["cb_alive"] = int(cbm.get("alive") or 0)
        out["limit"]["cb_products"] = cbm.get("products", "")
        out["limit"]["cb_coins"] = cbm.get("coins", "")
        out["limit"]["cb_fehlend"] = cbm.get("fehlend", "")
        try:
            wahl = json.loads(cbm.get("paarwahl") or "{}")
            # Nur Coins nennen, bei denen NICHT das USD-Paar gewählt wurde -- die
            # Abweichung ist die Information, die Regel ist es nicht.
            out["limit"]["cb_abweichend"] = ", ".join(
                f"{c} über {d['pid'].split('-')[-1]}" for c, d in sorted(wahl.items())
                if not str(d.get("pid", "")).endswith("-USD"))
        except ValueError:
            pass
        out["limit"]["cb_stats"] = cbm.get("stats", "")
    except (sqlite3.OperationalError, ValueError):
        pass

    # Aufgaben des Dashboards (Prognose und ihre Bausteine) -- sie kosten kein API-Gewicht,
    # gehören aber in denselben Zeitplan, sonst sucht man sie wieder an anderer Stelle.
    try:
        st = hl_forecast.store_connect()
        st.row_factory = sqlite3.Row
        letzte = st.execute("SELECT MAX(ts) FROM forecast").fetchone()[0]
        bausteine = {r["key"]: r["updated"] for r in st.execute("SELECT key, updated FROM learned")}
        w_ts = st.execute("SELECT MAX(updated) FROM weights").fetchone()[0]
        # 15.09.: "Gewichte prüfen" zeigte 50 h -- das war der Zeitpunkt des letzten SCHREIBENS. Die Prüfung
        # läuft alle 15 min, schreibt aber nur, wenn genug Fälle da sind. Jetzt: Zeitpunkt der Prüfung,
        # dazu im Text, ob gelernt wurde und wie alt der letzte Gewichtssatz ist.
        chk = st.execute("SELECT MAX(updated), value FROM learned WHERE key LIKE 'weights_check_%'").fetchone()
        try:
            chk_info = json.loads(chk[1]) if chk and chk[1] else {}
        except (ValueError, TypeError):
            chk_info = {}
        chk_ts = chk[0] if chk and chk[0] else None
        st.close()
        takte = {"analog": 3600, "magnets": 3600, "tprof": 6 * 3600}
        fc = {"Prognose": {"last": letzte, "next": (letzte or now) + 900, "takt": 900,
                           "info": "alle 15 min, früher bei Wal- oder Leaderboard-Ereignis"},
              "Gewichte prüfen": {"last": chk_ts or w_ts, "next": ((chk_ts or w_ts) or now) + 900, "takt": 900,
                                  "info": "Kalibrierung gegen die Trefferbilanz · "
                                          + (f"n_eff {chk_info.get('n_eff'):.0f}, " if isinstance(chk_info.get("n_eff"), (int, float)) else "")
                                          + (f"gelernt, Gewichte vor {(now - w_ts) / 3600:.0f} h geschrieben" if chk_info.get("gelernt") and w_ts
                                             else (f"noch nicht genug Fälle (ab n_eff {hl_forecast.MIN_N_EFF}); letzter Gewichtssatz vor {(now - w_ts) / 3600:.0f} h" if w_ts
                                                   else f"noch nicht genug Fälle (ab n_eff {hl_forecast.MIN_N_EFF})"))}}
        for k, label in (("analog", "Analog-Suche"), ("magnets", "Magnet-Statistik"), ("tprof", "Zeitprofil")):
            if bausteine.get(k):
                fc[label] = {"last": bausteine[k], "next": bausteine[k] + takte[k], "takt": takte[k], "info": ""}
        out["forecast"] = fc
    except Exception:
        pass
    con.close()
    return out


def sys_status() -> dict:
    with _SYS["lock"]:
        cur = _SYS["cur"]; hist = list(_SYS["hist"])
    if cur is None:
        cur = sys_sample()
    return {"current": cur, "history": hist, "max_24h": max((h[1] for h in hist if h[1] is not None), default=None)}


_RESP: dict = {"lock": threading.Lock(), "items": {}}


def _kappen(cache: dict, maximum: int) -> None:
    """
    Ältesten Eintrag verwerfen, wenn der Zwischenspeicher zu groß wird.

    Die Schlüssel enthalten den auf 50 USD gerundeten Kurs -- jede Bewegung von 50 USD
    legte einen neuen Eintrag an, der nie wieder gelöscht wurde. Auf einem Pi im
    Monatsbetrieb wächst der Speicherbedarf damit unbegrenzt, und die Einträge des
    Leaderboards enthalten vollständige Datensätze.
    """
    while len(cache) > maximum:
        aeltester = min(cache, key=lambda k: cache[k][0])
        cache.pop(aeltester, None)


def _grenze(wert, klein: int, gross: int, standard: int) -> int:
    """
    Zahl aus der Adresszeile in vernünftige Schranken zwingen.

    Ohne Obergrenze erzeugt hours=100000 eine Gitterliste von hunderten Megabyte und
    legt den Pi lahm -- ohne jede Anmeldung, allein durch einen Seitenaufruf.
    """
    try:
        return max(klein, min(gross, int(float(wert))))
    except (TypeError, ValueError):
        return standard


# 23.35: Lebensdauer der gespeicherten Antworten je Pfad (s). Dazu der „Einzelflug“: Läuft dieselbe Anfrage schon, rechnet kein
# zweiter Thread -- er liefert die vorige Antwort (bis 10 min alt) oder wartet auf die laufende. Ohne ihn stauten sich am
# 29./30.09. die Abrufe mehrerer Seiten (Wale, Profis, Pool) zu Dauerlast: jede langsame Anfrage zog weitere gleiche nach sich.
_RESP_TTL = {"/chart": 5, "/data": 15, "/whales": 15, "/forecast": 30, "/restore/info": 30, "/network": 15, "/verlauf": 60,
             "/konfluenz/bilanz": 600, "/profis": 30, "/pool": 60, "/network_ext": 60, "/makro": 60}
_RESP_ALT_S = 600
_SF: dict = {}                                        # Pfad mit Abfrage -> Event der laufenden Berechnung


def _sf_betreten(key: str) -> tuple:
    """(eigner, event, alte_antwort): eigner=True -> dieser Thread rechnet; sonst läuft es schon (Altantwort, falls vorhanden)."""
    with _RESP["lock"]:
        ev = _SF.get(key)
        if ev is None:
            ev = threading.Event(); _SF[key] = ev
            return True, ev, None
        hit = _RESP["items"].get(key)
        return False, ev, (hit[1] if hit and time.time() - hit[0] < _RESP_ALT_S else None)


def _sf_verlassen(key: str, ev) -> None:
    with _RESP["lock"]:
        if _SF.get(key) is ev:
            _SF.pop(key, None)
    ev.set()


def _resp_cache_get(key: str, ttl: float):
    if ttl <= 0:
        return None
    with _RESP["lock"]:
        hit = _RESP["items"].get(key)
        return hit[1] if hit and time.time() - hit[0] < ttl else None


def _resp_cache_put(key: str, body: bytes) -> None:
    with _RESP["lock"]:
        _RESP["items"][key] = (time.time(), body)
        if len(_RESP["items"]) > 64:
            oldest = min(_RESP["items"], key=lambda k: _RESP["items"][k][0]); _RESP["items"].pop(oldest, None)


# ---------------------------------------------------------------------------
# AI-Prognose: alle 15 min je Coin im Hintergrund, Ergebnis im Speicher und in forecasts.db
# ---------------------------------------------------------------------------

import hl_forecast

_FC: dict = {"lock": threading.Lock(), "by_coin": {}, "started": False, "scores": {}}


_LEARN: dict = {}          # coin -> {"ts", "weights", "wver", "analog", "tprof", "magnets", "ensemble"}


def forecast_learn(con, coin: str, force: bool = False) -> dict:
    """
    Lernstand je Coin: Gewichte alle 15 min aus der Trefferbilanz, Analog-Suche / Zeitprofil /
    Magnet-Statistik stündlich (teuer), Ensemble-Gewichte aus den laufenden Trefferquoten beider
    Modelle. Ergebnisse liegen in forecasts.db (Tabellen weights, learned), damit ein Neustart
    nicht bei null anfängt.
    """
    L = _LEARN.get(coin) or {}
    now = time.time()
    # Gewichte: Hauptspur 4 h alle 15 min, 24-h-Spur stündlich (teurer, und sie ändert sich langsam).
    # Beide Spuren: n_eff statt Fensterzahl, lam = 4 / n_eff, Mindest-n_eff je Treiber, gelernter
    # Maßstab beta für die Wahrscheinlichkeit (siehe hl_forecast.calibrate_weights).
    for h, takt, key, ckey in ((hl_forecast.HAUPT_HORIZONT, 900, "weights", "cal"), (24, 3600, "weights_24", "cal_24")):
        if not (force or now - L.get(f"w_ts_{h}", 0) > takt):
            continue
        try:
            if h == hl_forecast.HAUPT_HORIZONT:
                # Nach der Korrektur des Kapitulationssignals (invertiert und wirkungslos) und
                # der Binance-Zeitstempel sind alte Gewichte auf fehlerhaften Eingaben gelernt.
                # Einmalig verwerfen, damit die Kalibrierung wieder beim Prior beginnt.
                hl_forecast.reset_weights_once(coin)
            meta: dict = {}
            w = hl_forecast.calibrate_weights(con, coin, horizon_h=h, meta=meta)
            # K2-Neubau (23.09.): Kalibrierung v2 stündlich je Horizont, im Schatten (bis der Schalter gesetzt ist)
            try:
                import hl_kalib
                if time.time() - L.get(f"kalib2_ts_{h}", 0) >= 3600:
                    hl_kalib.kalibrieren(con, coin, horizon_h=h)
                    L[f"kalib2_ts_{h}"] = time.time()
                    if h == 4:
                        import hl_konstellation
                        hl_konstellation.berechnen(con, coin)                   # U25 Stufe 1: Konstellationen + Vorbedingungen
            except Exception as e:
                L.setdefault("errors", []).append(f"kalib2 {h}h: {type(e).__name__}: {e}")
                L["kalib2_fehler"] = f"{h} h: {type(e).__name__}: {e}"            # sichtbar in der Kachel und in der Kopfzeile
            try:
                hl_forecast.learned_save(coin, f"weights_check_{h}", {"ts": int(time.time()), "n_eff": meta.get("n_eff"), "gelernt": bool(meta.get("n_eff") and meta["n_eff"] >= hl_forecast.MIN_N_EFF)})
            except Exception:
                pass
            prev, _ = hl_forecast.learned_weights_load(coin, h=h)
            def abw(k, v):
                return abs((prev.get(k) or {}).get("weight", v["prior"]) - v["weight"])
            changed = any(abw(k, v) > 0.02 for k, v in w.items())
            gross = any(abw(k, v) > 0.10 for k, v in w.items())      # neue Version nur bei deutlicher Änderung
            if changed or not prev:
                hl_forecast.learned_weights_save(coin, w, bump=gross or not prev, h=h, meta=meta)
                L[f"w_saved_{h}"] = now
            elif now - L.get(f"w_saved_{h}", 0) > 3600:
                hl_forecast.learned_weights_save(coin, w, bump=False, h=h, meta=meta)   # n_eff/beta stündlich auffrischen
                L[f"w_saved_{h}"] = now
            w2, wver = hl_forecast.learned_weights_load(coin, h=h)
            L[key] = w2 or w; L[ckey] = meta; L[f"w_ts_{h}"] = now
            if h == hl_forecast.HAUPT_HORIZONT:
                L["wver"] = wver or now; L["w_ts"] = now
        except Exception as e:
            L.setdefault("errors", []).append(f"Gewichte {h} h: {e}")
    # Teure Bausteine stündlich, aus dem Speicher (learned) wiederverwendet
    for key, fn, age in (("analog", lambda: hl_forecast.analog_forecast(con, coin), 3600),
                         ("tprof", lambda: hl_forecast.time_vol_profile(con, coin), 6 * 3600),
                         ("magnets", lambda: hl_forecast.magnet_stats(con, coin), 3600)):
        if force or now - L.get(key + "_ts", 0) > age:
            val = hl_forecast.learned_load(coin, key, age) if not force else None
            if val is None:
                try:
                    val = fn()
                    if val is not None:
                        hl_forecast.learned_save(coin, key, val)
                except Exception as e:
                    L.setdefault("errors", []).append(f"{key}: {e}"); val = L.get(key)
            L[key] = val; L[key + "_ts"] = now
    # U8: Bilanz der Kauf-/Verkaufsempfehlungen -- stündlich, für alle Coins gemeinsam (Schlüssel "*")
    if force or now - L.get("empf_ts", 0) > 3600:
        val = None if force else hl_forecast.learned_load("*", "empf", 3600)
        if val is None:
            try:
                val = hl_forecast.empfehlungen_bilanz(con)
                hl_forecast.learned_save("*", "empf", val)
            except Exception as e:
                L.setdefault("errors", []).append(f"Empfehlungs-Bilanz: {e}")
                val = L.get("empf")
        L["empf"] = val; L["empf_ts"] = now

    # Kapitulation: jedes Mal (billig)
    try:
        L["capitulation"] = hl_forecast.capitulation_signal(con, coin)
    except Exception:
        L["capitulation"] = None
    # Magnet-Varianten (0,5-1 % / 1-2 %, 4-24 h): täglich, nur Anzeige und Diagnose
    if force or now - L.get("magnet_var_ts", 0) > 86400:
        try:
            L["magnet_var"] = hl_forecast.magnet_varianten(con, coin)
        except Exception as e:
            L.setdefault("errors", []).append(f"Magnet-Varianten: {e}")
        L["magnet_var_ts"] = now
    # Konto-Score (hl_score): täglich je Coin, Schnappschuss in forecasts.db; Score-Test wöchentlich.
    if force or now - L.get("scores_ts", 0) > 86400:
        st = None
        try:
            import hl_score
            st = hl_forecast.store_connect()
            t_alt, alt = hl_score.load_scores(st, coin)
            if force or not t_alt or now - t_alt > 86400 - 600:
                sc = hl_score.compute_scores(con, coin, score_klasse(con, coin))   # 23.39: dieselbe Einstufung wie check_elite
                if sc:
                    hl_score.save_scores(st, coin, sc, ts=now)
                    t_alt, alt = now, {a: {"score": v["score"], "comps": v["comps"], "klasse": v["klasse"], "n": v["n"], "alpha_4h": v["alpha_4h"],
                                           "t_4h": v.get("t_4h")} for a, v in sc.items()}   # t_4h: Beleg für die Elite-Regel (21.09.)
            G_ = gesperrte_konten(con)
            if G_:
                alt = {a_: v_ for a_, v_ in alt.items() if a_.lower() not in G_}   # Masterregel: Gesperrte ohne Score/Elite
            L["scores"] = alt; L["scores_snapshot"] = t_alt
            try:
                gf = hl_score.elite_filter(con, coin, set(alt)) if alt else {}     # Gewinn- UND Aktivitätsschranke (22.09.)
            except Exception:
                gf = {}
            L["elite"] = hl_score.elite(alt, gewinn=gf) if alt else []
            L["elite_ausgeschlossen"] = {a: g["grund"] for a, g in gf.items() if not g["ok"] and a in hl_score.elite(alt)}
            try:
                hl_forecast.learned_save(coin, "elite", L["elite"])          # Kanal zum Recorder: Elite-Konten jede Minute abfragen
            except Exception:
                pass
            L["scores_ts"] = now
            # Score-Test: einmal je Woche, Ergebnis dauerhaft in learned
            prev = hl_forecast.learned_load(coin, "score_test", 7 * 86400)
            if prev is None:
                r = hl_score.score_test(con, st, coin)
                if r:
                    hl_forecast.learned_save(coin, "score_test", r); prev = r
            L["score_test"] = prev
        except Exception as e:
            L.setdefault("errors", []).append(f"Konto-Score: {e}")
        finally:
            if st is not None:
                try:
                    st.close()
                except sqlite3.Error:
                    pass
    # Ensemble-Gewichte: Beta-Posterior je Modell statt "Trefferquote minus 0,4".
    #
    # Die alte Regel machte aus 48 gegen 57 Prozent bei je 127 ÜBERLAPPENDEN Fällen
    # (n_eff ≈ 1,3 Tage) eine Mischung 32/68 -- eine Entscheidung auf anderthalb
    # Standardabweichungen aus anderthalb Tagen. Jetzt: Posterior-Mittel mit 50
    # Pseudo-Beobachtungen bei 55 %, gezählt in n_eff (24-h-Pfade: n / 96), Nullpunkt 0,5
    # (ein Modell bei 50 % weiß nichts), Deckel [0,3; 0,7] bis n_eff >= 50 je Modell.
    try:
        sc = hl_forecast.score_forecasts(con, coin, wver=L.get("wver"))
        m, a = sc.get("model") or {}, sc.get("analog") or {}
        A = 50.0
        def post(blk, p0):
            ne = float(blk.get("n_eff") or 0.0); hr = blk.get("hit_rate")
            return (ne * hr + A * p0) / (ne + A) if hr is not None else p0
        if (m.get("n_eff") or 0) >= 1 and (a.get("n_eff") or 0) >= 1:
            # Pseudo-Priors 0,56 / 0,54 ergeben ohne Daten genau die bisherige Mischung 60 / 40
            em, ea = max(post(m, 0.56) - 0.5, 0.01), max(post(a, 0.54) - 0.5, 0.01)
            wm = em / (em + ea)
            reif = min(m.get("n_eff") or 0, a.get("n_eff") or 0) >= 50
            if not reif:
                wm = min(0.7, max(0.3, wm))
            L["ensemble"] = {"model": round(wm, 2), "analog": round(1 - wm, 2),
                             "from": f"Posterior (n_eff Modell {m.get('n_eff')}, Analog {a.get('n_eff')}{'' if reif else ', gedeckelt 30–70 %'})"}
        else:
            L["ensemble"] = {"model": 0.6, "analog": 0.4, "from": "Prior (noch keine bewerteten 24-h-Pfade)"}
        L["score"] = sc
    except Exception as e:
        L.setdefault("errors", []).append(f"Bewertung: {e}")
    # Lernplan: was wurde wann ausgewertet, wann beginnt das Lernen, wann die nächste Prüfung
    try:
        st = hl_forecast.store_connect()
        n_stored = st.execute("SELECT COUNT(*) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        first_ts = st.execute("SELECT MIN(ts) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        last_ts = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        n_24h = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=? AND ts<=?", (coin, now - 24 * 3600)).fetchone()[0]
        n_4h = st.execute("SELECT COUNT(*) FROM forecast WHERE coin=? AND ts<=?", (coin, now - 4 * 3600)).fetchone()[0]
        n_windows = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        next_4h = st.execute("SELECT MIN(ts) FROM forecast WHERE coin=? AND ts>?", (coin, now - 4 * 3600)).fetchone()[0]
        next_24h = st.execute("SELECT MIN(ts) FROM forecast WHERE coin=? AND ts>?", (coin, now - 24 * 3600)).fetchone()[0]
        n_4h_win = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=? AND ts<=?", (coin, now - 4 * 3600)).fetchone()[0]
        w_changed = st.execute("SELECT MAX(updated) FROM weights WHERE coin=?", (coin,)).fetchone()[0]
        comp = {r[0]: r[1] for r in st.execute("SELECT key, updated FROM learned WHERE coin=?", (coin,))}
        st.close()
        # Lernstart: n_eff der Hauptspur (4 h) erreicht MIN_N_EFF -- das sind 16 x 40 = 640 bewertete
        # Fenster, rund eine Woche. Die 24-h-Spur braucht 96 x 40 = 3.840 Fenster, etwa sechs Wochen.
        H = hl_forecast.HAUPT_HORIZONT; ziel = int(hl_forecast.MIN_N_EFF * H / 0.25)
        n_eff_4h = hl_forecast.n_eff_of(n_4h_win, H); n_eff_24h = hl_forecast.n_eff_of(n_24h, 24)
        fehlend = max(0, ziel - n_4h_win)
        learn_eta = int(now + fehlend * 900 + (H * 3600 if fehlend else 0))
        learning = n_eff_4h >= hl_forecast.MIN_N_EFF
        L["plan"] = {"n_stored": n_stored, "n_windows": n_windows, "first_ts": first_ts, "last_ts": last_ts, "n_scored_24h": n_24h, "n_scored_4h": n_4h,
                     "n_windows_4h": n_4h_win, "n_eff_4h": round(n_eff_4h, 1), "n_eff_24h": round(n_eff_24h, 1),
                     "ziel_fenster": ziel, "min_n_eff": hl_forecast.MIN_N_EFF, "min_n_eff_treiber": hl_forecast.min_n_eff_treiber(H),
                     "haupt_h": H, "fehlend": fehlend,
                     "next_eval_4h": (next_4h + 4 * 3600) if next_4h else None, "next_eval_24h": (next_24h + 24 * 3600) if next_24h else None,
                     "learn_eta": learn_eta, "learning": learning, "learning_24h": n_eff_24h >= hl_forecast.MIN_N_EFF,
                     "w_checked": L.get("w_ts"), "w_changed": w_changed,
                     "next_w_check": (L.get("w_ts") or now) + 900, "components": comp,
                     "next_forecast": (last_ts or now) + 900}
    except Exception as e:
        L.setdefault("errors", []).append(f"Lernplan: {e}")
    L["ts"] = now
    _LEARN[coin] = L
    return L


_FC_LOCKS: dict = {}
_FC_LOCKS_GUARD = threading.Lock()


def _fc_lock(coin: str) -> threading.Lock:
    with _FC_LOCKS_GUARD:
        return _FC_LOCKS.setdefault(coin, threading.Lock())


def forecast_compute(db_path: str, coin: str) -> dict | None:
    # M9 (Audit v10): Takt-Thread, Ereignis-Thread und HTTP-Abrufe konnten dieselbe Prognose parallel rechnen
    # (CPU-Spitzen, _LEARN ohne Sperre). Sperre je Coin: wer wartet, nimmt danach das frische Ergebnis.
    lk = _fc_lock(coin)
    if not lk.acquire(blocking=False):
        lk.acquire()                       # ein anderer Thread rechnet gerade: warten, dann den Cache nutzen
        lk.release()
        with _FC["lock"]:
            fc = _FC["by_coin"].get(coin)
        if fc and time.time() - (fc.get("ts") or 0) < 120:
            return fc                      # frisch gerechnet vom anderen Thread
        lk.acquire()
    try:
        return _forecast_compute_inner(db_path, coin)
    finally:
        lk.release()


def _forecast_compute_inner(db_path: str, coin: str) -> dict | None:
    con = connect(db_path)
    try:
        chart = load_chart(con, coin, minutes=7 * 1440, agg=60)
        chart = attach_binance(con, chart, coin, 60, 7 * 1440, "fusion")      # Orderbücher, Taker, Funding aller Börsen
        chart = attach_sources(chart, coin, "fusion", con)
        whales = load_whales(con, coin, 72, cache_s=20)
        smart = smart_money(con, coin)
        lb = load_leaderboard(con, coin, 20)
        lb_act = load_lb_activity(con, coin, chart.get("price") or 0, days=3)
        etf = chart.get("etf")
        learned = forecast_learn(con, coin)
        # Spotpreis der Perp-Marke gegenüberstellen: chart["price"] ist der aktuelle Kurs
        cb_daten = coinbase_cached(Handler.db, coin, chart.get("price"))
        fc = hl_forecast.compute_forecast(con, coin, chart, whales, smart, lb, lb_act, etf, chart.get("bnc"), chart.get("cdc"),
                                          chart.get("bybit"), chart.get("okx"), learned=learned,
                                          coinbase=cb_daten)
        if fc:
            # 23.42 (KONZEPT_Fusion.md, Stufe 1): Kostenschwelle, Kalibrierung v3 und Fusionsprognose im Schatten -- vor dem Speichern,
            # damit sie im Payload stehen (Labor, Bilanz). Ein Fehler hier hält die Prognose nie an, er steht in fc["fusion"]["fehler"].
            try:
                import hl_fusion
                hl_fusion.ergaenzen(con, fc)
            except Exception as e_fu:
                fc["fusion"] = {"fehler": [f"{type(e_fu).__name__}: {e_fu}"]}
            try:                                                      # 23.43: Kaskaden-Gleichung (Schatten); Treiber schon in compute_forecast
                import hl_kaskade
                hl_kaskade.ergaenzen(con, fc)
            except Exception as e_ka:
                fc["kaskade"] = {"fehler": f"{type(e_ka).__name__}: {e_ka}"}
            hl_forecast.store_forecast(fc)
            fc["score"] = learned.get("score") or hl_forecast.score_forecasts(con, coin, wver=learned.get("wver"))
            fc["empf"] = learned.get("empf")                          # U8: Bilanz der Empfehlungen (alle Coins)
            try:
                import hl_konstellation
                fc["konstellation"] = hl_konstellation.laden(coin)
                if fc["konstellation"]:
                    fc["konstellation"]["stabil"] = hl_konstellation.stabil(coin)
                    try:
                        st_ = hl_forecast.store_connect(hl_forecast.STORE)
                        fc["konstellation"]["hist_tage"] = st_.execute("SELECT COUNT(*) FROM konstellation_hist WHERE coin=?", (coin,)).fetchone()[0]; st_.close()
                    except Exception:
                        fc["konstellation"]["hist_tage"] = 0
            except Exception:
                fc["konstellation"] = None
            fc["learn"] = {"store": hl_forecast.STORE, "weights": learned.get("weights"), "wver": learned.get("wver"), "ensemble": learned.get("ensemble"), "plan": learned.get("plan"),
                           "cal": learned.get("cal"), "cal_24": learned.get("cal_24"),
                           "magnet_var": learned.get("magnet_var"),
                           "scores_n": len(learned.get("scores") or {}), "scores_snapshot": learned.get("scores_snapshot"),
                           "elite": [{"addr": a, **{k: (learned.get("scores") or {}).get(a, {}).get(k) for k in ("score", "n", "alpha_4h", "klasse")}}
                                     for a in (learned.get("elite") or [])[:5]],
                           "score_test": learned.get("score_test"),
                           "weights_24": {k: {"weight": v.get("weight"), "prior": v.get("prior"), "n_eff": v.get("n_eff"), "hit_rate": v.get("hit_rate")}
                                          for k, v in (learned.get("weights_24") or {}).items()},
                           "tprof": bool(learned.get("tprof")), "magnets": learned.get("magnets"), "errors": (learned.get("errors") or [])[-3:],
                           "n_scored": (learned.get("score") or {}).get("n", 0)}
            # jüngste 48 h Stundenkerzen für das Chart
            fc["history"] = [{"t": c["t"], "c": c["c"]} for c in (chart.get("candles") or [])[-48:]]
        return fc
    except Exception as e:
        import traceback
        tb = traceback.extract_tb(e.__traceback__)
        where = f"{os.path.basename(tb[-1].filename)}:{tb[-1].lineno} ({tb[-1].name})" if tb else "?"
        return {"error": f"{type(e).__name__}: {e} — bei {where}", "coin": coin, "ts": int(time.time()), "failed": True,
                "trace": "".join(traceback.format_exception(type(e), e, e.__traceback__))[-2000:]}
    finally:
        con.close()


def forecast_start(db_path: str) -> None:
    with _FC["lock"]:
        if _FC["started"]:
            return
        _FC["started"] = True
    def run():
        time.sleep(15)
        while True:
            try:
                con = connect(db_path)
                coins = [r[0] for r in con.execute("SELECT coin FROM bars WHERE ts >= ? GROUP BY coin ORDER BY coin", (int(time.time()) - 86_400,))]   # M9: nur der letzte Tag (Index ts), kein Vollscan
                con.close()
            except Exception:
                coins = []
            for coin in coins:
                fc = forecast_compute(db_path, coin)
                if fc:
                    with _FC["lock"]:
                        _FC["by_coin"][coin] = fc
            time.sleep(900)
    threading.Thread(target=run, daemon=True).start()


def forecast_watch_start(db_path: str) -> None:
    """
    Alle 30 s: Hat ein DIREKTIONALER Wal seit der letzten Prognose seine Position geändert?
    Dann wird die Prognose für diesen Coin sofort neu gerechnet (höchstens alle 2 min je Coin).
    Wal-Änderungen sind das schnellste Signal -- sie sollen nicht auf den 15-min-Takt warten.
    """
    def run():
        last_run: dict = {}
        time.sleep(45)
        while True:
            try:
                con = connect(db_path)
                bmap = behavior_map(con)
                dir_set = {a for a, cls in bmap.items() if cls.startswith("direktional")}
                with _FC["lock"]:
                    items = list(_FC["by_coin"].items())
                for coin, fc in items:
                    if not fc or fc.get("failed"):
                        continue
                    rows = con.execute("""SELECT addr, ts FROM whale_positions WHERE coin=? AND ts>? AND event IN ('open','add','reduce','close','flip') AND ABS(COALESCE(delta_usd,0))>=1e6
                                          ORDER BY ts DESC LIMIT 50""", (coin, fc.get("ts", 0))).fetchall()
                    newest = max((r["ts"] for r in rows if r["addr"].lower() in dir_set), default=None)
                    try:                                                     # Leaderboard-Ereignisse direktionaler Konten
                        lb_dir = hl_forecast.lb_directional_addrs(con, coin)
                        # 21.09.: Der Auslöser feuerte bei JEDEM Ereignis -- seit die Leaderboard-Stände alle 2 min
                        # kommen, gab es alle 2 min eines: sechs volle Prognosen je 2 min statt je 15 (drei Kerne SQLite).
                        # Jetzt nur Ereignisse ab 1 Mio USD, und ein Mindestabstand von 5 min je Coin.
                        lrows = con.execute("SELECT addr, ts FROM lb_events WHERE coin=? AND ts>? AND ABS(COALESCE(delta_usd,0))>=1e6 ORDER BY ts DESC LIMIT 50", (coin, fc.get("ts", 0))).fetchall()
                        lnew = max((r["ts"] for r in lrows if r["addr"] in lb_dir), default=None)
                        if lnew and (not newest or lnew > newest):
                            newest = lnew
                    except sqlite3.OperationalError:
                        pass
                    if newest and time.time() - last_run.get(coin, 0) >= 300:
                        last_run[coin] = time.time()
                        fc2 = forecast_compute(db_path, coin)
                        if fc2:
                            fc2["trigger"] = "Wal-/Leaderboard-Flow"
                            with _FC["lock"]:
                                _FC["by_coin"][coin] = fc2
                con.close()
            except Exception:
                pass
            time.sleep(30)
    threading.Thread(target=run, daemon=True).start()


def verlauf_get(db: str, coin: str, stunden: int = 72) -> dict:
    """
    Verlauf der Treiber (23.09., Wunsch des Nutzers): Bias und alle Treiber der gespeicherten Prognosen (alle 15 min)
    über die letzten `stunden`, dazu der Kurs zur Prognosezeit und die Ereignisse nach der Definition der
    Ereignis-Profile (U43; erst 4 h nach ihrem Beginn erkennbar). Rein beschreibend -- kein Vorhersagewert.
    Spot-Taker-Flow vor der Seiten-Umstellung (U41) bleibt leer.
    """
    now = int(time.time()); t_von = now - stunden * 3600
    st = hl_forecast.store_connect(hl_forecast.STORE)
    try:
        slim = st.execute("SELECT ts, price, bias FROM forecast_slim WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_von)).fetchall()
        drv = st.execute("SELECT ts, name, score FROM forecast_drivers WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_von)).fetchall()
    finally:
        st.close()
    ereignisse, fehler = [], None
    con = connect(db)
    try:
        cb_ab = hl_forecast.cb_seite_ab(con)
        try:
            import hl_konstellation
            ereignisse = hl_konstellation.ereignisse_kurs(con, coin, t_von, now)
        except Exception as e:                                          # Markierung ist Zugabe, der Verlauf zählt
            fehler = f"{type(e).__name__}: {e}"
    finally:
        con.close()
    t = [r[0] for r in slim]; idx = {ts: i for i, ts in enumerate(t)}
    treiber: dict = {}
    for ts, nm, sc in drv:
        i = idx.get(ts)
        if i is None or not nm:
            continue
        if nm == hl_forecast.CB_TREIBER and cb_ab and ts < cb_ab:
            sc = None
        treiber.setdefault(nm, [None] * len(t))[i] = None if sc is None else round(float(sc), 3)
    aktuell = {nm: v[-1] for nm, v in treiber.items() if v and v[-1] is not None}
    return {"coin": coin, "stunden": stunden, "ts": now, "t": t, "px": [r[1] for r in slim],
            "bias": [None if r[2] is None else round(float(r[2]), 3) for r in slim], "treiber": treiber,
            "aktuell": aktuell, "ereignisse": ereignisse, "fehler": fehler}


def forecast_get(db_path: str, coin: str) -> dict | None:
    with _FC["lock"]:
        fc = _FC["by_coin"].get(coin)
    if fc and time.time() - fc.get("ts", 0) < (60 if fc.get("failed") else 1200):
        return fc
    # noch nicht berechnet (Start) -> sofort rechnen, damit der Abschnitt nicht leer bleibt
    fc = forecast_compute(db_path, coin)
    if fc:
        with _FC["lock"]:
            _FC["by_coin"][coin] = fc
    return fc


class Handler(BaseHTTPRequestHandler):
    db = DB_PATH

    def _send(self, body: bytes, ctype: str) -> None:
        """
        Antwort senden -- mit Cache-Verbot und, wenn der Browser es kann, gepackt.

        Beides schont die SD-Karte des Pi: Ohne "no-store" legt Firefox jede der alle 5 s
        geholten Antworten in seinen Plattencache (gemessen: 2,4 GB/h auf die Karte, während
        der Recorder nur 0,05 GB/h auf den Stick schrieb). Das Packen senkt zusätzlich die
        Menge um rund 90 % -- JSON mit vielen Zahlen komprimiert sehr gut -- und spart dem
        Handy Funkzeit. Stufe 1: kaum Rechenzeit, fast die volle Ersparnis.
        """
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        if len(body) > 1400 and "gzip" in (self.headers.get("Accept-Encoding") or ""):
            try:
                packed = gzip.compress(body, 1)
                if len(packed) < len(body):
                    body = packed
                    self.send_header("Content-Encoding", "gzip")
                    self.send_header("Vary", "Accept-Encoding")
            except Exception:
                pass
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass                                   # Browser hat die Seite gewechselt

    def _post_erlaubt(self) -> bool:
        """
        Schutz gegen Klicks von fremden Seiten (CSRF).

        Ein POST von irgendeiner Webseite im Browser eines Geräts im selben Netz wäre
        sonst ein einfacher Aufruf, den der Browser ohne Rückfrage absendet -- und
        /update installiert Code mit Root-Rechten. Zwei Hürden, die eine fremde Seite
        nicht nehmen kann:

          1. Eine eigene Kopfzeile (X-HL-Request). Sobald ein Aufruf eine solche Zeile
             trägt, verlangt der Browser vorab eine Freigabe vom Server (Preflight) --
             die dieser Server nicht erteilt. Das eigene Dashboard sendet sie mit.
          2. Origin, falls vorhanden, muss zu diesem Server gehören.

        Das Dashboard selbst ist davon nicht betroffen; für Geräte im eigenen Netz
        ändert sich nichts. Wer den Zugang ganz schließen will, bindet den Dienst an
        127.0.0.1 und nutzt einen SSH-Tunnel -- siehe README.
        """
        if (self.headers.get("X-HL-Request") or "").strip() != "1":
            return False
        host = (self.headers.get("Host") or "").strip()
        # S1 (Audit v10): Host-Allowlist gegen DNS-Rebinding -- eine fremde Seite, die per DNS auf den Pi
        # umgebogen wird, kommt mit ihrem eigenen Hostnamen; erlaubt sind nur die Adressen dieses Rechners
        if host and host.split(":")[0].strip("[]") not in _eigene_hosts():
            return False
        herkunft = (self.headers.get("Origin") or "").strip()
        if herkunft:
            if host and not herkunft.endswith("//" + host):
                return False
        return True

    def do_POST(self) -> None:
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        if not self._post_erlaubt():
            self._send(json.dumps({"ok": False,
                                   "error": "Aufruf abgelehnt: fehlende Kopfzeile X-HL-Request. "
                                            "Schutz gegen Aufrufe von fremden Seiten."}).encode(),
                       "application/json")
            return
        if u.path == "/update":
            self._send(json.dumps(start_update(UPDATE_URL)).encode(), "application/json")
        elif u.path == "/restore":
            self._send(json.dumps(start_restore()).encode(), "application/json")
        elif u.path == "/debug/run":
            qq = parse_qs(u.query)
            coin_q = (qq.get("coin", ["BTC"])[0] or "BTC")[:12]
            coin_q = coin_q if coin_q.replace("-", "").replace("_", "").isalnum() else "BTC"   # nur Symbolzeichen ins Kommando
            self._send(json.dumps(debug_run(qq.get("name", [""])[0], self.db, coin_q)).encode(), "application/json")
        elif u.path == "/makro/fred_schluessel":                         # 23.48: FRED-Schlüssel im Tab „Daten“ eintragen
            self._send(json.dumps(makro_fred_schluessel(self)).encode(), "application/json")
        else:
            try:
                self.send_error(404)
            except (BrokenPipeError, ConnectionResetError):
                pass                    # Browser hat die Seite gewechselt

    def do_GET(self) -> None:
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        # Antwort-Cache: dieselbe Anfrage innerhalb weniger Sekunden (mehrere Browser, Wiederholungen)
        # bekommt die letzte Antwort -- schützt den Pi vor Anfragestürmen.
        ttl = _RESP_TTL.get(u.path, 0)                                     # Audit v4 L8, 23.35 Tabelle
        cached = _resp_cache_get(self.path, ttl)
        if cached is not None:
            self._send(cached, "application/json")
            return
        eigner_ev = None
        if ttl > 0:                                                        # 23.35: Einzelflug
            eigner, ev_, alt_ = _sf_betreten(self.path)
            if not eigner:
                if alt_ is None:
                    ev_.wait(120)
                    alt_ = _resp_cache_get(self.path, _RESP_ALT_S)
                if alt_ is not None:
                    self._send(alt_, "application/json")
                else:
                    try:
                        self.send_error(503, "Dashboard beschaeftigt -- gleiche Anfrage laeuft noch")
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                return
            eigner_ev = ev_
        try:
            if u.path == "/":
                self._send(PAGE.encode(), "text/html; charset=utf-8")
            elif u.path == "/leaderboard":
                qq = parse_qs(u.query)
                con = connect(self.db)
                payload = load_leaderboard(con, qq.get("coin", ["BTC"])[0], _grenze(qq.get("top", ["20"])[0], 1, 200, 20), _grenze(qq.get("days", ["7"])[0], 1, 90, 7))
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/lb_activity":
                qq = parse_qs(u.query)
                con = connect(self.db)
                coin_ = qq.get("coin", ["BTC"])[0]
                row = con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin_,)).fetchone()
                payload = load_lb_activity(con, coin_, float(row[0]) if row else 0, _grenze(qq.get("days", ["3"])[0], 1, 30, 3))
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/labels":
                qq = parse_qs(u.query)
                addrs = [a for a in qq.get("addrs", [""])[0].split(",") if a.startswith("0x")][:200]
                con = connect(self.db)
                payload = labels_for(con, addrs)
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/forecast":
                qq = parse_qs(u.query)
                body = json.dumps(forecast_get(self.db, qq.get("coin", ["BTC"])[0])).encode(); _resp_cache_put(self.path, body)   # 23.35: TTL galt nie
                self._send(body, "application/json")
            elif u.path == "/berichte":                                 # Berichtsplan (23.09.)
                self._send(json.dumps(berichte_uebersicht(self.db)).encode(), "application/json")
            elif u.path == "/bericht":
                body = bericht_lesen(parse_qs(u.query).get("name", [""])[0])
                if body is None:
                    self.send_error(404, "kein solcher Bericht")
                else:
                    self._send(body, "text/plain; charset=utf-8")
            elif u.path in ("/berichte/sammel", "/berichte/neu", "/berichte/letzter"):
                if u.path == "/berichte/sammel":
                    body, dateiname = berichte_sammel(_grenze(parse_qs(u.query).get("tage", ["7"])[0], 1, 60, 7))
                else:
                    body, dateiname = berichte_neu(nochmal=(u.path == "/berichte/letzter"))
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Disposition", f'attachment; filename="{dateiname}"')
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
            elif u.path.startswith("/speicher"):                      # 23.23: Speicherorte
                qq = parse_qs(u.query)
                if u.path == "/speicher":
                    out_ = speicher_status(self.db)
                elif u.path == "/speicher/ordner":
                    out_ = speicher_ordner(qq.get("pfad", [""])[0])
                elif u.path == "/speicher/backup_setzen":
                    out_ = speicher_backup_setzen(self.db, qq.get("pfad", [""])[0])
                elif u.path == "/speicher/jetzt":
                    out_ = speicher_jetzt()
                elif u.path == "/speicher/alt_loeschen" and qq.get("ok", [""])[0] == "1":
                    out_ = speicher_alt_loeschen(self.db)
                else:
                    out_ = {"ok": False, "msg": "unbekannt"}
                self._send(json.dumps(out_).encode(), "application/json")
            elif u.path == "/konfluenz/log":                          # 24.09.: Konfluenz-Ergebnis des Browsers aufzeichnen
                self._send(json.dumps(konfluenz_loggen(parse_qs(u.query))).encode(), "application/json")
            elif u.path == "/konfluenz/bilanz":
                con_ = connect(self.db)
                try:
                    body = json.dumps(hl_forecast.konfluenz_bilanz(con_), default=float).encode()
                finally:
                    con_.close()
                _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/anker":                                  # 23.28: Heatmap-Anker
                self._send(anker_payload(self.db, (parse_qs(u.query).get("coin") or ["BTC"])[0].upper()[:12]), "application/json")
            elif u.path in ("/labor", "/labor/daten", "/labor/chart", "/labor/trades", "/labor/equity"):     # 23.33 TradeLabor
                self._send(labor_payload(self.db, u.path[7:], parse_qs(u.query)), "application/json")
            elif u.path == "/familien":                               # 23.25: Treiberfamilien (Parallelbetrieb)
                self._send(familien_payload(self.db, (parse_qs(u.query).get("coin") or ["BTC"])[0].upper()[:12]), "application/json")
            elif u.path == "/verlauf":                                  # 23.09.: Verlauf der Treiber unter dem Kurs
                qq = parse_qs(u.query)
                body = json.dumps(verlauf_get(self.db, qq.get("coin", ["BTC"])[0], _grenze(qq.get("h", ["72"])[0], 6, 168, 72))).encode()
                _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/makro":                                  # 23.47 Makro-Chart (U121): eigene makro.db neben der Datenbank
                import hl_makro
                qq = parse_qs(u.query)
                body = hl_makro.payload_json(hl_makro.makro_pfad(self.db), (qq.get("tab") or ["ueberblick"])[0][:16],
                                             (qq.get("coin") or ["BTC"])[0].upper()[:8], makro_live(self.db))
                _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/makro.js":
                import hl_makro_js
                self._send(hl_makro_js.MAKRO_JS.encode(), "text/javascript; charset=utf-8")
            elif u.path == "/system":
                self._send(json.dumps(sys_status()).encode(), "application/json")
            elif u.path == "/network_ext":
                hours = _grenze(parse_qs(u.query).get("hours", ["3"])[0], 1, 48, 3) if "_grenze" in globals() else 3
                body = json.dumps(network_ext(self.db, hours)).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/network":
                body = json.dumps(network_status(self.db)).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/debug/status":
                qq = parse_qs(u.query)
                self._send(json.dumps(debug_status(qq.get("id", [""])[0])).encode(), "application/json")
            elif u.path == "/debug/list":
                self._send(json.dumps({k: v[0] for k, v in debug_commands(self.db).items()}).encode(), "application/json")
            elif u.path == "/update/status":
                self._send(json.dumps(update_status()).encode(), "application/json")
            elif u.path == "/debug/threads":
                # Was rechnet das Dashboard gerade? Stack jedes Threads (21.09.: drei Kerne ohne sichtbaren Grund);
                # 23.35: dazu die verbrauchte CPU-Zeit je Thread (/proc/self/task/<tid>/stat) -- auch für Threads ohne Python-Rahmen
                import traceback
                frames = sys._current_frames(); thr_ = {t.ident: t for t in threading.enumerate()}
                tick_ = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100

                def cpu_s(tid):
                    try:
                        with open(f"/proc/self/task/{tid}/stat") as f_:
                            x_ = f_.read().rsplit(")", 1)[1].split()
                        return (int(x_[11]) + int(x_[12])) / tick_
                    except (OSError, ValueError, IndexError, TypeError):
                        return None
                zeilen = []; bekannt_ = set()
                for ident, frame in frames.items():
                    t_ = thr_.get(ident); nid = getattr(t_, "native_id", None) if t_ else None
                    bekannt_.add(nid)
                    stack = traceback.extract_stack(frame)[-6:]
                    zeilen.append({"thread": t_.name if t_ else str(ident), "tid": nid, "cpu_s": cpu_s(nid) if nid else None,
                                   "stack": [f"{os.path.basename(f.filename)}:{f.lineno} {f.name}" for f in stack]})
                try:
                    for d_ in os.listdir("/proc/self/task"):
                        if int(d_) not in bekannt_:
                            c_ = cpu_s(int(d_))
                            if c_:
                                zeilen.append({"thread": f"ohne Python-Rahmen {d_}", "tid": int(d_), "cpu_s": c_, "stack": ["(nativ)"]})
                except OSError:
                    pass
                # 23.36: CPU des GANZEN Prozesses (/proc/self/stat zählt auch beendete Threads) -- kurze Anfragen leben
                # nur Sekundenbruchteile und fehlen in der Liste je Thread; die Differenz zeigt ihren Anteil.
                try:
                    with open("/proc/self/stat") as f_:
                        x_ = f_.read().rsplit(")", 1)[1].split()
                    prozess_s = (int(x_[11]) + int(x_[12])) / tick_
                except (OSError, ValueError, IndexError):
                    prozess_s = None
                self._send(json.dumps({"ts": time.time(), "threads": zeilen, "prozess_cpu_s": prozess_s}).encode(), "application/json")
            elif u.path == "/profis":
                body = json.dumps(profis_payload(self.db)).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/pool":
                qq_ = parse_qs(u.query)
                body = json.dumps(pool_vorschau(self.db, qq_.get("win", ["roi_7d"])[0], _grenze(qq_.get("n", ["500"])[0], 1, 600, 500))).encode()
                _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/restore/info":                       # 22.09.: Zeile war seit dem /debug/threads-Einbau verloren (Route 404)
                body = json.dumps(restore_info()).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/coins":
                con = connect(self.db)
                cs = [r[0] for r in con.execute(
                    "SELECT DISTINCT coin FROM bars ORDER BY coin")]
                con.close()
                self._send(json.dumps(cs or ["BTC"]).encode(), "application/json")
            elif u.path == "/manifest.json":
                self._send(json.dumps({
                    "name": "HL Liquidationen", "short_name": "HL Liq",
                    "start_url": "/", "display": "standalone",
                    "background_color": "#0d1117", "theme_color": "#0d1117",
                    "icons": [{"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}],
                }).encode(), "application/manifest+json")
            elif u.path == "/icon.svg":
                self._send(ICON_SVG.encode(), "image/svg+xml")
            elif u.path == "/health":
                self._send(json.dumps(load_health(self.db)).encode(), "application/json")
            elif u.path == "/whales":
                q = parse_qs(u.query)
                con = connect(self.db)
                payload = load_whales(con, q.get("coin", ["BTC"])[0],
                                      _grenze(q.get("hours", ["72"])[0], 1, 336, 72), cache_s=20)
                con.close()
                body = json.dumps(payload).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/chart":
                q = parse_qs(u.query)
                con = connect(self.db)
                src = q.get("src", ["hl"])[0]
                coin_ = q.get("coin", ["BTC"])[0]; mins_ = _grenze(q.get("minutes", ["240"])[0], 5, 3 * 525_600, 240); agg_ = _grenze(q.get("agg", ["1"])[0], 1, 10080, 1)
                payload = load_chart(con, coin_, mins_, agg_, fvg_min=float(q.get("fvg", ["0.0005"])[0]))
                if src in ("bnc", "fusion"):
                    payload = attach_binance(con, payload, coin_, agg_, mins_, src)
                try:
                    payload = attach_sources(payload, coin_, src, con)
                except Exception as e:                       # Zusatzquellen dürfen den Chart nie verhindern
                    payload["sources_error"] = str(e)[:200]
                con.close()
                body = json.dumps(payload).encode()
                _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/data":
                q = parse_qs(u.query)
                coin = q.get("coin", ["BTC"])[0]
                hours = _grenze(q.get("hours", ["24"])[0], 1, 336, 24)
                con = connect(self.db)
                span = con.execute("SELECT MIN(ts) a, MAX(ts) b FROM bars").fetchone()
                stats = {
                    "addresses": con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0],
                    "positions": con.execute(
                        "SELECT COUNT(*) FROM addresses WHERE notional>0").fetchone()[0],
                    "days": ((span["b"] - span["a"]) / 86400) if span["a"] else 0,
                }
                src = q.get("src", ["hl"])[0]
                if src == "bnc":
                    payload = {"grid": bnc_grid(con, coin, hours), "depth": bnc_depth(con, coin), "stats": stats,
                               "metrics": bnc_metrics_series(con, coin, max(hours, 24)), "src": "bnc"}
                else:
                    payload = {"grid": load_grid(con, coin, hours),
                               "depth": load_depth(con, coin), "stats": stats, "src": src}
                    if src == "fusion":
                        g = bnc_grid(con, coin, hours)
                        payload["bnc"] = {"grid_liqs": g["liqs"], "liq_cells": g["cells"], "depth": bnc_depth(con, coin),
                                          "metrics": bnc_metrics_series(con, coin, max(hours, 24))}
                con.close()
                body = json.dumps(payload).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            else:
                try:
                    self.send_error(404)
                except (BrokenPipeError, ConnectionResetError):
                    pass                # Browser hat die Seite gewechselt
        except Exception as e:
            try:
                self.send_error(500, str(e))
            except (BrokenPipeError, ConnectionResetError):
                pass                    # Browser hat die Seite gewechselt
        finally:
            if eigner_ev is not None:
                _sf_verlassen(self.path, eigner_ev)

    def log_message(self, *a) -> None:
        pass


def prewarm() -> None:
    """Langsame externe Quellen beim Start im Hintergrund laden, damit die Kacheln sofort stehen."""
    for coin in ("BTC", "ETH"):
        _warm(("etf", coin), lambda c=coin: etf_flows(c))


def serve(db: str, port: int, host: str = "127.0.0.1") -> None:
    prewarm()
    sys_monitor_start(db)
    forecast_start(db)
    forecast_watch_start(db)
    berichte_start(db)                                  # Berichtsplan (23.09.)
    familien_start(db)                                  # 23.25: Treiberfamilien -- Profi-Flow-Aufzeichnung, Wochenstufen
    labor_start(db)                                     # 23.33: TradeLabor -- simulierter Handel, Takt 15 s
    makro_start(db)                                     # 23.47: Makro-Chart -- Abruf nach Plan in makro.db (Tagesdaten)
    Handler.db = db
    try:
        srv = ThreadingHTTPServer((host, port), Handler)   # eine langsame Anfrage blockiert nicht die anderen
        srv.daemon_threads = True
    except OSError as e:
        if e.errno == 98:                      # EADDRINUSE
            print(f"Port {port} ist bereits belegt.\n")
            print("Meist läuft das Dashboard schon — als systemd-Dienst oder aus")
            print("einem früheren Aufruf. Beides zusammen geht nicht.\n")
            print("  Wer hält den Port?     sudo ss -ltnp | grep " + str(port))
            print("  Dienst-Status:         systemctl status hl-dashboard")
            print("  Dienst anhalten:       sudo systemctl stop hl-dashboard")
            print(f"  oder anderen Port:     --port {port + 1}")
            raise SystemExit(2)
        raise
    if host not in ("127.0.0.1", "localhost"):
        print("Achtung: Das Dashboard ist im Netzwerk erreichbar und hat keine "
              "Authentifizierung. Nur im vertrauenswürdigen Heimnetz nutzen.")
    print(f"Dashboard: http://{host}:{port}  (Strg-C beendet)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbeendet")


# ---------------------------------------------------------------------------

def selbsttest_last() -> bool:
    """
    23.35 (Dauerlast 29./30.09.): (1) jüngster Wal-Stand aus dem 6-h-Fenster gleich der Wahrheit eines Generators -- mit den
    Fallen gleicher Zeitstempel (Schließen und Wiedereröffnen, Eröffnen und Schließen, add und snap) und alten Eröffnungen;
    (2) behavior_map, load_whales und der Server rechnen bei gleichzeitigen Anfragen nur EINMAL, die übrigen bekommen die
    Antwort oder den vorigen Stand. 23.36: (3) Gesperrte weder in Tabelle, Ereignissen noch Exposure-Zeitreihe.
    Temporäre Datenbank, kein Netz.
    """
    import tempfile, urllib.request
    pruef = []

    def ok(name, bed, text):
        pruef.append((name, bool(bed), text))
    tmp = tempfile.mkdtemp(prefix="hl_viz_last_")
    pfad = os.path.join(tmp, "w.db")
    con = sqlite3.connect(pfad)
    con.executescript("""
        CREATE TABLE whale_positions (ts INTEGER, addr TEXT, coin TEXT, event TEXT, side TEXT, size REAL, pos_value REAL, entry_px REAL,
            liq_px REAL, leverage REAL, upnl REAL, mark_px REAL, delta_usd REAL, PRIMARY KEY (ts, addr, coin, event)) WITHOUT ROWID;
        CREATE INDEX ix_whale_coin_ts ON whale_positions(coin, ts); CREATE INDEX ix_whale_addr ON whale_positions(addr, ts);
        CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER, PRIMARY KEY (ts, coin));
    """)
    now = int(time.time()) // 600 * 600; t0 = now - 3 * 86_400
    wahr: dict = {}; rows = []
    A = lambda i: "0x%040x" % (0xbeef00 + i)
    ereignisse = {                                                     # (Konto, Coin) -> [(ts, event, side)]
        (A(1), "BTC"): [(t0, "open", "long")],                                            # alt eröffnet, nur Snapshots
        (A(2), "BTC"): [(t0, "open", "short"), (now - 86_400, "close", "short")],         # gestern geschlossen
        (A(3), "ETH"): [(t0, "open", "long"), (now - 3 * 3600, "close", "long"), (now - 3 * 3600, "open", "short")],   # geschlossen und neu, gleiche Sekunde
        (A(4), "ETH"): [(now - 2 * 3600, "open", "long"), (now - 2 * 3600 + 1, "close", "long")],   # kurz offen, zu
        (A(5), "HYPE"): [(t0, "open", "long"), (now - 3600, "add", "long")],                # add; der Snapshot derselben Minute kommt dazu
        (A(6), "HYPE"): [(now - 5 * 3600, "open", "short"), (now - 5 * 3600, "close", "short")],   # gleiche Sekunde: Schließen gewinnt
    }
    for (a, c), ev in ereignisse.items():
        offen = None
        for ts, e, sd in ev:
            rows.append((ts, a, c, e, sd, 1.0, 5e6, 100.0, 50.0, 5, 0.0, 100.0, 5e6))
            if e == "close":
                offen = None
            elif e == "open" and offen is None:
                offen = (ts, sd)
        if (a, c) == (A(6), "HYPE"):
            offen = None
        if offen:
            wahr[(a, c)] = offen[0]
        schluss = max(ts for ts, _, _ in ev)
        if offen:                                                        # Snapshot alle 10 min, solange offen (und über die Fälle hinweg)
            for t in range(ev[0][0] // 600 * 600, now + 1, 600):
                if t >= ev[0][0]:
                    rows.append((t, a, c, "snap", offen[1], 1.0, 5e6, 100.0, 50.0, 5, 0.0, 100.0, 0.0))
        del schluss
    con.executemany("INSERT OR REPLACE INTO whale_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?)", [(t, "BTC", 1, 1, 1, 1, 1, 1) for t in range(now - 7200, now, 60)])
    con.commit(); con.close()
    c2 = connect(pfad)
    _WAL_OFFEN.update(ts=0, map={})
    w = _load_whales_roh(c2, "BTC", 72)
    ist = {(d["addr"], d["coin"]): d["opened_at"] for d in w["current"]}
    ok("Wal-Stand im 6-h-Fenster = Wahrheit", ist == wahr and len(w["current"]) == len(wahr),
       f"{len(ist)} offene Positionen (Soll {len(wahr)}), Eröffnungszeiten {'gleich' if ist == wahr else 'ABWEICHEND ' + str({k: (ist.get(k), wahr.get(k)) for k in set(ist) | set(wahr) if ist.get(k) != wahr.get(k)})}")
    # 23.36: Gesperrte (Masterregel) weder in Tabelle, Ereignissen noch in der Exposure-Zeitreihe -- bis 23.35 zählten sie dort mit
    G = A(9)
    c3 = sqlite3.connect(pfad)
    c3.execute("CREATE TABLE IF NOT EXISTS konto_status (addr TEXT PRIMARY KEY, status TEXT, grund TEXT, seit INTEGER, quelle TEXT, fills_tag REAL, trades_tag REAL)")
    c3.execute("INSERT OR REPLACE INTO konto_status VALUES (?,?,?,?,?,?,?)", (G.upper().replace("0X", "0x"), "gesperrt", "test", now, "auto", None, 400))
    c3.executemany("INSERT OR REPLACE INTO whale_positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   [(now - 7200, G, "BTC", "open", "short", 1.0, 9e7, 100.0, 50.0, 5, 0.0, 100.0, 9e7)]
                   + [(t, G, "BTC", "snap", "short", 1.0, 9e7, 100.0, 50.0, 5, 0.0, 100.0, 0.0) for t in range(now - 7200, now + 1, 600)])
    c3.commit(); c3.close()
    _SPERRE_CACHE.update(ts=0.0, set=set()); _WAL_OFFEN.update(ts=0, map={})
    try:
        w2 = _load_whales_roh(connect(pfad), "BTC", 72)
    finally:
        _SPERRE_CACHE.update(ts=0.0, set=set())
    short_max = max((e["short_usd"] for e in w2["exposure"]), default=0.0)
    ok("Gesperrte: nicht in Tabelle, Ereignissen, Exposure", all(d["addr"] != G for d in w2["current"]) and all(e["addr"] != G for e in w2["events"])
       and short_max < 9e7 and len(w2["exposure"]) == len(w["exposure"]),
       f"gesperrtes Konto mit 90 Mio Short: Tabelle {sum(1 for d in w2['current'] if d['addr'] == G)}, Ereignisse {sum(1 for e in w2['events'] if e['addr'] == G)}, "
       f"größter Short in der Exposure {short_max / 1e6:.0f} Mio (ohne das Konto {max((e['short_usd'] for e in w['exposure']), default=0) / 1e6:.0f} Mio)")
    # (2) Einzelflug behavior_map
    zaehler = {"bm": 0, "lw": 0, "pp": 0}
    orig_bm, orig_lw, orig_pp = globals()["_behavior_rechnen"], globals()["_load_whales_roh"], globals()["profis_payload"]

    def bm_langsam(con_):
        zaehler["bm"] += 1; time.sleep(0.4); return orig_bm(con_)

    def lw_langsam(con_, coin, hours=72):
        zaehler["lw"] += 1; time.sleep(0.4); return {"current": [], "coin": coin}

    def pp_langsam(db):
        zaehler["pp"] += 1; time.sleep(0.5); return {"bereit": True, "n": zaehler["pp"]}
    globals()["_behavior_rechnen"] = bm_langsam; globals()["_load_whales_roh"] = lw_langsam; globals()["profis_payload"] = pp_langsam
    try:
        _BEH_CACHE.update(ts=0, map={}, rechnet=False)

        def lauf(fn, n):
            dauer = []

            def eins():
                t_ = time.time(); fn(); dauer.append(time.time() - t_)
            th = [threading.Thread(target=eins) for _ in range(n)]
            [t.start() for t in th]; [t.join(10) for t in th]
            return dauer
        lauf(lambda: behavior_map(connect(pfad)), 8)
        n1 = zaehler["bm"]
        _BEH_CACHE["ts"] = time.time() - 61                            # abgelaufen: einer rechnet, die anderen bekommen den vorigen Stand
        d2 = lauf(lambda: behavior_map(connect(pfad)), 8)
        schnell = sum(1 for x in d2 if x < 0.2)
        ok("behavior_map rechnet nur einmal", n1 == 1 and zaehler["bm"] == 2 and schnell >= 7,
           f"8 gleichzeitige Aufrufe: {n1} Berechnung; nach Ablauf {zaehler['bm'] - n1} Berechnung, {schnell} von 8 sofort mit dem vorigen Stand")
        _WH["cache"].clear()
        lauf(lambda: load_whales(None, "BTC", 72, cache_s=20), 6)
        ok("load_whales rechnet nur einmal", zaehler["lw"] == 1, f"6 gleichzeitige Aufrufe: {zaehler['lw']} Berechnung")
        # (3) Server: Einzelflug über HTTP
        Handler.db = pfad
        srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler); port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        with _RESP["lock"]:
            _RESP["items"].clear(); _SF.clear()
        antworten = []

        def hol():
            try:
                antworten.append(urllib.request.urlopen(f"http://127.0.0.1:{port}/profis", timeout=20).read())
            except Exception as e:
                antworten.append(repr(e).encode())
        lauf(hol, 6)
        gleich = len(set(antworten)) == 1 and b'"bereit"' in antworten[0]
        n_http = zaehler["pp"]
        with _RESP["lock"]:
            _RESP["items"]["/profis"] = (time.time() - 31, antworten[0])      # abgelaufen, aber als Altantwort da
        antworten.clear()
        d3 = lauf(hol, 6)
        schnell3 = sum(1 for x in d3 if x < 0.3)
        srv.shutdown(); srv.server_close()
        ok("Server: gleiche Anfragen rechnen einmal", n_http == 1 and gleich and zaehler["pp"] == 2 and schnell3 >= 5,
           f"6 gleichzeitige /profis: {n_http} Berechnung, {'gleiche' if gleich else 'VERSCHIEDENE'} Antworten; nach Ablauf "
           f"{zaehler['pp'] - n_http} Berechnung, {schnell3} von 6 sofort mit der vorigen Antwort")
    finally:
        globals()["_behavior_rechnen"] = orig_bm; globals()["_load_whales_roh"] = orig_lw; globals()["profis_payload"] = orig_pp
        _BEH_CACHE.update(ts=0, map={}, rechnet=False); _WH["cache"].clear()
        with _RESP["lock"]:
            _RESP["items"].clear(); _SF.clear()
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(p_[1] for p_ in pruef)
    print("Dashboard -- Last-Schutz (23.35) und Wal-Stand ohne Gesperrte (23.36)")
    for name, gut, text in pruef:
        print(f"  {'ok  ' if gut else 'FEHL'} {name:<42} {text}")
    print("  Ergebnis:", "bestanden" if alles else "NICHT bestanden")
    return alles


def main() -> None:
    p = argparse.ArgumentParser(description="Visualisierung der Liquidationsdaten")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--coin", default="BTC")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--depth", action="store_true", help="aktuellen Snapshot zeichnen")
    p.add_argument("--threshold", type=float, default=0.70,
                   help="Perzentil-Schwelle: darunter wird nichts gezeichnet")
    p.add_argument("--out", default=None)
    p.add_argument("--serve", action="store_true")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--update-url", default=UPDATE_URL,
                   help="Archiv für den Update-Knopf (GitHub blob- oder raw-Link)")
    p.add_argument("--host", default="127.0.0.1",
                   help="0.0.0.0 macht das Dashboard im LAN erreichbar (Pi!)")
    p.add_argument("--selbsttest-last", action="store_true", help="23.35: Wal-Stand im Fenster und Einzelflug gegen Anfragestau prüfen")
    args = p.parse_args()
    if args.selbsttest_last:
        sys.exit(0 if selbsttest_last() else 1)

    if args.serve:
        globals()["UPDATE_URL"] = args.update_url
        _SERVE["port"] = args.port
        serve(args.db, args.port, args.host)
        return

    con = connect(args.db)
    if args.depth:
        plot_depth(con, args.coin, args.out or f"{args.coin}_depth.png")
    else:
        plot_heatmap(con, args.coin, args.hours,
                     args.out or f"{args.coin}_heatmap.png", args.threshold)
    con.close()


if __name__ == "__main__":
    main()
