#!/usr/bin/env python3
"""
hl_viz.py — Visualisierung für die von hl_recorder.py aufgezeichneten Daten.

Drei Modi:
    python hl_viz.py --coin BTC                  # Heatmap als PNG
    python hl_viz.py --coin BTC --depth          # aktueller Snapshot als Balken
    python hl_viz.py --serve                     # Live-Dashboard im Browser

Das Dashboard läuft parallel zum Recorder auf derselben SQLite-Datei
(WAL-Modus, gleichzeitiges Lesen ist unproblematisch) und aktualisiert sich
selbst. Es braucht keine Internetverbindung und keine JS-Bibliotheken.
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import re
import shutil
import subprocess
import sys
import math
import sqlite3
import time
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB_PATH = "hl_liq.db"


def connect(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA temp_store=MEMORY")      # Sortierpuffer im RAM, nicht auf der SD-Karte
    return con


# ---------------------------------------------------------------------------
# Datenabfrage
# ---------------------------------------------------------------------------

def load_grid(con, coin: str, hours: int):
    """Heatmap als Gitter (Zeitachse x Preisachse) plus Preisreihe."""
    t_from = int(time.time()) - hours * 3600

    heat = con.execute(
        "SELECT ts, bucket_px, side, notional FROM heatmap "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    bars = con.execute(
        "SELECT ts, open, high, low, close, volume FROM bars "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    liqs = con.execute(
        "SELECT ts, px, sz, side FROM liquidations "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()

    if not heat or not bars:
        return None

    times = sorted({r["ts"] for r in heat})
    levels = sorted({r["bucket_px"] for r in heat})
    t_idx = {t: i for i, t in enumerate(times)}
    l_idx = {p: i for i, p in enumerate(levels)}

    grid = [[0.0] * len(times) for _ in levels]
    sides = [[""] * len(times) for _ in levels]
    for r in heat:
        i, j = l_idx[r["bucket_px"]], t_idx[r["ts"]]
        grid[i][j] += r["notional"]
        sides[i][j] = r["side"]

    return {
        "times": times, "levels": levels, "grid": grid, "sides": sides,
        "price": [(r["ts"], r["close"]) for r in bars],
        "liqs": [(r["ts"], r["px"], r["px"] * r["sz"], r["side"]) for r in liqs],
    }


def bnc_grid(con, coin: str, hours: int) -> dict:
    """Heatmap der EINGETRETENEN Binance-Liquidationen: 10-min-Spalten x 0,25-%-Preisstufen."""
    now = int(time.time()); t_from = now - hours * 3600
    liqs = bnc_liqs(con, coin, t_from)
    cand, _ = bnc_candles(con, coin, 5, hours * 60)
    times = list(range(t_from // 600 * 600, now + 600, 600))
    t_idx = {t: i for i, t in enumerate(times)}
    cells: dict = {}
    for ts, px, usd, side in liqs:
        cells.setdefault((bucket_px(px), ts // 600 * 600), [0.0, side])
        cells[(bucket_px(px), ts // 600 * 600)][0] += usd
    levels = sorted({b for b, _ in cells})
    l_idx = {p: i for i, p in enumerate(levels)}
    grid = [[0.0] * len(times) for _ in levels]; sides = [[""] * len(times) for _ in levels]
    for (b, t), (usd, side) in cells.items():
        if t in t_idx:
            grid[l_idx[b]][t_idx[t]] += usd; sides[l_idx[b]][t_idx[t]] = side
    return {"times": times, "levels": levels, "grid": grid, "sides": sides,
            "price": [(c["t"], c["c"]) for c in cand], "liqs": [(ts, px, usd, "A" if side == "long" else "B") for ts, px, usd, side in liqs],
            "realized": True}


def bnc_depth(con, coin: str, hours: int = 24) -> dict:
    """Momentaufnahme der eingetretenen Liquidationen der letzten Stunden, je Preisstufe und Seite."""
    now = int(time.time()); liqs = bnc_liqs(con, coin, now - hours * 3600)
    agg: dict = {}
    for ts, px, usd, side in liqs:
        c = agg.setdefault((bucket_px(px), side), {"bucket_px": bucket_px(px), "side": side, "notional": 0.0, "n_pos": 0})
        c["notional"] += usd; c["n_pos"] += 1
    cand, _ = bnc_candles(con, coin, 1, 120)
    price = cand[-1]["c"] if cand else None
    vol_1h = sum(c["v"] * c["c"] for c in cand[-60:]) if cand else 0
    return {"rows": sorted(agg.values(), key=lambda r: r["bucket_px"]), "price": price, "vol_1h": vol_1h,
            "ts": max((l[0] for l in liqs), default=now), "realized": True, "hours": hours}


def load_depth(con, coin: str):
    """Aktuellster Snapshot: Cluster ober- und unterhalb des Kurses."""
    row = con.execute(
        "SELECT MAX(ts) t FROM heatmap WHERE coin=?", (coin,)).fetchone()
    if not row or not row["t"]:
        return None
    ts = row["t"]
    rows = con.execute(
        "SELECT bucket_px, side, notional, n_pos FROM heatmap "
        "WHERE coin=? AND ts=? ORDER BY bucket_px", (coin, ts)).fetchall()
    px = con.execute(
        "SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1",
        (coin,)).fetchone()
    vol = con.execute(
        "SELECT SUM(volume*close) v FROM bars WHERE coin=? AND ts>=?",
        (coin, ts - 3600)).fetchone()
    return {
        "ts": ts,
        "price": px["close"] if px else None,
        "vol_1h": (vol["v"] or 0) if vol else 0,
        "rows": [dict(r) for r in rows],
    }


# ---------------------------------------------------------------------------
# Statische Grafiken
# ---------------------------------------------------------------------------

def load_whales(con, coin: str, hours: int = 72):
    """Aktuelle Wale, Ereignisse und Netto-Exposure-Zeitreihe."""
    try:
        con.execute("SELECT 1 FROM whale_positions LIMIT 1")
    except sqlite3.OperationalError:
        return {"current": [], "events": [], "exposure": [], "price": []}
    t_from = int(time.time()) - hours * 3600

    # letzter Zustand je Wal: jüngste Zeile, die kein close ist
    current = con.execute("""
        SELECT w.addr, w.coin, w.side, w.size, w.pos_value, w.entry_px, w.liq_px,
               w.leverage, w.upnl, w.mark_px, w.ts,
               (SELECT MIN(ts) FROM whale_positions o
                 WHERE o.addr=w.addr AND o.coin=w.coin AND o.event='open'
                   AND o.ts <= w.ts
                   AND NOT EXISTS (SELECT 1 FROM whale_positions c
                                   WHERE c.addr=w.addr AND c.coin=w.coin
                                     AND c.event='close' AND c.ts>o.ts AND c.ts<=w.ts))
               AS opened_at
        FROM whale_positions w
        WHERE w.ts = (SELECT MAX(ts) FROM whale_positions x
                      WHERE x.addr=w.addr AND x.coin=w.coin)
          AND w.event != 'close'
        ORDER BY w.pos_value DESC""").fetchall()

    events = con.execute("""
        SELECT ts, addr, event, side, pos_value, delta_usd, mark_px, leverage
        FROM whale_positions
        WHERE coin=? AND ts>=? AND event != 'snap' ORDER BY ts""",
        (coin, t_from)).fetchall()

    # Wal-Flow: Netto-Fluss der DIREKTIONALEN Wale in den letzten 15/30/60 min -- das schnellste
    # Signal, das wir haben (Wale werden jede Minute abgefragt). Kaufdruck = Long eröffnet/aufgestockt
    # oder Short reduziert/geschlossen; Verkaufsdruck umgekehrt. Maßstab: Z-Score gegen die eigene
    # Verteilung der Stundenflüsse der letzten 7 Tage; Breite = wie viele Wale in dieselbe Richtung.
    bmap0 = behavior_map(con)
    pc = behavior_per_coin(con)
    now_ = int(time.time())
    ev_rows = con.execute("""SELECT ts, addr, event, side, delta_usd FROM whale_positions
                             WHERE coin=? AND ts>=? AND event IN ('open','add','reduce','close','flip')""",
                          (coin, now_ - 7 * 86_400)).fetchall()

    def group_of(addr_l: str) -> str:
        """
        Gruppe des Kontos IN DIESEM COIN. Hat es hier gerade keine Position (etwa weil es sie
        geschlossen hat), gilt die kontoweite Klasse -- NICHT blind "direktional": Ein Market
        Maker, der seine BTC-Position schließt, bleibt ein Market Maker.
        """
        e = pc.get((addr_l, coin))
        if e:
            return e["group"]
        cls = bmap0.get(addr_l, "")
        if cls.startswith("Market-Maker"):
            return "mm"
        if cls.startswith("Hedge"):
            return "hedge"
        if cls.startswith("gemischt"):
            return "mixed"
        return "dir"

    # Alle Konten, die in diesem Coin Ereignisse haben -- auch solche, die nicht mehr in der
    # Wal-Liste stehen, weil sie ihre Position geschlossen haben. Sonst fiele genau das
    # aussagekräftigste Ereignis (ein Wal steigt vollständig aus) aus jeder Gruppe heraus.
    grp_of = {a: group_of(a) for a in ({r["addr"].lower() for r in ev_rows} | set(bmap0))}
    dir_set = {a for a, g in grp_of.items() if g == "dir"}

    def signed(event: str, side: str, delta) -> float:
        d = abs(delta or 0)
        if event in ("open", "add", "flip"):
            return d if side == "long" else -d
        return -d if side == "long" else d                     # reduce/close einer Long-Position = Verkaufsdruck
    # Jede Gruppe bekommt ihre eigene Statistik: Wer alle außer den direktionalen ausschließt,
    # erfährt nie, ob eine andere Gruppe das bessere Signal liefert. Die Selbstkalibrierung
    # misst es und gewichtet entsprechend -- ausschließen wäre eine Annahme, messen ist Wissen.
    #
    # EIN Durchgang über die Ereignisse für alle Gruppen und alle Fenster. Vier Gruppen mal
    # drei Fenster plus Stundenreihe wären 16 Durchläufe über bis zu 280.000 Zeilen gewesen --
    # mehrere Sekunden je Aufruf auf dem Pi.
    acc = {g: {w: {"buy": 0.0, "sell": 0.0, "nb": set(), "ns": set()} for w in (15, 30, 60)} for g in GROUPS}
    hourly = {g: {} for g in GROUPS}
    cut = {w: now_ - w * 60 for w in (15, 30, 60)}
    for r in ev_rows:
        a = r["addr"].lower(); g = grp_of.get(a, "dir")
        v = signed(r["event"], r["side"], r["delta_usd"])
        if v:
            h = hourly[g]; b = r["ts"] // 3600
            h[b] = h.get(b, 0.0) + v
        ts = r["ts"]
        if ts < cut[60] or not v:
            continue
        for w in (15, 30, 60):
            if ts >= cut[w]:
                d = acc[g][w]
                if v > 0: d["buy"] += v; d["nb"].add(a)
                else: d["sell"] += -v; d["ns"].add(a)

    members_by_group = {}
    for a, g in grp_of.items():
        members_by_group.setdefault(g, set()).add(a)

    def pack(g: str) -> dict:
        f = {f"w{w}": {"buy_usd": acc[g][w]["buy"], "sell_usd": acc[g][w]["sell"],
                       "net_usd": acc[g][w]["buy"] - acc[g][w]["sell"],
                       "n_buy": len(acc[g][w]["nb"]), "n_sell": len(acc[g][w]["ns"])} for w in (15, 30, 60)}
        vals = list(hourly[g].values())
        if len(vals) >= 24:
            m = sum(vals) / len(vals); sd = (sum((v - m) ** 2 for v in vals) / max(1, len(vals) - 1)) ** 0.5
            f["hour_sd"] = sd
            f["z30"] = (f["w30"]["net_usd"] * 2 - m) / sd if sd > 0 else 0.0     # 30 min auf Stunde hochgerechnet
            f["z60"] = (f["w60"]["net_usd"] - m) / sd if sd > 0 else 0.0
        else:
            f["hour_sd"] = f["z30"] = f["z60"] = None
        w30 = f["w30"]; same = w30["n_buy"] if w30["net_usd"] > 0 else w30["n_sell"]
        f["breadth"] = same
        f["event_signal"] = bool(f["z30"] is not None and abs(f["z30"]) >= 2.5 and same >= 4)
        f["n_members"] = len(members_by_group.get(g, ()))
        return f

    groups = {g: pack(g) for g in GROUPS if members_by_group.get(g) or hourly[g]}
    flow = dict(groups.get("dir") or pack("dir"))
    flow["groups"] = groups
    flow["group_names"] = GROUPS
    flow["n_directional"] = len(dir_set)
    flow["n_total"] = len(grp_of)
    flow["sizes"] = {g: len(m) for g, m in members_by_group.items()}
    flow["per_coin"] = grp_of                                    # für die Ereignisliste im Dashboard

    # Direktionale Wale: nur Konten, deren Verhaltensklasse "direktional" ist
    # (eine Seite, kein Hedge-, kein Market-Maker-Muster), je Seite Anzahl und Wert.
    by_addr: dict = {}
    for r in current:
        by_addr.setdefault(r["addr"], []).append(r)
    dirn = {"n_long": 0, "usd_long": 0.0, "n_short": 0, "usd_short": 0.0, "n_whales": len(by_addr), "n_directional": 0}
    bmap = behavior_map(con)
    for addr, rows in by_addr.items():
        cls = bmap.get(addr.lower(), "")
        if not cls.startswith("direktional"):
            continue
        sides = {r["side"] for r in rows}
        if len(sides) != 1:
            continue
        side = sides.pop(); usd = sum(r["pos_value"] or 0 for r in rows)
        dirn["n_directional"] += 1
        if side == "long":
            dirn["n_long"] += 1; dirn["usd_long"] += usd
        else:
            dirn["n_short"] += 1; dirn["usd_short"] += usd

    # Netto-Exposure je Snapshot: long positiv, short negativ
    exposure = con.execute("""
        SELECT ts,
               SUM(CASE WHEN side='long'  THEN pos_value ELSE 0 END) AS long_usd,
               SUM(CASE WHEN side='short' THEN pos_value ELSE 0 END) AS short_usd,
               COUNT(*) AS n
        FROM whale_positions
        WHERE coin=? AND ts>=? AND event='snap'
        GROUP BY ts ORDER BY ts""", (coin, t_from)).fetchall()

    price = con.execute(
        "SELECT ts, close FROM bars WHERE coin=? AND ts>=? ORDER BY ts",
        (coin, t_from)).fetchall()[::5]          # jede 5. Minute reicht fürs Bild

    return {
        "current": [dict(r) for r in current],
        "events": [dict(r) for r in events],
        "directional": dirn, "flow": flow,
        "exposure": [dict(r) for r in exposure],
        "price": [(r["ts"], r["close"]) for r in price],
    }


def load_stops(con, coin: str, price: float) -> dict:
    """
    Aktuelle Orders der Wale und Großkonten (>= 1 Mio) für einen Coin: je Adresse die jüngste Abfrage der
    letzten 20 Minuten. Daraus Cluster je Preis-Bucket (0,25 %-Raster) für
    stop_sell (Verkaufskaskade nach unten), stop_buy (Kaufkaskade nach oben),
    tp_* (absorbieren) und limit_* (ruhende Liquidität).
    """
    out = {"orders": [], "clusters": [], "n_whales": 0, "ts": None}
    try:
        rows = con.execute("""
            SELECT t.* FROM trigger_orders t
            JOIN (SELECT addr, MAX(ts) mts FROM trigger_orders
                  WHERE ts > ? GROUP BY addr) m ON m.addr = t.addr AND m.mts = t.ts
            WHERE t.coin = ? AND t.kind != 'none'
            ORDER BY t.kind, t.trigger_px""", (int(time.time()) - 6 * 3600, coin)).fetchall()
        # Konten der untersten Stufe werden nur alle 6 h gefragt -- so weit reicht das Fenster
        n_wh, oldest = con.execute("SELECT COUNT(*), MIN(mts) FROM (SELECT addr, MAX(ts) mts FROM trigger_orders "
                                   "WHERE ts > ? GROUP BY addr)", (int(time.time()) - 6 * 3600,)).fetchone()
        n_fresh = con.execute("SELECT COUNT(DISTINCT addr) FROM trigger_orders WHERE ts > ?",
                              (int(time.time()) - 1200,)).fetchone()[0]
    except sqlite3.OperationalError:
        return out
    out["n_whales"] = n_wh
    out["n_fresh"] = n_fresh
    out["oldest"] = oldest
    out["n_with_orders"] = len({r["addr"] for r in rows
                                if (r["trigger_px"] or r["limit_px"]) and price
                                and abs((r["trigger_px"] or r["limit_px"]) / price - 1) <= 0.30})
    if not rows:
        return out
    out["ts"] = max(r["ts"] for r in rows)
    agg: dict = {}
    for r in rows:
        px = r["trigger_px"] or r["limit_px"]
        if not px:
            continue
        out["orders"].append({"addr": r["addr"][:6] + "…" + r["addr"][-4:], "kind": r["kind"],
                              "px": px, "size": r["size"], "notional": r["notional"],
                              "type": r["order_type"], "tpsl": r["is_tpsl"],
                              "dist": (px / price - 1) if price else 0})
        b = round(math.exp(round(math.log(px) / math.log(1.0025)) * math.log(1.0025)), 2)
        k = (r["kind"], b)
        a = agg.setdefault(k, {"kind": r["kind"], "px": b, "notional": 0.0, "n": 0, "addrs": set()})
        a["notional"] += r["notional"]; a["n"] += 1; a["addrs"].add(r["addr"])
    out["clusters"] = sorted(({**a, "addrs": len(a["addrs"]),
                               "dist": (a["px"] / price - 1) if price else 0} for a in agg.values()),
                             key=lambda x: x["px"])
    return out


def load_api_budget(con) -> dict | None:
    try:
        rows = dict(con.execute("SELECT k, v FROM meta WHERE k IN "
                                "('api_weight_1m','api_weight_budget','api_weight_ts','rate_limited',"
                                "'poller_batch','poller_want','poller_due_a','poller_due_b','poller_due_c','addr_total',"
                                "'task_errors','recorder_alive',"
                                "'thermal_temp','thermal_level','thermal_weight_factor','thermal_interval_factor','thermal_since')"))
    except sqlite3.OperationalError:
        return None
    if "api_weight_1m" not in rows:
        return None
    thermal = {"temp": float(rows["thermal_temp"]) if rows.get("thermal_temp") else None,
               "level": int(rows.get("thermal_level") or 0), "weight_factor": float(rows.get("thermal_weight_factor") or 1),
               "interval_factor": float(rows.get("thermal_interval_factor") or 1), "since": int(rows.get("thermal_since") or 0)}
    poller = {k: int(rows.get(k) or 0) for k in ("poller_batch", "poller_want", "poller_due_a", "poller_due_b", "poller_due_c", "addr_total")}
    try:
        poller["task_errors"] = json.loads(rows.get("task_errors") or "{}")
    except ValueError:
        poller["task_errors"] = {}
    poller["alive"] = int(rows.get("recorder_alive") or 0)
    return {"thermal": thermal, "poller": poller, "used": int(rows["api_weight_1m"]), "budget": int(rows.get("api_weight_budget", 1200)),
            "ts": int(rows.get("api_weight_ts", 0)), "r429": int(rows.get("rate_limited", 0))}


def load_mas(con, coin: str, price: float) -> dict:
    """
    Gleitende Durchschnitte aus Tageskerzen (daily_bars, nachgeladen von
    hl_binance): 50/200 Tage und 50/200 Wochen. Die laufende Kerze wird durch
    den aktuellen Kurs ersetzt -- so, wie Charts es zeigen.
    """
    out = {"ma50d": None, "ma200d": None, "ma50w": None, "ma200w": None,
           "days": 0, "weeks": 0, "source": None, "cross": None}
    try:
        rows = con.execute("SELECT ts, close, source FROM daily_bars WHERE coin=? "
                           "ORDER BY ts", (coin,)).fetchall()
    except sqlite3.OperationalError:
        return out
    if not rows:
        return out
    today = int(time.time()) // 86_400 * 86_400
    closed = [(r["ts"], r["close"]) for r in rows if r["ts"] < today]
    out["source"] = rows[-1]["source"]
    daily = [c for _, c in closed] + ([price] if price else [])
    out["days"] = len(closed)

    # Wochen: ISO-Woche, Schluss = letzter Tag der Woche; laufende Woche = Kurs
    import datetime as _dt
    weekly, cur_key = [], None
    for ts, c in closed:
        y, w, _ = _dt.datetime.fromtimestamp(ts, _dt.timezone.utc).isocalendar()
        if (y, w) != cur_key:
            weekly.append(c); cur_key = (y, w)
        else:
            weekly[-1] = c
    now_key = _dt.datetime.now(_dt.timezone.utc).isocalendar()[:2]
    if price:
        if cur_key == now_key:
            weekly[-1] = price
        else:
            weekly.append(price)
    out["weeks"] = len(weekly)

    def sma(seq, n):
        return sum(seq[-n:]) / n if len(seq) >= n else None

    out["ma50d"], out["ma200d"] = sma(daily, 50), sma(daily, 200)
    out["ma50w"], out["ma200w"] = sma(weekly, 50), sma(weekly, 200)
    if out["ma50d"] and out["ma200d"]:
        out["cross"] = "golden" if out["ma50d"] > out["ma200d"] else "death"
    for k in ("ma50d", "ma200d", "ma50w", "ma200w"):
        out[k + "_dist"] = (price / out[k] - 1) if (out[k] and price) else None
    return out


def find_fvgs(candles: list[dict], min_pct: float = 0.0005) -> list[dict]:
    """
    Fair Value Gaps: Dreikerzen-Lücken, rein aus den Kerzen berechnet.

    Bullisch: Tief der dritten Kerze über dem Hoch der ersten.
    Bärisch:  Hoch der dritten Kerze unter dem Tief der ersten.
    Die Zone zwischen beiden ist die Lücke. Sie gilt als "gemildert", sobald
    spätere Kerzen wieder hineinlaufen: teilweise (Anteil), oder ganz, wenn
    der Kurs die ferne Kante erreicht. Nichts davon wird gespeichert.
    """
    gaps = []
    for i in range(2, len(candles)):
        a, b, c = candles[i - 2], candles[i - 1], candles[i]
        if c["l"] > a["h"]:
            kind, top, bot = "bull", c["l"], a["h"]
        elif c["h"] < a["l"]:
            kind, top, bot = "bear", a["l"], c["h"]
        else:
            continue
        mid = (top + bot) / 2
        if mid <= 0 or (top - bot) / mid < min_pct:
            continue
        gaps.append({"i": i - 1, "t": b["t"], "kind": kind, "top": top, "bot": bot,
                     "size_pct": (top - bot) / mid, "fill_i": None, "fill_pct": 0.0})

    for g in gaps:
        span = g["top"] - g["bot"]
        for j in range(g["i"] + 2, len(candles)):
            c = candles[j]
            if g["kind"] == "bull":
                if c["l"] <= g["bot"]:
                    g["fill_i"], g["fill_pct"] = j, 1.0
                    break
                if c["l"] < g["top"]:
                    g["fill_pct"] = max(g["fill_pct"], (g["top"] - c["l"]) / span)
            else:
                if c["h"] >= g["top"]:
                    g["fill_i"], g["fill_pct"] = j, 1.0
                    break
                if c["h"] > g["bot"]:
                    g["fill_pct"] = max(g["fill_pct"], (c["h"] - g["bot"]) / span)
    return gaps


ICON_SVG = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
    '<rect width="64" height="64" rx="12" fill="#0d1117"/>'
    '<rect x="10" y="36" width="8" height="18" fill="#e04b4b"/>'
    '<rect x="22" y="24" width="8" height="30" fill="#3ba55d"/>'
    '<rect x="34" y="30" width="8" height="24" fill="#e04b4b"/>'
    '<rect x="46" y="14" width="8" height="40" fill="#39ff14"/>'
    '<line x1="8" y1="20" x2="56" y2="20" stroke="#58a6ff" stroke-width="2" stroke-dasharray="4 3"/>'
    '</svg>')

_HEALTH_CACHE: dict = {"ts": 0, "check": None, "running": False}
_HEALTH_LOCK = threading.Lock()


def _run_quick_check(db: str) -> None:
    """quick_check im Hintergrund -- bei 1 GB auf einem USB-Stick dauert er Minuten."""
    try:
        con = connect(db)
        t0 = time.time()
        res = con.execute("PRAGMA quick_check").fetchone()[0]
        con.close()
        result = {"db_ok": res == "ok", "db_detail": "" if res == "ok" else str(res)[:120],
                  "check_seconds": round(time.time() - t0, 1), "checked_at": int(time.time())}
    except sqlite3.Error as e:
        result = {"db_ok": False, "db_detail": str(e)[:120], "check_seconds": 0,
                  "checked_at": int(time.time())}
    with _HEALTH_LOCK:
        _HEALTH_CACHE.update(ts=int(time.time()), check=result, running=False)


def load_health(db: str, max_age: int = 6 * 3600) -> dict:
    """
    Backup-Status (billig, bei jedem Aufruf frisch) und Zustand der Datenbank
    (quick_check, höchstens alle 6 h, im Hintergrund). Der Aufruf blockiert nie:
    läuft die Prüfung gerade, kommt der letzte bekannte Stand oder "läuft".
    """
    now = int(time.time())
    with _HEALTH_LOCK:
        stale = _HEALTH_CACHE["check"] is None or now - _HEALTH_CACHE["ts"] >= max_age
        if stale and not _HEALTH_CACHE["running"]:
            _HEALTH_CACHE["running"] = True
            threading.Thread(target=_run_quick_check, args=(db,), daemon=True).start()
        check = _HEALTH_CACHE["check"]
        running = _HEALTH_CACHE["running"]

    backup = None
    bdir = os.path.join(os.path.dirname(os.path.abspath(db)), "dbbackup")
    try:
        c0 = connect(db)
        r0 = c0.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
        c0.close()
        if r0 and r0[0]:
            bdir = r0[0]
    except sqlite3.Error:
        pass
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            backup = json.load(f)
    except (OSError, ValueError):
        pass

    bfree = btotal = bsame = None
    try:
        u = shutil.disk_usage(bdir if os.path.isdir(bdir) else os.path.dirname(os.path.abspath(db)))
        bfree, btotal = u.free, u.total
        bsame = os.stat(bdir).st_dev == os.stat(os.path.dirname(os.path.abspath(db))).st_dev if os.path.isdir(bdir) else None
    except OSError:
        pass
    data = {"backup": backup, "checking": running, "backup_dir": bdir, "backup_free": bfree, "backup_total": btotal,
            "backup_same_device": bsame,
            "db_size": os.path.getsize(db) if os.path.exists(db) else 0}
    if check:
        data.update(check)
    else:
        data.update(db_ok=None, db_detail="Prüfung läuft", check_seconds=0, checked_at=None)
    return data


_KLINE_CACHE: dict = {}
_KLINE_LOCK = threading.Lock()


def aggregate(rows, step: int) -> list[dict]:
    """Zeilen (ts, o, h, l, c, v) in Kerzen der Länge step (Sekunden) falten."""
    candles, cur = [], None
    for ts, o, h, l, c, v in rows:
        b = ts // step * step
        if cur is None or b != cur["t"]:
            if cur:
                candles.append(cur)
            cur = {"t": b, "o": o, "h": h, "l": l, "c": c, "v": v or 0}
        else:
            cur["h"] = max(cur["h"], h); cur["l"] = min(cur["l"], l); cur["c"] = c; cur["v"] += v or 0
    if cur:
        candles.append(cur)
    return candles


def week_start(ts: int) -> int:
    """Montag 00:00 UTC der Woche, in der ts liegt."""
    return (ts - 4 * 86_400) // 604_800 * 604_800 + 4 * 86_400   # 1970-01-01 war ein Donnerstag


def fetch_binance_klines(coin: str, interval: str, limit: int) -> list[dict]:
    """Binance-Futures-Kerzen als Ergänzung für lange Zeiträume; 5 min im Speicher gehalten."""
    import urllib.request
    key = (coin, interval, limit)
    with _KLINE_LOCK:
        hit = _KLINE_CACHE.get(key)
        if hit and time.time() - hit[0] < 300:
            return hit[1]
    out = []
    for base, path in (("https://fapi.binance.com", "/fapi/v1/klines"), ("https://api.binance.com", "/api/v3/klines")):
        try:
            url = f"{base}{path}?symbol={coin}USDT&interval={interval}&limit={limit}"
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}),
                                        timeout=15) as r:
                data = json.loads(r.read().decode())
            if isinstance(data, list) and data:
                out = [{"t": int(k[0]) // 1000, "o": float(k[1]), "h": float(k[2]), "l": float(k[3]),
                        "c": float(k[4]), "v": float(k[5])} for k in data]
                break
        except Exception:
            continue
    with _KLINE_LOCK:
        _KLINE_CACHE[key] = (time.time(), out)
    return out


def load_long_candles(con, coin: str, agg: int, minutes: int) -> tuple[list[dict], str]:
    """
    Kerzen ab 4 h Raster: aus den vorhandenen Tabellen der Datenbank, ergänzt
    um Binance, wo die eigene Aufzeichnung nicht zurückreicht.
      4 h   -> klines30 (30-min-Kerzen von Binance, falls hl_timestats geladen hat),
               sonst Binance 4h-Kerzen; die jüngsten Stunden aus den eigenen 1-min-Bars
      1 Tag -> daily_bars (5 Jahre, von hl_binance), sonst Binance 1d
      1 Wo  -> daily_bars zu ISO-Wochen gefaltet, sonst Binance 1w
    Liefert (Kerzen, Quellenangabe).
    """
    now = int(time.time()); t_from = now - minutes * 60; step = agg * 60
    src = []
    if agg == 240:
        try:
            rows = con.execute("SELECT ts, open, high, low, close, volume FROM klines30 WHERE coin=? AND ts>=? ORDER BY ts",
                               (coin, t_from)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        cands = aggregate([tuple(r) for r in rows], step) if rows else []
        if cands and cands[0]["t"] <= t_from + 2 * 86_400:
            candles, src = cands, ["Binance-30-min-Kerzen (klines30)"]
        else:
            candles, src = fetch_binance_klines(coin, "4h", 6 * 30 + 2), ["Binance 4h"]
        # die eigenen Minutenbars ersetzen das jüngste Stück, wo sie vorliegen
        own = con.execute("SELECT ts, open, high, low, close, volume FROM bars WHERE coin=? AND ts>=? ORDER BY ts",
                          (coin, max(t_from, now - 8 * 86_400))).fetchall()
        own_c = aggregate([tuple(r) for r in own], step)
        if own_c:
            first_own = own_c[0]["t"]
            candles = [c for c in candles if c["t"] < first_own] + own_c
            src.append("jüngste Kerzen aus eigenen Hyperliquid-Bars")
    else:
        try:
            rows = con.execute("SELECT ts, open, high, low, close, volume FROM daily_bars WHERE coin=? AND ts>=? ORDER BY ts",
                               (coin, t_from - 7 * 86_400)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        if rows and rows[0][0] <= t_from + 30 * 86_400:
            daily = [{"t": r[0], "o": r[1], "h": r[2], "l": r[3], "c": r[4], "v": r[5] or 0} for r in rows]
            src = ["Tageskerzen (daily_bars, Binance via hl_binance)"]
        else:
            daily = fetch_binance_klines(coin, "1d", min(1000, minutes // 1440 + 7))
            src = ["Binance 1d"]
        if agg >= 10080:
            weeks, cur = [], None
            for c in daily:
                w = week_start(c["t"])
                if cur is None or cur["t"] != w:
                    if cur:
                        weeks.append(cur)
                    cur = dict(c, t=w)
                else:
                    cur["h"] = max(cur["h"], c["h"]); cur["l"] = min(cur["l"], c["l"]); cur["c"] = c["c"]; cur["v"] += c["v"]
            if cur:
                weeks.append(cur)
            candles = weeks
        else:
            candles = daily
        candles = [c for c in candles if c["t"] >= t_from - (604_800 if agg >= 10080 else 0)]
        # laufende Kerze: Schluss aus dem eigenen aktuellen Kurs
        last = con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if candles and last and last[0]:
            candles[-1]["c"] = last[0]
            candles[-1]["h"] = max(candles[-1]["h"], last[0]); candles[-1]["l"] = min(candles[-1]["l"], last[0])
    return candles, " + ".join(src)


# ---------------------------------------------------------------------------
# Binance als zweite Quelle. Grundsatz: Datenbank zuerst (bnc_liquidations,
# bnc_metrics, bnc_bars, daily_bars), Live-Abfragen nur für das, was nicht
# gespeichert wird (Kerzen kurzer Raster, Orderbuch, Funding), mit Speicher-Cache
# und stiller Rückfallebene, damit das Dashboard ohne Netz nicht bricht.
# ---------------------------------------------------------------------------

_BNC_CACHE: dict = {}
_BNC_LOCK = threading.Lock()
BNC_INTERVALS = {1: "1m", 5: "5m", 15: "15m", 60: "1h", 240: "4h", 1440: "1d", 10080: "1w"}


def _cached(key, ttl, fn):
    with _BNC_LOCK:
        hit = _BNC_CACHE.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    try:
        val = fn()
    except Exception:
        val = None
    with _BNC_LOCK:
        _BNC_CACHE[key] = (time.time(), val)
    return val


def _bnc_get(path: str, params: dict, timeout: int = 12):
    import urllib.request, urllib.parse
    url = f"https://fapi.binance.com{path}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}),
                                timeout=timeout) as r:
        return json.loads(r.read().decode())


def bucket_px(px: float) -> float:
    step = math.log(1.0025)
    return round(math.exp(round(math.log(px) / step) * step), 6)


def bnc_candles(con, coin: str, agg: int, minutes: int) -> tuple[list[dict], str]:
    """Binance-Kerzen im gewünschten Raster: live (30 s Cache), sonst aus bnc_bars/daily_bars."""
    iv = BNC_INTERVALS.get(agg, "5m")
    limit = min(1500, max(10, minutes // max(agg, 1) + 2))
    live = _cached(("kl", coin, iv, limit), 30, lambda: [
        {"t": int(k[0]) // 1000, "o": float(k[1]), "h": float(k[2]), "l": float(k[3]), "c": float(k[4]), "v": float(k[5])}
        for k in _bnc_get("/fapi/v1/klines", {"symbol": f"{coin}USDT", "interval": iv, "limit": limit})])
    if live:
        return live, f"Binance {iv}"
    t_from = int(time.time()) - minutes * 60
    table = "daily_bars" if agg >= 1440 else "bnc_bars"
    try:
        rows = con.execute(f"SELECT ts, open, high, low, close, volume FROM {table} WHERE coin=? AND ts>=? ORDER BY ts",
                           (coin, t_from)).fetchall()
    except sqlite3.OperationalError:
        rows = []
    return aggregate([tuple(r) for r in rows], agg * 60), f"{table} (gespeichert, Live-Abruf nicht möglich)"


def bnc_liqs(con, coin: str, since: int) -> list[tuple]:
    """Eingetretene Liquidationen (ts, px, notional, side_liq): side_liq long = Long liquidiert (SELL-Fill)."""
    try:
        rows = con.execute("SELECT ts, price, notional, side FROM bnc_liquidations WHERE coin=? AND ts>=? ORDER BY ts",
                           (coin, since)).fetchall()
    except sqlite3.OperationalError:
        return []
    return [(r[0], r[1], r[2], "long" if str(r[3]).upper().startswith("S") else "short") for r in rows]


def bnc_book(coin: str, price: float) -> list[dict]:
    """Orderbuch-Tiefe als Cluster im 0,25-%-Raster (kind limit_buy/limit_sell), ±30 % um den Kurs."""
    def fetch():
        d = _bnc_get("/fapi/v1/depth", {"symbol": f"{coin}USDT", "limit": 1000})
        out = {}
        for side, kind in (("bids", "limit_buy"), ("asks", "limit_sell")):
            for p, q in d.get(side, []):
                p, q = float(p), float(q)
                if not price or abs(p / price - 1) > 0.30:
                    continue
                b = bucket_px(p)
                c = out.setdefault((kind, b), {"kind": kind, "px": b, "notional": 0.0, "n": 0, "addrs": 0, "src": "bnc"})
                c["notional"] += p * q; c["n"] += 1
        return list(out.values())
    return _cached(("book", coin, round(price / 50) if price else 0), 15, fetch) or []


def bnc_funding(coin: str):
    def fetch():
        d = _bnc_get("/fapi/v1/premiumIndex", {"symbol": f"{coin}USDT"})
        return float(d.get("lastFundingRate") or 0) / 8       # Binance: je 8 h -> je Stunde wie bei Hyperliquid
    return _cached(("funding", coin), 60, fetch)


def bnc_metrics_series(con, coin: str, hours: int) -> dict:
    """Kennzahlen als Zeitreihen: gespeichert (bnc_metrics), Verhältnisse zusätzlich live nachgeladen (5 min Cache)."""
    since = int(time.time()) - hours * 3600
    out: dict = {}
    try:
        for m, ts, v in con.execute("SELECT metric, ts, value FROM bnc_metrics WHERE coin=? AND ts>=? ORDER BY ts",
                                    (coin, since)):
            out.setdefault(m, []).append([ts, v])
    except sqlite3.OperationalError:
        pass
    per = "5m" if hours <= 24 else "1h"
    limit = min(500, hours * (12 if per == "5m" else 1) + 2)
    live = _cached(("ratios", coin, per, limit), 300, lambda: {
        m: [[int(r["timestamp"]) // 1000, float(r[field])] for r in _bnc_get(path, {"symbol": f"{coin}USDT", "period": per, "limit": limit})]
        for path, m, field in (("/futures/data/globalLongShortAccountRatio", "global_ls_account", "longShortRatio"),
                               ("/futures/data/topLongShortPositionRatio", "top_ls_position", "longShortRatio"),
                               ("/futures/data/takerlongshortRatio", "taker_ls", "buySellRatio"),
                               ("/futures/data/openInterestHist", "oi_notional", "sumOpenInterestValue"))})
    if live:
        for m, series in live.items():
            merged = {t: v for t, v in out.get(m, [])}
            merged.update({t: v for t, v in series if t >= since})
            out[m] = [[t, merged[t]] for t in sorted(merged)]
    latest = {m: (ser[-1][1] if ser else None) for m, ser in out.items()}
    return {"series": out, "latest": latest}


def attach_binance(con, payload: dict, coin: str, agg: int, minutes: int, src: str) -> dict:
    """
    src == 'bnc':    Kerzen, Marken, Orderbuch, Funding, Trend, RSI, FVGs aus Binance;
                     Marken = eingetretene Liquidationen im Chartzeitraum.
    src == 'fusion': Hyperliquid-Chart bleibt; dazu Binance-Orderbuch je Preisstufe
                     zu den Orders addiert, eingetretene Liquidationen beider Börsen als
                     Marker, Volumen/Funding beider Börsen, Kennzahlen.
    """
    now = int(time.time())
    cand, csrc = bnc_candles(con, coin, agg, minutes)
    price_b = cand[-1]["c"] if cand else (payload.get("price") or 0)
    liqs = bnc_liqs(con, coin, now - minutes * 60)
    book = bnc_book(coin, price_b or payload.get("price") or 0)
    fund = bnc_funding(coin)
    met = bnc_metrics_series(con, coin, 24)
    vol_b = sum(c["v"] * c["c"] for c in cand if c["t"] >= now - 3600) if cand else 0
    liq_marks = [(ts, px, usd, side, "bnc") for ts, px, usd, side in liqs]
    # eigene (Hyperliquid) Liquidationen im selben Fenster als Marker
    try:
        for r in con.execute("SELECT ts, px, px*sz, side FROM liquidations WHERE coin=? AND ts>=? ORDER BY ts",
                             (coin, now - minutes * 60)):
            liq_marks.append((r[0], r[1], r[2], "long" if str(r[3]).upper().startswith("A") else "short", "hl"))
    except sqlite3.OperationalError:
        pass
    payload["liq_marks"] = liq_marks
    cdc = cdc_snapshot(coin, price_b or payload.get("price") or 0)
    payload["cdc"] = cdc
    payload["bnc"] = {"metrics": met["latest"], "vol_1h": vol_b, "funding": fund, "book_n": len(book),
                      "liqs_1h": {"long": sum(u for t, p, u, sd in liqs if sd == "long" and t >= now - 3600),
                                  "short": sum(u for t, p, u, sd in liqs if sd == "short" and t >= now - 3600)}}
    if src == "bnc":
        if cand:
            payload["candles"] = cand; payload["source"] = csrc; payload["price"] = price_b
            payload["fvgs"] = find_fvgs(cand, 0.0005)
            closes = [c["c"] for c in cand]
            payload["rsi14"] = rsi14(closes) if len(closes) >= 16 else None
            m1, _ = bnc_candles(con, coin, 1, 120)
            payload["trend_60m"] = (m1[-1]["c"] / m1[-61]["c"] - 1) if len(m1) >= 61 else None
            payload["vol_1h"] = vol_b
        # Marken: eingetretene Liquidationen je Preisstufe im Chartzeitraum
        lv: dict = {}
        for ts, px, usd, side in liqs:
            c = lv.setdefault((bucket_px(px), side), {"px": bucket_px(px), "side": side, "notional": 0.0, "n_pos": 0})
            c["notional"] += usd; c["n_pos"] += 1
        levels = sorted(lv.values(), key=lambda x: -x["notional"])[:14]
        for l in levels:
            l["dist"] = (l["px"] / price_b - 1) if price_b else 0
        payload["levels"] = levels; payload["levels_realized"] = True
        payload["stops"] = {"clusters": book, "orders": [], "n_whales": 0, "n_fresh": 0, "n_with_orders": 0,
                            "oldest": None, "ts": now, "book": True}
        payload["funding"] = fund
        if book:
            near = lambda kind: sum(c["notional"] for c in book if c["kind"] == kind and abs(c["px"] / price_b - 1) <= 0.005)
            b, a = near("limit_buy"), near("limit_sell")
            payload["book"] = {"imb_50": (b - a) / (b + a) if (b + a) else 0, "bid_50": b, "ask_50": a, "src": "bnc"}
        payload["tick_events"] = []
    else:   # fusion
        stops = payload.get("stops") or {"clusters": []}
        merged: dict = {}
        for c in stops.get("clusters", []):
            merged[(c["kind"], c["px"])] = dict(c)
        for c in book:
            key = (c["kind"], c["px"])
            if key in merged:
                merged[key]["notional"] += c["notional"]; merged[key]["n"] += c["n"]; merged[key]["src"] = "both"
            else:
                merged[key] = dict(c)
        p0 = payload.get("price") or price_b
        for c in merged.values():
            c["dist"] = (c["px"] / p0 - 1) if p0 else 0
        # Crypto.com-Orderbuch ebenfalls je Preisstufe addieren (Data Mix Fusion: alle Quellen)
        for c in (cdc or {}).get("book", []):
            key = (c["kind"], c["px"])
            if key in merged:
                merged[key]["notional"] += c["notional"]; merged[key]["n"] += c["n"]; merged[key]["src"] = "mix"
            else:
                merged[key] = dict(c)
        for c in merged.values():
            c["dist"] = (c["px"] / p0 - 1) if p0 else 0
        stops["clusters"] = sorted(merged.values(), key=lambda c: c["px"]); stops["book_n"] = len(book); stops["cdc_book_n"] = len((cdc or {}).get("book", []))
        payload["stops"] = stops
        vol_c = (cdc or {}).get("vol_1h") or 0
        hl_vol = payload.get("vol_1h") or 0
        payload["vol_1h"] = hl_vol + vol_b + vol_c
        payload["vol_split"] = {"hl": hl_vol, "bnc": vol_b, "cdc": vol_c}
        if fund is not None and payload.get("funding") is not None:
            payload["funding_bnc"] = fund
    return payload


def rsi14(closes: list) -> float | None:
    if len(closes) < 16:
        return None
    gains, losses = [], []
    for a, b in zip(closes[-15:-1], closes[-14:]):
        gains.append(max(b - a, 0)); losses.append(max(a - b, 0))
    ag, al = sum(gains) / 14, sum(losses) / 14
    return 100.0 if al == 0 else round(100 - 100 / (1 + ag / al), 1)


# ---------------------------------------------------------------------------
# Zugangsschlüssel (accesstokens.json, normale Datei) und Crypto.com als dritte Börse.
# Crypto.com-Marktdaten sind öffentlich -- kein Schlüssel nötig; die Datei ist für
# Quellen gedacht, die später dazukommen (CoinGlass, CryptoQuant, Glassnode, Nansen, Arkham).
# ---------------------------------------------------------------------------

TOKENS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "accesstokens.json")
_TOK: dict = {"mtime": 0, "data": {}}


def tokens() -> dict:
    """Schlüssel aus accesstokens.json; leere Werte gelten als nicht vorhanden."""
    try:
        m = os.path.getmtime(TOKENS_FILE)
    except OSError:
        return {}
    if m != _TOK["mtime"]:
        try:
            with open(TOKENS_FILE) as f:
                raw = json.load(f)
            _TOK["data"] = {k: {kk: vv for kk, vv in v.items() if vv and not kk.startswith("_")}
                            for k, v in raw.items() if isinstance(v, dict)}
        except (OSError, ValueError):
            _TOK["data"] = {}
        _TOK["mtime"] = m
    return _TOK["data"]


CDC_BASE = "https://api.crypto.com/exchange/v1/public/"
CDC_TF = {1: "M1", 5: "M5", 15: "M15", 60: "H1", 240: "H4", 1440: "D1", 10080: "7D"}


def cdc_get(method: str, params: dict):
    """Öffentliche Crypto.com-Exchange-API; HL_TEST_STUBS=1 liefert feste Antworten für Tests."""
    if os.environ.get("HL_TEST_STUBS"):
        return _cdc_stub(method, params)
    import urllib.request, urllib.parse
    url = CDC_BASE + method + "?" + urllib.parse.urlencode(params)
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}), timeout=12) as r:
        d = json.loads(r.read().decode())
    if d.get("code") not in (0, "0", None):
        raise RuntimeError(f"crypto.com {method}: {d.get('code')} {d.get('message', '')}")
    return d.get("result", {})


def _cdc_stub(method: str, params: dict):
    now_ms = int(time.time() * 1000); px = 77100.0
    if method == "get-tickers":
        return {"data": [{"i": params.get("instrument_name"), "a": str(px), "v": "5580.6", "vv": "434638617.0", "oi": "6273.37",
                          "h": "78920", "l": "76622", "c": "-0.0122", "b": str(px - 0.1), "k": str(px + 0.1), "t": now_ms}]}
    if method == "get-book":
        return {"data": [{"bids": [[str(px - 5 * (i + 1)), str(0.3 + i * 0.05), "1"] for i in range(50)],
                          "asks": [[str(px + 5 * (i + 1)), str(0.25 + i * 0.05), "1"] for i in range(50)], "t": now_ms}]}
    if method == "get-trades":
        return {"data": [{"p": str(px), "q": "0.05" if i % 3 else "0.20", "s": "BUY" if i % 4 else "SELL", "t": now_ms - i * 1000} for i in range(150)]}
    if method == "get-candlestick":
        return {"data": [{"o": px, "h": px + 100, "l": px - 100, "c": px, "v": "100", "t": now_ms - k * 3600_000} for k in range(50)]}
    if method == "get-valuations":
        vt = params.get("valuation_type")
        return {"data": [{"v": str(px * (1.0001 if vt == "mark_price" else 1.0)), "t": now_ms}]}
    return {}


def cdc_snapshot(coin: str, price: float) -> dict | None:
    """
    Crypto.com-Kennzahlen für einen Coin, 30 s im Speicher: Open Interest (Coins und USD),
    24-h-Volumen, Stundenvolumen aus Kerzen, Taker-Flow aus den letzten 150 Trades,
    Prämie Mark gegen Index, Orderbuch als Cluster (kind limit_buy/limit_sell, src cdc).
    None, wenn der Coin dort nicht gehandelt wird oder die API nicht erreichbar ist.
    """
    inst = f"{coin}USD-PERP"
    def fetch():
        t = cdc_get("get-tickers", {"instrument_name": inst}).get("data") or []
        if not t:
            return None
        t = t[0]
        last = float(t.get("a") or price or 0)
        oi = float(t.get("oi") or 0)
        out = {"last": last, "oi": oi, "oi_usd": oi * last, "vol_24h_usd": float(t.get("vv") or 0),
               "high": float(t.get("h") or 0), "low": float(t.get("l") or 0), "ts": int(time.time())}
        try:
            c = cdc_get("get-candlestick", {"instrument_name": inst, "timeframe": "H1"}).get("data") or []
            out["vol_1h"] = sum(float(k.get("v") or 0) for k in c[:1]) * last if c else 0
            out["vol_24h_from_candles"] = sum(float(k.get("v") or 0) for k in c[:24]) * last if c else 0
        except Exception:
            out["vol_1h"] = 0
        try:
            tr = cdc_get("get-trades", {"instrument_name": inst, "count": 150}).get("data") or []
            buy = sum(float(x.get("q") or 0) for x in tr if str(x.get("s", "")).upper() == "BUY")
            sell = sum(float(x.get("q") or 0) for x in tr if str(x.get("s", "")).upper() == "SELL")
            out["taker_ls"] = (buy / sell) if sell > 0 else (None if buy == 0 else 9.99)
            out["taker_n"] = len(tr); out["taker_span_s"] = (int(tr[0].get("t", 0)) - int(tr[-1].get("t", 0))) / 1000 if len(tr) > 1 else 0
        except Exception:
            out["taker_ls"] = None
        try:
            mk = float((cdc_get("get-valuations", {"instrument_name": inst, "valuation_type": "mark_price", "count": 1}).get("data") or [{}])[0].get("v") or 0)
            ix = float((cdc_get("get-valuations", {"instrument_name": f"{coin}USD-INDEX", "valuation_type": "index_price", "count": 1}).get("data") or [{}])[0].get("v") or 0)
            out["premium"] = (mk / ix - 1) if mk and ix else None
        except Exception:
            out["premium"] = None
        try:
            bk = (cdc_get("get-book", {"instrument_name": inst, "depth": 50}).get("data") or [{}])[0]
            clusters: dict = {}
            for side, kind in (("bids", "limit_buy"), ("asks", "limit_sell")):
                for lvl in bk.get(side, []):
                    p, q = float(lvl[0]), float(lvl[1])
                    if not last or abs(p / last - 1) > 0.30:
                        continue
                    b = bucket_px(p)
                    c = clusters.setdefault((kind, b), {"kind": kind, "px": b, "notional": 0.0, "n": 0, "addrs": 0, "src": "cdc"})
                    c["notional"] += p * q; c["n"] += 1
            out["book"] = list(clusters.values())
        except Exception:
            out["book"] = []
        return out
    return _cached(("cdc", coin), 30, fetch)


# ---------------------------------------------------------------------------
# Weitere Quellen: Bybit, OKX (öffentliche Futures-Endpunkte), ETF-Flows (Farside,
# CoinGlass mit Schlüssel), Smart Money aus dem Hyperliquid-Leaderboard.
# Jede Quelle darf einzeln ausfallen; HL_TEST_STUBS=1 liefert feste Antworten.
# ---------------------------------------------------------------------------

def fetch_json(url: str, timeout: int = 12, data: bytes | None = None, text: bool = False):
    if os.environ.get("HL_TEST_STUBS"):
        return _src_stub(url, data, text)
    import urllib.request
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0",
                                                          **({"Content-Type": "application/json"} if data else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read().decode(errors="replace")
    return raw if text else json.loads(raw)


def _src_stub(url: str, data, text):
    """Feste Antworten für Tests ohne Netz -- Feldnamen wie in den echten APIs."""
    now_ms = int(time.time() * 1000); px = 77100.0
    if "api.bybit.com" in url:
        if "/tickers" in url:
            return {"result": {"list": [{"lastPrice": str(px), "openInterest": "51000", "openInterestValue": str(51000 * px), "fundingRate": "0.0001", "turnover24h": "9.8e9", "volume24h": "127000"}]}}
        if "account-ratio" in url:
            return {"result": {"list": [{"buyRatio": "0.58", "sellRatio": "0.42", "timestamp": str(now_ms)}]}}
        if "recent-trade" in url:
            return {"result": {"list": [{"price": str(px), "size": "0.1" if i % 3 else "0.4", "side": "Buy" if i % 5 else "Sell", "time": str(now_ms - i * 500)} for i in range(500)]}}
    if "okx.com" in url:
        if "/public/open-interest" in url:
            return {"data": [{"instId": "BTC-USDT-SWAP", "oi": "2900000", "oiCcy": "29000", "ts": str(now_ms)}]}
        if "/market/ticker" in url:
            return {"data": [{"last": str(px), "vol24h": "2500000", "volCcy24h": "25000", "ts": str(now_ms)}]}
        if "/public/funding-rate" in url:
            return {"data": [{"fundingRate": "0.00012", "nextFundingRate": "0.0001"}]}
        if "long-short-account-ratio" in url:
            return {"data": [[str(now_ms), "1.9"]]}
        if "taker-volume" in url:
            return {"data": [[str(now_ms), "1200", "1500"]]}
        if "/public/instruments" in url:
            return {"data": [{"instId": "BTC-USDT-SWAP", "ctVal": "0.01"}]}
        if "liquidation-orders" in url:
            return {"data": [{"details": [{"side": "sell", "sz": "50", "bkPx": str(px - 500), "ts": str(now_ms - 60000)}, {"side": "buy", "sz": "20", "bkPx": str(px + 400), "ts": str(now_ms - 120000)}]}]}
    if "farside.co.uk" in url:
        rows = "".join(f"<tr><td>{d} Sep 2026</td><td>120.5</td><td>(10.2)</td><td>-</td><td>{tot}</td></tr>"
                       for d, tot in ((8, "301.4"), (9, "(45.0)"), (10, "212.7")))
        return f"<html><table><tr><th>Date</th><th>IBIT</th><th>FBTC</th><th>GBTC</th><th>Total</th></tr>{rows}</table></html>"
    if "stats-data.hyperliquid.xyz" in url:
        rows = [{"ethAddress": f"0x{i:040x}", "accountValue": str(2e6 + i * 1e5), "displayName": ("Bobby" if i == 3 else None),
                 "windowPerformances": [["day", {"pnl": "1000", "roi": "0.01", "vlm": "1e6"}], ["week", {"pnl": "5000", "roi": "0.02", "vlm": "5e6"}],
                                        ["month", {"pnl": str(3e6 - i * 4e4), "roi": "0.3", "vlm": "5e7"}], ["allTime", {"pnl": "9e6", "roi": "1", "vlm": "1e9"}]]} for i in range(120)]
        return {"leaderboardRows": rows}
    if "api.hyperliquid.xyz/info" in url and data:
        req = json.loads(data.decode()); i = int(req.get("user", "0x0")[2:], 16)
        side = 1 if i % 3 else -1
        return {"assetPositions": [{"type": "oneWay", "position": {"coin": "BTC", "szi": str(side * (10 + i % 7)), "positionValue": str((10 + i % 7) * px),
                                                                     "leverage": {"type": "cross", "value": 10}, "liquidationPx": str(px * (0.9 if side > 0 else 1.1)), "entryPx": str(px)}}],
                "marginSummary": {"accountValue": "2e6"}}
    return {} if not text else ""


def _f(x, default=0.0) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def bybit_snapshot(coin: str) -> dict | None:
    """Bybit linear Perpetual: OI, Funding, 24-h-Umsatz, Long/Short-Konten, Taker aus 500 Trades."""
    sym = f"{coin}USDT"; base = "https://api.bybit.com/v5/market"
    def fetch():
        t = (fetch_json(f"{base}/tickers?category=linear&symbol={sym}").get("result") or {}).get("list") or []
        if not t:
            return None
        t = t[0]; last = _f(t.get("lastPrice"))
        out = {"last": last, "oi": _f(t.get("openInterest")), "oi_usd": _f(t.get("openInterestValue")) or _f(t.get("openInterest")) * last,
               "funding": _f(t.get("fundingRate")) / 8, "vol_24h_usd": _f(t.get("turnover24h")), "ts": int(time.time())}
        try:
            r = (fetch_json(f"{base}/account-ratio?category=linear&symbol={sym}&period=5min&limit=1").get("result") or {}).get("list") or []
            if r:
                b, s_ = _f(r[0].get("buyRatio")), _f(r[0].get("sellRatio"))
                out["ls_account"] = (b / s_) if s_ > 0 else None
        except Exception:
            out["ls_account"] = None
        try:
            tr = (fetch_json(f"{base}/recent-trade?category=linear&symbol={sym}&limit=500").get("result") or {}).get("list") or []
            buy = sum(_f(x.get("size")) for x in tr if str(x.get("side", "")).lower() == "buy")
            sell = sum(_f(x.get("size")) for x in tr if str(x.get("side", "")).lower() == "sell")
            out["taker_ls"] = (buy / sell) if sell > 0 else None; out["taker_n"] = len(tr)
            ts_ = [_f(x.get("time")) for x in tr if x.get("time")]
            out["taker_span_s"] = (max(ts_) - min(ts_)) / 1000 if len(ts_) > 1 else 0
            out["vol_1h"] = out["vol_24h_usd"] / 24      # Näherung: gleichmäßig über den Tag
        except Exception:
            out["taker_ls"] = None; out["vol_1h"] = out["vol_24h_usd"] / 24
        return out
    return _cached(("bybit", coin), 45, fetch)


def okx_snapshot(coin: str) -> dict | None:
    """OKX USDT-Swap: OI, Funding, 24-h-Volumen, Long/Short-Konten, Taker-Volumen, jüngste Liquidationen."""
    inst = f"{coin}-USDT-SWAP"; base = "https://www.okx.com/api/v5"
    def fetch():
        tk = (fetch_json(f"{base}/market/ticker?instId={inst}").get("data") or [])
        if not tk:
            return None
        tk = tk[0]; last = _f(tk.get("last"))
        out = {"last": last, "vol_24h_usd": _f(tk.get("volCcy24h")) * last, "ts": int(time.time())}
        out["vol_1h"] = out["vol_24h_usd"] / 24
        try:
            oi = (fetch_json(f"{base}/public/open-interest?instType=SWAP&instId={inst}").get("data") or [{}])[0]
            out["oi"] = _f(oi.get("oiCcy")); out["oi_usd"] = out["oi"] * last
        except Exception:
            out["oi"] = 0; out["oi_usd"] = 0
        try:
            fr = (fetch_json(f"{base}/public/funding-rate?instId={inst}").get("data") or [{}])[0]
            out["funding"] = _f(fr.get("fundingRate")) / 8
        except Exception:
            out["funding"] = None
        try:
            ls = (fetch_json(f"{base}/rubik/stat/contracts/long-short-account-ratio?ccy={coin}&period=5m").get("data") or [])
            out["ls_account"] = _f(ls[0][1]) if ls else None
        except Exception:
            out["ls_account"] = None
        try:
            tv = (fetch_json(f"{base}/rubik/stat/taker-volume?ccy={coin}&instType=CONTRACTS&period=5m").get("data") or [])
            if tv:
                sell, buy = _f(tv[0][1]), _f(tv[0][2])
                out["taker_ls"] = (buy / sell) if sell > 0 else None
        except Exception:
            out["taker_ls"] = None
        try:
            ct = _cached(("okx_ctval", coin), 86_400, lambda: _f(((fetch_json(f"{base}/public/instruments?instType=SWAP&instId={inst}").get("data") or [{}])[0]).get("ctVal"), 0.01)) or 0.01
            lq = (fetch_json(f"{base}/public/liquidation-orders?instType=SWAP&uly={coin}-USDT&state=filled&limit=100").get("data") or [])
            det = lq[0].get("details", []) if lq else []
            since = (time.time() - 3600) * 1000
            out["liq_1h_long"] = sum(_f(d.get("sz")) * _f(d.get("bkPx")) for d in det if d.get("side") == "sell" and _f(d.get("ts")) >= since) * ct
            out["liq_1h_short"] = sum(_f(d.get("sz")) * _f(d.get("bkPx")) for d in det if d.get("side") == "buy" and _f(d.get("ts")) >= since) * ct
        except Exception:
            out["liq_1h_long"] = out["liq_1h_short"] = None
        return out
    return _cached(("okx", coin), 45, fetch)


def etf_flows(coin: str) -> dict | None:
    """
    Tägliche Netto-Flüsse der Spot-ETFs (Mio USD): CoinGlass mit Schlüssel, sonst Farside-Tabelle.
    Liefert die letzten 10 Tage, den letzten Tag, die 5-Tage-Summe und die Serie gleicher Vorzeichen.
    """
    if coin not in ("BTC", "ETH"):
        return None
    def fetch():
        days: list = []
        key = (tokens().get("coinglass") or {}).get("api_key")
        if key:
            try:
                import urllib.request
                url = f"https://open-api-v4.coinglass.com/api/etf/{'bitcoin' if coin == 'BTC' else 'ethereum'}/flow-history"
                req = urllib.request.Request(url, headers={"CG-API-KEY": key, "User-Agent": "hl-dashboard/1.0"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    d = json.loads(r.read().decode())
                for row in (d.get("data") or [])[-15:]:
                    ts = int(row.get("timestamp") or 0) // 1000
                    days.append((time.strftime("%Y-%m-%d", time.gmtime(ts)), _f(row.get("flow_usd")) / 1e6))
            except Exception:
                days = []
        if not days:
            html = fetch_json(f"https://farside.co.uk/{coin.lower()}/", timeout=20, text=True)
            months = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}
            for row in re.findall(r"<tr[^>]*>(.*?)</tr>", html, re.S):
                cells = [re.sub(r"<[^>]+>", "", c).replace("&nbsp;", " ").strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)]
                if len(cells) < 3:
                    continue
                m = re.match(r"(\d{1,2}) (\w{3}) (\d{4})", cells[0])
                if not m or m.group(2) not in months:
                    continue
                tot = cells[-1].replace(",", "")
                neg = tot.startswith("(")
                val = _f(tot.strip("()"), 0.0) * (-1 if neg else 1) if tot not in ("-", "") else 0.0
                days.append((f"{m.group(3)}-{months[m.group(2)]:02d}-{int(m.group(1)):02d}", val))
        if not days:
            return None
        days = sorted(days)[-10:]
        vals = [v for _, v in days]
        streak = 0
        for v in reversed(vals):
            if v == 0 or (streak and (v > 0) != (vals[-1] > 0)):
                break
            streak += 1
        return {"days": days, "last": vals[-1], "last_date": days[-1][0], "sum5": sum(vals[-5:]), "streak": streak * (1 if vals[-1] > 0 else -1),
                "source": "CoinGlass" if key else "Farside"}
    return _cached(("etf", coin), 3600, fetch)


_WARM: dict = {}


def _lbact_bg(coin, price, days, min_big, newest_first, hourly):
    c = connect(Handler.db)
    try:
        return load_lb_activity(c, coin, price, days=days, min_big=min_big, newest_first=newest_first, hourly=hourly)
    finally:
        c.close()


def _warm(key, fn):
    """Langsame Quelle im Hintergrund berechnen: liefert den letzten Stand, stößt die Erneuerung an."""
    with _BNC_LOCK:
        hit = _BNC_CACHE.get(key)
        running = _WARM.get(key)
    fresh = hit and time.time() - hit[0] < {"smart": 600, "etf": 3600, "lbact": 30, "lbact48": 30}.get(key[0], 300)
    if fresh:
        return hit[1]
    if not running:
        def run():
            try:
                val = fn()
                with _BNC_LOCK:
                    _BNC_CACHE[key] = (time.time(), val)
            finally:
                with _BNC_LOCK:
                    _WARM[key] = None
        with _BNC_LOCK:
            _WARM[key] = threading.Thread(target=run, daemon=True)
            _WARM[key].start()
    return hit[1] if hit else None


_LB_CACHE: dict = {}


def load_leaderboard(con, coin: str, top_n: int = 20, days: int = 7) -> dict:
    key = (coin, top_n, days)
    with _LBACT_LOCK:
        hit = _LB_CACHE.get(key)
        if hit and time.time() - hit[0] < 30:
            return hit[1]
    out = _load_leaderboard(con, coin, top_n, days)
    with _LBACT_LOCK:
        _LB_CACHE[key] = (time.time(), out)
    return out


def _load_leaderboard(con, coin: str, top_n: int = 20, days: int = 7) -> dict:
    """
    Jüngste Abfrage des Recorders: Top-Konten mit Positionen (gruppiert), Trendreihe je
    Stunde für den Coin (lb_trend) und die BTC-Trendkachel (aktuell gegen 24 h zuvor).
    """
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.OperationalError:
        return {"ts": None, "accounts": [], "trend": [], "btc": None, "summary": None, "top_n": top_n}
    if not last:
        return {"ts": None, "accounts": [], "trend": [], "btc": None, "summary": None, "top_n": top_n}
    accts = [dict(r) for r in con.execute(
        "SELECT rank, addr, name, account_value, pnl_30d, roi_30d, pnl_7d, n_positions FROM lb_accounts WHERE ts=? AND rank<=? ORDER BY rank",
        (last, top_n))]
    pos = con.execute(
        "SELECT rank, addr, coin, side, size, pos_value, entry_px, liq_px, leverage, upnl, mark_px FROM lb_positions WHERE ts=? AND rank<=? ORDER BY rank, pos_value DESC",
        (last, top_n)).fetchall()
    by_addr: dict = {}
    for r in pos:
        by_addr.setdefault(r["addr"], []).append(dict(r))
    for a in accts:
        a["positions"] = by_addr.get(a["addr"], [])
        a["upnl"] = sum(p["upnl"] or 0 for p in a["positions"])
        a["pos_total"] = sum(p["pos_value"] or 0 for p in a["positions"])
    since = last - days * 86_400
    trend = [dict(r) for r in con.execute(
        "SELECT ts, n_long, n_short, usd_long, usd_short, net_usd, n_accounts, mark_px FROM lb_trend WHERE coin=? AND top_n=? AND ts>=? ORDER BY ts",
        (coin, top_n, since))]
    # aktuelle Verteilung im gewählten Coin aus der jüngsten Abfrage
    cur = {"n_long": 0, "n_short": 0, "usd_long": 0.0, "usd_short": 0.0}
    for r in pos:
        if r["coin"] == coin:
            if r["side"] == "long":
                cur["n_long"] += 1; cur["usd_long"] += r["pos_value"] or 0
            else:
                cur["n_short"] += 1; cur["usd_short"] += r["pos_value"] or 0
    cur["net_usd"] = cur["usd_long"] - cur["usd_short"]
    def btc_tile():
        btc_now = {"n_long": 0, "n_short": 0, "usd_long": 0.0, "usd_short": 0.0}
        for r in pos:
            if r["coin"] == "BTC":
                if r["side"] == "long":
                    btc_now["n_long"] += 1; btc_now["usd_long"] += r["pos_value"] or 0
                else:
                    btc_now["n_short"] += 1; btc_now["usd_short"] += r["pos_value"] or 0
        btc_now["net_usd"] = btc_now["usd_long"] - btc_now["usd_short"]
        ago = con.execute("SELECT net_usd, n_long, n_short FROM lb_trend WHERE coin='BTC' AND top_n=? AND ts<=? ORDER BY ts DESC LIMIT 1",
                          (top_n, last - 86_400)).fetchone()
        first = con.execute("SELECT net_usd FROM lb_trend WHERE coin='BTC' AND top_n=? AND ts>=? ORDER BY ts LIMIT 1", (top_n, since)).fetchone()
        btc_now["net_24h_ago"] = ago["net_usd"] if ago else None
        btc_now["delta_24h"] = (btc_now["net_usd"] - ago["net_usd"]) if ago else None
        btc_now["delta_7d"] = (btc_now["net_usd"] - first["net_usd"]) if first else None
        return btc_now
    # Leaderboard-Flow: Ereignisse DIREKTIONALER Konten in 30/60/180 min, Z-Score gegen 7-Tage-Stundenflüsse
    flow = {}; events = []
    try:
        dir_set = hl_forecast.lb_directional_addrs(con, coin)
        now_ = int(time.time())
        ev = con.execute("SELECT ts, addr, coin, event, side, delta_usd, pos_value, mark_px FROM lb_events WHERE coin=? AND ts>=? ORDER BY ts DESC",
                         (coin, now_ - 7 * 86_400)).fetchall()
        def signed(e):
            d = abs(e["delta_usd"] or 0)
            if e["event"] in ("open", "add", "flip"):
                return d if e["side"] == "long" else -d
            return -d if e["side"] == "long" else d
        names = {r["addr"]: (r["name"], r["rank"]) for r in con.execute("SELECT addr, name, rank FROM lb_accounts WHERE ts=?", (last,))}
        for w in (30, 60, 180):
            buy = sell = 0.0; nb = set(); ns = set()
            for e in ev:
                if e["ts"] < now_ - w * 60 or e["addr"] not in dir_set:
                    continue
                v = signed(e)
                if v > 0: buy += v; nb.add(e["addr"])
                elif v < 0: sell += -v; ns.add(e["addr"])
            flow[f"w{w}"] = {"buy_usd": buy, "sell_usd": sell, "net_usd": buy - sell, "n_buy": len(nb), "n_sell": len(ns)}
        hourly: dict = {}
        for e in ev:
            if e["addr"] in dir_set:
                hourly[e["ts"] // 3600] = hourly.get(e["ts"] // 3600, 0.0) + signed(e)
        vals = list(hourly.values())
        if len(vals) >= 24:
            m = sum(vals) / len(vals); sd = (sum((v - m) ** 2 for v in vals) / max(1, len(vals) - 1)) ** 0.5
            flow["z60"] = (flow["w60"]["net_usd"] - m) / sd if sd > 0 else 0.0
        else:
            flow["z60"] = None
        w60 = flow["w60"]; same = w60["n_buy"] if w60["net_usd"] > 0 else w60["n_sell"]
        flow["event_signal"] = bool(flow["z60"] is not None and abs(flow["z60"]) >= 2.5 and same >= 3)
        flow["n_directional"] = len(dir_set)
        events = [dict(e, directional=e["addr"] in dir_set, name=names.get(e["addr"], (None, None))[0], rank=names.get(e["addr"], (None, None))[1])
                  for e in ev[:40]]
    except sqlite3.OperationalError:
        pass
    return {"ts": last, "accounts": accts, "trend": trend, "btc": btc_tile(), "summary": cur, "top_n": top_n, "flow": flow, "events": events}


_LBACT_CACHE: dict = {}
_LBACT_LOCK = threading.Lock()

# Kaufdruck = Open Long + Close Short + Spot-Buy; Verkaufsdruck = Open Short + Close Long + Spot-Sell.
# Als SQL-Ausdruck, damit die Datenbank aggregiert -- nicht Python über hunderttausende Zeilen.
_IS_BUY_SQL = "COALESCE(buy, (CASE WHEN lower(dir) LIKE '%open long%' OR lower(dir) LIKE '%close short%' OR lower(dir) LIKE '%buy%' THEN 1 WHEN upper(side) LIKE 'B%' AND lower(dir) NOT LIKE '%sell%' AND lower(dir) NOT LIKE '%short%' AND lower(dir) NOT LIKE '%close long%' THEN 1 ELSE 0 END))"


_LBACT_CACHE: dict = {}
_LBACT_LOCK = threading.Lock()


def _is_buy(d: str, side: str) -> bool:
    d = (d or "").lower()
    if "open long" in d or "close short" in d or "buy" in d:
        return True
    if "open short" in d or "close long" in d or "sell" in d:
        return False
    return (side or "").upper().startswith("B")


def load_lb_activity(con, coin: str, price: float, days: int = 3, min_big: float = 1e5, newest_first: bool = False,
                     hourly: bool = False) -> dict | None:
    """
    Käufe/Verkäufe der Top-Konten (Perp und Spot). Alle Summen rechnet SQLite über die Spalte
    buy (Index coin, ts, buy); Python sieht nur Gruppen. Ergebnis 30 s gehalten, weil /chart alle
    5 s anfragt. Vorher: Vollscan und Python-Summen je Aufruf -- das hat den Pi lahmgelegt.
    """
    key = (coin, days, min_big, newest_first, hourly, round(price / 50) if price else 0)
    with _LBACT_LOCK:
        hit = _LBACT_CACHE.get(key)
        if hit and time.time() - hit[0] < 30:
            return hit[1]
    try:
        last_fill = con.execute("SELECT MAX(ts) FROM lb_fills").fetchone()[0]
        has_buy = "buy" in {r[1] for r in con.execute("PRAGMA table_info(lb_fills)")}
    except sqlite3.OperationalError:
        return None
    if not last_fill:
        return None
    # Kaufdruck-Ausdruck: Spalte buy, sonst (alte Datenbank vor der Migration) aus dir/side
    BUY = "buy" if has_buy else ("(CASE WHEN lower(dir) LIKE '%open long%' OR lower(dir) LIKE '%close short%' OR lower(dir) LIKE '%buy%' THEN 1 "
                                 "WHEN lower(dir) LIKE '%open short%' OR lower(dir) LIKE '%close long%' OR lower(dir) LIKE '%sell%' THEN 0 "
                                 "WHEN upper(side) LIKE 'B%' THEN 1 ELSE 0 END)")
    now = int(time.time()); since = now - days * 86_400; d24 = now - 86_400
    per_coin: dict = {}
    for r in con.execute(f"""SELECT coin, market, {BUY} b, SUM(notional) usd, COUNT(*) n, SUM(closed_pnl) pnl,
                                    SUM(CASE WHEN ts>=? THEN notional ELSE 0 END) usd24
                             FROM lb_fills WHERE ts>=? GROUP BY coin, market, b""", (d24, since)):
        buy = bool(r["b"]); c = r["coin"]
        d = per_coin.setdefault(c, {"coin": c, "buy_usd": 0.0, "sell_usd": 0.0, "buy_usd_24h": 0.0, "sell_usd_24h": 0.0, "n_buyers": 0, "n_sellers": 0,
                                    "n": 0, "spot_usd": 0.0, "perp_usd": 0.0, "closed_pnl": 0.0})
        d["n"] += r["n"]; d["closed_pnl"] += r["pnl"] or 0
        d["buy_usd" if buy else "sell_usd"] += r["usd"] or 0; d["buy_usd_24h" if buy else "sell_usd_24h"] += r["usd24"] or 0
        d["spot_usd" if r["market"] == "spot" else "perp_usd"] += r["usd"] or 0
    for r in con.execute(f"SELECT coin, {BUY} b, COUNT(DISTINCT addr) a FROM lb_fills WHERE ts>=? GROUP BY coin, b", (since,)):
        if r["coin"] in per_coin:
            per_coin[r["coin"]]["n_buyers" if r["b"] else "n_sellers"] = r["a"]
    coins = []
    for c, d in sorted(per_coin.items(), key=lambda kv: -(kv[1]["buy_usd"] + kv[1]["sell_usd"])):
        d["net_usd"] = d["buy_usd"] - d["sell_usd"]; d["net_usd_24h"] = d["buy_usd_24h"] - d["sell_usd_24h"]; coins.append(d)
    names = {}
    try:
        last_lb = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
        for r in con.execute("SELECT addr, name, rank FROM lb_accounts WHERE ts=?", (last_lb,)):
            names[r["addr"]] = {"name": r["name"], "rank": r["rank"]}
    except sqlite3.OperationalError:
        pass
    per_acct: dict = {}
    for r in con.execute(f"""SELECT addr, {BUY} b, SUM(notional) usd, COUNT(*) n, MAX(ts) last, SUM(px*sz) pxsz, SUM(sz) sz
                             FROM lb_fills WHERE coin=? AND ts>=? GROUP BY addr, b""", (coin, since)):
        a = per_acct.setdefault(r["addr"], {"addr": r["addr"], "buy": 0.0, "sell": 0.0, "n": 0, "last": 0, "pxsz": 0.0, "sz": 0.0})
        a["n"] += r["n"]; a["last"] = max(a["last"], r["last"])
        if r["b"]:
            a["buy"] += r["usd"] or 0; a["pxsz"] += r["pxsz"] or 0; a["sz"] += r["sz"] or 0
        else:
            a["sell"] += r["usd"] or 0
    accts = sorted(per_acct.values(), key=lambda a: -(a["buy"] + a["sell"]))[:30]
    for a in accts:
        a["net"] = a["buy"] - a["sell"]; a["vwap_buy"] = (a["pxsz"] / a["sz"]) if a["sz"] else None
        a["since_buy_pct"] = ((price / a["vwap_buy"] - 1) * 100) if (a["vwap_buy"] and price) else None
        a.update(names.get(a["addr"], {})); a.pop("pxsz", None); a.pop("sz", None)
    big = []
    order = "ts DESC" if newest_first else "notional DESC"
    for r in con.execute(f"""SELECT ts, addr, market, dir, {BUY} b, px, notional, closed_pnl FROM lb_fills
                             WHERE coin=? AND ts>=? AND notional>=? ORDER BY {order} LIMIT ?""", (coin, since, min_big, 60 if newest_first else 25)):
        buy = bool(r["b"])
        big.append({"ts": r["ts"], "addr": r["addr"], "market": r["market"], "dir": r["dir"], "buy": buy, "px": r["px"], "notional": r["notional"],
                    "closed_pnl": r["closed_pnl"], "since_pct": ((price / r["px"] - 1) * 100 * (1 if buy else -1)) if (price and r["px"]) else None,
                    **names.get(r["addr"], {})})
    series = []
    if hourly:
        h0 = since // 3600 * 3600; buckets: dict = {}
        for r in con.execute(f"""SELECT (ts/3600)*3600 h, {BUY} b, SUM(notional) usd, COUNT(*) n FROM lb_fills
                                 WHERE coin=? AND ts>=? GROUP BY h, b""", (coin, h0)):
            d = buckets.setdefault(r["h"], {"ts": r["h"], "buy": 0.0, "sell": 0.0, "n": 0})
            d["buy" if r["b"] else "sell"] += r["usd"] or 0; d["n"] += r["n"]
        pxs = {}
        try:
            for r in con.execute("SELECT (ts/3600)*3600 h, MAX(ts) mts, close FROM bars WHERE coin=? AND ts>=? GROUP BY h", (coin, h0)):
                pxs[r["h"]] = r["close"]
        except sqlite3.OperationalError:
            pass
        cum = 0.0
        for t in range(h0, now + 1, 3600):
            d = buckets.get(t, {"ts": t, "buy": 0.0, "sell": 0.0, "n": 0}); cum += d["buy"] - d["sell"]
            series.append({**d, "cum": cum, "px": pxs.get(t)})
    spot = []
    try:
        last_spot = con.execute("SELECT MAX(ts) FROM lb_spot").fetchone()[0]
        if last_spot:
            for r in con.execute("SELECT coin, token, COUNT(*) n, SUM(total) total, SUM(value_usd) usd, SUM(entry_ntl) entry FROM lb_spot WHERE ts=? GROUP BY token ORDER BY usd DESC", (last_spot,)):
                spot.append({"coin": r["coin"], "token": r["token"], "n": r["n"], "total": r["total"], "usd": r["usd"] or 0, "entry": r["entry"] or 0})
    except sqlite3.OperationalError:
        pass
    sel = next((d for d in coins if d["coin"] == coin), None)
    out = {"since": since, "last_fill": last_fill, "coins": coins, "accounts": accts, "big": big, "spot": spot, "selected": sel, "days": days, "series": series}
    with _LBACT_LOCK:
        _LBACT_CACHE[key] = (time.time(), out)
    return out


def smart_money(con, coin: str, top_n: int = 50) -> dict | None:
    """Smart-Money-Kachel aus der jüngsten Leaderboard-Abfrage des Recorders (Top 50)."""
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    except sqlite3.OperationalError:
        return None
    if not last:
        return None
    out = {"n_accounts": con.execute("SELECT COUNT(*) FROM lb_accounts WHERE ts=? AND rank<=?", (last, top_n)).fetchone()[0],
           "coin": {"n_long": 0, "usd_long": 0.0, "n_short": 0, "usd_short": 0.0},
           "all": {"n_long": 0, "usd_long": 0.0, "n_short": 0, "usd_short": 0.0}, "ts": last}
    net: dict = {}
    for r in con.execute("SELECT addr, coin, side, pos_value FROM lb_positions WHERE ts=? AND rank<=?", (last, top_n)):
        signed = (r["pos_value"] or 0) * (1 if r["side"] == "long" else -1)
        d = net.setdefault(r["addr"], {"all": 0.0, "coin": 0.0})
        d["all"] += signed
        if r["coin"] == coin:
            d["coin"] += signed
    for addr, d in net.items():
        for key in ("all", "coin"):
            v = d[key]
            if v > 0:
                out[key]["n_long"] += 1; out[key]["usd_long"] += v
            elif v < 0:
                out[key]["n_short"] += 1; out[key]["usd_short"] += -v
    return out


def attach_sources(payload: dict, coin: str, src: str, con=None) -> dict:
    """ETF-Flows und Smart Money in jeder Quelle; Bybit und OKX im Binance- und Fusionsmodus."""
    payload["etf"] = _warm(("etf", coin), lambda: etf_flows(coin))
    payload["smart"] = smart_money(con, coin) if con is not None else None
    payload["lb"] = load_leaderboard(con, coin, 20) if con is not None else None
    # Käufe/Verkäufe: im Hintergrund berechnet (eigene Verbindung), der Aufruf liefert den letzten Stand sofort
    price = payload.get("price") or 0
    payload["lb_act"] = _warm(("lbact", coin, 3), lambda: _lbact_bg(coin, price, 3, 1e5, False, False))
    payload["lb_act48"] = _warm(("lbact48", coin, 2), lambda: _lbact_bg(coin, price, 2, 5e4, True, True))
    if src in ("bnc", "fusion"):
        payload["bybit"] = bybit_snapshot(coin)
        payload["okx"] = okx_snapshot(coin)
    return payload


def load_chart(con, coin: str, minutes: int = 240, agg: int = 1, top: int = 14,
               fvg_min: float = 0.0005):
    """Kerzen aus den 1-Minuten-Bars plus die stärksten aktuellen Level."""
    t_from = int(time.time()) - minutes * 60
    source = "eigene Hyperliquid-Bars"
    if agg >= 240:
        candles, source = load_long_candles(con, coin, agg, minutes)
        rows = con.execute("SELECT ts, open, high, low, close, volume FROM bars "
                           "WHERE coin=? AND ts>=? ORDER BY ts", (coin, int(time.time()) - 3600)).fetchall()
    else:
        rows = con.execute(
            "SELECT ts, open, high, low, close, volume FROM bars "
            "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
        candles = aggregate([tuple(r) for r in rows], max(agg, 1) * 60)

    # 60-Minuten-Trend aus den Minutenbars, unabhängig vom Chart-Raster
    trend = None
    if len(rows) >= 61:
        c_now, c_then = rows[-1]["close"], rows[-61]["close"]
        if c_then:
            trend = c_now / c_then - 1

    # RSI(14) nach Wilder auf dem angezeigten Kerzenraster
    rsi = None
    closes = [c["c"] for c in candles]
    if len(closes) >= 16:
        gains, losses = [], []
        for a, b in zip(closes[:-1], closes[1:]):
            d_ = b - a
            gains.append(max(d_, 0.0)); losses.append(max(-d_, 0.0))
        n = 14
        ag = sum(gains[:n]) / n
        al = sum(losses[:n]) / n
        for g_, l_ in zip(gains[n:], losses[n:]):
            ag = (ag * (n - 1) + g_) / n
            al = (al * (n - 1) + l_) / n
        rsi = 100.0 if al == 0 else 100.0 - 100.0 / (1.0 + ag / al)

    d = load_depth(con, coin)
    levels = []
    if d and d["price"]:
        px = d["price"]
        near = [r for r in d["rows"] if 0.88 * px < r["bucket_px"] < 1.15 * px]
        near.sort(key=lambda r: -r["notional"])
        for r in near[:top]:
            levels.append({
                "px": r["bucket_px"], "side": r["side"],
                "notional": r["notional"], "n_pos": r["n_pos"],
                "dist": (r["bucket_px"] - px) / px,
                # Verhältnis zum Stundenvolumen: entscheidet, ob ein Level trägt
                "x_vol": (r["notional"] / d["vol_1h"]) if d["vol_1h"] else 0,
            })

    try:
        events = [dict(r) for r in con.execute(
            "SELECT t_trigger, reason, move_pct, px_extreme, n_ticks, n_liqs "
            "FROM tick_events WHERE coin=? AND reason != 'control' "
            "ORDER BY t_trigger DESC LIMIT 5", (coin,))]
    except sqlite3.OperationalError:
        events = []

    # Zusatzsignale für die Konfluenz-Anzeige, alle ohne Speicherung
    book = funding = None
    danger = None
    try:
        r = con.execute("SELECT ts, spread_bps, bid_50, ask_50, imb_50 FROM book_summary "
                        "WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if r and time.time() - r["ts"] < 600:
            book = dict(r)
        r = con.execute("SELECT ts, funding, oi FROM ctx_bars WHERE coin=? "
                        "ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if r and time.time() - r["ts"] < 900:
            funding = dict(r)
        # Danger-Time: ist das aktuelle 30-Minuten-Fenster laut Zeit-Heatmap belastbar erhöht?
        import datetime as _dt
        nowu = _dt.datetime.now(_dt.timezone.utc)
        slot = nowu.hour * 2 + (1 if nowu.minute >= 30 else 0)
        r = con.execute("SELECT threshold, rate, lift FROM time_heatmap WHERE coin=? AND tz='UTC' "
                        "AND weekday=? AND slot=? AND robust=1 ORDER BY threshold DESC LIMIT 1",
                        (coin, nowu.weekday(), slot)).fetchone()
        if r:
            danger = dict(r)
    except sqlite3.OperationalError:
        pass

    fvgs = find_fvgs(candles, fvg_min)
    last = candles[-1]["c"] if candles else 0
    mas = load_mas(con, coin, last)
    stops = load_stops(con, coin, last)
    budget = load_api_budget(con)
    for g in fvgs:
        g["dist"] = ((g["bot"] if g["kind"] == "bull" else g["top"]) / last - 1) if last else 0

    return {
        "candles": candles, "levels": levels,
        "tick_events": events,
        "fvgs": fvgs,
        "book": book, "funding": funding, "danger": danger,
        "mas": mas, "source": source, "agg": agg, "stops": stops, "budget": budget,
        "price": d["price"] if d else None,
        "vol_1h": d["vol_1h"] if d else 0,
        "snapshot_ts": d["ts"] if d else 0,
        "trend_60m": trend,
        "rsi14": rsi,
        "rsi_tf": f"{agg} min" if agg < 60 else f"{agg // 60} h",
    }


def plot_heatmap(con, coin: str, hours: int, out: str,
                 threshold: float = 0.70, gamma: float = 2.6) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.colors import LinearSegmentedColormap
    from matplotlib.dates import DateFormatter, date2num

    d = load_grid(con, coin, hours)
    if d is None:
        print(f"Keine Daten für {coin} in den letzten {hours} h.")
        return

    z = np.array(d["grid"], dtype=float)

    # Perzentil-Zuordnung statt Normierung aufs Maximum: entscheidend ist der
    # Rang einer Zelle unter allen anderen. Anschließend eine Potenz, damit
    # die Masse dunkel bleibt und nur die stärksten Cluster leuchten.
    pos = z[z > 0]
    if pos.size == 0:
        print("Nur leere Zellen.")
        return
    srt = np.sort(pos)
    rank = np.searchsorted(srt, z, side="right") / srt.size
    rank[z <= 0] = 0.0
    vis = rank >= threshold
    q = np.zeros_like(rank)
    q[vis] = ((rank[vis] - threshold) / max(1e-9, 1 - threshold)) ** gamma
    q = np.ma.masked_where(~vis, q)

    cmap = LinearSegmentedColormap.from_list("liq", [
        (0.00, "#04060f"), (0.22, "#0a288c"), (0.45, "#0096c8"),
        (0.68, "#3cdcb4"), (0.85, "#ffd60a"), (1.00, "#ffffeb")])
    cmap.set_bad("#04060f")

    x = date2num([np.datetime64(t, "s") for t in d["times"]])
    y = np.array(d["levels"])

    fig, ax = plt.subplots(figsize=(15, 8.5))
    ax.set_facecolor("#04060f")
    mesh = ax.pcolormesh(x, y, q, cmap=cmap, vmin=0, vmax=1, shading="nearest")

    pt = date2num([np.datetime64(t, "s") for t, _ in d["price"]])
    ax.plot(pt, [p for _, p in d["price"]], color="#ffffff", lw=1.5,
            label="Kurs", zorder=5)

    if d["liqs"]:
        lt = date2num([np.datetime64(t, "s") for t, *_ in d["liqs"]])
        lp = [p for _, p, *_ in d["liqs"]]
        ls = [max(6, min(220, n / 4000)) for *_, n, _ in d["liqs"]]
        ax.scatter(lt, lp, s=ls, facecolor="none", edgecolor="#ff3b6b",
                   lw=1.1, zorder=6, label="Liquidationen")

    prices = [p for _, p in d["price"]]
    ax.set_ylim(min(prices) * 0.90, max(prices) * 1.10)
    ax.xaxis.set_major_formatter(DateFormatter("%d.%m %H:%M"))
    ax.set_title(f"{coin} — Liquidationscluster, letzte {hours} h · "
                 f"nur oberhalb Perzentil {threshold*100:.0f}", fontsize=12)
    ax.set_ylabel("Preis")
    ax.grid(alpha=0.10, ls=":")
    ax.legend(loc="upper left", framealpha=0.6)
    cb = fig.colorbar(mesh, ax=ax, pad=0.01)
    cb.set_label("relative Clusterstärke (Rang unter allen Zellen)")
    fig.autofmt_xdate()
    plt.tight_layout()
    plt.savefig(out, dpi=130, facecolor="#0d1117")
    print(f"Gespeichert: {out}")


def plot_depth(con, coin: str, out: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    d = load_depth(con, coin)
    if not d or not d["rows"] or not d["price"]:
        print(f"Kein aktueller Snapshot für {coin}.")
        return

    px, v1h = d["price"], d["vol_1h"]
    rows = [r for r in d["rows"] if 0.8 * px < r["bucket_px"] < 1.25 * px]
    if not rows:
        print("Keine Cluster im relevanten Preisbereich.")
        return

    fig, ax = plt.subplots(figsize=(9, 11))
    for r in rows:
        col = "#e04b4b" if r["side"] == "long" else "#3ba55d"
        ax.barh(r["bucket_px"], r["notional"], height=px * 0.0022,
                color=col, alpha=0.85)

    ax.axhline(px, color="#00e5ff", lw=2)
    ax.text(ax.get_xlim()[1], px, f"  {px:,.2f}", va="center",
            color="#00808f", fontsize=10, fontweight="bold")

    if v1h > 0:
        ax.axvline(v1h * 0.5, color="grey", ls="--", lw=1)
        ax.text(v1h * 0.5, ax.get_ylim()[1], " 0.5x 1h-Vol",
                rotation=90, va="top", fontsize=8, color="grey")

    ax.set_title(f"{coin} — Cluster um den Kurs\n"
                 f"rot = Long-Liquidationen, grün = Short-Liquidationen\n"
                 f"Stand {time.strftime('%d.%m. %H:%M', time.localtime(d['ts']))}",
                 fontsize=11)
    ax.set_xlabel("Notional (USD)")
    ax.grid(axis="x", alpha=0.2, ls=":")
    plt.tight_layout()
    plt.savefig(out, dpi=130)
    print(f"Gespeichert: {out}")


# ---------------------------------------------------------------------------
# Live-Dashboard
# ---------------------------------------------------------------------------

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0d1117">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<link rel="manifest" href="/manifest.json">
<link rel="icon" href="/icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icon.svg">
<title>HL Liquidationen</title>
<style>
 table.w{border-collapse:collapse;font-size:11px;min-width:min(100%,900px)}
 table.w th{color:#8b949e;font-weight:500;text-align:left;padding:4px 10px;
   border-bottom:1px solid #21262d;font-size:10px;text-transform:uppercase;white-space:nowrap}
 table.w td{padding:5px 10px;border-bottom:1px solid #161b22;white-space:nowrap}
 table.w th.n,table.w td.n{text-align:right;font-variant-numeric:tabular-nums}
 .mono{font-family:ui-monospace,monospace;font-size:10px;color:#8b949e}
 body{background:#0d1117;color:#c9d1d9;font:13px system-ui,sans-serif;margin:0;padding:16px}
 h1{font-size:17px;margin:0 0 3px} h2{font-size:13px;margin:0 0 2px;color:#e6edf3}
 .sub{color:#8b949e;font-size:11px;line-height:1.45}
 canvas{background:#01030a;border:1px solid #21262d;border-radius:6px;width:100%;
        display:block;cursor:crosshair}
 .row{display:flex;gap:16px;flex-wrap:wrap;margin-top:6px}
 .col{flex:1;min-width:330px}
 .panel{margin-top:20px}
 .bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:12px 0 6px}
 label.lbl{font-size:10px;color:#8b949e;text-transform:uppercase;letter-spacing:.4px}
 select,button{background:#21262d;color:#c9d1d9;border:1px solid #30363d;
   border-radius:5px;padding:5px 9px;font-size:12px}
 button.tog{cursor:pointer;min-width:64px;font-weight:600}
 button.tog.on{background:#1f3d2a;border-color:#3ba55d;color:#7ee787}
 button.tog.off{background:#21262d;color:#8b949e}
 .kpi{display:flex;gap:20px;flex-wrap:wrap;margin:12px 0;padding:10px 12px;
      background:#161b22;border:1px solid #21262d;border-radius:6px}
 .kpi div span{display:block;color:#8b949e;font-size:10px;text-transform:uppercase;
               letter-spacing:.4px}
 .kpi b{font-size:17px;font-weight:600}
 .kpi b .d{display:block;font-size:11px;font-weight:500;color:#8b949e;text-transform:none;letter-spacing:0}
 .kpi b > span:not(.d){text-transform:none;letter-spacing:0;font-size:inherit;font-weight:inherit}
 .kpi b .d span{text-transform:none;letter-spacing:0;font-size:inherit;display:inline}
 .warn{color:#d29922;font-size:11px;margin-top:14px}
 .leg{display:flex;gap:14px;align-items:center;font-size:10px;color:#8b949e;
      margin:5px 0;flex-wrap:wrap}
 /* ---- Struktur: Kopf bleibt oben, Abschnitte nummeriert und einklappbar ---- */
 .top{position:sticky;top:0;z-index:20;background:rgba(13,17,23,0.96);backdrop-filter:blur(6px);
      margin:-16px -16px 0;padding:10px 16px 6px;border-bottom:1px solid #21262d}
 .titlerow{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
 .titlerow h1{margin:0;font-size:17px}
 .nav{display:flex;gap:4px;flex-wrap:wrap;margin-top:6px}
 .nav a{color:#c9d1d9;text-decoration:none;font-size:11px;padding:4px 9px;border-radius:12px;
        background:#161b22;border:1px solid #21262d;cursor:pointer}
 .nav a:hover{border-color:#58a6ff;color:#58a6ff}
 .nav a.dim{color:#8b949e}
 .panel{scroll-margin-top:96px}
 h2.sech{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none;margin:0}
 h2.sech .num{display:inline-flex;width:22px;height:22px;border-radius:50%;background:#21262d;color:#8b949e;
      font-size:11px;align-items:center;justify-content:center;flex:none}
 h2.sech .ttl{flex:1}
 h2.sech .help{font-size:12px;color:#8b949e;border:1px solid #30363d;border-radius:50%;width:18px;height:18px;
      display:inline-flex;align-items:center;justify-content:center;flex:none}
 h2.sech .help:hover{color:#58a6ff;border-color:#58a6ff}
 h2.sech .help.exp{border-radius:5px;width:auto;padding:0 6px;font-size:13px}
 h2.sech .chev{color:#8b949e;font-size:12px;transition:transform .15s;flex:none}
 .panel.closed .body{display:none}
 .panel.closed h2.sech .chev{transform:rotate(-90deg)}
 .panel.closed h2.sech{margin:0}
 .sub.help{border-left:2px solid #30363d;padding-left:10px;margin:8px 0 10px}
 /* ---- Handy (bis 700 px): alles untereinander, große Tippflächen ---- */
 @media (max-width:700px){
  body{padding:10px 10px 24px}
  .top{margin:-10px -10px 0;padding:8px 10px 6px}
  .titlerow h1{font-size:15px}
  .nav{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;padding-bottom:2px}
  .nav a{padding:5px 9px;font-size:11px;white-space:nowrap;flex:none}
  .kpi div span{white-space:normal}
  .panel{scroll-margin-top:120px}
  h1{font-size:16px} .sub{font-size:11px}
  .bar{display:grid;grid-template-columns:1fr 1fr;gap:8px 10px;align-items:center}
  .bar label.lbl{grid-column:1/-1;margin:2px 0 -4px;font-size:9px}
  .bar select,.bar button{width:100%;min-height:40px;font-size:14px;padding:6px 8px}
  .bar button.tog{grid-column:1/-1}
  .kpi{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:10px 14px;padding:10px}
  .kpi > div{min-width:0;overflow-wrap:anywhere}
  .kpi b{font-size:clamp(13px,4vw,17px);white-space:normal}
  .kpi b > span:not(.d){white-space:normal}
  .kpi b .d{display:block;font-size:12px;font-weight:500}
  .kpi div span{font-size:9px}
  .col{min-width:0;flex-basis:100%}
  .leg{gap:8px 12px;font-size:10px}
  .panel{margin-top:16px}
  canvas{border-radius:4px}
  #signalbox{font-size:12px}
  table.w{font-size:12px} table.w tr.grp td{background:#1c2128;border-top:2px solid #30363d;padding-top:7px}
 /* breite Tabellen scrollen im eigenen Rahmen seitwärts, statt die Seite zu verkleinern */
 #whaletable,#lbtable,#stoplevels,#lbactcoins,#lbactbig,#lbactspot,#lbact48coins,#lbact48big,#fcdrivers{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
 #fclearn .kpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr));gap:10px 14px}
 #fcdrivers table.w{min-width:640px}
 #whaletable table.w,#lbtable table.w,#lbactcoins table.w,#lbactbig table.w,#lbact48coins table.w,#lbact48big table.w{min-width:700px}
 #lbactspot table.w{min-width:560px}
 .lbl-name{color:#e3b341;font-weight:600;font-family:system-ui;font-size:12px}
 .lbl-dim{color:#6e7681;font-family:system-ui;font-size:11px}
 .lbl-beh{color:#8b949e;font-family:system-ui;font-size:11px;margin-left:8px}
 .lbl-links{font-family:system-ui;font-size:11px;margin-left:8px} .lbl-links a{color:#58a6ff;text-decoration:none} .lbl-links a:hover{text-decoration:underline}
 table.w td,table.w th{padding:6px 8px}
  #tip{max-width:80vw}
 }
 .sw{display:inline-block;width:11px;height:11px;border-radius:2px;
     margin-right:4px;vertical-align:-1px}
 .grad{width:110px;height:9px;border-radius:2px;background:linear-gradient(90deg,
   #04060f,#0a288c,#0096c8,#3cdcb4,#ffd60a,#ffffeb)}
 #tip{position:fixed;z-index:99;pointer-events:none;display:none;
      background:#0d1117;border:1px solid #30363d;border-radius:8px;
      padding:9px 12px;font-size:12px;box-shadow:0 6px 20px #000a;max-width:260px}
 #tip .t{color:#8b949e;font-size:10px;margin-bottom:5px}
 #tip .r{display:flex;justify-content:space-between;gap:16px;margin:2px 0}
 #tip .r i{font-style:normal;color:#8b949e}
 #tip .r b{font-weight:600}
</style></head><body>
<div class="top">
 <div class="titlerow">
  <h1>Hyperliquid — Liquidationscluster</h1>
  <div class="bar" style="margin:0">
   <label class="lbl" for="coin">Coin</label><select id="coin"></select>
   <label class="lbl" for="src">Quelle</label>
   <select id="src" title="Datenquelle für alle Abschnitte">
    <option value="hl" selected>Hyperliquid Daten</option>
    <option value="bnc">Binance Daten</option>
    <option value="fusion">Data Mix Fusion (Hyperliquid + Binance + Crypto.com)</option></select>
   <button onclick="load()" title="alle Daten jetzt neu laden">Neu laden</button>
  </div>
 </div>
 <nav class="nav">
  <a href="#sec-chart">Chart</a><a href="#sec-signal">Konfluenz</a><a href="#sec-forecast">AI-Prognose</a><a href="#sec-orders">Orders &amp; Stops</a>
  <a href="#sec-heat">Heatmap</a><a href="#sec-depth">Momentaufnahme</a><a href="#sec-whales">Wale</a><a href="#sec-leaderboard">Leaderboard</a><a href="#sec-lbact">Käufe/Verkäufe 3 T</a><a href="#sec-lbact48">48 h</a>
  <a href="#sec-update" class="dim">Update</a><a href="#sec-debug" class="dim">Debug</a><a href="#sec-system" class="dim">System</a>
  <a class="dim" onclick="toggleAll()" style="margin-left:auto" title="alle Abschnitte ein- oder ausklappen">alle ▾/▸</a>
 </nav>
</div>
<div class="sub" style="margin:8px 0 0">Echte Positionen aus der Kette, keine Schätzung. Kurs und Cluster aktualisieren sich automatisch;
 Tippen oder Fahren über eine Grafik zeigt Werte und Fadenkreuz. Jeder Abschnitt lässt sich am Titel einklappen, „ⓘ" zeigt die Erklärung.</div>

<div class="kpi" id="kpi"></div>

<div class="panel" id="sec-chart" data-sec="chart">
 <h2 class="sech" onclick="toggleSec('chart')"><span class="num">1</span><span class="ttl">Live-Chart — Kurs mit aktuellen Liquidationsmarken</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('chart')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="tf">Raster</label>
  <select id="tf"><option value="1|120">1 min · 2 h</option>
   <option value="5|720" selected>5 min · 12 h</option>
   <option value="15|2880">15 min · 2 Tage</option>
   <option value="60|10080">1 h · 7 Tage</option>
   <option value="240|43200">4 h · 30 Tage</option>
   <option value="1440|525600">1 Tag · 1 Jahr</option>
   <option value="10080|2628000">1 Woche · 5 Jahre</option></select>
  <button id="fvgtoggle" class="tog on" title="Fair Value Gaps ein- oder ausblenden">FVG an</button>
  <label class="lbl" for="fvg" title="Fair Value Gaps, die kleiner sind als dieser Anteil des Kurses, gelten als Rauschen und werden nicht gezeichnet">FVG-Mindestgröße</label>
  <select id="fvg" title="Lücken kleiner als dieser Anteil des Kurses werden ignoriert"><option value="0.0005" selected>0,05 % des Kurses</option>
   <option value="0.001">0,1 % des Kurses</option>
   <option value="0.0025">0,25 % des Kurses</option></select>
 </div>
 <div class="sub help" style="display:none">Waagerechte Linien sind Preisniveaus, auf denen gehebelte
  Positionen zwangsliquidiert würden. Rechts steht je Linie das Notional und der
  Abstand zum Kurs.</div>
 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Short-Liquidationen (über dem Kurs)</span>
  <span><i class="sw" style="background:#e04b4b"></i>Long-Liquidationen (unter dem Kurs)</span>
  <span>durchgezogen = ab halbem Stundenvolumen · gestrichelt = darunter</span>
  <span><i class="sw" style="background:rgba(57,255,20,.35);border:1px solid #39ff14"></i>bullisches FVG</span>
  <span><i class="sw" style="background:rgba(224,75,75,.35);border:1px solid #e04b4b"></i>bärisches FVG</span>
  <span>kräftig = offen · blass = gefüllt</span>
  <span title="Ein FVG ist die Lücke zwischen dem Hoch von Kerze 1 und dem Tief von Kerze 3 (bullisch) bzw. umgekehrt. Die FVG-Mindestgröße ist diese Lücke als Anteil des Kurses: 0,05 % bei 80.000 sind 40 USD. Kleinere Lücken werden nicht gezeichnet.">FVG-Mindestgröße = Lücke als Anteil des Kurses ⓘ</span>
  <span><i class="sw" style="background:#39d3ff"></i>Support</span>
  <span><i class="sw" style="background:#c678dd"></i>Resistance</span>
  <span><i class="sw" style="background:#8b949e"></i>Take-Profits</span>
  <span><i class="sw" style="background:#e04b4b"></i>/<i class="sw" style="background:#3ba55d"></i> Stops (gepunktet)</span>
  <span><i class="sw" style="background:#ff9f43"></i>Binance-Liquidation ▲▼</span>
  <span><i class="sw" style="background:#ff3b6b"></i>HL-Liquidation ▲▼ (Binance/Fusion)</span>
 </div>
 <canvas id="chart" height="400" data-hm="340"></canvas>
 <div class="sub" id="chartinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-signal" data-sec="signal">
 <h2 class="sech" onclick="toggleSec('signal')"><span class="num">2</span><span class="ttl">Konfluenz — welche Faktoren zeigen in dieselbe Richtung?</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Eine Zählung sichtbarer Faktoren, keine Prognose. Jede Regel steht
  daneben, damit du sie prüfen und verwerfen kannst. Die zugrunde liegende These —
  Cluster ziehen, Lücken werden gefüllt — ist genau das, was der Recorder erst noch
  belegen muss. <b>Nicht validiert.</b></div>

 <div id="signalbox" style="margin-top:8px;padding:10px 12px;background:#161b22;
  border:1px solid #21262d;border-radius:6px;font-size:12px;line-height:1.6"></div>

 </div></div>

<div class="panel" id="sec-forecast" data-sec="forecast">
 <h2 class="sech" onclick="toggleSec('forecast')"><span class="num" style="background:#3b2f6e;color:#c9b8ff">AI</span><span class="ttl">AI-Prognose — kalkulierter Pfad für 7 Tage, Kauf- und Verkaufspreis für die nächsten 4–12 Stunden</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('fcchart')" title="Prognose als PNG exportieren">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Alle 15 Minuten werden sämtliche gesammelten Daten zu einer Prognose verrechnet — ein
  transparentes Modell, kein Orakel. <b>Regime und Drift:</b> Lage zu MA 200 Tage und MA 50 Wochen, 60-Minuten-Trend, RSI,
  Drift der letzten Tage. <b>Richtungsdruck:</b> nur direktionale Konten — direktionale Wale, direktionales Smart Money,
  Käufe und Verkäufe direktionaler Leaderboard-Konten der letzten 24 h, Top-20-Trend, dazu Taker-Flow aller Börsen, Funding
  (gegen die Menge) und ETF-Flows. <b>Magneten:</b> Liquidationscluster ziehen, Limit-Wände bremsen, ein gekreuzter
  Stop-Auslöser wird zur Kaskade. <b>Pfad:</b> Stunde für Stunde bis 7 Tage, das Band ist die realisierte Volatilität mal
  Wurzel der Zeit — je weiter, desto breiter, so ehrlich ist die Unsicherheit. <b>Kauf- und Verkaufspreis:</b> im Fenster
  4–12 h, an Wänden und Clustern ausgerichtet; bei klarem Gegendruck wird abgeraten. Jede Prognose wird gespeichert und
  nach 4 und 24 Stunden gegen den echten Kurs geprüft — die Trefferquote steht unten und ist der ehrlichste Wert auf der Seite.</div>
 <div id="fcguide" class="kpi" style="margin:6px 0"></div>
 <div id="fclive" class="sub" style="margin:0 0 6px"></div>
 <div class="leg"><span><i class="sw" style="background:#fff"></i>Kurs 48 h</span><span><i class="sw" style="background:#c9b8ff"></i>Prognosepfad (Ensemble, gestrichelt; dünn = reines Modell)</span><span><i class="sw" style="background:rgba(201,184,255,0.18)"></i>Unsicherheitsband</span><span><i class="sw" style="background:#3ba55d"></i>Kaufpreis</span><span><i class="sw" style="background:#e04b4b"></i>Verkaufspreis</span><span>Magneten: Liq-Cluster · Wände</span></div>
 <div class="bar" style="margin:4px 0 6px">
  <label class="lbl">Ansicht</label>
  <button class="tog off fcz" data-span="24">24 h</button><button class="tog off fcz" data-span="72">3 T</button><button class="tog off fcz" data-span="216">alles</button>
  <button class="tog off" id="fcprev" title="nach links">◀</button><button class="tog off" id="fcnext" title="nach rechts">▶</button><button class="tog off" id="fcnow" title="zum Jetzt">jetzt</button>
  <span class="sub" style="margin:0" id="fcview"></span>
 </div>
 <canvas id="fcchart" height="300" data-hm="260" style="cursor:grab;touch-action:pan-y"></canvas>
 <div id="fcdrivers" style="margin-top:8px"></div>
 <div id="fclearn" style="margin-top:8px"></div>
 <div class="sub" id="fcinfo"></div>
 </div>
</div>

<div class="panel" id="sec-orders" data-sec="orders">
 <h2 class="sech" onclick="toggleSec('orders')"><span class="num">3</span><span class="ttl">Wartende Orders und Stops — Konten ab 250k USD</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('stops')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Trigger-Orders stehen nicht im Orderbuch: Sie werden erst am Auslösepreis zu
  Market-Orders — wie Liquidationen. Sell-Stops unter dem Kurs lösen Verkaufskaskaden aus,
  Buy-Stops darüber Kaufkaskaden. Take-Profits und ruhende Limit-Orders wirken gegenteilig,
  sie absorbieren. Abgefragt werden alle Konten ab 250k USD, gestaffelt nach Größe: ab 20 Mio
  alle 10 Minuten, 5–20 Mio alle 45 Minuten, 1–5 Mio alle 3 Stunden, darunter alle 6 Stunden —
  so passt es ins API-Budget. Gezeigt wird je Konto der jüngste Stand. Fahren oder Tippen zeigt
  ein Fadenkreuz mit dem Preis.</div>

 <div class="leg">
  <span><i class="sw" style="background:#e04b4b"></i>Sell-Stop (Verkaufskaskade)</span>
  <span><i class="sw" style="background:#3ba55d"></i>Buy-Stop (Kaufkaskade)</span>
  <span><i class="sw" style="background:#39d3ff"></i>Limit-Kauf (Kaufwand)</span>
  <span><i class="sw" style="background:#c678dd"></i>Limit-Verkauf (Verkaufswand)</span>
  <span><i class="sw" style="background:#8b949e"></i>Take-Profit</span>
 </div>
 <canvas id="stops" height="720" data-hm="560"></canvas>
 <div class="sub" id="stopsinfo"></div>
 <div id="stopslevels" style="margin-top:8px;overflow-x:auto"></div>

 </div></div>

<div class="panel" id="sec-heat" data-sec="heat">
 <h2 class="sech" onclick="toggleSec('heat')"><span class="num">4</span><span class="ttl">Heatmap — Clusterentwicklung über die Zeit</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('heat')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="hours">Zeitraum</label>
  <select id="hours"><option value="6">6 h</option><option value="24" selected>24 h</option>
   <option value="72">3 Tage</option><option value="168">7 Tage</option></select>
 </div>
 <div class="sub help" style="display:none">Waagerecht die Zeit, senkrecht der Preis. Die Farbe zeigt den
  Rang einer Zelle unter allen anderen, nicht den Absolutwert — sonst würde ein
  einzelner Großcluster die Skala verzerren.</div>
 <div class="bar">
  <label class="lbl" for="thr">Liquiditäts-Schwelle</label>
  <input type="range" id="thr" min="0" max="97" value="70" style="width:190px">
  <span class="sub" id="thrval" style="min-width:92px">Perzentil 70</span>
 </div>
 <div class="leg">
  <span>schwach<i class="grad" style="margin:0 6px;display:inline-block"></i>stark</span>
  <span><i class="sw" style="background:#fff"></i>Kursverlauf</span>
  <span><i class="sw" style="background:#ff3b6b"></i>eingetretene Liquidation</span>
 </div>
 <canvas id="heat" height="430" data-hm="360"></canvas>
 <div class="sub" id="heatinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-depth" data-sec="depth">
 <h2 class="sech" onclick="toggleSec('depth')"><span class="num">5</span><span class="ttl">Momentaufnahme — Cluster rund um den aktuellen Kurs</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('depth')" title="Chart als PNG exportieren (3-fache Auflösung)">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Senkrecht der Preis, Balkenlänge das Notional. Die gestrichelte
  Linie markiert das halbe Stundenvolumen: Cluster links davon werden vom Markt
  eher geschluckt, ohne den Kurs zu bewegen.</div>

 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Short-Liquidationen</span>
  <span><i class="sw" style="background:#e04b4b"></i>Long-Liquidationen</span>
  <span><i class="sw" style="background:#00e5ff"></i>aktueller Kurs</span>
 </div>
 <canvas id="depth" height="430" data-hm="360"></canvas>
 <div class="sub" id="depthinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-whales" data-sec="whales">
 <h2 class="sech" onclick="toggleSec('whales')"><span class="num">6</span><span class="ttl">Wale — Konten ab 10 Mio. USD Gesamtwert</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('whalechart')" title="Exposure-Chart als PNG exportieren">⤓ Chart</a><a class="help exp" onclick="event.stopPropagation();exportWhaleTable()" title="Wal-Liste mit allen Positionen als PNG exportieren (bei sehr langen Listen mehrere Teile)">⤓ Liste</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Oben die Netto-Ausrichtung aller Wale (grün = mehr Long, rot = mehr
  Short) gegen den Kurs. Darunter jede aktuell offene Wal-Position mit Einstieg,
  Liquidationspreis und Abstand dorthin — über alle Coins, der gewählte ist hervorgehoben.
  Ganz unten die letzten Änderungen im gewählten Coin. Der Blockkopf je Wallet nennt, wenn
  bekannt, wer dahintersteht: aus <code>labels.json</code> (eigene Pflege, Vorrang), dem
  Hyperliquid-Leaderboard (selbst gewählte Namen), Vault-Namen, Etherscan- und Arbiscan-Tags;
  dazu die Verhaltensklasse aus unseren Daten (Hedge, Market-Maker-Muster, direktional) und Links
  zu HypurrScan, Arbiscan und Arkham. „unbekannt" heißt: keine Quelle kennt einen Namen — das ist bei
  den meisten Walen so. Hedge heißt: mehrere Coins, eine Seite, niedriger Hebel — typisch für
  Market Maker und Basis-Trader, die Spot oder Optionen absichern, nicht für Wetten.
  <b>Vorsicht bei der Deutung:</b> Ein großer Short kann eine abgesicherte
  Spot-Position sein und sagt dann nichts über die Erwartung des Halters.</div>

 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Long-Exposure</span>
  <span><i class="sw" style="background:#e04b4b"></i>Short-Exposure</span>
  <span><i class="sw" style="background:#fff"></i>Kurs</span>
  <span>▲ öffnet / stockt auf &nbsp; ▼ reduziert / schließt</span>
 </div>
 <canvas id="whalechart" height="260" data-hm="220"></canvas>
 <div id="whaletable" style="margin-top:10px;overflow-x:auto"></div>
 <div id="whaleevents" class="sub" style="margin-top:8px"></div>
 <div id="bncmetrics" style="display:none;margin-top:10px">
  <div class="leg"><span><i class="sw" style="background:#58a6ff"></i>Open Interest (USD)</span>
   <span><i class="sw" style="background:#d29922"></i>Long/Short-Verhältnis Konten (global)</span>
   <span><i class="sw" style="background:#c678dd"></i>Long/Short Top-Trader (Position)</span>
   <span><i class="sw" style="background:#3ba55d"></i>Taker Kauf/Verkauf</span></div>
  <canvas id="metricschart" height="260" data-hm="220"></canvas>
  <div class="sub" id="metricsinfo"></div>
 </div>
</div>

<div class="warn" id="warn">
 </div></div>
<div class="panel" id="sec-leaderboard" data-sec="leaderboard">
 <h2 class="sech" onclick="toggleSec('leaderboard')"><span class="num">7</span><span class="ttl">Leaderboard Top 20 — die profitabelsten Konten und ihre Positionen</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('lbchart')" title="Trend-Chart als PNG exportieren">⤓ Chart</a><a class="help exp" onclick="event.stopPropagation();exportLbTable()" title="Leaderboard-Liste als PNG exportieren">⤓ Liste</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Die 20 Konten mit dem höchsten 30-Tage-PnL im Hyperliquid-Leaderboard (Kontowert ab 500k),
  ihre offenen Positionen und der unrealisierte PnL — vom Recorder alle 10 Minuten abgefragt. Das Chart zeigt,
  wie sich die Positionierung dieser Konten im gewählten Coin über die Zeit verschiebt: Long-Wert (grün) und
  Short-Wert (rot) je Stunde, dazu der Netto-Wert als Linie — einmal pro Stunde in <code>lb_trend</code>
  gespeichert, für Top 20 und Top 50, je Coin. Profitabel in den letzten 30 Tagen heißt nicht profitabel morgen;
  die Aussage liegt in der Verschiebung, nicht im Stand.</div>
 <div class="leg"><span><i class="sw" style="background:#3ba55d"></i>Long-Wert Top 20</span><span><i class="sw" style="background:#e04b4b"></i>Short-Wert Top 20</span><span><i class="sw" style="background:#58a6ff"></i>netto (Linie)</span><span><i class="sw" style="background:#fff"></i>Kurs</span></div>
 <canvas id="lbchart" height="240" data-hm="200"></canvas>
 <div class="sub" id="lbinfo"></div>
 <div id="lbtable" style="margin-top:8px"></div>
 </div>
</div>

<div class="panel" id="sec-lbact" data-sec="lbact">
 <h2 class="sech" onclick="toggleSec('lbact')"><span class="num">8</span><span class="ttl">Leaderboard — Käufe und Verkäufe der letzten 3 Tage (Perp und Spot)</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Alle Fills der Top-50-Konten der letzten 3 Tage, stündlich vom Recorder geholt (<code>userFillsByTime</code>), Perp und Spot.
  Kaufdruck = Open Long, Close Short und Spot-Käufe; Verkaufsdruck = Open Short, Close Long und Spot-Verkäufe. Die
  Übersicht je Coin zählt Konten und Notional beider Seiten, die Tabelle darunter die größten Einzeltrades im gewählten Coin
  mit der Kursentwicklung seit dem Trade — aus Sicht des Traders: positiv heißt, der Trade liegt im Gewinn. Spot-Bestände
  der Top-Konten stehen ganz unten (UBTC = BTC, UETH = ETH, USOL = SOL). Ein Verkauf kann Gewinnmitnahme, Absicherung oder
  Ausstieg sein — die Liste zeigt das Verhalten, nicht die Absicht.</div>
 <div id="lbactcoins"></div>
 <div id="lbactinfo" class="sub" style="margin-top:6px"></div>
 <div id="lbactbig" style="margin-top:8px"></div>
 <div id="lbactspot" style="margin-top:8px"></div>
 </div>
</div>

<div class="panel" id="sec-lbact48" data-sec="lbact48">
 <h2 class="sech" onclick="toggleSec('lbact48')"><span class="num">9</span><span class="ttl">Leaderboard — Käufe und Verkäufe der letzten 48 Stunden</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('lbact48chart')" title="Chart als PNG exportieren">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Dieselben Fills wie in Abschnitt 8, aber nur die letzten 48 Stunden — für ganz aktuelle Kauf- und
  Verkaufssignale. Das Chart zeigt je Stunde den Kaufdruck (grün, nach oben) und Verkaufsdruck (rot, nach unten) der
  Top-50-Konten im gewählten Coin, die blaue Linie den aufgelaufenen Netto-Wert, weiß den Kurs. Darunter die Übersicht je
  Coin und alle Trades ab 50k im gewählten Coin, neueste zuerst, mit der Kursentwicklung seit dem Trade aus Sicht des Traders.
  Der Recorder holt neue Fills stündlich — der jüngste Fill kann bis zu einer Stunde alt sein.</div>
 <div class="leg"><span><i class="sw" style="background:#3ba55d"></i>Kaufdruck je Stunde</span><span><i class="sw" style="background:#e04b4b"></i>Verkaufsdruck je Stunde</span><span><i class="sw" style="background:#58a6ff"></i>netto aufgelaufen</span><span><i class="sw" style="background:#fff"></i>Kurs</span></div>
 <canvas id="lbact48chart" height="220" data-hm="190"></canvas>
 <div id="lbact48info" class="sub"></div>
 <div id="lbact48coins" style="margin-top:8px"></div>
 <div id="lbact48big" style="margin-top:8px"></div>
 </div>
</div>

<div class="panel" id="sec-update" data-sec="update">
 <h2 class="sech" onclick="toggleSec('update')"><span class="ttl">Aktualisierung</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Lädt das Archiv von GitHub und spielt es mit <code>update.py</code> ein: Dienste stoppen,
  Dateien ersetzen, Syntaxprüfung mit Rückrollen, Units erneuern, Dienste starten. Das Dashboard
  ist dabei etwa eine Minute nicht erreichbar; die Seite wartet und lädt danach selbst neu.
  Braucht <code>sudo.txt</code> (Rechte 600) im Projektordner.</div>

 <button id="updbtn" class="tog off" style="margin-top:8px;min-width:220px">Update von GitHub einspielen</button>
 <pre id="updlog" style="display:none;margin-top:8px;background:#0d1117;border:1px solid #21262d;border-radius:6px;
   padding:10px;font-size:11px;max-height:320px;overflow:auto;white-space:pre-wrap"></pre>
</div>

<div class="panel" id="sec-debug" data-sec="debug">
 <h2 class="sech" onclick="toggleSec('debug')"><span class="ttl">Debug — Diagnoselauf mit Terminal-Ausgabe</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Startet eines der Diagnoseskripte oder liest ein Journal — als Dashboard-Benutzer, ohne sudo,
  aus einer festen Liste (kein freies Kommando). Die Ausgabe erscheint hier wie im Terminal; „Kopieren" legt sie mit
  Kopfzeile in die Zwischenablage, zum Einfügen in den Chat. Läufe mit Live-Abfragen (Leaderboard-Diagnose) brauchen
  bis zu einer Minute. Journale setzen voraus, dass der Benutzer sie lesen darf (Gruppe systemd-journal).</div>
 <div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="dbgselect">Lauf</label><select id="dbgselect"></select>
  <button id="dbgrun" class="tog off">Ausführen</button>
  <button id="dbgcopy" class="tog off" disabled title="Konsolenausgabe mit Kopfzeile in die Zwischenablage">Konsole kopieren</button>
  <button id="dbgsel" class="tog off" disabled title="alles markieren — danach „Kopieren" im Handy-Menü">Alles markieren</button>
  <button id="dbgsave" class="tog off" disabled title="als Textdatei speichern — lässt sich aus dem Download-Ordner teilen">Als Datei</button>
  <span id="dbgstate" class="sub" style="margin:0"></span>
 </div>
 <textarea id="dbgout" readonly spellcheck="false" style="display:block;width:100%;box-sizing:border-box;margin:0;background:#0d1117;border:1px solid #21262d;border-radius:6px;padding:10px;font:11px monospace;
   height:320px;resize:vertical;white-space:pre-wrap;color:#c9d1d9"></textarea>
 </div>
</div>

<div class="panel" id="sec-system" data-sec="system">
 <h2 class="sech" onclick="toggleSec('system')"><span class="ttl">System — Temperatur und Zustand des Pi</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><a class="help exp" onclick="event.stopPropagation();exportChart('syschart')" title="Verlauf als PNG exportieren">⤓</a><span class="chev">▾</span></h2>
 <div class="body">
 <div class="sub help" style="display:none">Der Dashboard-Server misst alle 60 Sekunden CPU-Temperatur, Takt, Drosselungsflags der Firmware,
  Last, Speicher und Datenträger und hält 24 Stunden Verlauf. Die Seite fragt jede Minute nach. Der Pi 5 beginnt bei
  80 °C zu drosseln, bei 85 °C stärker — Dauerwerte über 70 °C unter Last sind ein Hinweis auf schlechte Kühlung.
  „Unterspannung" heißt: das Netzteil liefert zu wenig, das ist die häufigste Ursache für Instabilität.</div>
 <div class="kpi" id="syskpi" style="margin:6px 0"></div>
 <div class="leg"><span><i class="sw" style="background:#e3b341"></i>CPU-Temperatur (°C)</span><span><i class="sw" style="background:#58a6ff"></i>CPU-Last gesamt (%, rechte Skala 0–100)</span><span>Linien: 70 °C · 80 °C (Drosselung)</span></div>
 <canvas id="syschart" height="160" data-hm="140"></canvas>
 <div class="sub" id="sysinfo"></div>
 </div>
</div>

<div id="taskbar" style="display:none;margin:6px 0;padding:8px 10px;background:#3d1d1d;border:1px solid #e04b4b;border-radius:6px;font-size:12px;color:#ffb4b4"></div>
<div id="tip"></div>

<div id="boot" style="background:#7a1f1f;color:#fff;padding:8px 14px;font:13px monospace;white-space:pre-wrap">Dashboard-Skript wird geladen … (bleibt diese Zeile stehen, ist das Skript nicht gestartet)
 </div></div>
<script>
// Eigenständiger Wächter: fängt auch Parse-Fehler des Hauptskripts, die dort selbst nichts mehr melden könnten
window.onerror=function(msg,src,line,col,err){
 var b=document.getElementById('boot'); if(!b) return;
 b.style.display='block';
 b.textContent='Skriptfehler: '+msg+' (Zeile '+line+', Spalte '+col+')'+(err&&err.stack?'\\n'+String(err.stack).split('\\n').slice(0,3).join('\\n'):'');
};
window.addEventListener('unhandledrejection',function(e){
 var b=document.getElementById('boot'); if(!b) return;
 b.style.display='block'; b.textContent='Ladefehler: '+(e.reason&&e.reason.message||e.reason);
});
</script>
<script>
document.getElementById('boot').style.display='none';   // Hauptskript läuft
const $=id=>document.getElementById(id);
// Fehler sichtbar machen: statt still in der Konsole zu landen, erscheinen sie oben auf der Seite
// Fehlerleiste: Verbindungsfehler verschwinden von selbst, sobald wieder Daten ankommen;
// Skriptfehler bleiben stehen (die gehen nicht von allein weg).
const ERR_LINES=[];                       // {kind:'fetch'|'script', text}
function renderErr(){
 let b=document.getElementById('errbar');
 if(!ERR_LINES.length){ if(b) b.remove(); return; }
 if(!b){b=document.createElement('div');b.id='errbar';
  b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:99;background:#7a1f1f;color:#fff;'
   +'padding:8px 14px;font:13px monospace;white-space:pre-wrap;border-bottom:2px solid #e04b4b';
  document.body.prepend(b);}
 b.textContent=ERR_LINES.slice(-6).map(l=>l.text).join('\\n');
}
function showErr(t, kind){
 kind=kind||(/keine Verbindung|Ladefehler|Failed to fetch|HTTP \\d/.test(t)?'fetch':'script');
 ERR_LINES.push({kind, text:new Date().toLocaleTimeString('de-DE')+'  '+t});
 while(ERR_LINES.length>6) ERR_LINES.shift();
 renderErr();
}
function clearFetchErr(){
 const had=ERR_LINES.some(l=>l.kind==='fetch'); if(!had) return;
 for(let i=ERR_LINES.length-1;i>=0;i--) if(ERR_LINES[i].kind==='fetch') ERR_LINES.splice(i,1);
 renderErr();
}
addEventListener('error',e=>showErr('Skriptfehler: '+e.message+' (Zeile '+e.lineno+')','script'));
addEventListener('unhandledrejection',e=>showErr('Ladefehler: '+(e.reason&&e.reason.message||e.reason),'fetch'));
async function getJSON(url){
 let r;
 try{ r=await fetch(url); }catch(e){ showErr(url.split('?')[0]+': keine Verbindung ('+e.message+')','fetch'); throw e; }
 if(!r.ok){ const t=await r.text(); showErr(url.split('?')[0]+': HTTP '+r.status+' '+t.slice(0,160),'fetch'); throw new Error('HTTP '+r.status); }
 try{ const j=await r.json(); clearFetchErr(); return j; }
 catch(e){ showErr(url.split('?')[0]+': keine gültige Antwort ('+e.message+')','fetch'); throw e; }
}
// Tab wieder sichtbar (Handy: Browser aus dem Hintergrund geholt): sofort neu laden statt
// auf den nächsten Takt zu warten -- und die Verbindungsfehler aus der Hintergrundzeit räumen sich
// mit der ersten erfolgreichen Antwort selbst weg.
document.addEventListener('visibilitychange',()=>{ if(!document.hidden){ setTimeout(()=>{ load(); loadHealth(); },200); } });
addEventListener('online',()=>{ setTimeout(load,500); });
let LAST=null, LAST_DEPTH=null, LAST_DATA=null, LAST_CHART=null, LAST_HEALTH=null, GEO={}, FVG_ON=true;
function SRC(){ const e=document.getElementById('src'); return e?e.value:'hl'; }
// Verhältnis x:1 als Kachel: Wert, darunter die Aufteilung in Prozent, Definition als Tooltip
function ratioTile(label, v, aWord, bWord, defn){
 // Verhältnis a:b -> "1,27 : 1" und darunter "56 % <aWord> · 44 % <bWord>"
 if(v==null||!isFinite(v)) return `<div title="${defn}"><span>${label}</span><b>—</b></div>`;
 const share=v/(1+v)*100, col=v>1.15?'#3ba55d':v<0.87?'#e04b4b':'#c9d1d9';
 return `<div title="${defn}"><span>${label}</span><b style="color:${col}">${(+v).toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2})} : 1`
  +`<span class="d">${share.toFixed(0)} % ${aWord} · ${(100-share).toFixed(0)} % ${bWord}</span></b></div>`;
}
const SRC_NAME={hl:'Hyperliquid',bnc:'Binance',fusion:'Data Mix Fusion'};
function setFvg(on){
 FVG_ON=on; const b=$('fvgtoggle'); if(!b) return;
 b.textContent=on?'FVG an':'FVG aus'; b.className='tog '+(on?'on':'off');
 if(LAST_CHART) drawChart(LAST_CHART);
}
function fillHealth(h){
 const b=$('kpi_backup'), d=$('kpi_db'); if(!b||!d) return;
 const bk=h.backup;
 if(!bk){ b.textContent='noch keines'; b.style.color='#d29922'; b.title='läuft 5 min nach Recorder-Start'; }
 else if(bk.ok){
  const age=(Date.now()/1000-bk.ts)/3600;
  b.textContent=hm(bk.ts); b.style.color=age<26?'#3ba55d':age<50?'#d29922':'#e04b4b';
  b.title=`vor ${age.toFixed(1)} h · ${(bk.size/1e6).toFixed(0)} MB · ${(bk.bars||0).toLocaleString('de-DE')} Bars · Ordner ${h.backup_dir||'?'}`;
  if(h.backup_free!=null&&h.db_size&&h.backup_free<h.db_size*1.1){
   b.textContent=hm(bk.ts)+' ⚠'; b.style.color='#e04b4b';
   b.title+=`\nPLATZ REICHT NICHT für das nächste Backup: ${(h.backup_free/1e9).toFixed(1)} GB frei, ${(h.db_size*1.1/1e9).toFixed(1)} GB nötig — das nächste wird übersprungen, das vorhandene bleibt.`; }
 } else {
  b.textContent='fehlgeschlagen'; b.style.color='#e04b4b';
  b.title=(bk.error||'')+(bk.last_good?` · gutes Backup von ${hm(bk.last_good)} liegt vor`:'');
 }
 if(h.db_ok===true){ d.textContent='OK'; d.style.color='#3ba55d';
  d.title=`quick_check bestanden · ${(h.db_size/1e6).toFixed(0)} MB · geprüft ${hm(h.checked_at)}`; }
 else if(h.db_ok===false){ d.textContent='BESCHÄDIGT'; d.style.color='#e04b4b';
  d.title=h.db_detail||'quick_check fehlgeschlagen'; }
 else if(h.checking){ d.textContent='prüft …'; d.style.color='#d29922'; d.title='quick_check läuft im Hintergrund'; }
 else { d.textContent='—'; d.style.color=''; }
}
// ---- Stop-Orders der Wale ----------------------------------------------------
// ---- Schlüsselniveaus aus den Orders: eine Rechnung für Panel, Chart und Konfluenz ----
function keyLevels(d){
 const S=(d&&d.stops&&d.stops.clusters)||[], p0=d&&(d.price||(d.candles&&d.candles.length?d.candles[d.candles.length-1].c:0));
 if(!S.length||!p0) return null;
 const inR=s=>Math.abs(s.dist)<=0.30;
 const best=(kind,sign)=>S.filter(s=>s.kind===kind&&inR(s)&&Math.sign(s.dist)===sign).sort((a,b)=>b.notional-a.notional)[0]||null;
 const nearest=(kind,sign)=>S.filter(s=>s.kind===kind&&inR(s)&&Math.sign(s.dist)===sign).sort((a,b)=>Math.abs(a.dist)-Math.abs(b.dist))[0]||null;
 const sum=(kind,sign,within)=>S.filter(s=>s.kind===kind&&Math.sign(s.dist)===sign&&Math.abs(s.dist)<=within).reduce((a,s)=>a+s.notional,0);
 return {
  support:    best('limit_buy',-1),          // größte Kaufwand unter dem Kurs
  resistance: best('limit_sell',1),          // größte Verkaufswand darüber
  tp_long:    best('tp_sell',1),             // Take-Profits der Longs (Verkauf oben)
  tp_short:   best('tp_buy',-1),             // Take-Profits der Shorts (Kauf unten)
  stop_sell:  best('stop_sell',-1), stop_sell_near: nearest('stop_sell',-1), stop_sell_2pct: sum('stop_sell',-1,0.02),
  stop_buy:   best('stop_buy',1),   stop_buy_near:  nearest('stop_buy',1),   stop_buy_2pct:  sum('stop_buy',1,0.02),
 };
}
const KEY_STYLE={support:['SUPPORT','#39d3ff'],resistance:['RESISTANCE','#c678dd'],tp_long:['TAKE-PROFIT LONGS','#8b949e'],
  tp_short:['TAKE-PROFIT SHORTS','#8b949e'],stop_sell:['SELL-STOPS','#e04b4b'],stop_buy:['BUY-STOPS','#3ba55d']};

function drawStops(d){
 const c=$('stops'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H);
 const S=(d.stops&&d.stops.clusters)||[], p0=d.price||(d.candles&&d.candles.length?d.candles[d.candles.length-1].c:0);
 const narrow=W<600, L=narrow?58:76, R=narrow?8:12, T=14, B=26, pw=W-L-R, ph=H-T-B;
 const info=$('stopsinfo'), lv=$('stopslevels');
 if(!S.length||!p0){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.textAlign='center';
  g.fillText(d.stops&&d.stops.n_whales?'Keine offenen Orders der Großkonten in diesem Coin':'Noch keine Order-Abfragen — der Recorder fragt Wale alle 2 Minuten', W/2, H/2);
  g.textAlign='left'; if(info) info.textContent=(d.stops&&d.stops.book&&SRC()==='bnc')?'Binance-Orderbuch derzeit nicht abrufbar — Netzverbindung des Pi prüfen; die Seite versucht es alle 5 s erneut':''; if(lv) lv.innerHTML=''; GEO.stops=null; return; }
 // Preisbereich fest ±30 %, Kaufseite links, Verkaufsseite rechts der Mittelachse
 let lo=p0*0.70, hi=p0*1.30; const pad=(hi-lo)*0.03; lo-=pad; hi+=pad;
 const Y=p=>T+(hi-p)/(hi-lo)*ph, mid=L+pw/2, half=pw/2-8;
 const inR=s=>s.px>=lo&&s.px<=hi;
 const BUY=['limit_buy','stop_buy','tp_buy'], SELL=['limit_sell','stop_sell','tp_sell'];
 const col={stop_sell:'#e04b4b',stop_buy:'#3ba55d',tp_sell:'#8b949e',tp_buy:'#8b949e',limit_sell:'#c678dd',limit_buy:'#39d3ff'};
 // je Preisstufe und Seite ein gestapelter Balken: Segmente nach Art
 const rows=new Map();
 S.filter(inR).forEach(s=>{ const side=BUY.includes(s.kind)?'buy':'sell'; const k=s.px.toFixed(4)+side;
  const r=rows.get(k)||{px:s.px,side,total:0,segs:[],addrs:0,n:0,dist:s.dist}; r.total+=s.notional; r.segs.push(s); r.addrs=Math.max(r.addrs,s.addrs); r.n+=s.n; rows.set(k,r); });
 const mx=Math.max(...[...rows.values()].map(r=>r.total),1);
 // Gitter und Preisachse
 g.strokeStyle='#161b22'; g.lineWidth=1;
 for(let k=0;k<=6;k++){const y=T+ph*k/6; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right';
 for(let k=0;k<=6;k++){const p=lo+(hi-lo)*(1-k/6); g.fillText(px(p).slice(0,9), L-6, T+ph*k/6+3);}
 g.textAlign='left';
 // Mittelachse und Seitentitel
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(mid,T); g.lineTo(mid,H-B); g.stroke();
 g.fillStyle='#8b949e'; g.font='bold 10px system-ui'; g.textAlign='right'; g.fillText('◀ KAUFSEITE', mid-6, T+10);
 g.textAlign='left'; g.fillText('VERKAUFSSEITE ▶', mid+6, T+10);
 const bars=[]; const h=Math.max(3,Math.min(8,ph/60));
 const order=[...rows.values()].sort((a,b)=>b.px-a.px);
 order.forEach(r=>{ const y=Y(r.px), w=Math.max(3,half*r.total/mx);
  let x=r.side==='buy'?mid-2:mid+2, dir=r.side==='buy'?-1:1;
  const kinds=r.side==='buy'?BUY:SELL;
  kinds.forEach(kd=>{ r.segs.filter(s=>s.kind===kd).forEach(s=>{ const sw=Math.max(1,w*s.notional/r.total);
   g.fillStyle=col[kd]; g.globalAlpha=kd.startsWith('tp')?0.6:kd.startsWith('limit')?0.8:1;
   g.fillRect(dir<0?x-sw:x, y-h/2, sw, h); g.globalAlpha=1; x+=dir*sw; }); });
  bars.push({y,h,r,x0:Math.min(mid,x),x1:Math.max(mid,x)}); });
 // Beschriftung der größten Balken, kollisionsfrei je Seite
 g.font='10px system-ui'; ['buy','sell'].forEach(side=>{ let last=-99;
  bars.filter(b=>b.r.side===side&&b.r.total>=mx*0.12).sort((a,b)=>a.y-b.y).forEach(b=>{ if(Math.abs(b.y-last)<11) return; last=b.y;
   const t=fmt(b.r.total)+(b.r.addrs>1?` · ${b.r.addrs} K.`:''); g.fillStyle='#c9d1d9';
   if(side==='buy'){ g.textAlign='right'; g.fillText(t, b.x0-5, b.y+4); } else { g.textAlign='left'; g.fillText(t, b.x1+5, b.y+4); } }); });
 g.textAlign='left';
 // Schlüsselniveaus markieren
 const K=keyLevels(d)||{};
 Object.entries(KEY_STYLE).forEach(([k,[label,color]])=>{ const s=K[k]; if(!s||s.px<lo||s.px>hi) return; const y=Y(s.px);
  g.strokeStyle=color; g.lineWidth=1; g.setLineDash([2,3]); g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
  g.fillStyle=color; g.font='bold 9px system-ui'; const onBuy=['support','tp_short','stop_sell'].includes(k);
  g.textAlign=onBuy?'left':'right'; g.fillText(label, onBuy?L+3:W-R-3, y-4); });
 g.textAlign='left';
 // Kurs
 const y0=Y(p0); g.strokeStyle='#58a6ff'; g.setLineDash([5,4]); g.lineWidth=1.5;
 g.beginPath(); g.moveTo(L,y0); g.lineTo(W-R,y0); g.stroke(); g.setLineDash([]);
 g.fillStyle='#58a6ff'; g.fillRect(W-R-60,y0-8,60,16); g.fillStyle='#0d1117'; g.font='bold 10px system-ui';
 g.textAlign='right'; g.fillText(px(p0).slice(0,9), W-R-4, y0+4); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText('Balkenlänge = Notional · gestapelt nach Art', L, H-8);
 GEO.stops={bars,L,T,B,pw,ph,W,H,R,lo,hi,mid};
 if(info&&d.stops.book&&SRC()==='bnc') info.innerHTML=`Binance-Orderbuch (bis 1.000 Stufen je Seite, ±30 %): ${d.stops.clusters.length} Preisstufen · Bereich ±30 % · Stand ${hm(d.stops.ts)}`;
 else if(info&&SRC()==='fusion') info.innerHTML=`Data Mix Fusion: ${d.stops.n_whales} HL-Konten abgefragt (${d.stops.n_with_orders||0} mit Orders) + Binance-Orderbuch ${d.stops.book_n||0} Stufen + Crypto.com-Orderbuch ${d.stops.cdc_book_n||0} Stufen — je Preisstufe summiert · Bereich ±30 %`;
 else if(info) info.innerHTML=`${d.stops.n_whales} Konten abgefragt, davon <b>${d.stops.n_with_orders||0}</b> mit Orders in ${$('coin').value} innerhalb ±30 % `
  +`(${d.stops.n_fresh||0} in den letzten 20 min abgefragt`
  +(d.stops.oldest?`, ältester Stand vor ${Math.round((Date.now()/1000-d.stops.oldest)/60)} min`:'')+`)`
  +(d.stops.ts?` · jüngste Abfrage ${hm(d.stops.ts)}`:'')
  +` · Spalte „Konten" in der Tabelle = Konten am jeweiligen Preisniveau`;
 // Live-Auswertung
 if(lv){ const row=(label,s,extra)=>`<tr><td>${label}</td><td class="n" style="color:${extra}">${s?px(s.px):'—'}</td>`
    +`<td class="n">${s?(s.dist*100).toFixed(2)+' %':'—'}</td><td class="n">${s?fmt(s.notional):'—'}</td><td class="n">${s?s.addrs:'—'}</td></tr>`;
  lv.innerHTML=`<table class="w"><tr><th>Niveau</th><th class="n">Preis</th><th class="n">Abstand</th><th class="n">Notional</th><th class="n">Konten</th></tr>`
   +row('Support — größte Kaufwand unter dem Kurs', K.support, '#39d3ff')
   +row('Resistance — größte Verkaufswand über dem Kurs', K.resistance, '#c678dd')
   +row('Höchste Take-Profits der Longs (Verkauf oben)', K.tp_long, '#8b949e')
   +row('Höchste Take-Profits der Shorts (Kauf unten)', K.tp_short, '#8b949e')
   +row('Größtes Sell-Stop-Cluster unter dem Kurs (Verkaufskaskade)', K.stop_sell, '#e04b4b')
   +row('Nächster Sell-Stop unter dem Kurs', K.stop_sell_near, '#e04b4b')
   +row('Größtes Buy-Stop-Cluster über dem Kurs (Kaufkaskade)', K.stop_buy, '#3ba55d')
   +row('Nächster Buy-Stop über dem Kurs', K.stop_buy_near, '#3ba55d')
   +`<tr><td>Sell-Stops innerhalb 2 % unter dem Kurs</td><td class="n" colspan="3" style="color:#e04b4b">${fmt(K.stop_sell_2pct||0)} USD</td><td></td></tr>`
   +`<tr><td>Buy-Stops innerhalb 2 % über dem Kurs</td><td class="n" colspan="3" style="color:#3ba55d">${fmt(K.stop_buy_2pct||0)} USD</td><td></td></tr>`
   +`</table>`; }
}
function crosshair(c, G, x, y, price){
 // waagerechte Preislinie mit Etikett am Rand, dazu eine senkrechte Linie an der Zeigerposition
 const g=c.getContext('2d'), d=devicePixelRatio||1; g.save(); g.setTransform(d,0,0,d,0,0);
 g.strokeStyle='rgba(201,209,217,0.55)'; g.lineWidth=1; g.setLineDash([4,3]);
 g.beginPath(); g.moveTo(G.L,y); g.lineTo(G.W-G.R,y); g.stroke();
 g.beginPath(); g.moveTo(x,G.T); g.lineTo(x,G.H-G.B); g.stroke(); g.setLineDash([]);
 const t=px(price).slice(0,10); g.font='bold 10px system-ui'; const w=g.measureText(t).width+10;
 g.fillStyle='#c9d1d9'; g.fillRect(G.L-w-2,y-8,w,16); g.fillStyle='#0d1117'; g.textAlign='right'; g.fillText(t,G.L-7,y+4);
 g.textAlign='left'; g.restore();
}
function tipStops(ev){
 const G=GEO.stops, c=$('stops'); if(!G) return hideTip();
 const r=c.getBoundingClientRect(), y=ev.clientY-r.top, x=ev.clientX-r.left;
 if(y>=G.T&&y<=G.H-G.B&&LAST_CHART){ drawStops(LAST_CHART); crosshair(c,G,x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const side=x<G.mid?'buy':'sell';
 const hit=G.bars.filter(b=>b.r.side===side&&Math.abs(b.y-y)<=Math.max(b.h,6)).sort((a,b)=>Math.abs(a.y-y)-Math.abs(b.y-y))[0];
 if(!hit) return hideTip();
 const name={stop_sell:'Sell-Stops',stop_buy:'Buy-Stops',tp_sell:'Take-Profit (Verkauf)',tp_buy:'Take-Profit (Kauf)',limit_sell:'Limit-Verkäufe',limit_buy:'Limit-Käufe'};
 const rows=hit.r.segs.map(s=>[name[s.kind]||s.kind, fmt(s.notional)+' USD · '+s.n+' Orders · '+s.addrs+' Konten']);
 rows.push(['Abstand',(hit.r.dist*100).toFixed(2)+' %', hit.r.dist<0?'#e04b4b':'#3ba55d']);
 showTip(ev, (side==='buy'?'Kaufseite bei ':'Verkaufsseite bei ')+px(hit.r.px)+' · '+fmt(hit.r.total), rows);
}

// ---- Konfluenz: transparente Regeln, jede mit Begründung --------------------
let LAST_WHALES=null, SIGNAL=null;
// Kaskadenmodell: Wo löst eine Kaskade aus, welche Art, wohin könnte sie laufen?
// Ablauf je Richtung in 0,25-%-Stufen vom Kurs weg: Auslöser = erstes nennenswertes Stop-Cluster
// (oder Liquidationscluster). Ab dort summiert sich der Druck (Stops + Liquidationen derselben
// Richtung, Perp-Notional), dagegen steht die Aufnahme: ruhende Limits (Support/Resistance) plus
// eine organische Grundaufnahme je Stufe (5 % des Stundenvolumens). Die Kaskade endet auf der
// Stufe, auf der die aufgelaufene Aufnahme den aufgelaufenen Druck erreicht -- das ist das Ziel.
// Long-Squeeze = Kaskade nach unten (Longs werden gestoppt/liquidiert), Short-Squeeze = nach oben.
function cascadeModel(d){
 const p0=d.price, vol=d.vol_1h||0, SC=(d.stops&&d.stops.clusters)||[], L=d.levels||[];
 if(!p0) return null;
 const step=Math.log(1.0025), bkt=px=>Math.round(Math.log(px)/step);
 const out={};
 for(const dir of ['down','up']){
  const sgn=dir==='down'?-1:1;
  const pressure=new Map(), absorb=new Map();
  const addTo=(m,b,v)=>m.set(b,(m.get(b)||0)+v);
  SC.forEach(s=>{ const b=bkt(s.px); const rel=(s.px/p0-1)*sgn; if(rel<=0||rel>0.15) return;
   if(dir==='down'&&s.kind==='stop_sell') addTo(pressure,b,s.notional);
   if(dir==='up'&&s.kind==='stop_buy') addTo(pressure,b,s.notional);
   if(dir==='down'&&(s.kind==='limit_buy'||s.kind==='tp_buy')) addTo(absorb,b,s.notional);
   if(dir==='up'&&(s.kind==='limit_sell'||s.kind==='tp_sell')) addTo(absorb,b,s.notional); });
  L.forEach(l=>{ const rel=(l.px/p0-1)*sgn; if(rel<=0||rel>0.15) return;
   if(dir==='down'&&l.side==='long') addTo(pressure,bkt(l.px),l.notional);
   if(dir==='up'&&l.side==='short') addTo(pressure,bkt(l.px),l.notional); });
  const b0=bkt(p0), minTrig=Math.max(vol*0.25,5e6), organic=vol*0.05;
  let trig=null, cumP=0, cumA=0, chain=[], target=null, wallMax=null, absorbTotal=0;
  for(let k=1;k<=60;k++){ const b=b0+sgn*k, px=Math.exp(b*step);
   const pr=pressure.get(b)||0, ab=absorb.get(b)||0;
   if(!trig){ if(pr>=minTrig){ trig={px,pressure:pr}; cumP=pr; chain.push({px,pressure:pr}); } continue; }
   cumP+=pr; cumA+=ab+organic; absorbTotal+=ab;
   if(pr>=Math.max(vol*0.1,2e6)) chain.push({px,pressure:pr});
   if(ab>(wallMax?wallMax.notional:0)) wallMax={px,notional:ab};
   if(cumA>=cumP){ target={px,cumP,cumA,steps:k}; break; } }
  if(trig&&!target){ const px=Math.exp((b0+sgn*60)*step); target={px,cumP,cumA,steps:60,open:true}; }
  out[dir]=trig?{trigger:trig,target,chain,wall:wallMax,absorb:absorbTotal,type:dir==='down'?'Long-Squeeze':'Short-Squeeze'}:null;
 }
 return out;
}
function cascadeText(c, p0, dir){
 const C=c&&c[dir]; if(!C) return null;
 const tDist=(C.trigger.px/p0-1)*100, zDist=(C.target.px/p0-1)*100;
 const chainTxt=C.chain.length>1?` · Kette: ${C.chain.slice(0,4).map(x=>px(x.px)+' ('+fmt(x.pressure)+')').join(' → ')}${C.chain.length>4?' …':''}`:'';
 const wall=C.wall?` · größte Aufnahme ${fmt(C.wall.notional)} bei ${px(C.wall.px)}`:'';
 return `${dir==='down'?'Verkaufskaskade':'Kaufkaskade'} (${C.type}) ab ${px(C.trigger.px)} (${tDist>=0?'+':''}${tDist.toFixed(2)} %): Druck ${fmt(C.target.cumP)} gegen Aufnahme ${fmt(C.target.cumA)} — Ziel ≈ ${px(C.target.px)} (${zDist>=0?'+':''}${zDist.toFixed(2)} %)${C.target.open?', Aufnahme reicht im Modell nicht — offen':''}${chainTxt}${wall}`;
}
function computeSignal(){
 const d=LAST_CHART; if(!d||!d.candles||!d.candles.length) return;
 const px0=d.price||d.candles[d.candles.length-1].c;
 const R=[], zones=[]; let buy=0, sell=0;
 const add=(side,pts,text)=>{ if(side==='buy')buy+=pts; else if(side==='sell')sell+=pts; R.push({side,pts,text}); };
 const near=(v,pct)=>Math.abs(v)<=pct;

 // 1. Liquidationscluster: Nähe = Anlauf wahrscheinlich (warten), frisch abgeräumt = Umkehrchance
 // (im Binance-Modus sind die Marken EINGETRETENE Liquidationen -- dafür gelten die Binance-Regeln unten)
 const L=d.levels_realized?[]:(d.levels||[]);
 const big=l=>l.x_vol>=0.5;
 const dn=L.filter(l=>l.side==='long'&&big(l)&&l.dist<0).sort((a,b)=>b.dist-a.dist)[0];
 const up=L.filter(l=>l.side==='short'&&big(l)&&l.dist>0).sort((a,b)=>a.dist-b.dist)[0];
 if(dn&&near(dn.dist,0.006)) add('wait',0,`Großes Long-Cluster ${(dn.dist*100).toFixed(2)} % unter dem Kurs (${fmt(dn.notional)}) — Anlauf wahrscheinlich, Kauf erst nach Abholung`);
 if(up&&near(up.dist,0.006)) add('wait',0,`Großes Short-Cluster ${(up.dist*100).toFixed(2)} % über dem Kurs (${fmt(up.notional)}) — Anlauf wahrscheinlich, Verkauf erst nach Abholung`);
 const ev=(d.tick_events||[]).filter(e=>Date.now()/1000-e.t_trigger/1000<3600)[0];
 if(ev){ const rec=(px0/ev.px_extreme-1);
  if(ev.move_pct<0&&rec>0.003&&ev.n_liqs>0){ add('buy',2,`Long-Kaskade vor ${Math.round((Date.now()/1000-ev.t_trigger/1000)/60)} min (${(ev.move_pct*100).toFixed(2)} %, ${ev.n_liqs} Liqs), Kurs ${(rec*100).toFixed(2)} % über dem Tief — Cluster abgeräumt`);
   zones.push({kind:'buy',bot:ev.px_extreme,top:ev.px_extreme*1.006,text:'Kaskadentief'}); }
  if(ev.move_pct>0&&rec<-0.003&&ev.n_liqs>0){ add('sell',2,`Short-Squeeze vor ${Math.round((Date.now()/1000-ev.t_trigger/1000)/60)} min (${(ev.move_pct*100).toFixed(2)} %, ${ev.n_liqs} Liqs), Kurs ${(-rec*100).toFixed(2)} % unter dem Hoch — Cluster abgeräumt`);
   zones.push({kind:'sell',bot:ev.px_extreme*0.994,top:ev.px_extreme,text:'Squeeze-Hoch'}); }
 }

 // 1b. Stop-Orders der Wale: Sell-Stops dicht unter dem Kurs = Kaskade nach unten droht,
 //     Buy-Stops dicht darüber = Kaskade nach oben. Wie Cluster: erst abwarten, dann handeln.
 //     Frisch ausgelöste Stops erkennt man daran, dass sie verschwunden sind -- das
 //     übernimmt die Kaskaden-Regel oben über die tatsächlichen Liquidationsfills.
 const SC=(d.stops&&d.stops.clusters)||[], vol1h=d.vol_1h||0;
 const bigStop=s=>s.notional>=Math.max(vol1h*0.25, 5e6);
 const sellStop=SC.filter(s=>s.kind==='stop_sell'&&s.dist<0&&s.dist>-0.008&&bigStop(s)).sort((a,b)=>b.dist-a.dist)[0];
 const buyStop =SC.filter(s=>s.kind==='stop_buy' &&s.dist>0&&s.dist< 0.008&&bigStop(s)).sort((a,b)=>a.dist-b.dist)[0];
 const CM=cascadeModel(d); LAST_CASCADE=CM;
 if(sellStop) add('wait',0,`Sell-Stops ${(sellStop.dist*100).toFixed(2)} % unter dem Kurs (${fmt(sellStop.notional)}, ${sellStop.addrs} Konten) — Verkaufskaskade droht, kein Long davor`);
 if(buyStop)  add('wait',0,`Buy-Stops +${(buyStop.dist*100).toFixed(2)} % über dem Kurs (${fmt(buyStop.notional)}, ${buyStop.addrs} Konten) — Kaufkaskade möglich, kein Short davor`);
 // Ruhende Limit-Orders: eine Kaufwand dicht unter dem Kurs stützt, eine Verkaufswand darüber deckelt.
 // Take-Profits wirken wie Limits (sie absorbieren), zählen aber nur als Hinweis.
 // Schlüsselniveaus -- dieselbe Rechnung wie Panel und Chart (keyLevels)
 const K=keyLevels(d)||{}, wall=s=>s&&s.notional>=Math.max(vol1h*0.5, 10e6);
 if(wall(K.support)&&K.support.dist>-0.01)      add('buy',1,`Support ${(K.support.dist*100).toFixed(2)} % unter dem Kurs: Kaufwand ${fmt(K.support.notional)} (${K.support.addrs} Konten)`);
 else if(K.support&&K.support.dist>-0.01)       add('warn',0,`Support ${(K.support.dist*100).toFixed(2)} % unter dem Kurs, aber klein (${fmt(K.support.notional)}) — kein Punkt`);
 if(wall(K.resistance)&&K.resistance.dist<0.01) add('sell',1,`Resistance +${(K.resistance.dist*100).toFixed(2)} % über dem Kurs: Verkaufswand ${fmt(K.resistance.notional)} (${K.resistance.addrs} Konten)`);
 else if(K.resistance&&K.resistance.dist<0.01)  add('warn',0,`Resistance +${(K.resistance.dist*100).toFixed(2)} % über dem Kurs, aber klein (${fmt(K.resistance.notional)}) — kein Punkt`);
 if(wall(K.tp_long)&&K.tp_long.dist<0.01)   add('warn',0,`Take-Profits der Longs +${(K.tp_long.dist*100).toFixed(2)} % über dem Kurs: ${fmt(K.tp_long.notional)} — Verkaufsdruck beim Anstieg (Hinweis)`);
 if(wall(K.tp_short)&&K.tp_short.dist>-0.01) add('warn',0,`Take-Profits der Shorts ${(K.tp_short.dist*100).toFixed(2)} % unter dem Kurs: ${fmt(K.tp_short.notional)} — Kaufdruck beim Rückgang (Hinweis)`);
 // Kaskadenmasse dicht am Kurs, unabhängig vom größten Einzelcluster
 if((K.stop_sell_2pct||0)>=Math.max(vol1h*0.5,10e6)) add('wait',0,`Sell-Stops innerhalb 2 % unter dem Kurs summieren sich auf ${fmt(K.stop_sell_2pct)} — ${cascadeText(CM,px0,'down')||'Verkaufskaskade bei Unterschreiten'}`);
 if((K.stop_buy_2pct||0) >=Math.max(vol1h*0.5,10e6)) add('wait',0,`Buy-Stops innerhalb 2 % über dem Kurs summieren sich auf ${fmt(K.stop_buy_2pct)} — ${cascadeText(CM,px0,'up')||'Kaufkaskade bei Überschreiten'}`);
 // Kaskadenprognose als eigene Hinweise, wenn der Auslöser innerhalb 3 % liegt (auch ohne die 2-%-Summe)
 for(const dir of ['down','up']){ const C=CM&&CM[dir]; if(!C) continue; const tDist=Math.abs(C.trigger.px/px0-1);
  const already=(dir==='down'&&(K.stop_sell_2pct||0)>=Math.max(vol1h*0.5,10e6))||(dir==='up'&&(K.stop_buy_2pct||0)>=Math.max(vol1h*0.5,10e6));
  if(tDist<=0.03&&!already) add('warn',0,`Kaskadenprognose: ${cascadeText(CM,px0,dir)}`); }

 // Stops UND Liquidationscluster auf derselben Seite dicht am Kurs: doppelter Magnet
 if(sellStop&&dn&&near(dn.dist,0.008)) add('wait',0,`Sell-Stops und Long-Liquidationen liegen beide dicht unter dem Kurs — doppelter Magnet nach unten`);
 if(buyStop&&up&&near(up.dist,0.008))  add('wait',0,`Buy-Stops und Short-Liquidationen liegen beide dicht über dem Kurs — doppelter Magnet nach oben`);

 // 2. Offene Fair Value Gaps direkt am Kurs
 const F=(d.fvgs||[]).filter(f=>f.fill_i==null);
 const fb=F.filter(f=>f.kind==='bull'&&f.top<=px0&&px0/f.top-1<0.005)[0];
 const fs=F.filter(f=>f.kind==='bear'&&f.bot>=px0&&f.bot/px0-1<0.005)[0];
 if(fb){ add('buy',1,`Offenes bullisches FVG ${px(fb.bot)}–${px(fb.top)} direkt unter dem Kurs`); zones.push({kind:'buy',bot:fb.bot,top:fb.top,text:'bullisches FVG'}); }
 if(fs){ add('sell',1,`Offenes bärisches FVG ${px(fs.bot)}–${px(fs.top)} direkt über dem Kurs`); zones.push({kind:'sell',bot:fs.bot,top:fs.top,text:'bärisches FVG'}); }
 const inb=F.filter(f=>f.kind==='bull'&&px0>=f.bot&&px0<=f.top)[0], ins=F.filter(f=>f.kind==='bear'&&px0>=f.bot&&px0<=f.top)[0];
 if(inb){ add('buy',1,`Kurs steht IM bullischen FVG ${px(inb.bot)}–${px(inb.top)}`); zones.push({kind:'buy',bot:inb.bot,top:inb.top,text:'bullisches FVG'}); }
 if(ins){ add('sell',1,`Kurs steht IM bärischen FVG ${px(ins.bot)}–${px(ins.top)}`); zones.push({kind:'sell',bot:ins.bot,top:ins.top,text:'bärisches FVG'}); }

 // 3. RSI
 if(d.rsi14!=null){ if(d.rsi14<=30) add('buy',1,`RSI ${d.rsi14.toFixed(0)} (${d.rsi_tf}) überverkauft`);
  else if(d.rsi14>=70) add('sell',1,`RSI ${d.rsi14.toFixed(0)} (${d.rsi_tf}) überkauft`); }

 // 4. Orderbuch-Imbalance (Tiefe innerhalb 50 bps)
 if(d.book){ const i=d.book.imb_50;
  if(i>=0.3) add('buy',1,`Orderbuch: ${(i*100).toFixed(0)} % mehr Bid- als Ask-Tiefe (50 bps)`);
  else if(i<=-0.3) add('sell',1,`Orderbuch: ${(-i*100).toFixed(0)} % mehr Ask- als Bid-Tiefe (50 bps)`); }

 // 5. Funding: extreme Werte bedeuten einseitige Positionierung
 if(d.funding){ const f=d.funding.funding;
  if(f<=-0.00005) add('buy',1,`Funding ${(f*100).toFixed(4)} %/h negativ — Shorts zahlen, Squeeze-Potenzial`);
  else if(f>=0.0001) add('sell',1,`Funding ${(f*100).toFixed(4)} %/h stark positiv — Longs überfüllt`); }

 // 6. Wal-Netto-Ausrichtung im gewählten Coin
 // Wal-Flow: Positionsänderungen der direktionalen Wale in den letzten 30 min -- schnellstes Signal (Nachrichten!)
 if(LAST_WHALES&&LAST_WHALES.flow&&LAST_WHALES.flow.groups){ const FG=LAST_WHALES.flow.groups, NM=LAST_WHALES.flow.group_names||{};
  const okW=w=>w&&(w.buy_usd+w.sell_usd)>=3e5&&(w.n_buy+w.n_sell)>=2;
  for(const g of ['hedge','mm','mixed']){ const gf=FG[g]; if(!gf) continue;
   let w=gf.w30, win='30 min', z=gf.z30; if(!okW(w)&&okW(gf.w60)){ w=gf.w60; win='60 min'; z=gf.z60; }
   if(!okW(w)) continue; const gr=w.buy_usd+w.sell_usd;
   if(Math.abs(w.net_usd)>gr*0.5) add('warn',0,`Wal-Flow ${NM[g]||g} ${win}: ${w.net_usd>0?w.n_buy+' Konten bauen Long auf / Short ab':w.n_sell+' Konten bauen Long ab / Short auf'}, netto ${w.net_usd>=0?'+':'−'}${fmt(Math.abs(w.net_usd))}${z!=null?` (Z ${z.toFixed(1)})`:''} — Hinweis, Gruppe wird noch bewertet`); } }
 if(LAST_WHALES&&LAST_WHALES.flow&&LAST_WHALES.flow.w30){ const F=LAST_WHALES.flow; const okW=w=>w&&(w.buy_usd+w.sell_usd)>=3e5&&(w.n_buy+w.n_sell)>=2;
  let w=F.w30, win='30 min', z=F.z30; if(!okW(w)&&okW(F.w60)){ w=F.w60; win='60 min'; z=F.z60; }   // langsame Serien: 60-min-Fenster
  const gross=w.buy_usd+w.sell_usd;
  if(okW(w)){ const big=F.event_signal, pts=big?2:1;
   if(w.net_usd>gross*0.5&&w.n_buy>=2) add('buy',pts,`Wal-Flow ${win}: ${w.n_buy} direktionale Wale bauen Long auf / Short ab, netto +${fmt(w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL: breit und außergewöhnlich schnell':''}`);
   else if(w.net_usd<-gross*0.5&&w.n_sell>=2) add('sell',pts,`Wal-Flow ${win}: ${w.n_sell} direktionale Wale bauen Long ab / Short auf, netto −${fmt(-w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL: breit und außergewöhnlich schnell':''}`);
   else add('warn',0,`Wal-Flow ${win} gemischt: ${w.n_buy} Wale kaufen ${fmt(w.buy_usd)}, ${w.n_sell} verkaufen ${fmt(w.sell_usd)} — kein Punkt`); } }
 // Leaderboard-Flow: Positionsänderungen der direktionalen Top-Konten (Stände alle 5 min verglichen)
 if(LAST_CHART&&LAST_CHART.lb&&LAST_CHART.lb.flow&&LAST_CHART.lb.flow.w60){ const F=LAST_CHART.lb.flow; const okW=w=>w&&(w.buy_usd+w.sell_usd)>=1.5e5&&(w.n_buy+w.n_sell)>=2;
  let w=F.w60, win='60 min'; if(!okW(w)&&okW(F.w180)){ w=F.w180; win='3 h'; }
  if(okW(w)){ const gross=w.buy_usd+w.sell_usd, z=F.z60, big=F.event_signal, pts=big?2:1;
   if(w.net_usd>gross*0.5&&w.n_buy>=2) add('buy',pts,`Leaderboard-Flow ${win}: ${w.n_buy} direktionale Top-Konten bauen Long auf / Short ab, netto +${fmt(w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL':''}`);
   else if(w.net_usd<-gross*0.5&&w.n_sell>=2) add('sell',pts,`Leaderboard-Flow ${win}: ${w.n_sell} direktionale Top-Konten bauen Long ab / Short auf, netto −${fmt(-w.net_usd)}${z!=null?` (Z ${z.toFixed(1)})`:''}${big?' — EREIGNIS-SIGNAL':''}`);
   else add('warn',0,`Leaderboard-Flow ${win} gemischt: ${w.n_buy} Konten kaufen ${fmt(w.buy_usd)}, ${w.n_sell} verkaufen ${fmt(w.sell_usd)} — kein Punkt`); } }
 // Nur direktionale Wale zählen: Hedges und Market Maker sind keine Meinung, sondern Absicherung
 if(LAST_WHALES&&LAST_WHALES.directional&&LAST_WHALES.directional.n_directional){
  const D=LAST_WHALES.directional;
  if(D.usd_long>D.usd_short*1.5) add('buy',1,`Direktionale Wale netto long: ${D.n_long} Konten ${fmt(D.usd_long)} gegen ${D.n_short} Konten ${fmt(D.usd_short)} short (Hedges und Market Maker ausgenommen)`);
  else if(D.usd_short>D.usd_long*1.5) add('sell',1,`Direktionale Wale netto short: ${D.n_short} Konten ${fmt(D.usd_short)} gegen ${D.n_long} Konten ${fmt(D.usd_long)} long (Hedges und Market Maker ausgenommen)`);
  else add('warn',0,`Direktionale Wale ausgeglichen: ${D.n_long} long ${fmt(D.usd_long)} gegen ${D.n_short} short ${fmt(D.usd_short)} — kein Punkt`);
 } else if(LAST_WHALES&&LAST_WHALES.directional){ add('warn',0,`${LAST_WHALES.directional.n_whales} Wale erfasst, keiner direktional — Wal-Faktor entfällt`); }

 // 6b. Binance (Binance-Modus und Fusion): Taker-Flow, Top-Trader-Positionierung, laufende Kaskade
 if(SRC()!=='hl'&&d.bnc){ const M=d.bnc.metrics||{}, LQ=d.bnc.liqs_1h||{}, CD=d.cdc||null;
  // Taker-Flow börsenübergreifend: Binance und Crypto.com nach Volumen gewichtet -- EIN Punkt, nicht zwei
  const parts=[]; if(M.taker_ls!=null) parts.push({n:'Binance',r:+M.taker_ls,w:Math.max(d.bnc.vol_1h||0,1)});
  // Trade-Stichproben (Crypto.com 150, Bybit 500 Trades) nur, wenn sie mindestens 60 s abdecken -- sonst Sekundenrauschen
  if(CD&&CD.taker_ls!=null&&CD.taker_ls<9&&(CD.taker_span_s||0)>=60) parts.push({n:'Crypto.com',r:+CD.taker_ls,w:Math.max(CD.vol_1h||0,1)});
  if(d.bybit&&d.bybit.taker_ls!=null&&(d.bybit.taker_span_s||0)>=60) parts.push({n:'Bybit',r:+d.bybit.taker_ls,w:Math.max(d.bybit.vol_1h||0,1)});
  if(d.okx&&d.okx.taker_ls!=null) parts.push({n:'OKX',r:+d.okx.taker_ls,w:Math.max(d.okx.vol_1h||0,1)});
  const lsx=[['Binance',M.global_ls_account],['Bybit',d.bybit&&d.bybit.ls_account],['OKX',d.okx&&d.okx.ls_account]].filter(e=>e[1]!=null);
  if(lsx.length>=2){ const avg=lsx.reduce((a,e)=>a+ +e[1],0)/lsx.length;
   if(avg>=2.5) add('warn',0,`Konten börsenübergreifend einseitig long (Ø ${avg.toFixed(1)}:1 — ${lsx.map(e=>`${e[0]} ${(+e[1]).toFixed(2)}`).join(', ')}) — Kaskadenrisiko nach unten (Hinweis)`);
   else if(avg<=0.6) add('warn',0,`Konten börsenübergreifend einseitig short (Ø ${avg.toFixed(2)}:1) — Squeeze-Risiko nach oben (Hinweis)`); }
  if(d.okx&&(d.okx.liq_1h_long||0)+(d.okx.liq_1h_short||0)>=5e6) add('wait',0,`OKX: ${fmt(d.okx.liq_1h_long||0)} Long- und ${fmt(d.okx.liq_1h_short||0)} Short-Liquidationen in der letzten Stunde — Kaskade läuft oder lief gerade`);
  if(parts.length){ const wsum=parts.reduce((a,p)=>a+p.w,0), r=parts.reduce((a,p)=>a+p.r*p.w,0)/wsum, lbl=parts.map(p=>`${p.n} ${p.r.toFixed(2)}`).join(', ');
   const agree=parts.every(p=>p.r>=1.2)||parts.every(p=>p.r<=0.8);
   if(r>=1.2) add('buy',1,`Taker-Flow ${(parts.length>1?'börsenübergreifend ':'')}${r.toFixed(2)}× mehr aggressive Käufe als Verkäufe (${lbl})${parts.length>1&&!agree?' — Börsen uneins':''}`);
   else if(r<=0.8) add('sell',1,`Taker-Flow ${(parts.length>1?'börsenübergreifend ':'')}nur ${r.toFixed(2)}× — aggressive Verkäufe überwiegen (${lbl})${parts.length>1&&!agree?' — Börsen uneins':''}`);
   else if(parts.length>1&&!agree&&parts.some(p=>p.r>=1.2)&&parts.some(p=>p.r<=0.8)) add('warn',0,`Taker-Flow gegenläufig: ${lbl} — Börsen uneins, kein Punkt`); }
  const fHL=(d.funding!=null&&typeof d.funding==='object')?d.funding.funding:d.funding;
  if(CD&&CD.premium!=null&&fHL!=null&&SRC()==='fusion'){ const prem=CD.premium, f=+fHL;
   if(Math.abs(prem)>0.0005&&Math.sign(prem)!==Math.sign(f)) add('warn',0,`Prämie Crypto.com ${(prem*100).toFixed(3)} % gegen Funding Hyperliquid ${(f*100).toFixed(4)} %/h gegenläufig — Positionierung der Börsen uneins (Hinweis)`);
   else if(Math.abs(prem)>0.002) add('warn',0,`Prämie Crypto.com ${(prem*100).toFixed(3)} % — Perpetual deutlich ${prem>0?'über':'unter'} Index, ${prem>0?'Longs zahlen, Squeeze-Risiko nach unten':'Shorts zahlen, Squeeze-Risiko nach oben'} (Hinweis)`); }
  if(M.top_ls_position!=null){ if(M.top_ls_position>=1.5) add('buy',1,`Binance Top-Trader netto long (Positionsverhältnis ${(+M.top_ls_position).toFixed(2)})`);
   else if(M.top_ls_position<=0.67) add('sell',1,`Binance Top-Trader netto short (Positionsverhältnis ${(+M.top_ls_position).toFixed(2)})`); }
  if(M.global_ls_account!=null&&M.global_ls_account>=3) add('warn',0,`Binance: ${(+M.global_ls_account).toFixed(1)}× mehr Long- als Short-Konten — einseitig, Kaskadenrisiko nach unten (Hinweis)`);
  const vol=d.bnc.vol_1h||vol1h||0;
  if((LQ.long||0)>=Math.max(vol*0.1,5e6)) add('wait',0,`Binance: ${fmt(LQ.long)} Long-Liquidationen in der letzten Stunde — Verkaufskaskade läuft oder lief gerade`);
  if((LQ.short||0)>=Math.max(vol*0.1,5e6)) add('wait',0,`Binance: ${fmt(LQ.short)} Short-Liquidationen in der letzten Stunde — Kaufkaskade läuft oder lief gerade`);
  const fHL2=(d.funding!=null&&typeof d.funding==='object')?d.funding.funding:d.funding;
  if(d.bnc.funding!=null&&SRC()==='fusion'&&fHL2!=null&&Math.sign(d.bnc.funding)!==Math.sign(+fHL2)&&Math.abs(d.bnc.funding)>0.00002)
   add('warn',0,`Funding gegenläufig: Hyperliquid ${(+fHL2*100).toFixed(4)} %/h, Binance ${(d.bnc.funding*100).toFixed(4)} %/h (Hinweis)`); }

 // 6c. ETF-Flows (BTC/ETH, jede Quelle): Regime-Faktor, ein Punkt
 if(d.etf&&['BTC','ETH'].includes($('coin').value)){ const E=d.etf;
  if(E.last>0&&E.sum5>0) add('buy',1,`ETF-Zuflüsse: ${E.last>0?'+':''}${E.last.toFixed(0)} Mio am ${E.last_date}, 5 Tage +${E.sum5.toFixed(0)} Mio${E.streak>=3?` — ${E.streak}. Zuflusstag in Folge`:''} (${E.source})`);
  else if(E.last<0&&E.sum5<0) add('sell',1,`ETF-Abflüsse: ${E.last.toFixed(0)} Mio am ${E.last_date}, 5 Tage ${E.sum5.toFixed(0)} Mio${E.streak<=-3?` — ${-E.streak}. Abflusstag in Folge`:''} (${E.source})`);
  else add('warn',0,`ETF-Flows uneinheitlich: letzter Tag ${E.last>0?'+':''}${E.last.toFixed(0)} Mio, 5 Tage ${E.sum5>0?'+':''}${E.sum5.toFixed(0)} Mio — kein Punkt`); }
 // 6d. Smart Money: Netto-Ausrichtung der profitabelsten Leaderboard-Konten, ein Punkt
 if(d.smart){ const S=d.smart, c=S.coin, a=S.all, use=(c.n_long+c.n_short)>=5?c:a, scope=(c.n_long+c.n_short)>=5?$('coin').value:'alle Coins';
  if(use.n_long+use.n_short>=5){
   if(use.usd_long>use.usd_short*1.5) add('buy',1,`Smart Money netto long (${scope}): ${use.n_long} Konten ${fmt(use.usd_long)} gegen ${use.n_short} Konten ${fmt(use.usd_short)} — die profitabelsten ${S.n_accounts} Konten der letzten 30 Tage`);
   else if(use.usd_short>use.usd_long*1.5) add('sell',1,`Smart Money netto short (${scope}): ${use.n_short} Konten ${fmt(use.usd_short)} gegen ${use.n_long} Konten ${fmt(use.usd_long)} — die profitabelsten ${S.n_accounts} Konten der letzten 30 Tage`);
   else add('warn',0,`Smart Money ausgeglichen (${scope}): ${use.n_long} long ${fmt(use.usd_long)}, ${use.n_short} short ${fmt(use.usd_short)} — kein Punkt`); } }

 // 6f. Käufe/Verkäufe der Top-50-Konten im gewählten Coin, letzte 24 h: ein Punkt ab 1,5-fachem Übergewicht und mind. 3 Konten
 if(d.lb_act&&d.lb_act.selected){ const S=d.lb_act.selected, b=S.buy_usd_24h, s_=S.sell_usd_24h;
  if(b+s_>=1e6&&S.n_buyers+S.n_sellers>=3){
   if(b>s_*1.5) add('buy',1,`Leaderboard-Konten kaufen ${$('coin').value}: 24 h ${fmt(b)} gekauft gegen ${fmt(s_)} verkauft (Perp + Spot, ${S.n_buyers} Käufer / ${S.n_sellers} Verkäufer)`);
   else if(s_>b*1.5) add('sell',1,`Leaderboard-Konten verkaufen ${$('coin').value}: 24 h ${fmt(s_)} verkauft gegen ${fmt(b)} gekauft (Perp + Spot, ${S.n_sellers} Verkäufer / ${S.n_buyers} Käufer)`);
   else add('warn',0,`Leaderboard-Konten in ${$('coin').value} uneinig: 24 h ${fmt(b)} gekauft, ${fmt(s_)} verkauft — kein Punkt`); } }

 // 6e. Leaderboard-Top-20-Trend im gewählten Coin: Drehung oder starker Aufbau als Hinweis (Punkte gibt Smart Money)
 if(d.lb&&d.lb.summary&&d.lb.trend&&d.lb.trend.length>=2){ const S=d.lb.summary, T=d.lb.trend, now=T[T.length-1].ts;
  const ago=[...T].reverse().find(r=>r.ts<=now-86400)||T[0]; const gross=S.usd_long+S.usd_short;
  if(gross>0){ const delta=S.net_usd-ago.net_usd;
   if(Math.sign(S.net_usd)!==Math.sign(ago.net_usd)&&Math.abs(S.net_usd)>gross*0.1) add('warn',0,`Leaderboard Top 20 in ${$('coin').value} gedreht: von netto ${ago.net_usd>0?'long':'short'} auf netto ${S.net_usd>0?'long':'short'} ${fmt(Math.abs(S.net_usd))} innerhalb 24 h (Hinweis)`);
   else if(Math.abs(delta)>=gross*0.25) add('warn',0,`Leaderboard Top 20 in ${$('coin').value}: netto ${delta>0?'+':'−'}${fmt(Math.abs(delta))} in 24 h — ${delta>0?'Longs bauen auf':'Shorts bauen auf'} (Hinweis)`); } }

 // 7. Gleitende Durchschnitte: Regime, je ein Punkt
 const m=d.mas||{};
 if(m.ma200d_dist!=null){ if(m.ma200d_dist>0) add('buy',1,`Kurs ${(m.ma200d_dist*100).toFixed(1)} % über dem MA 200 Tage (${px(m.ma200d)}) — Regime bullisch`);
  else add('sell',1,`Kurs ${(-m.ma200d_dist*100).toFixed(1)} % unter dem MA 200 Tage (${px(m.ma200d)}) — Regime bärisch`); }
 if(m.ma50w_dist!=null){ if(m.ma50w_dist>0) add('buy',1,`Kurs ${(m.ma50w_dist*100).toFixed(1)} % über dem MA 50 Wochen (${px(m.ma50w)})`);
  else add('sell',1,`Kurs ${(-m.ma50w_dist*100).toFixed(1)} % unter dem MA 50 Wochen (${px(m.ma50w)})`); }
 if(m.cross) add('warn',0,`${m.cross==='golden'?'Golden Cross':'Death Cross'}: MA 50 Tage ${m.cross==='golden'?'über':'unter'} MA 200 Tage (Hinweis, keine Punkte — schon über das Regime erfasst)`);

 // 8. Danger-Time aus der Zeit-Heatmap: keine Richtung, nur Warnung
 if(d.danger) add('warn',0,`Danger-Time: in diesem Wochentag-/Zeitfenster historisch ${d.danger.lift.toFixed(1)}x so oft Bewegungen über ${(d.danger.threshold*100).toFixed(0)} % (belastbar)`);

 const net=buy-sell, waiting=R.some(r=>r.side==='wait');
 let label,color;
 if(waiting&&Math.abs(net)<3){label='ABWARTEN — Cluster-Anlauf';color='#d29922';}
 else if(net>=3){label='KAUF-KONFLUENZ';color='#3ba55d';}
 else if(net<=-3){label='VERKAUFS-KONFLUENZ';color='#e04b4b';}
 else if(net>0){label='leicht bullisch';color='#7ee787';}
 else if(net<0){label='leicht bärisch';color='#ff7b72';}
 else{label='NEUTRAL';color='#c9d1d9';}
 // Zone nur, wenn Richtung und Preisniveau zusammenpassen
 const dir=net>0?'buy':net<0?'sell':null;
 const zone=dir?zones.filter(z=>z.kind===dir)[0]:null;
 SIGNAL={label,color,net,zone,dir};
 const t=$('kpi_signal'); if(t){t.textContent=label;t.style.color=color;t.title=`Kauf ${buy} · Verkauf ${sell}`;}
 const box=$('signalbox'); if(!box) return;
 const zoneNote=zone
   ?`<div style="margin-top:6px;color:${dir==='buy'?'#3ba55d':'#e04b4b'}">■ Zone im Chart: ${zone.text} ${px(zone.bot)}–${px(zone.top)}</div>`
   :(dir?`<div class="sub" style="margin-top:6px">Keine Zone eingezeichnet: die ${dir==='buy'?'Kauf':'Verkaufs'}-Punkte stammen aus Faktoren ohne Preisniveau (Wale, Orderbuch, Funding, RSI). Eine Zone entsteht erst durch ein FVG am Kurs oder ein frisch abgeräumtes Cluster.</div>`:'');
 const ic={buy:'▲',sell:'▼',wait:'⏸',warn:'⚠'}, col={buy:'#3ba55d',sell:'#e04b4b',wait:'#d29922',warn:'#d29922'};
 box.innerHTML=`<div style="font-size:15px;font-weight:600;color:${color};margin-bottom:6px">${label}
   <span style="font-size:11px;color:#8b949e;font-weight:400">· Kauf-Punkte ${buy}, Verkaufs-Punkte ${sell}, netto ${net>0?'+':''}${net}</span></div>`
  +(R.length?R.map(r=>`<div><span style="color:${col[r.side]}">${ic[r.side]}</span> ${r.text}`
    +(r.pts?` <span class="mono">(${r.side==='buy'?'+':'−'}${r.pts})</span>`:'')+`</div>`).join('')
   :'<div class="sub">Kein Faktor aktiv — Kurs ohne Cluster, Lücke oder Extremwert in der Nähe.</div>')
  +zoneNote
  +`<div class="sub" style="margin-top:8px">Schwellen: Konfluenz ab 3 Punkten netto. Cluster zählen ab halbem Stundenvolumen. `
  +`Orderbuch ab 30 % Imbalance, Funding ab −0,005 / +0,01 %/h, direktionale Wale ab 1,5-fachem Übergewicht (Hedges und Market Maker ausgenommen), Smart Money ab 1,5-fachem Übergewicht, ETF-Flows wenn letzter Tag und 5-Tage-Summe dasselbe Vorzeichen haben, Taker-Flow börsenübergreifend ab 1,2 / unter 0,8. Kaskadenprognose: Auslöser = erstes Stop- oder Liquidationscluster ab 25 % des Stundenvolumens; ab dort Druck (Stops + Liquidationen derselben Richtung) gegen Aufnahme (ruhende Limits + 5 % des Stundenvolumens je 0,25-%-Stufe); Ziel = Stufe, auf der die Aufnahme den Druck einholt. Long-Squeeze = nach unten, Short-Squeeze = nach oben. Ein Modell aus sichtbaren Orders, keine Vorhersage. `
  +`MA 200 Tage und MA 50 Wochen je ein Punkt nach Lage des Kurses. Stop-Cluster ab 25 % des Stundenvolumens (mind. 5 Mio) → Abwarten; `
  +`Kauf-/Verkaufswände ab 50 % (mind. 10 Mio) je ein Punkt; Take-Profits als Hinweis. Orders von Konten ab 250k USD.</div>`;
}

let healthTimer=null;
// ---- Chart als PNG exportieren: Neuzeichnung in 3-facher Auflösung, Kopfzeile mit Kontext ----
let EXPORT_DPR=0;
const EXPORT_DRAW={syschart:()=>LAST_SYS&&drawSystem(LAST_SYS), fcchart:()=>LAST_FC&&drawForecast(LAST_FC), chart:()=>LAST_CHART&&drawChart(LAST_CHART), stops:()=>LAST_CHART&&drawStops(LAST_CHART), lbchart:()=>LAST_CHART&&LAST_CHART.lb&&drawLbChart(LAST_CHART.lb), lbact48chart:()=>LAST_CHART&&drawLbAct48(LAST_CHART.lb_act48),
 heat:()=>LAST&&drawHeat(LAST), depth:()=>LAST_DEPTH&&drawDepth(LAST_DEPTH), whalechart:()=>LAST_WHALES&&drawWhales(LAST_WHALES),
 metricschart:()=>{const m=LAST_DATA&&(LAST_DATA.metrics||(LAST_DATA.bnc&&LAST_DATA.bnc.metrics)); if(m) drawMetrics(m);}};
function exportChart(id){
 const c=$(id), draw=EXPORT_DRAW[id]; if(!c||!draw) return;
 const scale=3, title=(c.closest('.panel')&&c.closest('.panel').querySelector('.ttl'))?c.closest('.panel').querySelector('.ttl').textContent:id;
 try{
  EXPORT_DPR=scale; draw();                            // in hoher Auflösung ins sichtbare Canvas zeichnen
  const r=c.getBoundingClientRect(), W=Math.round(r.width), H=Math.round(c.height/scale);
  const head=44, pad=16, out=document.createElement('canvas'); out.width=(W+2*pad)*scale; out.height=(H+head+2*pad)*scale;
  const g=out.getContext('2d'); g.setTransform(scale,0,0,scale,0,0);
  g.fillStyle='#0d1117'; g.fillRect(0,0,W+2*pad,H+head+2*pad);
  g.fillStyle='#c9d1d9'; g.font='bold 14px system-ui'; g.fillText(title, pad, pad+16);
  const meta=`${$('coin').value} · ${SRC_NAME[SRC()]} · ${new Date().toLocaleString('de-DE')} · Hyperliquid-Liquidationscluster`;
  g.fillStyle='#8b949e'; g.font='11px system-ui'; g.fillText(meta, pad, pad+34);
  g.drawImage(c, 0,0,c.width,c.height, pad, pad+head, W, H);   // Backing-Store 1:1 in Exportpixel
  g.strokeStyle='#30363d'; g.lineWidth=1; g.strokeRect(pad+0.5, pad+head+0.5, W-1, H-1);
  const a=document.createElement('a'); const ts=new Date(); const pad2=n=>String(n).padStart(2,'0');
  a.download=`hl_${id}_${$('coin').value}_${SRC()}_${ts.getFullYear()}${pad2(ts.getMonth()+1)}${pad2(ts.getDate())}-${pad2(ts.getHours())}${pad2(ts.getMinutes())}.png`;
  a.href=out.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove();
 }catch(e){ showErr('Export: '+(e.message||e)); }
 finally{ EXPORT_DPR=0; draw(); }                        // zurück auf Bildschirmauflösung
}

// ---- Wal-Liste als PNG: die gruppierte Tabelle wird auf ein Canvas gezeichnet ----
function exportWhaleTable(){
 const d=LAST_WHALES; if(!d||!d.current||!d.current.length){ showErr('Export: keine Wal-Positionen geladen'); return; }
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4);
 const age=s=>{const h=(Date.now()/1000-s)/3600; return h<1?Math.round(h*60)+' min':h<48?h.toFixed(1)+' h':(h/24).toFixed(1)+' T';};
 // Gruppierung wie in der Tabelle
 const groups=new Map();
 d.current.forEach(w=>{ const g=groups.get(w.addr)||{addr:w.addr,rows:[],total:0,long:0,short:0,upnl:0};
   g.rows.push(w); g.total+=w.pos_value||0; g.upnl+=w.upnl||0; if(w.side==='long') g.long+=w.pos_value||0; else g.short+=w.pos_value||0; groups.set(w.addr,g); });
 const ordered=[...groups.values()].sort((a,b)=>b.total-a.total); ordered.forEach(g=>g.rows.sort((a,b)=>(b.pos_value||0)-(a.pos_value||0)));
 // Zeilen aufbauen: [typ, zellen...]
 const cols=[['Wallet / Name',270,'l'],['Coin',60,'l'],['Seite',55,'l'],['Wert',90,'r'],['Hebel',55,'r'],['Einstieg',100,'r'],['Liq.-Preis',100,'r'],['Abstand',75,'r'],['unreal. PnL',95,'r'],['offen seit',80,'l'],['Stand',70,'l']];
 const lines=[];
 ordered.forEach(g=>{ const L=(LABELS||{})[g.addr.toLowerCase()]||{}; const net=g.long-g.short;
   lines.push({type:'grp', a:`${short(g.addr)} · ${g.rows.length} Position${g.rows.length>1?'en':''}`+(L.name?` · ${L.name}`:''),
     b:(L.behavior||'')+`   Gesamt ${fmt(g.total)} · netto ${net>0?'long':net<0?'short':'neutral'} ${fmt(Math.abs(net))} · PnL ${g.upnl>=0?'+':''}${fmt(g.upnl)}`, netcol:net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9'});
   g.rows.forEach(w=>{ const dist=w.mark_px?(w.liq_px-w.mark_px)/w.mark_px*100:0;
     lines.push({type:'row', hl:w.coin===coin, cells:[short(w.addr), w.coin, w.side, fmt(w.pos_value), (w.leverage||0)+'x', px(w.entry_px||0), px(w.liq_px||0), (dist>0?'+':'')+dist.toFixed(1)+' %', (w.upnl>=0?'+':'')+fmt(w.upnl||0), w.opened_at?age(w.opened_at):'—', age(w.ts)+' alt'],
       colors:[null,null,w.side==='long'?'#3ba55d':'#e04b4b',null,null,null,null,Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':null,(w.upnl||0)>=0?'#3ba55d':'#e04b4b',null,null]}); }); });
 // Seiten: höchstens 600 Zeilen je Bild (Canvas-Grenze), 2-fache Auflösung
 const scale=2, rowH=22, grpH=36, head=64, pad=16, W=cols.reduce((a,c)=>a+c[1],0)+2*pad;
 const pages=[]; let cur=[], h=0;
 lines.forEach(l=>{ const lh=l.type==='grp'?grpH:rowH; if(cur.length&&h+lh>600*rowH){ pages.push(cur); cur=[]; h=0; } cur.push(l); h+=lh; });
 if(cur.length) pages.push(cur);
 const D=d.directional||{}, ts=new Date(), pad2=n=>String(n).padStart(2,'0');
 const stamp=`${ts.getFullYear()}${pad2(ts.getMonth()+1)}${pad2(ts.getDate())}-${pad2(ts.getHours())}${pad2(ts.getMinutes())}`;
 pages.forEach((pg,pi)=>{
  const H=head+28+pg.reduce((a,l)=>a+(l.type==='grp'?grpH:rowH),0)+pad;
  const c=document.createElement('canvas'); c.width=W*scale; c.height=H*scale; const g=c.getContext('2d'); g.setTransform(scale,0,0,scale,0,0);
  g.fillStyle='#0d1117'; g.fillRect(0,0,W,H);
  g.fillStyle='#c9d1d9'; g.font='bold 15px system-ui'; g.fillText(`Wale — Konten ab 10 Mio USD Gesamtwert${pages.length>1?` (Teil ${pi+1} von ${pages.length})`:''}`, pad, pad+16);
  g.fillStyle='#8b949e'; g.font='11px system-ui';
  g.fillText(`${coin} · ${SRC_NAME[SRC()]} · ${ts.toLocaleString('de-DE')} · ${ordered.length} Wallets, ${d.current.length} Positionen`
    +(D.n_directional?` · direktional: ${D.n_long} long ${fmt(D.usd_long)} vs. ${D.n_short} short ${fmt(D.usd_short)}`:''), pad, pad+34);
  // Spaltenköpfe
  let y=head+8; g.fillStyle='#8b949e'; g.font='bold 10px system-ui';
  let x=pad; cols.forEach(([n,w,al])=>{ g.textAlign=al==='r'?'right':'left'; g.fillText(n.toUpperCase(), al==='r'?x+w-6:x+6, y); x+=w; });
  g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(pad,y+6); g.lineTo(W-pad,y+6); g.stroke(); y+=20;
  pg.forEach(l=>{
   if(l.type==='grp'){ g.fillStyle='#1c2128'; g.fillRect(pad,y-2,W-2*pad,grpH-4);
     g.fillStyle='#e3b341'; g.font='bold 12px system-ui'; g.textAlign='left'; g.fillText(l.a, pad+6, y+12);
     g.fillStyle=l.netcol; g.font='11px system-ui'; g.fillText(l.b, pad+6, y+27); y+=grpH; return; }
   if(l.hl){ g.fillStyle='#161b22'; g.fillRect(pad,y-2,W-2*pad,rowH-2); }
   let x=pad; g.font='11px monospace';
   l.cells.forEach((v,i)=>{ const [n,w,al]=cols[i]; g.fillStyle=l.colors[i]||'#c9d1d9'; g.textAlign=al==='r'?'right':'left'; g.fillText(String(v), al==='r'?x+w-6:x+(i===0?18:6), y+13); x+=w; });
   g.strokeStyle='#21262d'; g.beginPath(); g.moveTo(pad,y+rowH-3); g.lineTo(W-pad,y+rowH-3); g.stroke(); y+=rowH; });
  g.textAlign='left';
  const a=document.createElement('a'); a.download=`hl_wale_${coin}_${SRC()}_${stamp}${pages.length>1?`_teil${pi+1}`:''}.png`; a.href=c.toDataURL('image/png');
  setTimeout(()=>{ document.body.appendChild(a); a.click(); a.remove(); }, pi*400);
 });
}

function exportLbTable(){
 const L=LAST_CHART&&LAST_CHART.lb; if(!L||!L.accounts||!L.accounts.length){ showErr('Export: keine Leaderboard-Daten geladen'); return; }
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4), scale=2, rowH=22, grpH=36, head=64, pad=16;
 const cols=[['Rang / Konto',300,'l'],['Coin',60,'l'],['Seite',55,'l'],['Wert',90,'r'],['Hebel',55,'r'],['Einstieg',100,'r'],['Liq.-Preis',100,'r'],['Abstand',75,'r'],['unreal. PnL',95,'r'],['Kurs',90,'r']];
 const W=cols.reduce((a,c)=>a+c[1],0)+2*pad, lines=[];
 L.accounts.forEach(a=>{ const net=a.positions.reduce((s,p)=>s+(p.side==='long'?1:-1)*(p.pos_value||0),0);
  lines.push({type:'grp', a:`#${a.rank} ${a.name?a.name+' · ':''}${short(a.addr)} · ${a.positions.length} Position${a.positions.length!==1?'en':''}`, b:`Kontowert ${fmt(a.account_value)} · PnL 30 T +${fmt(a.pnl_30d)} (${(a.roi_30d*100).toFixed(0)} %) · 7 T ${a.pnl_7d>=0?'+':''}${fmt(a.pnl_7d)} · Positionen ${fmt(a.pos_total)} · netto ${net>0?'long':net<0?'short':'—'} ${fmt(Math.abs(net))} · unreal. PnL ${a.upnl>=0?'+':''}${fmt(a.upnl)}`, netcol:net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9'});
  a.positions.forEach(p=>{ const dist=p.mark_px?(p.liq_px-p.mark_px)/p.mark_px*100:0;
   lines.push({type:'row', hl:p.coin===coin, cells:[`#${a.rank}`, p.coin, p.side, fmt(p.pos_value), (p.leverage||0)+'x', px(p.entry_px||0), p.liq_px?px(p.liq_px):'—', p.liq_px?(dist>0?'+':'')+dist.toFixed(1)+' %':'—', (p.upnl>=0?'+':'')+fmt(p.upnl||0), p.mark_px?px(p.mark_px):'—'],
     colors:[null,null,p.side==='long'?'#3ba55d':'#e04b4b',null,null,null,null,Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':null,(p.upnl||0)>=0?'#3ba55d':'#e04b4b',null]}); }); });
 const H=head+28+lines.reduce((a,l)=>a+(l.type==='grp'?grpH:rowH),0)+pad, c=document.createElement('canvas'); c.width=W*scale; c.height=H*scale;
 const g=c.getContext('2d'); g.setTransform(scale,0,0,scale,0,0); g.fillStyle='#0d1117'; g.fillRect(0,0,W,H);
 g.fillStyle='#c9d1d9'; g.font='bold 15px system-ui'; g.fillText('Hyperliquid-Leaderboard Top 20 — Positionen und PnL', pad, pad+16);
 const S=L.summary||{}; g.fillStyle='#8b949e'; g.font='11px system-ui'; g.fillText(`${coin} · ${new Date().toLocaleString('de-DE')} · Stand ${hm(L.ts)} · in ${coin}: ${S.n_long||0} long ${fmt(S.usd_long||0)} vs. ${S.n_short||0} short ${fmt(S.usd_short||0)}`, pad, pad+34);
 let y=head+8; g.fillStyle='#8b949e'; g.font='bold 10px system-ui'; let x=pad; cols.forEach(([n,w,al])=>{ g.textAlign=al==='r'?'right':'left'; g.fillText(n.toUpperCase(), al==='r'?x+w-6:x+6, y); x+=w; });
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(pad,y+6); g.lineTo(W-pad,y+6); g.stroke(); y+=20;
 lines.forEach(l=>{ if(l.type==='grp'){ g.fillStyle='#1c2128'; g.fillRect(pad,y-2,W-2*pad,grpH-4); g.fillStyle='#e3b341'; g.font='bold 12px system-ui'; g.textAlign='left'; g.fillText(l.a,pad+6,y+12); g.fillStyle=l.netcol; g.font='11px system-ui'; g.fillText(l.b,pad+6,y+27); y+=grpH; return; }
  if(l.hl){ g.fillStyle='#161b22'; g.fillRect(pad,y-2,W-2*pad,rowH-2); } let x=pad; g.font='11px monospace';
  l.cells.forEach((v,i)=>{ const [n,w,al]=cols[i]; g.fillStyle=l.colors[i]||'#c9d1d9'; g.textAlign=al==='r'?'right':'left'; g.fillText(String(v), al==='r'?x+w-6:x+(i===0?18:6), y+13); x+=w; });
  g.strokeStyle='#21262d'; g.beginPath(); g.moveTo(pad,y+rowH-3); g.lineTo(W-pad,y+rowH-3); g.stroke(); y+=rowH; });
 g.textAlign='left'; const ts=new Date(), p2=n=>String(n).padStart(2,'0');
 const a=document.createElement('a'); a.download=`hl_leaderboard_${coin}_${ts.getFullYear()}${p2(ts.getMonth()+1)}${p2(ts.getDate())}-${p2(ts.getHours())}${p2(ts.getMinutes())}.png`; a.href=c.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove();
}

// ---- Abschnitte ein-/ausklappen, Zustand im Browser gemerkt ----------------------
function secState(){ try{ return JSON.parse(localStorage.getItem('hl_sec')||'{}'); }catch(e){ return {}; } }
function applySec(){
 const st=secState();
 document.querySelectorAll('.panel[data-sec]').forEach(p=>p.classList.toggle('closed', !!st[p.dataset.sec]));
}
function toggleSec(key){
 const p=document.getElementById('sec-'+key); if(!p) return;
 const st=secState(); st[key]=!p.classList.contains('closed'); p.classList.toggle('closed', st[key]);
 try{ localStorage.setItem('hl_sec', JSON.stringify(st)); }catch(e){}
 if(!st[key]){ setTimeout(load,50); }          // beim Aufklappen neu zeichnen
}
function toggleAll(){
 const ps=[...document.querySelectorAll('.panel[data-sec]')], anyOpen=ps.some(p=>!p.classList.contains('closed'));
 const st={}; ps.forEach(p=>{ st[p.dataset.sec]=anyOpen; p.classList.toggle('closed', anyOpen); });
 try{ localStorage.setItem('hl_sec', JSON.stringify(st)); }catch(e){}
 if(!anyOpen) setTimeout(load,50);
}
function applySrcLabels(){
 const src=SRC(), n=SRC_NAME[src];
 const set=(sel,txt)=>{ const e=document.querySelector(sel); if(e) e.textContent=txt; };
 set('#sec-chart .ttl', src==='hl'?'Live-Chart — Kurs mit aktuellen Liquidationsmarken':src==='bnc'?'Live-Chart (Binance) — Kurs mit eingetretenen Liquidationen':'Live-Chart (Data Mix Fusion) — HL-Marken, Liquidationen beider Börsen');
 set('#sec-orders .ttl', src==='hl'?'Wartende Orders und Stops — Konten ab 250k USD':src==='bnc'?'Orderbuch Binance — Tiefe je Preisstufe':'Orders (Data Mix Fusion) — HL-Konten + Orderbücher Binance und Crypto.com je Preisstufe summiert');
 set('#sec-heat .ttl', src==='hl'?'Heatmap — Clusterentwicklung über die Zeit':src==='bnc'?'Heatmap (Binance) — eingetretene Liquidationen über die Zeit':'Heatmap (Data Mix Fusion) — HL-Cluster, Binance-Liquidationen orange');
 set('#sec-depth .ttl', src==='hl'?'Momentaufnahme — Cluster rund um den aktuellen Kurs':src==='bnc'?'Momentaufnahme (Binance) — Liquidationen der letzten 24 h um den Kurs':'Momentaufnahme (Data Mix Fusion) — HL-Cluster, Binance eingetreten orange');
 set('#sec-whales .ttl', src==='hl'?'Wale — Konten ab 10 Mio. USD Gesamtwert':src==='bnc'?'Binance und Crypto.com — Open Interest, Long/Short, Taker-Flow':'Wale (HL), Kennzahlen Binance und Crypto.com');
 set('#sec-signal .ttl', src==='hl'?'Konfluenz — welche Faktoren zeigen in dieselbe Richtung?':`Konfluenz (${n}) — welche Faktoren zeigen in dieselbe Richtung?`);
 document.body.dataset.src=src;
}
function toggleHelp(a){
 const h=a.closest('.panel').querySelector('.sub.help'); if(!h) return;
 h.style.display=h.style.display==='none'?'block':'none';
}
applySec();

// ---- AI-Prognose: alle 5 min nachfragen (Server rechnet alle 15 min) -------------------------
let LAST_FC=null, FC_COIN='';
async function loadForecast(){
 const coin=$('coin').value;
 try{ const fc=await getJSON('/forecast?coin='+encodeURIComponent(coin)); LAST_FC=fc; FC_COIN=coin; drawForecast(fc); }catch(e){}
}
// Sichtfenster des Prognose-Charts: Start (Stunden relativ zu jetzt, -48..) und Spanne (Stunden)
let FC_VIEW={start:-48, span:216};
function fcClamp(){ FC_VIEW.span=Math.max(6,Math.min(216,FC_VIEW.span)); FC_VIEW.start=Math.max(-48,Math.min(168-FC_VIEW.span,FC_VIEW.start)); }
function fcSetSpan(span){ FC_VIEW.span=span; FC_VIEW.start=span>=216?-48:-Math.round(span/4); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); }   // Vorgaben: ein Viertel Vergangenheit, drei Viertel Prognose
function fcPan(dh){ FC_VIEW.start+=dh; fcClamp(); if(LAST_FC) drawForecast(LAST_FC); }
function fcInit(){
 document.querySelectorAll('.fcz').forEach(b=>b.onclick=()=>fcSetSpan(+b.dataset.span));
 $('fcprev').onclick=()=>fcPan(-Math.round(FC_VIEW.span/3)); $('fcnext').onclick=()=>fcPan(Math.round(FC_VIEW.span/3)); $('fcnow').onclick=()=>{ FC_VIEW.start=Math.max(-48,-Math.round(FC_VIEW.span/4)); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); };
 const c=$('fcchart'); let drag=null, pinch=null;
 const hpx=()=>{ const G=GEO.fc; return G?G.pw/FC_VIEW.span:1; };   // Pixel je Stunde
 c.addEventListener('mousedown',e=>{ drag={x:e.clientX,start:FC_VIEW.start}; c.style.cursor='grabbing'; });
 addEventListener('mousemove',e=>{ if(drag){ FC_VIEW.start=drag.start-(e.clientX-drag.x)/hpx(); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); } });
 addEventListener('mouseup',()=>{ if(drag){ drag=null; c.style.cursor='grab'; } });
 c.addEventListener('mousemove',e=>{ if(!drag) fcCrosshair(e.clientX); });
 c.addEventListener('mouseleave',()=>{ if(LAST_FC) drawForecast(LAST_FC); });
 c.addEventListener('wheel',e=>{ e.preventDefault(); const r=c.getBoundingClientRect(), G=GEO.fc; if(!G) return; const hx=FC_VIEW.start+(e.clientX-r.left-G.Lm)/G.pw*FC_VIEW.span;
  const f=e.deltaY>0?1.25:0.8; const ns=Math.max(6,Math.min(216,FC_VIEW.span*f)); FC_VIEW.start=hx-(hx-FC_VIEW.start)*ns/FC_VIEW.span; FC_VIEW.span=ns; fcClamp(); if(LAST_FC) drawForecast(LAST_FC); },{passive:false});
 c.addEventListener('touchstart',e=>{ if(e.touches.length===1){ drag={x:e.touches[0].clientX,start:FC_VIEW.start,moved:false}; } else if(e.touches.length===2){ pinch={d:Math.abs(e.touches[0].clientX-e.touches[1].clientX),span:FC_VIEW.span}; drag=null; } },{passive:true});
 c.addEventListener('touchmove',e=>{ if(pinch&&e.touches.length===2){ const d=Math.abs(e.touches[0].clientX-e.touches[1].clientX); FC_VIEW.span=pinch.span*pinch.d/Math.max(d,10); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); return; }
  if(drag&&e.touches.length===1){ const dx=e.touches[0].clientX-drag.x; if(Math.abs(dx)>4) drag.moved=true; FC_VIEW.start=drag.start-dx/hpx(); fcClamp(); if(LAST_FC) drawForecast(LAST_FC); } },{passive:true});
 c.addEventListener('touchend',e=>{ if(drag&&!drag.moved&&e.changedTouches.length){ fcCrosshair(e.changedTouches[0].clientX); setTimeout(()=>{ if(LAST_FC) drawForecast(LAST_FC); },2500); } drag=null; if(e.touches.length<2) pinch=null; },{passive:true});
}
function fcCrosshair(clientX){
 const G=GEO.fc, fc=LAST_FC, c=$('fcchart'); if(!G||!fc) return; const r=c.getBoundingClientRect(); const x=clientX-r.left; if(x<G.Lm||x>G.W-G.R) return;
 const h=Math.round(FC_VIEW.start+(x-G.Lm)/G.pw*FC_VIEW.span); drawForecast(fc);
 const g=c.getContext('2d'), d=devicePixelRatio||1; g.save(); g.setTransform(d,0,0,d,0,0);
 const X=t=>G.Lm+((t-fc.ts)/3600-FC_VIEW.start)/FC_VIEW.span*G.pw, xx=X(fc.ts+h*3600);
 g.strokeStyle='rgba(201,209,217,0.55)'; g.setLineDash([4,3]); g.beginPath(); g.moveTo(xx,G.T); g.lineTo(xx,G.T+G.ph); g.stroke(); g.setLineDash([]);
 let lines=[];
 if(h<=0){ const hist=fc.history||[]; const pt=hist.reduce((a,b)=>Math.abs(b.t-(fc.ts+h*3600))<Math.abs(a.t-(fc.ts+h*3600))?b:a,hist[0]); if(pt) lines=[`${hm(pt.t)}`,`Kurs ${px(pt.c)}`]; }
 else { const p=fc.path[Math.min(fc.path.length-1,h)], b=fc.band[Math.min(fc.band.length-1,h)]; lines=[`+${h} h · ${hm(fc.ts+h*3600)}`,`Prognose ${px(p.px)} (${((p.px/fc.price-1)*100).toFixed(2)} %)`,`Band ${px(b.lo)} – ${px(b.hi)}`]; if(p.px_model!=null) lines.push(`reines Modell ${px(p.px_model)}`); }
 g.font='11px system-ui'; const w=Math.max(...lines.map(l=>g.measureText(l).width))+14, bx=Math.min(xx+8,G.W-G.R-w), by=G.T+6;
 g.fillStyle='rgba(22,27,34,0.95)'; g.fillRect(bx,by,w,lines.length*15+8); g.strokeStyle='#30363d'; g.strokeRect(bx+0.5,by+0.5,w-1,lines.length*15+7);
 g.fillStyle='#c9d1d9'; g.textAlign='left'; lines.forEach((l,i)=>g.fillText(l,bx+7,by+15+i*15)); g.restore();
}
function drawForecast(fc){
 const c=$('fcchart'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H);
 const guide=$('fcguide'), drv=$('fcdrivers'), info=$('fcinfo');
 if(!fc||fc.error||!fc.path){ if(W){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText(fc&&fc.error?('Prognose nicht berechenbar: '+fc.error):'Prognose wird berechnet …',12,24); }
  guide.innerHTML=''; drv.innerHTML=''; info.textContent=fc&&fc.error?'':'erste Berechnung läuft — braucht etwa eine Minute nach dem Start'; return; }
 const p0=fc.price, B=fc.buy, S=fc.sell, O=fc.outlook, col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9', sg=v=>(v>=0?'+':'')+v.toFixed(2)+' %';
 // ---- Guide-Kacheln ----
 guide.innerHTML=`<div title="Gewichteter Richtungsdruck aller Treiber, −1 bis +1"><span>Bias</span><b style="color:${col(fc.bias)}">${fc.label}<span class="d">${fc.bias>=0?'+':''}${fc.bias.toFixed(2)} · Konfidenz ${(fc.confidence*100).toFixed(0)} %${fc.missing&&fc.missing.length?' · fehlt: '+fc.missing.slice(0,2).join(', '):''}</span></b></div>`
  +`<div title="${B.reason}"><span>Optimaler Kaufpreis (nächste ${B.window_h[0]}–${B.window_h[1]} h)</span><b style="color:${B.advised?'#3ba55d':'#8b949e'}">${px(B.px)}<span class="d">${sg(B.dist_pct)} zum Kurs · ${B.advised?B.reason:B.note}</span></b></div>`
  +`<div title="${S.reason}"><span>Optimaler Verkaufspreis (offene Positionen, ${S.window_h[0]}–${S.window_h[1]} h)</span><b style="color:${S.advised?'#e04b4b':'#8b949e'}">${px(S.px)}<span class="d">${sg(S.dist_pct)} zum Kurs · ${S.advised?S.reason:S.note}</span></b></div>`
  +`<div title="Erwartete Bewegung der ersten ${O.h1} Stunden zum nächsten Magneten"><span>Nächste Bewegung (${O.h1} h)</span><b style="color:${col(O.target_pct)}">${px(O.target_12h)}<span class="d">${sg(O.target_pct)}${O.cascade?` · dann ${O.cascade.type} ab ${px(O.cascade.trigger)} bis ≈ ${px(O.cascade.target)}`:''}</span></b></div>`
  +`<div title="Pfad-Endpunkt nach 7 Tagen und Unsicherheitsband"><span>7 Tage</span><b style="color:${col(O.end_pct)}">${px(O.end_px)}<span class="d">${sg(O.end_pct)} · Band ${px(O.lo)} – ${px(O.hi)}</span></b></div>`
  +(()=>{ const sc=fc.score||{}; if(!sc.n&&!sc.n_4h) return `<div title="Trefferquote: Richtung nach 4 h und 24 h gegen den echten Kurs geprüft"><span>Trefferquote</span><b>noch keine<span class="d">erste Prüfung 4 h nach der ersten Prognose</span></b></div>`;
     return `<div title="Anteil der Prognosen, deren Richtung nach 24 h (bzw. 4 h) stimmte; MAE = mittlerer absoluter Fehler nach 24 h"><span>Trefferquote</span><b style="color:${sc.hit_rate!=null?(sc.hit_rate>=0.6?'#3ba55d':sc.hit_rate>=0.45?'#d29922':'#e04b4b'):'#c9d1d9'}">${sc.hit_rate!=null?(sc.hit_rate*100).toFixed(0)+' % (24 h, n='+sc.n+')':'—'}<span class="d">${sc.hit_rate_4h!=null?'4 h: '+(sc.hit_rate_4h*100).toFixed(0)+' % (n='+sc.n_4h+')':''}${sc.mae_pct!=null?' · Fehler 24 h Ø '+sc.mae_pct.toFixed(2)+' %':''}</span></b></div>`; })();
 // ---- Chart: 48 h Historie + 7 Tage Pfad ----
 if(!W){ return; }
 const hist=fc.history||[], path=fc.path, band=fc.band;
 fcClamp(); const vs=FC_VIEW.start, vsp=FC_VIEW.span, Lm=64,R=64,T=14,Bm=26,pw=W-Lm-R,ph=H-T-Bm;
 const X=t=>Lm+((t-fc.ts)/3600-vs)/vsp*pw, inView=t=>{ const hh=(t-fc.ts)/3600; return hh>=vs-1&&hh<=vs+vsp+1; };
 // Preisskala aus dem sichtbaren Ausschnitt
 const vis=[...hist.filter(h=>inView(h.t)).map(h=>h.c),...band.filter(b=>inView(fc.ts+b.h*3600)).flatMap(b=>[b.lo,b.hi])];
 if(vs<=12){ vis.push(B.px,S.px); }
 const allPx=vis.filter(v=>v); const lo=(allPx.length?Math.min(...allPx):fc.price*0.95)*0.997, hi=(allPx.length?Math.max(...allPx):fc.price*1.05)*1.003, Y=v=>T+(hi-v)/(hi-lo)*ph;
 g.strokeStyle='#161b22'; for(let k=0;k<=5;k++){const y=T+ph*k/5; g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.fillStyle='#6e7681'; g.font='10px system-ui'; g.textAlign='right'; g.fillText(px(hi-(hi-lo)*k/5),Lm-4,y+3);}
 g.textAlign='left';
 // Clip auf den Zeichenbereich
 g.save(); g.beginPath(); g.rect(Lm,T,pw,ph); g.clip();
 // Zeitgitter: Tage immer; 6-h-Linien unter 5 Tagen Spanne; Stundenlinien unter 30 h
 const stepH=vsp<=30?1:vsp<=120?6:24;
 for(let hh=Math.ceil(vs/stepH)*stepH; hh<=vs+vsp; hh+=stepH){ const t=fc.ts+hh*3600, x=X(t); const isDay=hh%24===0&&hh!==0;
  g.strokeStyle=isDay?'#30363d':'#161b22'; g.beginPath(); g.moveTo(x,T); g.lineTo(x,T+ph); g.stroke();
  g.fillStyle=isDay?'#8b949e':'#6e7681'; g.font='9px system-ui'; g.textAlign='center';
  g.fillText(stepH===24?(hh>0?'+'+(hh/24)+' T':hh===0?'jetzt':(hh/24)+' T'):(stepH===6?(hh%24===0?(hh>0?'+'+(hh/24)+' T':'jetzt'):(hh>0?'+':'')+hh+' h'):(hh%6===0?((hh>0?'+':'')+hh+' h'):'')),x,H-8); }
 g.textAlign='left';
 // Trennlinie jetzt
 g.strokeStyle='#8b949e'; g.setLineDash([2,3]); g.beginPath(); g.moveTo(X(fc.ts),T); g.lineTo(X(fc.ts),T+ph); g.stroke(); g.setLineDash([]); g.fillStyle='#8b949e'; g.font='10px system-ui'; g.fillText('jetzt',X(fc.ts)+3,T+10);
 // Band
 g.fillStyle='rgba(201,184,255,0.14)'; g.beginPath(); band.forEach((b,i)=>{ const x=X(fc.ts+b.h*3600); i?g.lineTo(x,Y(b.hi)):g.moveTo(x,Y(b.hi)); }); for(let i=band.length-1;i>=0;i--){ const b=band[i]; g.lineTo(X(fc.ts+b.h*3600),Y(b.lo)); } g.closePath(); g.fill();
 // Magneten
 const M=fc.magnets||{}; const drawMag=(arr,color,label)=>arr.forEach(m=>{ const y=Y(m.px); if(y<T||y>T+ph) return; g.strokeStyle=color; g.lineWidth=1; g.setLineDash([1,3]); g.beginPath(); g.moveTo(X(fc.ts),y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]); g.fillStyle=color; g.font='9px system-ui'; g.textAlign='right'; g.fillText(`${label} ${fmt(m.usd)}`,W-R-2,y-2); g.textAlign='left'; });
 drawMag(M.liq_up||[],'rgba(59,165,93,0.8)','Short-Liq'); drawMag(M.liq_dn||[],'rgba(224,75,75,0.8)','Long-Liq'); drawMag(M.wall_up||[],'rgba(200,120,255,0.8)','Wand'); drawMag(M.wall_dn||[],'rgba(88,166,255,0.8)','Wand');
 // Historie
 if(hist.length>1){ g.strokeStyle='#fff'; g.lineWidth=1.4; g.beginPath(); hist.forEach((h,i)=>i?g.lineTo(X(h.t),Y(h.c)):g.moveTo(X(h.t),Y(h.c))); g.stroke(); }
 // Pfad (Ensemble) und, dünn, der reine Modellpfad
 if(path[1]&&path[1].px_model!=null){ g.strokeStyle='rgba(201,184,255,0.45)'; g.lineWidth=1; g.setLineDash([3,4]); g.beginPath(); path.forEach((p,i)=>{ const x=X(fc.ts+p.h*3600); i?g.lineTo(x,Y(p.px_model)):g.moveTo(x,Y(p.px_model)); }); g.stroke(); g.setLineDash([]); }
 g.strokeStyle='#c9b8ff'; g.lineWidth=2; g.setLineDash([7,4]); g.beginPath(); path.forEach((p,i)=>{ const x=X(fc.ts+p.h*3600); i?g.lineTo(x,Y(p.px)):g.moveTo(x,Y(p.px)); }); g.stroke(); g.setLineDash([]);
 // Fenster 4-12 h und Kauf/Verkauf
 g.fillStyle='rgba(255,255,255,0.04)'; g.fillRect(X(fc.ts+4*3600),T,X(fc.ts+12*3600)-X(fc.ts+4*3600),ph);
 [[B.px,'#3ba55d','KAUF '+px(B.px)+(B.advised?'':' (nicht ratsam)')],[S.px,'#e04b4b','VERKAUF '+px(S.px)+(S.advised?'':' (nicht ratsam)')]].forEach(([v,cc,lbl])=>{ const y=Y(v); if(y<T||y>T+ph) return;
  g.strokeStyle=cc; g.lineWidth=1.4; g.setLineDash([5,3]); g.beginPath(); g.moveTo(X(fc.ts),y); g.lineTo(X(fc.ts+24*3600),y); g.stroke(); g.setLineDash([]); g.fillStyle=cc; g.font='bold 10px system-ui'; g.fillText(lbl,X(fc.ts)+4,y-3); });
 g.restore();
 // Kurs jetzt
 if(Y(p0)>=T&&Y(p0)<=T+ph){ g.fillStyle='#58a6ff'; g.fillRect(W-R+2,Y(p0)-8,R-4,16); g.fillStyle='#0d1117'; g.font='bold 10px system-ui'; g.fillText(px(p0),W-R+5,Y(p0)+4); }
 $('fcview').textContent=`${vs<=0?hm(fc.ts+vs*3600):'+'+Math.round(vs)+' h'} bis +${Math.round(vs+vsp)} h · ${vsp<=30?'Stundenraster':vsp<=120?'6-h-Raster':'Tagesraster'} · ziehen = scrollen, Rad/Pinch = zoomen, tippen = Werte`;
 GEO.fc={fc,Lm,R,T,B:Bm,pw,ph,W,H,lo,hi};
 // ---- Treiber (mit gelerntem Gewicht und Trefferquote je Treiber) ----
 drv.innerHTML=`<table class="w"><tr><th>Treiber</th><th class="n">Richtung</th><th class="n">Gewicht</th><th class="n">Prior</th><th class="n">Treffer</th><th>Begründung</th></tr>`
  +fc.drivers.map(d=>`<tr><td><b>${d.name}</b>${d.learned?' <span class="lbl-beh" title="Gewicht aus der eigenen Trefferbilanz gelernt">gelernt</span>':''}</td><td class="n" style="color:${col(d.score)}">${d.score>=0?'+':''}${d.score.toFixed(2)}</td><td class="n"${d.learned?' style="color:#c9b8ff"':''}>${d.weight.toFixed(2)}</td><td class="n" style="color:#6e7681">${(d.prior||d.weight).toFixed(1)}</td><td class="n" style="color:${d.hit_rate==null?'#6e7681':d.hit_rate>=0.55?'#3ba55d':d.hit_rate<0.45?'#e04b4b':'#c9d1d9'}">${d.hit_rate!=null?(d.hit_rate*100).toFixed(0)+' % (n='+d.n+')':'—'}</td><td>${d.text}</td></tr>`).join('')+'</table>';
 // ---- Selbstoptimierung ----
 const Lr=fc.learn||{}, EN=fc.ensemble||{}, AN=fc.analog, MS=fc.magnet_stats, MU=fc.magnet_used, sc=fc.score||{};
 const lw=Lr.weights||{}; const nLearned=Object.values(lw).filter(w=>Math.abs((w.weight||0)-(w.prior||0))>0.02).length;
 $('fclearn').innerHTML=`<div class="sub" style="margin:6px 0 4px"><b>Selbstoptimierung</b> — das Modell lernt an seinen eigenen Prognosen</div><div class="kpi" style="margin:0">`
  +`<div title="Treibergewichte aus der Trefferbilanz gelernt (Logit auf die 24-h-Richtung, Prior als Anker; ab 40 bewerteten Prognosen)"><span>Gelernte Gewichte</span><b>${nLearned} von ${Object.keys(lw).length||Object.keys(fc.drivers).length}<span class="d">${(Lr.plan&&Lr.plan.n_scored_24h)||0} Prognosen nach 24 h bewertet (eine je 15 min gezählt) · ${((Lr.plan&&Lr.plan.n_scored_24h)||0)<40?'Lernen ab 40 — siehe Lernplan':'Version '+(Lr.wver?hm(Lr.wver):'—')}</span></b></div>`
  +`<div title="Mischung aus Modellpfad und Analog-Median; Gewichte aus den laufenden Trefferquoten beider Modelle"><span>Ensemble</span><b>${((EN.w_model||0.6)*100).toFixed(0)} % Modell · ${((EN.w_analog||0.4)*100).toFixed(0)} % Analog<span class="d">${(Lr.ensemble||{}).from||''}${sc.model&&sc.model.n?` · Modell ${(sc.model.hit_rate*100).toFixed(0)} % (n=${sc.model.n})`:''}${sc.analog&&sc.analog.n?` · Analog ${(sc.analog.hit_rate*100).toFixed(0)} % (n=${sc.analog.n})`:''}</span></b></div>`
  +(AN?`<div title="Die ähnlichsten Momente der Kurshistorie (Renditen, Volatilität, RSI, Lage zum 7-Tage-Mittel, Tageszeit, Wochentag)"><span>Analog-Suche</span><b>${AN.n} Analoge<span class="d">aus ${AN.span_days.toFixed(0)} Tagen Historie · 24 h danach: Median ${(AN.ret[24].med*100).toFixed(2)} %, ${(AN.ret[24].p_up*100).toFixed(0)} % aufwärts · 7 T: ${AN.ret[168]?(AN.ret[168].med*100).toFixed(1)+' % ('+(AN.ret[168].q20*100).toFixed(1)+' … '+(AN.ret[168].q80*100).toFixed(1)+' %)':'—'}</span></b></div>`
    :`<div title="braucht mindestens ~40 Tage 30-min-Kerzen (klines30 oder bnc_bars)"><span>Analog-Suche</span><b>—<span class="d">noch zu wenig Kurshistorie für diesen Coin</span></b></div>`)
  +(MS?`<div title="Aus Heatmap-Snapshots gemessen: Wahrscheinlichkeit, dass ein großes Cluster innerhalb 12 h erreicht wird, Überschuss und Rückkehr — nach Abstandsklassen"><span>Magnet-Statistik</span><b>${Object.entries(MS).map(([k,v])=>`${k} %: ${(v.p_touch*100).toFixed(0)} %`).join(' · ')}<span class="d">${MU?`genutzt: Klasse ${MU.class} — Treffer ${(MU.p_touch*100).toFixed(0)} %, Überschuss ${(MU.overshoot*100).toFixed(2)} %, Rückkehr ${(MU.retrace*100).toFixed(0)} % (n=${MU.n})`:'kein großes Cluster in Reichweite'}</span></b></div>`
    :`<div title="braucht einige Tage Heatmap-Snapshots"><span>Magnet-Statistik</span><b>—<span class="d">noch zu wenige Cluster-Annäherungen gemessen</span></b></div>`)
  +`<div title="Volatilität je Wochentag und Stunde aus der Kurshistorie formt das Unsicherheitsband"><span>Zeitprofil</span><b>${fc.tprof_used?'aktiv':'—'}<span class="d">${fc.tprof_used?'Band je Stunde mit der typischen Volatilität dieser Stunde skaliert':'noch kein Profil'}${Lr.store?'<br>Ablage: '+Lr.store:''}</span></b></div>`
  +(sc.oos&&sc.oos.n?`<div title="Trefferquote nur der Prognosen, die mit der aktuellen Gewichtsversion entstanden — der ehrliche Wert, nicht an den Daten kalibriert, auf denen er gemessen wird"><span>Out-of-sample</span><b style="color:${sc.oos.hit_rate>=0.6?'#3ba55d':sc.oos.hit_rate>=0.45?'#d29922':'#e04b4b'}">${(sc.oos.hit_rate*100).toFixed(0)} %<span class="d">n=${sc.oos.n} seit der letzten Kalibrierung</span></b></div>`:'')
  +((Lr.errors||[]).length?`<div><span>Lernfehler</span><b style="color:#d29922">${Lr.errors.length}<span class="d">${Lr.errors.join(' · ').slice(0,160)}</span></b></div>`:'')
  +'</div>'+(()=>{ const P=Lr.plan; if(!P) return ''; const t=v=>v?hm(v):'—'; const rel=v=>{ if(!v) return ''; const m=Math.round((v-Date.now()/1000)/60); return m<=0?' (jetzt fällig)':m<60?` (in ${m} min)`:m<48*60?` (in ${(m/60).toFixed(1)} h)`:` (in ${(m/1440).toFixed(1)} Tagen)`; };
     const C=P.components||{};
     return `<div class="sub" style="margin:8px 0 4px"><b>Lernplan</b> — wann was passiert</div><div class="kpi" style="margin:0">`
      +`<div title="${(Lr.store||'forecasts.db')} — Prognosen dieses Coins (alle 15 min plus Sofortberechnungen bei Wal-/Leaderboard-Ereignissen); fürs Lernen zählt eine je 15-min-Fenster, damit Ereignis-Serien nicht dominieren"><span>Prognosen</span><b>${P.n_stored} gespeichert<span class="d">seit ${t(P.first_ts)} · ${P.n_windows||P.n_stored} Fenster à 15 min · bewertet: ${P.n_scored_4h} nach 4 h, ${P.n_scored_24h} Fenster nach 24 h</span></b></div>`
      +`<div title="Die Bewertung läuft mit jeder Berechnung; eine Prognose wird bewertet, sobald sie 4 bzw. 24 h alt ist"><span>Nächste Bewertung</span><b>${t(P.next_eval_4h)}${rel(P.next_eval_4h)}<span class="d">4-h-Prüfung · 24-h-Prüfung ${t(P.next_eval_24h)}${rel(P.next_eval_24h)}</span></b></div>`
      +`<div title="Das Lernen der Gewichte beginnt, sobald 40 Prognose-Fenster (je 15 min) mindestens 24 h alt und bewertet sind — ein statistisches Minimum, damit keine Zufallstreffer die Gewichte bewegen"><span>Lernbeginn</span><b style="color:${P.learning?'#3ba55d':'#c9d1d9'}">${P.learning?'läuft':t(P.learn_eta)+rel(P.learn_eta)}<span class="d">${P.learning?'Gewichte werden aus der Trefferbilanz gelernt':`noch ${Math.max(0,40-P.n_scored_24h)} bewertete Fenster bis zum Start`}</span></b></div>`
      +`<div title="Alle 15 min werden die Gewichte neu berechnet; gespeichert wird nur, wenn sich eines um mehr als 0,02 ändert — das ist eine neue Gewichtsversion. Vor dem Lernbeginn ist die gespeicherte Version der Prior."><span>Gewichte</span><b>geprüft ${t(P.w_checked)}<span class="d">${P.learning?'zuletzt geändert':'Version (Prior) seit'} ${t(P.w_changed)} · nächste Prüfung ${t(P.next_w_check)}${rel(P.next_w_check)}</span></b></div>`
      +`<div title="Stündlich: Analog-Suche und Magnet-Statistik; alle 6 h: Zeitprofil — aus forecasts.db (Tabelle learned)"><span>Bausteine erneuert</span><b><span class="d" style="display:block;font-size:12px;color:#c9d1d9">Analog ${t(C.analog)} · Magneten ${t(C.magnets)} · Zeitprofil ${t(C.tprof)}</span><span class="d">nächste Prognose ${t(P.next_forecast)}${rel(P.next_forecast)} (früher bei Wal-/Leaderboard-Ereignis)</span></b></div>`
      +'</div>'; })()+(fc.analog_examples&&fc.analog_examples.length?`<div class="sub" style="margin-top:4px">Nächste Analoge: ${fc.analog_examples.map(e=>`${new Date(e.ts*1000).toLocaleDateString('de-DE')} (Abstand ${e.dist}, 24 h danach ${(e.r24*100).toFixed(1)} %)`).join(' · ')}</div>`:'');
 info.textContent=`Prognose von ${hm(fc.ts)} · Volatilität ${(fc.sigma_h*100).toFixed(2)} %/h · ${fc.n_directional_lb} direktionale Leaderboard-Konten berücksichtigt · nächste Berechnung in ≤ 15 min · Modell aus sichtbaren Daten, keine Vorhersage`;
}
fcInit(); loadForecast(); setInterval(loadForecast, 60000);

// ---- Systemüberwachung: alle 60 s -------------------------------------------------------
let LAST_SYS=null;
function tempColor(t){ return t==null?'#c9d1d9':t>=80?'#e04b4b':t>=70?'#d29922':t>=60?'#e3b341':'#3ba55d'; }
async function loadSystem(){
 try{ LAST_SYS=await getJSON('/system'); drawSystem(LAST_SYS); }catch(e){}
}
function drawSystem(S){
 const c=S.current||{}, k=$('syskpi'); if(!k) return;
 const up=c.uptime_s!=null?(c.uptime_s>=86400?(c.uptime_s/86400).toFixed(1)+' Tage':(c.uptime_s/3600).toFixed(1)+' h'):'—';
 const memPct=c.mem_total?(c.mem_total-c.mem_avail)/c.mem_total*100:null;
 const cpuCol=c.cpu_pct==null?'#c9d1d9':c.cpu_pct>=90?'#e04b4b':c.cpu_pct>=70?'#d29922':'#3ba55d';
 const flags=(c.throttle_flags||[]); const now=flags.filter(f=>/JETZT/.test(f)), past=flags.filter(f=>/seit Start/.test(f));
 k.innerHTML=`<div title="CPU-Temperatur aus der Thermal-Zone; Pi 5 drosselt ab 80 °C"><span>CPU-Temperatur</span><b style="color:${tempColor(c.temp)}">${c.temp!=null?c.temp.toFixed(1)+' °C':'—'}<span class="d">Maximum 24 h: ${S.max_24h!=null?S.max_24h.toFixed(1)+' °C':'—'}</span></b></div>`
  +`<div title="Drosselungsflags der Firmware (vcgencmd get_throttled). Temperaturlimit seit Start = der Pi hat seit dem Neustart mindestens einmal 85 °C erreicht und sich selbst gedrosselt: Kühlung prüfen."><span>Drosselung (Firmware)</span><b style="color:${now.length?'#e04b4b':past.length?'#d29922':'#3ba55d'}">${now.length?now.join(', '):past.length?'aktuell nicht':'keine'}<span class="d">${past.length?'seit Start: '+past.join(', '):(c.throttled_hex?'Flags '+c.throttled_hex:'kein vcgencmd — kein Raspberry?')}${past.some(f=>/Temperaturlimit|Unterspannung/.test(f))?' — <span style="color:#e04b4b">'+(past.some(f=>/Temperaturlimit/.test(f))?'85 °C erreicht: Kühlung unzureichend':'')+(past.some(f=>/Unterspannung/.test(f))?' Netzteil zu schwach':'')+'</span>':''}</span></b></div>`
  +`<div title="CPU-Takt jetzt"><span>CPU-Takt</span><b>${c.cpu_mhz!=null?Math.round(c.cpu_mhz)+' MHz':'—'}</b></div>`
  +`<div title="CPU-Auslastung aller Kerne zusammen in Prozent, gemittelt seit der letzten Messung (60 s); 100 % = alle ${c.n_cpu||'?'} Kerne voll"><span>CPU-Last gesamt (%)</span><b style="color:${cpuCol}">${c.cpu_pct!=null?c.cpu_pct.toFixed(1)+' %':'—'}<span class="d">Last 1 / 5 / 15 min: ${c.load?c.load.map(v=>v.toFixed(2)).join(' / '):'—'} (${c.n_cpu||'?'} Kerne)</span></b></div>`
  +`<div title="Arbeitsspeicher: gesamt und verfügbar (MemAvailable — wirklich nutzbar, inkl. freigebbarem Cache)"><span>RAM gesamt / frei</span><b style="color:${memPct==null?'#c9d1d9':memPct>=90?'#e04b4b':memPct>=75?'#d29922':'#c9d1d9'}">${c.mem_total?(c.mem_total/1e9).toFixed(2)+' GB / '+(c.mem_avail/1e9).toFixed(2)+' GB frei':'—'}<span class="d">${memPct!=null?'belegt '+memPct.toFixed(0)+' % · '+((c.mem_total-c.mem_avail)/1e9).toFixed(2)+' GB':''}</span></b></div>`
  +(c.disks||[]).map(d=>`<div title="${d.path}"><span>${d.label} frei</span><b style="color:${d.free/d.total<0.1?'#e04b4b':d.free/d.total<0.2?'#d29922':'#c9d1d9'}">${(d.free/1e9).toFixed(1)} GB<span class="d">von ${(d.total/1e9).toFixed(0)} GB · ${(d.free/d.total*100).toFixed(0)} % frei</span></b></div>`).join('')
  +`<div title="Laufzeit seit dem letzten Neustart"><span>Läuft seit</span><b>${up}</b></div>`
  +(()=>{ const th=LAST_CHART&&LAST_CHART.budget&&LAST_CHART.budget.thermal;
     const tip="Recorder: ab 70 °C 15 % weniger API-Gewicht und 15 % längere Takte, ab 75 °C 30 % / 45 %, ab 80 °C 50 % / 100 %; Hysterese 3 °C";
     if(!th||th.temp==null&&!th.level) return `<div title="${tip}"><span>Temperaturschutz Recorder</span><b style="color:#d29922">keine Meldung<span class="d">${LAST_CHART&&LAST_CHART.budget?'Recorder schreibt keine Temperaturwerte — Version vor dem Temperaturschutz oder noch kein Snapshot seit dem Neustart':'Recorder meldet kein Budget'}</span></b></div>`;
     const txt=th.level?`Stufe ${th.level} seit ${hm(th.since)}`:'inaktiv';
     const warn=(c.temp!=null&&c.temp>=70&&!th.level)?' · <span style="color:#e04b4b">Dashboard misst '+c.temp.toFixed(1)+' °C, Recorder drosselt nicht — Recorder-Version oder Messung prüfen</span>':'';
     return `<div title="${tip}"><span>Temperaturschutz Recorder</span><b style="color:${th.level?'#e04b4b':'#3ba55d'}">${txt}<span class="d">${th.level?`API-Gewicht ×${th.weight_factor.toFixed(2)} · Takte ×${th.interval_factor.toFixed(2)}`:'Schwellen 70 / 75 / 80 °C'}${th.temp!=null?` · Recorder misst ${th.temp.toFixed(1)} °C`:''}${warn}</span></b></div>`; })();
 const cv=$('syschart'); const [g,W,H]=fit(cv); g.clearRect(0,0,W,H); if(!W) return;
 const Hh=S.history||[];
 if(Hh.length<2){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText('Verlauf baut sich auf — eine Messung pro Minute',12,24); GEO.sys=null; return; }
 const L=44,R=44,T=10,B=24,pw=W-L-R,ph=H-T-B, t0=Hh[0][0], t1=Hh[Hh.length-1][0], X=t=>L+(t1>t0?(t-t0)/(t1-t0):0.5)*pw;
 const temps=Hh.map(h=>h[1]).filter(v=>v!=null); const lo=(temps.length?Math.min(30,...temps):30)-2, hi=(temps.length?Math.max(85,...temps):85)+2, Y=v=>T+(hi-v)/(hi-lo)*ph;
 g.strokeStyle='#161b22'; for(let k2=0;k2<=4;k2++){const y=T+ph*k2/4; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 [[70,'#d29922'],[80,'#e04b4b']].forEach(([v,col])=>{ g.strokeStyle=col; g.setLineDash([4,3]); g.beginPath(); g.moveTo(L,Y(v)); g.lineTo(W-R,Y(v)); g.stroke(); g.setLineDash([]); g.fillStyle=col; g.font='9px system-ui'; g.textAlign='left'; g.fillText(v+' °C',W-R+3,Y(v)+3); });
 g.strokeStyle='#e3b341'; g.lineWidth=1.6; g.beginPath(); let st=false; Hh.forEach((h,i)=>{ if(h[1]==null) return; st?g.lineTo(X(h[0]),Y(h[1])):g.moveTo(X(h[0]),Y(h[1])); st=true; }); g.stroke();
 g.strokeStyle='rgba(88,166,255,0.8)'; g.lineWidth=1; g.beginPath(); Hh.forEach((h,i)=>{ const y=T+ph-Math.min(100,Math.max(0,h[2]||0))/100*ph; i?g.lineTo(X(h[0]),y):g.moveTo(X(h[0]),y); }); g.stroke();
 g.fillStyle='#58a6ff'; g.font='9px system-ui'; g.textAlign='left'; g.fillText('100 %',W-R+3,T+ph*0.0+10); g.fillText('0 %',W-R+3,T+ph-2);
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right'; g.fillText(hi.toFixed(0)+'°',L-4,T+10); g.fillText(lo.toFixed(0)+'°',L-4,T+ph); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(t0),L,H-8); g.textAlign='right'; g.fillText(hm(t1),W-R,H-8); g.textAlign='left';
 GEO.sys={Hh,L,R,T,B,pw,ph,W,H};
 $('sysinfo').textContent=`${Hh.length} Messungen · Stand ${hm(c.ts)} · Farben: grün < 60, gelb < 70, orange < 80, rot ≥ 80 °C`;
}
loadSystem(); setInterval(loadSystem, 60000);

// ---- Debug-Konsole ---------------------------------------------------------------
let DBG_JOB=null, DBG_TIMER=null, DBG_TEXT='';
async function dbgInit(){
 try{ const l=await getJSON('/debug/list'); const sel=$('dbgselect'); sel.innerHTML=Object.entries(l).map(([k,v])=>`<option value="${k}">${v}</option>`).join('');
  $('dbgrun').onclick=dbgRun; $('dbgcopy').onclick=dbgCopy; $('dbgsel').onclick=dbgSelectAll; $('dbgsave').onclick=dbgSave; }catch(e){}
}
function dbgSelectAll(){ const ta=$('dbgout'); ta.focus(); ta.select(); try{ ta.setSelectionRange(0, ta.value.length); }catch(e){} $('dbgstate').textContent='markiert — jetzt „Kopieren" im Handy-Menü antippen'; }
function dbgSave(){
 const t=DBG_TEXT||$('dbgout').value; const name=($('dbgselect').value||'debug')+'_'+new Date().toISOString().slice(0,16).replace(/[:T]/g,'-')+'.txt';
 const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([t],{type:'text/plain;charset=utf-8'})); a.download=name; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(a.href); a.remove();},1000);
 $('dbgstate').textContent='als '+name+' gespeichert — aus dem Download-Ordner teilen';
}
async function dbgRun(){
 const name=$('dbgselect').value; $('dbgrun').disabled=true; $('dbgcopy').disabled=true; $('dbgsel').disabled=true; $('dbgsave').disabled=true; $('dbgout').value=''; $('dbgstate').textContent='startet …';
 try{ const r=await fetch('/debug/run?name='+encodeURIComponent(name),{method:'POST'}); const j=await r.json();
  if(!j.ok){ $('dbgstate').textContent=j.msg; $('dbgrun').disabled=false; return; }
  DBG_JOB=j.id; $('dbgout').value='$ '+j.cmd+'\\n'; dbgPoll();
 }catch(e){ $('dbgstate').textContent='Fehler: '+(e.message||e); $('dbgrun').disabled=false; }
}
async function dbgPoll(){
 try{ const st=await getJSON('/debug/status?id='+encodeURIComponent(DBG_JOB));
  if(!st.ok){ $('dbgstate').textContent=st.msg; $('dbgrun').disabled=false; return; }
  const head='$ '+st.cmd+'\\n'; $('dbgout').value=head+(st.output||''); $('dbgout').scrollTop=$('dbgout').scrollHeight;
  if(st.running){ $('dbgstate').textContent=`läuft … ${st.seconds} s`; DBG_TIMER=setTimeout(dbgPoll,1000); return; }
  $('dbgstate').textContent=`fertig nach ${st.seconds} s · Exit ${st.rc}`; $('dbgrun').disabled=false; $('dbgcopy').disabled=false; $('dbgsel').disabled=false; $('dbgsave').disabled=false;
  DBG_TEXT=`# ${st.label}\\n# ${new Date().toLocaleString('de-DE')} · Coin ${$('coin').value} · Quelle ${SRC_NAME[SRC()]} · Exit ${st.rc} · ${st.seconds} s\\n`+head+(st.output||'');
 }catch(e){ $('dbgstate').textContent='Verbindung verloren, versuche weiter …'; DBG_TIMER=setTimeout(dbgPoll,2000); }
}
async function dbgCopy(){
 // 1. Zwischenablage-API (nur HTTPS/localhost) · 2. execCommand über das sichtbare Textfeld (auch HTTP) · 3. markieren lassen
 const t=DBG_TEXT||$('dbgout').value; let ok=false;
 if(navigator.clipboard&&window.isSecureContext){ try{ await navigator.clipboard.writeText(t); ok=true; }catch(e){} }
 if(!ok){ try{ const ta=$('dbgout'); const keep=ta.value; ta.value=t; ta.readOnly=false; ta.focus(); ta.select(); ta.setSelectionRange(0,t.length); ok=document.execCommand('copy'); ta.readOnly=true; ta.value=keep; ta.blur(); }catch(e){} }
 if(ok){ $('dbgstate').textContent='in die Zwischenablage kopiert'; }
 else { dbgSelectAll(); $('dbgstate').textContent='Zwischenablage über HTTP gesperrt — Text ist markiert: „Kopieren" im Handy-Menü, oder „Als Datei"'; }
}
dbgInit();

// ---- Update-Knopf --------------------------------------------------------------
let updTimer=null;
async function pollUpdate(reloadWhenDone){
 const pre=$('updlog'); pre.style.display='block';
 try{ const r=await fetch('/update/status',{cache:'no-store'}); const st=await r.json();
  pre.textContent=(st.log||'(noch keine Ausgabe)')+(st.running?'\\n… läuft …':'');
  pre.scrollTop=pre.scrollHeight;
  if(st.done){ clearTimeout(updTimer); updTimer=null; $('updbtn').disabled=false;
   $('updbtn').textContent=st.ok_marker?'Update fertig — Seite lädt neu':'Update mit Fehler beendet';
   if(st.ok_marker&&reloadWhenDone) setTimeout(()=>location.reload(true),2500); return; }
 }catch(e){ pre.textContent=(pre.textContent||'')+'\\n… Dashboard startet neu, warte …'; }
 updTimer=setTimeout(()=>pollUpdate(reloadWhenDone),3000);
}
async function runUpdate(){
 if(!confirm('Update von GitHub laden und einspielen?\\nDienste werden neu gestartet, die Aufzeichnung pausiert etwa eine Minute.')) return;
 const b=$('updbtn'); b.disabled=true; b.textContent='Lade Archiv …';
 try{ const r=await fetch('/update',{method:'POST'}); const j=await r.json();
  $('updlog').style.display='block'; $('updlog').textContent=j.msg;
  if(!j.ok){ b.disabled=false; b.textContent='Update von GitHub einspielen'; return; }
  b.textContent='Update läuft …'; pollUpdate(true);
 }catch(e){ b.disabled=false; b.textContent='Update von GitHub einspielen'; showErr('Update: '+e.message); }
}
async function loadHealth(){
 try{LAST_HEALTH=await getJSON('/health'); fillHealth(LAST_HEALTH);}catch(e){}
 // solange die Prüfung läuft, alle 30 s nachsehen statt erst in einer Stunde
 if(healthTimer){clearTimeout(healthTimer);healthTimer=null;}
 if(LAST_HEALTH&&(LAST_HEALTH.checking||LAST_HEALTH.db_ok==null)) healthTimer=setTimeout(loadHealth,30000);
}
function taskWarn(b){
 // Absturz einer Recorder-Aufgabe sichtbar machen: vorher stand so etwas nur im Journal
 const P=(b&&b.poller)||{}, T=P.task_errors||{}, now=Date.now()/1000;
 const recent=Object.entries(T).filter(([k,v])=>v&&v.ts&&now-v.ts<6*3600);
 const stale=P.alive&&now-P.alive>180;
 const el=$('taskbar'); if(!el) return;
 if(!recent.length&&!stale){ el.style.display='none'; el.innerHTML=''; return; }
 el.style.display='block';
 el.innerHTML=(stale?`<b>Recorder meldet sich nicht</b> \u2014 letztes Lebenszeichen ${hm(P.alive)}.<br>`:'')
  +recent.map(([k,v])=>`<b>Aufgabe ${k} abgest\u00fcrzt</b> (${v.count}\u00d7 \u00b7 zuletzt ${hm(v.ts)}): ${v.error}`).join('<br>')
  +(recent.length?'<br><span class="lbl-dim">wird automatisch neu gestartet \u2014 Details unter Debug \u2192 Journal hl-recorder</span>':'');
}
function fillBudget(d){
 const el=$('kpi_api'); if(!el) return; const b=d.budget;
 if(!b){el.textContent='—';el.style.color='';el.title='Recorder meldet noch kein Budget';return;}
 const pct=b.used/b.budget*100, age=Date.now()/1000-b.ts;
 const th=b.thermal||{};
 el.innerHTML=`${b.used} / ${b.budget} <span class="d">${(()=>{const P=b.poller||{}; if(!P.poller_want) return ''; const full=P.poller_batch>=P.poller_want;
   return `Poller ${P.poller_batch}/${P.poller_want} je Runde${full?'':' <span style="color:#d29922">— Stapel nicht voll</span>'} · fällig: ${P.poller_due_a} mit Position, ${P.poller_due_b} neu, ${P.poller_due_c} leer · ${(P.addr_total||0).toLocaleString('de-DE')} Adressen · `;})()}${pct.toFixed(0)} % · Reserve ${(100-pct).toFixed(0)} %${th.level?` · <span style="color:#e04b4b">Temperaturschutz Stufe ${th.level}: Gewicht −${Math.round((1-th.weight_factor)*100)} %, Takte +${Math.round((th.interval_factor-1)*100)} % (${th.temp!=null?th.temp.toFixed(1)+' °C':''})</span>`:''}</span>`;
 el.style.color=pct<70?'#3ba55d':pct<85?'#d29922':'#e04b4b';
 el.title=`Hyperliquid-Gewicht der letzten Minute: ${pct.toFixed(0)} % des Limits von ${b.budget}/min. `
  +`Der Recorder deckelt sich selbst bei 85 % — mindestens 15 % bleiben frei.`
  +(age>90?` · Stand vor ${Math.round(age/60)} min`:'')+(b.r429?` · ${b.r429}× HTTP 429 seit Start`:'');
 if(age>300){el.textContent+=' ?';el.style.color='#8b949e';}
}
function fillLbActTile(){
 const el=$('kpi_lbact'); if(!el) return; const A=LAST_CHART&&LAST_CHART.lb_act, S=A&&A.selected; $('kpi_lbact_coin').textContent=$('coin').value;
 if(!A){ el.textContent='lädt … (erster Lauf ~90 s nach Recorder-Start)'; return; }
 if(!S){ el.textContent='keine Trades der Top 50 in '+$('coin').value+' in 3 Tagen'; return; }
 const n24=S.net_usd_24h, n3=S.net_usd, c24=n24>0?'#3ba55d':n24<0?'#e04b4b':'#c9d1d9';
 el.innerHTML=`<span style="color:${c24}">24 h: netto ${n24>=0?'+':'−'}${fmt(Math.abs(n24))}</span><span class="d">3 Tage: netto ${n3>=0?'+':'−'}${fmt(Math.abs(n3))} · Käufe ${fmt(S.buy_usd)} (${S.n_buyers} Konten) · Verkäufe ${fmt(S.sell_usd)} (${S.n_sellers} Konten) · Spot ${fmt(S.spot_usd)}</span>`;
}
function drawLbActivity(A){
 const box=$('lbactcoins'); if(!box) return;
 if(!A){ box.innerHTML='<div class="sub">noch keine Fills — der Recorder holt sie etwa 90 s nach dem Start, dann stündlich.</div>'; $('lbactinfo').textContent=''; $('lbactbig').innerHTML=''; $('lbactspot').innerHTML=''; return; }
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4), sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 box.innerHTML=`<table class="w"><tr><th>Coin</th><th class="n">Käufe 3 T</th><th class="n">Konten</th><th class="n">Verkäufe 3 T</th><th class="n">Konten</th><th class="n">netto 3 T</th><th class="n">netto 24 h</th><th class="n">Spot-Anteil</th><th class="n">real. PnL</th><th class="n">Trades</th></tr>`
  +A.coins.slice(0,14).map(d=>`<tr${d.coin===coin?' style="background:#161b22"':''}><td><b>${d.coin}</b></td><td class="n" style="color:#3ba55d">${fmt(d.buy_usd)}</td><td class="n">${d.n_buyers}</td><td class="n" style="color:#e04b4b">${fmt(d.sell_usd)}</td><td class="n">${d.n_sellers}</td><td class="n" style="color:${col(d.net_usd)}"><b>${sg(d.net_usd)}</b></td><td class="n" style="color:${col(d.net_usd_24h)}">${sg(d.net_usd_24h)}</td><td class="n">${(d.buy_usd+d.sell_usd)?((d.spot_usd/(d.buy_usd+d.sell_usd))*100).toFixed(0):0} %</td><td class="n" style="color:${col(d.closed_pnl)}">${sg(d.closed_pnl)}</td><td class="n">${d.n}</td></tr>`).join('')+'</table>';
 $('lbactinfo').textContent=`Fills seit ${hm(A.since)} · jüngster Fill ${hm(A.last_fill)} · ${A.coins.length} Coins gehandelt · Kaufdruck = Open Long + Close Short + Spot-Kauf`;
 const B=A.big||[];
 $('lbactbig').innerHTML=B.length?`<div class="sub" style="margin:6px 0 4px"><b>Größte Trades in ${coin}</b> (ab 100k, Kursentwicklung seit dem Trade aus Sicht des Traders)</div><table class="w"><tr><th>Zeit</th><th>Konto</th><th>Markt</th><th>Richtung</th><th class="n">Notional</th><th class="n">Preis</th><th class="n">seither</th><th class="n">real. PnL</th></tr>`
  +B.map(t=>`<tr><td class="mono">${hm(t.ts)}</td><td class="mono">${t.rank?'#'+t.rank+' ':''}${t.name?`<span class="lbl-name">${t.name}</span>`:short(t.addr)}</td><td>${t.market}</td><td style="color:${t.buy?'#3ba55d':'#e04b4b'}">${t.dir}</td><td class="n"><b>${fmt(t.notional)}</b></td><td class="n">${px(t.px)}</td><td class="n" style="color:${t.since_pct==null?'#8b949e':col(t.since_pct)}">${t.since_pct==null?'—':(t.since_pct>=0?'+':'')+t.since_pct.toFixed(2)+' %'}</td><td class="n" style="color:${col(t.closed_pnl)}">${t.closed_pnl?sg(t.closed_pnl):'—'}</td></tr>`).join('')+'</table>'
  :`<div class="sub">keine Trades ab 100k in ${coin} in den letzten 3 Tagen.</div>`;
 const SP=A.spot||[];
 $('lbactspot').innerHTML=SP.length?`<div class="sub" style="margin:6px 0 4px"><b>Spot-Bestände der Top 50</b> (jüngster Stundenstand)</div><table class="w"><tr><th>Token</th><th>Coin</th><th class="n">Konten</th><th class="n">Menge</th><th class="n">Wert (USD)</th><th class="n">Einstand</th><th class="n">seit Einstand</th></tr>`
  +SP.slice(0,12).map(r=>`<tr${r.coin===coin?' style="background:#161b22"':''}><td><b>${r.token}</b></td><td>${r.coin}</td><td class="n">${r.n}</td><td class="n">${r.total.toLocaleString('de-DE',{maximumFractionDigits:2})}</td><td class="n"><b>${r.usd?fmt(r.usd):'—'}</b></td><td class="n">${r.entry?fmt(r.entry):'—'}</td><td class="n" style="color:${r.usd&&r.entry?col(r.usd-r.entry):'#8b949e'}">${r.usd&&r.entry?((r.usd/r.entry-1)*100).toFixed(1)+' %':'—'}</td></tr>`).join('')+'</table>'
  :'<div class="sub">keine Spot-Bestände erfasst.</div>';
}
function drawLbAct48(A){
 const c=$('lbact48chart'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H); if(!W) return;
 const coin=$('coin').value, short=a=>a.slice(0,6)+'…'+a.slice(-4), sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 const S=A&&A.series||[];
 if(!A||!S.length){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText(A?'keine Trades der Top 50 in '+coin+' in 48 h':'noch keine Fills — der Recorder holt sie etwa 90 s nach dem Start',12,24);
  $('lbact48info').textContent=''; $('lbact48coins').innerHTML=''; $('lbact48big').innerHTML=''; GEO.lbact48=null; return; }
 const Lm=64,R=64,Tp=12,B=26,pw=W-Lm-R,ph=H-Tp-B, n=S.length, cw=pw/n;
 const mx=Math.max(1,...S.map(r=>Math.max(r.buy,r.sell))), cumMax=Math.max(1,...S.map(r=>Math.abs(r.cum)));
 const mid=Tp+ph/2, Yb=v=>(v/mx)*(ph/2), Yc=v=>mid-(v/cumMax)*(ph/2);
 g.strokeStyle='#161b22'; for(let k=0;k<=4;k++){const y=Tp+ph*k/4; g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke();}
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(Lm,mid); g.lineTo(W-R,mid); g.stroke();
 S.forEach((r,i)=>{ const x=Lm+i*cw+1, w=Math.max(1,cw-2); g.fillStyle='rgba(59,165,93,0.8)'; g.fillRect(x,mid-Yb(r.buy),w,Yb(r.buy)); g.fillStyle='rgba(224,75,75,0.8)'; g.fillRect(x,mid,w,Yb(r.sell)); });
 g.strokeStyle='#58a6ff'; g.lineWidth=1.8; g.beginPath(); S.forEach((r,i)=>{ const x=Lm+i*cw+cw/2; i?g.lineTo(x,Yc(r.cum)):g.moveTo(x,Yc(r.cum)); }); g.stroke();
 const P=S.filter(r=>r.px); if(P.length>1){ const lo=Math.min(...P.map(r=>r.px)), hi=Math.max(...P.map(r=>r.px)); const Yp=v=>Tp+ph-(v-lo)/Math.max(1e-9,hi-lo)*ph;
  g.strokeStyle='rgba(255,255,255,0.7)'; g.lineWidth=1; g.beginPath(); let started=false; S.forEach((r,i)=>{ if(!r.px) return; const x=Lm+i*cw+cw/2; started?g.lineTo(x,Yp(r.px)):g.moveTo(x,Yp(r.px)); started=true; }); g.stroke();
  g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='left'; g.fillText(px(hi),W-R+4,Tp+10); g.fillText(px(lo),W-R+4,Tp+ph); }
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right'; g.fillText('+'+fmt(mx)+'/h',Lm-4,Tp+10); g.fillText('0',Lm-4,mid+3); g.fillText('−'+fmt(mx)+'/h',Lm-4,Tp+ph); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(S[0].ts),Lm,H-8); g.textAlign='right'; g.fillText(hm(S[n-1].ts),W-R,H-8); g.textAlign='left';
 GEO.lbact48={S,Lm,R,Tp,B,pw,ph,W,H};
 const sel=A.selected||{buy_usd:0,sell_usd:0,net_usd:0,n_buyers:0,n_sellers:0,buy_usd_24h:0,sell_usd_24h:0};
 $('lbact48info').innerHTML=`${coin} 48 h: Käufe <span style="color:#3ba55d">${fmt(sel.buy_usd)}</span> (${sel.n_buyers} Konten) · Verkäufe <span style="color:#e04b4b">${fmt(sel.sell_usd)}</span> (${sel.n_sellers} Konten) · netto <b style="color:${col(sel.net_usd)}">${sg(sel.net_usd)}</b> · 24 h netto <b style="color:${col(sel.buy_usd_24h-sel.sell_usd_24h)}">${sg(sel.buy_usd_24h-sel.sell_usd_24h)}</b> · jüngster Fill ${hm(A.last_fill)}`;
 $('lbact48coins').innerHTML=`<table class="w"><tr><th>Coin</th><th class="n">Käufe 48 h</th><th class="n">Konten</th><th class="n">Verkäufe 48 h</th><th class="n">Konten</th><th class="n">netto 48 h</th><th class="n">netto 24 h</th><th class="n">Spot-Anteil</th><th class="n">Trades</th></tr>`
  +A.coins.slice(0,12).map(d=>`<tr${d.coin===coin?' style="background:#161b22"':''}><td><b>${d.coin}</b></td><td class="n" style="color:#3ba55d">${fmt(d.buy_usd)}</td><td class="n">${d.n_buyers}</td><td class="n" style="color:#e04b4b">${fmt(d.sell_usd)}</td><td class="n">${d.n_sellers}</td><td class="n" style="color:${col(d.net_usd)}"><b>${sg(d.net_usd)}</b></td><td class="n" style="color:${col(d.net_usd_24h)}">${sg(d.net_usd_24h)}</td><td class="n">${(d.buy_usd+d.sell_usd)?((d.spot_usd/(d.buy_usd+d.sell_usd))*100).toFixed(0):0} %</td><td class="n">${d.n}</td></tr>`).join('')+'</table>';
 const Bg=A.big||[];
 $('lbact48big').innerHTML=Bg.length?`<div class="sub" style="margin:6px 0 4px"><b>Trades in ${coin}, letzte 48 h</b> (ab 50k, neueste zuerst)</div><table class="w"><tr><th>Zeit</th><th>Konto</th><th>Markt</th><th>Richtung</th><th class="n">Notional</th><th class="n">Preis</th><th class="n">seither</th><th class="n">real. PnL</th></tr>`
  +Bg.map(t=>`<tr><td class="mono">${hm(t.ts)}</td><td class="mono">${t.rank?'#'+t.rank+' ':''}${t.name?`<span class="lbl-name">${t.name}</span>`:short(t.addr)}</td><td>${t.market}</td><td style="color:${t.buy?'#3ba55d':'#e04b4b'}">${t.dir}</td><td class="n"><b>${fmt(t.notional)}</b></td><td class="n">${px(t.px)}</td><td class="n" style="color:${t.since_pct==null?'#8b949e':col(t.since_pct)}">${t.since_pct==null?'—':(t.since_pct>=0?'+':'')+t.since_pct.toFixed(2)+' %'}</td><td class="n" style="color:${col(t.closed_pnl)}">${t.closed_pnl?sg(t.closed_pnl):'—'}</td></tr>`).join('')+'</table>'
  :`<div class="sub">keine Trades ab 50k in ${coin} in den letzten 48 h.</div>`;
}
function fillLbTile(){
 const el=$('kpi_lbbtc'); if(!el) return; const L=LAST_CHART&&LAST_CHART.lb, B=L&&L.btc;
 if(!B||(!B.n_long&&!B.n_short)){ el.textContent=L&&L.ts?'keine BTC-Position unter den Top 20':'lädt … (Recorder fragt alle 10 min)'; el.style.color=''; return; }
 const tot=B.usd_long+B.usd_short, pl=tot?B.usd_long/tot*100:0, net=B.net_usd, col=net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9';
 const d24=B.delta_24h, d7=B.delta_7d, arrow=v=>v==null?'—':(v>0?'▲ +':v<0?'▼ ':'')+fmt(Math.abs(v));
 el.innerHTML=`<span style="color:#3ba55d">${B.n_long} LONG ${fmt(B.usd_long)} [${pl.toFixed(0)} %]</span> <span style="color:#8b949e">vs.</span> <span style="color:#e04b4b">${B.n_short} SHORT ${fmt(B.usd_short)} [${(100-pl).toFixed(0)} %]</span>`
  +`<span class="d" style="color:${col}">netto ${net>0?'long':net<0?'short':'neutral'} ${fmt(Math.abs(net))}</span><span class="d">24 h: ${arrow(d24)} · 7 T: ${arrow(d7)} — Trend: ${d24==null?'noch keine Historie':d24>0?'Longs bauen auf':d24<0?'Shorts bauen auf / Longs ab':'unverändert'}</span>`;
 el.style.color='';
}
function drawLbChart(L){
 const c=$('lbchart'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H); if(!W) return;
 const T=L&&L.trend||[];
 if(!T.length){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText(L&&L.ts?'noch keine Trendzeile — die erste kommt zur vollen Stunde':'noch keine Leaderboard-Abfrage — der Recorder fragt alle 10 min',12,24); GEO.lb=null; return; }
 const Lm=64,R=64,Tp=12,B=26,pw=W-Lm-R,ph=H-Tp-B;
 const t0=T[0].ts, t1=T[T.length-1].ts, X=t=>Lm+(t1>t0?(t-t0)/(t1-t0):0.5)*pw;
 const mx=Math.max(1,...T.map(r=>Math.max(r.usd_long,r.usd_short))), Y=v=>Tp+ph/2-(v/mx)*(ph/2);
 const Yn=v=>Tp+ph/2-(v/mx)*(ph/2);
 g.strokeStyle='#161b22'; for(let k=0;k<=4;k++){const y=Tp+ph*k/4; g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke();}
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(Lm,Tp+ph/2); g.lineTo(W-R,Tp+ph/2); g.stroke();
 const bw=Math.max(2,Math.min(14,pw/Math.max(T.length,1)*0.4));
 T.forEach(r=>{ const x=X(r.ts); g.fillStyle='rgba(59,165,93,0.75)'; g.fillRect(x-bw,Tp+ph/2-(r.usd_long/mx)*(ph/2),bw,(r.usd_long/mx)*(ph/2));
   g.fillStyle='rgba(224,75,75,0.75)'; g.fillRect(x,Tp+ph/2,bw,(r.usd_short/mx)*(ph/2)); });
 g.strokeStyle='#58a6ff'; g.lineWidth=1.8; g.beginPath(); T.forEach((r,i)=>{ const y=Yn(r.net_usd); i?g.lineTo(X(r.ts),y):g.moveTo(X(r.ts),y); }); g.stroke();
 const P=T.filter(r=>r.mark_px); if(P.length>1){ const lo=Math.min(...P.map(r=>r.mark_px)), hi=Math.max(...P.map(r=>r.mark_px)); const Yp=v=>Tp+ph-(v-lo)/Math.max(1e-9,hi-lo)*ph;
  g.strokeStyle='rgba(255,255,255,0.7)'; g.lineWidth=1; g.beginPath(); P.forEach((r,i)=>i?g.lineTo(X(r.ts),Yp(r.mark_px)):g.moveTo(X(r.ts),Yp(r.mark_px))); g.stroke();
  g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='left'; g.fillText(px(hi),W-R+4,Tp+10); g.fillText(px(lo),W-R+4,Tp+ph); }
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right'; g.fillText('+'+fmt(mx),Lm-4,Tp+10); g.fillText('0',Lm-4,Tp+ph/2+3); g.fillText('−'+fmt(mx),Lm-4,Tp+ph); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(t0),Lm,H-8); g.textAlign='right'; g.fillText(hm(t1),W-R,H-8); g.textAlign='left';
 GEO.lb={T,Lm,R,Tp,B,pw,ph,W,H,mx};
}
function drawLbTable(L){
 const box=$('lbtable'); if(!box) return; const A=L&&L.accounts||[]; const coin=$('coin').value;
 if(!A.length){ box.innerHTML='<div class="sub">noch keine Leaderboard-Abfrage.</div>'; return; }
 const short=a=>a.slice(0,6)+'…'+a.slice(-4);
 const head=a=>{ const net=a.positions.reduce((s,p)=>s+(p.side==='long'?1:-1)*(p.pos_value||0),0), col=net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9';
  return `<tr class="grp"><td class="mono" colspan="3"><b>#${a.rank}</b> ${a.name?`<span class="lbl-name">${a.name}</span> · `:''}${short(a.addr)} · ${a.positions.length} Position${a.positions.length!==1?'en':''}<br><span class="lbl-beh">Kontowert ${fmt(a.account_value)} · PnL 30 T <span style="color:#3ba55d">+${fmt(a.pnl_30d)}</span> (${(a.roi_30d*100).toFixed(0)} %) · 7 T ${a.pnl_7d>=0?'+':''}${fmt(a.pnl_7d)}</span></td>`
   +`<td class="n"><b>${fmt(a.pos_total)}</b></td><td colspan="4" style="color:${col}">netto ${net>0?'long':net<0?'short':'—'} ${fmt(Math.abs(net))}</td><td class="n" style="color:${a.upnl>=0?'#3ba55d':'#e04b4b'}">${a.upnl>=0?'+':''}${fmt(a.upnl)}</td><td></td></tr>`; };
 box.innerHTML=`<table class="w"><tr><th>Rang / Konto</th><th>Coin</th><th>Seite</th><th class="n">Wert</th><th class="n">Hebel</th><th class="n">Einstieg</th><th class="n">Liq.-Preis</th><th class="n">Abstand</th><th class="n">unreal. PnL</th><th>Kurs</th></tr>`
  +A.map(a=>head(a)+a.positions.map(p=>{ const dist=p.mark_px?(p.liq_px-p.mark_px)/p.mark_px*100:0, dc=Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':'#c9d1d9';
    return `<tr${p.coin===coin?' style="background:#161b22"':''}><td class="mono" style="color:#6e7681;padding-left:18px">└ #${a.rank}</td><td><b>${p.coin}</b></td><td style="color:${p.side==='long'?'#3ba55d':'#e04b4b'}">${p.side}</td><td class="n"><b>${fmt(p.pos_value)}</b></td><td class="n">${(p.leverage||0)}x</td><td class="n">${px(p.entry_px||0)}</td><td class="n">${p.liq_px?px(p.liq_px):'—'}</td><td class="n" style="color:${dc}">${p.liq_px?(dist>0?'+':'')+dist.toFixed(1)+' %':'—'}</td><td class="n" style="color:${p.upnl>=0?'#3ba55d':'#e04b4b'}">${p.upnl>=0?'+':''}${fmt(p.upnl)}</td><td class="mono">${p.mark_px?px(p.mark_px):'—'}</td></tr>`; }).join('')).join('')+'</table>';
 const S=L.summary||{}; const F=L.flow||{}, w=F.w60||{}, w3=F.w180||{}, sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v||0)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 $('lbinfo').innerHTML=`Stand ${hm(L.ts)} · ${A.length} Konten · in ${coin}: ${S.n_long||0} long ${fmt(S.usd_long||0)}, ${S.n_short||0} short ${fmt(S.usd_short||0)}, netto ${S.net_usd>0?'long':S.net_usd<0?'short':'—'} ${fmt(Math.abs(S.net_usd||0))} · Trendzeilen ${L.trend.length} (stündlich)`
  +(F.w60?`<br><b>Leaderboard-Flow live</b> (nur direktionale Konten, Stände alle 5 min verglichen): 60 min <span style="color:${col(w.net_usd)}">${sg(w.net_usd)}</span> (${w.n_buy||0}/${w.n_sell||0} Konten) · 3 h <span style="color:${col(w3.net_usd)}">${sg(w3.net_usd)}</span> (${w3.n_buy||0}/${w3.n_sell||0})${F.z60!=null?' · Z '+F.z60.toFixed(1):''}${F.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''} · ${F.n_directional||0} direktionale Konten`:'')
  +((L.events||[]).length?`<br><b>Letzte Änderungen der Top-Konten:</b> <span class="lbl-dim">(grau = nicht direktional)</span><br>`+L.events.slice(0,15).map(e=>{ const nm={open:'eröffnet',add:'stockt auf',reduce:'reduziert',close:'schließt',flip:'dreht auf'}[e.event]||e.event;
     return `<span style="${e.directional?'':'color:#6e7681'}">${hm(e.ts)} · ${e.rank?'#'+e.rank+' ':''}${e.name?`<span class="lbl-name">${e.name}</span>`:e.addr.slice(0,6)+'…'+e.addr.slice(-4)} ${nm} <span style="color:${e.directional?(e.side==='long'?'#3ba55d':'#e04b4b'):'#6e7681'}">${e.side}</span> ${e.delta_usd>=0?'+':''}${fmt(e.delta_usd)} USD${e.mark_px?' bei '+px(e.mark_px):''}</span>`; }).join('<br>'):'');
}
function fillFcLive(){
 const el=$('fclive'); if(!el) return; const F=LAST_WHALES&&LAST_WHALES.flow, fc=LAST_FC; if(!F||!F.w30){ el.textContent=''; return; }
 const w=F.w30, w60=F.w60, sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v)), col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9';
 const agree=fc&&Math.abs(fc.bias)>0.12&&Math.abs(w60.net_usd)>=1e6?(Math.sign(fc.bias)===Math.sign(w60.net_usd)?'bestätigt die Prognoserichtung':'<span style="color:#ff9f43">läuft gegen die Prognoserichtung — nächste Neuberechnung binnen 30 s</span>'):'';
 el.innerHTML=`<b>Wal-Flow live</b> (alle 20 s, nur direktionale Wale): 30 min <span style="color:${col(w.net_usd)}">${sg(w.net_usd)}</span> (${w.n_buy}/${w.n_sell} Wale) · 60 min <span style="color:${col(w60.net_usd)}">${sg(w60.net_usd)}</span> (${w60.n_buy}/${w60.n_sell})${F.z30!=null?' · Z '+F.z30.toFixed(1):''}${F.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''}${agree?' · '+agree:''}`
   +((LAST_CHART&&LAST_CHART.lb&&LAST_CHART.lb.flow&&LAST_CHART.lb.flow.w60)?(()=>{ const LF=LAST_CHART.lb.flow, l60=LF.w60; return `<br><b>Leaderboard-Flow live</b> (direktionale Top-Konten, 5-min-Stände): 60 min <span style="color:${col(l60.net_usd)}">${sg(l60.net_usd)}</span> (${l60.n_buy}/${l60.n_sell} Konten)${LF.z60!=null?' · Z '+LF.z60.toFixed(1):''}${LF.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''}`; })():'')
   +(fc&&fc.trigger?`<br>letzte Prognose ausgelöst durch ${fc.trigger}`:'');
}
function fillFlow(){
 const el=$('kpi_flow'); if(!el) return; const F=LAST_WHALES&&LAST_WHALES.flow; if(!F||!F.w30){ el.textContent='—'; return; }
 const w=F.w30, w60=F.w60, col=v=>v>0?'#3ba55d':v<0?'#e04b4b':'#c9d1d9', sg=v=>(v>=0?'+':'−')+fmt(Math.abs(v));
 const G=F.groups||{}, NM=F.group_names||{}, SZ=F.sizes||{};
 const line=g=>{ const gf=G[g]; if(!gf) return ''; const a=gf.w60||{}; if(!a.n_buy&&!a.n_sell) return `${NM[g]||g} ruhig`;
   return `${NM[g]||g} ${a.net_usd>=0?'+':'−'}${fmt(Math.abs(a.net_usd))} (${a.n_buy}/${a.n_sell})`; };
 el.innerHTML=`<span style="color:${col(w.net_usd)}">${sg(w.net_usd)}</span>${F.event_signal?' <span style="color:#ff9f43">⚡ Ereignis</span>':''}`
  +`<span class="d">direktional: ${w.n_buy} kaufen ${fmt(w.buy_usd)} · ${w.n_sell} verkaufen ${fmt(w.sell_usd)}${F.z30!=null?' · Z '+F.z30.toFixed(1):''} · 60 min ${sg(w60.net_usd)}`
  +`<br>60 min je Gruppe: ${['hedge','mm','mixed'].map(line).filter(Boolean).join(' · ')||'keine weiteren Gruppen'}`
  +`<br>${Object.entries(SZ).map(([g,n])=>`${n} ${NM[g]||g}`).join(' · ')} (Klasse je Coin)</span>`;
}
function fillDirectional(){
 const el=$('kpi_dirn'); if(!el) return; const D=LAST_WHALES&&LAST_WHALES.directional;
 if(!D||!D.n_directional){ el.textContent='—'; el.style.color=''; el.title=D?`${D.n_whales} Wale erfasst, keiner direktional`:''; return; }
 const tot=D.usd_long+D.usd_short, pl=tot?D.usd_long/tot*100:0, ps=tot?D.usd_short/tot*100:0;
 el.innerHTML=`<span style="color:#3ba55d">${D.n_long} LONG ${fmt(D.usd_long)} [${pl.toFixed(0)} %]</span> <span style="color:#8b949e">vs.</span> <span style="color:#e04b4b">${D.n_short} SHORT ${fmt(D.usd_short)} [${ps.toFixed(0)} %]</span>`
  +`<span class="d">${D.n_directional} von ${D.n_whales} Walen direktional · übrige: Hedge, Market Maker, gemischt</span>`;
 el.style.color='';
}
function fillMAs(d){
 const m=d.mas||{}, a=$('kpi_ma50w'), b=$('kpi_ma200d'); if(!a||!b) return;
 const all=`MA 50 T ${m.ma50d?px(m.ma50d):'—'} · MA 200 T ${m.ma200d?px(m.ma200d):'—'}\\nMA 50 W ${m.ma50w?px(m.ma50w):'—'} · MA 200 W ${m.ma200w?px(m.ma200w):'—'}`
  +`\\n${m.days} Tageskerzen, ${m.weeks} Wochen · Quelle ${m.source||'—'}`
  +(m.cross?`\\n${m.cross==='golden'?'Golden Cross (MA50 T über MA200 T)':'Death Cross (MA50 T unter MA200 T)'}`:'');
 const set=(el,v,dist)=>{ if(v==null){el.textContent='—';el.style.color='';el.title=all+'\\nZu wenig Tageskerzen — hl_binance.py --backfill-daily';return;}
  el.innerHTML=px(v)+' <span class="d">'+(dist>=0?'▲':'▼')+' '+(Math.abs(dist)*100).toFixed(1)+' %</span>';
  el.style.color=dist>=0?'#3ba55d':'#e04b4b'; el.title=all+`\\nKurs ${dist>=0?'über':'unter'} dem Durchschnitt (${(dist*100).toFixed(2)} %)`; };
 set(a,m.ma50w,m.ma50w_dist); set(b,m.ma200d,m.ma200d_dist);
}
function fillIndicators(d){
 fillMAs(d); fillBudget(d);
 const t=$('kpi_trend'), r=$('kpi_rsi'), l=$('kpi_rsi_lbl');
 if(!t||!r) return;
 if(d.trend_60m==null){t.textContent='—';t.style.color='';}
 else{const v=d.trend_60m*100;
  t.textContent=(v>=0?'▲ +':'▼ ')+v.toFixed(2)+' %';
  t.style.color=Math.abs(v)<0.15?'#c9d1d9':v>0?'#3ba55d':'#e04b4b';}
 if(d.rsi14==null){r.textContent='—';r.style.color='';}
 else{const v=d.rsi14; r.textContent=v.toFixed(1);
  r.style.color=v>=70?'#e04b4b':v<=30?'#3ba55d':'#c9d1d9';
  r.title=v>=70?'überkauft':v<=30?'überverkauft':'neutral';}
 if(l) l.textContent='RSI 14 · '+(d.rsi_tf||'');
}
function fit(c){
 // Höhe immer aus dem HTML-Attribut ableiten. Vorher wurde c.height bei jedem
 // Zeichnen erneut mit der Pixeldichte multipliziert -- auf Handys (Dichte 2-3)
 // wuchs der Chart damit alle 5 s um den Faktor der Dichte.
 const d=EXPORT_DPR||devicePixelRatio||1;
 // Basis-Höhe EINMAL aus dem HTML-Attribut nehmen und in data-h0 merken:
 // c.height=... schreibt das Attribut zurück, sonst wächst es mit jeder Zeichnung.
 if(!c.dataset.h0) c.dataset.h0=c.getAttribute('height')||'400';
 const base=+(innerWidth<700&&c.dataset.hm?c.dataset.hm:c.dataset.h0)||400;
 const r=c.getBoundingClientRect();
 if(r.width===0){ return [c.getContext('2d'),0,base]; }   // eingeklappter Abschnitt: nichts zu zeichnen
 c.style.height=base+'px';
 c.width=Math.round(r.width*d); c.height=Math.round(base*d);
 const x=c.getContext('2d'); x.setTransform(d,0,0,d,0,0);
 return [x,r.width,base];}
function fmt(n){ if(n<0) return '-'+fmt(-n);   // negative Werte (PnL) mit Vorzeichen, gleiche Einheiten
 return n>=1e9?(n/1e9).toFixed(2)+' Mrd':n>=1e6?(n/1e6).toFixed(1)+' Mio'
 :n>=1e3?(n/1e3).toFixed(0)+'k':(+n).toFixed(0);}
function px(n){return n>=1000?n.toLocaleString('de-DE',{maximumFractionDigits:2})
 :(+n).toFixed(4);}
function hm(ts){const d=new Date(ts*1000);
 return String(d.getDate()).padStart(2,'0')+'.'+String(d.getMonth()+1).padStart(2,'0')
  +'. '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');}
function dmy(ts){const d=new Date(ts*1000);
 return String(d.getDate()).padStart(2,'0')+'.'+String(d.getMonth()+1).padStart(2,'0')+'.'+String(d.getFullYear()).slice(2);}
// Zeitbeschriftung passend zum Raster: bei Tagen und Wochen nur das Datum
function tlabel(ts){ return (LAST_CHART&&LAST_CHART.agg>=1440)?dmy(ts):hm(ts); }

// Farbverlauf dunkelblau -> blau -> cyan -> gelb -> weiss.
// Der dunkle Fuss ist entscheidend: ohne ihn leuchtet die ganze Flaeche.
const RAMP=[[0,4,10,32],[.22,10,40,140],[.45,0,150,200],
            [.68,60,220,180],[.85,255,214,10],[1,255,255,235]];
function heatColor(p){
 for(let i=1;i<RAMP.length;i++){
  if(p<=RAMP[i][0]){const a=RAMP[i-1],b=RAMP[i],t=(p-a[0])/(b[0]-a[0]||1);
   return [Math.round(a[1]+(b[1]-a[1])*t),Math.round(a[2]+(b[2]-a[2])*t),
           Math.round(a[3]+(b[3]-a[3])*t)];}}
 return [255,255,235];
}
// Perzentil-Zuordnung: entscheidend ist der Rang unter allen Zellen.
function makeScale(values){
 const v=values.filter(x=>x>0); if(!v.length) return null;
 const step=Math.max(1,Math.floor(v.length/20000)), s=[];
 for(let i=0;i<v.length;i+=step) s.push(v[i]);
 s.sort((a,b)=>a-b);
 const BINS=256, brk=new Float64Array(BINS);
 for(let i=0;i<BINS;i++) brk[i]=s[Math.min(s.length-1,Math.floor(i/BINS*s.length))];
 return {brk,min:s[0],max:s[s.length-1],
  pct(x){let lo=0,hi=BINS-1; if(x<=this.brk[0])return 0;
   while(lo<hi){const m=(lo+hi+1)>>1; if(this.brk[m]<=x)lo=m;else hi=m-1;}
   return lo/(BINS-1);}};
}

function drawChart(d){
 const [g,W,H]=fit($('chart')); g.clearRect(0,0,W,H);
 if(!d||!d.candles.length){g.fillStyle='#8b949e';
  g.fillText('noch keine Kursdaten — der Recorder muss erst laufen',12,24);return;}
 const C=d.candles, L=(d.levels||[]);
 const narrow=W<600, R=narrow?56:68,Lm=8,T=12,B=26, pw=W-Lm-R, ph=H-T-B;
 let lo=Math.min(...C.map(c=>c.l)), hi=Math.max(...C.map(c=>c.h));
 L.forEach(l=>{if(Math.abs(l.dist)<0.035){lo=Math.min(lo,l.px);hi=Math.max(hi,l.px);}});
 { const M0=d.mas||{}, p0=C[C.length-1].c;
   ['ma50w','ma200d','ma50d','ma200w'].forEach(k=>{const v=M0[k]; if(v&&Math.abs(v/p0-1)<0.035){lo=Math.min(lo,v);hi=Math.max(hi,v);}});
   const K0=keyLevels(d)||{}; Object.keys(KEY_STYLE).forEach(k=>{const s=K0[k]; if(s&&Math.abs(s.px/p0-1)<0.035){lo=Math.min(lo,s.px);hi=Math.max(hi,s.px);}}); }
 if(SIGNAL&&SIGNAL.zone){const z=SIGNAL.zone, p0=C[C.length-1].c;
  if(Math.abs(z.bot/p0-1)<0.035&&Math.abs(z.top/p0-1)<0.035){lo=Math.min(lo,z.bot);hi=Math.max(hi,z.top);}}
 const pad=(hi-lo)*0.08||1; lo-=pad; hi+=pad;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 const cw=Math.max(1.5,pw/C.length), bw=Math.max(1,cw*0.62);
 const FV=FVG_ON?(d.fvgs||[]):[];
 GEO.chart={C,L,Lm,T,pw,ph,cw,lo,hi,H,B,R,W,FV};

 g.strokeStyle='#161b22';g.lineWidth=1;
 for(let k=0;k<=5;k++){const y=T+ph*k/5;g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();}

 // Fair Value Gaps: von der mittleren Kerze bis zur Füllung, sonst bis zum Rand
 FV.forEach(f=>{const x0=Lm+f.i*cw, x1=f.fill_i!=null?Lm+f.fill_i*cw+cw:W-R;
  const y0=Y(f.top), y1=Y(f.bot); if(y1<T||y0>H-B) return;
  const open=f.fill_i==null, a=open?0.28:0.09;
  g.fillStyle=f.kind==='bull'?`rgba(57,255,20,${a})`:`rgba(224,75,75,${a})`;
  g.fillRect(x0,Math.max(T,y0),Math.max(1,x1-x0),Math.min(H-B,y1)-Math.max(T,y0));
  if(open){g.strokeStyle=f.kind==='bull'?'rgba(57,255,20,.95)':'rgba(224,75,75,.7)';
   g.lineWidth=1;g.setLineDash([2,3]);g.strokeRect(x0,y0,x1-x0,y1-y0);g.setLineDash([]);
   // Teilfüllung als Balken an der Innenkante
   if(f.fill_pct>0){g.fillStyle='rgba(255,255,255,.12)';
    const fh=(y1-y0)*f.fill_pct; g.fillRect(x0,f.kind==='bull'?y0:y1-fh,x1-x0,fh);}}});

 // Eingetretene Liquidationen als Marker (Binance orange, Hyperliquid magenta) -- Binance- und Fusionsmodus
 if(d.liq_marks&&d.liq_marks.length){ const t0=C[0].t, t1=C[C.length-1].t, step=C.length>1?(C[1].t-C[0].t):60;
  d.liq_marks.forEach(m=>{ const [t,p,usd,side,src]=m; if(t<t0||t>t1+step) return;
   const i=Math.min(C.length-1,Math.floor((t-t0)/step)), x=Lm+i*cw+cw/2, y=Y(p); if(y<T||y>H-B) return;
   g.fillStyle=src==='bnc'?'rgba(255,159,67,0.9)':'rgba(255,59,107,0.9)';
   g.beginPath(); if(side==='long'){ g.moveTo(x-3,y-3); g.lineTo(x+3,y-3); g.lineTo(x,y+3);} else { g.moveTo(x-3,y+3); g.lineTo(x+3,y+3); g.lineTo(x,y-3);} g.closePath(); g.fill(); }); }

 // Kaskadenprognose: Auslöser (orange, gestrichelt) und Ziel (orange, gepunktet) je Richtung, wenn der Auslöser innerhalb 3 % liegt
 if(LAST_CASCADE&&d.price){ for(const dir of ['down','up']){ const C=LAST_CASCADE[dir]; if(!C) continue; if(Math.abs(C.trigger.px/d.price-1)>0.03) continue;
  const yT=Y(C.trigger.px), yZ=Y(C.target.px); g.strokeStyle='rgba(255,159,67,0.9)'; g.lineWidth=1.2;
  if(yT>T&&yT<H-B){ g.setLineDash([6,3]); g.beginPath(); g.moveTo(Lm,yT); g.lineTo(W-R,yT); g.stroke(); g.setLineDash([]);
   g.fillStyle='#ff9f43'; g.font='bold 10px system-ui'; g.textAlign='left'; g.fillText(`KASKADE ${dir==='down'?'▼':'▲'} ab ${px(C.trigger.px)} · ${C.type}`, Lm+6, yT+(dir==='down'?12:-4)); }
  if(yZ>T&&yZ<H-B){ g.setLineDash([2,3]); g.beginPath(); g.moveTo(Lm,yZ); g.lineTo(W-R,yZ); g.stroke(); g.setLineDash([]);
   g.fillStyle='#ff9f43'; g.font='10px system-ui'; g.fillText(`Ziel ≈ ${px(C.target.px)} (Druck ${fmt(C.target.cumP)} / Aufnahme ${fmt(C.target.cumA)})`, Lm+6, yZ+(dir==='down'?12:-4)); } } }

 // Gleitende Durchschnitte als waagerechte Linien, sofern im Preisbereich
 const M=d.mas||{};
 [['ma50w','MA 50 W','#e3b341'],['ma200d','MA 200 T','#a371f7'],['ma50d','MA 50 T','#79c0ff'],['ma200w','MA 200 W','#f778ba']].forEach(([k,lab,col])=>{
  const v=M[k]; if(!v) return; const y=Y(v); if(y<T||y>H-B) return;
  g.strokeStyle=col; g.lineWidth=1.2; g.setLineDash([6,4]); g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
  g.fillStyle=col; g.font='bold 10px system-ui'; g.fillText(lab+' '+px(v), Lm+6, y-3);});

 // Schlüsselniveaus aus den Orders der Großkonten: Support, Resistance, Take-Profits, Stops
 { const K=keyLevels(d)||{}; let usedY=[];
   Object.entries(KEY_STYLE).forEach(([k,[label,color]])=>{ const s=K[k]; if(!s) return; const y=Y(s.px); if(y<T||y>H-B) return;
    g.strokeStyle=color; g.lineWidth=k==='support'||k==='resistance'?2:1.2; g.setLineDash(k.startsWith('stop')?[3,3]:k.startsWith('tp')?[8,4]:[]);
    g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
    // Beschriftung links, ohne Kollision
    let ly=y-4; while(usedY.some(u=>Math.abs(u-ly)<11)) ly-=11; usedY.push(ly);
    const txt=label+' '+px(s.px)+' · '+fmt(s.notional); g.font='bold 10px system-ui';
    const tw=g.measureText(txt).width+8; g.fillStyle='rgba(13,17,23,0.85)'; g.fillRect(Lm+4,ly-9,tw,12);
    g.fillStyle=color; g.fillText(txt, Lm+8, ly); }); }

 // Konfluenz-Zone: ein AKTUELLES Fenster -- Kasten am rechten Rand über die
 // letzten Kerzen, nicht ein Band über die ganze Historie
 if(SIGNAL&&SIGNAL.zone){const z=SIGNAL.zone, y0=Y(z.top), y1=Y(z.bot);
  if(y1>T&&y0<H-B){const c=z.kind==='buy'?'57,255,20':'224,75,75';
   const zw=Math.max(cw*10, pw*0.09), x0=W-R-zw, x1=W-R;
   const yy0=Math.max(T,y0), yy1=Math.min(H-B,y1);
   g.fillStyle=`rgba(${c},0.22)`; g.fillRect(x0,yy0,zw,yy1-yy0);
   g.strokeStyle=`rgba(${c},0.95)`; g.lineWidth=2; g.strokeRect(x0,yy0,zw,yy1-yy0);
   // linke Kante als Beginn des Fensters betonen
   g.fillStyle=`rgba(${c},0.9)`; g.fillRect(x0-1,yy0,3,yy1-yy0);
   const label=(z.kind==='buy'?'KAUFZONE':'VERKAUFSZONE'), sub=z.text;
   g.font='bold 11px system-ui'; const lw=Math.max(g.measureText(label).width,g.measureText(sub).width)+12;
   const lx=Math.max(Lm, x1-lw), ly=(z.kind==='buy'? Math.max(T+2, yy0-30) : Math.min(H-B-30, yy1+4));
   g.fillStyle='rgba(13,17,23,0.85)'; g.fillRect(lx,ly,lw,28);
   g.strokeStyle=`rgba(${c},0.95)`; g.lineWidth=1; g.strokeRect(lx,ly,lw,28);
   g.fillStyle=`rgb(${c})`; g.fillText(label, lx+6, ly+12);
   g.font='10px system-ui'; g.fillStyle='#c9d1d9'; g.fillText(sub, lx+6, ly+24);}}
 const mxN=Math.max(...L.map(l=>l.notional),1);
 L.forEach(l=>{const y=Y(l.px); if(y<T||y>H-B)return;
  const a=0.25+0.65*(l.notional/mxN);
  g.strokeStyle=l.side==='long'?`rgba(224,75,75,${a})`:`rgba(59,165,93,${a})`;
  g.lineWidth=l.x_vol>=0.5?2:1; g.setLineDash(l.x_vol>=0.5?[]:[3,3]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle=l.side==='long'?'#e04b4b':'#3ba55d';g.font='9px system-ui';
  g.fillText(fmt(l.notional),W-R+3,y-2);
  g.fillStyle='#6e7681';g.fillText((l.dist*100).toFixed(1)+'%',W-R+3,y+8);});
 C.forEach((c,i)=>{const x=Lm+i*cw+cw/2, up=c.c>=c.o;
  g.strokeStyle=up?'#3ba55d':'#e04b4b'; g.fillStyle=g.strokeStyle; g.lineWidth=1;
  g.beginPath();g.moveTo(x,Y(c.h));g.lineTo(x,Y(c.l));g.stroke();
  const y1=Y(Math.max(c.o,c.c)),y2=Y(Math.min(c.o,c.c));
  g.fillRect(x-bw/2,y1,bw,Math.max(1,y2-y1));});
 if(d.price){const y=Y(d.price);
  g.strokeStyle='#00e5ff';g.lineWidth=1;g.setLineDash([5,4]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle='#00e5ff';g.fillRect(W-R,y-7,R,14);
  g.fillStyle='#010409';g.font='bold 10px system-ui';g.fillText(px(d.price),W-R+3,y+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 for(let k=0;k<4;k++){const i=Math.floor(k/3*(C.length-1));
  g.fillText(tlabel(C[i].t), Lm+i*cw, H-8);}
 g.fillText('Preis (USD) rechts · Zeit unten', Lm, T+10);
 const te=(d.tick_events||[]);
 const openF=FV.filter(f=>f.fill_i==null);
 const nearest=openF.slice().sort((a,b)=>Math.abs(a.dist)-Math.abs(b.dist))[0];
 const fvtxt=FV.length?` · <b>FVG:</b> ${openF.length} offen (${openF.filter(f=>f.kind==='bull').length} bull / `
   +`${openF.filter(f=>f.kind==='bear').length} bear), ${FV.length-openF.length} gefüllt`
   +(nearest?` · nächstes ${nearest.kind} ${px(nearest.bot)}–${px(nearest.top)} `
     +`(${(nearest.dist*100).toFixed(2)} %, ${(nearest.fill_pct*100).toFixed(0)} % gefüllt)`:''):'';
 $('chartinfo').innerHTML=(d.agg>=240?`Quelle: ${d.source} · `:'')+`${C.length} Kerzen · ${L.length} Liquidationsmarken`
  +` · Stundenvolumen ${fmt(d.vol_1h||0)} USD`+fvtxt
  +(te.length?`<br><b>Tick-Aufzeichnungen:</b> `+te.map(e=>
    `${hm(e.t_trigger/1000)} <span style="color:${e.move_pct<0?'#e04b4b':'#3ba55d'}">`
    +`${(e.move_pct*100).toFixed(2)} %</span> (${e.reason}, ${e.n_ticks.toLocaleString('de-DE')} Ticks, `
    +`${e.n_liqs} Liqs)`).join(' · '):'');
}

function drawHeat(d){
 const [g,W,H]=fit($('heat')); g.clearRect(0,0,W,H);
 if(!d||!d.times.length||!d.price||!d.price.length){g.fillStyle='#8b949e';g.fillText('keine Daten',12,22); $('heatinfo').textContent=''; GEO.heat=null; return;}
 const P=d.price.map(p=>p[1]), lo=Math.min(...P)*0.94, hi=Math.max(...P)*1.06;
 const L=52,R=12,T=10,B=26, pw=W-L-R, ph=H-T-B;
 const t0=d.times[0], t1=d.times[d.times.length-1];
 const X=t=>L+(t-t0)/(t1-t0+1)*pw, Y=p=>T+(hi-p)/(hi-lo)*ph;
 g.fillStyle='#01030a'; g.fillRect(L,T,pw,ph);
 const flat=[]; d.grid.forEach(r=>r.forEach(v=>{if(v>0)flat.push(v)}));
 const sc=makeScale(flat), thr=(+$('thr').value)/100;
 const cw=Math.max(1.5,pw/d.times.length), chh=Math.max(1.5,ph*0.0025/((hi-lo)/hi));
 GEO.heat={d,L,T,pw,ph,lo,hi,t0,t1,sc,thr,H,B,W,R};
 let shown=0;
 d.grid.forEach((row,i)=>{const y=Y(d.levels[i]); if(y<T-4||y>H-B+4)return;
  row.forEach((v,j)=>{ if(v<=0||!sc)return;
   const p=sc.pct(v); if(p<thr)return;
   const q=Math.pow((p-thr)/(1-thr||1),2.6);
   const c=heatColor(q);
   g.fillStyle=`rgba(${c[0]},${c[1]},${c[2]},${0.35+0.65*q})`;
   g.fillRect(X(d.times[j]),y-chh/2,cw,chh); shown++;});});
 g.strokeStyle='#ffffff';g.lineWidth=1.6;g.beginPath();
 d.price.forEach((p,i)=>{const x=X(p[0]),y=Y(p[1]);i?g.lineTo(x,y):g.moveTo(x,y)});
 g.stroke();
 g.strokeStyle='#ff3b6b';g.lineWidth=1.2;
 // Eingetretene Liquidationen: die betroffene Zelle wird magenta, wie in der Legende.
 // Mehrere im selben Zeit-/Preisfeld werden zusammengefasst; die Deckkraft folgt dem Notional.
 { const cells=new Map();
   d.liqs.forEach(l=>{ const col=Math.floor((l[0]-t0)/Math.max(1,(t1-t0)/d.times.length)), row=Math.round(Math.log(l[1]/lo)/Math.log(1.0025));
     const k=col+':'+row; const c=cells.get(k)||{x:X(l[0]),y:Y(l[1]),usd:0,n:0}; c.usd+=l[2]; c.n++; cells.set(k,c); });
   cells.forEach(c=>{ if(c.y<T-4||c.y>H-B+4) return;
     const a=Math.min(1,0.45+c.usd/2e6*0.55), h=Math.max(chh,3), w=Math.max(cw,3);
     g.fillStyle=`rgba(255,59,107,${a})`; g.fillRect(Math.floor(c.x),Math.round(c.y-h/2),Math.ceil(w),Math.ceil(h));
     g.strokeStyle='#ff3b6b'; g.lineWidth=1; g.strokeRect(Math.floor(c.x)+0.5,Math.round(c.y-h/2)+0.5,Math.ceil(w),Math.ceil(h)); }); }
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=4;k++){const p=lo+(hi-lo)*k/4;g.fillText(px(p).slice(0,9),4,Y(p)+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 const nx=W<600?2:4;   // auf schmalen Bildschirmen weniger Zeitmarken, sonst überlappen sie
 for(let k=0;k<=nx;k++){const t=t0+(t1-t0)*k/nx;
  g.fillText(hm(t), Math.min(X(t),W-R-52), H-8);}
 g.fillStyle='#8b949e';g.font='9px system-ui';
 g.save();g.translate(11,T+ph/2);g.rotate(-Math.PI/2);
 g.textAlign='center';g.fillText('Preis (USD)',0,0);g.restore();
 let extra='';
 if(SRC()==='fusion'&&LAST_DATA&&LAST_DATA.bnc&&LAST_DATA.bnc.grid_liqs){
  const bl=LAST_DATA.bnc.grid_liqs; const cw2=Math.max(1.5,pw/d.times.length);
  bl.forEach(l=>{const x=X(l[0]), y=Y(l[1]); if(y<T||y>H-B||x<L||x>W-R) return;
   g.fillStyle='rgba(255,159,67,0.75)'; g.fillRect(Math.floor(x),Math.round(y-2),Math.max(cw2,3),4);});
  extra=` · Binance-Liquidationen (orange): ${bl.length}`;
 }
 $('heatinfo').textContent=(d.realized?`Eingetretene Binance-Liquidationen: ${flat.length.toLocaleString('de-DE')} Zellen · Notional je Zelle bis ${fmt(sc?sc.max:0)} USD`
  :(sc? `${shown.toLocaleString('de-DE')} von ${flat.length.toLocaleString('de-DE')} Zellen `
    +`sichtbar · unterhalb Perzentil ${Math.round(thr*100)} ausgeblendet `
    +`· Notional je Zelle ${fmt(sc.min)}–${fmt(sc.max)} USD` : ''))+extra;
}

function drawDepth(d){
 const [g,W,H]=fit($('depth')); g.clearRect(0,0,W,H);
 const di=$('depthinfo');
 if(!d||!d.rows.length){g.fillStyle='#8b949e';g.fillText(d&&d.realized?'keine eingetretenen Binance-Liquidationen im Zeitraum':'kein Snapshot',12,22);
  if(di) di.textContent=d&&d.realized?'Binance: keine eingetretenen Liquidationen in den letzten 24 h — oder hl_binance läuft nicht':''; GEO.depth=null; return;}
 const p0=d.price, rows=d.rows.filter(r=>r.bucket_px>p0*0.85&&r.bucket_px<p0*1.18);
 if(!rows.length){g.fillStyle='#8b949e';g.fillText('keine Cluster im Bereich',12,22); if(di) di.textContent=''; GEO.depth=null; return;}
 const lo=p0*0.85, hi=p0*1.18, mx=Math.max(...rows.map(r=>r.notional));
 const L=62,R=10,T=10,B=26, pw=W-L-R, ph=H-T-B;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 GEO.depth={rows,L,T,pw,ph,lo,hi,mx,p0,vol:d.vol_1h,H,B,W,R};
 rows.forEach(r=>{const w=r.notional/mx*pw, y=Y(r.bucket_px);
  g.fillStyle=r.side==='long'?'rgba(224,75,75,.85)':'rgba(59,165,93,.85)';
  g.fillRect(L,y-2,w,4);});
 if(d.vol_1h>0){const x=L+(d.vol_1h*0.5)/mx*pw;
  if(x<W-R){g.strokeStyle='#8b949e';g.setLineDash([4,4]);g.beginPath();
   g.moveTo(x,T);g.lineTo(x,H-B);g.stroke();g.setLineDash([]);
   g.fillStyle='#8b949e';g.font='9px system-ui';g.fillText('halbes Stundenvolumen',x+3,T+10);}}
 g.strokeStyle='#00e5ff';g.lineWidth=2;g.beginPath();
 g.moveTo(L,Y(p0));g.lineTo(W-R,Y(p0));g.stroke();
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=6;k++){const p=lo+(hi-lo)*k/6;g.fillText(px(p).slice(0,9),4,Y(p)+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 for(let k=0;k<=3;k++){const v=mx*k/3;g.fillText(fmt(v),L+pw*k/3,H-8);}
 g.fillText('Notional (USD)',L+pw/2-30,H-16);
 const up=rows.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
 const dn=rows.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0);
 // Fusion: eingetretene Binance-Liquidationen der letzten 24 h als Overlay (orange), NICHT addiert --
 // erwartete Cluster und eingetretene Liquidationen sind verschiedene Größen.
 let extra='';
 if(SRC()==='fusion'&&LAST_DATA&&LAST_DATA.bnc&&LAST_DATA.bnc.depth){
  const R2=LAST_DATA.bnc.depth.rows.filter(r=>r.bucket_px>lo&&r.bucket_px<hi);
  const mx2=Math.max(...R2.map(r=>r.notional),1);
  R2.forEach(r=>{const w=r.notional/mx2*pw*0.6, y=Y(r.bucket_px); g.fillStyle='rgba(255,159,67,0.7)'; g.fillRect(L,y-1.5,w,3);});
  const bl=R2.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0), bs=R2.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
  extra=` · Binance eingetreten 24 h (orange): Longs ${fmt(bl)}, Shorts ${fmt(bs)}`;
 }
 $('depthinfo').textContent=(d.realized?`Eingetretene Liquidationen (Binance, ${d.hours||24} h): ${rows.length} Preisstufen · Longs liquidiert ${fmt(dn)} USD · Shorts liquidiert ${fmt(up)} USD · Stand ${hm(d.ts)}`
  :`${rows.length} Cluster · über dem Kurs ${fmt(up)} USD · darunter ${fmt(dn)} USD · Stand ${hm(d.ts)}`)+extra;
}

function drawMetrics(m){
 const box=$('bncmetrics'); if(!box) return; if(!m||!m.series){ box.style.display='none'; return; }
 box.style.display='block';
 const c=$('metricschart'); const [g,W,H]=fit(c); g.clearRect(0,0,W,H); if(!W) return;
 const L=56,R=56,T=12,B=24, pw=W-L-R, ph=H-T-B;
 const S=m.series; const keys=[['oi_notional','#58a6ff'],['global_ls_account','#d29922'],['top_ls_position','#c678dd'],['taker_ls','#3ba55d']];
 const all=keys.flatMap(([k])=>S[k]||[]); if(!all.length){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText('noch keine Binance-Kennzahlen — kommen mit hl_binance (Backfill und alle 10 min)',12,24); return; }
 const t0=Math.min(...all.map(p=>p[0])), t1=Math.max(...all.map(p=>p[0])), X=t=>L+(t-t0)/Math.max(1,t1-t0)*pw;
 // OI links (absolut), Verhältnisse rechts (gemeinsame Skala um 1)
 const oi=S.oi_notional||[]; const ratios=keys.slice(1).flatMap(([k])=>S[k]||[]).map(p=>p[1]);
 const rlo=Math.min(0.5,...ratios), rhi=Math.max(1.5,...ratios);
 const Yr=v=>T+(rhi-v)/(rhi-rlo)*ph;
 g.strokeStyle='#161b22'; for(let k=0;k<=4;k++){const y=T+ph*k/4; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 g.strokeStyle='#30363d'; g.setLineDash([3,3]); g.beginPath(); g.moveTo(L,Yr(1)); g.lineTo(W-R,Yr(1)); g.stroke(); g.setLineDash([]);
 if(oi.length){ const lo=Math.min(...oi.map(p=>p[1])), hi=Math.max(...oi.map(p=>p[1])); const Yo=v=>T+(hi-v)/Math.max(1e-9,hi-lo)*ph;
  g.strokeStyle='#58a6ff'; g.lineWidth=1.6; g.beginPath(); oi.forEach((p,i)=>i?g.lineTo(X(p[0]),Yo(p[1])):g.moveTo(X(p[0]),Yo(p[1]))); g.stroke();
  g.fillStyle='#58a6ff'; g.font='10px system-ui'; g.textAlign='right'; g.fillText(fmt(hi),L-4,T+8); g.fillText(fmt(lo),L-4,H-B); g.textAlign='left'; }
 keys.slice(1).forEach(([k,col])=>{ const ser=S[k]||[]; if(!ser.length) return; g.strokeStyle=col; g.lineWidth=1.4; g.beginPath();
  ser.forEach((p,i)=>i?g.lineTo(X(p[0]),Yr(p[1])):g.moveTo(X(p[0]),Yr(p[1]))); g.stroke(); });
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='left';
 [rhi,1,rlo].forEach(v=>g.fillText(v.toFixed(2),W-R+4,Yr(v)+3));
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(t0),L,H-8); g.textAlign='right'; g.fillText(hm(t1),W-R,H-8); g.textAlign='left';
 const l=m.latest||{};
 $('metricsinfo').innerHTML=`Binance-Kennzahlen · Open Interest ${l.oi_notional?fmt(l.oi_notional)+' USD':'—'} · L/S Konten ${l.global_ls_account?(+l.global_ls_account).toFixed(2):'—'} `
  +`· L/S Top-Trader ${l.top_ls_position?(+l.top_ls_position).toFixed(2):'—'} · Taker ${l.taker_ls?(+l.taker_ls).toFixed(2):'—'} — Verhältnisse rechts skaliert, 1,00 = ausgeglichen (gestrichelt)`
  +(LAST_CHART&&LAST_CHART.cdc?` · Crypto.com: OI ${fmt(LAST_CHART.cdc.oi_usd||0)} USD, Taker ${LAST_CHART.cdc.taker_ls!=null?(+LAST_CHART.cdc.taker_ls).toFixed(2):'—'}, Prämie ${LAST_CHART.cdc.premium!=null?(LAST_CHART.cdc.premium*100).toFixed(3)+' %':'—'}`:'')
  +` · <a class="lbl-links" style="cursor:pointer" onclick="exportChart('metricschart')">⤓ PNG</a>`;
}

function drawWhales(d){
 const [g,W,H]=fit($('whalechart')); g.clearRect(0,0,W,H);
 const E=d.exposure||[], P=d.price||[], coin=$('coin').value;
 const C=d.current||[];
 if(!E.length){g.fillStyle='#8b949e';g.font='12px system-ui';
  g.fillText(C.length
   ? `Zeitreihe für ${coin} entsteht mit den nächsten Snapshots — die Tabelle unten ist schon gefüllt`
   : 'noch keine Wal-Positionen erfasst — Wale ab 20 Mio. USD erscheinen hier, sobald der Recorder sie findet',12,24);
  drawWhaleTable(d); return;}
 const L=8,R=64,T=10,B=24, pw=W-L-R, ph=H-T-B;
 const t0=E[0].ts, t1=E[E.length-1].ts;
 const X=t=>L+(t-t0)/(t1-t0+1)*pw;
 const mxE=Math.max(...E.map(e=>Math.max(e.long_usd,e.short_usd)),1);
 const Ye=v=>T+ph/2-v/mxE*(ph/2-4);
 // Exposure als gespiegelte Flaechen um die Mittellinie
 g.fillStyle='rgba(59,165,93,.55)'; g.beginPath(); g.moveTo(X(t0),Ye(0));
 E.forEach(e=>g.lineTo(X(e.ts),Ye(e.long_usd))); g.lineTo(X(t1),Ye(0)); g.fill();
 g.fillStyle='rgba(224,75,75,.55)'; g.beginPath(); g.moveTo(X(t0),Ye(0));
 E.forEach(e=>g.lineTo(X(e.ts),Ye(-e.short_usd))); g.lineTo(X(t1),Ye(0)); g.fill();
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(L,Ye(0)); g.lineTo(W-R,Ye(0)); g.stroke();
 // Kurs auf eigener Skala rechts
 if(P.length){const pv=P.map(p=>p[1]), plo=Math.min(...pv), phi=Math.max(...pv);
  const Yp=p=>T+(phi-p)/(phi-plo||1)*ph;
  g.strokeStyle='#fff';g.lineWidth=1.3;g.beginPath();
  P.forEach((p,i)=>{const x=X(p[0]),y=Yp(p[1]); if(x<L||x>W-R)return; i?g.lineTo(x,y):g.moveTo(x,y)});
  g.stroke();
  g.fillStyle='#8b949e';g.font='9px system-ui';
  g.fillText(px(phi),W-R+3,T+9); g.fillText(px(plo),W-R+3,T+ph);
  // Ereignismarker
  (d.events||[]).forEach(ev=>{const x=X(ev.ts); if(x<L||x>W-R)return;
   const up=ev.event==='open'||ev.event==='add'||(ev.event==='flip');
   const near=P.reduce((a,b)=>Math.abs(b[0]-ev.ts)<Math.abs(a[0]-ev.ts)?b:a);
   const y=Yp(near[1]);
   g.fillStyle=ev.side==='long'?'#3ba55d':'#e04b4b';
   g.beginPath(); if(up){g.moveTo(x,y-9);g.lineTo(x-5,y-1);g.lineTo(x+5,y-1);}
   else{g.moveTo(x,y+9);g.lineTo(x-5,y+1);g.lineTo(x+5,y+1);} g.fill();});}
 g.fillStyle='#8b949e';g.font='9px system-ui';
 g.fillText('+'+fmt(mxE),L+2,T+9); g.fillText('-'+fmt(mxE),L+2,T+ph-2);
 g.fillStyle='#6e7681'; g.fillText(hm(t0),L,H-8); g.fillText(hm(t1),W-R-60,H-8);
 drawWhaleTable(d);
}

let LABELS={}, LABELS_AT=0, LB_TABLE_KEY='', LBACT_KEY='', LAST_CASCADE=null;
async function loadLabels(addrs){
 if(!addrs.length) return;
 try{ const r=await getJSON('/labels?addrs='+addrs.slice(0,200).join(',')); LABELS=Object.assign(LABELS,r); LABELS_AT=Date.now();
  if(LAST_WHALES) drawWhaleTable(LAST_WHALES, true); }catch(e){}
}
let WH_TABLE_KEY='';
function drawWhaleTable(d, force){
 const C=d.current||[], coin=$('coin').value;
 const need=[...new Set(C.map(w=>w.addr.toLowerCase()))].filter(a=>!LABELS[a]||LABELS[a].pending);
 if(need.length&&Date.now()-LABELS_AT>15000){ LABELS_AT=Date.now(); loadLabels(need); }
 // nur neu bauen, wenn sich der Stand geändert hat -- sonst springt die Seite beim Lesen
 const key=coin+'|'+C.length+'|'+Math.max(0,...C.map(w=>w.ts||0))+'|'+Object.keys(LABELS).length+'|'+Object.values(LABELS).filter(l=>l&&l.name).length;
 if(!force&&key===WH_TABLE_KEY) return; WH_TABLE_KEY=key;
 const short=a=>a.slice(0,6)+'…'+a.slice(-4);
 const age=s=>{const h=(Date.now()/1000-s)/3600; return h<1?Math.round(h*60)+' min':h<48?h.toFixed(1)+' h':(h/24).toFixed(1)+' T';};
 // Nach Wallet gruppiert: alle Positionen einer Adresse als Block, Wallets nach Gesamtwert,
 // innerhalb des Blocks nach Positionswert. Der Blockkopf nennt Summe und Netto-Ausrichtung.
 const groups=new Map();
 C.forEach(w=>{ const g=groups.get(w.addr)||{addr:w.addr,rows:[],total:0,long:0,short:0,upnl:0};
   g.rows.push(w); g.total+=w.pos_value||0; g.upnl+=w.upnl||0; if(w.side==='long') g.long+=w.pos_value||0; else g.short+=w.pos_value||0; groups.set(w.addr,g); });
 const ordered=[...groups.values()].sort((a,b)=>b.total-a.total);
 ordered.forEach(g=>g.rows.sort((a,b)=>(b.pos_value||0)-(a.pos_value||0)));
 const head=g=>{ const net=g.long-g.short, col=net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9';
   const L=(LABELS||{})[g.addr.toLowerCase()]||{};
   const name=L.name?`<span class="lbl-name" title="${(L.source||'').replace(/"/g,'&quot;')}">${L.name}</span>`:(L.pending?'<span class="lbl-dim">Zuordnung läuft …</span>':'<span class="lbl-dim">unbekannt</span>');
   const beh=L.behavior?` <span class="lbl-beh" title="Verhaltensklasse aus den eigenen Daten">${L.behavior}</span>`:'';
   const links=L.links?` <span class="lbl-links"><a href="${L.links.hypurrscan}" target="_blank" rel="noopener">HypurrScan</a> · <a href="${L.links.arbiscan}" target="_blank" rel="noopener">Arbiscan</a> · <a href="${L.links.arkham}" target="_blank" rel="noopener">Arkham</a></span>`:'';
   return `<tr class="grp"><td class="mono" colspan="3"><b>${short(g.addr)}</b> · ${g.rows.length} Position${g.rows.length>1?'en':''}<br>${name}${beh}${links}</td>`
    +`<td class="n"><b>${fmt(g.total)}</b></td><td colspan="4" style="color:${col}">netto ${net>0?'long':net<0?'short':'neutral'} ${fmt(Math.abs(net))}</td>`
    +`<td class="n" style="color:${g.upnl>=0?'#3ba55d':'#e04b4b'}">${g.upnl>=0?'+':''}${fmt(g.upnl)}</td><td colspan="2"></td></tr>`; };
 $('whaletable').innerHTML=C.length?`<table class="w"><tr>
  <th>Wallet</th><th>Coin</th><th>Seite</th><th class="n">Wert</th><th class="n">Hebel</th>
  <th class="n">Einstieg</th><th class="n">Liq.-Preis</th><th class="n">Abstand</th>
  <th class="n">unreal. PnL</th><th>offen seit</th><th>Stand</th></tr>`
  +ordered.map(g=>head(g)+g.rows.map(w=>{const dist=w.mark_px?(w.liq_px-w.mark_px)/w.mark_px*100:0;
   const dc=Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':'#c9d1d9';
   const hl=w.coin===coin?' style="background:#161b22"':'';
   return `<tr${hl}><td class="mono" style="color:#6e7681;padding-left:18px">${g.rows.length>1?'└':''} ${short(w.addr)}</td>
    <td><b>${w.coin}</b></td>
    <td style="color:${w.side==='long'?'#3ba55d':'#e04b4b'}">${w.side}</td>
    <td class="n"><b>${fmt(w.pos_value)}</b></td><td class="n">${(+w.leverage).toFixed(0)}x</td>
    <td class="n">${px(w.entry_px)}</td><td class="n">${px(w.liq_px)}</td>
    <td class="n" style="color:${dc}">${dist>0?'+':''}${dist.toFixed(1)} %</td>
    <td class="n" style="color:${w.upnl>=0?'#3ba55d':'#e04b4b'}">${w.upnl>=0?'+':''}${fmt(w.upnl)}</td>
    <td>${w.opened_at?age(w.opened_at):'—'}</td><td class="mono">${age(w.ts)} alt</td></tr>`}).join('')).join('')
  +'</table>':'<div class="sub">Aktuell keine offene Position über der Schwelle.</div>';
 const other=C.filter(w=>w.coin!==coin).length;
 if(C.length&&!C.some(w=>w.coin===coin))
  $('whaletable').innerHTML=`<div class="sub" style="margin-bottom:6px">Kein Wal in ${coin} — `
   +`die ${other} unten halten ihre großen Positionen in anderen Coins.</div>`+$('whaletable').innerHTML;

 const ev=(d.events||[]).slice(-12).reverse();
 const name={open:'eröffnet',add:'stockt auf',reduce:'reduziert',close:'schließt',flip:'dreht auf'};
 const PC=(d.flow&&d.flow.per_coin)||{}, NM=(d.flow&&d.flow.group_names)||{};
 const grp=a=>(PC[a.toLowerCase()]||'dir');
 const cls=a=>NM[grp(a)]||((LABELS||{})[a.toLowerCase()]||{}).behavior||'';
 const isDir=a=>grp(a)==='dir';
 const GCOL={dir:null, hedge:'#8b949e', mm:'#8b949e', mixed:'#c9a227'};
 const F=d.flow||{}; const w=F.w30||{}, w60=F.w60||{};
 $('whaleevents').innerHTML=(F.w30?`<div class="sub" style="margin:0 0 6px"><b>Wal-Flow live</b> (nur direktionale Wale): 30 min <span style="color:${w.net_usd>0?'#3ba55d':w.net_usd<0?'#e04b4b':'#c9d1d9'}">${w.net_usd>=0?'+':'−'}${fmt(Math.abs(w.net_usd||0))}</span> (${w.n_buy||0} kaufen / ${w.n_sell||0} verkaufen) · 60 min <span style="color:${w60.net_usd>0?'#3ba55d':w60.net_usd<0?'#e04b4b':'#c9d1d9'}">${w60.net_usd>=0?'+':'−'}${fmt(Math.abs(w60.net_usd||0))}</span> (${w60.n_buy||0}/${w60.n_sell||0})${F.z30!=null?' · Z '+F.z30.toFixed(1):''}${F.event_signal?' · <span style="color:#ff9f43">⚡ Ereignis-Signal</span>':''} — jede Änderung eines direktionalen Wals löst binnen 30 s eine neue Prognose aus</div>`:'')
  +(ev.length?'<b>Letzte Änderungen:</b> <span class="lbl-dim">(Klasse je Coin — jede Gruppe wird eigenständig ausgewertet)</span><br>'+ev.map(e=>{ const g=grp(e.addr), dir=g==='dir', c=cls(e.addr), dim=GCOL[g];
   return `<span style="${dim?'color:'+dim:''}">${hm(e.ts)} · <span class="mono">${short(e.addr)}</span> ${name[e.event]||e.event} `
  +`<span style="color:${dir?(e.side==='long'?'#3ba55d':'#e04b4b'):(dim||'#6e7681')}">${e.side}</span> `
  +`${e.delta_usd>=0?'+':''}${fmt(e.delta_usd)} USD bei ${px(e.mark_px)}${c?` <span class="lbl-beh">${c.split(' (')[0]}</span>`:''}</span>`; }).join('<br>')
  :'noch keine Änderungen im Zeitraum');
}

// ---- Tooltip -------------------------------------------------------------
function showTip(ev, title, rows){
 const t=$('tip');
 t.innerHTML=`<div class="t">${title}</div>`+rows.map(
  r=>`<div class="r"><i>${r[0]}</i><b style="color:${r[2]||'#c9d1d9'}">${r[1]}</b></div>`).join('');
 t.style.display='block';
 const w=t.offsetWidth,h=t.offsetHeight;
 let x=ev.clientX+14, y=ev.clientY-h-10;
 if(x+w>innerWidth-8) x=ev.clientX-w-14;
 if(y<8) y=ev.clientY+18;
 // auf schmalen Bildschirmen: nie über den Rand hinaus, unter dem Finger platzieren
 x=Math.max(6, Math.min(x, innerWidth-w-6));
 if(innerWidth<700){ y=ev.clientY+24; if(y+h>innerHeight-8) y=ev.clientY-h-24; }
 t.style.left=x+'px'; t.style.top=y+'px';
}
function hideTip(){ $('tip').style.display='none'; }

function pos(ev,c){const r=c.getBoundingClientRect();
 return {x:ev.clientX-r.left, y:ev.clientY-r.top};}

function tipHeat(ev){
 const G=GEO.heat; if(!G) return hideTip();
 const {x,y}=pos(ev,$('heat'));
 if(x<G.L||x>G.L+G.pw||y<G.T||y>G.T+G.ph) return hideTip();
 if(LAST){ drawHeat(LAST); crosshair($('heat'),G,x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const d=G.d;
 const t=G.t0+(x-G.L)/G.pw*(G.t1-G.t0);
 let j=0,best=1e18; d.times.forEach((tt,k)=>{const e=Math.abs(tt-t);if(e<best){best=e;j=k}});
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 let i=0,bp=1e18; d.levels.forEach((lv,k)=>{const e=Math.abs(lv-p);if(e<bp){bp=e;i=k}});
 const v=d.grid[i][j], side=d.sides[i]?d.sides[i][j]:'';
 const pr=d.price.reduce((a,b)=>Math.abs(b[0]-t)<Math.abs(a[0]-t)?b:a);
 const rows=[['Zeit',hm(d.times[j])],['Preisniveau',px(d.levels[i])+' USD'],
             ['Kurs damals',px(pr[1])+' USD']];
 if(v>0){
  rows.push(['Notional',fmt(v)+' USD']);
  if(G.sc) rows.push(['Rang',(G.sc.pct(v)*100).toFixed(0)+'. Perzentil']);
  if(side) rows.push(['Art', side==='long'?'Long-Liquidationen':'Short-Liquidationen',
                      side==='long'?'#e04b4b':'#3ba55d']);
 } else rows.push(['Notional','kein Cluster','#6e7681']);
 showTip(ev,'Heatmap',rows);
}

function tipChart(ev){
 const G=GEO.chart; if(!G) return hideTip();
 const {x,y}=pos(ev,$('chart'));
 if(x<G.Lm||x>G.Lm+G.pw||y<G.T||y>G.T+G.ph) return hideTip();
 if(LAST_CHART){ drawChart(LAST_CHART); crosshair($('chart'),{L:G.Lm,R:G.R,T:G.T,B:G.B,W:G.W,H:G.H},x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const i=Math.max(0,Math.min(G.C.length-1,Math.floor((x-G.Lm)/G.cw)));
 const c=G.C[i];
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 const rows=[['Eröffnung',px(c.o)],['Hoch',px(c.h)],['Tief',px(c.l)],
             ['Schluss',px(c.c),c.c>=c.o?'#3ba55d':'#e04b4b'],
             ['Volumen',fmt(c.v)]];
 const near=G.L.filter(l=>Math.abs(l.px-p)/p<0.004)
             .sort((a,b)=>Math.abs(a.px-p)-Math.abs(b.px-p))[0];
 if(near) rows.push(['Marke '+px(near.px),fmt(near.notional)+' USD · '
   +near.x_vol.toFixed(2)+'x Vol', near.side==='long'?'#e04b4b':'#3ba55d']);
 const inGap=(G.FV||[]).filter(f=>p>=f.bot&&p<=f.top&&i>=f.i&&(f.fill_i==null||i<=f.fill_i))[0];
 if(inGap) rows.push(['FVG '+(inGap.kind==='bull'?'bullisch':'bärisch'),
   px(inGap.bot)+'–'+px(inGap.top)+' · '+(inGap.size_pct*100).toFixed(2)+' % · '
   +(inGap.fill_i==null?(inGap.fill_pct*100).toFixed(0)+' % gefüllt, offen':'gefüllt'),
   inGap.kind==='bull'?'#39ff14':'#e04b4b']);
 showTip(ev,tlabel(c.t)+(LAST_CHART&&LAST_CHART.agg>=1440?'':''),rows);
}

function tipDepth(ev){
 const G=GEO.depth; if(!G) return hideTip();
 const {x,y}=pos(ev,$('depth'));
 if(y<G.T||y>G.T+G.ph) return hideTip();
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 if(LAST){ drawDepth(LAST_DEPTH||{rows:G.rows,price:G.p0,vol_1h:G.vol}); crosshair($('depth'),G,x,y,p); }
 const r=G.rows.reduce((a,b)=>Math.abs(b.bucket_px-p)<Math.abs(a.bucket_px-p)?b:a);
 const dist=(r.bucket_px-G.p0)/G.p0;
 showTip(ev,'Cluster bei '+px(r.bucket_px)+' USD',[
  ['Notional',fmt(r.notional)+' USD'],
  ['Positionen',r.n_pos],
  ['Abstand zum Kurs',(dist*100).toFixed(2)+' %'],
  ['Anteil Stundenvol.',G.vol?(r.notional/G.vol).toFixed(2)+'x':'—'],
  ['Art',r.side==='long'?'Long-Liquidationen':'Short-Liquidationen',
   r.side==='long'?'#e04b4b':'#3ba55d']]);
}

for(const [id,fn] of [['heat',tipHeat],['chart',tipChart],['depth',tipDepth],['stops',tipStops]]){
 const c=$(id);
 c.addEventListener('mousemove',fn);
 const redraw=()=>{ if(LAST_CHART){ if(c.id==='stops') drawStops(LAST_CHART); if(c.id==='chart') drawChart(LAST_CHART); }
  if(LAST&&c.id==='heat') drawHeat(LAST); if(LAST_DEPTH&&c.id==='depth') drawDepth(LAST_DEPTH); };
 c.addEventListener('mouseleave',()=>{hideTip(); redraw();});
 c.addEventListener('click',fn);
 c.addEventListener('touchstart',e=>{e.preventDefault();fn(e.touches[0]);},{passive:false});
 c.addEventListener('touchmove',e=>{e.preventDefault();fn(e.touches[0]);},{passive:false});
 c.addEventListener('touchend',()=>setTimeout(()=>{hideTip(); redraw();},2500));
}

async function loadChart(){
 const coin=$('coin').value, [agg,mins]=$('tf').value.split('|');
 const fvg=$('fvg')?$('fvg').value:'0.0005';
 try{LAST_CHART=await getJSON(`/chart?coin=${coin}&agg=${agg}&minutes=${mins}&fvg=${fvg}&src=${SRC()}`);
  if(LAST_DATA) renderKpi();
  { const k=(LAST_CHART.lb_act?LAST_CHART.lb_act.last_fill:0)+'|'+coin; if(k!==LBACT_KEY){ LBACT_KEY=k; drawLbActivity(LAST_CHART.lb_act); drawLbAct48(LAST_CHART.lb_act48); } }
  if(LAST_SYS&&!LAST_SYS._thermalDrawn){ LAST_SYS._thermalDrawn=true; drawSystem(LAST_SYS); }
  if(LAST_CHART.lb){ drawLbChart(LAST_CHART.lb);
   const key=(LAST_CHART.lb.ts||0)+'|'+coin+'|'+(LAST_CHART.lb.accounts||[]).length;   // Tabelle nur bei neuem Stand neu bauen (sonst springt die Seite)
   if(key!==LB_TABLE_KEY){ LB_TABLE_KEY=key; drawLbTable(LAST_CHART.lb); } }
  computeSignal();
  drawChart(LAST_CHART);
  drawStops(LAST_CHART);
  fillIndicators(LAST_CHART);
 }catch(e){ console.error('Chart:', e); showErr('Chart: '+(e.message||e)); }
}
function renderKpi(){
 const d=LAST_DATA; if(!d) return;
 const dp=d.depth||{rows:[]};
 const up=dp.rows.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
 const dn=dp.rows.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0);
 const B=(LAST_CHART&&LAST_CHART.bnc)||{}, M=B.metrics||{}, src=SRC(), CD=(LAST_CHART&&LAST_CHART.cdc)||null;
 const cdcTiles=CD?ratioTile('Taker Kauf/Verkauf Crypto.com (Verhältnis)', CD.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', `Volumen der Market-Käufe geteilt durch Market-Verkäufe aus den letzten ${CD.taker_n||0} Trades (${Math.round(CD.taker_span_s||0)} s) auf Crypto.com`)
  +`<div title="Open Interest auf Crypto.com: ${(CD.oi||0).toFixed(1)} ${$('coin').value} × Kurs; darunter die Prämie des Perpetuals gegen den Index (Funding-Näherung)"><span>Open Interest Crypto.com (USD)</span><b>${fmt(CD.oi_usd||0)}<span class="d">Prämie ${CD.premium!=null?(CD.premium*100).toFixed(3)+' %':'—'} · 24 h ${fmt(CD.vol_24h_usd||0)}</span></b></div>`
  :`<div title="Crypto.com derzeit nicht abrufbar oder Coin dort nicht gehandelt"><span>Crypto.com</span><b>—</b></div>`;
 const D={
  liqAbove:'Summe des Notionals (USD) aller Short-Positionen, die laut Positionsdaten über dem aktuellen Kurs liquidiert würden — eine Erwartung, kein Ereignis.',
  liqBelow:'Summe des Notionals (USD) aller Long-Positionen, die unter dem aktuellen Kurs liquidiert würden — Erwartung.',
  liqL:'USD-Notional der in der letzten Stunde auf Binance zwangsliquidierten LONG-Positionen (Verkaufs-Fills).',
  liqS:'USD-Notional der in der letzten Stunde auf Binance zwangsliquidierten SHORT-Positionen (Kauf-Fills).',
  oi:'Open Interest: Gesamtwert aller offenen Perpetual-Positionen auf Binance in USD (sumOpenInterestValue).',
  lsAcc:'Zahl der Konten mit Netto-Long geteilt durch Zahl der Konten mit Netto-Short, alle Binance-Konten (globalLongShortAccountRatio). 1,00 : 1 = ausgeglichen.',
  lsTop:'Positionsgröße long geteilt durch Positionsgröße short der größten Binance-Konten (topLongShortPositionRatio). Gewichtet nach USD, nicht nach Kontenzahl.',
  taker:'Volumen der aggressiven Market-Käufe geteilt durch Volumen der Market-Verkäufe (takerlongshortRatio, 5-min-Fenster). Über 1: Käufer nehmen Liquidität.',
  vol:'Gehandeltes Volumen der letzten Stunde in USD (Kerzenvolumen × Preis).',
  addr:'Anzahl der Hyperliquid-Adressen, die der Recorder aus den Trade-Feeds gesammelt hat.',
  pos:'Anzahl dieser Adressen mit mindestens einer offenen Perpetual-Position (nach der letzten Abfrage).',
 };
 const liqTiles=src==='hl'?`
  <div title="${D.liqAbove}"><span>Short-Liqs darüber (USD)</span><b style="color:#3ba55d">${fmt(up)}</b></div>
  <div title="${D.liqBelow}"><span>Long-Liqs darunter (USD)</span><b style="color:#e04b4b">${fmt(dn)}</b></div>`
  :src==='bnc'?`
  <div title="${D.liqL}"><span>Long-Liquidationen 1 h (Binance, USD)</span><b style="color:#e04b4b">${fmt((B.liqs_1h||{}).long||0)}</b></div>
  <div title="${D.liqS}"><span>Short-Liquidationen 1 h (Binance, USD)</span><b style="color:#3ba55d">${fmt((B.liqs_1h||{}).short||0)}</b></div>
  <div title="${D.oi}"><span>Open Interest (Binance, USD)</span><b>${M.oi_notional?fmt(M.oi_notional):'—'}</b></div>`
  +ratioTile('Long/Short Konten (Verhältnis)', M.global_ls_account, 'der Konten long', 'short', D.lsAcc)
  +ratioTile('Long/Short Top-Trader (Verhältnis)', M.top_ls_position, 'des Positionswerts long', 'short', D.lsTop)
  +ratioTile('Taker Kauf/Verkauf Binance (Verhältnis)', M.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', D.taker)+cdcTiles
  :`
  <div title="${D.liqAbove}"><span>Short-Liqs darüber (HL erwartet, USD)</span><b style="color:#3ba55d">${fmt(up)}</b></div>
  <div title="${D.liqBelow}"><span>Long-Liqs darunter (HL erwartet, USD)</span><b style="color:#e04b4b">${fmt(dn)}</b></div>
  <div title="${D.liqL} + ${D.liqS}"><span>Liquidationen 1 h (Binance, Long + Short, USD)</span><b>${fmt(((B.liqs_1h||{}).long||0)+((B.liqs_1h||{}).short||0))}</b></div>
  <div title="${D.oi}"><span>Open Interest (Binance, USD)</span><b>${M.oi_notional?fmt(M.oi_notional):'—'}</b></div>`
  +ratioTile('Taker Kauf/Verkauf Binance (Verhältnis)', M.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', D.taker)+cdcTiles;
 const vol=src==='fusion'?((dp.vol_1h||0)+(B.vol_1h||0)+((CD&&CD.vol_1h)||0)):src==='bnc'?(B.vol_1h||dp.vol_1h||0):(dp.vol_1h||0);
 // Börsenübergreifende Kacheln (Binance-Modus und Fusion): OI, Taker, Long/Short-Konten, Funding
 const BY=(LAST_CHART&&LAST_CHART.bybit)||null, OK=(LAST_CHART&&LAST_CHART.okx)||null;
 let exTiles='';
 if(src!=='hl'){
  const ex=[['Binance',{oi:M.oi_notional,taker:M.taker_ls,ls:M.global_ls_account,fund:B.funding,vol:B.vol_1h}],['Bybit',BY&&{oi:BY.oi_usd,taker:BY.taker_ls,ls:BY.ls_account,fund:BY.funding,vol:BY.vol_1h}],
            ['OKX',OK&&{oi:OK.oi_usd,taker:OK.taker_ls,ls:OK.ls_account,fund:OK.funding,vol:OK.vol_1h}],['Crypto.com',CD&&{oi:CD.oi_usd,taker:CD.taker_ls,ls:null,fund:CD.premium!=null?CD.premium/8:null,vol:CD.vol_1h}]].filter(e=>e[1]);
  const oiSum=ex.reduce((a,e)=>a+(e[1].oi||0),0), oiTxt=ex.filter(e=>e[1].oi).map(e=>`${e[0]} ${fmt(e[1].oi)}`).join(' · ');
  const spanOf={Bybit:BY&&BY.taker_span_s,'Crypto.com':CD&&CD.taker_span_s};
  const tk=ex.filter(e=>e[1].taker!=null&&e[1].taker<9&&(spanOf[e[0]]==null||spanOf[e[0]]>=60)), wsum=tk.reduce((a,e)=>a+Math.max(e[1].vol||0,1),0), tkAvg=tk.length?tk.reduce((a,e)=>a+e[1].taker*Math.max(e[1].vol||0,1),0)/wsum:null;
  const ls=ex.filter(e=>e[1].ls!=null), fu=ex.filter(e=>e[1].fund!=null), fuAvg=fu.length?fu.reduce((a,e)=>a+e[1].fund,0)/fu.length:null;
  exTiles=`<div title="Summe des Open Interest der erreichbaren Börsen in USD: ${oiTxt}"><span>Open Interest ${ex.filter(e=>e[1].oi).length} Börsen (USD)</span><b>${fmt(oiSum)}<span class="d">${oiTxt}</span></b></div>`
   +(tkAvg!=null?`<div title="Taker Kauf/Verkauf nach Stundenvolumen gewichtet über ${tk.map(e=>e[0]).join(', ')} — über 1: aggressive Käufer überwiegen"><span>Taker börsenübergreifend (Verhältnis)</span><b style="color:${tkAvg>1.15?'#3ba55d':tkAvg<0.87?'#e04b4b':'#c9d1d9'}">${tkAvg.toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2})} : 1<span class="d">${ex.filter(e=>e[1].taker!=null&&e[1].taker<9).map(e=>`${e[0]} ${(+e[1].taker).toFixed(2)}${spanOf[e[0]]!=null&&spanOf[e[0]]<60?' (nur '+Math.round(spanOf[e[0]])+' s, nicht gewertet)':''}`).join(' · ')}</span></b></div>`:'')
   +(ls.length?`<div title="Verhältnis Long- zu Short-Konten je Börse (Binance global, Bybit, OKX); über 1 = mehr Konten long"><span>Long/Short Konten je Börse</span><b>${ls.map(e=>`${e[0]} ${(+e[1].ls).toFixed(2)}`).join(' · ')}</b></div>`:'')
   +(fuAvg!=null?`<div title="Funding je Stunde (Binance, Bybit, OKX aus 8-h-Sätzen; Crypto.com aus der Prämie); Durchschnitt und Einzelwerte in % pro Stunde"><span>Funding Ø Börsen (%/h)</span><b style="color:${fuAvg>0.0001?'#e04b4b':fuAvg<-0.00005?'#3ba55d':'#c9d1d9'}">${(fuAvg*100).toFixed(4)} %<span class="d">${fu.map(e=>`${e[0]} ${(e[1].fund*100).toFixed(4)}`).join(' · ')}</span></b></div>`:'');
 }
 // ETF-Flows und Smart Money in jeder Quelle
 const E=(LAST_CHART&&LAST_CHART.etf)||null, SMd=(LAST_CHART&&LAST_CHART.smart)||null;
 const etfTile=(['BTC','ETH'].includes($('coin').value))?(E?`<div title="Tägliche Netto-Zu-/Abflüsse der US-Spot-ETFs in Mio USD (Quelle ${E.source}); Serie = Tage in Folge mit gleichem Vorzeichen"><span>ETF-Flows ${$('coin').value} (Mio USD/Tag)</span><b style="color:${E.last>0?'#3ba55d':E.last<0?'#e04b4b':'#c9d1d9'}">${E.last>0?'+':''}${E.last.toFixed(1)}<span class="d">${E.last_date} · 5 Tage ${E.sum5>0?'+':''}${E.sum5.toFixed(0)} Mio · Serie ${Math.abs(E.streak)} Tag${Math.abs(E.streak)!==1?'e':''} ${E.streak>0?'Zufluss':E.streak<0?'Abfluss':''}</span></b></div>`
   :`<div title="ETF-Flows werden geladen (Farside, einmal pro Stunde)"><span>ETF-Flows ${$('coin').value}</span><b>lädt …</b></div>`):'';
 const smTile=SMd?(()=>{ const c=SMd.coin, a=SMd.all, use=(c.n_long+c.n_short)>=5?c:a, scope=(c.n_long+c.n_short)>=5?$('coin').value:'alle Coins';
   const tot=use.usd_long+use.usd_short, pl=tot?use.usd_long/tot*100:0;
   return `<div title="Die ${SMd.n_accounts} Konten mit dem höchsten 30-Tage-PnL im Hyperliquid-Leaderboard (Kontowert ab 500k): Netto-Ausrichtung ihrer Positionen je Konto, ${scope}; Positionen vom Recorder alle 10 min abgefragt"><span>Smart Money HL Top ${SMd.n_accounts} (${scope}, USD)</span><b><span style="color:#3ba55d">${use.n_long} LONG ${fmt(use.usd_long)} [${pl.toFixed(0)} %]</span> <span style="color:#8b949e">vs.</span> <span style="color:#e04b4b">${use.n_short} SHORT ${fmt(use.usd_short)} [${(100-pl).toFixed(0)} %]</span><span class="d">Konten mit den besten 30-Tage-Ergebnissen · Stand ${hm(SMd.ts)}</span></b></div>`; })()
  :`<div title="Smart Money kommt vom Recorder (Leaderboard alle 10 min); bis zur ersten Abfrage leer"><span>Smart Money HL Top 50</span><b>lädt …</b></div>`;
 $('kpi').innerHTML=`
  <div title="Letzter Handelspreis in USD${src==='bnc'?' (Binance-Kerze)':' (Hyperliquid-Trade-Feed)'}"><span>Kurs${src==='bnc'?' (Binance)':''} (USD)</span><b>${dp.price?px(dp.price):'—'}</b></div>`+liqTiles+`
  <div title="${D.vol}${src==='fusion'&&LAST_CHART&&LAST_CHART.vol_split?` — HL ${fmt(LAST_CHART.vol_split.hl||0)}, Binance ${fmt(LAST_CHART.vol_split.bnc||0)}, Crypto.com ${fmt(LAST_CHART.vol_split.cdc||0)}`:''}"><span>Volumen 1 h${src==='fusion'?' (HL + Binance + Crypto.com)':src==='bnc'?' (Binance)':''} (USD)</span><b>${fmt(vol)}</b></div>`+exTiles+etfTile+smTile
  +(src!=='bnc'?`
  <div title="${D.addr}"><span>Adressen erfasst (Anzahl)</span><b>${d.stats.addresses.toLocaleString('de-DE')}</b></div>
  <div title="${D.pos}"><span>mit offener Position (Anzahl)</span><b>${d.stats.positions.toLocaleString('de-DE')}</b></div>`:'')+`
  <div title="Kursänderung der letzten 60 Minuten in Prozent (Schluss jetzt gegen Schluss vor 60 Minutenkerzen)"><span>60-Minuten-Trend (%)</span><b id="kpi_trend">—</b></div>
  <div title="Relative-Stärke-Index nach Wilder über 14 Kerzen des gewählten Rasters, Skala 0–100: unter 30 überverkauft, über 70 überkauft"><span id="kpi_rsi_lbl">RSI 14</span><b id="kpi_rsi">—</b></div>
  <div title="Gleitender Durchschnitt der Wochenschlusskurse über 50 Wochen (USD); darunter der Abstand des Kurses in Prozent — ▲ Kurs darüber, ▼ Kurs darunter"><span>MA 50 Wochen (USD · Abstand %)</span><b id="kpi_ma50w">—</b></div>
  <div title="Gleitender Durchschnitt der Tagesschlusskurse über 200 Tage (USD); darunter der Abstand des Kurses in Prozent"><span>MA 200 Tage (USD · Abstand %)</span><b id="kpi_ma200d">—</b></div>
  <div title="Zeitpunkt des letzten verifizierten Datenbank-Backups"><span>Letztes Backup</span><b id="kpi_backup">—</b></div>
  <div title="Ergebnis der letzten SQLite-Integritätsprüfung (quick_check)"><span>Datenbank</span><b id="kpi_db">—</b></div>
  <div title="Nur direktionale Wale (eine Seite, kein Hedge-, kein Market-Maker-Muster), Konten ab 10 Mio USD Gesamtwert, alle Coins: Anzahl Konten und Positionswert je Seite, Prozent = Anteil am Wert beider Seiten"><span>Wal-Position (nur direktional, USD)</span><b id="kpi_dirn">—</b></div>
  <div title="Käufe minus Verkäufe der Top-50-Konten im gewählten Coin (Perp und Spot, Notional USD) in den letzten 24 h und 3 Tagen; Konten = Käufer / Verkäufer im Zeitraum"><span>Leaderboard Käufe/Verkäufe <span id="kpi_lbact_coin"></span> (USD)</span><b id="kpi_lbact">—</b></div>
  <div title="Netto-Positionsänderung der direktionalen Wale im gewählten Coin in den letzten 30 min (Long auf/Short ab = Kauf; Z = Abweichung von der eigenen 7-Tage-Verteilung der Stundenflüsse); Ereignis-Signal ab Z 2,5 und 4 Walen in dieselbe Richtung"><span>Wal-Flow 30 min (direktional, USD)</span><b id="kpi_flow">—</b></div>
  <div title="Positionierung der 20 profitabelsten Leaderboard-Konten (30-Tage-PnL) in BTC: Konten und Positionswert je Seite, Netto-Wert und dessen Veränderung gegen 24 h und 7 Tage zuvor (aus der stündlichen Aufzeichnung lb_trend)"><span>Leaderboard Top 20 — BTC-Trend (USD)</span><b id="kpi_lbbtc">—</b></div>
  <div title="Netto-Summe der Konfluenz-Punkte: Kauf-Punkte minus Verkaufs-Punkte; ab ±3 Konfluenz, Details im Abschnitt Konfluenz"><span>Konfluenz</span><b id="kpi_signal">—</b></div>
  <div title="Verbrauchte Gewichtseinheiten der Hyperliquid-API in der letzten Minute (Positionsabfrage 2, Orderabfrage 20) gegen das Limit von 1.200 je Minute und IP"><span>API-Gewicht / Minute</span><b id="kpi_api">—</b></div>`;
 if(LAST_CHART){ fillBudget(LAST_CHART); fillIndicators(LAST_CHART); }
 if(LAST_HEALTH) fillHealth(LAST_HEALTH);
 fillDirectional(); fillFlow(); fillFcLive(); fillLbTile(); fillLbActTile();
 if(LAST_CHART&&LAST_CHART.budget) taskWarn(LAST_CHART.budget);
}

async function load(){
 loadChart();
 const coin=$('coin').value, h=$('hours').value;
 const d=await getJSON(`/data?coin=${coin}&hours=${h}&src=${SRC()}`);
 LAST=d.grid; LAST_DEPTH=d.depth; LAST_DATA=d; drawHeat(d.grid); drawDepth(d.depth);
 if(SRC()==='bnc'){ LAST_WHALES={exposure:[],current:[],events:[],price:[]}; drawWhales(LAST_WHALES); drawMetrics(d.metrics); computeSignal(); if(LAST_CHART) drawChart(LAST_CHART); }
 else { try{LAST_WHALES=await getJSON(`/whales?coin=${coin}&hours=${Math.max(72,h)}`); drawWhales(LAST_WHALES); computeSignal();
  if(LAST_CHART) drawChart(LAST_CHART);}catch(e){}
  if(SRC()==='fusion'&&d.bnc) drawMetrics(d.bnc.metrics); else $('bncmetrics').style.display='none'; }
 renderKpi();
 if(LAST_CHART) fillBudget(LAST_CHART);
 if(LAST_CHART) computeSignal();
 if(LAST_CHART) fillIndicators(LAST_CHART);
 if(LAST_HEALTH) fillHealth(LAST_HEALTH);
 $('warn').textContent=d.stats.days<14
  ? `Aufzeichnung läuft erst ${d.stats.days.toFixed(1)} Tage — die Abdeckung der `
    +`Adressen ist noch unvollständig, absolute Zahlen fallen zu niedrig aus.`:'';
}
$('thr').oninput=()=>{$('thrval').textContent='Perzentil '+$('thr').value;
                      if(LAST) drawHeat(LAST);};
getJSON('/coins').then(cs=>{
 if(!Array.isArray(cs)||!cs.length){showErr('/coins: leere Liste — Datenbank ohne Kerzen? Pfad in der Unit prüfen');return;}
 $('coin').innerHTML=cs.map(c=>`<option>${c}</option>`).join('');
 load(); loadHealth();
 setInterval(load,20000); setInterval(loadChart,5000); setInterval(loadHealth,3600000);
 $('coin').onchange=()=>{ load(); loadForecast(); }; $('hours').onchange=load;
 try{ const sv=localStorage.getItem('hl_src'); if(sv&&$('src').querySelector(`option[value="${sv}"]`)) $('src').value=sv; }catch(e){}
 $('src').onchange=()=>{ try{localStorage.setItem('hl_src',SRC());}catch(e){} applySrcLabels(); load(); };
 applySrcLabels();
 $('tf').onchange=loadChart; $('fvg').onchange=loadChart;
 $('fvgtoggle').onclick=()=>setFvg(!FVG_ON);
 $('updbtn').onclick=runUpdate;
 let rsz=null; addEventListener('resize',()=>{clearTimeout(rsz); rsz=setTimeout(load,300);});   // Drehung: alle Panels neu
}).catch(()=>{});   // Fehler wurde von getJSON bereits in der Leiste gemeldet
</script></body></html>"""


# ---------------------------------------------------------------------------
# Update per Knopf: Archiv von GitHub laden, update.py in eigener systemd-Einheit
# starten (ein Kind des Dashboards stürbe mit dem Dashboard-Neustart).
# ---------------------------------------------------------------------------

UPDATE_URL = "https://raw.githubusercontent.com/lll174/Seed/main/hl_liq_project.zip"
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
UPDATE_LOG = os.path.join(ROOT_DIR, "updates", "last_update.log")


def raw_github(url: str) -> str:
    """blob-Links der GitHub-Oberfläche auf den Rohdownload umschreiben."""
    m = re.match(r"https?://github\.com/([^/]+)/([^/]+)/blob/(.+)", url)
    return f"https://raw.githubusercontent.com/{m.group(1)}/{m.group(2)}/{m.group(3)}" if m else url


def sudo_password() -> tuple[str | None, str]:
    f = os.path.join(ROOT_DIR, "sudo.txt")
    if not os.path.exists(f):
        return None, "sudo.txt fehlt im Projektordner"
    mode = os.stat(f).st_mode & 0o777
    if mode & 0o077:
        return None, f"sudo.txt hat Rechte {oct(mode)} — bitte chmod 600 sudo.txt"
    pw = open(f, errors="replace").read().strip()
    return (pw, "") if pw else (None, "sudo.txt ist leer")


def start_update(url: str) -> dict:
    """Archiv laden, prüfen, update.py abgekoppelt starten. Liefert Status für die Seite."""
    import urllib.request, zipfile
    pw, why = sudo_password()
    if not pw:
        return {"ok": False, "msg": why}
    os.makedirs(os.path.dirname(UPDATE_LOG), exist_ok=True)
    target = os.path.join(ROOT_DIR, "updates", "hl_liq_project.zip")
    try:
        req = urllib.request.Request(raw_github(url), headers={"User-Agent": "hl-dashboard-update/1.0",
                                                               "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read()
    except Exception as e:
        return {"ok": False, "msg": f"Download fehlgeschlagen: {e}"}
    if data[:2] != b"PK":
        return {"ok": False, "msg": "Download ist kein ZIP — GitHub-Link prüfen (Rohdatei, nicht HTML-Seite)"}
    with open(target, "wb") as f:
        f.write(data)
    try:
        with zipfile.ZipFile(target) as z:
            names = {n.split("/")[-1] for n in z.namelist()}
        if not {"hl_recorder.py", "hl_viz.py", "update.py"} <= names:
            return {"ok": False, "msg": "Archiv unvollständig"}
    except zipfile.BadZipFile as e:
        return {"ok": False, "msg": f"ZIP defekt: {e}"}
    py = os.path.join(ROOT_DIR, ".venv", "bin", "python")
    if not os.path.exists(py):
        py = sys.executable
    uid, gid = os.getuid(), os.getgid()
    with open(UPDATE_LOG, "w") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] Archiv geladen ({len(data)//1024} kB), starte update.py …\n")
    if shutil.which("systemd-run") and os.path.exists("/run/systemd/system"):
        # Läuft noch ein Update? Dann nicht doppelt starten.
        active = subprocess.run(["systemctl", "list-units", "--no-legend", "--plain", "--state=active,activating",
                                 "hl-update*"], capture_output=True, text=True).stdout.strip()
        if active:
            return {"ok": False, "msg": "Ein Update läuft noch: " + active.split()[0]}
        # Reste gescheiterter Läufe freigeben (sonst: 'Unit ... was already loaded')
        subprocess.run(["sudo", "-S", "-p", "", "systemctl", "reset-failed", "hl-update.service", "hl-update-*.service"],
                       input=pw + "\n", capture_output=True, text=True)
        # eigene, kurzlebige Einheit mit eindeutigem Namen: überlebt den Dashboard-Neustart
        unit = "hl-update-" + time.strftime("%Y%m%d-%H%M%S")
        cmd = ["sudo", "-S", "-p", "", "systemd-run", f"--unit={unit}", "--collect",
               f"--uid={uid}", f"--gid={gid}", f"--working-directory={ROOT_DIR}",
               f"--property=StandardOutput=append:{UPDATE_LOG}",
               f"--property=StandardError=append:{UPDATE_LOG}",
               py, os.path.join(ROOT_DIR, "update.py"), target, "--yes"]
        r = subprocess.run(cmd, input=pw + "\n", capture_output=True, text=True)
        if r.returncode != 0:
            return {"ok": False, "msg": "systemd-run fehlgeschlagen: " + (r.stderr.strip()[-200:] or "unbekannt")}
        with open(os.path.join(ROOT_DIR, "updates", "last_unit.txt"), "w") as f:
            f.write(unit)
        return {"ok": True, "msg": f"Update gestartet (Einheit {unit}). Das Dashboard startet gleich neu."}
    # ohne systemd: abgekoppelter Prozess
    with open(UPDATE_LOG, "a") as logf:
        subprocess.Popen([py, os.path.join(ROOT_DIR, "update.py"), target, "--yes"],
                         cwd=ROOT_DIR, stdout=logf, stderr=subprocess.STDOUT, start_new_session=True)
    return {"ok": True, "msg": "Update gestartet."}


def update_status() -> dict:
    running = False
    if shutil.which("systemctl"):
        unit = "hl-update"
        try:
            with open(os.path.join(ROOT_DIR, "updates", "last_unit.txt")) as f:
                unit = f.read().strip() or unit
        except OSError:
            pass
        running = subprocess.run(["systemctl", "is-active", unit], capture_output=True,
                                 text=True).stdout.strip() in ("active", "activating")
    log = ""
    try:
        with open(UPDATE_LOG, errors="replace") as f:
            log = "".join(f.readlines()[-40:])
    except OSError:
        pass
    done = ("Fertig." in log) or ("FEHLER" in log and not running) or ("Abbruch" in log)
    return {"running": running, "done": done and not running, "log": log,
            "ok_marker": "Fertig." in log}


# ---------------------------------------------------------------------------
# Wallet-Zuordnung: wer steckt hinter einer Adresse?
#   1. labels.json         -- eigene Pflege, hat Vorrang, wird nie überschrieben
#   2. Hyperliquid-Leaderboard  -- selbst gewählte Anzeigenamen (kein API-Gewicht)
#   3. vaultDetails        -- ist die Adresse ein Vault? (Gewicht 20, 1 Abfrage/min, 7 Tage Cache)
#   4. Etherscan-Namenstags (octal.art) und Arbiscan-Tags (Datensatz) -- Börsen, Fonds, Market Maker
#   5. Verhaltensklasse aus den eigenen Daten -- Hedge, Market-Maker-Muster, direktional
# Treffer und Fehlschläge landen in labels_cache.json, damit nichts doppelt gefragt wird.
# ---------------------------------------------------------------------------

LABELS_FILE = os.path.join(ROOT_DIR, "labels.json")
LABELS_CACHE = os.path.join(ROOT_DIR, "labels_cache.json")
ARB_LABELS_URL = "https://raw.githubusercontent.com/brianleect/etherscan-labels/main/data/arbiscan/combined/combinedAllLabels.json"
_LBL_LOCK = threading.Lock()
_LBL: dict = {"own": {}, "own_mtime": 0, "cache": None, "queue": [], "queued": set(), "worker": None,
              "leaderboard": None, "leaderboard_ts": 0, "arb": None, "arb_ts": 0, "last_vault_call": 0}
_LBL_TTL = 7 * 86_400
_LBL_NEG_TTL = 2 * 86_400


def _lbl_load_cache() -> dict:
    with _LBL_LOCK:
        if _LBL["cache"] is None:
            try:
                with open(LABELS_CACHE) as f:
                    _LBL["cache"] = json.load(f)
            except (OSError, ValueError):
                _LBL["cache"] = {}
        return _LBL["cache"]


def _lbl_save_cache() -> None:
    with _LBL_LOCK:
        try:
            tmp = LABELS_CACHE + ".tmp"
            with open(tmp, "w") as f:
                json.dump(_LBL["cache"], f, ensure_ascii=False)
            os.replace(tmp, LABELS_CACHE)
        except OSError:
            pass


def _lbl_own() -> dict:
    try:
        m = os.path.getmtime(LABELS_FILE)
    except OSError:
        return {}
    with _LBL_LOCK:
        if m != _LBL["own_mtime"]:
            try:
                with open(LABELS_FILE) as f:
                    raw = json.load(f)
                _LBL["own"] = {k.lower(): v for k, v in raw.items() if isinstance(v, dict) and k.startswith("0x")}
            except (OSError, ValueError):
                _LBL["own"] = {}
            _LBL["own_mtime"] = m
        return _LBL["own"]


def _http_json(url: str, timeout: int = 20, data: bytes | None = None):
    import urllib.request
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "hl-dashboard/1.0",
                                                          **({"Content-Type": "application/json"} if data else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _lbl_leaderboard() -> dict:
    """Adresse -> displayName: aus lb_names (schreibt der Recorder stündlich) -- kein 40-MB-Download im Dashboard.
    Rückfall auf den Download nur, wenn die Tabelle fehlt oder leer ist."""
    with _LBL_LOCK:
        if _LBL["leaderboard"] is not None and time.time() - _LBL["leaderboard_ts"] < 3600:
            return _LBL["leaderboard"]
    names: dict = {}
    try:
        con = connect(Handler.db)
        for r in con.execute("SELECT addr, name, account_value FROM lb_names"):
            names[r["addr"].lower()] = {"name": r["name"], "value": r["account_value"] or 0}
        con.close()
    except Exception:
        names = {}
    if names:
        with _LBL_LOCK:
            _LBL["leaderboard"] = names; _LBL["leaderboard_ts"] = time.time()
        return names
    try:
        d = _http_json("https://stats-data.hyperliquid.xyz/Mainnet/leaderboard", timeout=60)
        rows = d.get("leaderboardRows") if isinstance(d, dict) else d
        for r in rows or []:
            a, n = str(r.get("ethAddress", "")).lower(), r.get("displayName")
            if a and n:
                names[a] = {"name": str(n), "value": float(r.get("accountValue") or 0)}
    except Exception:
        pass
    with _LBL_LOCK:
        if names or _LBL["leaderboard"] is None:
            _LBL["leaderboard"] = names; _LBL["leaderboard_ts"] = time.time()
        return _LBL["leaderboard"]


def _lbl_arbiscan() -> dict:
    """Arbiscan-Namenstags aus dem offenen Datensatz, einmal geladen und lokal gehalten."""
    with _LBL_LOCK:
        if _LBL["arb"] is not None:
            return _LBL["arb"]
    out: dict = {}
    path = os.path.join(ROOT_DIR, "updates", "arbiscan_labels.json")
    try:
        if not os.path.exists(path) or time.time() - os.path.getmtime(path) > 30 * 86_400:
            d = _http_json(ARB_LABELS_URL, timeout=60)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                json.dump(d, f)
        with open(path) as f:
            d = json.load(f)
        if isinstance(d, dict):
            for addr, info in d.items():
                if isinstance(info, dict):
                    out[addr.lower()] = info.get("name") or info.get("Name Tag") or ",".join(info.get("labels", []) or [])
        elif isinstance(d, list):
            for row in d:
                if isinstance(row, dict) and row.get("address"):
                    out[str(row["address"]).lower()] = row.get("name") or row.get("nameTag") or ""
    except Exception:
        pass
    with _LBL_LOCK:
        _LBL["arb"] = out
    return out


def _lbl_lookup_one(addr: str, prev: dict | None = None) -> dict:
    """
    Alle automatischen Quellen für eine Adresse. Je Quelle wird gemerkt, wann sie
    geprüft wurde (checked), damit offene Vault-Prüfungen nicht die anderen Quellen
    erneut anstoßen. Liefert {name, category, source, checked, pending_vault}.
    """
    a = addr.lower(); now = time.time()
    checked = dict((prev or {}).get("checked") or {})
    lb = _lbl_leaderboard().get(a)
    if lb:
        return {"name": lb["name"], "category": "leaderboard", "source": "Hyperliquid-Leaderboard (selbst gewählter Name)", "checked": checked}
    if now - checked.get("octal", 0) > _LBL_NEG_TTL:
        try:
            d = _http_json(f"https://octal.art/etherscan-labels/addresses/{a}.json", timeout=15)
            labels = d.get("Labels") or {}
            tag = next((v.get("Name Tag") for v in labels.values() if isinstance(v, dict) and v.get("Name Tag")), None)
            checked["octal"] = now
            if tag:
                return {"name": tag, "category": ", ".join(sorted(labels.keys())) or "etherscan", "source": "Etherscan-Namenstag", "checked": checked}
        except Exception as e:
            if "404" in str(e):          # sicher unbekannt; Netzfehler -> später erneut
                checked["octal"] = now
    arb = _lbl_arbiscan().get(a)
    if arb:
        return {"name": arb, "category": "arbiscan", "source": "Arbiscan-Tag (Datensatz 2023)", "checked": checked}
    if now - checked.get("vault", 0) > _LBL_TTL:
        with _LBL_LOCK:                   # Vault? Gewicht 20 -- höchstens eine Abfrage pro Minute
            may = time.time() - _LBL["last_vault_call"] >= 60
            if may:
                _LBL["last_vault_call"] = time.time()
        if not may:
            return {"checked": checked, "pending_vault": True}
        try:
            d = _http_json("https://api.hyperliquid.xyz/info", timeout=15,
                           data=json.dumps({"type": "vaultDetails", "vaultAddress": a}).encode())
            checked["vault"] = now
            if isinstance(d, dict) and d.get("name"):
                return {"name": f"Vault „{d['name']}“", "category": "vault", "checked": checked,
                        "source": f"Hyperliquid vaultDetails · Leader {str(d.get('leader',''))[:10]}… · TVL {float(d.get('tvl') or 0)/1e6:.1f} Mio"}
        except Exception:
            return {"checked": checked, "pending_vault": True}
    return {"checked": checked}


def _lbl_worker() -> None:
    while True:
        with _LBL_LOCK:
            if not _LBL["queue"]:
                _LBL["worker"] = None
                return
            addr = _LBL["queue"].pop(0)
        cache = _lbl_load_cache()
        res = _lbl_lookup_one(addr, cache.get(addr))
        with _LBL_LOCK:
            cache[addr] = {"ts": time.time(), **res}
            _LBL["queued"].discard(addr)
        _lbl_save_cache()
        time.sleep(1.5)


_BEH_CACHE: dict = {"ts": 0, "map": {}}
_BEH_LOCK = threading.Lock()


def behavior_map(con) -> dict:
    """
    Verhaltensklasse aller Wale in EINEM Durchgang, 60 s im Speicher.
    Je Adresse: letzter Stand je Coin aus whale_positions (Index addr, ts), dazu die
    ruhenden Limits aus der jüngsten Order-Abfrage (nur letzte 6 h, ein Scan).
    Vorher lief je Wal eine Abfrage mit lower(addr) -- ohne Index, mit verschachteltem
    Vollscan: bei 40.000 Zeilen und 150 Walen antwortete der Server nicht mehr.
    """
    with _BEH_LOCK:
        if time.time() - _BEH_CACHE["ts"] < 60:
            return _BEH_CACHE["map"]
    latest: dict = {}
    try:
        for addr, coin, event, side, val, lev, ts in con.execute(
                "SELECT addr, coin, event, side, pos_value, leverage, ts FROM whale_positions ORDER BY ts"):
            latest[(addr, coin)] = (event, side, val or 0, lev or 0)
    except sqlite3.OperationalError:
        return {}
    per_addr: dict = {}
    for (addr, coin), (event, side, val, lev) in latest.items():
        if event == "close" or val <= 0:
            continue
        per_addr.setdefault(addr, []).append((coin, side, val, lev))
    orders: dict = {}
    try:
        since = int(time.time()) - 6 * 3600
        last_ts: dict = {}
        rows = con.execute("SELECT addr, ts, kind FROM trigger_orders WHERE ts>=? AND kind IN ('limit_buy','limit_sell')",
                           (since,)).fetchall()
        for addr, ts, kind in rows:
            last_ts[addr] = max(last_ts.get(addr, 0), ts)
        for addr, ts, kind in rows:
            if ts == last_ts[addr]:
                orders.setdefault(addr, {}).setdefault(kind, 0); orders[addr][kind] += 1
    except sqlite3.OperationalError:
        pass
    out = {}
    for addr, ps in per_addr.items():
        coins = {c for c, _, _, _ in ps}; sides = {sd for _, sd, _, _ in ps}
        lev = max(l for _, _, _, l in ps); n = len(coins); ob = orders.get(addr, {})
        if ob.get("limit_buy", 0) >= 5 and ob.get("limit_sell", 0) >= 5:
            cls = "Market-Maker-Muster (beidseitig viele ruhende Limits)"
        elif len(sides) == 2:
            cls = "gemischt (long und short)"
        elif n >= 3 and lev <= 10:
            cls = f"Hedge-Muster ({n} Coins, eine Seite, Hebel ≤ 10)"
        elif n >= 3:
            cls = f"direktional ({n} Coins, eine Seite, Hebel bis {lev:.0f}×)"
        elif n == 1 and lev >= 15:
            cls = "direktional (ein Coin, hoher Hebel)"
        else:
            cls = f"direktional ({n} Coin{'s' if n > 1 else ''}, Hebel bis {lev:.0f}×)"
        out[addr.lower()] = cls
    # Klasse JE COIN: Ein Konto kann in BTC klar positioniert sein und in ETH die Gegenseite
    # halten -- kontoweit "gemischt", für BTC aber eine Meinung. Entscheidend für das Signal
    # ist, wie sich das Konto IN DIESEM COIN verhält, nicht sein Gesamtbild.
    per_coin = {}
    for addr, ps in per_addr.items():
        ob = orders.get(addr, {})
        mm = ob.get("limit_buy", 0) >= 5 and ob.get("limit_sell", 0) >= 5
        coins = {c for c, _, _, _ in ps}
        sides_all = {sd for _, sd, _, _ in ps}
        lev_max = max((l for _, _, _, l in ps), default=0)      # kontoweit, wie in behavior_map
        for coin, side, val, lev in ps:
            if mm:
                grp = "mm"
            elif len(coins) >= 3 and len(sides_all) == 1 and lev_max <= 10:
                grp = "hedge"                       # viele Coins, eine Seite, wenig Hebel
            elif len(sides_all) == 2 and len(coins) >= 2:
                grp = "mixed"                       # trägt beide Seiten -- in diesem Coin aber eine
            else:
                grp = "dir"
            per_coin[(addr.lower(), coin)] = {"group": grp, "side": side, "val": val, "lev": lev,
                                              "coins": len(coins), "both_sides": len(sides_all) == 2}
    with _BEH_LOCK:
        _BEH_CACHE.update(ts=time.time(), map=out, per_coin=per_coin)
    return out


GROUPS = {"dir": "direktional", "hedge": "Hedge", "mm": "Market Maker", "mixed": "gemischt"}


def behavior_per_coin(con) -> dict:
    """Klasse je (Adresse, Coin) -- füllt denselben Zwischenspeicher wie behavior_map."""
    behavior_map(con)
    with _BEH_LOCK:
        return _BEH_CACHE.get("per_coin") or {}


def behavior_class(con, addr: str) -> str:
    return behavior_map(con).get(addr.lower(), "")


def labels_for(con, addrs: list[str]) -> dict:
    """Für jede Adresse: Name/Quelle (eigen > Cache), Verhaltensklasse, Links; Unbekannte in die Warteschlange."""
    own = _lbl_own(); cache = _lbl_load_cache(); out = {}; now = time.time(); bmap = behavior_map(con)
    for addr in addrs:
        a = addr.lower()
        rec = {"links": {"hypurrscan": f"https://hypurrscan.io/address/{a}",
                         "arbiscan": f"https://arbiscan.io/address/{a}",
                         "arkham": f"https://intel.arkm.com/explorer/address/{a}",
                         "hyperliquid": f"https://app.hyperliquid.xyz/explorer/address/{a}"},
               "behavior": bmap.get(a, "")}
        if a in own:
            o = own[a]; rec.update({"name": o.get("name", ""), "category": o.get("kategorie") or o.get("category", "eigen"),
                                    "source": o.get("quelle") or o.get("source", "labels.json")})
        else:
            c = cache.get(a)
            fresh = c and (now - c.get("ts", 0) < (_LBL_TTL if c.get("name") else _LBL_NEG_TTL)) and not (c.get("pending_vault") and now - c.get("ts", 0) > 90)
            if c and c.get("name"):
                rec.update({"name": c["name"], "category": c.get("category", ""), "source": c.get("source", "")})
            if not fresh:
                with _LBL_LOCK:
                    if a not in _LBL["queued"]:
                        _LBL["queue"].append(a); _LBL["queued"].add(a)
                        if _LBL["worker"] is None:
                            _LBL["worker"] = threading.Thread(target=_lbl_worker, daemon=True); _LBL["worker"].start()
                rec["pending"] = True
        out[a] = rec
    return out


# ---------------------------------------------------------------------------
# Debug-Konsole: feste Liste von Diagnoseläufen (kein freies Kommando), läuft als
# Dashboard-Benutzer ohne sudo, Ausgabe wird abgeholt und lässt sich kopieren.
# ---------------------------------------------------------------------------

def _py() -> str:
    v = os.path.join(ROOT_DIR, ".venv", "bin", "python")
    return v if os.path.exists(v) else sys.executable


def debug_commands(db: str) -> dict:
    py = _py()
    return {
        "report": ("★ VOLLBERICHT (2 min) — alles auf einmal, zum Einfügen in den Chat", [py, "check_report.py", "--db", db, "--minutes", "2"]),
        "check_leaderboard": ("Leaderboard-Diagnose (Konten, Rohformat, Live-Gegenprobe)", [py, "check_leaderboard.py", "--db", db]),
        "check_forecast": ("Prognose-Diagnose (vollständiger Traceback, Lernstand)", [py, "check_forecast.py", "--db", db]),
        "check_writes": ("Schreiblast messen (5 min): je Tabelle, je Laufwerk, je Prozess", [py, "check_writes.py", "--db", db, "--seconds", "300"]),
        "check_writes_short": ("Schreiblast messen (60 s, schnelle Stichprobe)", [py, "check_writes.py", "--db", db, "--seconds", "60"]),
        "browser_cache": ("Browser auf dem Pi: Cache-Größe und Schreiblast (Firefox/Chromium)", ["sh", "-c",
            "echo '--- Firefox-Profile:'; du -shc ~/.mozilla/firefox/*/ ~/.cache/mozilla/firefox/*/ 2>/dev/null | tail -20; "
            "echo; echo '--- Chromium:'; du -shc ~/.config/chromium ~/.cache/chromium 2>/dev/null | tail -5; "
            "echo; echo 'Firefox schreibt seinen Cache auf die SD-Karte. Abstellen: about:config ->'; "
            "echo '  browser.cache.disk.enable = false   (Cache nur im RAM)'; "
            "echo '  browser.sessionstore.interval = 600000   (Sitzung alle 10 min statt alle 15 s)'; "
            "echo 'Alternative: Dashboard vom Handy oder PC aus ansehen statt vom Pi.'"]),
        "sd_usage": ("SD-Karte: Belegung, größte Ordner, Journal, Swap", ["sh", "-c",
            "df -h / ; echo; echo '--- größte Ordner auf /:'; du -xhd2 / 2>/dev/null | sort -rh | head -20; "
            "echo; echo '--- Journal:'; journalctl --disk-usage 2>/dev/null; "
            "echo; echo '--- Swap:'; swapon --show; free -h | head -3; "
            "echo; echo '--- Logdateien des Projekts:'; ls -la logs/ 2>/dev/null | head; ls -la updates/ 2>/dev/null | head"]),
        "check_orders": ("Order-Abfragen: wie viele, wie stimmig", [py, "check_orders.py", "--db", db]),
        "check_daily": ("Tageskerzen / MA-Kacheln", [py, "check_daily.py", "--db", db]),
        "db_size": ("Speicherbelegung je Tabelle", [py, "db_size.py", db]),
        "audit": ("Recorder --audit (Gesamtstatus)", [py, "hl_recorder.py", "--db", db, "--audit"]),
        "status": ("Recorder --status", [py, "hl_recorder.py", "--db", db, "--status"]),
        "binance_status": ("Binance-Modul --status", [py, "hl_binance.py", "--db", db, "--status"]),
        "journal_recorder": ("Journal hl-recorder (letzte 80 Zeilen)", ["journalctl", "-u", "hl-recorder", "-n", "80", "--no-pager", "-o", "short-iso"]),
        "journal_dashboard": ("Journal hl-dashboard (letzte 80 Zeilen)", ["journalctl", "-u", "hl-dashboard", "-n", "80", "--no-pager", "-o", "short-iso"]),
        "journal_binance": ("Journal hl-binance (letzte 80 Zeilen)", ["journalctl", "-u", "hl-binance", "-n", "80", "--no-pager", "-o", "short-iso"]),
        "journal_update": ("Update-Log (updates/last_update.log)", ["tail", "-n", "120", UPDATE_LOG]),
        "services": ("Dienste: systemctl status", ["systemctl", "status", "hl-recorder", "hl-dashboard", "hl-binance", "--no-pager", "-l"]),
        "disk": ("Datenträger und Speicher", ["sh", "-c", "df -h / /mnt/* 2>/dev/null; echo; free -h; echo; uptime; echo; vcgencmd measure_temp 2>/dev/null"]),
    }


_DBG: dict = {"lock": threading.Lock(), "jobs": {}}


def debug_run(name: str, db: str) -> dict:
    cmds = debug_commands(db)
    if name not in cmds:
        return {"ok": False, "msg": "unbekannter Lauf"}
    label, cmd = cmds[name]
    job_id = f"{name}-{int(time.time())}"
    job = {"id": job_id, "name": name, "label": label, "cmd": " ".join(cmd), "started": time.time(), "running": True,
           "output": "", "rc": None}
    with _DBG["lock"]:
        if any(j["running"] for j in _DBG["jobs"].values()):
            return {"ok": False, "msg": "Es läuft schon ein Diagnoselauf — bitte warten."}
        _DBG["jobs"] = {job_id: job}                  # nur der jüngste Lauf wird gehalten

    def run():
        try:
            env = dict(os.environ, PYTHONUNBUFFERED="1")
            p = subprocess.Popen(cmd, cwd=ROOT_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env)
            buf = []
            for line in p.stdout:
                buf.append(line)
                if sum(len(x) for x in buf) > 200_000:
                    buf.append("\n… Ausgabe gekürzt (200 kB) …\n"); p.kill(); break
                with _DBG["lock"]:
                    job["output"] = "".join(buf)
            rc = p.wait(timeout=600)
            with _DBG["lock"]:
                job["output"] = "".join(buf); job["rc"] = rc
        except FileNotFoundError as e:
            with _DBG["lock"]:
                job["output"] += f"\nBefehl nicht verfügbar: {e}\n"; job["rc"] = 127
        except Exception as e:
            with _DBG["lock"]:
                job["output"] += f"\nFehler: {e}\n"; job["rc"] = 1
        finally:
            with _DBG["lock"]:
                job["running"] = False
    threading.Thread(target=run, daemon=True).start()
    return {"ok": True, "id": job_id, "label": label, "cmd": job["cmd"]}


def debug_status(job_id: str) -> dict:
    with _DBG["lock"]:
        job = _DBG["jobs"].get(job_id)
        if not job:
            return {"ok": False, "msg": "kein solcher Lauf"}
        return {"ok": True, "running": job["running"], "output": job["output"], "rc": job["rc"],
                "label": job["label"], "cmd": job["cmd"], "seconds": round(time.time() - job["started"], 1)}


# ---------------------------------------------------------------------------
# Systemüberwachung des Pi: Temperatur, Drosselung, Last, Speicher, Datenträger --
# ein Hintergrund-Thread misst alle 60 s, hält 24 h Verlauf, das Dashboard fragt ab.
# ---------------------------------------------------------------------------

_SYS: dict = {"lock": threading.Lock(), "hist": [], "cur": None, "started": False}


def _read(path: str) -> str | None:
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return None


def sys_sample(db_path: str | None = None) -> dict:
    now = int(time.time()); out: dict = {"ts": now}
    # Temperatur: Thermal-Zone (alle Pis), sonst vcgencmd
    t = _read("/sys/class/thermal/thermal_zone0/temp")
    temp = None
    if t and t.lstrip("-").isdigit():
        temp = int(t) / 1000
    else:
        try:
            r = subprocess.run(["vcgencmd", "measure_temp"], capture_output=True, text=True, timeout=3)
            m = re.search(r"temp=([\d.]+)", r.stdout)
            temp = float(m.group(1)) if m else None
        except Exception:
            temp = None
    out["temp"] = temp
    # Drosselung (Raspberry-Firmware): Bitmaske von vcgencmd get_throttled
    flags = []
    try:
        r = subprocess.run(["vcgencmd", "get_throttled"], capture_output=True, text=True, timeout=3)
        m = re.search(r"0x([0-9a-fA-F]+)", r.stdout)
        if m:
            v = int(m.group(1), 16); out["throttled_hex"] = f"0x{v:x}"
            bits = {0: "Unterspannung JETZT", 1: "Takt begrenzt JETZT", 2: "gedrosselt JETZT", 3: "Temperaturlimit JETZT",
                    16: "Unterspannung seit Start", 17: "Takt begrenzt seit Start", 18: "gedrosselt seit Start", 19: "Temperaturlimit seit Start"}
            flags = [name for bit, name in bits.items() if v & (1 << bit)]
    except Exception:
        out["throttled_hex"] = None
    out["throttle_flags"] = flags
    # Takt
    f = _read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
    out["cpu_mhz"] = int(f) / 1000 if f and f.isdigit() else None
    # Last, Speicher, Laufzeit
    try:
        out["load"] = list(os.getloadavg())
    except OSError:
        out["load"] = None
    # CPU-Auslastung gesamt in %: aus /proc/stat, Differenz zur letzten Messung
    # (erste Messung: kurzes Fenster von 0,5 s)
    def cpu_times():
        st = _read("/proc/stat") or ""
        m = re.match(r"cpu\s+(.*)", st)
        if not m:
            return None
        v = [int(x) for x in m.group(1).split()[:8]]
        idle = v[3] + (v[4] if len(v) > 4 else 0)
        return idle, sum(v)
    cur_t = cpu_times(); prev_t = _SYS.get("cpu_prev")
    if cur_t and not prev_t:
        time.sleep(0.5); prev_t, cur_t = cur_t, cpu_times()
    if cur_t and prev_t and cur_t[1] > prev_t[1]:
        out["cpu_pct"] = round(100 * (1 - (cur_t[0] - prev_t[0]) / (cur_t[1] - prev_t[1])), 1)
    else:
        out["cpu_pct"] = None
    _SYS["cpu_prev"] = cur_t
    out["n_cpu"] = os.cpu_count()
    mem = _read("/proc/meminfo") or ""
    def kb(key):
        m = re.search(rf"^{key}:\s+(\d+)", mem, re.M); return int(m.group(1)) * 1024 if m else None
    out["mem_total"], out["mem_avail"] = kb("MemTotal"), kb("MemAvailable")
    up = _read("/proc/uptime"); out["uptime_s"] = float(up.split()[0]) if up else None
    # Datenträger: Wurzel und der Datenträger der Datenbank
    disks = []
    for label, path in (("System", "/"), ("Datenbank", os.path.dirname(os.path.abspath(db_path)) if db_path else None)):
        if not path or not os.path.exists(path):
            continue
        try:
            u = shutil.disk_usage(path); disks.append({"label": label, "path": path, "total": u.total, "free": u.free})
        except OSError:
            pass
    out["disks"] = disks
    return out


def _sys_hist_file() -> str:
    """Systemverlauf neben der Hauptdatenbank (schont die SD-Karte), sonst im Projektordner."""
    import hl_forecast as _hf                      # lokal: das Modul wird weiter unten importiert
    d = os.path.dirname(os.path.abspath(_hf.STORE))
    if os.path.isdir(d) and os.access(d, os.W_OK):
        return os.path.join(d, "sys_history.json")
    return os.path.join(ROOT_DIR, "updates", "sys_history.json")


SYS_HIST_FILE = _sys_hist_file()


def sys_monitor_start(db_path: str) -> None:
    with _SYS["lock"]:
        if _SYS["started"]:
            return
        _SYS["started"] = True
        try:                                                        # Verlauf des letzten Laufs übernehmen (Neustart, Update)
            with open(SYS_HIST_FILE) as f:
                old = json.load(f)
            cut = time.time() - 86_400
            _SYS["hist"] = [tuple(h) for h in old if isinstance(h, list) and len(h) == 3 and h[0] >= cut]
        except (OSError, ValueError):
            pass
    def run():
        n = 0
        while True:
            try:
                smp = sys_sample(db_path)
                with _SYS["lock"]:
                    _SYS["cur"] = smp
                    if smp.get("temp") is not None or smp.get("cpu_pct") is not None:
                        _SYS["hist"].append((smp["ts"], smp.get("temp"), smp.get("cpu_pct") or 0))
                        _SYS["hist"] = _SYS["hist"][-1440:]          # 24 h bei 60 s
                    hist = list(_SYS["hist"])
                n += 1
                if n % 5 == 0:                                       # alle 5 min sichern
                    os.makedirs(os.path.dirname(SYS_HIST_FILE), exist_ok=True)
                    tmp = SYS_HIST_FILE + ".tmp"
                    with open(tmp, "w") as f:
                        json.dump(hist, f)
                    os.replace(tmp, SYS_HIST_FILE)
            except Exception:
                pass
            time.sleep(60)
    threading.Thread(target=run, daemon=True).start()


def sys_status() -> dict:
    with _SYS["lock"]:
        cur = _SYS["cur"]; hist = list(_SYS["hist"])
    if cur is None:
        cur = sys_sample()
    return {"current": cur, "history": hist, "max_24h": max((h[1] for h in hist if h[1] is not None), default=None)}


_RESP: dict = {"lock": threading.Lock(), "items": {}}


def _resp_cache_get(key: str, ttl: float):
    if ttl <= 0:
        return None
    with _RESP["lock"]:
        hit = _RESP["items"].get(key)
        return hit[1] if hit and time.time() - hit[0] < ttl else None


def _resp_cache_put(key: str, body: bytes) -> None:
    with _RESP["lock"]:
        _RESP["items"][key] = (time.time(), body)
        if len(_RESP["items"]) > 64:
            oldest = min(_RESP["items"], key=lambda k: _RESP["items"][k][0]); _RESP["items"].pop(oldest, None)


# ---------------------------------------------------------------------------
# AI-Prognose: alle 15 min je Coin im Hintergrund, Ergebnis im Speicher und in forecasts.db
# ---------------------------------------------------------------------------

import hl_forecast

_FC: dict = {"lock": threading.Lock(), "by_coin": {}, "started": False, "scores": {}}


_LEARN: dict = {}          # coin -> {"ts", "weights", "wver", "analog", "tprof", "magnets", "ensemble"}


def forecast_learn(con, coin: str, force: bool = False) -> dict:
    """
    Lernstand je Coin: Gewichte alle 15 min aus der Trefferbilanz, Analog-Suche / Zeitprofil /
    Magnet-Statistik stündlich (teuer), Ensemble-Gewichte aus den laufenden Trefferquoten beider
    Modelle. Ergebnisse liegen in forecasts.db (Tabellen weights, learned), damit ein Neustart
    nicht bei null anfängt.
    """
    L = _LEARN.get(coin) or {}
    now = time.time()
    # Gewichte
    if force or now - L.get("w_ts", 0) > 900:
        try:
            w = hl_forecast.calibrate_weights(con, coin)
            prev, _ = hl_forecast.learned_weights_load(coin)
            changed = any(abs((prev.get(k) or {}).get("weight", v["prior"]) - v["weight"]) > 0.02 for k, v in w.items())
            if changed or not prev:
                hl_forecast.learned_weights_save(coin, w)
            w2, wver = hl_forecast.learned_weights_load(coin)
            L["weights"] = w2 or w; L["wver"] = wver or now; L["w_ts"] = now
        except Exception as e:
            L.setdefault("errors", []).append(f"Gewichte: {e}")
    # Teure Bausteine stündlich, aus dem Speicher (learned) wiederverwendet
    for key, fn, age in (("analog", lambda: hl_forecast.analog_forecast(con, coin), 3600),
                         ("tprof", lambda: hl_forecast.time_vol_profile(con, coin), 6 * 3600),
                         ("magnets", lambda: hl_forecast.magnet_stats(con, coin), 3600)):
        if force or now - L.get(key + "_ts", 0) > age:
            val = hl_forecast.learned_load(coin, key, age) if not force else None
            if val is None:
                try:
                    val = fn()
                    if val is not None:
                        hl_forecast.learned_save(coin, key, val)
                except Exception as e:
                    L.setdefault("errors", []).append(f"{key}: {e}"); val = L.get(key)
            L[key] = val; L[key + "_ts"] = now
    # Kapitulation: jedes Mal (billig)
    try:
        L["capitulation"] = hl_forecast.capitulation_signal(con, coin)
    except Exception:
        L["capitulation"] = None
    # Ensemble-Gewichte aus den Trefferquoten beider Modelle (mindestens 30 Prognosen je Modell)
    try:
        sc = hl_forecast.score_forecasts(con, coin, wver=L.get("wver"))
        m, a = sc.get("model") or {}, sc.get("analog") or {}
        if (m.get("n") or 0) >= 30 and (a.get("n") or 0) >= 30 and m.get("hit_rate") is not None and a.get("hit_rate") is not None:
            em, ea = max(m["hit_rate"] - 0.4, 0.05), max(a["hit_rate"] - 0.4, 0.05)
            L["ensemble"] = {"model": round(em / (em + ea), 2), "analog": round(ea / (em + ea), 2), "from": "Trefferquoten"}
        else:
            L["ensemble"] = {"model": 0.6, "analog": 0.4, "from": "Prior (noch zu wenige bewertete Prognosen)"}
        L["score"] = sc
    except Exception as e:
        L.setdefault("errors", []).append(f"Bewertung: {e}")
    # Lernplan: was wurde wann ausgewertet, wann beginnt das Lernen, wann die nächste Prüfung
    try:
        st = hl_forecast.store_connect()
        n_stored = st.execute("SELECT COUNT(*) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        first_ts = st.execute("SELECT MIN(ts) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        last_ts = st.execute("SELECT MAX(ts) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        n_24h = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=? AND ts<=?", (coin, now - 24 * 3600)).fetchone()[0]
        n_4h = st.execute("SELECT COUNT(*) FROM forecast WHERE coin=? AND ts<=?", (coin, now - 4 * 3600)).fetchone()[0]
        n_windows = st.execute("SELECT COUNT(DISTINCT ts/900) FROM forecast WHERE coin=?", (coin,)).fetchone()[0]
        next_4h = st.execute("SELECT MIN(ts) FROM forecast WHERE coin=? AND ts>?", (coin, now - 4 * 3600)).fetchone()[0]
        next_24h = st.execute("SELECT MIN(ts) FROM forecast WHERE coin=? AND ts>?", (coin, now - 24 * 3600)).fetchone()[0]
        ts40 = st.execute("SELECT MIN(ts) FROM (SELECT MIN(ts) ts FROM forecast WHERE coin=? GROUP BY ts/900 ORDER BY ts LIMIT 1 OFFSET 39)", (coin,)).fetchone()
        ts40 = ts40 if ts40 and ts40[0] else None
        w_changed = st.execute("SELECT MAX(updated) FROM weights WHERE coin=?", (coin,)).fetchone()[0]
        comp = {r[0]: r[1] for r in st.execute("SELECT key, updated FROM learned WHERE coin=?", (coin,))}
        st.close()
        if ts40:
            learn_eta = ts40[0] + 24 * 3600                                # die 40. Prognose ist dann 24 h alt
        else:
            learn_eta = int(now + (40 - n_windows) * 900 + 24 * 3600)    # 15-min-Takt bis zum 40. Fenster, dann 24 h Wartezeit
        L["plan"] = {"n_stored": n_stored, "n_windows": n_windows, "first_ts": first_ts, "last_ts": last_ts, "n_scored_24h": n_24h, "n_scored_4h": n_4h,
                     "next_eval_4h": (next_4h + 4 * 3600) if next_4h else None, "next_eval_24h": (next_24h + 24 * 3600) if next_24h else None,
                     "learn_eta": learn_eta, "learning": n_24h >= 40, "w_checked": L.get("w_ts"), "w_changed": w_changed,
                     "next_w_check": (L.get("w_ts") or now) + 900, "components": comp,
                     "next_forecast": (last_ts or now) + 900}
    except Exception as e:
        L.setdefault("errors", []).append(f"Lernplan: {e}")
    L["ts"] = now
    _LEARN[coin] = L
    return L


def forecast_compute(db_path: str, coin: str) -> dict | None:
    con = connect(db_path)
    try:
        chart = load_chart(con, coin, minutes=7 * 1440, agg=60)
        chart = attach_binance(con, chart, coin, 60, 7 * 1440, "fusion")      # Orderbücher, Taker, Funding aller Börsen
        chart = attach_sources(chart, coin, "fusion", con)
        whales = load_whales(con, coin, 72)
        smart = smart_money(con, coin)
        lb = load_leaderboard(con, coin, 20)
        lb_act = load_lb_activity(con, coin, chart.get("price") or 0, days=3)
        etf = chart.get("etf")
        learned = forecast_learn(con, coin)
        fc = hl_forecast.compute_forecast(con, coin, chart, whales, smart, lb, lb_act, etf, chart.get("bnc"), chart.get("cdc"),
                                          chart.get("bybit"), chart.get("okx"), learned=learned)
        if fc:
            hl_forecast.store_forecast(fc)
            fc["score"] = learned.get("score") or hl_forecast.score_forecasts(con, coin, wver=learned.get("wver"))
            fc["learn"] = {"store": hl_forecast.STORE, "weights": learned.get("weights"), "wver": learned.get("wver"), "ensemble": learned.get("ensemble"), "plan": learned.get("plan"),
                           "tprof": bool(learned.get("tprof")), "magnets": learned.get("magnets"), "errors": (learned.get("errors") or [])[-3:],
                           "n_scored": (learned.get("score") or {}).get("n", 0)}
            # jüngste 48 h Stundenkerzen für das Chart
            fc["history"] = [{"t": c["t"], "c": c["c"]} for c in (chart.get("candles") or [])[-48:]]
        return fc
    except Exception as e:
        import traceback
        tb = traceback.extract_tb(e.__traceback__)
        where = f"{os.path.basename(tb[-1].filename)}:{tb[-1].lineno} ({tb[-1].name})" if tb else "?"
        return {"error": f"{type(e).__name__}: {e} — bei {where}", "coin": coin, "ts": int(time.time()), "failed": True,
                "trace": "".join(traceback.format_exception(type(e), e, e.__traceback__))[-2000:]}
    finally:
        con.close()


def forecast_start(db_path: str) -> None:
    with _FC["lock"]:
        if _FC["started"]:
            return
        _FC["started"] = True
    def run():
        time.sleep(15)
        while True:
            try:
                con = connect(db_path)
                coins = [r[0] for r in con.execute("SELECT DISTINCT coin FROM bars ORDER BY coin")]
                con.close()
            except Exception:
                coins = []
            for coin in coins:
                fc = forecast_compute(db_path, coin)
                if fc:
                    with _FC["lock"]:
                        _FC["by_coin"][coin] = fc
            time.sleep(900)
    threading.Thread(target=run, daemon=True).start()


def forecast_watch_start(db_path: str) -> None:
    """
    Alle 30 s: Hat ein DIREKTIONALER Wal seit der letzten Prognose seine Position geändert?
    Dann wird die Prognose für diesen Coin sofort neu gerechnet (höchstens alle 2 min je Coin).
    Wal-Änderungen sind das schnellste Signal -- sie sollen nicht auf den 15-min-Takt warten.
    """
    def run():
        last_run: dict = {}
        time.sleep(45)
        while True:
            try:
                con = connect(db_path)
                bmap = behavior_map(con)
                dir_set = {a for a, cls in bmap.items() if cls.startswith("direktional")}
                with _FC["lock"]:
                    items = list(_FC["by_coin"].items())
                for coin, fc in items:
                    if not fc or fc.get("failed"):
                        continue
                    rows = con.execute("""SELECT addr, ts FROM whale_positions WHERE coin=? AND ts>? AND event IN ('open','add','reduce','close','flip')
                                          ORDER BY ts DESC LIMIT 50""", (coin, fc.get("ts", 0))).fetchall()
                    newest = max((r["ts"] for r in rows if r["addr"].lower() in dir_set), default=None)
                    try:                                                     # Leaderboard-Ereignisse direktionaler Konten
                        lb_dir = hl_forecast.lb_directional_addrs(con, coin)
                        lrows = con.execute("SELECT addr, ts FROM lb_events WHERE coin=? AND ts>? ORDER BY ts DESC LIMIT 50", (coin, fc.get("ts", 0))).fetchall()
                        lnew = max((r["ts"] for r in lrows if r["addr"] in lb_dir), default=None)
                        if lnew and (not newest or lnew > newest):
                            newest = lnew
                    except sqlite3.OperationalError:
                        pass
                    if newest and time.time() - last_run.get(coin, 0) >= 120:
                        last_run[coin] = time.time()
                        fc2 = forecast_compute(db_path, coin)
                        if fc2:
                            fc2["trigger"] = "Wal-/Leaderboard-Flow"
                            with _FC["lock"]:
                                _FC["by_coin"][coin] = fc2
                con.close()
            except Exception:
                pass
            time.sleep(30)
    threading.Thread(target=run, daemon=True).start()


def forecast_get(db_path: str, coin: str) -> dict | None:
    with _FC["lock"]:
        fc = _FC["by_coin"].get(coin)
    if fc and time.time() - fc.get("ts", 0) < (60 if fc.get("failed") else 1200):
        return fc
    # noch nicht berechnet (Start) -> sofort rechnen, damit der Abschnitt nicht leer bleibt
    fc = forecast_compute(db_path, coin)
    if fc:
        with _FC["lock"]:
            _FC["by_coin"][coin] = fc
    return fc


class Handler(BaseHTTPRequestHandler):
    db = DB_PATH

    def _send(self, body: bytes, ctype: str) -> None:
        """
        Antwort senden -- mit Cache-Verbot und, wenn der Browser es kann, gepackt.

        Beides schont die SD-Karte des Pi: Ohne "no-store" legt Firefox jede der alle 5 s
        geholten Antworten in seinen Plattencache (gemessen: 2,4 GB/h auf die Karte, während
        der Recorder nur 0,05 GB/h auf den Stick schrieb). Das Packen senkt zusätzlich die
        Menge um rund 90 % -- JSON mit vielen Zahlen komprimiert sehr gut -- und spart dem
        Handy Funkzeit. Stufe 1: kaum Rechenzeit, fast die volle Ersparnis.
        """
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        if len(body) > 1400 and "gzip" in (self.headers.get("Accept-Encoding") or ""):
            try:
                packed = gzip.compress(body, 1)
                if len(packed) < len(body):
                    body = packed
                    self.send_header("Content-Encoding", "gzip")
                    self.send_header("Vary", "Accept-Encoding")
            except Exception:
                pass
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass                                   # Browser hat die Seite gewechselt

    def do_POST(self) -> None:
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        if u.path == "/update":
            self._send(json.dumps(start_update(UPDATE_URL)).encode(), "application/json")
        elif u.path == "/debug/run":
            qq = parse_qs(u.query)
            self._send(json.dumps(debug_run(qq.get("name", [""])[0], self.db)).encode(), "application/json")
        else:
            self.send_error(404)

    def do_GET(self) -> None:
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        # Antwort-Cache: dieselbe Anfrage innerhalb weniger Sekunden (mehrere Browser, Wiederholungen)
        # bekommt die letzte Antwort -- schützt den Pi vor Anfragestürmen.
        cached = _resp_cache_get(self.path, 4 if u.path == "/chart" else 8 if u.path in ("/data", "/whales") else 0)
        if cached is not None:
            self._send(cached, "application/json")
            return
        try:
            if u.path == "/":
                self._send(PAGE.encode(), "text/html; charset=utf-8")
            elif u.path == "/leaderboard":
                qq = parse_qs(u.query)
                con = connect(self.db)
                payload = load_leaderboard(con, qq.get("coin", ["BTC"])[0], int(qq.get("top", ["20"])[0]), int(qq.get("days", ["7"])[0]))
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/lb_activity":
                qq = parse_qs(u.query)
                con = connect(self.db)
                coin_ = qq.get("coin", ["BTC"])[0]
                row = con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin_,)).fetchone()
                payload = load_lb_activity(con, coin_, float(row[0]) if row else 0, int(qq.get("days", ["3"])[0]))
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/labels":
                qq = parse_qs(u.query)
                addrs = [a for a in qq.get("addrs", [""])[0].split(",") if a.startswith("0x")][:200]
                con = connect(self.db)
                payload = labels_for(con, addrs)
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/forecast":
                qq = parse_qs(u.query)
                self._send(json.dumps(forecast_get(self.db, qq.get("coin", ["BTC"])[0])).encode(), "application/json")
            elif u.path == "/system":
                self._send(json.dumps(sys_status()).encode(), "application/json")
            elif u.path == "/debug/status":
                qq = parse_qs(u.query)
                self._send(json.dumps(debug_status(qq.get("id", [""])[0])).encode(), "application/json")
            elif u.path == "/debug/list":
                self._send(json.dumps({k: v[0] for k, v in debug_commands(self.db).items()}).encode(), "application/json")
            elif u.path == "/update/status":
                self._send(json.dumps(update_status()).encode(), "application/json")
            elif u.path == "/coins":
                con = connect(self.db)
                cs = [r[0] for r in con.execute(
                    "SELECT DISTINCT coin FROM bars ORDER BY coin")]
                con.close()
                self._send(json.dumps(cs or ["BTC"]).encode(), "application/json")
            elif u.path == "/manifest.json":
                self._send(json.dumps({
                    "name": "HL Liquidationen", "short_name": "HL Liq",
                    "start_url": "/", "display": "standalone",
                    "background_color": "#0d1117", "theme_color": "#0d1117",
                    "icons": [{"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}],
                }).encode(), "application/manifest+json")
            elif u.path == "/icon.svg":
                self._send(ICON_SVG.encode(), "image/svg+xml")
            elif u.path == "/health":
                self._send(json.dumps(load_health(self.db)).encode(), "application/json")
            elif u.path == "/whales":
                q = parse_qs(u.query)
                con = connect(self.db)
                payload = load_whales(con, q.get("coin", ["BTC"])[0],
                                      int(q.get("hours", ["72"])[0]))
                con.close()
                body = json.dumps(payload).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/chart":
                q = parse_qs(u.query)
                con = connect(self.db)
                src = q.get("src", ["hl"])[0]
                coin_ = q.get("coin", ["BTC"])[0]; mins_ = int(q.get("minutes", ["240"])[0]); agg_ = int(q.get("agg", ["1"])[0])
                payload = load_chart(con, coin_, mins_, agg_, fvg_min=float(q.get("fvg", ["0.0005"])[0]))
                if src in ("bnc", "fusion"):
                    payload = attach_binance(con, payload, coin_, agg_, mins_, src)
                try:
                    payload = attach_sources(payload, coin_, src, con)
                except Exception as e:                       # Zusatzquellen dürfen den Chart nie verhindern
                    payload["sources_error"] = str(e)[:200]
                con.close()
                body = json.dumps(payload).encode()
                _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            elif u.path == "/data":
                q = parse_qs(u.query)
                coin = q.get("coin", ["BTC"])[0]
                hours = int(q.get("hours", ["24"])[0])
                con = connect(self.db)
                span = con.execute("SELECT MIN(ts) a, MAX(ts) b FROM bars").fetchone()
                stats = {
                    "addresses": con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0],
                    "positions": con.execute(
                        "SELECT COUNT(*) FROM addresses WHERE notional>0").fetchone()[0],
                    "days": ((span["b"] - span["a"]) / 86400) if span["a"] else 0,
                }
                src = q.get("src", ["hl"])[0]
                if src == "bnc":
                    payload = {"grid": bnc_grid(con, coin, hours), "depth": bnc_depth(con, coin), "stats": stats,
                               "metrics": bnc_metrics_series(con, coin, max(hours, 24)), "src": "bnc"}
                else:
                    payload = {"grid": load_grid(con, coin, hours),
                               "depth": load_depth(con, coin), "stats": stats, "src": src}
                    if src == "fusion":
                        payload["bnc"] = {"grid_liqs": bnc_grid(con, coin, hours)["liqs"], "depth": bnc_depth(con, coin),
                                          "metrics": bnc_metrics_series(con, coin, max(hours, 24))}
                con.close()
                body = json.dumps(payload).encode(); _resp_cache_put(self.path, body)
                self._send(body, "application/json")
            else:
                self.send_error(404)
        except Exception as e:
            self.send_error(500, str(e))

    def log_message(self, *a) -> None:
        pass


def prewarm() -> None:
    """Langsame externe Quellen beim Start im Hintergrund laden, damit die Kacheln sofort stehen."""
    for coin in ("BTC", "ETH"):
        _warm(("etf", coin), lambda c=coin: etf_flows(c))


def serve(db: str, port: int, host: str = "127.0.0.1") -> None:
    prewarm()
    sys_monitor_start(db)
    forecast_start(db)
    forecast_watch_start(db)
    Handler.db = db
    try:
        srv = ThreadingHTTPServer((host, port), Handler)   # eine langsame Anfrage blockiert nicht die anderen
        srv.daemon_threads = True
    except OSError as e:
        if e.errno == 98:                      # EADDRINUSE
            print(f"Port {port} ist bereits belegt.\n")
            print("Meist läuft das Dashboard schon — als systemd-Dienst oder aus")
            print("einem früheren Aufruf. Beides zusammen geht nicht.\n")
            print("  Wer hält den Port?     sudo ss -ltnp | grep " + str(port))
            print("  Dienst-Status:         systemctl status hl-dashboard")
            print("  Dienst anhalten:       sudo systemctl stop hl-dashboard")
            print(f"  oder anderen Port:     --port {port + 1}")
            raise SystemExit(2)
        raise
    if host not in ("127.0.0.1", "localhost"):
        print("Achtung: Das Dashboard ist im Netzwerk erreichbar und hat keine "
              "Authentifizierung. Nur im vertrauenswürdigen Heimnetz nutzen.")
    print(f"Dashboard: http://{host}:{port}  (Strg-C beendet)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbeendet")


# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Visualisierung der Liquidationsdaten")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--coin", default="BTC")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--depth", action="store_true", help="aktuellen Snapshot zeichnen")
    p.add_argument("--threshold", type=float, default=0.70,
                   help="Perzentil-Schwelle: darunter wird nichts gezeichnet")
    p.add_argument("--out", default=None)
    p.add_argument("--serve", action="store_true")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--update-url", default=UPDATE_URL,
                   help="Archiv für den Update-Knopf (GitHub blob- oder raw-Link)")
    p.add_argument("--host", default="127.0.0.1",
                   help="0.0.0.0 macht das Dashboard im LAN erreichbar (Pi!)")
    args = p.parse_args()

    if args.serve:
        globals()["UPDATE_URL"] = args.update_url
        serve(args.db, args.port, args.host)
        return

    con = connect(args.db)
    if args.depth:
        plot_depth(con, args.coin, args.out or f"{args.coin}_depth.png")
    else:
        plot_heatmap(con, args.coin, args.hours,
                     args.out or f"{args.coin}_heatmap.png", args.threshold)
    con.close()


if __name__ == "__main__":
    main()
