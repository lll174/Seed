#!/usr/bin/env python3
"""
hl_viz.py — Visualisierung für die von hl_recorder.py aufgezeichneten Daten.

Drei Modi:
    python hl_viz.py --coin BTC                  # Heatmap als PNG
    python hl_viz.py --coin BTC --depth          # aktueller Snapshot als Balken
    python hl_viz.py --serve                     # Live-Dashboard im Browser

Das Dashboard läuft parallel zum Recorder auf derselben SQLite-Datei
(WAL-Modus, gleichzeitiges Lesen ist unproblematisch) und aktualisiert sich
selbst. Es braucht keine Internetverbindung und keine JS-Bibliotheken.
"""

from __future__ import annotations

import argparse
import json
import math
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

DB_PATH = "hl_liq.db"


def connect(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    return con


# ---------------------------------------------------------------------------
# Datenabfrage
# ---------------------------------------------------------------------------

def load_grid(con, coin: str, hours: int):
    """Heatmap als Gitter (Zeitachse x Preisachse) plus Preisreihe."""
    t_from = int(time.time()) - hours * 3600

    heat = con.execute(
        "SELECT ts, bucket_px, side, notional FROM heatmap "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    bars = con.execute(
        "SELECT ts, open, high, low, close, volume FROM bars "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    liqs = con.execute(
        "SELECT ts, px, sz, side FROM liquidations "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()

    if not heat or not bars:
        return None

    times = sorted({r["ts"] for r in heat})
    levels = sorted({r["bucket_px"] for r in heat})
    t_idx = {t: i for i, t in enumerate(times)}
    l_idx = {p: i for i, p in enumerate(levels)}

    grid = [[0.0] * len(times) for _ in levels]
    sides = [[""] * len(times) for _ in levels]
    for r in heat:
        i, j = l_idx[r["bucket_px"]], t_idx[r["ts"]]
        grid[i][j] += r["notional"]
        sides[i][j] = r["side"]

    return {
        "times": times, "levels": levels, "grid": grid, "sides": sides,
        "price": [(r["ts"], r["close"]) for r in bars],
        "liqs": [(r["ts"], r["px"], r["px"] * r["sz"], r["side"]) for r in liqs],
    }


def load_depth(con, coin: str):
    """Aktuellster Snapshot: Cluster ober- und unterhalb des Kurses."""
    row = con.execute(
        "SELECT MAX(ts) t FROM heatmap WHERE coin=?", (coin,)).fetchone()
    if not row or not row["t"]:
        return None
    ts = row["t"]
    rows = con.execute(
        "SELECT bucket_px, side, notional, n_pos FROM heatmap "
        "WHERE coin=? AND ts=? ORDER BY bucket_px", (coin, ts)).fetchall()
    px = con.execute(
        "SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1",
        (coin,)).fetchone()
    vol = con.execute(
        "SELECT SUM(volume*close) v FROM bars WHERE coin=? AND ts>=?",
        (coin, ts - 3600)).fetchone()
    return {
        "ts": ts,
        "price": px["close"] if px else None,
        "vol_1h": (vol["v"] or 0) if vol else 0,
        "rows": [dict(r) for r in rows],
    }


# ---------------------------------------------------------------------------
# Statische Grafiken
# ---------------------------------------------------------------------------

def load_chart(con, coin: str, minutes: int = 240, agg: int = 1, top: int = 14):
    """Kerzen aus den 1-Minuten-Bars plus die stärksten aktuellen Level."""
    t_from = int(time.time()) - minutes * 60
    rows = con.execute(
        "SELECT ts, open, high, low, close, volume FROM bars "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()

    candles, cur = [], None
    step = max(agg, 1) * 60
    for r in rows:
        b = r["ts"] // step * step
        if cur is None or b != cur["t"]:
            if cur:
                candles.append(cur)
            cur = {"t": b, "o": r["open"], "h": r["high"],
                   "l": r["low"], "c": r["close"], "v": r["volume"]}
        else:
            cur["h"] = max(cur["h"], r["high"])
            cur["l"] = min(cur["l"], r["low"])
            cur["c"] = r["close"]
            cur["v"] += r["volume"]
    if cur:
        candles.append(cur)

    d = load_depth(con, coin)
    levels = []
    if d and d["price"]:
        px = d["price"]
        near = [r for r in d["rows"] if 0.88 * px < r["bucket_px"] < 1.15 * px]
        near.sort(key=lambda r: -r["notional"])
        for r in near[:top]:
            levels.append({
                "px": r["bucket_px"], "side": r["side"],
                "notional": r["notional"], "n_pos": r["n_pos"],
                "dist": (r["bucket_px"] - px) / px,
                # Verhältnis zum Stundenvolumen: entscheidet, ob ein Level trägt
                "x_vol": (r["notional"] / d["vol_1h"]) if d["vol_1h"] else 0,
            })

    return {
        "candles": candles, "levels": levels,
        "price": d["price"] if d else None,
        "vol_1h": d["vol_1h"] if d else 0,
        "snapshot_ts": d["ts"] if d else 0,
    }


def plot_heatmap(con, coin: str, hours: int, out: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.colors import LogNorm
    from matplotlib.dates import DateFormatter, date2num

    d = load_grid(con, coin, hours)
    if d is None:
        print(f"Keine Daten für {coin} in den letzten {hours} h.")
        return

    z = np.array(d["grid"])
    z = np.ma.masked_where(z <= 0, z)
    x = date2num([np.datetime64(t, "s") for t in d["times"]])
    y = np.array(d["levels"])

    fig, ax = plt.subplots(figsize=(15, 8.5))
    mesh = ax.pcolormesh(x, y, z, norm=LogNorm(vmin=max(z.min(), 1e4), vmax=z.max()),
                         cmap="inferno", shading="nearest", alpha=0.92)

    pt = date2num([np.datetime64(t, "s") for t, _ in d["price"]])
    ax.plot(pt, [p for _, p in d["price"]], color="#00e5ff", lw=1.4,
            label="Kurs", zorder=5)

    if d["liqs"]:
        lt = date2num([np.datetime64(t, "s") for t, *_ in d["liqs"]])
        lp = [p for _, p, *_ in d["liqs"]]
        ls = [max(6, min(220, n / 4000)) for *_, n, _ in d["liqs"]]
        ax.scatter(lt, lp, s=ls, facecolor="none", edgecolor="#39ff14",
                   lw=1.1, zorder=6, label="Liquidationen")

    # Preisachse auf den relevanten Bereich beschränken
    prices = [p for _, p in d["price"]]
    lo, hi = min(prices), max(prices)
    ax.set_ylim(lo * 0.90, hi * 1.10)

    ax.xaxis.set_major_formatter(DateFormatter("%d.%m %H:%M"))
    ax.set_title(f"{coin} — Liquidationscluster, letzte {hours} h "
                 f"({len(d['times'])} Snapshots)", fontsize=13)
    ax.set_ylabel("Preis")
    ax.grid(alpha=0.15, ls=":")
    ax.legend(loc="upper left", framealpha=0.8)
    fig.colorbar(mesh, ax=ax, label="Liquidations-Notional (USD, log)", pad=0.01)
    fig.autofmt_xdate()
    plt.tight_layout()
    plt.savefig(out, dpi=130)
    print(f"Gespeichert: {out}")


def plot_depth(con, coin: str, out: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    d = load_depth(con, coin)
    if not d or not d["rows"] or not d["price"]:
        print(f"Kein aktueller Snapshot für {coin}.")
        return

    px, v1h = d["price"], d["vol_1h"]
    rows = [r for r in d["rows"] if 0.8 * px < r["bucket_px"] < 1.25 * px]
    if not rows:
        print("Keine Cluster im relevanten Preisbereich.")
        return

    fig, ax = plt.subplots(figsize=(9, 11))
    for r in rows:
        col = "#e04b4b" if r["side"] == "long" else "#3ba55d"
        ax.barh(r["bucket_px"], r["notional"], height=px * 0.0022,
                color=col, alpha=0.85)

    ax.axhline(px, color="#00e5ff", lw=2)
    ax.text(ax.get_xlim()[1], px, f"  {px:,.2f}", va="center",
            color="#00808f", fontsize=10, fontweight="bold")

    if v1h > 0:
        ax.axvline(v1h * 0.5, color="grey", ls="--", lw=1)
        ax.text(v1h * 0.5, ax.get_ylim()[1], " 0.5x 1h-Vol",
                rotation=90, va="top", fontsize=8, color="grey")

    ax.set_title(f"{coin} — Cluster um den Kurs\n"
                 f"rot = Long-Liquidationen, grün = Short-Liquidationen\n"
                 f"Stand {time.strftime('%d.%m. %H:%M', time.localtime(d['ts']))}",
                 fontsize=11)
    ax.set_xlabel("Notional (USD)")
    ax.grid(axis="x", alpha=0.2, ls=":")
    plt.tight_layout()
    plt.savefig(out, dpi=130)
    print(f"Gespeichert: {out}")


# ---------------------------------------------------------------------------
# Live-Dashboard
# ---------------------------------------------------------------------------

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<title>HL Liquidationen</title>
<style>
 body{background:#0d1117;color:#c9d1d9;font:13px system-ui,sans-serif;margin:0;padding:16px}
 h1{font-size:16px;margin:0 0 4px} .sub{color:#8b949e;font-size:11px;margin-bottom:14px}
 canvas{background:#010409;border:1px solid #21262d;border-radius:6px;width:100%}
 .row{display:flex;gap:16px;flex-wrap:wrap} .col{flex:1;min-width:320px}
 select,button{background:#21262d;color:#c9d1d9;border:1px solid #30363d;
   border-radius:5px;padding:5px 9px;font-size:12px;margin-right:6px}
 .kpi{display:flex;gap:22px;margin:10px 0}
 .kpi div span{display:block;color:#8b949e;font-size:10px;text-transform:uppercase}
 .kpi b{font-size:17px;font-weight:600}
 .warn{color:#d29922;font-size:11px;margin-top:10px}
</style></head><body>
<h1>Hyperliquid — Liquidationscluster</h1>
<div class="sub">Aktualisiert sich alle 20 s aus der laufenden Aufzeichnung.</div>
<div><select id="coin"></select>
 <select id="hours"><option value="6">6 h</option><option value="24" selected>24 h</option>
 <option value="72">3 T</option><option value="168">7 T</option></select>
 <select id="tf"><option value="1|120">1 min / 2 h</option>
  <option value="5|720" selected>5 min / 12 h</option>
  <option value="15|2880">15 min / 2 T</option>
  <option value="60|10080">1 h / 7 T</option></select>
 <button onclick="load()">Neu laden</button></div>
<div class="kpi" id="kpi"></div>
<canvas id="chart" height="400"></canvas>
<div class="sub" id="chartinfo" style="margin:6px 0 14px"></div>
<div class="row">
 <div class="col" style="flex:2"><canvas id="heat" height="440"></canvas></div>
 <div class="col"><canvas id="depth" height="440"></canvas></div>
</div>
<div class="warn" id="warn"></div>
<script>
const $=id=>document.getElementById(id);
function fit(c){const r=c.getBoundingClientRect();const d=devicePixelRatio||1;
 c.width=r.width*d;c.height=c.height*d;const x=c.getContext('2d');x.scale(d,d);
 return [x,r.width,c.height/d];}
function fmt(n){return n>=1e9?(n/1e9).toFixed(2)+'B':n>=1e6?(n/1e6).toFixed(1)+'M'
 :n>=1e3?(n/1e3).toFixed(0)+'k':n.toFixed(0);}

function drawChart(d){
 const [g,W,H]=fit($('chart')); g.clearRect(0,0,W,H);
 if(!d||!d.candles.length){g.fillStyle='#8b949e';
  g.fillText('noch keine Kursdaten — der Recorder muss erst laufen',12,24);return;}
 const C=d.candles, L=(d.levels||[]);
 const R=64,Lm=8,T=12,B=22, pw=W-Lm-R, ph=H-T-B;
 // Preisbereich aus Kerzen, erweitert um nahe Level
 let lo=Math.min(...C.map(c=>c.l)), hi=Math.max(...C.map(c=>c.h));
 L.forEach(l=>{if(Math.abs(l.dist)<0.035){lo=Math.min(lo,l.px);hi=Math.max(hi,l.px);}});
 const pad=(hi-lo)*0.08||1; lo-=pad; hi+=pad;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 const cw=Math.max(1.5,pw/C.length), bw=Math.max(1,cw*0.62);

 g.strokeStyle='#161b22';g.lineWidth=1;
 for(let k=0;k<=5;k++){const y=T+ph*k/5;g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();}

 // Liquidationslevels als waagerechte Linien
 const mxN=Math.max(...L.map(l=>l.notional),1);
 L.forEach(l=>{const y=Y(l.px); if(y<T||y>H-B)return;
  const a=0.25+0.65*(l.notional/mxN);
  g.strokeStyle=l.side==='long'?`rgba(224,75,75,${a})`:`rgba(59,165,93,${a})`;
  g.lineWidth=l.x_vol>=0.5?2:1;
  g.setLineDash(l.x_vol>=0.5?[]:[3,3]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle=l.side==='long'?'#e04b4b':'#3ba55d';g.font='9px system-ui';
  g.fillText(fmt(l.notional),W-R+3,y-2);
  g.fillStyle='#6e7681';g.fillText((l.dist*100).toFixed(1)+'%',W-R+3,y+8);});

 // Kerzen
 C.forEach((c,i)=>{const x=Lm+i*cw+cw/2, up=c.c>=c.o;
  g.strokeStyle=up?'#3ba55d':'#e04b4b'; g.fillStyle=g.strokeStyle;
  g.lineWidth=1; g.beginPath();g.moveTo(x,Y(c.h));g.lineTo(x,Y(c.l));g.stroke();
  const y1=Y(Math.max(c.o,c.c)),y2=Y(Math.min(c.o,c.c));
  g.fillRect(x-bw/2,y1,bw,Math.max(1,y2-y1));});

 // aktueller Kurs
 if(d.price){const y=Y(d.price);
  g.strokeStyle='#00e5ff';g.lineWidth=1;g.setLineDash([5,4]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle='#00e5ff';g.fillRect(W-R,y-7,R,14);
  g.fillStyle='#010409';g.font='bold 10px system-ui';
  g.fillText(d.price.toFixed(d.price<10?4:2),W-R+3,y+3);}

 g.fillStyle='#6e7681';g.font='9px system-ui';
 const t0=new Date(C[0].t*1000),t1=new Date(C[C.length-1].t*1000);
 const hm=x=>x.getHours().toString().padStart(2,'0')+':'+x.getMinutes().toString().padStart(2,'0');
 g.fillText(hm(t0),Lm,H-6); g.fillText(hm(t1),W-R-28,H-6);
 $('chartinfo').textContent=
  `${C.length} Kerzen · ${L.length} Level eingezeichnet · durchgezogen = mindestens `
  +`halbes Stundenvolumen, gestrichelt = darunter (wird eher absorbiert)`;
}

function drawHeat(d){
 const [g,W,H]=fit($('heat')); g.clearRect(0,0,W,H);
 if(!d||!d.times.length){g.fillStyle='#8b949e';g.fillText('keine Daten',12,22);return;}
 const P=d.price.map(p=>p[1]), lo=Math.min(...P)*0.94, hi=Math.max(...P)*1.06;
 const L=40,R=12,T=10,B=22, pw=W-L-R, ph=H-T-B;
 const X=t=>L+(t-d.times[0])/(d.times[d.times.length-1]-d.times[0]+1)*pw;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 let mx=0; d.grid.forEach(r=>r.forEach(v=>{if(v>mx)mx=v}));
 const cw=Math.max(1.5,pw/d.times.length), chh=Math.max(1.5,ph*0.0025/((hi-lo)/hi));
 d.grid.forEach((row,i)=>{const y=Y(d.levels[i]); if(y<T-4||y>H-B+4)return;
  row.forEach((v,j)=>{ if(v<=0)return;
   const a=Math.log10(1+v)/Math.log10(1+mx);
   g.fillStyle=`hsla(${45-38*a},100%,${18+42*a}%,${0.25+0.7*a})`;
   g.fillRect(X(d.times[j]),y-chh/2,cw,chh);});});
 g.strokeStyle='#00e5ff';g.lineWidth=1.5;g.beginPath();
 d.price.forEach((p,i)=>{const x=X(p[0]),y=Y(p[1]);i?g.lineTo(x,y):g.moveTo(x,y)});
 g.stroke();
 g.strokeStyle='#39ff14';g.lineWidth=1;
 d.liqs.forEach(l=>{const r=Math.max(2,Math.min(14,l[2]/6000));
  g.beginPath();g.arc(X(l[0]),Y(l[1]),r,0,7);g.stroke();});
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=4;k++){const p=lo+(hi-lo)*k/4;g.fillText(p.toFixed(0),4,Y(p)+3);}
}

function drawDepth(d){
 const [g,W,H]=fit($('depth')); g.clearRect(0,0,W,H);
 if(!d||!d.rows.length){g.fillStyle='#8b949e';g.fillText('kein Snapshot',12,22);return;}
 const px=d.price, rows=d.rows.filter(r=>r.bucket_px>px*0.85&&r.bucket_px<px*1.18);
 if(!rows.length)return;
 const lo=px*0.85, hi=px*1.18, mx=Math.max(...rows.map(r=>r.notional));
 const L=52,R=10,T=10,B=20, pw=W-L-R, ph=H-T-B;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 rows.forEach(r=>{const w=r.notional/mx*pw, y=Y(r.bucket_px);
  g.fillStyle=r.side==='long'?'rgba(224,75,75,.85)':'rgba(59,165,93,.85)';
  g.fillRect(L,y-2,w,4);});
 if(d.vol_1h>0){const x=L+(d.vol_1h*0.5)/mx*pw;
  if(x<W-R){g.strokeStyle='#8b949e';g.setLineDash([4,4]);g.beginPath();
   g.moveTo(x,T);g.lineTo(x,H-B);g.stroke();g.setLineDash([]);
   g.fillStyle='#8b949e';g.font='9px system-ui';g.fillText('0.5x Vol',x+3,T+10);}}
 g.strokeStyle='#00e5ff';g.lineWidth=2;g.beginPath();
 g.moveTo(L,Y(px));g.lineTo(W-R,Y(px));g.stroke();
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=6;k++){const p=lo+(hi-lo)*k/6;g.fillText(p.toFixed(0),4,Y(p)+3);}
}

async function loadChart(){
 const coin=$('coin').value, [agg,mins]=$('tf').value.split('|');
 try{
  const r=await fetch(`/chart?coin=${coin}&agg=${agg}&minutes=${mins}`);
  drawChart(await r.json());
 }catch(e){}
}

async function load(){
 loadChart();
 const coin=$('coin').value, h=$('hours').value;
 const r=await fetch(`/data?coin=${coin}&hours=${h}`); const d=await r.json();
 drawHeat(d.grid); drawDepth(d.depth);
 const dp=d.depth||{rows:[]};
 const up=dp.rows.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
 const dn=dp.rows.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0);
 $('kpi').innerHTML=`
  <div><span>Kurs</span><b>${dp.price?dp.price.toLocaleString():'—'}</b></div>
  <div><span>Short-Liqs darüber</span><b style="color:#3ba55d">${fmt(up)}</b></div>
  <div><span>Long-Liqs darunter</span><b style="color:#e04b4b">${fmt(dn)}</b></div>
  <div><span>Volumen 1 h</span><b>${fmt(dp.vol_1h||0)}</b></div>
  <div><span>Adressen</span><b>${d.stats.addresses.toLocaleString()}</b></div>
  <div><span>Positionen</span><b>${d.stats.positions.toLocaleString()}</b></div>`;
 $('warn').textContent=d.stats.days<14
  ? `Aufzeichnung läuft erst ${d.stats.days.toFixed(1)} Tage — die Abdeckung `
    +`der Adressen ist noch unvollständig, absolute Zahlen sind zu niedrig.`:'';
}
fetch('/coins').then(r=>r.json()).then(cs=>{
 $('coin').innerHTML=cs.map(c=>`<option>${c}</option>`).join('');
 load(); setInterval(load,20000); setInterval(loadChart,5000);
 $('coin').onchange=$('hours').onchange=load;
 $('tf').onchange=loadChart;
 addEventListener('resize',()=>{loadChart();});
});
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    db = DB_PATH

    def _send(self, body: bytes, ctype: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        try:
            if u.path == "/":
                self._send(PAGE.encode(), "text/html; charset=utf-8")
            elif u.path == "/coins":
                con = connect(self.db)
                cs = [r[0] for r in con.execute(
                    "SELECT DISTINCT coin FROM bars ORDER BY coin")]
                con.close()
                self._send(json.dumps(cs or ["BTC"]).encode(), "application/json")
            elif u.path == "/chart":
                q = parse_qs(u.query)
                con = connect(self.db)
                payload = load_chart(
                    con,
                    q.get("coin", ["BTC"])[0],
                    int(q.get("minutes", ["240"])[0]),
                    int(q.get("agg", ["1"])[0]))
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/data":
                q = parse_qs(u.query)
                coin = q.get("coin", ["BTC"])[0]
                hours = int(q.get("hours", ["24"])[0])
                con = connect(self.db)
                span = con.execute("SELECT MIN(ts) a, MAX(ts) b FROM bars").fetchone()
                stats = {
                    "addresses": con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0],
                    "positions": con.execute(
                        "SELECT COUNT(*) FROM addresses WHERE notional>0").fetchone()[0],
                    "days": ((span["b"] - span["a"]) / 86400) if span["a"] else 0,
                }
                payload = {"grid": load_grid(con, coin, hours),
                           "depth": load_depth(con, coin), "stats": stats}
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            else:
                self.send_error(404)
        except Exception as e:
            self.send_error(500, str(e))

    def log_message(self, *a) -> None:
        pass


def serve(db: str, port: int, host: str = "127.0.0.1") -> None:
    Handler.db = db
    srv = HTTPServer((host, port), Handler)
    if host not in ("127.0.0.1", "localhost"):
        print("Achtung: Das Dashboard ist im Netzwerk erreichbar und hat keine "
              "Authentifizierung. Nur im vertrauenswürdigen Heimnetz nutzen.")
    print(f"Dashboard: http://{host}:{port}  (Strg-C beendet)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbeendet")


# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Visualisierung der Liquidationsdaten")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--coin", default="BTC")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--depth", action="store_true", help="aktuellen Snapshot zeichnen")
    p.add_argument("--out", default=None)
    p.add_argument("--serve", action="store_true")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--host", default="127.0.0.1",
                   help="0.0.0.0 macht das Dashboard im LAN erreichbar (Pi!)")
    args = p.parse_args()

    if args.serve:
        serve(args.db, args.port, args.host)
        return

    con = connect(args.db)
    if args.depth:
        plot_depth(con, args.coin, args.out or f"{args.coin}_depth.png")
    else:
        plot_heatmap(con, args.coin, args.hours,
                     args.out or f"{args.coin}_heatmap.png")
    con.close()


if __name__ == "__main__":
    main()
