#!/usr/bin/env python3
"""
hl_viz.py — Visualisierung für die von hl_recorder.py aufgezeichneten Daten.

Drei Modi:
    python hl_viz.py --coin BTC                  # Heatmap als PNG
    python hl_viz.py --coin BTC --depth          # aktueller Snapshot als Balken
    python hl_viz.py --serve                     # Live-Dashboard im Browser

Das Dashboard läuft parallel zum Recorder auf derselben SQLite-Datei
(WAL-Modus, gleichzeitiges Lesen ist unproblematisch) und aktualisiert sich
selbst. Es braucht keine Internetverbindung und keine JS-Bibliotheken.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import math
import sqlite3
import time
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB_PATH = "hl_liq.db"


def connect(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA temp_store=MEMORY")      # Sortierpuffer im RAM, nicht auf der SD-Karte
    return con


# ---------------------------------------------------------------------------
# Datenabfrage
# ---------------------------------------------------------------------------

def load_grid(con, coin: str, hours: int):
    """Heatmap als Gitter (Zeitachse x Preisachse) plus Preisreihe."""
    t_from = int(time.time()) - hours * 3600

    heat = con.execute(
        "SELECT ts, bucket_px, side, notional FROM heatmap "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    bars = con.execute(
        "SELECT ts, open, high, low, close, volume FROM bars "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
    liqs = con.execute(
        "SELECT ts, px, sz, side FROM liquidations "
        "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()

    if not heat or not bars:
        return None

    times = sorted({r["ts"] for r in heat})
    levels = sorted({r["bucket_px"] for r in heat})
    t_idx = {t: i for i, t in enumerate(times)}
    l_idx = {p: i for i, p in enumerate(levels)}

    grid = [[0.0] * len(times) for _ in levels]
    sides = [[""] * len(times) for _ in levels]
    for r in heat:
        i, j = l_idx[r["bucket_px"]], t_idx[r["ts"]]
        grid[i][j] += r["notional"]
        sides[i][j] = r["side"]

    return {
        "times": times, "levels": levels, "grid": grid, "sides": sides,
        "price": [(r["ts"], r["close"]) for r in bars],
        "liqs": [(r["ts"], r["px"], r["px"] * r["sz"], r["side"]) for r in liqs],
    }


def bnc_grid(con, coin: str, hours: int) -> dict:
    """Heatmap der EINGETRETENEN Binance-Liquidationen: 10-min-Spalten x 0,25-%-Preisstufen."""
    now = int(time.time()); t_from = now - hours * 3600
    liqs = bnc_liqs(con, coin, t_from)
    cand, _ = bnc_candles(con, coin, 5, hours * 60)
    times = list(range(t_from // 600 * 600, now + 600, 600))
    t_idx = {t: i for i, t in enumerate(times)}
    cells: dict = {}
    for ts, px, usd, side in liqs:
        cells.setdefault((bucket_px(px), ts // 600 * 600), [0.0, side])
        cells[(bucket_px(px), ts // 600 * 600)][0] += usd
    levels = sorted({b for b, _ in cells})
    l_idx = {p: i for i, p in enumerate(levels)}
    grid = [[0.0] * len(times) for _ in levels]; sides = [[""] * len(times) for _ in levels]
    for (b, t), (usd, side) in cells.items():
        if t in t_idx:
            grid[l_idx[b]][t_idx[t]] += usd; sides[l_idx[b]][t_idx[t]] = side
    return {"times": times, "levels": levels, "grid": grid, "sides": sides,
            "price": [(c["t"], c["c"]) for c in cand], "liqs": [(ts, px, usd, "A" if side == "long" else "B") for ts, px, usd, side in liqs],
            "realized": True}


def bnc_depth(con, coin: str, hours: int = 24) -> dict:
    """Momentaufnahme der eingetretenen Liquidationen der letzten Stunden, je Preisstufe und Seite."""
    now = int(time.time()); liqs = bnc_liqs(con, coin, now - hours * 3600)
    agg: dict = {}
    for ts, px, usd, side in liqs:
        c = agg.setdefault((bucket_px(px), side), {"bucket_px": bucket_px(px), "side": side, "notional": 0.0, "n_pos": 0})
        c["notional"] += usd; c["n_pos"] += 1
    cand, _ = bnc_candles(con, coin, 1, 120)
    price = cand[-1]["c"] if cand else None
    vol_1h = sum(c["v"] * c["c"] for c in cand[-60:]) if cand else 0
    return {"rows": sorted(agg.values(), key=lambda r: r["bucket_px"]), "price": price, "vol_1h": vol_1h,
            "ts": max((l[0] for l in liqs), default=now), "realized": True, "hours": hours}


def load_depth(con, coin: str):
    """Aktuellster Snapshot: Cluster ober- und unterhalb des Kurses."""
    row = con.execute(
        "SELECT MAX(ts) t FROM heatmap WHERE coin=?", (coin,)).fetchone()
    if not row or not row["t"]:
        return None
    ts = row["t"]
    rows = con.execute(
        "SELECT bucket_px, side, notional, n_pos FROM heatmap "
        "WHERE coin=? AND ts=? ORDER BY bucket_px", (coin, ts)).fetchall()
    px = con.execute(
        "SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1",
        (coin,)).fetchone()
    vol = con.execute(
        "SELECT SUM(volume*close) v FROM bars WHERE coin=? AND ts>=?",
        (coin, ts - 3600)).fetchone()
    return {
        "ts": ts,
        "price": px["close"] if px else None,
        "vol_1h": (vol["v"] or 0) if vol else 0,
        "rows": [dict(r) for r in rows],
    }


# ---------------------------------------------------------------------------
# Statische Grafiken
# ---------------------------------------------------------------------------

def load_whales(con, coin: str, hours: int = 72):
    """Aktuelle Wale, Ereignisse und Netto-Exposure-Zeitreihe."""
    try:
        con.execute("SELECT 1 FROM whale_positions LIMIT 1")
    except sqlite3.OperationalError:
        return {"current": [], "events": [], "exposure": [], "price": []}
    t_from = int(time.time()) - hours * 3600

    # letzter Zustand je Wal: jüngste Zeile, die kein close ist
    current = con.execute("""
        SELECT w.addr, w.coin, w.side, w.size, w.pos_value, w.entry_px, w.liq_px,
               w.leverage, w.upnl, w.mark_px, w.ts,
               (SELECT MIN(ts) FROM whale_positions o
                 WHERE o.addr=w.addr AND o.coin=w.coin AND o.event='open'
                   AND o.ts <= w.ts
                   AND NOT EXISTS (SELECT 1 FROM whale_positions c
                                   WHERE c.addr=w.addr AND c.coin=w.coin
                                     AND c.event='close' AND c.ts>o.ts AND c.ts<=w.ts))
               AS opened_at
        FROM whale_positions w
        WHERE w.ts = (SELECT MAX(ts) FROM whale_positions x
                      WHERE x.addr=w.addr AND x.coin=w.coin)
          AND w.event != 'close'
        ORDER BY w.pos_value DESC""").fetchall()

    events = con.execute("""
        SELECT ts, addr, event, side, pos_value, delta_usd, mark_px, leverage
        FROM whale_positions
        WHERE coin=? AND ts>=? AND event != 'snap' ORDER BY ts""",
        (coin, t_from)).fetchall()

    # Netto-Exposure je Snapshot: long positiv, short negativ
    exposure = con.execute("""
        SELECT ts,
               SUM(CASE WHEN side='long'  THEN pos_value ELSE 0 END) AS long_usd,
               SUM(CASE WHEN side='short' THEN pos_value ELSE 0 END) AS short_usd,
               COUNT(*) AS n
        FROM whale_positions
        WHERE coin=? AND ts>=? AND event='snap'
        GROUP BY ts ORDER BY ts""", (coin, t_from)).fetchall()

    price = con.execute(
        "SELECT ts, close FROM bars WHERE coin=? AND ts>=? ORDER BY ts",
        (coin, t_from)).fetchall()[::5]          # jede 5. Minute reicht fürs Bild

    return {
        "current": [dict(r) for r in current],
        "events": [dict(r) for r in events],
        "exposure": [dict(r) for r in exposure],
        "price": [(r["ts"], r["close"]) for r in price],
    }


def load_stops(con, coin: str, price: float) -> dict:
    """
    Aktuelle Orders der Wale und Großkonten (>= 1 Mio) für einen Coin: je Adresse die jüngste Abfrage der
    letzten 20 Minuten. Daraus Cluster je Preis-Bucket (0,25 %-Raster) für
    stop_sell (Verkaufskaskade nach unten), stop_buy (Kaufkaskade nach oben),
    tp_* (absorbieren) und limit_* (ruhende Liquidität).
    """
    out = {"orders": [], "clusters": [], "n_whales": 0, "ts": None}
    try:
        rows = con.execute("""
            SELECT t.* FROM trigger_orders t
            JOIN (SELECT addr, MAX(ts) mts FROM trigger_orders
                  WHERE ts > ? GROUP BY addr) m ON m.addr = t.addr AND m.mts = t.ts
            WHERE t.coin = ? AND t.kind != 'none'
            ORDER BY t.kind, t.trigger_px""", (int(time.time()) - 6 * 3600, coin)).fetchall()
        # Konten der untersten Stufe werden nur alle 6 h gefragt -- so weit reicht das Fenster
        n_wh, oldest = con.execute("SELECT COUNT(*), MIN(mts) FROM (SELECT addr, MAX(ts) mts FROM trigger_orders "
                                   "WHERE ts > ? GROUP BY addr)", (int(time.time()) - 6 * 3600,)).fetchone()
        n_fresh = con.execute("SELECT COUNT(DISTINCT addr) FROM trigger_orders WHERE ts > ?",
                              (int(time.time()) - 1200,)).fetchone()[0]
    except sqlite3.OperationalError:
        return out
    out["n_whales"] = n_wh
    out["n_fresh"] = n_fresh
    out["oldest"] = oldest
    out["n_with_orders"] = len({r["addr"] for r in rows
                                if (r["trigger_px"] or r["limit_px"]) and price
                                and abs((r["trigger_px"] or r["limit_px"]) / price - 1) <= 0.30})
    if not rows:
        return out
    out["ts"] = max(r["ts"] for r in rows)
    agg: dict = {}
    for r in rows:
        px = r["trigger_px"] or r["limit_px"]
        if not px:
            continue
        out["orders"].append({"addr": r["addr"][:6] + "…" + r["addr"][-4:], "kind": r["kind"],
                              "px": px, "size": r["size"], "notional": r["notional"],
                              "type": r["order_type"], "tpsl": r["is_tpsl"],
                              "dist": (px / price - 1) if price else 0})
        b = round(math.exp(round(math.log(px) / math.log(1.0025)) * math.log(1.0025)), 2)
        k = (r["kind"], b)
        a = agg.setdefault(k, {"kind": r["kind"], "px": b, "notional": 0.0, "n": 0, "addrs": set()})
        a["notional"] += r["notional"]; a["n"] += 1; a["addrs"].add(r["addr"])
    out["clusters"] = sorted(({**a, "addrs": len(a["addrs"]),
                               "dist": (a["px"] / price - 1) if price else 0} for a in agg.values()),
                             key=lambda x: x["px"])
    return out


def load_api_budget(con) -> dict | None:
    try:
        rows = dict(con.execute("SELECT k, v FROM meta WHERE k IN "
                                "('api_weight_1m','api_weight_budget','api_weight_ts','rate_limited')"))
    except sqlite3.OperationalError:
        return None
    if "api_weight_1m" not in rows:
        return None
    return {"used": int(rows["api_weight_1m"]), "budget": int(rows.get("api_weight_budget", 1200)),
            "ts": int(rows.get("api_weight_ts", 0)), "r429": int(rows.get("rate_limited", 0))}


def load_mas(con, coin: str, price: float) -> dict:
    """
    Gleitende Durchschnitte aus Tageskerzen (daily_bars, nachgeladen von
    hl_binance): 50/200 Tage und 50/200 Wochen. Die laufende Kerze wird durch
    den aktuellen Kurs ersetzt -- so, wie Charts es zeigen.
    """
    out = {"ma50d": None, "ma200d": None, "ma50w": None, "ma200w": None,
           "days": 0, "weeks": 0, "source": None, "cross": None}
    try:
        rows = con.execute("SELECT ts, close, source FROM daily_bars WHERE coin=? "
                           "ORDER BY ts", (coin,)).fetchall()
    except sqlite3.OperationalError:
        return out
    if not rows:
        return out
    today = int(time.time()) // 86_400 * 86_400
    closed = [(r["ts"], r["close"]) for r in rows if r["ts"] < today]
    out["source"] = rows[-1]["source"]
    daily = [c for _, c in closed] + ([price] if price else [])
    out["days"] = len(closed)

    # Wochen: ISO-Woche, Schluss = letzter Tag der Woche; laufende Woche = Kurs
    import datetime as _dt
    weekly, cur_key = [], None
    for ts, c in closed:
        y, w, _ = _dt.datetime.fromtimestamp(ts, _dt.timezone.utc).isocalendar()
        if (y, w) != cur_key:
            weekly.append(c); cur_key = (y, w)
        else:
            weekly[-1] = c
    now_key = _dt.datetime.now(_dt.timezone.utc).isocalendar()[:2]
    if price:
        if cur_key == now_key:
            weekly[-1] = price
        else:
            weekly.append(price)
    out["weeks"] = len(weekly)

    def sma(seq, n):
        return sum(seq[-n:]) / n if len(seq) >= n else None

    out["ma50d"], out["ma200d"] = sma(daily, 50), sma(daily, 200)
    out["ma50w"], out["ma200w"] = sma(weekly, 50), sma(weekly, 200)
    if out["ma50d"] and out["ma200d"]:
        out["cross"] = "golden" if out["ma50d"] > out["ma200d"] else "death"
    for k in ("ma50d", "ma200d", "ma50w", "ma200w"):
        out[k + "_dist"] = (price / out[k] - 1) if (out[k] and price) else None
    return out


def find_fvgs(candles: list[dict], min_pct: float = 0.0005) -> list[dict]:
    """
    Fair Value Gaps: Dreikerzen-Lücken, rein aus den Kerzen berechnet.

    Bullisch: Tief der dritten Kerze über dem Hoch der ersten.
    Bärisch:  Hoch der dritten Kerze unter dem Tief der ersten.
    Die Zone zwischen beiden ist die Lücke. Sie gilt als "gemildert", sobald
    spätere Kerzen wieder hineinlaufen: teilweise (Anteil), oder ganz, wenn
    der Kurs die ferne Kante erreicht. Nichts davon wird gespeichert.
    """
    gaps = []
    for i in range(2, len(candles)):
        a, b, c = candles[i - 2], candles[i - 1], candles[i]
        if c["l"] > a["h"]:
            kind, top, bot = "bull", c["l"], a["h"]
        elif c["h"] < a["l"]:
            kind, top, bot = "bear", a["l"], c["h"]
        else:
            continue
        mid = (top + bot) / 2
        if mid <= 0 or (top - bot) / mid < min_pct:
            continue
        gaps.append({"i": i - 1, "t": b["t"], "kind": kind, "top": top, "bot": bot,
                     "size_pct": (top - bot) / mid, "fill_i": None, "fill_pct": 0.0})

    for g in gaps:
        span = g["top"] - g["bot"]
        for j in range(g["i"] + 2, len(candles)):
            c = candles[j]
            if g["kind"] == "bull":
                if c["l"] <= g["bot"]:
                    g["fill_i"], g["fill_pct"] = j, 1.0
                    break
                if c["l"] < g["top"]:
                    g["fill_pct"] = max(g["fill_pct"], (g["top"] - c["l"]) / span)
            else:
                if c["h"] >= g["top"]:
                    g["fill_i"], g["fill_pct"] = j, 1.0
                    break
                if c["h"] > g["bot"]:
                    g["fill_pct"] = max(g["fill_pct"], (c["h"] - g["bot"]) / span)
    return gaps


ICON_SVG = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
    '<rect width="64" height="64" rx="12" fill="#0d1117"/>'
    '<rect x="10" y="36" width="8" height="18" fill="#e04b4b"/>'
    '<rect x="22" y="24" width="8" height="30" fill="#3ba55d"/>'
    '<rect x="34" y="30" width="8" height="24" fill="#e04b4b"/>'
    '<rect x="46" y="14" width="8" height="40" fill="#39ff14"/>'
    '<line x1="8" y1="20" x2="56" y2="20" stroke="#58a6ff" stroke-width="2" stroke-dasharray="4 3"/>'
    '</svg>')

_HEALTH_CACHE: dict = {"ts": 0, "check": None, "running": False}
_HEALTH_LOCK = threading.Lock()


def _run_quick_check(db: str) -> None:
    """quick_check im Hintergrund -- bei 1 GB auf einem USB-Stick dauert er Minuten."""
    try:
        con = connect(db)
        t0 = time.time()
        res = con.execute("PRAGMA quick_check").fetchone()[0]
        con.close()
        result = {"db_ok": res == "ok", "db_detail": "" if res == "ok" else str(res)[:120],
                  "check_seconds": round(time.time() - t0, 1), "checked_at": int(time.time())}
    except sqlite3.Error as e:
        result = {"db_ok": False, "db_detail": str(e)[:120], "check_seconds": 0,
                  "checked_at": int(time.time())}
    with _HEALTH_LOCK:
        _HEALTH_CACHE.update(ts=int(time.time()), check=result, running=False)


def load_health(db: str, max_age: int = 6 * 3600) -> dict:
    """
    Backup-Status (billig, bei jedem Aufruf frisch) und Zustand der Datenbank
    (quick_check, höchstens alle 6 h, im Hintergrund). Der Aufruf blockiert nie:
    läuft die Prüfung gerade, kommt der letzte bekannte Stand oder "läuft".
    """
    now = int(time.time())
    with _HEALTH_LOCK:
        stale = _HEALTH_CACHE["check"] is None or now - _HEALTH_CACHE["ts"] >= max_age
        if stale and not _HEALTH_CACHE["running"]:
            _HEALTH_CACHE["running"] = True
            threading.Thread(target=_run_quick_check, args=(db,), daemon=True).start()
        check = _HEALTH_CACHE["check"]
        running = _HEALTH_CACHE["running"]

    backup = None
    bdir = os.path.join(os.path.dirname(os.path.abspath(db)), "dbbackup")
    try:
        c0 = connect(db)
        r0 = c0.execute("SELECT v FROM meta WHERE k='backup_dir'").fetchone()
        c0.close()
        if r0 and r0[0]:
            bdir = r0[0]
    except sqlite3.Error:
        pass
    try:
        with open(os.path.join(bdir, "backup.json")) as f:
            backup = json.load(f)
    except (OSError, ValueError):
        pass

    data = {"backup": backup, "checking": running,
            "db_size": os.path.getsize(db) if os.path.exists(db) else 0}
    if check:
        data.update(check)
    else:
        data.update(db_ok=None, db_detail="Prüfung läuft", check_seconds=0, checked_at=None)
    return data


_KLINE_CACHE: dict = {}
_KLINE_LOCK = threading.Lock()


def aggregate(rows, step: int) -> list[dict]:
    """Zeilen (ts, o, h, l, c, v) in Kerzen der Länge step (Sekunden) falten."""
    candles, cur = [], None
    for ts, o, h, l, c, v in rows:
        b = ts // step * step
        if cur is None or b != cur["t"]:
            if cur:
                candles.append(cur)
            cur = {"t": b, "o": o, "h": h, "l": l, "c": c, "v": v or 0}
        else:
            cur["h"] = max(cur["h"], h); cur["l"] = min(cur["l"], l); cur["c"] = c; cur["v"] += v or 0
    if cur:
        candles.append(cur)
    return candles


def week_start(ts: int) -> int:
    """Montag 00:00 UTC der Woche, in der ts liegt."""
    return (ts - 4 * 86_400) // 604_800 * 604_800 + 4 * 86_400   # 1970-01-01 war ein Donnerstag


def fetch_binance_klines(coin: str, interval: str, limit: int) -> list[dict]:
    """Binance-Futures-Kerzen als Ergänzung für lange Zeiträume; 5 min im Speicher gehalten."""
    import urllib.request
    key = (coin, interval, limit)
    with _KLINE_LOCK:
        hit = _KLINE_CACHE.get(key)
        if hit and time.time() - hit[0] < 300:
            return hit[1]
    out = []
    for base, path in (("https://fapi.binance.com", "/fapi/v1/klines"), ("https://api.binance.com", "/api/v3/klines")):
        try:
            url = f"{base}{path}?symbol={coin}USDT&interval={interval}&limit={limit}"
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}),
                                        timeout=15) as r:
                data = json.loads(r.read().decode())
            if isinstance(data, list) and data:
                out = [{"t": int(k[0]) // 1000, "o": float(k[1]), "h": float(k[2]), "l": float(k[3]),
                        "c": float(k[4]), "v": float(k[5])} for k in data]
                break
        except Exception:
            continue
    with _KLINE_LOCK:
        _KLINE_CACHE[key] = (time.time(), out)
    return out


def load_long_candles(con, coin: str, agg: int, minutes: int) -> tuple[list[dict], str]:
    """
    Kerzen ab 4 h Raster: aus den vorhandenen Tabellen der Datenbank, ergänzt
    um Binance, wo die eigene Aufzeichnung nicht zurückreicht.
      4 h   -> klines30 (30-min-Kerzen von Binance, falls hl_timestats geladen hat),
               sonst Binance 4h-Kerzen; die jüngsten Stunden aus den eigenen 1-min-Bars
      1 Tag -> daily_bars (5 Jahre, von hl_binance), sonst Binance 1d
      1 Wo  -> daily_bars zu ISO-Wochen gefaltet, sonst Binance 1w
    Liefert (Kerzen, Quellenangabe).
    """
    now = int(time.time()); t_from = now - minutes * 60; step = agg * 60
    src = []
    if agg == 240:
        try:
            rows = con.execute("SELECT ts, open, high, low, close, volume FROM klines30 WHERE coin=? AND ts>=? ORDER BY ts",
                               (coin, t_from)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        cands = aggregate([tuple(r) for r in rows], step) if rows else []
        if cands and cands[0]["t"] <= t_from + 2 * 86_400:
            candles, src = cands, ["Binance-30-min-Kerzen (klines30)"]
        else:
            candles, src = fetch_binance_klines(coin, "4h", 6 * 30 + 2), ["Binance 4h"]
        # die eigenen Minutenbars ersetzen das jüngste Stück, wo sie vorliegen
        own = con.execute("SELECT ts, open, high, low, close, volume FROM bars WHERE coin=? AND ts>=? ORDER BY ts",
                          (coin, max(t_from, now - 8 * 86_400))).fetchall()
        own_c = aggregate([tuple(r) for r in own], step)
        if own_c:
            first_own = own_c[0]["t"]
            candles = [c for c in candles if c["t"] < first_own] + own_c
            src.append("jüngste Kerzen aus eigenen Hyperliquid-Bars")
    else:
        try:
            rows = con.execute("SELECT ts, open, high, low, close, volume FROM daily_bars WHERE coin=? AND ts>=? ORDER BY ts",
                               (coin, t_from - 7 * 86_400)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        if rows and rows[0][0] <= t_from + 30 * 86_400:
            daily = [{"t": r[0], "o": r[1], "h": r[2], "l": r[3], "c": r[4], "v": r[5] or 0} for r in rows]
            src = ["Tageskerzen (daily_bars, Binance via hl_binance)"]
        else:
            daily = fetch_binance_klines(coin, "1d", min(1000, minutes // 1440 + 7))
            src = ["Binance 1d"]
        if agg >= 10080:
            weeks, cur = [], None
            for c in daily:
                w = week_start(c["t"])
                if cur is None or cur["t"] != w:
                    if cur:
                        weeks.append(cur)
                    cur = dict(c, t=w)
                else:
                    cur["h"] = max(cur["h"], c["h"]); cur["l"] = min(cur["l"], c["l"]); cur["c"] = c["c"]; cur["v"] += c["v"]
            if cur:
                weeks.append(cur)
            candles = weeks
        else:
            candles = daily
        candles = [c for c in candles if c["t"] >= t_from - (604_800 if agg >= 10080 else 0)]
        # laufende Kerze: Schluss aus dem eigenen aktuellen Kurs
        last = con.execute("SELECT close FROM bars WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if candles and last and last[0]:
            candles[-1]["c"] = last[0]
            candles[-1]["h"] = max(candles[-1]["h"], last[0]); candles[-1]["l"] = min(candles[-1]["l"], last[0])
    return candles, " + ".join(src)


# ---------------------------------------------------------------------------
# Binance als zweite Quelle. Grundsatz: Datenbank zuerst (bnc_liquidations,
# bnc_metrics, bnc_bars, daily_bars), Live-Abfragen nur für das, was nicht
# gespeichert wird (Kerzen kurzer Raster, Orderbuch, Funding), mit Speicher-Cache
# und stiller Rückfallebene, damit das Dashboard ohne Netz nicht bricht.
# ---------------------------------------------------------------------------

_BNC_CACHE: dict = {}
_BNC_LOCK = threading.Lock()
BNC_INTERVALS = {1: "1m", 5: "5m", 15: "15m", 60: "1h", 240: "4h", 1440: "1d", 10080: "1w"}


def _cached(key, ttl, fn):
    with _BNC_LOCK:
        hit = _BNC_CACHE.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    try:
        val = fn()
    except Exception:
        val = None
    with _BNC_LOCK:
        _BNC_CACHE[key] = (time.time(), val)
    return val


def _bnc_get(path: str, params: dict, timeout: int = 12):
    import urllib.request, urllib.parse
    url = f"https://fapi.binance.com{path}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hl-dashboard/1.0"}),
                                timeout=timeout) as r:
        return json.loads(r.read().decode())


def bucket_px(px: float) -> float:
    step = math.log(1.0025)
    return round(math.exp(round(math.log(px) / step) * step), 6)


def bnc_candles(con, coin: str, agg: int, minutes: int) -> tuple[list[dict], str]:
    """Binance-Kerzen im gewünschten Raster: live (30 s Cache), sonst aus bnc_bars/daily_bars."""
    iv = BNC_INTERVALS.get(agg, "5m")
    limit = min(1500, max(10, minutes // max(agg, 1) + 2))
    live = _cached(("kl", coin, iv, limit), 30, lambda: [
        {"t": int(k[0]) // 1000, "o": float(k[1]), "h": float(k[2]), "l": float(k[3]), "c": float(k[4]), "v": float(k[5])}
        for k in _bnc_get("/fapi/v1/klines", {"symbol": f"{coin}USDT", "interval": iv, "limit": limit})])
    if live:
        return live, f"Binance {iv}"
    t_from = int(time.time()) - minutes * 60
    table = "daily_bars" if agg >= 1440 else "bnc_bars"
    try:
        rows = con.execute(f"SELECT ts, open, high, low, close, volume FROM {table} WHERE coin=? AND ts>=? ORDER BY ts",
                           (coin, t_from)).fetchall()
    except sqlite3.OperationalError:
        rows = []
    return aggregate([tuple(r) for r in rows], agg * 60), f"{table} (gespeichert, Live-Abruf nicht möglich)"


def bnc_liqs(con, coin: str, since: int) -> list[tuple]:
    """Eingetretene Liquidationen (ts, px, notional, side_liq): side_liq long = Long liquidiert (SELL-Fill)."""
    try:
        rows = con.execute("SELECT ts, price, notional, side FROM bnc_liquidations WHERE coin=? AND ts>=? ORDER BY ts",
                           (coin, since)).fetchall()
    except sqlite3.OperationalError:
        return []
    return [(r[0], r[1], r[2], "long" if str(r[3]).upper().startswith("S") else "short") for r in rows]


def bnc_book(coin: str, price: float) -> list[dict]:
    """Orderbuch-Tiefe als Cluster im 0,25-%-Raster (kind limit_buy/limit_sell), ±30 % um den Kurs."""
    def fetch():
        d = _bnc_get("/fapi/v1/depth", {"symbol": f"{coin}USDT", "limit": 1000})
        out = {}
        for side, kind in (("bids", "limit_buy"), ("asks", "limit_sell")):
            for p, q in d.get(side, []):
                p, q = float(p), float(q)
                if not price or abs(p / price - 1) > 0.30:
                    continue
                b = bucket_px(p)
                c = out.setdefault((kind, b), {"kind": kind, "px": b, "notional": 0.0, "n": 0, "addrs": 0, "src": "bnc"})
                c["notional"] += p * q; c["n"] += 1
        return list(out.values())
    return _cached(("book", coin, round(price / 50) if price else 0), 15, fetch) or []


def bnc_funding(coin: str):
    def fetch():
        d = _bnc_get("/fapi/v1/premiumIndex", {"symbol": f"{coin}USDT"})
        return float(d.get("lastFundingRate") or 0) / 8       # Binance: je 8 h -> je Stunde wie bei Hyperliquid
    return _cached(("funding", coin), 60, fetch)


def bnc_metrics_series(con, coin: str, hours: int) -> dict:
    """Kennzahlen als Zeitreihen: gespeichert (bnc_metrics), Verhältnisse zusätzlich live nachgeladen (5 min Cache)."""
    since = int(time.time()) - hours * 3600
    out: dict = {}
    try:
        for m, ts, v in con.execute("SELECT metric, ts, value FROM bnc_metrics WHERE coin=? AND ts>=? ORDER BY ts",
                                    (coin, since)):
            out.setdefault(m, []).append([ts, v])
    except sqlite3.OperationalError:
        pass
    per = "5m" if hours <= 24 else "1h"
    limit = min(500, hours * (12 if per == "5m" else 1) + 2)
    live = _cached(("ratios", coin, per, limit), 300, lambda: {
        m: [[int(r["timestamp"]) // 1000, float(r[field])] for r in _bnc_get(path, {"symbol": f"{coin}USDT", "period": per, "limit": limit})]
        for path, m, field in (("/futures/data/globalLongShortAccountRatio", "global_ls_account", "longShortRatio"),
                               ("/futures/data/topLongShortPositionRatio", "top_ls_position", "longShortRatio"),
                               ("/futures/data/takerlongshortRatio", "taker_ls", "buySellRatio"),
                               ("/futures/data/openInterestHist", "oi_notional", "sumOpenInterestValue"))})
    if live:
        for m, series in live.items():
            merged = {t: v for t, v in out.get(m, [])}
            merged.update({t: v for t, v in series if t >= since})
            out[m] = [[t, merged[t]] for t in sorted(merged)]
    latest = {m: (ser[-1][1] if ser else None) for m, ser in out.items()}
    return {"series": out, "latest": latest}


def attach_binance(con, payload: dict, coin: str, agg: int, minutes: int, src: str) -> dict:
    """
    src == 'bnc':    Kerzen, Marken, Orderbuch, Funding, Trend, RSI, FVGs aus Binance;
                     Marken = eingetretene Liquidationen im Chartzeitraum.
    src == 'fusion': Hyperliquid-Chart bleibt; dazu Binance-Orderbuch je Preisstufe
                     zu den Orders addiert, eingetretene Liquidationen beider Börsen als
                     Marker, Volumen/Funding beider Börsen, Kennzahlen.
    """
    now = int(time.time())
    cand, csrc = bnc_candles(con, coin, agg, minutes)
    price_b = cand[-1]["c"] if cand else (payload.get("price") or 0)
    liqs = bnc_liqs(con, coin, now - minutes * 60)
    book = bnc_book(coin, price_b or payload.get("price") or 0)
    fund = bnc_funding(coin)
    met = bnc_metrics_series(con, coin, 24)
    vol_b = sum(c["v"] * c["c"] for c in cand if c["t"] >= now - 3600) if cand else 0
    liq_marks = [(ts, px, usd, side, "bnc") for ts, px, usd, side in liqs]
    # eigene (Hyperliquid) Liquidationen im selben Fenster als Marker
    try:
        for r in con.execute("SELECT ts, px, px*sz, side FROM liquidations WHERE coin=? AND ts>=? ORDER BY ts",
                             (coin, now - minutes * 60)):
            liq_marks.append((r[0], r[1], r[2], "long" if str(r[3]).upper().startswith("A") else "short", "hl"))
    except sqlite3.OperationalError:
        pass
    payload["liq_marks"] = liq_marks
    payload["bnc"] = {"metrics": met["latest"], "vol_1h": vol_b, "funding": fund, "book_n": len(book),
                      "liqs_1h": {"long": sum(u for t, p, u, sd in liqs if sd == "long" and t >= now - 3600),
                                  "short": sum(u for t, p, u, sd in liqs if sd == "short" and t >= now - 3600)}}
    if src == "bnc":
        if cand:
            payload["candles"] = cand; payload["source"] = csrc; payload["price"] = price_b
            payload["fvgs"] = find_fvgs(cand, 0.0005)
            closes = [c["c"] for c in cand]
            payload["rsi14"] = rsi14(closes) if len(closes) >= 16 else None
            m1, _ = bnc_candles(con, coin, 1, 120)
            payload["trend_60m"] = (m1[-1]["c"] / m1[-61]["c"] - 1) if len(m1) >= 61 else None
            payload["vol_1h"] = vol_b
        # Marken: eingetretene Liquidationen je Preisstufe im Chartzeitraum
        lv: dict = {}
        for ts, px, usd, side in liqs:
            c = lv.setdefault((bucket_px(px), side), {"px": bucket_px(px), "side": side, "notional": 0.0, "n_pos": 0})
            c["notional"] += usd; c["n_pos"] += 1
        levels = sorted(lv.values(), key=lambda x: -x["notional"])[:14]
        for l in levels:
            l["dist"] = (l["px"] / price_b - 1) if price_b else 0
        payload["levels"] = levels; payload["levels_realized"] = True
        payload["stops"] = {"clusters": book, "orders": [], "n_whales": 0, "n_fresh": 0, "n_with_orders": 0,
                            "oldest": None, "ts": now, "book": True}
        payload["funding"] = fund
        if book:
            near = lambda kind: sum(c["notional"] for c in book if c["kind"] == kind and abs(c["px"] / price_b - 1) <= 0.005)
            b, a = near("limit_buy"), near("limit_sell")
            payload["book"] = {"imb_50": (b - a) / (b + a) if (b + a) else 0, "bid_50": b, "ask_50": a, "src": "bnc"}
        payload["tick_events"] = []
    else:   # fusion
        stops = payload.get("stops") or {"clusters": []}
        merged: dict = {}
        for c in stops.get("clusters", []):
            merged[(c["kind"], c["px"])] = dict(c)
        for c in book:
            key = (c["kind"], c["px"])
            if key in merged:
                merged[key]["notional"] += c["notional"]; merged[key]["n"] += c["n"]; merged[key]["src"] = "both"
            else:
                merged[key] = dict(c)
        p0 = payload.get("price") or price_b
        for c in merged.values():
            c["dist"] = (c["px"] / p0 - 1) if p0 else 0
        stops["clusters"] = sorted(merged.values(), key=lambda c: c["px"]); stops["book_n"] = len(book)
        payload["stops"] = stops
        payload["vol_1h"] = (payload.get("vol_1h") or 0) + vol_b
        payload["vol_split"] = {"hl": (payload.get("vol_1h") or 0) - vol_b, "bnc": vol_b}
        if fund is not None and payload.get("funding") is not None:
            payload["funding_bnc"] = fund
    return payload


def rsi14(closes: list) -> float | None:
    if len(closes) < 16:
        return None
    gains, losses = [], []
    for a, b in zip(closes[-15:-1], closes[-14:]):
        gains.append(max(b - a, 0)); losses.append(max(a - b, 0))
    ag, al = sum(gains) / 14, sum(losses) / 14
    return 100.0 if al == 0 else round(100 - 100 / (1 + ag / al), 1)


def load_chart(con, coin: str, minutes: int = 240, agg: int = 1, top: int = 14,
               fvg_min: float = 0.0005):
    """Kerzen aus den 1-Minuten-Bars plus die stärksten aktuellen Level."""
    t_from = int(time.time()) - minutes * 60
    source = "eigene Hyperliquid-Bars"
    if agg >= 240:
        candles, source = load_long_candles(con, coin, agg, minutes)
        rows = con.execute("SELECT ts, open, high, low, close, volume FROM bars "
                           "WHERE coin=? AND ts>=? ORDER BY ts", (coin, int(time.time()) - 3600)).fetchall()
    else:
        rows = con.execute(
            "SELECT ts, open, high, low, close, volume FROM bars "
            "WHERE coin=? AND ts>=? ORDER BY ts", (coin, t_from)).fetchall()
        candles = aggregate([tuple(r) for r in rows], max(agg, 1) * 60)

    # 60-Minuten-Trend aus den Minutenbars, unabhängig vom Chart-Raster
    trend = None
    if len(rows) >= 61:
        c_now, c_then = rows[-1]["close"], rows[-61]["close"]
        if c_then:
            trend = c_now / c_then - 1

    # RSI(14) nach Wilder auf dem angezeigten Kerzenraster
    rsi = None
    closes = [c["c"] for c in candles]
    if len(closes) >= 16:
        gains, losses = [], []
        for a, b in zip(closes[:-1], closes[1:]):
            d_ = b - a
            gains.append(max(d_, 0.0)); losses.append(max(-d_, 0.0))
        n = 14
        ag = sum(gains[:n]) / n
        al = sum(losses[:n]) / n
        for g_, l_ in zip(gains[n:], losses[n:]):
            ag = (ag * (n - 1) + g_) / n
            al = (al * (n - 1) + l_) / n
        rsi = 100.0 if al == 0 else 100.0 - 100.0 / (1.0 + ag / al)

    d = load_depth(con, coin)
    levels = []
    if d and d["price"]:
        px = d["price"]
        near = [r for r in d["rows"] if 0.88 * px < r["bucket_px"] < 1.15 * px]
        near.sort(key=lambda r: -r["notional"])
        for r in near[:top]:
            levels.append({
                "px": r["bucket_px"], "side": r["side"],
                "notional": r["notional"], "n_pos": r["n_pos"],
                "dist": (r["bucket_px"] - px) / px,
                # Verhältnis zum Stundenvolumen: entscheidet, ob ein Level trägt
                "x_vol": (r["notional"] / d["vol_1h"]) if d["vol_1h"] else 0,
            })

    try:
        events = [dict(r) for r in con.execute(
            "SELECT t_trigger, reason, move_pct, px_extreme, n_ticks, n_liqs "
            "FROM tick_events WHERE coin=? AND reason != 'control' "
            "ORDER BY t_trigger DESC LIMIT 5", (coin,))]
    except sqlite3.OperationalError:
        events = []

    # Zusatzsignale für die Konfluenz-Anzeige, alle ohne Speicherung
    book = funding = None
    danger = None
    try:
        r = con.execute("SELECT ts, spread_bps, bid_50, ask_50, imb_50 FROM book_summary "
                        "WHERE coin=? ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if r and time.time() - r["ts"] < 600:
            book = dict(r)
        r = con.execute("SELECT ts, funding, oi FROM ctx_bars WHERE coin=? "
                        "ORDER BY ts DESC LIMIT 1", (coin,)).fetchone()
        if r and time.time() - r["ts"] < 900:
            funding = dict(r)
        # Danger-Time: ist das aktuelle 30-Minuten-Fenster laut Zeit-Heatmap belastbar erhöht?
        import datetime as _dt
        nowu = _dt.datetime.now(_dt.timezone.utc)
        slot = nowu.hour * 2 + (1 if nowu.minute >= 30 else 0)
        r = con.execute("SELECT threshold, rate, lift FROM time_heatmap WHERE coin=? AND tz='UTC' "
                        "AND weekday=? AND slot=? AND robust=1 ORDER BY threshold DESC LIMIT 1",
                        (coin, nowu.weekday(), slot)).fetchone()
        if r:
            danger = dict(r)
    except sqlite3.OperationalError:
        pass

    fvgs = find_fvgs(candles, fvg_min)
    last = candles[-1]["c"] if candles else 0
    mas = load_mas(con, coin, last)
    stops = load_stops(con, coin, last)
    budget = load_api_budget(con)
    for g in fvgs:
        g["dist"] = ((g["bot"] if g["kind"] == "bull" else g["top"]) / last - 1) if last else 0

    return {
        "candles": candles, "levels": levels,
        "tick_events": events,
        "fvgs": fvgs,
        "book": book, "funding": funding, "danger": danger,
        "mas": mas, "source": source, "agg": agg, "stops": stops, "budget": budget,
        "price": d["price"] if d else None,
        "vol_1h": d["vol_1h"] if d else 0,
        "snapshot_ts": d["ts"] if d else 0,
        "trend_60m": trend,
        "rsi14": rsi,
        "rsi_tf": f"{agg} min" if agg < 60 else f"{agg // 60} h",
    }


def plot_heatmap(con, coin: str, hours: int, out: str,
                 threshold: float = 0.70, gamma: float = 2.6) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.colors import LinearSegmentedColormap
    from matplotlib.dates import DateFormatter, date2num

    d = load_grid(con, coin, hours)
    if d is None:
        print(f"Keine Daten für {coin} in den letzten {hours} h.")
        return

    z = np.array(d["grid"], dtype=float)

    # Perzentil-Zuordnung statt Normierung aufs Maximum: entscheidend ist der
    # Rang einer Zelle unter allen anderen. Anschließend eine Potenz, damit
    # die Masse dunkel bleibt und nur die stärksten Cluster leuchten.
    pos = z[z > 0]
    if pos.size == 0:
        print("Nur leere Zellen.")
        return
    srt = np.sort(pos)
    rank = np.searchsorted(srt, z, side="right") / srt.size
    rank[z <= 0] = 0.0
    vis = rank >= threshold
    q = np.zeros_like(rank)
    q[vis] = ((rank[vis] - threshold) / max(1e-9, 1 - threshold)) ** gamma
    q = np.ma.masked_where(~vis, q)

    cmap = LinearSegmentedColormap.from_list("liq", [
        (0.00, "#04060f"), (0.22, "#0a288c"), (0.45, "#0096c8"),
        (0.68, "#3cdcb4"), (0.85, "#ffd60a"), (1.00, "#ffffeb")])
    cmap.set_bad("#04060f")

    x = date2num([np.datetime64(t, "s") for t in d["times"]])
    y = np.array(d["levels"])

    fig, ax = plt.subplots(figsize=(15, 8.5))
    ax.set_facecolor("#04060f")
    mesh = ax.pcolormesh(x, y, q, cmap=cmap, vmin=0, vmax=1, shading="nearest")

    pt = date2num([np.datetime64(t, "s") for t, _ in d["price"]])
    ax.plot(pt, [p for _, p in d["price"]], color="#ffffff", lw=1.5,
            label="Kurs", zorder=5)

    if d["liqs"]:
        lt = date2num([np.datetime64(t, "s") for t, *_ in d["liqs"]])
        lp = [p for _, p, *_ in d["liqs"]]
        ls = [max(6, min(220, n / 4000)) for *_, n, _ in d["liqs"]]
        ax.scatter(lt, lp, s=ls, facecolor="none", edgecolor="#ff3b6b",
                   lw=1.1, zorder=6, label="Liquidationen")

    prices = [p for _, p in d["price"]]
    ax.set_ylim(min(prices) * 0.90, max(prices) * 1.10)
    ax.xaxis.set_major_formatter(DateFormatter("%d.%m %H:%M"))
    ax.set_title(f"{coin} — Liquidationscluster, letzte {hours} h · "
                 f"nur oberhalb Perzentil {threshold*100:.0f}", fontsize=12)
    ax.set_ylabel("Preis")
    ax.grid(alpha=0.10, ls=":")
    ax.legend(loc="upper left", framealpha=0.6)
    cb = fig.colorbar(mesh, ax=ax, pad=0.01)
    cb.set_label("relative Clusterstärke (Rang unter allen Zellen)")
    fig.autofmt_xdate()
    plt.tight_layout()
    plt.savefig(out, dpi=130, facecolor="#0d1117")
    print(f"Gespeichert: {out}")


def plot_depth(con, coin: str, out: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    d = load_depth(con, coin)
    if not d or not d["rows"] or not d["price"]:
        print(f"Kein aktueller Snapshot für {coin}.")
        return

    px, v1h = d["price"], d["vol_1h"]
    rows = [r for r in d["rows"] if 0.8 * px < r["bucket_px"] < 1.25 * px]
    if not rows:
        print("Keine Cluster im relevanten Preisbereich.")
        return

    fig, ax = plt.subplots(figsize=(9, 11))
    for r in rows:
        col = "#e04b4b" if r["side"] == "long" else "#3ba55d"
        ax.barh(r["bucket_px"], r["notional"], height=px * 0.0022,
                color=col, alpha=0.85)

    ax.axhline(px, color="#00e5ff", lw=2)
    ax.text(ax.get_xlim()[1], px, f"  {px:,.2f}", va="center",
            color="#00808f", fontsize=10, fontweight="bold")

    if v1h > 0:
        ax.axvline(v1h * 0.5, color="grey", ls="--", lw=1)
        ax.text(v1h * 0.5, ax.get_ylim()[1], " 0.5x 1h-Vol",
                rotation=90, va="top", fontsize=8, color="grey")

    ax.set_title(f"{coin} — Cluster um den Kurs\n"
                 f"rot = Long-Liquidationen, grün = Short-Liquidationen\n"
                 f"Stand {time.strftime('%d.%m. %H:%M', time.localtime(d['ts']))}",
                 fontsize=11)
    ax.set_xlabel("Notional (USD)")
    ax.grid(axis="x", alpha=0.2, ls=":")
    plt.tight_layout()
    plt.savefig(out, dpi=130)
    print(f"Gespeichert: {out}")


# ---------------------------------------------------------------------------
# Live-Dashboard
# ---------------------------------------------------------------------------

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0d1117">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<link rel="manifest" href="/manifest.json">
<link rel="icon" href="/icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icon.svg">
<title>HL Liquidationen</title>
<style>
 table.w{border-collapse:collapse;font-size:11px;min-width:min(100%,900px)}
 table.w th{color:#8b949e;font-weight:500;text-align:left;padding:4px 10px;
   border-bottom:1px solid #21262d;font-size:10px;text-transform:uppercase;white-space:nowrap}
 table.w td{padding:5px 10px;border-bottom:1px solid #161b22;white-space:nowrap}
 table.w th.n,table.w td.n{text-align:right;font-variant-numeric:tabular-nums}
 .mono{font-family:ui-monospace,monospace;font-size:10px;color:#8b949e}
 body{background:#0d1117;color:#c9d1d9;font:13px system-ui,sans-serif;margin:0;padding:16px}
 h1{font-size:17px;margin:0 0 3px} h2{font-size:13px;margin:0 0 2px;color:#e6edf3}
 .sub{color:#8b949e;font-size:11px;line-height:1.45}
 canvas{background:#01030a;border:1px solid #21262d;border-radius:6px;width:100%;
        display:block;cursor:crosshair}
 .row{display:flex;gap:16px;flex-wrap:wrap;margin-top:6px}
 .col{flex:1;min-width:330px}
 .panel{margin-top:20px}
 .bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:12px 0 6px}
 label.lbl{font-size:10px;color:#8b949e;text-transform:uppercase;letter-spacing:.4px}
 select,button{background:#21262d;color:#c9d1d9;border:1px solid #30363d;
   border-radius:5px;padding:5px 9px;font-size:12px}
 button.tog{cursor:pointer;min-width:64px;font-weight:600}
 button.tog.on{background:#1f3d2a;border-color:#3ba55d;color:#7ee787}
 button.tog.off{background:#21262d;color:#8b949e}
 .kpi{display:flex;gap:20px;flex-wrap:wrap;margin:12px 0;padding:10px 12px;
      background:#161b22;border:1px solid #21262d;border-radius:6px}
 .kpi div span{display:block;color:#8b949e;font-size:10px;text-transform:uppercase;
               letter-spacing:.4px}
 .kpi b{font-size:17px;font-weight:600}
 .kpi b .d{display:block;font-size:11px;font-weight:500;color:#8b949e;text-transform:none;letter-spacing:0}
 .warn{color:#d29922;font-size:11px;margin-top:14px}
 .leg{display:flex;gap:14px;align-items:center;font-size:10px;color:#8b949e;
      margin:5px 0;flex-wrap:wrap}
 /* ---- Struktur: Kopf bleibt oben, Abschnitte nummeriert und einklappbar ---- */
 .top{position:sticky;top:0;z-index:20;background:rgba(13,17,23,0.96);backdrop-filter:blur(6px);
      margin:-16px -16px 0;padding:10px 16px 6px;border-bottom:1px solid #21262d}
 .titlerow{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
 .titlerow h1{margin:0;font-size:17px}
 .nav{display:flex;gap:4px;flex-wrap:wrap;margin-top:6px}
 .nav a{color:#c9d1d9;text-decoration:none;font-size:11px;padding:4px 9px;border-radius:12px;
        background:#161b22;border:1px solid #21262d;cursor:pointer}
 .nav a:hover{border-color:#58a6ff;color:#58a6ff}
 .nav a.dim{color:#8b949e}
 .panel{scroll-margin-top:96px}
 h2.sech{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none;margin:0}
 h2.sech .num{display:inline-flex;width:22px;height:22px;border-radius:50%;background:#21262d;color:#8b949e;
      font-size:11px;align-items:center;justify-content:center;flex:none}
 h2.sech .ttl{flex:1}
 h2.sech .help{font-size:12px;color:#8b949e;border:1px solid #30363d;border-radius:50%;width:18px;height:18px;
      display:inline-flex;align-items:center;justify-content:center;flex:none}
 h2.sech .help:hover{color:#58a6ff;border-color:#58a6ff}
 h2.sech .chev{color:#8b949e;font-size:12px;transition:transform .15s;flex:none}
 .panel.closed .body{display:none}
 .panel.closed h2.sech .chev{transform:rotate(-90deg)}
 .panel.closed h2.sech{margin:0}
 .sub.help{border-left:2px solid #30363d;padding-left:10px;margin:8px 0 10px}
 /* ---- Handy (bis 700 px): alles untereinander, große Tippflächen ---- */
 @media (max-width:700px){
  body{padding:10px 10px 24px}
  .top{margin:-10px -10px 0;padding:8px 10px 6px}
  .titlerow h1{font-size:15px}
  .nav{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;padding-bottom:2px}
  .nav a{padding:5px 9px;font-size:11px;white-space:nowrap;flex:none}
  .kpi div span{white-space:normal}
  .panel{scroll-margin-top:120px}
  h1{font-size:16px} .sub{font-size:11px}
  .bar{display:grid;grid-template-columns:1fr 1fr;gap:8px 10px;align-items:center}
  .bar label.lbl{grid-column:1/-1;margin:2px 0 -4px;font-size:9px}
  .bar select,.bar button{width:100%;min-height:40px;font-size:14px;padding:6px 8px}
  .bar button.tog{grid-column:1/-1}
  .kpi{display:grid;grid-template-columns:1fr 1fr;gap:10px 14px;padding:10px}
  .kpi b{font-size:clamp(13px,4vw,17px);white-space:nowrap}
  .kpi b .d{display:block;font-size:12px;font-weight:500}
  .kpi div span{font-size:9px}
  .col{min-width:0;flex-basis:100%}
  .leg{gap:8px 12px;font-size:10px}
  .panel{margin-top:16px}
  canvas{border-radius:4px}
  #signalbox{font-size:12px}
  table.w{font-size:12px} table.w tr.grp td{background:#1c2128;border-top:2px solid #30363d;padding-top:7px}
 table.w td,table.w th{padding:6px 8px}
  #tip{max-width:80vw}
 }
 .sw{display:inline-block;width:11px;height:11px;border-radius:2px;
     margin-right:4px;vertical-align:-1px}
 .grad{width:110px;height:9px;border-radius:2px;background:linear-gradient(90deg,
   #04060f,#0a288c,#0096c8,#3cdcb4,#ffd60a,#ffffeb)}
 #tip{position:fixed;z-index:99;pointer-events:none;display:none;
      background:#0d1117;border:1px solid #30363d;border-radius:8px;
      padding:9px 12px;font-size:12px;box-shadow:0 6px 20px #000a;max-width:260px}
 #tip .t{color:#8b949e;font-size:10px;margin-bottom:5px}
 #tip .r{display:flex;justify-content:space-between;gap:16px;margin:2px 0}
 #tip .r i{font-style:normal;color:#8b949e}
 #tip .r b{font-weight:600}
</style></head><body>
<div class="top">
 <div class="titlerow">
  <h1>Hyperliquid — Liquidationscluster</h1>
  <div class="bar" style="margin:0">
   <label class="lbl" for="coin">Coin</label><select id="coin"></select>
   <label class="lbl" for="src">Quelle</label>
   <select id="src" title="Datenquelle für alle Abschnitte">
    <option value="hl" selected>Hyperliquid Daten</option>
    <option value="bnc">Binance Daten</option>
    <option value="fusion">Hyperliquid + Binance Fusion</option></select>
   <button onclick="load()" title="alle Daten jetzt neu laden">Neu laden</button>
  </div>
 </div>
 <nav class="nav">
  <a href="#sec-chart">Chart</a><a href="#sec-signal">Konfluenz</a><a href="#sec-orders">Orders &amp; Stops</a>
  <a href="#sec-heat">Heatmap</a><a href="#sec-depth">Momentaufnahme</a><a href="#sec-whales">Wale</a>
  <a href="#sec-update" class="dim">Update</a>
  <a class="dim" onclick="toggleAll()" style="margin-left:auto" title="alle Abschnitte ein- oder ausklappen">alle ▾/▸</a>
 </nav>
</div>
<div class="sub" style="margin:8px 0 0">Echte Positionen aus der Kette, keine Schätzung. Kurs und Cluster aktualisieren sich automatisch;
 Tippen oder Fahren über eine Grafik zeigt Werte und Fadenkreuz. Jeder Abschnitt lässt sich am Titel einklappen, „ⓘ" zeigt die Erklärung.</div>

<div class="kpi" id="kpi"></div>

<div class="panel" id="sec-chart" data-sec="chart">
 <h2 class="sech" onclick="toggleSec('chart')"><span class="num">1</span><span class="ttl">Live-Chart — Kurs mit aktuellen Liquidationsmarken</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="tf">Raster</label>
  <select id="tf"><option value="1|120">1 min · 2 h</option>
   <option value="5|720" selected>5 min · 12 h</option>
   <option value="15|2880">15 min · 2 Tage</option>
   <option value="60|10080">1 h · 7 Tage</option>
   <option value="240|43200">4 h · 30 Tage</option>
   <option value="1440|525600">1 Tag · 1 Jahr</option>
   <option value="10080|2628000">1 Woche · 5 Jahre</option></select>
  <button id="fvgtoggle" class="tog on" title="Fair Value Gaps ein- oder ausblenden">FVG an</button>
  <label class="lbl" for="fvg" title="Fair Value Gaps, die kleiner sind als dieser Anteil des Kurses, gelten als Rauschen und werden nicht gezeichnet">FVG-Mindestgröße</label>
  <select id="fvg" title="Lücken kleiner als dieser Anteil des Kurses werden ignoriert"><option value="0.0005" selected>0,05 % des Kurses</option>
   <option value="0.001">0,1 % des Kurses</option>
   <option value="0.0025">0,25 % des Kurses</option></select>
 </div>
 <div class="sub help" style="display:none">Waagerechte Linien sind Preisniveaus, auf denen gehebelte
  Positionen zwangsliquidiert würden. Rechts steht je Linie das Notional und der
  Abstand zum Kurs.</div>
 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Short-Liquidationen (über dem Kurs)</span>
  <span><i class="sw" style="background:#e04b4b"></i>Long-Liquidationen (unter dem Kurs)</span>
  <span>durchgezogen = ab halbem Stundenvolumen · gestrichelt = darunter</span>
  <span><i class="sw" style="background:rgba(57,255,20,.35);border:1px solid #39ff14"></i>bullisches FVG</span>
  <span><i class="sw" style="background:rgba(224,75,75,.35);border:1px solid #e04b4b"></i>bärisches FVG</span>
  <span>kräftig = offen · blass = gefüllt</span>
  <span title="Ein FVG ist die Lücke zwischen dem Hoch von Kerze 1 und dem Tief von Kerze 3 (bullisch) bzw. umgekehrt. Die FVG-Mindestgröße ist diese Lücke als Anteil des Kurses: 0,05 % bei 80.000 sind 40 USD. Kleinere Lücken werden nicht gezeichnet.">FVG-Mindestgröße = Lücke als Anteil des Kurses ⓘ</span>
  <span><i class="sw" style="background:#39d3ff"></i>Support</span>
  <span><i class="sw" style="background:#c678dd"></i>Resistance</span>
  <span><i class="sw" style="background:#8b949e"></i>Take-Profits</span>
  <span><i class="sw" style="background:#e04b4b"></i>/<i class="sw" style="background:#3ba55d"></i> Stops (gepunktet)</span>
  <span><i class="sw" style="background:#ff9f43"></i>Binance-Liquidation ▲▼</span>
  <span><i class="sw" style="background:#ff3b6b"></i>HL-Liquidation ▲▼ (Binance/Fusion)</span>
 </div>
 <canvas id="chart" height="400" data-hm="340"></canvas>
 <div class="sub" id="chartinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-signal" data-sec="signal">
 <h2 class="sech" onclick="toggleSec('signal')"><span class="num">2</span><span class="ttl">Konfluenz — welche Faktoren zeigen in dieselbe Richtung?</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Eine Zählung sichtbarer Faktoren, keine Prognose. Jede Regel steht
  daneben, damit du sie prüfen und verwerfen kannst. Die zugrunde liegende These —
  Cluster ziehen, Lücken werden gefüllt — ist genau das, was der Recorder erst noch
  belegen muss. <b>Nicht validiert.</b></div>

 <div id="signalbox" style="margin-top:8px;padding:10px 12px;background:#161b22;
  border:1px solid #21262d;border-radius:6px;font-size:12px;line-height:1.6"></div>

 </div></div>

<div class="panel" id="sec-orders" data-sec="orders">
 <h2 class="sech" onclick="toggleSec('orders')"><span class="num">3</span><span class="ttl">Wartende Orders und Stops — Konten ab 250k USD</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Trigger-Orders stehen nicht im Orderbuch: Sie werden erst am Auslösepreis zu
  Market-Orders — wie Liquidationen. Sell-Stops unter dem Kurs lösen Verkaufskaskaden aus,
  Buy-Stops darüber Kaufkaskaden. Take-Profits und ruhende Limit-Orders wirken gegenteilig,
  sie absorbieren. Abgefragt werden alle Konten ab 250k USD, gestaffelt nach Größe: ab 20 Mio
  alle 10 Minuten, 5–20 Mio alle 45 Minuten, 1–5 Mio alle 3 Stunden, darunter alle 6 Stunden —
  so passt es ins API-Budget. Gezeigt wird je Konto der jüngste Stand. Fahren oder Tippen zeigt
  ein Fadenkreuz mit dem Preis.</div>

 <div class="leg">
  <span><i class="sw" style="background:#e04b4b"></i>Sell-Stop (Verkaufskaskade)</span>
  <span><i class="sw" style="background:#3ba55d"></i>Buy-Stop (Kaufkaskade)</span>
  <span><i class="sw" style="background:#39d3ff"></i>Limit-Kauf (Kaufwand)</span>
  <span><i class="sw" style="background:#c678dd"></i>Limit-Verkauf (Verkaufswand)</span>
  <span><i class="sw" style="background:#8b949e"></i>Take-Profit</span>
 </div>
 <canvas id="stops" height="720" data-hm="560"></canvas>
 <div class="sub" id="stopsinfo"></div>
 <div id="stopslevels" style="margin-top:8px;overflow-x:auto"></div>

 </div></div>

<div class="panel" id="sec-heat" data-sec="heat">
 <h2 class="sech" onclick="toggleSec('heat')"><span class="num">4</span><span class="ttl">Heatmap — Clusterentwicklung über die Zeit</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="bar" style="margin:4px 0 8px">
  <label class="lbl" for="hours">Zeitraum</label>
  <select id="hours"><option value="6">6 h</option><option value="24" selected>24 h</option>
   <option value="72">3 Tage</option><option value="168">7 Tage</option></select>
 </div>
 <div class="sub help" style="display:none">Waagerecht die Zeit, senkrecht der Preis. Die Farbe zeigt den
  Rang einer Zelle unter allen anderen, nicht den Absolutwert — sonst würde ein
  einzelner Großcluster die Skala verzerren.</div>
 <div class="bar">
  <label class="lbl" for="thr">Liquiditäts-Schwelle</label>
  <input type="range" id="thr" min="0" max="97" value="70" style="width:190px">
  <span class="sub" id="thrval" style="min-width:92px">Perzentil 70</span>
 </div>
 <div class="leg">
  <span>schwach<i class="grad" style="margin:0 6px;display:inline-block"></i>stark</span>
  <span><i class="sw" style="background:#fff"></i>Kursverlauf</span>
  <span><i class="sw" style="background:#ff3b6b"></i>eingetretene Liquidation</span>
 </div>
 <canvas id="heat" height="430" data-hm="360"></canvas>
 <div class="sub" id="heatinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-depth" data-sec="depth">
 <h2 class="sech" onclick="toggleSec('depth')"><span class="num">5</span><span class="ttl">Momentaufnahme — Cluster rund um den aktuellen Kurs</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Senkrecht der Preis, Balkenlänge das Notional. Die gestrichelte
  Linie markiert das halbe Stundenvolumen: Cluster links davon werden vom Markt
  eher geschluckt, ohne den Kurs zu bewegen.</div>

 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Short-Liquidationen</span>
  <span><i class="sw" style="background:#e04b4b"></i>Long-Liquidationen</span>
  <span><i class="sw" style="background:#00e5ff"></i>aktueller Kurs</span>
 </div>
 <canvas id="depth" height="430" data-hm="360"></canvas>
 <div class="sub" id="depthinfo" style="margin-top:5px"></div>

 </div></div>

<div class="panel" id="sec-whales" data-sec="whales">
 <h2 class="sech" onclick="toggleSec('whales')"><span class="num">6</span><span class="ttl">Wale — Positionen ab 20 Mio. USD</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Oben die Netto-Ausrichtung aller Wale (grün = mehr Long, rot = mehr
  Short) gegen den Kurs. Darunter jede aktuell offene Wal-Position mit Einstieg,
  Liquidationspreis und Abstand dorthin — über alle Coins, der gewählte ist hervorgehoben.
  Ganz unten die letzten Änderungen im gewählten Coin.
  <b>Vorsicht bei der Deutung:</b> Ein großer Short kann eine abgesicherte
  Spot-Position sein und sagt dann nichts über die Erwartung des Halters.</div>

 <div class="leg">
  <span><i class="sw" style="background:#3ba55d"></i>Long-Exposure</span>
  <span><i class="sw" style="background:#e04b4b"></i>Short-Exposure</span>
  <span><i class="sw" style="background:#fff"></i>Kurs</span>
  <span>▲ öffnet / stockt auf &nbsp; ▼ reduziert / schließt</span>
 </div>
 <canvas id="whalechart" height="260" data-hm="220"></canvas>
 <div id="whaletable" style="margin-top:10px;overflow-x:auto"></div>
 <div id="whaleevents" class="sub" style="margin-top:8px"></div>
 <div id="bncmetrics" style="display:none;margin-top:10px">
  <div class="leg"><span><i class="sw" style="background:#58a6ff"></i>Open Interest (USD)</span>
   <span><i class="sw" style="background:#d29922"></i>Long/Short-Verhältnis Konten (global)</span>
   <span><i class="sw" style="background:#c678dd"></i>Long/Short Top-Trader (Position)</span>
   <span><i class="sw" style="background:#3ba55d"></i>Taker Kauf/Verkauf</span></div>
  <canvas id="metricschart" height="260" data-hm="220"></canvas>
  <div class="sub" id="metricsinfo"></div>
 </div>
</div>

<div class="warn" id="warn">
 </div></div>
<div class="panel" id="sec-update" data-sec="update" id="updatepanel">
 <h2 class="sech" onclick="toggleSec('update')"><span class="ttl">Aktualisierung</span><a class="help" onclick="event.stopPropagation();toggleHelp(this)" title="Erklärung ein-/ausblenden">ⓘ</a><span class="chev">▾</span></h2>
 <div class="body">
<div class="sub help" style="display:none">Lädt das Archiv von GitHub und spielt es mit <code>update.py</code> ein: Dienste stoppen,
  Dateien ersetzen, Syntaxprüfung mit Rückrollen, Units erneuern, Dienste starten. Das Dashboard
  ist dabei etwa eine Minute nicht erreichbar; die Seite wartet und lädt danach selbst neu.
  Braucht <code>sudo.txt</code> (Rechte 600) im Projektordner.</div>

 <button id="updbtn" class="tog off" style="margin-top:8px;min-width:220px">Update von GitHub einspielen</button>
 <pre id="updlog" style="display:none;margin-top:8px;background:#0d1117;border:1px solid #21262d;border-radius:6px;
   padding:10px;font-size:11px;max-height:320px;overflow:auto;white-space:pre-wrap"></pre>
</div>

<div id="tip"></div>

<div id="boot" style="background:#7a1f1f;color:#fff;padding:8px 14px;font:13px monospace;white-space:pre-wrap">Dashboard-Skript wird geladen … (bleibt diese Zeile stehen, ist das Skript nicht gestartet)
 </div></div>
<script>
// Eigenständiger Wächter: fängt auch Parse-Fehler des Hauptskripts, die dort selbst nichts mehr melden könnten
window.onerror=function(msg,src,line,col,err){
 var b=document.getElementById('boot'); if(!b) return;
 b.style.display='block';
 b.textContent='Skriptfehler: '+msg+' (Zeile '+line+', Spalte '+col+')'+(err&&err.stack?'\\n'+String(err.stack).split('\\n').slice(0,3).join('\\n'):'');
};
window.addEventListener('unhandledrejection',function(e){
 var b=document.getElementById('boot'); if(!b) return;
 b.style.display='block'; b.textContent='Ladefehler: '+(e.reason&&e.reason.message||e.reason);
});
</script>
<script>
document.getElementById('boot').style.display='none';   // Hauptskript läuft
const $=id=>document.getElementById(id);
// Fehler sichtbar machen: statt still in der Konsole zu landen, erscheinen sie oben auf der Seite
function showErr(t){
 let b=document.getElementById('errbar');
 if(!b){b=document.createElement('div');b.id='errbar';
  b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:99;background:#7a1f1f;color:#fff;'
   +'padding:8px 14px;font:13px monospace;white-space:pre-wrap;border-bottom:2px solid #e04b4b';
  document.body.prepend(b);}
 const line=new Date().toLocaleTimeString('de-DE')+'  '+t;
 b.textContent=(b.textContent?b.textContent+'\\n':'')+line;
 if(b.textContent.split('\\n').length>6) b.textContent=b.textContent.split('\\n').slice(-6).join('\\n');
}
addEventListener('error',e=>showErr('Skriptfehler: '+e.message+' (Zeile '+e.lineno+')'));
addEventListener('unhandledrejection',e=>showErr('Ladefehler: '+(e.reason&&e.reason.message||e.reason)));
async function getJSON(url){
 let r;
 try{ r=await fetch(url); }catch(e){ showErr(url.split('?')[0]+': keine Verbindung ('+e.message+')'); throw e; }
 if(!r.ok){ const t=await r.text(); showErr(url.split('?')[0]+': HTTP '+r.status+' '+t.slice(0,160)); throw new Error('HTTP '+r.status); }
 try{ return await r.json(); }catch(e){ showErr(url.split('?')[0]+': keine gültige Antwort ('+e.message+')'); throw e; }
}
let LAST=null, LAST_DEPTH=null, LAST_DATA=null, LAST_CHART=null, LAST_HEALTH=null, GEO={}, FVG_ON=true;
function SRC(){ const e=document.getElementById('src'); return e?e.value:'hl'; }
// Verhältnis x:1 als Kachel: Wert, darunter die Aufteilung in Prozent, Definition als Tooltip
function ratioTile(label, v, aWord, bWord, defn){
 // Verhältnis a:b -> "1,27 : 1" und darunter "56 % <aWord> · 44 % <bWord>"
 if(v==null||!isFinite(v)) return `<div title="${defn}"><span>${label}</span><b>—</b></div>`;
 const share=v/(1+v)*100, col=v>1.15?'#3ba55d':v<0.87?'#e04b4b':'#c9d1d9';
 return `<div title="${defn}"><span>${label}</span><b style="color:${col}">${(+v).toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2})} : 1`
  +`<span class="d">${share.toFixed(0)} % ${aWord} · ${(100-share).toFixed(0)} % ${bWord}</span></b></div>`;
}
const SRC_NAME={hl:'Hyperliquid',bnc:'Binance',fusion:'Hyperliquid + Binance'};
function setFvg(on){
 FVG_ON=on; const b=$('fvgtoggle'); if(!b) return;
 b.textContent=on?'FVG an':'FVG aus'; b.className='tog '+(on?'on':'off');
 if(LAST_CHART) drawChart(LAST_CHART);
}
function fillHealth(h){
 const b=$('kpi_backup'), d=$('kpi_db'); if(!b||!d) return;
 const bk=h.backup;
 if(!bk){ b.textContent='noch keines'; b.style.color='#d29922'; b.title='läuft 5 min nach Recorder-Start'; }
 else if(bk.ok){
  const age=(Date.now()/1000-bk.ts)/3600;
  b.textContent=hm(bk.ts); b.style.color=age<26?'#3ba55d':age<50?'#d29922':'#e04b4b';
  b.title=`vor ${age.toFixed(1)} h · ${(bk.size/1e6).toFixed(0)} MB · ${(bk.bars||0).toLocaleString('de-DE')} Bars`;
 } else {
  b.textContent='fehlgeschlagen'; b.style.color='#e04b4b';
  b.title=(bk.error||'')+(bk.last_good?` · gutes Backup von ${hm(bk.last_good)} liegt vor`:'');
 }
 if(h.db_ok===true){ d.textContent='OK'; d.style.color='#3ba55d';
  d.title=`quick_check bestanden · ${(h.db_size/1e6).toFixed(0)} MB · geprüft ${hm(h.checked_at)}`; }
 else if(h.db_ok===false){ d.textContent='BESCHÄDIGT'; d.style.color='#e04b4b';
  d.title=h.db_detail||'quick_check fehlgeschlagen'; }
 else if(h.checking){ d.textContent='prüft …'; d.style.color='#d29922'; d.title='quick_check läuft im Hintergrund'; }
 else { d.textContent='—'; d.style.color=''; }
}
// ---- Stop-Orders der Wale ----------------------------------------------------
// ---- Schlüsselniveaus aus den Orders: eine Rechnung für Panel, Chart und Konfluenz ----
function keyLevels(d){
 const S=(d&&d.stops&&d.stops.clusters)||[], p0=d&&(d.price||(d.candles&&d.candles.length?d.candles[d.candles.length-1].c:0));
 if(!S.length||!p0) return null;
 const inR=s=>Math.abs(s.dist)<=0.30;
 const best=(kind,sign)=>S.filter(s=>s.kind===kind&&inR(s)&&Math.sign(s.dist)===sign).sort((a,b)=>b.notional-a.notional)[0]||null;
 const nearest=(kind,sign)=>S.filter(s=>s.kind===kind&&inR(s)&&Math.sign(s.dist)===sign).sort((a,b)=>Math.abs(a.dist)-Math.abs(b.dist))[0]||null;
 const sum=(kind,sign,within)=>S.filter(s=>s.kind===kind&&Math.sign(s.dist)===sign&&Math.abs(s.dist)<=within).reduce((a,s)=>a+s.notional,0);
 return {
  support:    best('limit_buy',-1),          // größte Kaufwand unter dem Kurs
  resistance: best('limit_sell',1),          // größte Verkaufswand darüber
  tp_long:    best('tp_sell',1),             // Take-Profits der Longs (Verkauf oben)
  tp_short:   best('tp_buy',-1),             // Take-Profits der Shorts (Kauf unten)
  stop_sell:  best('stop_sell',-1), stop_sell_near: nearest('stop_sell',-1), stop_sell_2pct: sum('stop_sell',-1,0.02),
  stop_buy:   best('stop_buy',1),   stop_buy_near:  nearest('stop_buy',1),   stop_buy_2pct:  sum('stop_buy',1,0.02),
 };
}
const KEY_STYLE={support:['SUPPORT','#39d3ff'],resistance:['RESISTANCE','#c678dd'],tp_long:['TAKE-PROFIT LONGS','#8b949e'],
  tp_short:['TAKE-PROFIT SHORTS','#8b949e'],stop_sell:['SELL-STOPS','#e04b4b'],stop_buy:['BUY-STOPS','#3ba55d']};

function drawStops(d){
 const c=$('stops'); if(!c) return; const [g,W,H]=fit(c); g.clearRect(0,0,W,H);
 const S=(d.stops&&d.stops.clusters)||[], p0=d.price||(d.candles&&d.candles.length?d.candles[d.candles.length-1].c:0);
 const narrow=W<600, L=narrow?58:76, R=narrow?8:12, T=14, B=26, pw=W-L-R, ph=H-T-B;
 const info=$('stopsinfo'), lv=$('stopslevels');
 if(!S.length||!p0){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.textAlign='center';
  g.fillText(d.stops&&d.stops.n_whales?'Keine offenen Orders der Großkonten in diesem Coin':'Noch keine Order-Abfragen — der Recorder fragt Wale alle 2 Minuten', W/2, H/2);
  g.textAlign='left'; if(info) info.textContent=(d.stops&&d.stops.book&&SRC()==='bnc')?'Binance-Orderbuch derzeit nicht abrufbar — Netzverbindung des Pi prüfen; die Seite versucht es alle 5 s erneut':''; if(lv) lv.innerHTML=''; GEO.stops=null; return; }
 // Preisbereich fest ±30 %, Kaufseite links, Verkaufsseite rechts der Mittelachse
 let lo=p0*0.70, hi=p0*1.30; const pad=(hi-lo)*0.03; lo-=pad; hi+=pad;
 const Y=p=>T+(hi-p)/(hi-lo)*ph, mid=L+pw/2, half=pw/2-8;
 const inR=s=>s.px>=lo&&s.px<=hi;
 const BUY=['limit_buy','stop_buy','tp_buy'], SELL=['limit_sell','stop_sell','tp_sell'];
 const col={stop_sell:'#e04b4b',stop_buy:'#3ba55d',tp_sell:'#8b949e',tp_buy:'#8b949e',limit_sell:'#c678dd',limit_buy:'#39d3ff'};
 // je Preisstufe und Seite ein gestapelter Balken: Segmente nach Art
 const rows=new Map();
 S.filter(inR).forEach(s=>{ const side=BUY.includes(s.kind)?'buy':'sell'; const k=s.px.toFixed(4)+side;
  const r=rows.get(k)||{px:s.px,side,total:0,segs:[],addrs:0,n:0,dist:s.dist}; r.total+=s.notional; r.segs.push(s); r.addrs=Math.max(r.addrs,s.addrs); r.n+=s.n; rows.set(k,r); });
 const mx=Math.max(...[...rows.values()].map(r=>r.total),1);
 // Gitter und Preisachse
 g.strokeStyle='#161b22'; g.lineWidth=1;
 for(let k=0;k<=6;k++){const y=T+ph*k/6; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='right';
 for(let k=0;k<=6;k++){const p=lo+(hi-lo)*(1-k/6); g.fillText(px(p).slice(0,9), L-6, T+ph*k/6+3);}
 g.textAlign='left';
 // Mittelachse und Seitentitel
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(mid,T); g.lineTo(mid,H-B); g.stroke();
 g.fillStyle='#8b949e'; g.font='bold 10px system-ui'; g.textAlign='right'; g.fillText('◀ KAUFSEITE', mid-6, T+10);
 g.textAlign='left'; g.fillText('VERKAUFSSEITE ▶', mid+6, T+10);
 const bars=[]; const h=Math.max(3,Math.min(8,ph/60));
 const order=[...rows.values()].sort((a,b)=>b.px-a.px);
 order.forEach(r=>{ const y=Y(r.px), w=Math.max(3,half*r.total/mx);
  let x=r.side==='buy'?mid-2:mid+2, dir=r.side==='buy'?-1:1;
  const kinds=r.side==='buy'?BUY:SELL;
  kinds.forEach(kd=>{ r.segs.filter(s=>s.kind===kd).forEach(s=>{ const sw=Math.max(1,w*s.notional/r.total);
   g.fillStyle=col[kd]; g.globalAlpha=kd.startsWith('tp')?0.6:kd.startsWith('limit')?0.8:1;
   g.fillRect(dir<0?x-sw:x, y-h/2, sw, h); g.globalAlpha=1; x+=dir*sw; }); });
  bars.push({y,h,r,x0:Math.min(mid,x),x1:Math.max(mid,x)}); });
 // Beschriftung der größten Balken, kollisionsfrei je Seite
 g.font='10px system-ui'; ['buy','sell'].forEach(side=>{ let last=-99;
  bars.filter(b=>b.r.side===side&&b.r.total>=mx*0.12).sort((a,b)=>a.y-b.y).forEach(b=>{ if(Math.abs(b.y-last)<11) return; last=b.y;
   const t=fmt(b.r.total)+(b.r.addrs>1?` · ${b.r.addrs} K.`:''); g.fillStyle='#c9d1d9';
   if(side==='buy'){ g.textAlign='right'; g.fillText(t, b.x0-5, b.y+4); } else { g.textAlign='left'; g.fillText(t, b.x1+5, b.y+4); } }); });
 g.textAlign='left';
 // Schlüsselniveaus markieren
 const K=keyLevels(d)||{};
 Object.entries(KEY_STYLE).forEach(([k,[label,color]])=>{ const s=K[k]; if(!s||s.px<lo||s.px>hi) return; const y=Y(s.px);
  g.strokeStyle=color; g.lineWidth=1; g.setLineDash([2,3]); g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
  g.fillStyle=color; g.font='bold 9px system-ui'; const onBuy=['support','tp_short','stop_sell'].includes(k);
  g.textAlign=onBuy?'left':'right'; g.fillText(label, onBuy?L+3:W-R-3, y-4); });
 g.textAlign='left';
 // Kurs
 const y0=Y(p0); g.strokeStyle='#58a6ff'; g.setLineDash([5,4]); g.lineWidth=1.5;
 g.beginPath(); g.moveTo(L,y0); g.lineTo(W-R,y0); g.stroke(); g.setLineDash([]);
 g.fillStyle='#58a6ff'; g.fillRect(W-R-60,y0-8,60,16); g.fillStyle='#0d1117'; g.font='bold 10px system-ui';
 g.textAlign='right'; g.fillText(px(p0).slice(0,9), W-R-4, y0+4); g.textAlign='left';
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText('Balkenlänge = Notional · gestapelt nach Art', L, H-8);
 GEO.stops={bars,L,T,B,pw,ph,W,H,R,lo,hi,mid};
 if(info&&d.stops.book&&SRC()==='bnc') info.innerHTML=`Binance-Orderbuch (bis 1.000 Stufen je Seite, ±30 %): ${d.stops.clusters.length} Preisstufen · Bereich ±30 % · Stand ${hm(d.stops.ts)}`;
 else if(info&&SRC()==='fusion') info.innerHTML=`Fusion: ${d.stops.n_whales} HL-Konten abgefragt (${d.stops.n_with_orders||0} mit Orders) + Binance-Orderbuch mit ${d.stops.book_n||0} Stufen — je Preisstufe summiert · Bereich ±30 %`;
 else if(info) info.innerHTML=`${d.stops.n_whales} Konten abgefragt, davon <b>${d.stops.n_with_orders||0}</b> mit Orders in ${$('coin').value} innerhalb ±30 % `
  +`(${d.stops.n_fresh||0} in den letzten 20 min abgefragt`
  +(d.stops.oldest?`, ältester Stand vor ${Math.round((Date.now()/1000-d.stops.oldest)/60)} min`:'')+`)`
  +(d.stops.ts?` · jüngste Abfrage ${hm(d.stops.ts)}`:'')
  +` · Spalte „Konten" in der Tabelle = Konten am jeweiligen Preisniveau`;
 // Live-Auswertung
 if(lv){ const row=(label,s,extra)=>`<tr><td>${label}</td><td class="n" style="color:${extra}">${s?px(s.px):'—'}</td>`
    +`<td class="n">${s?(s.dist*100).toFixed(2)+' %':'—'}</td><td class="n">${s?fmt(s.notional):'—'}</td><td class="n">${s?s.addrs:'—'}</td></tr>`;
  lv.innerHTML=`<table class="w"><tr><th>Niveau</th><th class="n">Preis</th><th class="n">Abstand</th><th class="n">Notional</th><th class="n">Konten</th></tr>`
   +row('Support — größte Kaufwand unter dem Kurs', K.support, '#39d3ff')
   +row('Resistance — größte Verkaufswand über dem Kurs', K.resistance, '#c678dd')
   +row('Höchste Take-Profits der Longs (Verkauf oben)', K.tp_long, '#8b949e')
   +row('Höchste Take-Profits der Shorts (Kauf unten)', K.tp_short, '#8b949e')
   +row('Größtes Sell-Stop-Cluster unter dem Kurs (Verkaufskaskade)', K.stop_sell, '#e04b4b')
   +row('Nächster Sell-Stop unter dem Kurs', K.stop_sell_near, '#e04b4b')
   +row('Größtes Buy-Stop-Cluster über dem Kurs (Kaufkaskade)', K.stop_buy, '#3ba55d')
   +row('Nächster Buy-Stop über dem Kurs', K.stop_buy_near, '#3ba55d')
   +`<tr><td>Sell-Stops innerhalb 2 % unter dem Kurs</td><td class="n" colspan="3" style="color:#e04b4b">${fmt(K.stop_sell_2pct||0)} USD</td><td></td></tr>`
   +`<tr><td>Buy-Stops innerhalb 2 % über dem Kurs</td><td class="n" colspan="3" style="color:#3ba55d">${fmt(K.stop_buy_2pct||0)} USD</td><td></td></tr>`
   +`</table>`; }
}
function crosshair(c, G, x, y, price){
 // waagerechte Preislinie mit Etikett am Rand, dazu eine senkrechte Linie an der Zeigerposition
 const g=c.getContext('2d'), d=devicePixelRatio||1; g.save(); g.setTransform(d,0,0,d,0,0);
 g.strokeStyle='rgba(201,209,217,0.55)'; g.lineWidth=1; g.setLineDash([4,3]);
 g.beginPath(); g.moveTo(G.L,y); g.lineTo(G.W-G.R,y); g.stroke();
 g.beginPath(); g.moveTo(x,G.T); g.lineTo(x,G.H-G.B); g.stroke(); g.setLineDash([]);
 const t=px(price).slice(0,10); g.font='bold 10px system-ui'; const w=g.measureText(t).width+10;
 g.fillStyle='#c9d1d9'; g.fillRect(G.L-w-2,y-8,w,16); g.fillStyle='#0d1117'; g.textAlign='right'; g.fillText(t,G.L-7,y+4);
 g.textAlign='left'; g.restore();
}
function tipStops(ev){
 const G=GEO.stops, c=$('stops'); if(!G) return hideTip();
 const r=c.getBoundingClientRect(), y=ev.clientY-r.top, x=ev.clientX-r.left;
 if(y>=G.T&&y<=G.H-G.B&&LAST_CHART){ drawStops(LAST_CHART); crosshair(c,G,x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const side=x<G.mid?'buy':'sell';
 const hit=G.bars.filter(b=>b.r.side===side&&Math.abs(b.y-y)<=Math.max(b.h,6)).sort((a,b)=>Math.abs(a.y-y)-Math.abs(b.y-y))[0];
 if(!hit) return hideTip();
 const name={stop_sell:'Sell-Stops',stop_buy:'Buy-Stops',tp_sell:'Take-Profit (Verkauf)',tp_buy:'Take-Profit (Kauf)',limit_sell:'Limit-Verkäufe',limit_buy:'Limit-Käufe'};
 const rows=hit.r.segs.map(s=>[name[s.kind]||s.kind, fmt(s.notional)+' USD · '+s.n+' Orders · '+s.addrs+' Konten']);
 rows.push(['Abstand',(hit.r.dist*100).toFixed(2)+' %', hit.r.dist<0?'#e04b4b':'#3ba55d']);
 showTip(ev, (side==='buy'?'Kaufseite bei ':'Verkaufsseite bei ')+px(hit.r.px)+' · '+fmt(hit.r.total), rows);
}

// ---- Konfluenz: transparente Regeln, jede mit Begründung --------------------
let LAST_WHALES=null, SIGNAL=null;
function computeSignal(){
 const d=LAST_CHART; if(!d||!d.candles||!d.candles.length) return;
 const px0=d.price||d.candles[d.candles.length-1].c;
 const R=[], zones=[]; let buy=0, sell=0;
 const add=(side,pts,text)=>{ if(side==='buy')buy+=pts; else if(side==='sell')sell+=pts; R.push({side,pts,text}); };
 const near=(v,pct)=>Math.abs(v)<=pct;

 // 1. Liquidationscluster: Nähe = Anlauf wahrscheinlich (warten), frisch abgeräumt = Umkehrchance
 // (im Binance-Modus sind die Marken EINGETRETENE Liquidationen -- dafür gelten die Binance-Regeln unten)
 const L=d.levels_realized?[]:(d.levels||[]);
 const big=l=>l.x_vol>=0.5;
 const dn=L.filter(l=>l.side==='long'&&big(l)&&l.dist<0).sort((a,b)=>b.dist-a.dist)[0];
 const up=L.filter(l=>l.side==='short'&&big(l)&&l.dist>0).sort((a,b)=>a.dist-b.dist)[0];
 if(dn&&near(dn.dist,0.006)) add('wait',0,`Großes Long-Cluster ${(dn.dist*100).toFixed(2)} % unter dem Kurs (${fmt(dn.notional)}) — Anlauf wahrscheinlich, Kauf erst nach Abholung`);
 if(up&&near(up.dist,0.006)) add('wait',0,`Großes Short-Cluster ${(up.dist*100).toFixed(2)} % über dem Kurs (${fmt(up.notional)}) — Anlauf wahrscheinlich, Verkauf erst nach Abholung`);
 const ev=(d.tick_events||[]).filter(e=>Date.now()/1000-e.t_trigger/1000<3600)[0];
 if(ev){ const rec=(px0/ev.px_extreme-1);
  if(ev.move_pct<0&&rec>0.003&&ev.n_liqs>0){ add('buy',2,`Long-Kaskade vor ${Math.round((Date.now()/1000-ev.t_trigger/1000)/60)} min (${(ev.move_pct*100).toFixed(2)} %, ${ev.n_liqs} Liqs), Kurs ${(rec*100).toFixed(2)} % über dem Tief — Cluster abgeräumt`);
   zones.push({kind:'buy',bot:ev.px_extreme,top:ev.px_extreme*1.006,text:'Kaskadentief'}); }
  if(ev.move_pct>0&&rec<-0.003&&ev.n_liqs>0){ add('sell',2,`Short-Squeeze vor ${Math.round((Date.now()/1000-ev.t_trigger/1000)/60)} min (${(ev.move_pct*100).toFixed(2)} %, ${ev.n_liqs} Liqs), Kurs ${(-rec*100).toFixed(2)} % unter dem Hoch — Cluster abgeräumt`);
   zones.push({kind:'sell',bot:ev.px_extreme*0.994,top:ev.px_extreme,text:'Squeeze-Hoch'}); }
 }

 // 1b. Stop-Orders der Wale: Sell-Stops dicht unter dem Kurs = Kaskade nach unten droht,
 //     Buy-Stops dicht darüber = Kaskade nach oben. Wie Cluster: erst abwarten, dann handeln.
 //     Frisch ausgelöste Stops erkennt man daran, dass sie verschwunden sind -- das
 //     übernimmt die Kaskaden-Regel oben über die tatsächlichen Liquidationsfills.
 const SC=(d.stops&&d.stops.clusters)||[], vol1h=d.vol_1h||0;
 const bigStop=s=>s.notional>=Math.max(vol1h*0.25, 5e6);
 const sellStop=SC.filter(s=>s.kind==='stop_sell'&&s.dist<0&&s.dist>-0.008&&bigStop(s)).sort((a,b)=>b.dist-a.dist)[0];
 const buyStop =SC.filter(s=>s.kind==='stop_buy' &&s.dist>0&&s.dist< 0.008&&bigStop(s)).sort((a,b)=>a.dist-b.dist)[0];
 if(sellStop) add('wait',0,`Sell-Stops ${(sellStop.dist*100).toFixed(2)} % unter dem Kurs (${fmt(sellStop.notional)}, ${sellStop.addrs} Konten) — Verkaufskaskade droht, kein Long davor`);
 if(buyStop)  add('wait',0,`Buy-Stops +${(buyStop.dist*100).toFixed(2)} % über dem Kurs (${fmt(buyStop.notional)}, ${buyStop.addrs} Konten) — Kaufkaskade möglich, kein Short davor`);
 // Ruhende Limit-Orders: eine Kaufwand dicht unter dem Kurs stützt, eine Verkaufswand darüber deckelt.
 // Take-Profits wirken wie Limits (sie absorbieren), zählen aber nur als Hinweis.
 // Schlüsselniveaus -- dieselbe Rechnung wie Panel und Chart (keyLevels)
 const K=keyLevels(d)||{}, wall=s=>s&&s.notional>=Math.max(vol1h*0.5, 10e6);
 if(wall(K.support)&&K.support.dist>-0.01)      add('buy',1,`Support ${(K.support.dist*100).toFixed(2)} % unter dem Kurs: Kaufwand ${fmt(K.support.notional)} (${K.support.addrs} Konten)`);
 else if(K.support&&K.support.dist>-0.01)       add('warn',0,`Support ${(K.support.dist*100).toFixed(2)} % unter dem Kurs, aber klein (${fmt(K.support.notional)}) — kein Punkt`);
 if(wall(K.resistance)&&K.resistance.dist<0.01) add('sell',1,`Resistance +${(K.resistance.dist*100).toFixed(2)} % über dem Kurs: Verkaufswand ${fmt(K.resistance.notional)} (${K.resistance.addrs} Konten)`);
 else if(K.resistance&&K.resistance.dist<0.01)  add('warn',0,`Resistance +${(K.resistance.dist*100).toFixed(2)} % über dem Kurs, aber klein (${fmt(K.resistance.notional)}) — kein Punkt`);
 if(wall(K.tp_long)&&K.tp_long.dist<0.01)   add('warn',0,`Take-Profits der Longs +${(K.tp_long.dist*100).toFixed(2)} % über dem Kurs: ${fmt(K.tp_long.notional)} — Verkaufsdruck beim Anstieg (Hinweis)`);
 if(wall(K.tp_short)&&K.tp_short.dist>-0.01) add('warn',0,`Take-Profits der Shorts ${(K.tp_short.dist*100).toFixed(2)} % unter dem Kurs: ${fmt(K.tp_short.notional)} — Kaufdruck beim Rückgang (Hinweis)`);
 // Kaskadenmasse dicht am Kurs, unabhängig vom größten Einzelcluster
 if((K.stop_sell_2pct||0)>=Math.max(vol1h*0.5,10e6)) add('wait',0,`Sell-Stops innerhalb 2 % unter dem Kurs summieren sich auf ${fmt(K.stop_sell_2pct)} — Verkaufskaskade bei Unterschreiten`);
 if((K.stop_buy_2pct||0) >=Math.max(vol1h*0.5,10e6)) add('wait',0,`Buy-Stops innerhalb 2 % über dem Kurs summieren sich auf ${fmt(K.stop_buy_2pct)} — Kaufkaskade bei Überschreiten`);

 // Stops UND Liquidationscluster auf derselben Seite dicht am Kurs: doppelter Magnet
 if(sellStop&&dn&&near(dn.dist,0.008)) add('wait',0,`Sell-Stops und Long-Liquidationen liegen beide dicht unter dem Kurs — doppelter Magnet nach unten`);
 if(buyStop&&up&&near(up.dist,0.008))  add('wait',0,`Buy-Stops und Short-Liquidationen liegen beide dicht über dem Kurs — doppelter Magnet nach oben`);

 // 2. Offene Fair Value Gaps direkt am Kurs
 const F=(d.fvgs||[]).filter(f=>f.fill_i==null);
 const fb=F.filter(f=>f.kind==='bull'&&f.top<=px0&&px0/f.top-1<0.005)[0];
 const fs=F.filter(f=>f.kind==='bear'&&f.bot>=px0&&f.bot/px0-1<0.005)[0];
 if(fb){ add('buy',1,`Offenes bullisches FVG ${px(fb.bot)}–${px(fb.top)} direkt unter dem Kurs`); zones.push({kind:'buy',bot:fb.bot,top:fb.top,text:'bullisches FVG'}); }
 if(fs){ add('sell',1,`Offenes bärisches FVG ${px(fs.bot)}–${px(fs.top)} direkt über dem Kurs`); zones.push({kind:'sell',bot:fs.bot,top:fs.top,text:'bärisches FVG'}); }
 const inb=F.filter(f=>f.kind==='bull'&&px0>=f.bot&&px0<=f.top)[0], ins=F.filter(f=>f.kind==='bear'&&px0>=f.bot&&px0<=f.top)[0];
 if(inb){ add('buy',1,`Kurs steht IM bullischen FVG ${px(inb.bot)}–${px(inb.top)}`); zones.push({kind:'buy',bot:inb.bot,top:inb.top,text:'bullisches FVG'}); }
 if(ins){ add('sell',1,`Kurs steht IM bärischen FVG ${px(ins.bot)}–${px(ins.top)}`); zones.push({kind:'sell',bot:ins.bot,top:ins.top,text:'bärisches FVG'}); }

 // 3. RSI
 if(d.rsi14!=null){ if(d.rsi14<=30) add('buy',1,`RSI ${d.rsi14.toFixed(0)} (${d.rsi_tf}) überverkauft`);
  else if(d.rsi14>=70) add('sell',1,`RSI ${d.rsi14.toFixed(0)} (${d.rsi_tf}) überkauft`); }

 // 4. Orderbuch-Imbalance (Tiefe innerhalb 50 bps)
 if(d.book){ const i=d.book.imb_50;
  if(i>=0.3) add('buy',1,`Orderbuch: ${(i*100).toFixed(0)} % mehr Bid- als Ask-Tiefe (50 bps)`);
  else if(i<=-0.3) add('sell',1,`Orderbuch: ${(-i*100).toFixed(0)} % mehr Ask- als Bid-Tiefe (50 bps)`); }

 // 5. Funding: extreme Werte bedeuten einseitige Positionierung
 if(d.funding){ const f=d.funding.funding;
  if(f<=-0.00005) add('buy',1,`Funding ${(f*100).toFixed(4)} %/h negativ — Shorts zahlen, Squeeze-Potenzial`);
  else if(f>=0.0001) add('sell',1,`Funding ${(f*100).toFixed(4)} %/h stark positiv — Longs überfüllt`); }

 // 6. Wal-Netto-Ausrichtung im gewählten Coin
 if(LAST_WHALES&&LAST_WHALES.exposure&&LAST_WHALES.exposure.length){
  const e=LAST_WHALES.exposure[LAST_WHALES.exposure.length-1];
  if(e.long_usd>e.short_usd*1.5) add('buy',1,`Wale netto long (${fmt(e.long_usd)} gegen ${fmt(e.short_usd)})`);
  else if(e.short_usd>e.long_usd*1.5) add('sell',1,`Wale netto short (${fmt(e.short_usd)} gegen ${fmt(e.long_usd)}) — kann Absicherung sein`); }

 // 6b. Binance (Binance-Modus und Fusion): Taker-Flow, Top-Trader-Positionierung, laufende Kaskade
 if(SRC()!=='hl'&&d.bnc){ const M=d.bnc.metrics||{}, LQ=d.bnc.liqs_1h||{};
  if(M.taker_ls!=null){ if(M.taker_ls>=1.2) add('buy',1,`Binance Taker-Flow: ${(+M.taker_ls).toFixed(2)}× mehr aggressive Käufe als Verkäufe`);
   else if(M.taker_ls<=0.8) add('sell',1,`Binance Taker-Flow: nur ${(+M.taker_ls).toFixed(2)}× — aggressive Verkäufe überwiegen`); }
  if(M.top_ls_position!=null){ if(M.top_ls_position>=1.5) add('buy',1,`Binance Top-Trader netto long (Positionsverhältnis ${(+M.top_ls_position).toFixed(2)})`);
   else if(M.top_ls_position<=0.67) add('sell',1,`Binance Top-Trader netto short (Positionsverhältnis ${(+M.top_ls_position).toFixed(2)})`); }
  if(M.global_ls_account!=null&&M.global_ls_account>=3) add('warn',0,`Binance: ${(+M.global_ls_account).toFixed(1)}× mehr Long- als Short-Konten — einseitig, Kaskadenrisiko nach unten (Hinweis)`);
  const vol=d.bnc.vol_1h||vol1h||0;
  if((LQ.long||0)>=Math.max(vol*0.1,5e6)) add('wait',0,`Binance: ${fmt(LQ.long)} Long-Liquidationen in der letzten Stunde — Verkaufskaskade läuft oder lief gerade`);
  if((LQ.short||0)>=Math.max(vol*0.1,5e6)) add('wait',0,`Binance: ${fmt(LQ.short)} Short-Liquidationen in der letzten Stunde — Kaufkaskade läuft oder lief gerade`);
  if(d.bnc.funding!=null&&SRC()==='fusion'&&d.funding!=null&&Math.sign(d.bnc.funding)!==Math.sign(d.funding)&&Math.abs(d.bnc.funding)>0.00002)
   add('warn',0,`Funding gegenläufig: Hyperliquid ${(d.funding*100).toFixed(4)} %/h, Binance ${(d.bnc.funding*100).toFixed(4)} %/h (Hinweis)`); }

 // 7. Gleitende Durchschnitte: Regime, je ein Punkt
 const m=d.mas||{};
 if(m.ma200d_dist!=null){ if(m.ma200d_dist>0) add('buy',1,`Kurs ${(m.ma200d_dist*100).toFixed(1)} % über dem MA 200 Tage (${px(m.ma200d)}) — Regime bullisch`);
  else add('sell',1,`Kurs ${(-m.ma200d_dist*100).toFixed(1)} % unter dem MA 200 Tage (${px(m.ma200d)}) — Regime bärisch`); }
 if(m.ma50w_dist!=null){ if(m.ma50w_dist>0) add('buy',1,`Kurs ${(m.ma50w_dist*100).toFixed(1)} % über dem MA 50 Wochen (${px(m.ma50w)})`);
  else add('sell',1,`Kurs ${(-m.ma50w_dist*100).toFixed(1)} % unter dem MA 50 Wochen (${px(m.ma50w)})`); }
 if(m.cross) add('warn',0,`${m.cross==='golden'?'Golden Cross':'Death Cross'}: MA 50 Tage ${m.cross==='golden'?'über':'unter'} MA 200 Tage (Hinweis, keine Punkte — schon über das Regime erfasst)`);

 // 8. Danger-Time aus der Zeit-Heatmap: keine Richtung, nur Warnung
 if(d.danger) add('warn',0,`Danger-Time: in diesem Wochentag-/Zeitfenster historisch ${d.danger.lift.toFixed(1)}x so oft Bewegungen über ${(d.danger.threshold*100).toFixed(0)} % (belastbar)`);

 const net=buy-sell, waiting=R.some(r=>r.side==='wait');
 let label,color;
 if(waiting&&Math.abs(net)<3){label='ABWARTEN — Cluster-Anlauf';color='#d29922';}
 else if(net>=3){label='KAUF-KONFLUENZ';color='#3ba55d';}
 else if(net<=-3){label='VERKAUFS-KONFLUENZ';color='#e04b4b';}
 else if(net>0){label='leicht bullisch';color='#7ee787';}
 else if(net<0){label='leicht bärisch';color='#ff7b72';}
 else{label='NEUTRAL';color='#c9d1d9';}
 // Zone nur, wenn Richtung und Preisniveau zusammenpassen
 const dir=net>0?'buy':net<0?'sell':null;
 const zone=dir?zones.filter(z=>z.kind===dir)[0]:null;
 SIGNAL={label,color,net,zone,dir};
 const t=$('kpi_signal'); if(t){t.textContent=label;t.style.color=color;t.title=`Kauf ${buy} · Verkauf ${sell}`;}
 const box=$('signalbox'); if(!box) return;
 const zoneNote=zone
   ?`<div style="margin-top:6px;color:${dir==='buy'?'#3ba55d':'#e04b4b'}">■ Zone im Chart: ${zone.text} ${px(zone.bot)}–${px(zone.top)}</div>`
   :(dir?`<div class="sub" style="margin-top:6px">Keine Zone eingezeichnet: die ${dir==='buy'?'Kauf':'Verkaufs'}-Punkte stammen aus Faktoren ohne Preisniveau (Wale, Orderbuch, Funding, RSI). Eine Zone entsteht erst durch ein FVG am Kurs oder ein frisch abgeräumtes Cluster.</div>`:'');
 const ic={buy:'▲',sell:'▼',wait:'⏸',warn:'⚠'}, col={buy:'#3ba55d',sell:'#e04b4b',wait:'#d29922',warn:'#d29922'};
 box.innerHTML=`<div style="font-size:15px;font-weight:600;color:${color};margin-bottom:6px">${label}
   <span style="font-size:11px;color:#8b949e;font-weight:400">· Kauf-Punkte ${buy}, Verkaufs-Punkte ${sell}, netto ${net>0?'+':''}${net}</span></div>`
  +(R.length?R.map(r=>`<div><span style="color:${col[r.side]}">${ic[r.side]}</span> ${r.text}`
    +(r.pts?` <span class="mono">(${r.side==='buy'?'+':'−'}${r.pts})</span>`:'')+`</div>`).join('')
   :'<div class="sub">Kein Faktor aktiv — Kurs ohne Cluster, Lücke oder Extremwert in der Nähe.</div>')
  +zoneNote
  +`<div class="sub" style="margin-top:8px">Schwellen: Konfluenz ab 3 Punkten netto. Cluster zählen ab halbem Stundenvolumen. `
  +`Orderbuch ab 30 % Imbalance, Funding ab −0,005 / +0,01 %/h, Wale ab 1,5-fachem Übergewicht. `
  +`MA 200 Tage und MA 50 Wochen je ein Punkt nach Lage des Kurses. Stop-Cluster ab 25 % des Stundenvolumens (mind. 5 Mio) → Abwarten; `
  +`Kauf-/Verkaufswände ab 50 % (mind. 10 Mio) je ein Punkt; Take-Profits als Hinweis. Orders von Konten ab 250k USD.</div>`;
}

let healthTimer=null;
// ---- Abschnitte ein-/ausklappen, Zustand im Browser gemerkt ----------------------
function secState(){ try{ return JSON.parse(localStorage.getItem('hl_sec')||'{}'); }catch(e){ return {}; } }
function applySec(){
 const st=secState();
 document.querySelectorAll('.panel[data-sec]').forEach(p=>p.classList.toggle('closed', !!st[p.dataset.sec]));
}
function toggleSec(key){
 const p=document.getElementById('sec-'+key); if(!p) return;
 const st=secState(); st[key]=!p.classList.contains('closed'); p.classList.toggle('closed', st[key]);
 try{ localStorage.setItem('hl_sec', JSON.stringify(st)); }catch(e){}
 if(!st[key]){ setTimeout(load,50); }          // beim Aufklappen neu zeichnen
}
function toggleAll(){
 const ps=[...document.querySelectorAll('.panel[data-sec]')], anyOpen=ps.some(p=>!p.classList.contains('closed'));
 const st={}; ps.forEach(p=>{ st[p.dataset.sec]=anyOpen; p.classList.toggle('closed', anyOpen); });
 try{ localStorage.setItem('hl_sec', JSON.stringify(st)); }catch(e){}
 if(!anyOpen) setTimeout(load,50);
}
function applySrcLabels(){
 const src=SRC(), n=SRC_NAME[src];
 const set=(sel,txt)=>{ const e=document.querySelector(sel); if(e) e.textContent=txt; };
 set('#sec-chart .ttl', src==='hl'?'Live-Chart — Kurs mit aktuellen Liquidationsmarken':src==='bnc'?'Live-Chart (Binance) — Kurs mit eingetretenen Liquidationen':'Live-Chart (Fusion) — HL-Marken, Liquidationen beider Börsen');
 set('#sec-orders .ttl', src==='hl'?'Wartende Orders und Stops — Konten ab 250k USD':src==='bnc'?'Orderbuch Binance — Tiefe je Preisstufe':'Orders (Fusion) — HL-Konten + Binance-Orderbuch je Preisstufe summiert');
 set('#sec-heat .ttl', src==='hl'?'Heatmap — Clusterentwicklung über die Zeit':src==='bnc'?'Heatmap (Binance) — eingetretene Liquidationen über die Zeit':'Heatmap (Fusion) — HL-Cluster, Binance-Liquidationen orange');
 set('#sec-depth .ttl', src==='hl'?'Momentaufnahme — Cluster rund um den aktuellen Kurs':src==='bnc'?'Momentaufnahme (Binance) — Liquidationen der letzten 24 h um den Kurs':'Momentaufnahme (Fusion) — HL-Cluster, Binance eingetreten orange');
 set('#sec-whales .ttl', src==='hl'?'Wale — Positionen ab 20 Mio. USD':src==='bnc'?'Binance — Open Interest, Long/Short, Taker-Flow':'Wale (HL) und Binance-Kennzahlen');
 set('#sec-signal .ttl', src==='hl'?'Konfluenz — welche Faktoren zeigen in dieselbe Richtung?':`Konfluenz (${n}) — welche Faktoren zeigen in dieselbe Richtung?`);
 document.body.dataset.src=src;
}
function toggleHelp(a){
 const h=a.closest('.panel').querySelector('.sub.help'); if(!h) return;
 h.style.display=h.style.display==='none'?'block':'none';
}
applySec();

// ---- Update-Knopf --------------------------------------------------------------
let updTimer=null;
async function pollUpdate(reloadWhenDone){
 const pre=$('updlog'); pre.style.display='block';
 try{ const r=await fetch('/update/status',{cache:'no-store'}); const st=await r.json();
  pre.textContent=(st.log||'(noch keine Ausgabe)')+(st.running?'\\n… läuft …':'');
  pre.scrollTop=pre.scrollHeight;
  if(st.done){ clearTimeout(updTimer); updTimer=null; $('updbtn').disabled=false;
   $('updbtn').textContent=st.ok_marker?'Update fertig — Seite lädt neu':'Update mit Fehler beendet';
   if(st.ok_marker&&reloadWhenDone) setTimeout(()=>location.reload(true),2500); return; }
 }catch(e){ pre.textContent=(pre.textContent||'')+'\\n… Dashboard startet neu, warte …'; }
 updTimer=setTimeout(()=>pollUpdate(reloadWhenDone),3000);
}
async function runUpdate(){
 if(!confirm('Update von GitHub laden und einspielen?\\nDienste werden neu gestartet, die Aufzeichnung pausiert etwa eine Minute.')) return;
 const b=$('updbtn'); b.disabled=true; b.textContent='Lade Archiv …';
 try{ const r=await fetch('/update',{method:'POST'}); const j=await r.json();
  $('updlog').style.display='block'; $('updlog').textContent=j.msg;
  if(!j.ok){ b.disabled=false; b.textContent='Update von GitHub einspielen'; return; }
  b.textContent='Update läuft …'; pollUpdate(true);
 }catch(e){ b.disabled=false; b.textContent='Update von GitHub einspielen'; showErr('Update: '+e.message); }
}
async function loadHealth(){
 try{LAST_HEALTH=await getJSON('/health'); fillHealth(LAST_HEALTH);}catch(e){}
 // solange die Prüfung läuft, alle 30 s nachsehen statt erst in einer Stunde
 if(healthTimer){clearTimeout(healthTimer);healthTimer=null;}
 if(LAST_HEALTH&&(LAST_HEALTH.checking||LAST_HEALTH.db_ok==null)) healthTimer=setTimeout(loadHealth,30000);
}
function fillBudget(d){
 const el=$('kpi_api'); if(!el) return; const b=d.budget;
 if(!b){el.textContent='—';el.style.color='';el.title='Recorder meldet noch kein Budget';return;}
 const pct=b.used/b.budget*100, age=Date.now()/1000-b.ts;
 el.innerHTML=`${b.used} / ${b.budget} <span class="d">${pct.toFixed(0)} % · Reserve ${(100-pct).toFixed(0)} %</span>`;
 el.style.color=pct<70?'#3ba55d':pct<85?'#d29922':'#e04b4b';
 el.title=`Hyperliquid-Gewicht der letzten Minute: ${pct.toFixed(0)} % des Limits von ${b.budget}/min. `
  +`Der Recorder deckelt sich selbst bei 85 % — mindestens 15 % bleiben frei.`
  +(age>90?` · Stand vor ${Math.round(age/60)} min`:'')+(b.r429?` · ${b.r429}× HTTP 429 seit Start`:'');
 if(age>300){el.textContent+=' ?';el.style.color='#8b949e';}
}
function fillMAs(d){
 const m=d.mas||{}, a=$('kpi_ma50w'), b=$('kpi_ma200d'); if(!a||!b) return;
 const all=`MA 50 T ${m.ma50d?px(m.ma50d):'—'} · MA 200 T ${m.ma200d?px(m.ma200d):'—'}\\nMA 50 W ${m.ma50w?px(m.ma50w):'—'} · MA 200 W ${m.ma200w?px(m.ma200w):'—'}`
  +`\\n${m.days} Tageskerzen, ${m.weeks} Wochen · Quelle ${m.source||'—'}`
  +(m.cross?`\\n${m.cross==='golden'?'Golden Cross (MA50 T über MA200 T)':'Death Cross (MA50 T unter MA200 T)'}`:'');
 const set=(el,v,dist)=>{ if(v==null){el.textContent='—';el.style.color='';el.title=all+'\\nZu wenig Tageskerzen — hl_binance.py --backfill-daily';return;}
  el.innerHTML=px(v)+' <span class="d">'+(dist>=0?'▲':'▼')+' '+(Math.abs(dist)*100).toFixed(1)+' %</span>';
  el.style.color=dist>=0?'#3ba55d':'#e04b4b'; el.title=all+`\\nKurs ${dist>=0?'über':'unter'} dem Durchschnitt (${(dist*100).toFixed(2)} %)`; };
 set(a,m.ma50w,m.ma50w_dist); set(b,m.ma200d,m.ma200d_dist);
}
function fillIndicators(d){
 fillMAs(d); fillBudget(d);
 const t=$('kpi_trend'), r=$('kpi_rsi'), l=$('kpi_rsi_lbl');
 if(!t||!r) return;
 if(d.trend_60m==null){t.textContent='—';t.style.color='';}
 else{const v=d.trend_60m*100;
  t.textContent=(v>=0?'▲ +':'▼ ')+v.toFixed(2)+' %';
  t.style.color=Math.abs(v)<0.15?'#c9d1d9':v>0?'#3ba55d':'#e04b4b';}
 if(d.rsi14==null){r.textContent='—';r.style.color='';}
 else{const v=d.rsi14; r.textContent=v.toFixed(1);
  r.style.color=v>=70?'#e04b4b':v<=30?'#3ba55d':'#c9d1d9';
  r.title=v>=70?'überkauft':v<=30?'überverkauft':'neutral';}
 if(l) l.textContent='RSI 14 · '+(d.rsi_tf||'');
}
function fit(c){
 // Höhe immer aus dem HTML-Attribut ableiten. Vorher wurde c.height bei jedem
 // Zeichnen erneut mit der Pixeldichte multipliziert -- auf Handys (Dichte 2-3)
 // wuchs der Chart damit alle 5 s um den Faktor der Dichte.
 const d=devicePixelRatio||1;
 // Basis-Höhe EINMAL aus dem HTML-Attribut nehmen und in data-h0 merken:
 // c.height=... schreibt das Attribut zurück, sonst wächst es mit jeder Zeichnung.
 if(!c.dataset.h0) c.dataset.h0=c.getAttribute('height')||'400';
 const base=+(innerWidth<700&&c.dataset.hm?c.dataset.hm:c.dataset.h0)||400;
 const r=c.getBoundingClientRect();
 if(r.width===0){ return [c.getContext('2d'),0,base]; }   // eingeklappter Abschnitt: nichts zu zeichnen
 c.style.height=base+'px';
 c.width=Math.round(r.width*d); c.height=Math.round(base*d);
 const x=c.getContext('2d'); x.setTransform(d,0,0,d,0,0);
 return [x,r.width,base];}
function fmt(n){ if(n<0) return '-'+fmt(-n);   // negative Werte (PnL) mit Vorzeichen, gleiche Einheiten
 return n>=1e9?(n/1e9).toFixed(2)+' Mrd':n>=1e6?(n/1e6).toFixed(1)+' Mio'
 :n>=1e3?(n/1e3).toFixed(0)+'k':(+n).toFixed(0);}
function px(n){return n>=1000?n.toLocaleString('de-DE',{maximumFractionDigits:2})
 :(+n).toFixed(4);}
function hm(ts){const d=new Date(ts*1000);
 return String(d.getDate()).padStart(2,'0')+'.'+String(d.getMonth()+1).padStart(2,'0')
  +'. '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');}
function dmy(ts){const d=new Date(ts*1000);
 return String(d.getDate()).padStart(2,'0')+'.'+String(d.getMonth()+1).padStart(2,'0')+'.'+String(d.getFullYear()).slice(2);}
// Zeitbeschriftung passend zum Raster: bei Tagen und Wochen nur das Datum
function tlabel(ts){ return (LAST_CHART&&LAST_CHART.agg>=1440)?dmy(ts):hm(ts); }

// Farbverlauf dunkelblau -> blau -> cyan -> gelb -> weiss.
// Der dunkle Fuss ist entscheidend: ohne ihn leuchtet die ganze Flaeche.
const RAMP=[[0,4,10,32],[.22,10,40,140],[.45,0,150,200],
            [.68,60,220,180],[.85,255,214,10],[1,255,255,235]];
function heatColor(p){
 for(let i=1;i<RAMP.length;i++){
  if(p<=RAMP[i][0]){const a=RAMP[i-1],b=RAMP[i],t=(p-a[0])/(b[0]-a[0]||1);
   return [Math.round(a[1]+(b[1]-a[1])*t),Math.round(a[2]+(b[2]-a[2])*t),
           Math.round(a[3]+(b[3]-a[3])*t)];}}
 return [255,255,235];
}
// Perzentil-Zuordnung: entscheidend ist der Rang unter allen Zellen.
function makeScale(values){
 const v=values.filter(x=>x>0); if(!v.length) return null;
 const step=Math.max(1,Math.floor(v.length/20000)), s=[];
 for(let i=0;i<v.length;i+=step) s.push(v[i]);
 s.sort((a,b)=>a-b);
 const BINS=256, brk=new Float64Array(BINS);
 for(let i=0;i<BINS;i++) brk[i]=s[Math.min(s.length-1,Math.floor(i/BINS*s.length))];
 return {brk,min:s[0],max:s[s.length-1],
  pct(x){let lo=0,hi=BINS-1; if(x<=this.brk[0])return 0;
   while(lo<hi){const m=(lo+hi+1)>>1; if(this.brk[m]<=x)lo=m;else hi=m-1;}
   return lo/(BINS-1);}};
}

function drawChart(d){
 const [g,W,H]=fit($('chart')); g.clearRect(0,0,W,H);
 if(!d||!d.candles.length){g.fillStyle='#8b949e';
  g.fillText('noch keine Kursdaten — der Recorder muss erst laufen',12,24);return;}
 const C=d.candles, L=(d.levels||[]);
 const narrow=W<600, R=narrow?56:68,Lm=8,T=12,B=26, pw=W-Lm-R, ph=H-T-B;
 let lo=Math.min(...C.map(c=>c.l)), hi=Math.max(...C.map(c=>c.h));
 L.forEach(l=>{if(Math.abs(l.dist)<0.035){lo=Math.min(lo,l.px);hi=Math.max(hi,l.px);}});
 { const M0=d.mas||{}, p0=C[C.length-1].c;
   ['ma50w','ma200d','ma50d','ma200w'].forEach(k=>{const v=M0[k]; if(v&&Math.abs(v/p0-1)<0.035){lo=Math.min(lo,v);hi=Math.max(hi,v);}});
   const K0=keyLevels(d)||{}; Object.keys(KEY_STYLE).forEach(k=>{const s=K0[k]; if(s&&Math.abs(s.px/p0-1)<0.035){lo=Math.min(lo,s.px);hi=Math.max(hi,s.px);}}); }
 if(SIGNAL&&SIGNAL.zone){const z=SIGNAL.zone, p0=C[C.length-1].c;
  if(Math.abs(z.bot/p0-1)<0.035&&Math.abs(z.top/p0-1)<0.035){lo=Math.min(lo,z.bot);hi=Math.max(hi,z.top);}}
 const pad=(hi-lo)*0.08||1; lo-=pad; hi+=pad;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 const cw=Math.max(1.5,pw/C.length), bw=Math.max(1,cw*0.62);
 const FV=FVG_ON?(d.fvgs||[]):[];
 GEO.chart={C,L,Lm,T,pw,ph,cw,lo,hi,H,B,R,W,FV};

 g.strokeStyle='#161b22';g.lineWidth=1;
 for(let k=0;k<=5;k++){const y=T+ph*k/5;g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();}

 // Fair Value Gaps: von der mittleren Kerze bis zur Füllung, sonst bis zum Rand
 FV.forEach(f=>{const x0=Lm+f.i*cw, x1=f.fill_i!=null?Lm+f.fill_i*cw+cw:W-R;
  const y0=Y(f.top), y1=Y(f.bot); if(y1<T||y0>H-B) return;
  const open=f.fill_i==null, a=open?0.28:0.09;
  g.fillStyle=f.kind==='bull'?`rgba(57,255,20,${a})`:`rgba(224,75,75,${a})`;
  g.fillRect(x0,Math.max(T,y0),Math.max(1,x1-x0),Math.min(H-B,y1)-Math.max(T,y0));
  if(open){g.strokeStyle=f.kind==='bull'?'rgba(57,255,20,.95)':'rgba(224,75,75,.7)';
   g.lineWidth=1;g.setLineDash([2,3]);g.strokeRect(x0,y0,x1-x0,y1-y0);g.setLineDash([]);
   // Teilfüllung als Balken an der Innenkante
   if(f.fill_pct>0){g.fillStyle='rgba(255,255,255,.12)';
    const fh=(y1-y0)*f.fill_pct; g.fillRect(x0,f.kind==='bull'?y0:y1-fh,x1-x0,fh);}}});

 // Eingetretene Liquidationen als Marker (Binance orange, Hyperliquid magenta) -- Binance- und Fusionsmodus
 if(d.liq_marks&&d.liq_marks.length){ const t0=C[0].t, t1=C[C.length-1].t, step=C.length>1?(C[1].t-C[0].t):60;
  d.liq_marks.forEach(m=>{ const [t,p,usd,side,src]=m; if(t<t0||t>t1+step) return;
   const i=Math.min(C.length-1,Math.floor((t-t0)/step)), x=Lm+i*cw+cw/2, y=Y(p); if(y<T||y>H-B) return;
   g.fillStyle=src==='bnc'?'rgba(255,159,67,0.9)':'rgba(255,59,107,0.9)';
   g.beginPath(); if(side==='long'){ g.moveTo(x-3,y-3); g.lineTo(x+3,y-3); g.lineTo(x,y+3);} else { g.moveTo(x-3,y+3); g.lineTo(x+3,y+3); g.lineTo(x,y-3);} g.closePath(); g.fill(); }); }

 // Gleitende Durchschnitte als waagerechte Linien, sofern im Preisbereich
 const M=d.mas||{};
 [['ma50w','MA 50 W','#e3b341'],['ma200d','MA 200 T','#a371f7'],['ma50d','MA 50 T','#79c0ff'],['ma200w','MA 200 W','#f778ba']].forEach(([k,lab,col])=>{
  const v=M[k]; if(!v) return; const y=Y(v); if(y<T||y>H-B) return;
  g.strokeStyle=col; g.lineWidth=1.2; g.setLineDash([6,4]); g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
  g.fillStyle=col; g.font='bold 10px system-ui'; g.fillText(lab+' '+px(v), Lm+6, y-3);});

 // Schlüsselniveaus aus den Orders der Großkonten: Support, Resistance, Take-Profits, Stops
 { const K=keyLevels(d)||{}; let usedY=[];
   Object.entries(KEY_STYLE).forEach(([k,[label,color]])=>{ const s=K[k]; if(!s) return; const y=Y(s.px); if(y<T||y>H-B) return;
    g.strokeStyle=color; g.lineWidth=k==='support'||k==='resistance'?2:1.2; g.setLineDash(k.startsWith('stop')?[3,3]:k.startsWith('tp')?[8,4]:[]);
    g.beginPath(); g.moveTo(Lm,y); g.lineTo(W-R,y); g.stroke(); g.setLineDash([]);
    // Beschriftung links, ohne Kollision
    let ly=y-4; while(usedY.some(u=>Math.abs(u-ly)<11)) ly-=11; usedY.push(ly);
    const txt=label+' '+px(s.px)+' · '+fmt(s.notional); g.font='bold 10px system-ui';
    const tw=g.measureText(txt).width+8; g.fillStyle='rgba(13,17,23,0.85)'; g.fillRect(Lm+4,ly-9,tw,12);
    g.fillStyle=color; g.fillText(txt, Lm+8, ly); }); }

 // Konfluenz-Zone: ein AKTUELLES Fenster -- Kasten am rechten Rand über die
 // letzten Kerzen, nicht ein Band über die ganze Historie
 if(SIGNAL&&SIGNAL.zone){const z=SIGNAL.zone, y0=Y(z.top), y1=Y(z.bot);
  if(y1>T&&y0<H-B){const c=z.kind==='buy'?'57,255,20':'224,75,75';
   const zw=Math.max(cw*10, pw*0.09), x0=W-R-zw, x1=W-R;
   const yy0=Math.max(T,y0), yy1=Math.min(H-B,y1);
   g.fillStyle=`rgba(${c},0.22)`; g.fillRect(x0,yy0,zw,yy1-yy0);
   g.strokeStyle=`rgba(${c},0.95)`; g.lineWidth=2; g.strokeRect(x0,yy0,zw,yy1-yy0);
   // linke Kante als Beginn des Fensters betonen
   g.fillStyle=`rgba(${c},0.9)`; g.fillRect(x0-1,yy0,3,yy1-yy0);
   const label=(z.kind==='buy'?'KAUFZONE':'VERKAUFSZONE'), sub=z.text;
   g.font='bold 11px system-ui'; const lw=Math.max(g.measureText(label).width,g.measureText(sub).width)+12;
   const lx=Math.max(Lm, x1-lw), ly=(z.kind==='buy'? Math.max(T+2, yy0-30) : Math.min(H-B-30, yy1+4));
   g.fillStyle='rgba(13,17,23,0.85)'; g.fillRect(lx,ly,lw,28);
   g.strokeStyle=`rgba(${c},0.95)`; g.lineWidth=1; g.strokeRect(lx,ly,lw,28);
   g.fillStyle=`rgb(${c})`; g.fillText(label, lx+6, ly+12);
   g.font='10px system-ui'; g.fillStyle='#c9d1d9'; g.fillText(sub, lx+6, ly+24);}}
 const mxN=Math.max(...L.map(l=>l.notional),1);
 L.forEach(l=>{const y=Y(l.px); if(y<T||y>H-B)return;
  const a=0.25+0.65*(l.notional/mxN);
  g.strokeStyle=l.side==='long'?`rgba(224,75,75,${a})`:`rgba(59,165,93,${a})`;
  g.lineWidth=l.x_vol>=0.5?2:1; g.setLineDash(l.x_vol>=0.5?[]:[3,3]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle=l.side==='long'?'#e04b4b':'#3ba55d';g.font='9px system-ui';
  g.fillText(fmt(l.notional),W-R+3,y-2);
  g.fillStyle='#6e7681';g.fillText((l.dist*100).toFixed(1)+'%',W-R+3,y+8);});
 C.forEach((c,i)=>{const x=Lm+i*cw+cw/2, up=c.c>=c.o;
  g.strokeStyle=up?'#3ba55d':'#e04b4b'; g.fillStyle=g.strokeStyle; g.lineWidth=1;
  g.beginPath();g.moveTo(x,Y(c.h));g.lineTo(x,Y(c.l));g.stroke();
  const y1=Y(Math.max(c.o,c.c)),y2=Y(Math.min(c.o,c.c));
  g.fillRect(x-bw/2,y1,bw,Math.max(1,y2-y1));});
 if(d.price){const y=Y(d.price);
  g.strokeStyle='#00e5ff';g.lineWidth=1;g.setLineDash([5,4]);
  g.beginPath();g.moveTo(Lm,y);g.lineTo(W-R,y);g.stroke();g.setLineDash([]);
  g.fillStyle='#00e5ff';g.fillRect(W-R,y-7,R,14);
  g.fillStyle='#010409';g.font='bold 10px system-ui';g.fillText(px(d.price),W-R+3,y+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 for(let k=0;k<4;k++){const i=Math.floor(k/3*(C.length-1));
  g.fillText(tlabel(C[i].t), Lm+i*cw, H-8);}
 g.fillText('Preis (USD) rechts · Zeit unten', Lm, T+10);
 const te=(d.tick_events||[]);
 const openF=FV.filter(f=>f.fill_i==null);
 const nearest=openF.slice().sort((a,b)=>Math.abs(a.dist)-Math.abs(b.dist))[0];
 const fvtxt=FV.length?` · <b>FVG:</b> ${openF.length} offen (${openF.filter(f=>f.kind==='bull').length} bull / `
   +`${openF.filter(f=>f.kind==='bear').length} bear), ${FV.length-openF.length} gefüllt`
   +(nearest?` · nächstes ${nearest.kind} ${px(nearest.bot)}–${px(nearest.top)} `
     +`(${(nearest.dist*100).toFixed(2)} %, ${(nearest.fill_pct*100).toFixed(0)} % gefüllt)`:''):'';
 $('chartinfo').innerHTML=(d.agg>=240?`Quelle: ${d.source} · `:'')+`${C.length} Kerzen · ${L.length} Liquidationsmarken`
  +` · Stundenvolumen ${fmt(d.vol_1h||0)} USD`+fvtxt
  +(te.length?`<br><b>Tick-Aufzeichnungen:</b> `+te.map(e=>
    `${hm(e.t_trigger/1000)} <span style="color:${e.move_pct<0?'#e04b4b':'#3ba55d'}">`
    +`${(e.move_pct*100).toFixed(2)} %</span> (${e.reason}, ${e.n_ticks.toLocaleString('de-DE')} Ticks, `
    +`${e.n_liqs} Liqs)`).join(' · '):'');
}

function drawHeat(d){
 const [g,W,H]=fit($('heat')); g.clearRect(0,0,W,H);
 if(!d||!d.times.length||!d.price||!d.price.length){g.fillStyle='#8b949e';g.fillText('keine Daten',12,22); $('heatinfo').textContent=''; GEO.heat=null; return;}
 const P=d.price.map(p=>p[1]), lo=Math.min(...P)*0.94, hi=Math.max(...P)*1.06;
 const L=52,R=12,T=10,B=26, pw=W-L-R, ph=H-T-B;
 const t0=d.times[0], t1=d.times[d.times.length-1];
 const X=t=>L+(t-t0)/(t1-t0+1)*pw, Y=p=>T+(hi-p)/(hi-lo)*ph;
 g.fillStyle='#01030a'; g.fillRect(L,T,pw,ph);
 const flat=[]; d.grid.forEach(r=>r.forEach(v=>{if(v>0)flat.push(v)}));
 const sc=makeScale(flat), thr=(+$('thr').value)/100;
 const cw=Math.max(1.5,pw/d.times.length), chh=Math.max(1.5,ph*0.0025/((hi-lo)/hi));
 GEO.heat={d,L,T,pw,ph,lo,hi,t0,t1,sc,thr,H,B,W,R};
 let shown=0;
 d.grid.forEach((row,i)=>{const y=Y(d.levels[i]); if(y<T-4||y>H-B+4)return;
  row.forEach((v,j)=>{ if(v<=0||!sc)return;
   const p=sc.pct(v); if(p<thr)return;
   const q=Math.pow((p-thr)/(1-thr||1),2.6);
   const c=heatColor(q);
   g.fillStyle=`rgba(${c[0]},${c[1]},${c[2]},${0.35+0.65*q})`;
   g.fillRect(X(d.times[j]),y-chh/2,cw,chh); shown++;});});
 g.strokeStyle='#ffffff';g.lineWidth=1.6;g.beginPath();
 d.price.forEach((p,i)=>{const x=X(p[0]),y=Y(p[1]);i?g.lineTo(x,y):g.moveTo(x,y)});
 g.stroke();
 g.strokeStyle='#ff3b6b';g.lineWidth=1.2;
 // Eingetretene Liquidationen: die betroffene Zelle wird magenta, wie in der Legende.
 // Mehrere im selben Zeit-/Preisfeld werden zusammengefasst; die Deckkraft folgt dem Notional.
 { const cells=new Map();
   d.liqs.forEach(l=>{ const col=Math.floor((l[0]-t0)/Math.max(1,(t1-t0)/d.times.length)), row=Math.round(Math.log(l[1]/lo)/Math.log(1.0025));
     const k=col+':'+row; const c=cells.get(k)||{x:X(l[0]),y:Y(l[1]),usd:0,n:0}; c.usd+=l[2]; c.n++; cells.set(k,c); });
   cells.forEach(c=>{ if(c.y<T-4||c.y>H-B+4) return;
     const a=Math.min(1,0.45+c.usd/2e6*0.55), h=Math.max(chh,3), w=Math.max(cw,3);
     g.fillStyle=`rgba(255,59,107,${a})`; g.fillRect(Math.floor(c.x),Math.round(c.y-h/2),Math.ceil(w),Math.ceil(h));
     g.strokeStyle='#ff3b6b'; g.lineWidth=1; g.strokeRect(Math.floor(c.x)+0.5,Math.round(c.y-h/2)+0.5,Math.ceil(w),Math.ceil(h)); }); }
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=4;k++){const p=lo+(hi-lo)*k/4;g.fillText(px(p).slice(0,9),4,Y(p)+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 const nx=W<600?2:4;   // auf schmalen Bildschirmen weniger Zeitmarken, sonst überlappen sie
 for(let k=0;k<=nx;k++){const t=t0+(t1-t0)*k/nx;
  g.fillText(hm(t), Math.min(X(t),W-R-52), H-8);}
 g.fillStyle='#8b949e';g.font='9px system-ui';
 g.save();g.translate(11,T+ph/2);g.rotate(-Math.PI/2);
 g.textAlign='center';g.fillText('Preis (USD)',0,0);g.restore();
 let extra='';
 if(SRC()==='fusion'&&LAST_DATA&&LAST_DATA.bnc&&LAST_DATA.bnc.grid_liqs){
  const bl=LAST_DATA.bnc.grid_liqs; const cw2=Math.max(1.5,pw/d.times.length);
  bl.forEach(l=>{const x=X(l[0]), y=Y(l[1]); if(y<T||y>H-B||x<L||x>W-R) return;
   g.fillStyle='rgba(255,159,67,0.75)'; g.fillRect(Math.floor(x),Math.round(y-2),Math.max(cw2,3),4);});
  extra=` · Binance-Liquidationen (orange): ${bl.length}`;
 }
 $('heatinfo').textContent=(d.realized?`Eingetretene Binance-Liquidationen: ${flat.length.toLocaleString('de-DE')} Zellen · Notional je Zelle bis ${fmt(sc?sc.max:0)} USD`
  :(sc? `${shown.toLocaleString('de-DE')} von ${flat.length.toLocaleString('de-DE')} Zellen `
    +`sichtbar · unterhalb Perzentil ${Math.round(thr*100)} ausgeblendet `
    +`· Notional je Zelle ${fmt(sc.min)}–${fmt(sc.max)} USD` : ''))+extra;
}

function drawDepth(d){
 const [g,W,H]=fit($('depth')); g.clearRect(0,0,W,H);
 const di=$('depthinfo');
 if(!d||!d.rows.length){g.fillStyle='#8b949e';g.fillText(d&&d.realized?'keine eingetretenen Binance-Liquidationen im Zeitraum':'kein Snapshot',12,22);
  if(di) di.textContent=d&&d.realized?'Binance: keine eingetretenen Liquidationen in den letzten 24 h — oder hl_binance läuft nicht':''; GEO.depth=null; return;}
 const p0=d.price, rows=d.rows.filter(r=>r.bucket_px>p0*0.85&&r.bucket_px<p0*1.18);
 if(!rows.length){g.fillStyle='#8b949e';g.fillText('keine Cluster im Bereich',12,22); if(di) di.textContent=''; GEO.depth=null; return;}
 const lo=p0*0.85, hi=p0*1.18, mx=Math.max(...rows.map(r=>r.notional));
 const L=62,R=10,T=10,B=26, pw=W-L-R, ph=H-T-B;
 const Y=p=>T+(hi-p)/(hi-lo)*ph;
 GEO.depth={rows,L,T,pw,ph,lo,hi,mx,p0,vol:d.vol_1h,H,B,W,R};
 rows.forEach(r=>{const w=r.notional/mx*pw, y=Y(r.bucket_px);
  g.fillStyle=r.side==='long'?'rgba(224,75,75,.85)':'rgba(59,165,93,.85)';
  g.fillRect(L,y-2,w,4);});
 if(d.vol_1h>0){const x=L+(d.vol_1h*0.5)/mx*pw;
  if(x<W-R){g.strokeStyle='#8b949e';g.setLineDash([4,4]);g.beginPath();
   g.moveTo(x,T);g.lineTo(x,H-B);g.stroke();g.setLineDash([]);
   g.fillStyle='#8b949e';g.font='9px system-ui';g.fillText('halbes Stundenvolumen',x+3,T+10);}}
 g.strokeStyle='#00e5ff';g.lineWidth=2;g.beginPath();
 g.moveTo(L,Y(p0));g.lineTo(W-R,Y(p0));g.stroke();
 g.fillStyle='#8b949e';g.font='10px system-ui';
 for(let k=0;k<=6;k++){const p=lo+(hi-lo)*k/6;g.fillText(px(p).slice(0,9),4,Y(p)+3);}
 g.fillStyle='#6e7681';g.font='9px system-ui';
 for(let k=0;k<=3;k++){const v=mx*k/3;g.fillText(fmt(v),L+pw*k/3,H-8);}
 g.fillText('Notional (USD)',L+pw/2-30,H-16);
 const up=rows.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
 const dn=rows.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0);
 // Fusion: eingetretene Binance-Liquidationen der letzten 24 h als Overlay (orange), NICHT addiert --
 // erwartete Cluster und eingetretene Liquidationen sind verschiedene Größen.
 let extra='';
 if(SRC()==='fusion'&&LAST_DATA&&LAST_DATA.bnc&&LAST_DATA.bnc.depth){
  const R2=LAST_DATA.bnc.depth.rows.filter(r=>r.bucket_px>lo&&r.bucket_px<hi);
  const mx2=Math.max(...R2.map(r=>r.notional),1);
  R2.forEach(r=>{const w=r.notional/mx2*pw*0.6, y=Y(r.bucket_px); g.fillStyle='rgba(255,159,67,0.7)'; g.fillRect(L,y-1.5,w,3);});
  const bl=R2.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0), bs=R2.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
  extra=` · Binance eingetreten 24 h (orange): Longs ${fmt(bl)}, Shorts ${fmt(bs)}`;
 }
 $('depthinfo').textContent=(d.realized?`Eingetretene Liquidationen (Binance, ${d.hours||24} h): ${rows.length} Preisstufen · Longs liquidiert ${fmt(dn)} USD · Shorts liquidiert ${fmt(up)} USD · Stand ${hm(d.ts)}`
  :`${rows.length} Cluster · über dem Kurs ${fmt(up)} USD · darunter ${fmt(dn)} USD · Stand ${hm(d.ts)}`)+extra;
}

function drawMetrics(m){
 const box=$('bncmetrics'); if(!box) return; if(!m||!m.series){ box.style.display='none'; return; }
 box.style.display='block';
 const c=$('metricschart'); const [g,W,H]=fit(c); g.clearRect(0,0,W,H); if(!W) return;
 const L=56,R=56,T=12,B=24, pw=W-L-R, ph=H-T-B;
 const S=m.series; const keys=[['oi_notional','#58a6ff'],['global_ls_account','#d29922'],['top_ls_position','#c678dd'],['taker_ls','#3ba55d']];
 const all=keys.flatMap(([k])=>S[k]||[]); if(!all.length){ g.fillStyle='#8b949e'; g.font='12px system-ui'; g.fillText('noch keine Binance-Kennzahlen — kommen mit hl_binance (Backfill und alle 10 min)',12,24); return; }
 const t0=Math.min(...all.map(p=>p[0])), t1=Math.max(...all.map(p=>p[0])), X=t=>L+(t-t0)/Math.max(1,t1-t0)*pw;
 // OI links (absolut), Verhältnisse rechts (gemeinsame Skala um 1)
 const oi=S.oi_notional||[]; const ratios=keys.slice(1).flatMap(([k])=>S[k]||[]).map(p=>p[1]);
 const rlo=Math.min(0.5,...ratios), rhi=Math.max(1.5,...ratios);
 const Yr=v=>T+(rhi-v)/(rhi-rlo)*ph;
 g.strokeStyle='#161b22'; for(let k=0;k<=4;k++){const y=T+ph*k/4; g.beginPath(); g.moveTo(L,y); g.lineTo(W-R,y); g.stroke();}
 g.strokeStyle='#30363d'; g.setLineDash([3,3]); g.beginPath(); g.moveTo(L,Yr(1)); g.lineTo(W-R,Yr(1)); g.stroke(); g.setLineDash([]);
 if(oi.length){ const lo=Math.min(...oi.map(p=>p[1])), hi=Math.max(...oi.map(p=>p[1])); const Yo=v=>T+(hi-v)/Math.max(1e-9,hi-lo)*ph;
  g.strokeStyle='#58a6ff'; g.lineWidth=1.6; g.beginPath(); oi.forEach((p,i)=>i?g.lineTo(X(p[0]),Yo(p[1])):g.moveTo(X(p[0]),Yo(p[1]))); g.stroke();
  g.fillStyle='#58a6ff'; g.font='10px system-ui'; g.textAlign='right'; g.fillText(fmt(hi),L-4,T+8); g.fillText(fmt(lo),L-4,H-B); g.textAlign='left'; }
 keys.slice(1).forEach(([k,col])=>{ const ser=S[k]||[]; if(!ser.length) return; g.strokeStyle=col; g.lineWidth=1.4; g.beginPath();
  ser.forEach((p,i)=>i?g.lineTo(X(p[0]),Yr(p[1])):g.moveTo(X(p[0]),Yr(p[1]))); g.stroke(); });
 g.fillStyle='#8b949e'; g.font='10px system-ui'; g.textAlign='left';
 [rhi,1,rlo].forEach(v=>g.fillText(v.toFixed(2),W-R+4,Yr(v)+3));
 g.fillStyle='#6e7681'; g.font='9px system-ui'; g.fillText(hm(t0),L,H-8); g.textAlign='right'; g.fillText(hm(t1),W-R,H-8); g.textAlign='left';
 const l=m.latest||{};
 $('metricsinfo').innerHTML=`Binance-Kennzahlen · Open Interest ${l.oi_notional?fmt(l.oi_notional)+' USD':'—'} · L/S Konten ${l.global_ls_account?(+l.global_ls_account).toFixed(2):'—'} `
  +`· L/S Top-Trader ${l.top_ls_position?(+l.top_ls_position).toFixed(2):'—'} · Taker ${l.taker_ls?(+l.taker_ls).toFixed(2):'—'} — Verhältnisse rechts skaliert, 1,00 = ausgeglichen (gestrichelt)`;
}

function drawWhales(d){
 const [g,W,H]=fit($('whalechart')); g.clearRect(0,0,W,H);
 const E=d.exposure||[], P=d.price||[], coin=$('coin').value;
 const C=d.current||[];
 if(!E.length){g.fillStyle='#8b949e';g.font='12px system-ui';
  g.fillText(C.length
   ? `Zeitreihe für ${coin} entsteht mit den nächsten Snapshots — die Tabelle unten ist schon gefüllt`
   : 'noch keine Wal-Positionen erfasst — Wale ab 20 Mio. USD erscheinen hier, sobald der Recorder sie findet',12,24);
  drawWhaleTable(d); return;}
 const L=8,R=64,T=10,B=24, pw=W-L-R, ph=H-T-B;
 const t0=E[0].ts, t1=E[E.length-1].ts;
 const X=t=>L+(t-t0)/(t1-t0+1)*pw;
 const mxE=Math.max(...E.map(e=>Math.max(e.long_usd,e.short_usd)),1);
 const Ye=v=>T+ph/2-v/mxE*(ph/2-4);
 // Exposure als gespiegelte Flaechen um die Mittellinie
 g.fillStyle='rgba(59,165,93,.55)'; g.beginPath(); g.moveTo(X(t0),Ye(0));
 E.forEach(e=>g.lineTo(X(e.ts),Ye(e.long_usd))); g.lineTo(X(t1),Ye(0)); g.fill();
 g.fillStyle='rgba(224,75,75,.55)'; g.beginPath(); g.moveTo(X(t0),Ye(0));
 E.forEach(e=>g.lineTo(X(e.ts),Ye(-e.short_usd))); g.lineTo(X(t1),Ye(0)); g.fill();
 g.strokeStyle='#30363d'; g.beginPath(); g.moveTo(L,Ye(0)); g.lineTo(W-R,Ye(0)); g.stroke();
 // Kurs auf eigener Skala rechts
 if(P.length){const pv=P.map(p=>p[1]), plo=Math.min(...pv), phi=Math.max(...pv);
  const Yp=p=>T+(phi-p)/(phi-plo||1)*ph;
  g.strokeStyle='#fff';g.lineWidth=1.3;g.beginPath();
  P.forEach((p,i)=>{const x=X(p[0]),y=Yp(p[1]); if(x<L||x>W-R)return; i?g.lineTo(x,y):g.moveTo(x,y)});
  g.stroke();
  g.fillStyle='#8b949e';g.font='9px system-ui';
  g.fillText(px(phi),W-R+3,T+9); g.fillText(px(plo),W-R+3,T+ph);
  // Ereignismarker
  (d.events||[]).forEach(ev=>{const x=X(ev.ts); if(x<L||x>W-R)return;
   const up=ev.event==='open'||ev.event==='add'||(ev.event==='flip');
   const near=P.reduce((a,b)=>Math.abs(b[0]-ev.ts)<Math.abs(a[0]-ev.ts)?b:a);
   const y=Yp(near[1]);
   g.fillStyle=ev.side==='long'?'#3ba55d':'#e04b4b';
   g.beginPath(); if(up){g.moveTo(x,y-9);g.lineTo(x-5,y-1);g.lineTo(x+5,y-1);}
   else{g.moveTo(x,y+9);g.lineTo(x-5,y+1);g.lineTo(x+5,y+1);} g.fill();});}
 g.fillStyle='#8b949e';g.font='9px system-ui';
 g.fillText('+'+fmt(mxE),L+2,T+9); g.fillText('-'+fmt(mxE),L+2,T+ph-2);
 g.fillStyle='#6e7681'; g.fillText(hm(t0),L,H-8); g.fillText(hm(t1),W-R-60,H-8);
 drawWhaleTable(d);
}

function drawWhaleTable(d){
 const C=d.current||[], coin=$('coin').value;
 const short=a=>a.slice(0,6)+'…'+a.slice(-4);
 const age=s=>{const h=(Date.now()/1000-s)/3600; return h<1?Math.round(h*60)+' min':h<48?h.toFixed(1)+' h':(h/24).toFixed(1)+' T';};
 // Nach Wallet gruppiert: alle Positionen einer Adresse als Block, Wallets nach Gesamtwert,
 // innerhalb des Blocks nach Positionswert. Der Blockkopf nennt Summe und Netto-Ausrichtung.
 const groups=new Map();
 C.forEach(w=>{ const g=groups.get(w.addr)||{addr:w.addr,rows:[],total:0,long:0,short:0,upnl:0};
   g.rows.push(w); g.total+=w.pos_value||0; g.upnl+=w.upnl||0; if(w.side==='long') g.long+=w.pos_value||0; else g.short+=w.pos_value||0; groups.set(w.addr,g); });
 const ordered=[...groups.values()].sort((a,b)=>b.total-a.total);
 ordered.forEach(g=>g.rows.sort((a,b)=>(b.pos_value||0)-(a.pos_value||0)));
 const head=g=>{ const net=g.long-g.short, col=net>0?'#3ba55d':net<0?'#e04b4b':'#c9d1d9';
   return `<tr class="grp"><td class="mono" colspan="3"><b>${short(g.addr)}</b> · ${g.rows.length} Position${g.rows.length>1?'en':''}</td>`
    +`<td class="n"><b>${fmt(g.total)}</b></td><td colspan="4" style="color:${col}">netto ${net>0?'long':net<0?'short':'neutral'} ${fmt(Math.abs(net))}</td>`
    +`<td class="n" style="color:${g.upnl>=0?'#3ba55d':'#e04b4b'}">${g.upnl>=0?'+':''}${fmt(g.upnl)}</td><td colspan="2"></td></tr>`; };
 $('whaletable').innerHTML=C.length?`<table class="w"><tr>
  <th>Wallet</th><th>Coin</th><th>Seite</th><th class="n">Wert</th><th class="n">Hebel</th>
  <th class="n">Einstieg</th><th class="n">Liq.-Preis</th><th class="n">Abstand</th>
  <th class="n">unreal. PnL</th><th>offen seit</th><th>Stand</th></tr>`
  +ordered.map(g=>head(g)+g.rows.map(w=>{const dist=w.mark_px?(w.liq_px-w.mark_px)/w.mark_px*100:0;
   const dc=Math.abs(dist)<3?'#e04b4b':Math.abs(dist)<8?'#d29922':'#c9d1d9';
   const hl=w.coin===coin?' style="background:#161b22"':'';
   return `<tr${hl}><td class="mono" style="color:#6e7681;padding-left:18px">${g.rows.length>1?'└':''} ${short(w.addr)}</td>
    <td><b>${w.coin}</b></td>
    <td style="color:${w.side==='long'?'#3ba55d':'#e04b4b'}">${w.side}</td>
    <td class="n"><b>${fmt(w.pos_value)}</b></td><td class="n">${(+w.leverage).toFixed(0)}x</td>
    <td class="n">${px(w.entry_px)}</td><td class="n">${px(w.liq_px)}</td>
    <td class="n" style="color:${dc}">${dist>0?'+':''}${dist.toFixed(1)} %</td>
    <td class="n" style="color:${w.upnl>=0?'#3ba55d':'#e04b4b'}">${w.upnl>=0?'+':''}${fmt(w.upnl)}</td>
    <td>${w.opened_at?age(w.opened_at):'—'}</td><td class="mono">${age(w.ts)} alt</td></tr>`}).join('')).join('')
  +'</table>':'<div class="sub">Aktuell keine offene Position über der Schwelle.</div>';
 const other=C.filter(w=>w.coin!==coin).length;
 if(C.length&&!C.some(w=>w.coin===coin))
  $('whaletable').innerHTML=`<div class="sub" style="margin-bottom:6px">Kein Wal in ${coin} — `
   +`die ${other} unten halten ihre großen Positionen in anderen Coins.</div>`+$('whaletable').innerHTML;

 const ev=(d.events||[]).slice(-12).reverse();
 const name={open:'eröffnet',add:'stockt auf',reduce:'reduziert',close:'schließt',flip:'dreht auf'};
 $('whaleevents').innerHTML=ev.length?'<b>Letzte Änderungen:</b><br>'+ev.map(e=>
  `${hm(e.ts)} · <span class="mono">${short(e.addr)}</span> ${name[e.event]||e.event} `
  +`<span style="color:${e.side==='long'?'#3ba55d':'#e04b4b'}">${e.side}</span> `
  +`${e.delta_usd>=0?'+':''}${fmt(e.delta_usd)} USD bei ${px(e.mark_px)}`).join('<br>')
  :'noch keine Änderungen im Zeitraum';
}

// ---- Tooltip -------------------------------------------------------------
function showTip(ev, title, rows){
 const t=$('tip');
 t.innerHTML=`<div class="t">${title}</div>`+rows.map(
  r=>`<div class="r"><i>${r[0]}</i><b style="color:${r[2]||'#c9d1d9'}">${r[1]}</b></div>`).join('');
 t.style.display='block';
 const w=t.offsetWidth,h=t.offsetHeight;
 let x=ev.clientX+14, y=ev.clientY-h-10;
 if(x+w>innerWidth-8) x=ev.clientX-w-14;
 if(y<8) y=ev.clientY+18;
 // auf schmalen Bildschirmen: nie über den Rand hinaus, unter dem Finger platzieren
 x=Math.max(6, Math.min(x, innerWidth-w-6));
 if(innerWidth<700){ y=ev.clientY+24; if(y+h>innerHeight-8) y=ev.clientY-h-24; }
 t.style.left=x+'px'; t.style.top=y+'px';
}
function hideTip(){ $('tip').style.display='none'; }

function pos(ev,c){const r=c.getBoundingClientRect();
 return {x:ev.clientX-r.left, y:ev.clientY-r.top};}

function tipHeat(ev){
 const G=GEO.heat; if(!G) return hideTip();
 const {x,y}=pos(ev,$('heat'));
 if(x<G.L||x>G.L+G.pw||y<G.T||y>G.T+G.ph) return hideTip();
 if(LAST){ drawHeat(LAST); crosshair($('heat'),G,x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const d=G.d;
 const t=G.t0+(x-G.L)/G.pw*(G.t1-G.t0);
 let j=0,best=1e18; d.times.forEach((tt,k)=>{const e=Math.abs(tt-t);if(e<best){best=e;j=k}});
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 let i=0,bp=1e18; d.levels.forEach((lv,k)=>{const e=Math.abs(lv-p);if(e<bp){bp=e;i=k}});
 const v=d.grid[i][j], side=d.sides[i]?d.sides[i][j]:'';
 const pr=d.price.reduce((a,b)=>Math.abs(b[0]-t)<Math.abs(a[0]-t)?b:a);
 const rows=[['Zeit',hm(d.times[j])],['Preisniveau',px(d.levels[i])+' USD'],
             ['Kurs damals',px(pr[1])+' USD']];
 if(v>0){
  rows.push(['Notional',fmt(v)+' USD']);
  if(G.sc) rows.push(['Rang',(G.sc.pct(v)*100).toFixed(0)+'. Perzentil']);
  if(side) rows.push(['Art', side==='long'?'Long-Liquidationen':'Short-Liquidationen',
                      side==='long'?'#e04b4b':'#3ba55d']);
 } else rows.push(['Notional','kein Cluster','#6e7681']);
 showTip(ev,'Heatmap',rows);
}

function tipChart(ev){
 const G=GEO.chart; if(!G) return hideTip();
 const {x,y}=pos(ev,$('chart'));
 if(x<G.Lm||x>G.Lm+G.pw||y<G.T||y>G.T+G.ph) return hideTip();
 if(LAST_CHART){ drawChart(LAST_CHART); crosshair($('chart'),{L:G.Lm,R:G.R,T:G.T,B:G.B,W:G.W,H:G.H},x,y,G.hi-(y-G.T)/G.ph*(G.hi-G.lo)); }
 const i=Math.max(0,Math.min(G.C.length-1,Math.floor((x-G.Lm)/G.cw)));
 const c=G.C[i];
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 const rows=[['Eröffnung',px(c.o)],['Hoch',px(c.h)],['Tief',px(c.l)],
             ['Schluss',px(c.c),c.c>=c.o?'#3ba55d':'#e04b4b'],
             ['Volumen',fmt(c.v)]];
 const near=G.L.filter(l=>Math.abs(l.px-p)/p<0.004)
             .sort((a,b)=>Math.abs(a.px-p)-Math.abs(b.px-p))[0];
 if(near) rows.push(['Marke '+px(near.px),fmt(near.notional)+' USD · '
   +near.x_vol.toFixed(2)+'x Vol', near.side==='long'?'#e04b4b':'#3ba55d']);
 const inGap=(G.FV||[]).filter(f=>p>=f.bot&&p<=f.top&&i>=f.i&&(f.fill_i==null||i<=f.fill_i))[0];
 if(inGap) rows.push(['FVG '+(inGap.kind==='bull'?'bullisch':'bärisch'),
   px(inGap.bot)+'–'+px(inGap.top)+' · '+(inGap.size_pct*100).toFixed(2)+' % · '
   +(inGap.fill_i==null?(inGap.fill_pct*100).toFixed(0)+' % gefüllt, offen':'gefüllt'),
   inGap.kind==='bull'?'#39ff14':'#e04b4b']);
 showTip(ev,tlabel(c.t)+(LAST_CHART&&LAST_CHART.agg>=1440?'':''),rows);
}

function tipDepth(ev){
 const G=GEO.depth; if(!G) return hideTip();
 const {x,y}=pos(ev,$('depth'));
 if(y<G.T||y>G.T+G.ph) return hideTip();
 const p=G.hi-(y-G.T)/G.ph*(G.hi-G.lo);
 if(LAST){ drawDepth(LAST_DEPTH||{rows:G.rows,price:G.p0,vol_1h:G.vol}); crosshair($('depth'),G,x,y,p); }
 const r=G.rows.reduce((a,b)=>Math.abs(b.bucket_px-p)<Math.abs(a.bucket_px-p)?b:a);
 const dist=(r.bucket_px-G.p0)/G.p0;
 showTip(ev,'Cluster bei '+px(r.bucket_px)+' USD',[
  ['Notional',fmt(r.notional)+' USD'],
  ['Positionen',r.n_pos],
  ['Abstand zum Kurs',(dist*100).toFixed(2)+' %'],
  ['Anteil Stundenvol.',G.vol?(r.notional/G.vol).toFixed(2)+'x':'—'],
  ['Art',r.side==='long'?'Long-Liquidationen':'Short-Liquidationen',
   r.side==='long'?'#e04b4b':'#3ba55d']]);
}

for(const [id,fn] of [['heat',tipHeat],['chart',tipChart],['depth',tipDepth],['stops',tipStops]]){
 const c=$(id);
 c.addEventListener('mousemove',fn);
 const redraw=()=>{ if(LAST_CHART){ if(c.id==='stops') drawStops(LAST_CHART); if(c.id==='chart') drawChart(LAST_CHART); }
  if(LAST&&c.id==='heat') drawHeat(LAST); if(LAST_DEPTH&&c.id==='depth') drawDepth(LAST_DEPTH); };
 c.addEventListener('mouseleave',()=>{hideTip(); redraw();});
 c.addEventListener('click',fn);
 c.addEventListener('touchstart',e=>{e.preventDefault();fn(e.touches[0]);},{passive:false});
 c.addEventListener('touchmove',e=>{e.preventDefault();fn(e.touches[0]);},{passive:false});
 c.addEventListener('touchend',()=>setTimeout(()=>{hideTip(); redraw();},2500));
}

async function loadChart(){
 const coin=$('coin').value, [agg,mins]=$('tf').value.split('|');
 const fvg=$('fvg')?$('fvg').value:'0.0005';
 try{LAST_CHART=await getJSON(`/chart?coin=${coin}&agg=${agg}&minutes=${mins}&fvg=${fvg}&src=${SRC()}`);
  if(LAST_DATA) renderKpi();
  computeSignal();
  drawChart(LAST_CHART);
  drawStops(LAST_CHART);
  fillIndicators(LAST_CHART);
 }catch(e){ console.error('Chart:', e); showErr('Chart: '+(e.message||e)); }
}
function renderKpi(){
 const d=LAST_DATA; if(!d) return;
 const dp=d.depth||{rows:[]};
 const up=dp.rows.filter(r=>r.side==='short').reduce((a,b)=>a+b.notional,0);
 const dn=dp.rows.filter(r=>r.side==='long').reduce((a,b)=>a+b.notional,0);
 const B=(LAST_CHART&&LAST_CHART.bnc)||{}, M=B.metrics||{}, src=SRC();
 const D={
  liqAbove:'Summe des Notionals (USD) aller Short-Positionen, die laut Positionsdaten über dem aktuellen Kurs liquidiert würden — eine Erwartung, kein Ereignis.',
  liqBelow:'Summe des Notionals (USD) aller Long-Positionen, die unter dem aktuellen Kurs liquidiert würden — Erwartung.',
  liqL:'USD-Notional der in der letzten Stunde auf Binance zwangsliquidierten LONG-Positionen (Verkaufs-Fills).',
  liqS:'USD-Notional der in der letzten Stunde auf Binance zwangsliquidierten SHORT-Positionen (Kauf-Fills).',
  oi:'Open Interest: Gesamtwert aller offenen Perpetual-Positionen auf Binance in USD (sumOpenInterestValue).',
  lsAcc:'Zahl der Konten mit Netto-Long geteilt durch Zahl der Konten mit Netto-Short, alle Binance-Konten (globalLongShortAccountRatio). 1,00 : 1 = ausgeglichen.',
  lsTop:'Positionsgröße long geteilt durch Positionsgröße short der größten Binance-Konten (topLongShortPositionRatio). Gewichtet nach USD, nicht nach Kontenzahl.',
  taker:'Volumen der aggressiven Market-Käufe geteilt durch Volumen der Market-Verkäufe (takerlongshortRatio, 5-min-Fenster). Über 1: Käufer nehmen Liquidität.',
  vol:'Gehandeltes Volumen der letzten Stunde in USD (Kerzenvolumen × Preis).',
  addr:'Anzahl der Hyperliquid-Adressen, die der Recorder aus den Trade-Feeds gesammelt hat.',
  pos:'Anzahl dieser Adressen mit mindestens einer offenen Perpetual-Position (nach der letzten Abfrage).',
 };
 const liqTiles=src==='hl'?`
  <div title="${D.liqAbove}"><span>Short-Liqs darüber (USD)</span><b style="color:#3ba55d">${fmt(up)}</b></div>
  <div title="${D.liqBelow}"><span>Long-Liqs darunter (USD)</span><b style="color:#e04b4b">${fmt(dn)}</b></div>`
  :src==='bnc'?`
  <div title="${D.liqL}"><span>Long-Liquidationen 1 h (Binance, USD)</span><b style="color:#e04b4b">${fmt((B.liqs_1h||{}).long||0)}</b></div>
  <div title="${D.liqS}"><span>Short-Liquidationen 1 h (Binance, USD)</span><b style="color:#3ba55d">${fmt((B.liqs_1h||{}).short||0)}</b></div>
  <div title="${D.oi}"><span>Open Interest (Binance, USD)</span><b>${M.oi_notional?fmt(M.oi_notional):'—'}</b></div>`
  +ratioTile('Long/Short Konten (Verhältnis)', M.global_ls_account, 'der Konten long', 'short', D.lsAcc)
  +ratioTile('Long/Short Top-Trader (Verhältnis)', M.top_ls_position, 'des Positionswerts long', 'short', D.lsTop)
  +ratioTile('Taker Kauf/Verkauf (Verhältnis)', M.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', D.taker)
  :`
  <div title="${D.liqAbove}"><span>Short-Liqs darüber (HL erwartet, USD)</span><b style="color:#3ba55d">${fmt(up)}</b></div>
  <div title="${D.liqBelow}"><span>Long-Liqs darunter (HL erwartet, USD)</span><b style="color:#e04b4b">${fmt(dn)}</b></div>
  <div title="${D.liqL} + ${D.liqS}"><span>Liquidationen 1 h (Binance, Long + Short, USD)</span><b>${fmt(((B.liqs_1h||{}).long||0)+((B.liqs_1h||{}).short||0))}</b></div>
  <div title="${D.oi}"><span>Open Interest (Binance, USD)</span><b>${M.oi_notional?fmt(M.oi_notional):'—'}</b></div>`
  +ratioTile('Taker Kauf/Verkauf Binance (Verhältnis)', M.taker_ls, 'des Taker-Volumens Käufe', 'Verkäufe', D.taker);
 const vol=src==='fusion'?((dp.vol_1h||0)+(B.vol_1h||0)):src==='bnc'?(B.vol_1h||dp.vol_1h||0):(dp.vol_1h||0);
 $('kpi').innerHTML=`
  <div title="Letzter Handelspreis in USD${src==='bnc'?' (Binance-Kerze)':' (Hyperliquid-Trade-Feed)'}"><span>Kurs${src==='bnc'?' (Binance)':''} (USD)</span><b>${dp.price?px(dp.price):'—'}</b></div>`+liqTiles+`
  <div title="${D.vol}"><span>Volumen 1 h${src==='fusion'?' (HL + Binance)':src==='bnc'?' (Binance)':''} (USD)</span><b>${fmt(vol)}</b></div>`
  +(src!=='bnc'?`
  <div title="${D.addr}"><span>Adressen erfasst (Anzahl)</span><b>${d.stats.addresses.toLocaleString('de-DE')}</b></div>
  <div title="${D.pos}"><span>mit offener Position (Anzahl)</span><b>${d.stats.positions.toLocaleString('de-DE')}</b></div>`:'')+`
  <div title="Kursänderung der letzten 60 Minuten in Prozent (Schluss jetzt gegen Schluss vor 60 Minutenkerzen)"><span>60-Minuten-Trend (%)</span><b id="kpi_trend">—</b></div>
  <div title="Relative-Stärke-Index nach Wilder über 14 Kerzen des gewählten Rasters, Skala 0–100: unter 30 überverkauft, über 70 überkauft"><span id="kpi_rsi_lbl">RSI 14</span><b id="kpi_rsi">—</b></div>
  <div title="Gleitender Durchschnitt der Wochenschlusskurse über 50 Wochen (USD); darunter der Abstand des Kurses in Prozent — ▲ Kurs darüber, ▼ Kurs darunter"><span>MA 50 Wochen (USD · Abstand %)</span><b id="kpi_ma50w">—</b></div>
  <div title="Gleitender Durchschnitt der Tagesschlusskurse über 200 Tage (USD); darunter der Abstand des Kurses in Prozent"><span>MA 200 Tage (USD · Abstand %)</span><b id="kpi_ma200d">—</b></div>
  <div title="Zeitpunkt des letzten verifizierten Datenbank-Backups"><span>Letztes Backup</span><b id="kpi_backup">—</b></div>
  <div title="Ergebnis der letzten SQLite-Integritätsprüfung (quick_check)"><span>Datenbank</span><b id="kpi_db">—</b></div>
  <div title="Netto-Summe der Konfluenz-Punkte: Kauf-Punkte minus Verkaufs-Punkte; ab ±3 Konfluenz, Details im Abschnitt Konfluenz"><span>Konfluenz</span><b id="kpi_signal">—</b></div>
  <div title="Verbrauchte Gewichtseinheiten der Hyperliquid-API in der letzten Minute (Positionsabfrage 2, Orderabfrage 20) gegen das Limit von 1.200 je Minute und IP"><span>API-Gewicht / Minute</span><b id="kpi_api">—</b></div>`;
 if(LAST_CHART){ fillBudget(LAST_CHART); fillIndicators(LAST_CHART); }
 if(LAST_HEALTH) fillHealth(LAST_HEALTH);
}

async function load(){
 loadChart();
 const coin=$('coin').value, h=$('hours').value;
 const d=await getJSON(`/data?coin=${coin}&hours=${h}&src=${SRC()}`);
 LAST=d.grid; LAST_DEPTH=d.depth; LAST_DATA=d; drawHeat(d.grid); drawDepth(d.depth);
 if(SRC()==='bnc'){ LAST_WHALES={exposure:[],current:[],events:[],price:[]}; drawWhales(LAST_WHALES); drawMetrics(d.metrics); computeSignal(); if(LAST_CHART) drawChart(LAST_CHART); }
 else { try{LAST_WHALES=await getJSON(`/whales?coin=${coin}&hours=${Math.max(72,h)}`); drawWhales(LAST_WHALES); computeSignal();
  if(LAST_CHART) drawChart(LAST_CHART);}catch(e){}
  if(SRC()==='fusion'&&d.bnc) drawMetrics(d.bnc.metrics); else $('bncmetrics').style.display='none'; }
 renderKpi();
 if(LAST_CHART) fillBudget(LAST_CHART);
 if(LAST_CHART) computeSignal();
 if(LAST_CHART) fillIndicators(LAST_CHART);
 if(LAST_HEALTH) fillHealth(LAST_HEALTH);
 $('warn').textContent=d.stats.days<14
  ? `Aufzeichnung läuft erst ${d.stats.days.toFixed(1)} Tage — die Abdeckung der `
    +`Adressen ist noch unvollständig, absolute Zahlen fallen zu niedrig aus.`:'';
}
$('thr').oninput=()=>{$('thrval').textContent='Perzentil '+$('thr').value;
                      if(LAST) drawHeat(LAST);};
getJSON('/coins').then(cs=>{
 if(!Array.isArray(cs)||!cs.length){showErr('/coins: leere Liste — Datenbank ohne Kerzen? Pfad in der Unit prüfen');return;}
 $('coin').innerHTML=cs.map(c=>`<option>${c}</option>`).join('');
 load(); loadHealth();
 setInterval(load,20000); setInterval(loadChart,5000); setInterval(loadHealth,3600000);
 $('coin').onchange=$('hours').onchange=load;
 try{ const sv=localStorage.getItem('hl_src'); if(sv&&$('src').querySelector(`option[value="${sv}"]`)) $('src').value=sv; }catch(e){}
 $('src').onchange=()=>{ try{localStorage.setItem('hl_src',SRC());}catch(e){} applySrcLabels(); load(); };
 applySrcLabels();
 $('tf').onchange=loadChart; $('fvg').onchange=loadChart;
 $('fvgtoggle').onclick=()=>setFvg(!FVG_ON);
 $('updbtn').onclick=runUpdate;
 let rsz=null; addEventListener('resize',()=>{clearTimeout(rsz); rsz=setTimeout(load,300);});   // Drehung: alle Panels neu
}).catch(()=>{});   // Fehler wurde von getJSON bereits in der Leiste gemeldet
</script></body></html>"""


# ---------------------------------------------------------------------------
# Update per Knopf: Archiv von GitHub laden, update.py in eigener systemd-Einheit
# starten (ein Kind des Dashboards stürbe mit dem Dashboard-Neustart).
# ---------------------------------------------------------------------------

UPDATE_URL = "https://raw.githubusercontent.com/lll174/Seed/main/hl_liq_project.zip"
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
UPDATE_LOG = os.path.join(ROOT_DIR, "updates", "last_update.log")


def raw_github(url: str) -> str:
    """blob-Links der GitHub-Oberfläche auf den Rohdownload umschreiben."""
    m = re.match(r"https?://github\.com/([^/]+)/([^/]+)/blob/(.+)", url)
    return f"https://raw.githubusercontent.com/{m.group(1)}/{m.group(2)}/{m.group(3)}" if m else url


def sudo_password() -> tuple[str | None, str]:
    f = os.path.join(ROOT_DIR, "sudo.txt")
    if not os.path.exists(f):
        return None, "sudo.txt fehlt im Projektordner"
    mode = os.stat(f).st_mode & 0o777
    if mode & 0o077:
        return None, f"sudo.txt hat Rechte {oct(mode)} — bitte chmod 600 sudo.txt"
    pw = open(f, errors="replace").read().strip()
    return (pw, "") if pw else (None, "sudo.txt ist leer")


def start_update(url: str) -> dict:
    """Archiv laden, prüfen, update.py abgekoppelt starten. Liefert Status für die Seite."""
    import urllib.request, zipfile
    pw, why = sudo_password()
    if not pw:
        return {"ok": False, "msg": why}
    os.makedirs(os.path.dirname(UPDATE_LOG), exist_ok=True)
    target = os.path.join(ROOT_DIR, "updates", "hl_liq_project.zip")
    try:
        req = urllib.request.Request(raw_github(url), headers={"User-Agent": "hl-dashboard-update/1.0",
                                                               "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read()
    except Exception as e:
        return {"ok": False, "msg": f"Download fehlgeschlagen: {e}"}
    if data[:2] != b"PK":
        return {"ok": False, "msg": "Download ist kein ZIP — GitHub-Link prüfen (Rohdatei, nicht HTML-Seite)"}
    with open(target, "wb") as f:
        f.write(data)
    try:
        with zipfile.ZipFile(target) as z:
            names = {n.split("/")[-1] for n in z.namelist()}
        if not {"hl_recorder.py", "hl_viz.py", "update.py"} <= names:
            return {"ok": False, "msg": "Archiv unvollständig"}
    except zipfile.BadZipFile as e:
        return {"ok": False, "msg": f"ZIP defekt: {e}"}
    py = os.path.join(ROOT_DIR, ".venv", "bin", "python")
    if not os.path.exists(py):
        py = sys.executable
    uid, gid = os.getuid(), os.getgid()
    with open(UPDATE_LOG, "w") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] Archiv geladen ({len(data)//1024} kB), starte update.py …\n")
    if shutil.which("systemd-run") and os.path.exists("/run/systemd/system"):
        # Läuft noch ein Update? Dann nicht doppelt starten.
        active = subprocess.run(["systemctl", "list-units", "--no-legend", "--plain", "--state=active,activating",
                                 "hl-update*"], capture_output=True, text=True).stdout.strip()
        if active:
            return {"ok": False, "msg": "Ein Update läuft noch: " + active.split()[0]}
        # Reste gescheiterter Läufe freigeben (sonst: 'Unit ... was already loaded')
        subprocess.run(["sudo", "-S", "-p", "", "systemctl", "reset-failed", "hl-update.service", "hl-update-*.service"],
                       input=pw + "\n", capture_output=True, text=True)
        # eigene, kurzlebige Einheit mit eindeutigem Namen: überlebt den Dashboard-Neustart
        unit = "hl-update-" + time.strftime("%Y%m%d-%H%M%S")
        cmd = ["sudo", "-S", "-p", "", "systemd-run", f"--unit={unit}", "--collect",
               f"--uid={uid}", f"--gid={gid}", f"--working-directory={ROOT_DIR}",
               f"--property=StandardOutput=append:{UPDATE_LOG}",
               f"--property=StandardError=append:{UPDATE_LOG}",
               py, os.path.join(ROOT_DIR, "update.py"), target, "--yes"]
        r = subprocess.run(cmd, input=pw + "\n", capture_output=True, text=True)
        if r.returncode != 0:
            return {"ok": False, "msg": "systemd-run fehlgeschlagen: " + (r.stderr.strip()[-200:] or "unbekannt")}
        with open(os.path.join(ROOT_DIR, "updates", "last_unit.txt"), "w") as f:
            f.write(unit)
        return {"ok": True, "msg": f"Update gestartet (Einheit {unit}). Das Dashboard startet gleich neu."}
    # ohne systemd: abgekoppelter Prozess
    with open(UPDATE_LOG, "a") as logf:
        subprocess.Popen([py, os.path.join(ROOT_DIR, "update.py"), target, "--yes"],
                         cwd=ROOT_DIR, stdout=logf, stderr=subprocess.STDOUT, start_new_session=True)
    return {"ok": True, "msg": "Update gestartet."}


def update_status() -> dict:
    running = False
    if shutil.which("systemctl"):
        unit = "hl-update"
        try:
            with open(os.path.join(ROOT_DIR, "updates", "last_unit.txt")) as f:
                unit = f.read().strip() or unit
        except OSError:
            pass
        running = subprocess.run(["systemctl", "is-active", unit], capture_output=True,
                                 text=True).stdout.strip() in ("active", "activating")
    log = ""
    try:
        with open(UPDATE_LOG, errors="replace") as f:
            log = "".join(f.readlines()[-40:])
    except OSError:
        pass
    done = ("Fertig." in log) or ("FEHLER" in log and not running) or ("Abbruch" in log)
    return {"running": running, "done": done and not running, "log": log,
            "ok_marker": "Fertig." in log}


class Handler(BaseHTTPRequestHandler):
    db = DB_PATH

    def _send(self, body: bytes, ctype: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        from urllib.parse import urlparse
        u = urlparse(self.path)
        if u.path == "/update":
            self._send(json.dumps(start_update(UPDATE_URL)).encode(), "application/json")
        else:
            self.send_error(404)

    def do_GET(self) -> None:
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        try:
            if u.path == "/":
                self._send(PAGE.encode(), "text/html; charset=utf-8")
            elif u.path == "/update/status":
                self._send(json.dumps(update_status()).encode(), "application/json")
            elif u.path == "/coins":
                con = connect(self.db)
                cs = [r[0] for r in con.execute(
                    "SELECT DISTINCT coin FROM bars ORDER BY coin")]
                con.close()
                self._send(json.dumps(cs or ["BTC"]).encode(), "application/json")
            elif u.path == "/manifest.json":
                self._send(json.dumps({
                    "name": "HL Liquidationen", "short_name": "HL Liq",
                    "start_url": "/", "display": "standalone",
                    "background_color": "#0d1117", "theme_color": "#0d1117",
                    "icons": [{"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}],
                }).encode(), "application/manifest+json")
            elif u.path == "/icon.svg":
                self._send(ICON_SVG.encode(), "image/svg+xml")
            elif u.path == "/health":
                self._send(json.dumps(load_health(self.db)).encode(), "application/json")
            elif u.path == "/whales":
                q = parse_qs(u.query)
                con = connect(self.db)
                payload = load_whales(con, q.get("coin", ["BTC"])[0],
                                      int(q.get("hours", ["72"])[0]))
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/chart":
                q = parse_qs(u.query)
                con = connect(self.db)
                src = q.get("src", ["hl"])[0]
                coin_ = q.get("coin", ["BTC"])[0]; mins_ = int(q.get("minutes", ["240"])[0]); agg_ = int(q.get("agg", ["1"])[0])
                payload = load_chart(con, coin_, mins_, agg_, fvg_min=float(q.get("fvg", ["0.0005"])[0]))
                if src in ("bnc", "fusion"):
                    payload = attach_binance(con, payload, coin_, agg_, mins_, src)
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            elif u.path == "/data":
                q = parse_qs(u.query)
                coin = q.get("coin", ["BTC"])[0]
                hours = int(q.get("hours", ["24"])[0])
                con = connect(self.db)
                span = con.execute("SELECT MIN(ts) a, MAX(ts) b FROM bars").fetchone()
                stats = {
                    "addresses": con.execute("SELECT COUNT(*) FROM addresses").fetchone()[0],
                    "positions": con.execute(
                        "SELECT COUNT(*) FROM addresses WHERE notional>0").fetchone()[0],
                    "days": ((span["b"] - span["a"]) / 86400) if span["a"] else 0,
                }
                src = q.get("src", ["hl"])[0]
                if src == "bnc":
                    payload = {"grid": bnc_grid(con, coin, hours), "depth": bnc_depth(con, coin), "stats": stats,
                               "metrics": bnc_metrics_series(con, coin, max(hours, 24)), "src": "bnc"}
                else:
                    payload = {"grid": load_grid(con, coin, hours),
                               "depth": load_depth(con, coin), "stats": stats, "src": src}
                    if src == "fusion":
                        payload["bnc"] = {"grid_liqs": bnc_grid(con, coin, hours)["liqs"], "depth": bnc_depth(con, coin),
                                          "metrics": bnc_metrics_series(con, coin, max(hours, 24))}
                con.close()
                self._send(json.dumps(payload).encode(), "application/json")
            else:
                self.send_error(404)
        except Exception as e:
            self.send_error(500, str(e))

    def log_message(self, *a) -> None:
        pass


def serve(db: str, port: int, host: str = "127.0.0.1") -> None:
    Handler.db = db
    try:
        srv = ThreadingHTTPServer((host, port), Handler)   # eine langsame Anfrage blockiert nicht die anderen
        srv.daemon_threads = True
    except OSError as e:
        if e.errno == 98:                      # EADDRINUSE
            print(f"Port {port} ist bereits belegt.\n")
            print("Meist läuft das Dashboard schon — als systemd-Dienst oder aus")
            print("einem früheren Aufruf. Beides zusammen geht nicht.\n")
            print("  Wer hält den Port?     sudo ss -ltnp | grep " + str(port))
            print("  Dienst-Status:         systemctl status hl-dashboard")
            print("  Dienst anhalten:       sudo systemctl stop hl-dashboard")
            print(f"  oder anderen Port:     --port {port + 1}")
            raise SystemExit(2)
        raise
    if host not in ("127.0.0.1", "localhost"):
        print("Achtung: Das Dashboard ist im Netzwerk erreichbar und hat keine "
              "Authentifizierung. Nur im vertrauenswürdigen Heimnetz nutzen.")
    print(f"Dashboard: http://{host}:{port}  (Strg-C beendet)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbeendet")


# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Visualisierung der Liquidationsdaten")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--coin", default="BTC")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--depth", action="store_true", help="aktuellen Snapshot zeichnen")
    p.add_argument("--threshold", type=float, default=0.70,
                   help="Perzentil-Schwelle: darunter wird nichts gezeichnet")
    p.add_argument("--out", default=None)
    p.add_argument("--serve", action="store_true")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--update-url", default=UPDATE_URL,
                   help="Archiv für den Update-Knopf (GitHub blob- oder raw-Link)")
    p.add_argument("--host", default="127.0.0.1",
                   help="0.0.0.0 macht das Dashboard im LAN erreichbar (Pi!)")
    args = p.parse_args()

    if args.serve:
        globals()["UPDATE_URL"] = args.update_url
        serve(args.db, args.port, args.host)
        return

    con = connect(args.db)
    if args.depth:
        plot_depth(con, args.coin, args.out or f"{args.coin}_depth.png")
    else:
        plot_heatmap(con, args.coin, args.hours,
                     args.out or f"{args.coin}_heatmap.png", args.threshold)
    con.close()


if __name__ == "__main__":
    main()
