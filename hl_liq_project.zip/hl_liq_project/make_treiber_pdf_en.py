#!/usr/bin/env python3
"""Treiber-Dokumentation als PDF (Stand 15.09.2026, Codebasis hl_forecast.py / hl_indikatoren.py / hl_score.py)."""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, KeepTogether)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont("DV", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DVB", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DVI", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf"))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("DV", normal="DV", bold="DVB", italic="DVI", boldItalic="DVB")

INK = colors.HexColor("#1b1f24"); MUTED = colors.HexColor("#57606a"); LINE = colors.HexColor("#d0d7de"); BG = colors.HexColor("#f6f8fa")
S = {
    "h1": ParagraphStyle("h1", fontName="DVB", fontSize=17, leading=22, spaceAfter=8, textColor=INK),
    "h2": ParagraphStyle("h2", fontName="DVB", fontSize=13, leading=17, spaceBefore=12, spaceAfter=5, textColor=INK),
    "h3": ParagraphStyle("h3", fontName="DVB", fontSize=10.5, leading=14, spaceBefore=9, spaceAfter=3, textColor=INK),
    "p": ParagraphStyle("p", fontName="DV", fontSize=9.2, leading=13, spaceAfter=4, textColor=INK, alignment=TA_LEFT),
    "small": ParagraphStyle("small", fontName="DV", fontSize=8, leading=11, textColor=MUTED),
    "f": ParagraphStyle("f", fontName="DV", fontSize=9, leading=13, leftIndent=10, backColor=BG, borderPadding=(3, 4, 3, 4), spaceBefore=2, spaceAfter=5),
    "cell": ParagraphStyle("cell", fontName="DV", fontSize=8.2, leading=10.5, textColor=INK),
    "cellb": ParagraphStyle("cellb", fontName="DVB", fontSize=8.2, leading=10.5, textColor=INK),
}
story = []
P = lambda t, st="p": story.append(Paragraph(t, S[st]))
F = lambda t: story.append(Paragraph(t, S["f"]))


def treiber(name, prior, quelle, berechnung, ereignisse, hinweis=None):
    """Ein Treiber-Abschnitt: Quelle, Berechnung (Formel), Ereignisse, Hinweis."""
    teile = [Paragraph(f"{name} <font color='#57606a' size='8'>— prior {prior}</font>", S["h3"]),
             Paragraph(f"<b>Inputs:</b> {quelle}", S["p"])]
    for b in berechnung:
        teile.append(Paragraph(b, S["f"]))
    teile.append(Paragraph(f"<b>What moves it:</b> {ereignisse}", S["p"]))
    if hinweis:
        teile.append(Paragraph(f"<font color='#57606a'>{hinweis}</font>", S["p"]))
    story.append(KeepTogether(teile))


def tabelle(kopf, zeilen, breiten):
    data = [[Paragraph(k, S["cellb"]) for k in kopf]] + [[Paragraph(str(c), S["cell"]) for c in z] for z in zeilen]
    t = Table(data, colWidths=breiten, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), BG), ("LINEBELOW", (0, 0), (-1, 0), 0.6, LINE),
                           ("LINEBELOW", (0, 1), (-1, -1), 0.25, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4), ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    story.append(t); story.append(Spacer(1, 6))


# =====================================================================================
P("Hyperliquid Liquidation Clusters — The Drivers of the Forecast", "h1")
P("An explanation of every driver: inputs, computation, triggering events. As of 15 September 2026; code base "
  "<i>hl_forecast.py</i>, <i>hl_indikatoren.py</i>, <i>hl_score.py</i>. All formulas are taken from the code. Where a number is a "
  "starting value (prior), it says so — calibration replaces it with measured values. Driver names are given in English with the "
  "German dashboard label in brackets.", "small")
story.append(Spacer(1, 8))

# ---- 1 ------------------------------------------------------------------------------
P("1. How a forecast is produced", "h2")
P("Every 15 minutes the dashboard computes one forecast per coin. Each <b>driver</b> delivers a <b>score</b> between −1 (down) and "
  "+1 (up) and carries a <b>weight</b>. Before any learning the weight is the prior from the table in section 13; once enough "
  "independent cases exist, calibration replaces it per horizon (4 h and 24 h) with a learned value. Scores and weights yield three quantities:")
F("Bias (directional pressure) = Σ<sub>i</sub> score<sub>i</sub> · weight<sub>i</sub> / Σ<sub>i</sub> weight<sub>i</sub>  ∈ [−1, 1], separately for the 4-h and the 24-h track")
F("P(up) = σ( β · Σ<sub>i</sub> score<sub>i</sub> · weight<sub>i</sub> / Σ priors )  with σ(z) = 1/(1+e<super>−z</super>); β is a learned scale (start 1.0, allowed 0.2–4.0). The denominator is constant: the logit is a sum of evidence — a missing driver is a piece of evidence with Bayes factor 1 (contribution zero); fewer active drivers are less evidence (audit v9).")
F("Agreement = share of the weight whose score points in the direction of the bias (used for display and confluence)")
P("The bias steers the <b>path model</b> (section 12): if |bias| > 0.12 a target is chosen — the nearest large liquidation cluster in "
  "the direction of the bias — and the reach comes from the measured touch statistics; otherwise the path runs on the sigma band. The "
  "<b>regime</b> (section 10) widens the band but shifts nothing. The forecast stores scores, weights, P(up) and the path; after 4 h "
  "and 24 h it is scored against the real price.")

# ---- 2 ------------------------------------------------------------------------------
P("2. Calibration — how priors become measured weights", "h2")
P("After h hours every forecast becomes a case: the direction of the real price (up/down) against the drivers' scores at that time. "
  "Neighbouring 15-minute forecasts share almost the same future, so what counts is not the number of windows but <b>n_eff</b> = the "
  "number of separate h-hour blocks. Learning starts at n_eff 40 per horizon; an individual driver is released only once it was active "
  "in n_eff 50 (4 h) or 30 (24 h) blocks.")
F("Model: p<sub>t</sub> = σ( β · Σ<sub>i</sub> w<sub>i</sub> x<sub>i,t</sub> / S ),  S = Σ priors")
F("Loss: logistic error (p<sub>t</sub> − y<sub>t</sub>) plus regularisation λ · Σ (w<sub>i</sub> − prior<sub>i</sub>)<super>2</super>,  λ = 4 / n_eff")
F("Update: w<sub>i</sub> ← clip( w<sub>i</sub> − lr · ∂loss/∂w<sub>i</sub>, 0, 2 · prior<sub>i</sub> ),  β ← clip(β − lr<sub>β</sub> · ∂loss/∂β, 0.2, 4.0); up to 300 rounds or step < 10<super>−4</super>")
P("Reading: with few cases λ pulls the weights towards the prior (nothing is learned from chance); as n_eff grows a weight may move "
  "down to zero (driver muted) or up to twice its prior. A driver with a hit rate near 50 % drifts towards zero — that is the "
  "<b>kill criterion</b>. Per driver the hit rate, Wilson interval and n_eff are shown; the <b>null test</b> (pure noise) must yield "
  "weights at the prior, β near 1 and a 50 % hit rate.")

# ---- 3 ------------------------------------------------------------------------------
P("3. Regime and drift (technical drivers)", "h2")
P("Source: hourly candles of the last 7 days (Hyperliquid <i>bars</i>); daily candles for the moving averages (Binance <i>daily_bars</i>, else HL).", "small")
treiber("200-day MA („MA 200 Tage“)", "0.8", "Daily closes, moving average over 200 days; p<sub>0</sub> = current price.",
        ["d = p<sub>0</sub> / MA200 − 1;  score = clip(d / 0.10, −1, 1) · 0.6"],
        "Any price move relative to the yearly mean: 10 % above the MA saturates at +0.6, 10 % below at −0.6. A trend-following driver — a state, not an event.")
treiber("50-week MA („MA 50 Wochen“)", "0.6", "Weekly closes, average over 50 weeks.",
        ["d = p<sub>0</sub> / MA50W − 1;  score = clip(d / 0.10, −1, 1) · 0.5"],
        "Like the 200-day MA on the weekly scale. Together they describe the long-term regime.")
treiber("60-minute trend („60-min-Trend“)", "0.5", "Hourly candles: return of the last 60 minutes (trend_60m).",
        ["score = clip( r<sub>60min</sub> / 0.01, −1, 1 ) · 0.5"],
        "One percent of movement in an hour saturates. Reacts to any hour with a clear direction; short-term momentum.")
treiber("RSI 14 (1 h)", "0.5", "Relative strength index over 14 hourly candles.",
        ["score = clip( (50 − RSI) / 30, −1, 1 ) · 0.5   (mean reversion: overbought pushes down, oversold supports)"],
        "RSI 80 → −0.5; RSI 20 → +0.5. Works against the 60-minute trend — calibration decides which one carries.")
treiber("7-day drift („7-Tage-Drift“)", "0.4", "Hourly candles of the last 168 h; σ = realised volatility per hour.",
        ["drift = ln( C<sub>now</sub> / C<sub>−168h</sub> ) / 168  (per hour);  score = clip( drift / (0.3 · σ), −1, 1 ) · 0.4"],
        "A weekly drift reaching 30 % of the hourly volatility saturates. A damped trend, normalised by volatility.")

# ---- 4 ------------------------------------------------------------------------------
P("4. Positioning and flow of the accounts (Hyperliquid)", "h2")
P("This is the core of the project: on Hyperliquid every account is readable. The recorder polls ~140,000 addresses for positions, "
  "tracks the top accounts of the leaderboard every 2 minutes and receives every trade of the six coins via WebSocket (fills in real "
  "time). Accounts are classified: <b>directional</b> (one side per coin, real leverage), <b>hedge</b> (many coins, one side, little "
  "leverage), <b>market maker</b>, <b>mixed</b>. Only directional accounts carry a direction.", "small")
treiber("Directional whales („Direktionale Wale“)", "1.2", "Open positions of all whales (≥ 20 M position value) <b>in this coin</b> from the poller (whale_positions); class per coin (one side; hedge and market-maker accounts excluded). Until 15 Sep the coin filter was missing — the driver summed all six coins (found with check_treiber).",
        ["score = ( USD<sub>long</sub> − USD<sub>short</sub> ) / ( USD<sub>long</sub> + USD<sub>short</sub> )"],
        "Every opening, increase, reduction or close of a whale position in the coin. The system's highest prior: the alignment of the large directional accounts.")
treiber("Whale flow 30 min („Wal-Flow 30 min“)", "1.3", "Position changes of the directional whales in the last 30 min (fallback 60 min), buys and sells in USD, number of accounts; z-score against its own history; event signal.",
        ["Condition: gross ≥ 150,000 USD and ≥ 2 accounts, or ≥ 5 M from a single account (then score × 0.7 — size without breadth)",
         "score = ( net / gross ) · clip( |Z| / 2.5, 0.4, 1.0 );  with event signal: score ← score + 0.5 · (sign(score) − score)   (halfway to ±1, monotone, no clipping loss; Stage 1)"],
        "A burst of buying or selling by several whales within half an hour. The <b>event signal</b> (section 11) lifts the score by 50 %.")
treiber("Leaderboard flow 60 min („Leaderboard-Flow 60 min“)", "1.0", "Position changes of the directional top accounts of the leaderboard (snapshots every 2 min → events in lb_events), 60 min (fallback 3 h).",
        ["Condition: gross ≥ 75,000 USD and ≥ 2 accounts, or ≥ 1 M from a single account (then score × 0.7)",
         "score = ( net / gross ) · clip( |Z| / 2.5, 0.4, 1.0 );  with event signal halfway to ±1 (as whale flow)"],
        "Like the whale flow, for the ranking of the most profitable accounts instead of the largest.")
treiber("Smart money (directional) („Smart Money (direktional)“)", "1.0", "Current positions of the leaderboard top 50 in the coin, directional accounts only, net per account (lb_positions).",
        ["net<sub>k</sub> = Σ position value · (+1 long / −1 short) per account;  UL = Σ net > 0,  US = Σ |net < 0|",
         "Condition: ≥ 3 accounts;  score = ( UL − US ) / max( UL + US, 1 )"],
        "Any position change of a profitable directional account in the coin. Alignment rather than flow — like “Directional whales”, but selected by profitability instead of size.")
treiber("Buys/sells 24 h (directional) („Käufe/Verkäufe 24 h“)", "1.0", "Fills of the directional top accounts in the last 24 h (lb_fills, perp and spot), buy side from the field buy.",
        ["Condition: gross ≥ 250,000 USD and ≥ 2 accounts;  score = ( buy − sell ) / ( buy + sell )"],
        "Every fill of a directional top account — since the trade stream in real time, completed with closedPnl/fee/dir by the REST back-fill.")
treiber("Top-20 trend 24 h („Top-20-Trend 24 h“)", "0.6", "Net positioning of the top 20 (lb_trend, hourly): now against 24 h ago.",
        ["Δ = ( net<sub>now</sub> − net<sub>−24h</sub> ) / gross<sub>now</sub>;  score = clip( Δ / 0.5, −1, 1 ) · 0.6"],
        "A shift of the alignment by half the gross value within a day saturates. The inertia of the large accounts.")
treiber("Smart flow 4 h („Smart-Flow 4 h“)", "1.0", "Position steps of all accounts in the last 4 h (whales + leaderboard, de-duplicated), weighted by the account score S ∈ [0,1] from hl_score (class ≥ 0.6 and S > 0 only).",
        ["score = Σ<sub>k</sub> S<sub>k</sub> · direction<sub>k</sub> · √notional<sub>k</sub> / Σ<sub>k</sub> S<sub>k</sub> · √notional<sub>k</sub>   (square root: no single account is the signal)",
         "Condition: ≥ 3 scored accounts, gross ≥ 500,000 USD"],
        "Every position step of an account with a good score. The score itself: 35 % lead (mean 4-h return after its steps, shrunk by n/(n+20)), 25 % edge per turnover, 20 % consistency, 10 % size, 10 % class — recomputed daily, tested weekly against the following week's lead.")
treiber("Counter flow („Gegen-Flow“)", "0.3", "Position steps of accounts with a demonstrably <b>negative</b> lead (α<sub>4h</sub> < 0, n ≥ 20), last 4 h.",
        ["score = − Σ direction<sub>k</sub> · √notional<sub>k</sub> / Σ √notional<sub>k</sub>   (inverted);  condition ≥ 3 accounts"],
        "When the losers trade, the system leans the other way. An experiment with a small prior — if losers trade randomly, calibration parks the driver.")
treiber("Elite positioning („Elite-Positionierung“)", "1.0", "Current positions of the ten best accounts by score (learn.elite) in the coin; leaderboard state before whale state, no double counting. Since 15 Sep an account joins the elite only with <b>evidence</b>: at least 10 steps in the coin, a positive lead (α<sub>4h</sub> > 0), t ≥ 1.0 for that lead, and it must actually be making money — leaderboard 30-day PnL > 0 where available, and the held position at most 3 % under water (profit gate, 21 Sep); and at most 300 bundled trades per day (activity gate, 22 Sep — taker HFT without resting limits escapes the market-maker rule, and hundreds of steps make any tiny lead ‘significant’); only accounts that are <b>directional in this coin</b> are counted (leaderboard group; whales without a leaderboard entry only with a purely directional account-wide class).",
        ["Condition: ≥ 3 countable positions;  share = largest position / ( UL + US );  damper = clip( (1 − share) / 0.5, 0.5, 1 )",
         "score = ( UL − US ) / ( UL + US ) · damper   (if one account holds more than half of the gross value it is no longer a group signal)"],
        "Every position change of an elite account. The purest form of the golden rule: what the best hold — as a group, not as a single account. Check tool: debug entry “Elite-Positionierung prüfen”.")

# ---- 5 ------------------------------------------------------------------------------
P("5. Market microstructure", "h2")
treiber("Taker flow („Taker-Flow“)", "0.7", "Taker buy/sell ratio from Binance (5-min window, live), OKX (5 min), Bybit (last 500 trades) and Crypto.com (last 150 trades); exchanges with a span < 60 s or a ratio ≥ 9 are excluded.",
        ["avg = mean<sub>exchanges</sub> ln( r<sub>exchange</sub> );  score = clip( avg / ln 1.5, −1, 1 ) · 0.7"],
        "Aggressive buys (market orders) against aggressive sells. A ratio of 1.5 : 1 across all exchanges saturates. Log mean so that 2 : 1 and 1 : 2 are symmetric.",
        "Long-term studies (audit v3): no directional predictive power on daily horizons — the prior was deliberately kept, calibration decides.")
treiber("Funding", "0.4", "Current Hyperliquid funding rate per hour (ctx_bars, freshness 15 min).",
        ["score = clip( −f / 0.0002, −1, 1 ) · 0.4   (contrarian: positive funding = longs pay = squeeze risk to the downside)"],
        "Funding of 0.02 %/h saturates at −0.4. Extreme funding works against the crowd.")
treiber("Order book („Orderbuch“)", "0.4", "Hyperliquid order book ±50 bps (book_summary, every 5 s from the WebSocket, freshness 10 min).",
        ["imb = ( bid<sub>50</sub> − ask<sub>50</sub> ) / ( bid<sub>50</sub> + ask<sub>50</sub> );  score = clip( imb / 0.5, −1, 1 ) · 0.4"],
        "Any shift of depth near the price. In mix mode the Binance/Crypto.com books stay out of this driver (they feed the walls in the path model).")
treiber("Capitulation („Kapitulation“)", "0.5", "Realised Binance liquidations of the last 3 days (bnc_liquidations) in 30-minute blocks; side = the liquidated position.",
        ["L<sub>now</sub> = long liquidations of the last two completed half-hour blocks;  avg<sub>L</sub> = mean per block over 3 days",
         "Long burst: L<sub>now</sub> ≥ 4 · avg<sub>L</sub> and ≥ 3 M → score +0.8 (chance of recovery);  short burst analogously → −0.8 (squeeze under way)"],
        "A liquidation cascade — four times the average within an hour. A pure event driver; otherwise absent.",
        "The stream delivered nothing until 14 Sep (Binance had moved its WebSocket URLs); the driver therefore only starts now at n_eff 0.")

# ---- 6 ------------------------------------------------------------------------------
P("6. Coinbase spot (demand without leverage)", "h2")
P("Source: service hl-coinbase — minute candles with taker side (cb_bars, 180 days), order book every 30 s (cb_book). Freshness: 30 min.", "small")
treiber("Coinbase premium („Coinbase-Prämie“)", "0.8", "Spot price against the perp price in basis points; resting level and dispersion from its own minute series → z-score.",
        ["premium = ( spot / perp − 1 ) · 10<super>4</super>;  Z = ( premium − mean ) / dispersion;  score = clip( Z / 2.5, −1, 1 )"],
        "A sudden swelling of the premium (US demand), not its permanent level — the z-score measures the distance from its own resting level.")
treiber("Spot taker flow („Spot-Taker-Flow“)", "0.7", "Aggressive buys and sells of the last 60 minutes (rolling) on Coinbase; z-score against history; gross ≥ 200,000 USD.",
        ["score = ( net / gross ) · clip( |Z| / 2.5, 0.4, 1.0 )"],
        "A burst of real, paid-for spot demand or supply.")
treiber("Spot order book („Spot-Orderbuch“)", "0.4", "Coinbase depth ±25 bps; condition bid + ask ≥ 100,000 USD.",
        ["imb = ( bid<sub>25</sub> − ask<sub>25</sub> ) / ( bid<sub>25</sub> + ask<sub>25</sub> );  score = clip( 2 · imb, −1, 1 )"],
        "A shift of spot depth. The weakest of the three Coinbase quantities.")

# ---- 7 ------------------------------------------------------------------------------
P("7. ETF flows (BTC and ETH only)", "h2")
treiber("ETF flows („ETF-Flows“)", "0.6", "Daily net flows of the spot ETFs (Farside), last day and the sum of the last 5 days in M USD.",
        ["Same signs (last day and 5-day sum positive): score = clip( Σ<sub>5d</sub> / 1000, 0.2, 1 ) · 0.6;  both negative: mirror image; otherwise 0"],
        "A sustained inflow or outflow over several days. One billion in five days saturates.")
treiber("ETF momentum („ETF-Momentum“)", "0.5", "Daily flows from etf_flows (stored without limit); freshness: latest day at most 4 days old; ≥ 12 days required.",
        ["score = tanh( ( mean<sub>3d</sub> − mean<sub>10d</sub> ) / σ<sub>60d</sub> )"],
        "Acceleration of the flows: the last three days against the last ten, normalised by the dispersion. The studies see the effect on day 3–4.")

# ---- 8 ------------------------------------------------------------------------------
P("8. History", "h2")
treiber("Analogue search („Analog-Suche“)", "0.8", "30-minute candles over 3 years; features of the current pattern (returns, volatility, RSI, position relative to MAs) against history; the n most similar moments and their following 24 h.",
        ["p<sub>up</sub> = share of analogues with the price above the start after 24 h;  base = unconditional up-share of the history",
         "score = clip( ( p<sub>up</sub> − base ) · 4, −1, 1 ) · 0.8;  plus a Wilson interval on n"],
        "Not an event but similarity: when the market looked like this, did it go up more often than usual afterwards? Measured against the base rate so that the upward drift of history cannot fake anything.")

# ---- 9 ------------------------------------------------------------------------------
P("9. Indicators from audit report v3 (since 14 Sep 2026)", "h2")
P("Small priors, contrarian where the long-term studies support it. All percentiles as midrank (ties count half); a constant reference series yields no rank.", "small")
treiber("OI overheating („OI-Überhitzung“)", "0.3", "Open interest: Binance (bnc_metrics, 10 min) or Hyperliquid (ctx_bars), percentile over 90 days; only with ≥ 14 days of series and the latest value ≤ 6 h old.",
        ["o = clip( ( pct − 0.90 ) / 0.10, 0, 1 );  score = −0.6 · o   (active from the 90th percentile only)"],
        "A build-up of open interest into the top ten percent of its own history. Evidence: the following week has a wider range, more drawdowns, 44 % instead of 53 % up — hence a slight contrarian tilt; at the same time a regime flag.")
treiber("Crowding extreme („Crowding-Extrem“)", "0.5", "Net alignment of the top 20 (lb_trend, hourly, up to 365 days): crowd = (USD<sub>long</sub> − USD<sub>short</sub>) / (USD<sub>long</sub> + USD<sub>short</sub>); percentile of its own history; ≥ 14 days required.",
        ["pct ≤ 0.10: score = ( 0.10 − pct ) / 0.10   (up to +1);   pct ≥ 0.90: score = −0.5 · ( pct − 0.90 ) / 0.10   (down to −0.5);   otherwise 0"],
        "The top accounts as short-heavy as rarely before (bottom decile) → contrarian up, strong; as long-heavy as rarely before → contrarian down, mild. Asymmetric as in the study (+6.9 %/30 d at the bottom).")
treiber("Crowding trend 7 d („Crowding-Trend 7 T“)", "0.4", "The same series: change of alignment over 7 days, normalised by the dispersion of such 7-day changes (≥ 21 days required).",
        ["score = tanh( Δ<sub>7d</sub> / σ<sub>Δ7d</sub> ) · 0.8"],
        "A reshuffle of the large accounts over the week — the trend of positioning.")
treiber("Vol spike reversion („Vol-Spike-Reversion“)", "0.3", "Parkinson volatility from hourly high/low of the last 24 h against daily high/low of the 20 days before.",
        ["σ<sub>P</sub> = √( mean ln(H/L)<super>2</super> / (4 ln 2) );  ratio = σ<sub>24h</sub> · √24 / σ<sub>20d</sub>",
         "spike = clip( ( ratio − 1.5 ) / 1.5, 0, 1 );  score = − sign( r<sub>24h</sub> ) · spike, if |r<sub>24h</sub>| > 0.5 %"],
        "A volatility burst (from 1.5× the norm) after a clear move → tendency to snap back. The ratio is also the band multiplier (0.7–1.6).")
treiber("Funding spread („Funding-Spread“)", "0.4", "HL funding (hourly rate × 8) against the mean of the 8-h rates of Bybit, OKX (ext_metrics) and Binance (bnc_metrics), joined hourly; percentile over 30 days; ≥ 3 days required.",
        ["spread = f<sub>HL,8h</sub> − mean( f<sub>other,8h</sub> );  score = −clip( ( pct − 0.5 ) · 2, −1, 1 ) · (1.0 if |spread| ≥ 0.01 %, else 0.5)"],
        "Hyperliquid more expensive than the other exchanges (carry arbitrage: short HL, long elsewhere) → contrarian down; the reverse up. According to the literature, basis/carry is the strongest of the signals examined.")
treiber("Liquidation pressure, 3 exchanges („Liquidationsdruck (3 Börsen)“)", "0.5", "Realised liquidations from Binance (stream), Bybit (stream, complete), OKX (every 2 min) and Hyperliquid (inferred), 30 days; side = the liquidated position.",
        ["total<sub>2h</sub> = longs + shorts of the last two hours;  pct = rank against rolling 2-h sums of the 30 days",
         "imb = ( longs − shorts ) / total;  intens = clip( ( pct − 0.90 ) / 0.10, 0, 1 );  score = imb · intens"],
        "A liquidation wave in the top ten percent: long liquidations → capitulation, chance of recovery (+); short liquidations → squeeze, risk of a setback (−). The intensity is also a regime flag.")

# ---- 10 -----------------------------------------------------------------------------
P("10. Regime — what widens the band but has no direction", "h2")
P("The long-term studies show that open interest, volatility, liquidation intensity and the variance compression of the taker flow "
  "predict <i>movement</i>, not direction. They therefore enter the forecast band as a multiplier, never the bias.")
F("Band multiplier = clip( ratio<sub>vol</sub>, 0.7, 1.6 ) · (1 + 0.25 · o<sub>OI</sub>) · (1 + 0.25 · intens<sub>liq</sub>) · (1 + 0.20 · compr), capped 0.7–2.2")
F("Variance compression: variance of the 10-s balances (buy − sell) · price per hour (bars10), the last completed hour against the distribution of the 30 days; compr = clip( ( 0.10 − pct ) / 0.10, 0, 1 )")
P("Reading: an unusually calm taker flow (bottom decile) is the only placebo-tested regularity <i>before</i> cascades — it raises the risk but names no direction. The regime line sits above the driver table.")

# ---- 11 -----------------------------------------------------------------------------
P("11. Event signals — when a flow is exceptional", "h2")
P("Whale flow and leaderboard flow carry an event signal that lifts the score by 50 %. It does not fire on a z-score (which, on "
  "sparsely populated hourly series with many zeros, caught 42 % of all hours) but on <b>rank</b>:")
F("Event if |net<sub>hour</sub>| ≥ 98th percentile of the last 14 days (excluding the current hour)  and  |net| ≥ floor (whales 2 M, leaderboard 500,000 USD)  and  breadth ≥ 3 accounts")
P("A percentile fires by construction at a fixed rate (~2 % of hours); floor and breadth prevent trifles from becoming events in quiet "
  "weeks. Measured on 13 Sep: the rank caught all three cases of the old rule and found a fourth (−54 M from 12 accounts).")

# ---- 12 -----------------------------------------------------------------------------
P("12. Path model — magnets, walls, stops", "h2")
P("The path connects direction and liquidation clusters. Candidates are Hyperliquid liquidation clusters from the heatmap (short clusters above, long clusters below the price):")
F("Magnet if notional ≥ max( 10 % of the HL hourly volume, 5 M )   — MAGNET_VOL_ANTEIL = 0.10, MAGNET_MIN_USD = 5 M (the same function in forecast and statistics)")
F("Wall (brakes): limit/TP orders from HL + Binance book + Crypto.com book per 0.25 % level, ≥ max( 50 % of the fused hourly volume, 5 M );  stop trigger: HL trigger orders ≥ max( 25 % HL volume, 5 M )")
F("Target = nearest magnet in the direction of the bias (at |bias| ≤ 0.12: no target, sigma band);  reach = 0.5 + 0.5 · touch rate of the distance class (0–1 %, 1–2 %, 2–3 %) from the magnet statistics; overshoot and retrace after the touch from the same statistics")
F("Band: σ<sub>hour</sub> · time profile(weekday, hour) · band multiplier, accumulated over the horizon")
P("The <b>magnet statistics</b> measure from the heatmap snapshots: touch rate within 12 h against a placebo level at the same distance on "
  "the other side (lift), Wilson interval on n_eff (separate 12-h blocks), by distance and by size class. The <b>magnet variants</b> "
  "(0.5–1 % and 1–2 %, 4/8/12/24 h) test, following Cho et al., Osler and Avellaneda/Lipkin, whether clusters attract: Δ touch − placebo "
  "with z, excess movement with t, “closer” against placebo, conditional 15-minute probability. Only with that evidence will the path "
  "approach a cluster at neutral bias as well.")

# ---- 13 -----------------------------------------------------------------------------
P("13. All drivers at a glance", "h2")
zeilen = [
    ("200-day MA (MA 200 Tage)", "0.8", "clip(d/0.10)·0.6", "position vs. yearly mean"),
    ("50-week MA (MA 50 Wochen)", "0.6", "clip(d/0.10)·0.5", "position vs. weekly mean"),
    ("60-minute trend (60-min-Trend)", "0.5", "clip(r60/0.01)·0.5", "hourly momentum"),
    ("RSI 14 (1 h)", "0.5", "clip((50−RSI)/30)·0.5", "mean reversion"),
    ("7-day drift (7-Tage-Drift)", "0.4", "clip(drift/(0.3σ))·0.4", "damped weekly trend"),
    ("Directional whales (Direktionale Wale)", "1.2", "(L−S)/(L+S), per coin", "positions ≥ 20 M, directional"),
    ("Whale flow 30 min (Wal-Flow 30 min)", "1.3", "net/gross·clip(|Z|/2.5,0.4,1)·event", "position changes of whales"),
    ("Leaderboard flow 60 min", "1.0", "as whale flow", "position changes of top accounts"),
    ("Smart money (directional)", "1.0", "(UL−US)/(UL+US)", "alignment of top 50, directional"),
    ("Buys/sells 24 h (Käufe/Verkäufe 24 h)", "1.0", "(B−S)/(B+S)", "fills of directional top accounts"),
    ("Top-20 trend 24 h", "0.6", "clip(Δ/0.5)·0.6", "reshuffle of the top 20"),
    ("Smart flow 4 h (Smart-Flow 4 h)", "1.0", "Σ S·dir·√N / Σ S·√N", "flow weighted by account score"),
    ("Counter flow (Gegen-Flow)", "0.3", "−Σ dir·√N / Σ √N", "losers inverted (experiment)"),
    ("Elite positioning (Elite-Positionierung)", "1.0", "(UL−US)/(UL+US)·damper, directional in coin", "the ten best accounts as a group"),
    ("Taker flow (Taker-Flow)", "0.7", "clip(mean ln r / ln 1.5)·0.7", "4 exchanges, aggressive orders"),
    ("Funding", "0.4", "clip(−f/0.0002)·0.4", "contrarian at extreme funding"),
    ("Order book (Orderbuch)", "0.4", "clip(imb50/0.5)·0.4", "HL depth ±50 bps"),
    ("Capitulation (Kapitulation)", "0.5", "±0.8 on burst ≥ 4× avg and ≥ 3 M", "liquidation cascade (Binance)"),
    ("Coinbase premium (Coinbase-Prämie)", "0.8", "clip(Z/2.5)", "swelling of the spot premium"),
    ("Spot taker flow (Spot-Taker-Flow)", "0.7", "net/gross·clip(|Z|/2.5,0.4,1)", "paid-for spot demand"),
    ("Spot order book (Spot-Orderbuch)", "0.4", "clip(2·imb25)", "Coinbase depth ±25 bps"),
    ("ETF flows (ETF-Flows)", "0.6", "clip(Σ5d/1000, 0.2, 1)·0.6 on matching signs", "sustained in-/outflow"),
    ("ETF momentum (ETF-Momentum)", "0.5", "tanh((m3−m10)/σ60)", "acceleration of flows"),
    ("Analogue search (Analog-Suche)", "0.8", "clip((p_up−base)·4)·0.8", "similar moments of history"),
    ("OI overheating (OI-Überhitzung)", "0.3", "−0.6·clip((pct−0.9)/0.1)", "OI in the top decile"),
    ("Crowding extreme (Crowding-Extrem)", "0.5", "+1…0 bottom / 0…−0.5 top", "top-20 alignment extreme"),
    ("Crowding trend 7 d (Crowding-Trend 7 T)", "0.4", "tanh(Δ7d/σ)·0.8", "reshuffle over the week"),
    ("Vol spike reversion (Vol-Spike-Reversion)", "0.3", "−sign(r24)·clip((ratio−1.5)/1.5)", "vol burst after a move"),
    ("Funding spread (Funding-Spread)", "0.4", "−clip((pct−0.5)·2)", "HL funding vs. 3 exchanges"),
    ("Liquidation pressure (Liquidationsdruck)", "0.5", "imb·clip((pct−0.9)/0.1)", "liquidation wave, 4 sources"),
]
tabelle(["Driver (dashboard label)", "Prior", "Score (short form)", "What moves it"], zeilen, [50 * mm, 12 * mm, 60 * mm, 53 * mm])
P("Learned weights, hit rate, Wilson interval and n_eff per driver are shown live in the dashboard's driver table; “learned” means the weight deviates from the prior.", "small")

# ---- 14 -----------------------------------------------------------------------------
P("14. Glossary", "h2")
gl = [
    ("clip(x, a, b)", "x limited to the interval [a, b]; without arguments [−1, 1]."),
    ("Prior", "Starting weight of a driver before learning; also the centre of the regularisation."),
    ("n_eff", "Number of independent cases = separate horizon blocks, not the number of 15-min windows."),
    ("Z-score", "Distance from the series' own mean in units of its dispersion (own history)."),
    ("Percentile / midrank", "Share of smaller values in the reference series, ties count half; a constant series → no rank."),
    ("Wilson interval", "Confidence interval of a rate that does not become too narrow at small n; here on n_eff."),
    ("Brier skill", "Quality of the probability against the base rate “always up”; > 0 is better than the base rate."),
    ("Placebo", "Comparison level at the same distance on the other side of the price at the same time; lift = touch rate / placebo."),
    ("directional", "Account with one side per coin and real leverage; hedge, market-maker and mixed accounts carry no direction."),
    ("Event signal", "Rank ≥ 98 % of the last 14 days + floor + breadth ≥ 3 accounts; lifts flow scores by 50 %."),
    ("Regime", "Band multiplier from vol ratio, OI overheating, liquidation intensity, variance compression; no direction."),
    ("Kill criterion", "A driver whose hit rate stays at 50 % drifts towards weight zero in calibration."),
]
tabelle(["Term", "Meaning"], gl, [40 * mm, 135 * mm])

# =====================================================================================
def kopf_fuss(canvas, doc):
    canvas.saveState(); canvas.setFont("DV", 7.5); canvas.setFillColor(MUTED)
    canvas.drawString(18 * mm, 10 * mm, "Hyperliquid Liquidation Clusters · Forecast Drivers · as of 15 Sep 2026")
    canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


doc = SimpleDocTemplate("/mnt/user-data/outputs/Forecast_Drivers_2026-09-15.pdf", pagesize=A4,
                        leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=16 * mm,
                        title="Forecast Drivers — Hyperliquid Liquidation Clusters", author="hl_liq_project")
doc.build(story, onFirstPage=kopf_fuss, onLaterPages=kopf_fuss)
print("PDF geschrieben")
