# Konzept: „Aktive Profis" — die 20 profitabelsten aktiven Trader mit ihren Trades

**Projekt:** hl_liq_project · **Stand:** 22.09.2026 · **Status:** Konzept vor Umsetzung, zur externen Prüfung
**Entscheidungen des Nutzers (22.09.):** Korrektur = Rückgang ≥ 2 % binnen 12 h · Trades gebündelt je Minute
· Qualifikation über 7 Tage · Kandidatenpool: Kontowert ≥ 1 Mio USD und Tagesumsatz ≥ 500k · Perp **und** Spot.
**Antworten auf die offenen Fragen (22.09., Nutzer):** Entry-Lift zusätzlich (erkennt gute Einstiege) ·
Bündelung je Minute und Richtung (Entscheidung Assistent, siehe 5) · Bot = mindestens alle 4 Stunden ein
Trade über 7 Tage (kein Mensch schläft weniger) · Rang nach **ROI** (Gewinn 12 h relativ zum Kontowert) ·
Pool-Hysterese in zwei Etappen: 7 Tage zu Beginn, später 30 Tage.

> **Stand 30.09.2026 (Version 23.38):** Die geltenden Regeln der Darwin-Liste stehen in `hl_profis.py` (Kopf) und in
> UEBERGABE 3ζ/3η: Regeln v3 -- Aufnahme streng (Glück ≤ 1 % über 14 Tage, Vorsprung ≥ 10 Punkte, Gewinn 7 T und 30 T > 0,
> 2–150 Trades/Tag), Verbleib großzügig (Glück ≤ 50 %, Gewinn 30 T > 0), Abstieg nach 3 Tagen in Folge ohne Verbleib --
> diese Schonung nur für Konten, die die strenge Aufnahme bestanden haben (jeder Weg auf die Liste verlangt sie).
> Dieses Konzept beschreibt den Ausgangspunkt vom 22.09.
>
> **Bewertung 06.10.2026 (U136, UEBERGABE 3δδ):** Aufnahme bei Glück 3 % statt 1 %? Im Pool vom 06.10. (69 geprüfte Konten)
> erwartet der Zufall bei 3 % 1,2 Aufnahmen, beobachtet sind 2; zwischen 1 und 3 % kein Hinweis auf Können. Simulation der
> Regeln v3: Zufallsmitglieder 1,9 → 4,9, Könner nur besser abgedeckt, wenn sie selten sind. Empfehlung: 1 % lassen,
> Beinahe-Aufnahmen im Schatten vorwärts verfolgen; Entscheidung beim Nutzer. Eine geänderte Aufnahme wäre Regeln v4 mit
> neuer Labor-Kennung (`liste=4`; heute gilt `liste=3`).
>
> **Seit 23.57 (Nutzer 07.10.: „ja“):** Schatten der Darwin-Liste gebaut und vorab festgelegt, Abschnitt 11. Die Aufnahme bleibt bei
> Glück ≤ 1 %; über eine Lockerung entscheidet das Urteil am 18.11.2026.

---

## 0. Ziel in einem Satz

Eine Rangliste der 20 profitabelsten **aktiven** Trader — aktiv heißt: mindestens 2 (seit 23.31; vorher 5) gebündelte Trades am [seit 23.32 Timing-Qualifikation über alle Ein- und Ausstiege: mindestens 4, Glückswahrscheinlichkeit ≤ 5 %]
Tag, und nachweislich vor Korrekturen aus Positionen heraus —, mit ihren letzten fünf Trades, einer
[bot trader]-Marke bei 24-h-Handel, Rangfolge alle 12 Stunden nach dem Gewinn der letzten 12 Stunden.

## 1. Was die Liste NICHT sein soll

- Keine Liste der größten Gewinner nach Betrag (das ist das Leaderboard; dort sitzen passive Halter und Vaults).
- Keine Liste nach Kontowert (Größe ist Filter, nicht Rang).
- Kein Treiber der Prognose — vorerst reine Beobachtung. Die Elite des Treibers wird erst nach
  einer Beobachtungszeit auf diese Liste umgestellt (eigene Entscheidung, siehe 8).

## 2. Datenquellen (alles bereits erhoben)

| Bedarf | Quelle | Stand |
|---|---|---|
| Kontowert, Tagesumsatz, PnL-Fenster aller Konten | stündliche Leaderboard-Datei (`fetch_leaderboard`, ~40 MB) — heute wird nur die Spitze (75) ausgewertet | vorhanden, Auswertung zu erweitern |
| Fills (Zeit, Coin, Seite, Betrag, Kurs) | Trade-Stream (`users` je Trade) — kostenlos, heute gefiltert auf 75 Konten (`fill_konten`) | vorhanden, Filter zu erweitern |
| closedPnl, fee, Open/Close je Fill | REST `userFillsByTime` (Gewicht 20 je Konto und Seite) | vorhanden (Nachtrag), Pool zu erweitern |
| Positionen (Seite, Größe, uPnL) | Leaderboard-Zyklus (75, alle 2 min) · Poller (Wale, Stufen nach Größe) | vorhanden; Pool-Konten müssen in den Poller (Stufe nach Umsatz) |
| Kurs für Korrektur-Prüfung | `bars` (Minutenkerzen), `daily_bars` | vorhanden |
| Kontowert der Wale | in `clearinghouseState.marginSummary.accountValue` enthalten, heute nicht gespeichert | kleine Recorder-Ergänzung |

## 3. Kandidatenpool (Phase 0 + 1)

**Phase 0 — Zählen, nichts ändern.** Werkzeug `check_pool.py`: liest die letzte Leaderboard-Datei und
druckt die Verteilung: Konten nach Kontowert (≥ 1 / 5 / 20 Mio) × Tagesumsatz (≥ 100k / 500k / 5 Mio),
dazu ROI-Verteilung des Pools. Erwartung: einige tausend über 1 Mio, davon 300–800 mit ≥ 500k Umsatz.
Erst mit dieser Zahl wird über Speicher und REST-Budget entschieden (Deckel: 500 Konten nach Umsatz).

**Phase 1 — Pool führen.** Tabelle `pool_accounts (addr, seit, account_value, vlm_1d, vlm_7d, pnl_7d,
roi_7d, letzte_pruefung)`, stündlich aus der Leaderboard-Datei aktualisiert; Aufnahme bei Kontowert ≥ 1 Mio
und vlm_1d ≥ 500k, Verbleib **7 Tage** nach dem letzten Erfüllen (Hysterese; Etappe 2 nach Beobachtung:
30 Tage — Parameter `POOL_HYSTERESE_TAGE`, kein Umbau).

### 3.1 Ergebnis Phase 0 (22.09., echte Leaderboard-Datei)

46.651 Konten; 2.990 mit Kontowert ≥ 1 Mio; **Pool 545** (≥ 1 Mio und ≥ 500k Tagesumsatz), keine
Vaults erkennbar; ROI 7 T Median +7,7 % (Bullenwoche), 69 % positiv; Median-Kontowert 3,0 Mio,
Umschlag Median 4,2×/Woche, 37 Konten unter 0,5× (Halter); Überlappung mit der Top-75-Auswahl 35
→ rund 510 neue Konten. Die 30 umsatzstärksten sind fast alle Market Maker (Umschlag 100–1.300×,
ROI um null oder negativ). **Konsequenzen:** (a) kein Deckel nach Umsatz — alle 545 (Deckel 600);
(b) Vielhandler-Regel im Speicher von Anfang an: Rohfills 14 T nur bis 500 Fills/Tag, darüber
Stundenaggregat plus rohe letzte 24 h für die Anzeige; kein REST-Nachtrag für Vielhandler (Drei-
Seiten-Regel), ihr Gewinn aus Hyperliquids Tagesfenster; (c) **Ausschluss ab 300 gebündelten
Trades/Tag** (Entscheidung Nutzer 22.09.) — unterhalb liegt aktives, oberhalb maschinelles Handeln;
die Bot-Marke (≤ 4 h Abstand) bleibt für die, die darunter liegen. `check_pool.py --max-trades 300`
rechnet aus den Fills der überlappenden Konten die Beziehung Umschlag → Trades/Tag auf den Pool hoch;
die echte Zahl liefern die Stream-Fills nach 24 h in Phase 1.

### 3.2 Hochrechnung (22.09., zweiter Lauf) und Grenze 150

Die Beziehung Umschlag → Trades/Tag existiert praktisch nicht (Smimen: 116× Umschlag, 23 Trades/Tag;
0x9321: 5,5×, 384 Trades/Tag) — Umschlag misst Größe, nicht Aktivität. Von 33 gemessenen Konten lagen
2 über 300 Trades/Tag, 3 unter 5. **Entscheidung Nutzer: Grenze 150 gebündelte Trades/Tag**
(`POOL_MAX_TRADES_TAG`). Die echte Verteilung liefert Phase 1 (Abschnitt 4) über `check_pool.py`, Block 2b.

### 3.3 Erste 23 Stunden Phase 1 (22.09., 20:48)

669 Konten in der Pool-Tabelle (472 erfüllen die Aufnahme aktuell, der Rest bleibt per Hysterese);
Stundenaggregat deckt 23 von 24 h. **241** Konten mit Fills, davon **124 mit 5–150 gebündelten
Trades/Tag** (Median 7) und 19 über 150 (die meisten inzwischen gesperrt); **428 ohne Fills** — sie
handeln andere Coins: der Trade-Stream ist nur für die sechs verfolgten Coins abonniert. Daraus die
Präzisierung: **Aktivität = gebündelte Trades/Tag auf den verfolgten Coins.** Für Phase 2: Gesperrte
(`konto_status`) ausschließen; Anzeige „669 (472 aktuell)".

## 4. Erfassung je Pool-Konto

**Phase 1 umgesetzt (22.09., Version 2026-09-22.7):** `pool_accounts` wird stündlich aus der
Leaderboard-Datei fortgeschrieben (Hysterese 7 T, Deckel 600 nach Wochengewinn, neue Konten kommen ins
Adressverzeichnis); `fill_konten` = Auswahl ∪ Pool (Stream-Fills, 0 Gewicht; Richtung aus der Position
abgeleitet); Poller-Stufe „Pool" (alle 10 min, auch ohne Position); Kontowert (`accountValue`) in
`addresses.account_value`; `pool_fills_hourly` (je Konto, Stunde, Coin, Markt: gebündelte Trades,
Fills, Umsätze, closedPnl, Gebühren) für die letzten 24 abgeschlossenen Stunden je Fill-Lauf neu
berechnet; Rohfills 14 Tage, Vielhandler (> 500 Fills/Tag) nur 1 Tag. Proben: Aufnahme/Hysterese/
Deckel, Poller-Stufe, Bündelung (12 Fills in einer Minute + 3 in einer anderen = 2 Trades).

- **Stream-Fills** für alle Pool-Konten (`fill_konten` = Leaderboard-Auswahl ∪ Pool). Gewicht: 0.
  Richtung Open/Close aus der bekannten Position abgeleitet (vorhandene Logik), closedPnl per REST.
- **REST-Nachtrag** closedPnl/fee/dir: alle 12 h je Pool-Konto (Rang 3, hinter allem; 20 Gewicht je
  Konto → 500 Konten = 10.000 Gewicht je 12 h ≈ 9 min Budget), mit der Vielhandler-Regel (ab 3 vollen
  Seiten nur noch täglich; Bots liefern der Stream).
- **Positionen**: Pool-Konten in den Poller mit eigener Stufe „Pool" (alle 10 min; bei ≥ 20 Mio wie Wale).
  Kontowert (`accountValue`) wird bei jeder Abfrage in `addresses` geschrieben.
- **Aggregat** `pool_fills_hourly (addr, stunde, coin, n_trades_gebuendelt, buy_usd, sell_usd, closed_pnl,
  fee)`, unbegrenzt — Rohfills bleiben 14 Tage (heute 3).

## 5. Bewertung (täglich, je Konto, aus 7 Tagen)

| Größe | Definition | Schwelle |
|---|---|---|
| **Trades/Tag** | gebündelt: Zahl der Minuten mit Fills je Richtung, gemittelt über 7 Tage | ≥ 5 (Pflicht) |
| **Gewinn 7 T** | Σ closedPnl (7 T) + (uPnL jetzt − uPnL vor 7 T); Perp und Spot | > 0 (Pflicht) |
| **Exit-Lift** | für jedes Schließen/Reduzieren einer Long-Position: Rückgang ≥ 2 % binnen 12 h danach? Anteil solcher Fälle minus Anteil an zufälligen Zeitpunkten desselben Zeitraums (Placebo, 200 Ziehungen); spiegelbildlich für Shorts (Anstieg ≥ 2 %). Mit n_eff (getrennte 12-h-Blöcke) und t | > 0 und t ≥ 1 (Pflicht) |
| **Entry-Lift** | für jedes Eröffnen/Aufstocken einer Long-Position: Anstieg ≥ 2 % binnen 12 h danach? Anteil minus Placebo; spiegelbildlich für Shorts (Rückgang ≥ 2 %). n_eff, t wie oben | Anzeige und Rangbonus (siehe unten); Pflicht ist nur der Exit-Lift — wer gut einsteigt, aber nie reagiert, ist Halter |
| **Reaktion gesamt** | Exit-Lift und Entry-Lift getrennt ausgewiesen; die Karte zeigt beide mit t | Anzeige |
| **Reaktionszeit** | Median der Minuten zwischen einer Bewegung ≥ 1 % in 15 min und dem nächsten Trade des Kontos | Anzeige |
| **Bester Coin** | Coin mit höchstem Σ closedPnl (7 T) | Anzeige |
| **[bot trader]** | über 7 Tage ist der **längste Abstand zwischen zwei Trades ≤ 4 h** (kein Mensch schläft weniger). Zusatzinfo auf der Karte: Regelmäßigkeit der Abstände (Variationskoeffizient) und Stundenabdeckung | Marke, kein Ausschluss |
| **Kontowert** | `accountValue` (Perp) + Spot-Guthaben, sofern erfasst | ≥ 1 Mio (Pflicht) |

Ausschluss ausdrücklich: Konten mit < 5 Trades/Tag (passive Halter), Market-Maker-Muster (≥ 5 ruhende
Kauf- und ≥ 5 Verkaufs-Limits, vorhandene Klassifikation), Vaults (Leaderboard-Kennzeichen).

## 6. Rangfolge (alle 12 h) und Anzeige

- **Rang** unter den Qualifizierten nach **ROI 12 h** = [Σ closedPnl (12 h) + Δ uPnL (12 h)] / Kontowert zu
  Beginn des Fensters (Entscheidung Nutzer: relativ, nicht absolut — sonst gewinnen die Größten).
  Qualifikation (Abschnitt 5) über 7 Tage, Rang über 12 Stunden — so bleibt der Pool geprüft, und nur
  die Reihenfolge bewegt sich. Die 12-h-Zahl allein wäre Rauschen (eine Position dominiert).
  Der Kontowert im Nenner ist der einzahlungsbereinigte Wert zu Fensterbeginn (Kontowert − Σ closedPnl
  seither, aus `lb_stats_hist` bzw. `addresses`), damit eine Einzahlung den ROI nicht drückt.
- **Karte je Trader** (20): Label/Adresse, Kontowert, Gewinn 12 h · 7 T, Trades/Tag, Exit-Lift (t),
  Reaktionszeit, bester Coin, aktuelle Positionen, Marke [bot trader], Rang-Änderung seit dem letzten Lauf.
  Darunter die **letzten 5 Trades**: Zeit, Coin (Perp/Spot), long/short, open/close/reduce, Betrag, Kurs,
  closedPnl (wenn nachgetragen), „seither" aus Sicht des Traders.
- Trades aktualisieren sich live (Stream); die Rangfolge alle 12 h (00:00/12:00 UTC), mit Stempel.
- Debug-Eintrag „Aktive Profis prüfen": Pool-Größe, Qualifikationsquoten, Exit-Lift-Verteilung, Placebo.

## 7. Prüfungen vor dem Vertrauen

- **Nulltest Exit-Lift:** Auf Rauschen (zufällige Schließzeitpunkte) muss der Lift im Mittel null sein; mit
  eingebauter Kante (Schließen kurz vor konstruierten Rückgängen) klar positiv. Teil des Selbsttests.
- **Bot-Heuristik:** Probe mit einem künstlichen 24-h-Muster (Marke) und einem Tagesmuster (keine Marke).
- **Bündelung:** Probe, dass 20 Teil-Fills einer Minute als ein Trade zählen.
- **Placebo-Ziehungen** je Konto aus demselben 7-Tage-Fenster, damit Volatilität nicht als Können gilt.

## 8. Risiken und Grenzen

- Unterkonten: große Trader verteilen Kapital; ein Teil ihrer Aktivität bleibt unsichtbar.
- Spot-Guthaben: `spotClearinghouseState` ist ein eigener Aufruf (Gewicht 2); für den Kontowert wird es
  nur für die 20 angezeigten Konten geholt.
- Der Exit-Lift misst Timing beim Aussteigen; ein Trader, der nie aussteigt, hat keinen (→ unqualifiziert,
  gewollt). Ein Trader mit wenigen Exits hat kleines n_eff → t < 1 → unqualifiziert, bis der Beleg reicht.
- Pool-Größe unbekannt bis Phase 0; Deckel 500 Konten nach Umsatz.
- Zeitzonen: Bot-Heuristik in UTC; ein Mensch in Asien handelt nachts UTC — die Stundenabdeckung
  (≥ 20 von 24) verlangt beide Tageshälften, das trennt.

## 9. Aufwand und Reihenfolge

| Phase | Inhalt | Gewicht/Tag | Aufwand |
|---|---|---|---|
| 0 | `check_pool.py`: Pool zählen (nichts ändern) | 0 | klein |
| 1 | Pool-Tabelle, Stream-Fills für den Pool, Kontowert der Wale, Rohfills 14 T, Stundenaggregat | 0 | mittel (Recorder) |
| 2 | Bewertung: Bündelung, Gewinn 7 T/12 h, Exit-Lift mit Placebo, Reaktionszeit, Bot-Marke, bester Coin; Nulltest | REST-Nachtrag ~10.000 je 12 h (Rang 3) | mittel (neues Modul `hl_profis.py`) |
| 3 | Dashboard-Abschnitt mit 20 Karten, 12-h-Stempel, Debug-Eintrag; Töne bei Trades der 20 (optional) | 0 | mittel |
| später | Elite des Treibers auf diese Liste umstellen — nach 4 Wochen Beobachtung, eigene Entscheidung | — | klein |

## 10. Offene Fragen an das Audit

1. ~~Exit-Lift allein?~~ — entschieden: Entry-Lift zusätzlich (Anzeige, Rangbonus); Pflicht bleibt der Exit-Lift.
2. ~~Bündelung~~ — entschieden: je Minute und Richtung. Begründung: Ein Auftrag erzeugt oft 5–20 Teil-Fills in
   derselben Minute; die Bündelung je Minute zählt ihn als einen Trade, ohne dass die Auftrags-ID gespeichert
   werden muss, und entspricht der Darstellung in der Trade-Tabelle. Zwei Aufträge in derselben Minute und
   Richtung zählen als einer — ein vernachlässigbarer Fehler gegenüber dem Vielfachen durch Teil-Fills.
3. ~~Bot-Heuristik~~ — entschieden: längster Abstand zwischen Trades ≤ 4 h über 7 Tage.
4. ~~Rang absolut oder ROI~~ — entschieden: ROI (einzahlungsbereinigter Kontowert im Nenner).
5. ~~Hysterese~~ — entschieden: 7 Tage, Etappe 2: 30 Tage.

**Verbleibend für das Audit:** die Placebo-Konstruktion des Exit-/Entry-Lifts (200 Ziehungen aus demselben
7-Tage-Fenster je Konto — genügt das gegen Volatilitäts-Regime?) und die Frage, ob der Rangbonus für den
Entry-Lift als Addition zum ROI-Rang oder nur als Sortierkriterium bei Gleichstand wirken soll (Vorschlag:
nur Anzeige und Gleichstand — der Rang bleibt reiner ROI).

## 11. Schatten der Darwin-Liste (U136) — vorab festgelegt am 07.10.2026

Frage des Nutzers (06.10. 22:55): Aufnahme schon bei Glück < 3 % statt ≤ 1 %? Bewertung (UEBERGABE 3δδ): im Pool vom 06.10. ist
zwischen 1 und 3 % kein Können zu sehen, und 3 % füllt die Liste in der Simulation vor allem mit Glück. Entscheidung des Nutzers
(07.10. 13:37): bei 1 % bleiben und die Beinahe-Aufnahmen beobachten. Dieser Abschnitt legt fest, wie, BEVOR Daten da sind.

**11.1 Gruppen** (`hl_profis.schatten_gruppe`, einmal täglich mit der ersten Bewertung nach 00 UTC; der erste Eintrag schon bei
der ersten Bewertung nach dem Update):
- „≤ 1 %“: erfüllt die Aufnahme (das sind genau die Zugänge der Darwin-Liste);
- „1–3 %“ und „3–5 %“: erfüllt alle Bedingungen der Aufnahme außer der Glücksschwelle (Aktivität, Gewinn 7 T und 30 T, ≥ 6
  Ein-/Ausstiege, Vorsprung ≥ 10 Punkte, kein Einstiegs-Veto), Glück im Band;
- Kontrolle: ebenso geprüft (Aktivität, Gewinn, ≥ 6, kein Veto), Glück über 5 % -- der Rest des geprüften Pools;
- Mitglieder der Liste nur in „≤ 1 %“.

**11.2 Eintragen** (`schatten_tag`): beim ersten Mal mit Zeitpunkt, Glück, Ein-/Ausstiegen und Zufallsquote dieses Tages. Ein Band
bleibt; eine spätere Bilanz verschiebt kein Konto (sonst wählte man nach dem Ergebnis aus). Aus der Kontrolle führt genau ein Weg in
ein Band: ab dann zählt das Konto dort, seine Entscheidungen davor bleiben in der Kontrolle.

**11.3 Vorwärts** (`schatten_entscheidungen`, täglich): Ein- und Ausstiege NACH dem Eintritt, sobald ihr 12-h-Fenster vorbei ist.
Richtig, Zufallsquote und die Zählung „je Richtung und 4-h-Block einmal“ genau wie die Darwin-Prüfung (`bewerte_konto`). Das
Fenster (bis, jetzt − 12 h] rückt vor; jede Entscheidung zählt einmal.

**11.4 Warum eine Kontrollgruppe.** Konten handeln eher in bewegten Phasen. Dann treffen auch Ein- und Ausstiege ohne Können öfter
als die Zufallsquote aus beliebigen Zeitpunkten -- die offene Frage aus Abschnitt 10 („genügt das Placebo gegen
Volatilitäts-Regime?“). In der Simulation mit diesem Bias (+4 Punkte für alle) sagt der Vergleich nur mit der Zufallsquote in 25–33 %
der Läufe „Timing“, der Vergleich mit der Kontrolle in 3 %. Im Pool vom 06.10. trafen 68 geprüfte Konten 28,1 % gegen 24,6 %
Zufall -- Können, Auswahl nach Gewinn oder Bias; vorwärts gegen die Kontrolle trennt es.

**11.5 Maß und Urteil** (`schatten_urteil`):
- Mehr-Treffer je Gruppe m = (richtig − Σ Zufallsquote) / Entscheidungen; Δ = m(1–3 %) − m(Kontrolle); Streuung aus Σ q(1−q)
  beider Gruppen, einseitiger z-Test.
- **„Timing belegt“ nur, wenn alles gilt:** Δ ≥ 5 Punkte; p < 0,05; im Band mindestens 60 Entscheidungen aus mindestens 3 Konten,
  in der Kontrolle mindestens 60; Δ > 0 auch ohne jedes einzelne Konto des Bands.
- **Termin:** 18.11.2026 (rund 6 Wochen; Bericht 19:15). Reichen dann Entscheidungen oder Konten nicht: 16.12.2026, dieselben
  Bedingungen. Davor nur Zwischenstand (wöchentlich in „★ Aktive Profis“), kein Urteil.
- Nebenbei, ohne Urteil: „1–5 %“ zusammen und „≤ 1 %“ (die Liste selbst) gegen die Kontrolle.
- Teststärke (Simulation, 6 Wochen): wahrer Vorsprung des Bands gegen die Kontrolle +8,7 Punkte -> 93 % belegt, +6,0 -> 63 %,
  +5,3 -> 53 %, +2,9 -> 30 %; ohne Können 3–7 %.

**11.6 Was folgt.** „Timing belegt“: Aufnahme bei Glück ≤ 3 % wird Kandidat für Regeln v4 (neue Labor-Kennung `liste=4`, die
Bilanz von `liste=3` bleibt getrennt), Entscheidung beim Nutzer. „Nicht belegt“: Aufnahme bleibt bei ≤ 1 %, U136 ist erledigt.
„Nicht entscheidbar“ am 16.12.: der Pool liefert zu wenige Beinahe-Aufnahmen; die Frage ruht.

**11.7 Proben** (`hl_profis.py --nulltest`, Teil „Schatten der Darwin-Liste“): Gruppen gegen die Aufnahme (12 Fälle); Eintragen
(Band fest, Kontrolle -> Band einmal, einmal je Tag); vorwärts auf Kursdaten gleich `bewerte_konto` (Treffer, Zufall), nur nach dem
Eintritt, zwei Schritte = einer (ein 4-h-Block über die Grenze zählt einmal), Wechsel teilt; Statistik gegen eine Rechnung von Hand,
ohne ein Konto, Termine; Simulation (150 Konten, 42 Tage): ohne Können mit Bias belegt ≤ 8 %, nur gegen die Zufallsquote ≥ 15 %,
halber Pool mit +15 Punkten ≥ 80 %. Mutationen 19 von 19 rot. Ende-zu-Ende in der Sandbox (Recorder-Schema, echte `bewerten`,
Dashboard-Schritt an zwei Tagen, `check_profis`): vorwärts gezählt = Rechnung von Hand.

**11.8 Grenzen.** Konten, die den Pool verlassen, liefern weniger Ereignisse (keine Pool-Positionen mehr). Entscheidungen eines
Kontos hängen zusammen; die Probe ohne ein Konto fängt nur den gröbsten Fall. Die Zufallsquote ist die der letzten 14 Tage am
Auswertungstag.

**11.9 Erster Eintrag auf dem Pi (07.10., Bericht 19:18; Nachtrag, ändert nichts an 11.1–11.8).** Eingetragen mit der ersten
Bewertung nach dem Update um 14:44: „≤ 1 %“ 2 Konten (x.com/SilkBtc 0,3 %, 0x58b2…11f3 0,6 %), „1–3 %“ 1 (0x541e…071d 1,3 %),
„3–5 %“ 3 (0xd7b8…9f55 4,4 %, 0x7743…e4fe 4,3 %, 0x9836…457e 3,8 %), Kontrolle 48. Vorwärts noch 0 Entscheidungen (ausgewertet bis
07.10. 02:44, vor dem Eintritt); erste Zahlen nach dem Tagesschritt am 09.10.
- Viereinhalb Stunden später standen dieselben Konten bei 2,1 / 4,0 / 6,6 / 8,8 / 5,8 % (das 1,5- bis 3,5-Fache). Die
  Glückswahrscheinlichkeit über 14 Tage bewegt sich mit wenigen neuen Entscheidungen stark. Deshalb gilt die Gruppe ab dem
  Eintritt (11.2), und gezählt wird nur danach.
- Das Band 1–3 % muss bis 18.11. auf mindestens 3 Konten mit 60 Entscheidungen wachsen; sonst gilt 16.12. (11.5).
- Seit 23.58 steht in der Tabelle „Konten (mit Entsch.)“, z. B. „48 (0)“: eingetragen, davon mit Entscheidungen. Vorher waren
  es zwei Spalten, die sich wie eine lasen.
