#!/usr/bin/env python3
"""
hl_timestats.py — Zeitbasierte Heatmap: wann treten große Kursbewegungen gehäuft auf?

Wertet historische 30-Minuten-Kerzen von Binance aus und zählt je Wochentag und
30-Minuten-Fenster, wie oft die Bewegung eine Schwelle überschreitet. Ergebnis
ist ein Raster aus 7 x 48 = 336 Feldern, das "danger times" sichtbar macht:
Zeitfenster, in denen statistisch überdurchschnittlich oft schnelle Bewegungen
und Kaskaden auftreten.

    python hl_timestats.py --coin BTC --years 3
    python hl_timestats.py --coin BTC --tz Europe/Berlin --measure net
    python hl_timestats.py --coin BTC --json danger.json     # für den Bot
    python hl_timestats.py --simulate                        # Test ohne Netz

Zwei Maße:
  range = (Hoch - Tief) / Eröffnung   -> misst Ausschläge, also auch Kaskaden,
                                         die wieder zurücklaufen. Standard.
  net   = |Schluss - Eröffnung| / Er. -> misst nur die Nettobewegung.

Statistische Warnung: 336 Felder gleichzeitig zu testen erzeugt bei einem
Signifikanzniveau von 5 Prozent rein zufällig rund 17 "signifikante" Treffer.
Das Skript rechnet deshalb Wilson-Konfidenzintervalle und markiert nur Felder,
deren Untergrenze über der Grundrate liegt — nach Bonferroni-Korrektur.
"""

from __future__ import annotations

import argparse
import json
import math
import sqlite3
import sys
import time
import urllib.request
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

FAPI = "https://fapi.binance.com"
DB_PATH = "hl_liq.db"
DAYS_DE = ["Montag", "Dienstag", "Mittwoch", "Donnerstag",
           "Freitag", "Samstag", "Sonntag"]
DAYS_SHORT = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS klines30 (
    ts     INTEGER,
    coin   TEXT,
    open   REAL, high REAL, low REAL, close REAL,
    volume REAL,
    PRIMARY KEY (ts, coin)
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS time_heatmap (
    coin       TEXT,
    tz         TEXT,
    measure    TEXT,
    threshold  REAL,
    weekday    INTEGER,   -- 0 = Montag
    slot       INTEGER,   -- 0..47, Fenster von 30 Minuten
    n          INTEGER,   -- Beobachtungen in diesem Feld
    hits       INTEGER,   -- davon über der Schwelle
    rate       REAL,
    ci_low     REAL,      -- Wilson-Untergrenze
    ci_high    REAL,
    lift       REAL,      -- Rate geteilt durch Grundrate
    robust     INTEGER,   -- 1 = auch nach Mehrfachtest-Korrektur erhöht
    avg_range  REAL,      -- mittlerer Ausschlag im Feld
    PRIMARY KEY (coin, tz, measure, threshold, weekday, slot)
) WITHOUT ROWID;
"""


def db_connect(path: str = DB_PATH) -> sqlite3.Connection:
    con = sqlite3.connect(path, timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


# ---------------------------------------------------------------------------
# Daten
# ---------------------------------------------------------------------------

def _get(path: str, params: dict):
    from urllib.parse import urlencode
    url = f"{FAPI}{path}?{urlencode(params)}"
    for attempt in range(4):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "hl-timestats/1.0"})
            with urllib.request.urlopen(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 451:
                raise RuntimeError("Binance sperrt den Zugriff aus dieser Region.") from e
            if e.code in (418, 429):
                time.sleep(5 * (attempt + 1))
                continue
            raise
        except Exception:
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Binance-Request {path} fehlgeschlagen")


def fetch_klines(con: sqlite3.Connection, coin: str, years: float) -> int:
    """30-Minuten-Kerzen laden und zwischenspeichern."""
    symbol = f"{coin.upper()}USDT"
    now = int(time.time() * 1000)
    start = now - int(years * 365.25 * 86_400_000)

    have = con.execute("SELECT MAX(ts) FROM klines30 WHERE coin=?", (coin,)).fetchone()[0]
    if have:
        start = max(start, (have + 1) * 1000)
        print(f"  Zwischenspeicher bis {datetime.fromtimestamp(have, timezone.utc):%Y-%m-%d}, "
              "lade nur Neues")

    rows, cursor, total = [], start, 0
    while cursor < now:
        chunk = _get("/fapi/v1/klines", {"symbol": symbol, "interval": "30m",
                                         "limit": 1500, "startTime": cursor,
                                         "endTime": now})
        if not chunk:
            break
        for k in chunk:
            rows.append((int(k[0]) // 1000, coin, float(k[1]), float(k[2]),
                         float(k[3]), float(k[4]), float(k[5])))
        newest = int(chunk[-1][0])
        if newest <= cursor:
            break
        cursor = newest + 1_800_000
        total += len(chunk)
        if len(rows) >= 5000:
            con.executemany("INSERT OR REPLACE INTO klines30 VALUES (?,?,?,?,?,?,?)", rows)
            con.commit()
            rows = []
        time.sleep(0.2)

    if rows:
        con.executemany("INSERT OR REPLACE INTO klines30 VALUES (?,?,?,?,?,?,?)", rows)
        con.commit()
    return total


def simulate(con: sqlite3.Connection, coin: str = "BTC", years: float = 3) -> None:
    """
    Testdaten mit eingebautem Muster: erhöhte Volatilität rund um 00, 08 und
    16 Uhr UTC (Funding) sowie zum US-Handelsstart. So lässt sich prüfen, ob
    die Auswertung bekannte Muster überhaupt findet.
    """
    import random
    rng = random.Random(11)
    n = int(years * 365.25 * 48)
    t0 = int(time.time()) - n * 1800
    px, rows = 60_000.0, []
    for i in range(n):
        ts = t0 + i * 1800
        h = datetime.fromtimestamp(ts, timezone.utc).hour
        wd = datetime.fromtimestamp(ts, timezone.utc).weekday()
        vol = 0.004
        if h in (0, 8, 16):
            vol *= 2.6                    # Funding-Zeitpunkte
        if h == 14 and wd < 5:
            vol *= 2.2                    # US-Eröffnung, nur werktags
        if wd >= 5:
            vol *= 0.75                   # Wochenende ruhiger
        ret = rng.gauss(0, vol)
        o = px
        px *= math.exp(ret)
        wick = abs(rng.gauss(0, vol)) * px
        rows.append((ts, coin, o, max(o, px) + wick, min(o, px) - wick, px,
                     rng.uniform(100, 900)))
    con.executemany("INSERT OR REPLACE INTO klines30 VALUES (?,?,?,?,?,?,?)", rows)
    con.commit()
    print(f"Simulation: {len(rows):,} Kerzen mit bekanntem Muster erzeugt.")
    print("Erwartung: erhöhte Werte um 00, 08, 16 UTC und werktags um 14 UTC.")


# ---------------------------------------------------------------------------
# Statistik
# ---------------------------------------------------------------------------

def wilson(hits: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Konfidenzintervall für einen Anteil. Bei kleinen n ehrlicher als p +/- 1.96*se."""
    if n == 0:
        return 0.0, 0.0
    p = hits / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (c - r) / d), min(1.0, (c + r) / d)


def analyze(con: sqlite3.Connection, coin: str, tz_name: str, measure: str,
            thresholds: list[float], since: str | None = None) -> dict:
    tz = ZoneInfo(tz_name)
    q = "SELECT ts, open, high, low, close FROM klines30 WHERE coin=?"
    params: list = [coin]
    if since:
        params.append(int(datetime.fromisoformat(since)
                          .replace(tzinfo=timezone.utc).timestamp()))
        q += " AND ts>=?"
    rows = con.execute(q + " ORDER BY ts", params).fetchall()
    if len(rows) < 2000:
        print(f"Nur {len(rows)} Kerzen — für 336 Felder deutlich zu wenig.")
        print("Mindestens ein Jahr laden (--years 1 entspricht rund 17.500 Kerzen).")
        return {}

    # Zelle -> Liste der Bewegungen
    cells: dict[tuple[int, int], list[float]] = {}
    for ts, o, h, l, c in rows:
        if o <= 0:
            continue
        move = (h - l) / o if measure == "range" else abs(c - o) / o
        d = datetime.fromtimestamp(ts, tz)
        key = (d.weekday(), d.hour * 2 + (1 if d.minute >= 30 else 0))
        cells.setdefault(key, []).append(move)

    all_moves = [m for v in cells.values() for m in v]
    span_days = (rows[-1][0] - rows[0][0]) / 86400
    out = {
        "coin": coin, "tz": tz_name, "measure": measure,
        "n_candles": len(rows), "span_days": span_days,
        "from": datetime.fromtimestamp(rows[0][0], tz).isoformat(),
        "to": datetime.fromtimestamp(rows[-1][0], tz).isoformat(),
        "thresholds": {},
    }

    n_cells = len(cells)
    for thr in thresholds:
        base = sum(1 for m in all_moves if m > thr) / len(all_moves)
        # Bonferroni: Niveau durch Anzahl der Felder teilen -> z steigt
        z_corr = 1.96 if n_cells <= 1 else _z_for(0.05 / n_cells)
        grid = {}
        for (wd, slot), moves in cells.items():
            n = len(moves)
            hits = sum(1 for m in moves if m > thr)
            rate = hits / n
            lo, hi = wilson(hits, n)
            lo_c, _ = wilson(hits, n, z_corr)
            grid[(wd, slot)] = {
                "n": n, "hits": hits, "rate": rate,
                "ci_low": lo, "ci_high": hi,
                "lift": rate / base if base > 0 else 0.0,
                "robust": int(lo_c > base),
                "avg": sum(moves) / n,
            }
        out["thresholds"][thr] = {"base": base, "grid": grid}
    return out


def two_proportion_test(h1: int, n1: int, h2: int, n2: int) -> tuple[float, float]:
    """
    Zwei-Stichproben-Test für Anteile. Liefert (z, p) zweiseitig.
    Ohne scipy, p-Wert über die Fehlerfunktion.
    """
    if n1 == 0 or n2 == 0:
        return 0.0, 1.0
    p1, p2 = h1 / n1, h2 / n2
    p = (h1 + h2) / (n1 + n2)
    se = math.sqrt(p * (1 - p) * (1 / n1 + 1 / n2))
    if se == 0:
        return 0.0, 1.0
    z = (p1 - p2) / se
    return z, math.erfc(abs(z) / math.sqrt(2))


def test_window(con: sqlite3.Connection, coin: str, tz_name: str, measure: str,
                thresholds: list[float], window: str, weekdays: str | None = None,
                since: str | None = None) -> None:
    """
    Prüft ein vorab festgelegtes Zeitfenster gegen den Rest des Tages.

    Weil hier genau eine Hypothese getestet wird und nicht 336, entfällt die
    Mehrfachtest-Korrektur. Das macht den Test deutlich aussagekräftiger --
    aber nur, solange das Fenster wirklich vorher festgelegt wurde und nicht
    aus derselben Grafik abgelesen ist.
    """
    tz = ZoneInfo(tz_name)
    a, _, b = window.partition("-")
    sh, sm = (int(x) for x in a.split(":"))
    eh, em = (int(x) for x in b.split(":"))
    start_min, end_min = sh * 60 + sm, eh * 60 + em
    wd_filter = None
    if weekdays:
        wd_filter = {int(x) for x in weekdays.split(",")}

    q = "SELECT ts, open, high, low, close FROM klines30 WHERE coin=?"
    params: list = [coin]
    if since:
        params.append(int(datetime.fromisoformat(since)
                          .replace(tzinfo=timezone.utc).timestamp()))
        q += " AND ts>=?"
    rows = con.execute(q + " ORDER BY ts", params).fetchall()
    if len(rows) < 2000:
        print(f"Nur {len(rows)} Kerzen — zu wenig für einen belastbaren Test.")
        return

    inside, outside = [], []
    per_year: dict[int, list] = {}
    for ts, o, h, l, c in rows:
        if o <= 0:
            continue
        move = (h - l) / o if measure == "range" else abs(c - o) / o
        d = datetime.fromtimestamp(ts, tz)
        if wd_filter is not None and d.weekday() not in wd_filter:
            continue
        minute = d.hour * 60 + d.minute
        # Fenster über Mitternacht hinweg korrekt behandeln
        if start_min <= end_min:
            is_in = start_min <= minute < end_min
        else:
            is_in = minute >= start_min or minute < end_min
        (inside if is_in else outside).append(move)
        per_year.setdefault(d.year, []).append((is_in, move))

    print("\n" + "=" * 72)
    print(f"Gerichteter Test: {coin} · Fenster {window} ({tz_name}) · {measure}")
    if weekdays:
        print(f"Nur Wochentage: {', '.join(DAYS_SHORT[int(x)] for x in weekdays.split(','))}")
    print(f"{len(inside):,} Kerzen im Fenster, {len(outside):,} außerhalb")
    print("=" * 72)

    for thr in thresholds:
        hi_in = sum(1 for m in inside if m > thr)
        hi_out = sum(1 for m in outside if m > thr)
        r_in = hi_in / len(inside) if inside else 0
        r_out = hi_out / len(outside) if outside else 0
        z, pval = two_proportion_test(hi_in, len(inside), hi_out, len(outside))
        lo_in, hi_ci_in = wilson(hi_in, len(inside))
        lo_out, hi_ci_out = wilson(hi_out, len(outside))

        print()
        print(f"Bewegung > {thr:.0%}")
        print(f"    im Fenster    {r_in:>7.2%}  ({hi_in:,} von {len(inside):,})"
              f"   95%-KI {lo_in:.2%}–{hi_ci_in:.2%}")
        print(f"    außerhalb     {r_out:>7.2%}  ({hi_out:,} von {len(outside):,})"
              f"   95%-KI {lo_out:.2%}–{hi_ci_out:.2%}")
        if r_out > 0:
            print(f"    Verhältnis    {r_in/r_out:>7.2f}x")
        print(f"    z = {z:+.2f}, p = {pval:.2}", end="")
        if pval < 0.001:
            print("   -> sehr deutlich")
        elif pval < 0.05:
            print("   -> signifikant")
        else:
            print("   -> nicht von Zufall zu unterscheiden")

        # Stabilität über die Jahre: hält der Effekt, oder stammt er aus einem Jahr?
        print("    Jahr für Jahr:", end="")
        parts = []
        for yr in sorted(per_year):
            ins = [m for i, m in per_year[yr] if i]
            outs = [m for i, m in per_year[yr] if not i]
            if len(ins) < 50 or len(outs) < 200:
                continue
            ri = sum(1 for m in ins if m > thr) / len(ins)
            ro = sum(1 for m in outs if m > thr) / len(outs)
            parts.append(f"{yr}: {ri/ro:.2f}x" if ro > 0 else f"{yr}: –")
        print("  " + "  ".join(parts) if parts else "  (zu wenig Daten)")

    print()
    print("  Hinweis zur Verwertbarkeit: In liquiditätsschwachen Stunden bewegt")
    print("  sich der Kurs leichter — aber deine eigenen Orders werden dort")
    print("  ebenfalls schlechter gefüllt. Der weitere Spread frisst genau den")
    print("  Vorteil, den die größere Bewegung verspricht.")


def _z_for(alpha: float) -> float:
    """Zweiseitiger z-Wert per Bisektion — spart die scipy-Abhängigkeit."""
    target = 1 - alpha / 2
    lo, hi = 0.0, 8.0
    for _ in range(80):
        mid = (lo + hi) / 2
        cdf = 0.5 * (1 + math.erf(mid / math.sqrt(2)))
        if cdf < target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def store(con: sqlite3.Connection, res: dict) -> None:
    rows = []
    for thr, d in res["thresholds"].items():
        for (wd, slot), c in d["grid"].items():
            rows.append((res["coin"], res["tz"], res["measure"], thr, wd, slot,
                         c["n"], c["hits"], c["rate"], c["ci_low"], c["ci_high"],
                         c["lift"], c["robust"], c["avg"]))
    con.executemany(
        "INSERT OR REPLACE INTO time_heatmap VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    con.commit()
    print(f"\n{len(rows)} Felder in time_heatmap gespeichert.")


# ---------------------------------------------------------------------------
# Ausgabe
# ---------------------------------------------------------------------------

BLOCKS = " ░▒▓█"


def print_report(res: dict, thr: float, top: int = 15) -> None:
    d = res["thresholds"][thr]
    grid, base = d["grid"], d["base"]
    n_per_cell = res["n_candles"] / 336

    print(f"\n{'='*72}")
    print(f"{res['coin']} · Bewegung > {thr:.0%} ({res['measure']}) · {res['tz']}")
    print(f"{res['from'][:10]} bis {res['to'][:10]} · {res['n_candles']:,} Kerzen "
          f"· rund {n_per_cell:.0f} Beobachtungen je Feld")
    print(f"Grundrate: {base:.2%} aller 30-Minuten-Fenster")
    print("=" * 72)

    mx = max(c["rate"] for c in grid.values()) or 1
    print("\n     " + "".join(f"{h:<2}" if h % 2 == 0 else "  " for h in range(24)))
    for wd in range(7):
        line = ""
        for slot in range(48):
            c = grid.get((wd, slot))
            if not c:
                line += " "
                continue
            lvl = min(4, int(c["rate"] / mx * 4.999))
            ch = BLOCKS[lvl]
            line += f"\033[1;31m{ch}\033[0m" if c["robust"] else ch
        print(f"  {DAYS_SHORT[wd]} {line}")
    print("     " + "".join(f"{h:<2}" if h % 2 == 0 else "  " for h in range(24)))
    print("\n  Dichte = Häufigkeit, rot = auch nach Mehrfachtest-Korrektur erhöht")

    ranked = sorted(grid.items(), key=lambda kv: -kv[1]["rate"])[:top]
    print(f"\n  Die {top} auffälligsten Fenster:")
    print(f"  {'Zeitfenster':<26}{'Rate':>8}{'Lift':>7}{'95%-KI':>16}{'n':>6}  robust")
    for (wd, slot), c in ranked:
        hh, mm = divmod(slot * 30, 60)
        e_h, e_m = divmod(slot * 30 + 30, 60)
        label = f"{DAYS_DE[wd]} {hh:02d}:{mm:02d}-{e_h % 24:02d}:{e_m:02d}"
        ci = f"{c['ci_low']:.1%}-{c['ci_high']:.1%}"
        mark = "  ja" if c["robust"] else "   –"
        print(f"  {label:<26}{c['rate']:>7.1%}{c['lift']:>7.2f}{ci:>16}{c['n']:>6}{mark}")

    robust = [k for k, c in grid.items() if c["robust"]]
    print(f"\n  {len(robust)} von 336 Feldern sind belastbar erhöht.")
    if not robust:
        print("  Keines übersteht die Korrektur — die Unterschiede sind mit dieser")
        print("  Datenmenge nicht von Zufall zu unterscheiden. Mehr Jahre laden,")
        print("  oder die Schwelle senken, damit mehr Treffer je Feld anfallen.")


def plot(res: dict, thr: float, out: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np

    d = res["thresholds"][thr]
    z = np.full((7, 48), np.nan)
    rob = np.zeros((7, 48), bool)
    for (wd, slot), c in d["grid"].items():
        z[wd, slot] = c["rate"]
        rob[wd, slot] = bool(c["robust"])

    fig, ax = plt.subplots(figsize=(16, 5.5))
    m = ax.imshow(z * 100, aspect="auto", cmap="inferno", interpolation="nearest")
    for wd in range(7):
        for slot in range(48):
            if rob[wd, slot]:
                ax.add_patch(plt.Rectangle((slot - .5, wd - .5), 1, 1,
                                           fill=False, edgecolor="#00e5ff", lw=1.4))
    ax.set_yticks(range(7), DAYS_DE)
    ax.set_xticks(range(0, 48, 2), [f"{h:02d}" for h in range(24)])
    ax.set_xlabel(f"Uhrzeit ({res['tz']}), Felder zu 30 Minuten")
    ax.set_title(f"{res['coin']} — Anteil der 30-Minuten-Fenster mit Bewegung "
                 f"> {thr:.0%} ({res['measure']})\n"
                 f"{res['from'][:10]} bis {res['to'][:10]}, "
                 f"Grundrate {d['base']:.1%} · "
                 f"blau umrandet = belastbar erhöht", fontsize=11)
    fig.colorbar(m, ax=ax, label="Anteil der Fenster in %", pad=0.01)
    plt.tight_layout()
    plt.savefig(out, dpi=130)
    print(f"Gespeichert: {out}")


def export_json(res: dict, path: str) -> None:
    """Kompakte Form für den Bot: nur die belastbar erhöhten Fenster."""
    danger = []
    for thr, d in res["thresholds"].items():
        for (wd, slot), c in d["grid"].items():
            if c["robust"]:
                hh, mm = divmod(slot * 30, 60)
                danger.append({
                    "weekday": wd, "weekday_name": DAYS_DE[wd],
                    "slot": slot, "time": f"{hh:02d}:{mm:02d}",
                    "threshold": thr, "rate": round(c["rate"], 4),
                    "lift": round(c["lift"], 2), "n": c["n"],
                })
    danger.sort(key=lambda x: -x["lift"])
    payload = {"coin": res["coin"], "tz": res["tz"], "measure": res["measure"],
               "from": res["from"], "to": res["to"],
               "n_candles": res["n_candles"],
               "base_rates": {str(t): round(d["base"], 5)
                              for t, d in res["thresholds"].items()},
               "danger_windows": danger}
    with open(path, "w") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    print(f"Gespeichert: {path} ({len(danger)} auffällige Fenster)")


# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Zeitbasierte Volatilitäts-Heatmap")
    p.add_argument("--db", default=DB_PATH)
    p.add_argument("--coin", default="BTC")
    p.add_argument("--years", type=float, default=3)
    p.add_argument("--tz", default="UTC",
                   help="z. B. Europe/Berlin. UTC vermeidet Sommerzeit-Verschmierung.")
    p.add_argument("--measure", default="range", choices=["range", "net"])
    p.add_argument("--thresholds", type=float, nargs="+", default=[0.01, 0.03])
    p.add_argument("--since", help="nur ab diesem Datum, z. B. 2024-01-01")
    p.add_argument("--no-fetch", action="store_true", help="nur vorhandene Daten nutzen")
    p.add_argument("--simulate", action="store_true")
    p.add_argument("--json", help="auffällige Fenster als JSON exportieren")
    p.add_argument("--png", action="store_true")
    p.add_argument("--test-window", metavar="HH:MM-HH:MM",
                   help="ein vorab festgelegtes Fenster gegen den Rest testen, "
                        "z. B. 02:00-05:00")
    p.add_argument("--weekdays", help="auf Wochentage einschränken, 0=Mo, z. B. 0,1,2,3,4")
    args = p.parse_args()

    con = db_connect(args.db)

    if args.simulate:
        simulate(con, args.coin, args.years)
    elif not args.no_fetch:
        print(f"Lade 30-Minuten-Kerzen für {args.coin}, {args.years} Jahre …")
        n = fetch_klines(con, args.coin, args.years)
        print(f"  {n:,} neue Kerzen")

    if args.test_window:
        test_window(con, args.coin, args.tz, args.measure, args.thresholds,
                    args.test_window, args.weekdays, args.since)
        con.close()
        return

    res = analyze(con, args.coin, args.tz, args.measure, args.thresholds, args.since)
    if not res:
        return

    for thr in args.thresholds:
        print_report(res, thr)
        if args.png:
            plot(res, thr, f"{args.coin}_zeit_{int(thr*100)}pct.png")

    store(con, res)
    if args.json:
        export_json(res, args.json)

    print("\nHinweis: Das ist eine Beschreibung der Vergangenheit, keine Vorhersage.")
    print("Zeitmuster verschieben sich, wenn sich die Marktstruktur ändert.")
    con.close()


if __name__ == "__main__":
    main()
