# KONZEPT Risikoradar (U307, U308) — Risiko eines Rücksetzers in Prozent, acht Achsen, Alarm

Stand 23.11.2026, 20:12 (gemessen), Fable 5.2. **Vorab festgelegt, bevor eine Zahl dieses Moduls auf echten Daten gerechnet wurde.**
**Fassung 2 vom 23.11.2026, 21:25 (gemessen):** Präzisierungen beim Bau, gesammelt in Abschnitt 12 und an den betroffenen Stellen
eingetragen — ebenfalls vor jeder Zahl auf echten Daten (gerechnet wurde bis dahin nur auf erzeugten Reihen).
Auf dem Pi läuft 2026-09-23.121 · 967df1fdf8. Grundlage: `BEWERTUNG_Risikoradar_23-11-2026.md` (Bestand, eigene Urteile, Recherche).
Abweichungen nur als neue Fassung mit Datum und Grund, wie bei den übrigen KONZEPT-Dateien.

**Auftrag des Nutzers (23.11.2026 19:41, Kern wörtlich):** „eine Art Risikoradar zu zeigen, und das Risiko in Prozenten
einzuschätzen … Sollte das Risiko zu sehr ansteigen, sollte es zusätzlich eine Audiomitteilung geben. Die neue Funktion sollte zu
sehen sein im Cockpit, so dass man übersichtlich gleich erkennen kann, wie das aktuelle Marktrisiko ist und ob möglicherweise ein
Kursrückgang erfolgen könnte.“

**Entscheidungen des Nutzers (23.11.2026 20:04, Auswahl zum Anklicken):**
1. Ereignis: beide Zahlen — groß „−10 % in 7 Tagen“, darunter „−7 % in 48 Stunden“.
2. Wege der Meldung: Push aufs Handy mit Ton, Ton im Dashboard, gesprochene Ansage. Kein Lautsprecher am Pi.
3. Reihenfolge: Konzept, dann Paket 1 (Karte im Cockpit, Alarm auf dem Belegten, Prüfung der neuen Zeichen auf dem Pi); Aufschläge
   in Paket 2.

**Lieferung (von mir festgelegt, Grund: Größe):** Paket 1 kommt in zwei Teilen. **23.122 (U307):** Karte, Grundrisiko, Achsen,
Druck-Index, Alarm, Rückblick des Grundrisikos. **23.123 (U308):** Prüfung der Regeln R1–R7. Paket 2 (U309, später): Aufschläge für
bestandene Regeln, Sicht des Marktes (kurze Optionen, Prognosemärkte), weitere Messreihen.

---

## 0. Kurzfassung

- **Zwei Zahlen je Coin:** Wahrscheinlichkeit, dass der Kurs in 7 Tagen 10 % tiefer berührt wird (groß), und in 48 Stunden 7 % tiefer
  (klein). Beide aus der Verteilung des Ausblicks am jetzigen Kurs. Für andere Coins als BTC gilt die gleichwertige Schwelle nach
  ihrer Schwankung.
- **Jede Zahl steht neben ihrer Grundrate** und trägt eine Stufe: normal · erhöht (riskanteste 20 % der Tage) · hoch (riskanteste 5 %).
- **Geprüft wird vor der Anzeige:** Ein Rückblick ab 2022 rechnet beide Zahlen nach (G7, G2). Besteht eine Zahl nicht, steht sie
  grau mit dem Satz „im Rückblick nicht bestätigt“ und löst keinen Alarm aus.
- **Acht Achsen** zeigen, wo Druck entsteht. Fünf davon haben lange Historie und bilden den Druck-Index. Achsen und Index sind
  Messwerte, keine Vorhersage, bis eine Regel besteht.
- **Alarm** beim Eintritt in „hoch“: Push mit höchster Priorität, Sirene und gesprochene Ansage im Dashboard. Sperrzeit 12 Stunden.
- **Sieben Regeln R1–R7** für Warnzeichen sind hier festgeschrieben und werden mit 23.123 geprüft. Was besteht, darf in Paket 2 die
  Prozentzahl erhöhen.
- **Wirkung:** keine auf Prognose, Labor, Engine, Notbremse.

---

## 1. Ereignisse

Für Coin c zum Zeitpunkt t mit Kurs P:
- **E7:** Das Tief im Zeitraum (t, t + 7 Tage] liegt bei höchstens P · (1 − 0,10 · f_c).
- **E2:** Das Tief im Zeitraum (t, t + 48 Stunden] liegt bei höchstens P · (1 − 0,07 · f_c).

**Faktor f_c** (gleichwertige Schwelle, nach der Regel des Nutzers vom 20.10.2026 für die Akkumulation): f_BTC = 1. Sonst
f_c = σ̄_c ÷ σ̄_BTC, mindestens 1, auf zwei Stellen gerundet. σ̄ ist die Wurzel aus dem Mittel der quadrierten Tagesrenditen
(Tagesschlüsse des Binance-Perpetuals `<COIN>USDT` aus `hebel.db`) über die 365 Tage vor dem Monatsersten; nur Tage, an denen Coin und
BTC einen Schluss haben; mindestens 180 solche Tage, sonst gibt es für den Coin keine Zahl. Der Faktor gilt für den ganzen Monat.
Coins: BTC, ETH, HYPE, ZEC, XMR. PAXG nicht.

Die Karte nennt die Schwelle des Coins in Prozent und als Kurs („−13,9 % = 1.404“).

**Messung im Rückblick:** an Tagesursprüngen 00:00 UTC; das Tief ist das kleinste Tief der 24-Stunden-Blöcke, die in den nächsten
2 bzw. 7 Tagen enden (wie S3 des Ausblicks).

---

## 2. Grundrisiko (die Prozentzahl in 23.122)

- p7 = `hl_ausblick.erreichen_aus_lauf(L, ln(1 − 0,10·f_c), 7)`, p2 = `erreichen_aus_lauf(L, ln(1 − 0,07·f_c), 2)`. L ist die abgelegte
  Verteilung des laufenden Tiefs der jüngsten Rechnung des Ausblicks, angelegt am jetzigen Kurs — dieselbe Quelle wie der
  Kurs-Rechner. Für BTC ist p7 damit dieselbe Zahl, die der Kurs-Rechner für −10 % in 7 Tagen zeigt.
- Dafür legt der Ausblick ab 23.122 die Verteilung zusätzlich für Tag 2 ab (`lauf_quantile`: Horizonte 2, 7, 14, 28). Sonst ändert
  sich am Ausblick nichts.
- Frische: Kurs höchstens 5 Minuten alt, Rechnung des Ausblicks höchstens 3 Stunden alt (strenger als der Kurs-Rechner mit 2 Tagen,
  weil eine Zahl für 48 Stunden sonst veraltet wäre; der Ausblick rechnet im Hintergrund stündlich, bei offenem Abschnitt alle
  30 Minuten — Fassung 2). Sonst steht der Grund statt der Zahl.
  Liegt p unter 0,5 % oder über 99,5 %, steht „unter 0,5 %“ bzw. „über 99,5 %“.
- Anzeige mit einer Nachkommastelle unter 10 %, sonst ganzzahlig.

---

## 3. Rückblick des Grundrisikos (G7, G2) — Debug 161

**Rechnung:** Für jeden Coin und jeden Tagesursprung τ (00:00 UTC) ab 01.01.2022, für den die Bibliothek des Ausblicks mindestens
200 Fenster hat, die vor τ vollständig abgelaufen waren: p7(τ) und p2(τ) aus den Szenarien des Ausblicks mit der damaligen
Schwankungsprognose (kausal, ohne Drift, wie S3), f_c des damaligen Monats. Eingetreten: E7 bzw. E2 nach Abschnitt 1. Jede Zahl
ist wie in der Anzeige auf 0,5 % bis 99,5 % begrenzt (Fassung 2, Abschnitt 12 Nr. 13).

**Vergleich:** die laufende Grundrate g(τ) = Anteil der früheren Ursprünge desselben Coins mit eingetretenem Ereignis, deren Frist bei τ
abgelaufen war (mindestens 100, sonst zählt der Ursprung nicht).

**Maße** (über alle Coins zusammen, je Ereignis): Brier(p), Brier(g), Brier-Skill = 1 − Brier(p) ÷ Brier(g); Steigung der
Kalibrierung (Logit-Regression des Eintritts auf logit p); Zuverlässigkeit in den Klassen 0–2, 2–5, 5–10, 10–20, 20–40, über 40 % mit
90-%-Band (Wilson); p-Wert des Skills aus dem stationären Block-Bootstrap der Tagesmittel (Block 28 Tage, 2000 Ziehungen, einseitig).

**Besteht** (je Ereignis): mindestens 1000 Ursprungstage und 50 eingetretene Ereignisse **und** Skill > 0 mit p < 0,05 **und** Steigung
zwischen 0,8 und 1,2 **und** (Fassung 2, Abschnitt 12 Nr. 1) Niveau zwischen 0,8 und 1,25 — Niveau = Mittel der Zahl ÷ eingetretene
Quote. Sonst „nicht bestätigt“ mit dem Grund; geprüft wird in dieser Reihenfolge: Historie, Skill, Steigung, Niveau. Zwei Urteile, G7
und G2, je für die eigene Zahl; keine weitere Korrektur. Je Coin steht das Niveau als Hinweis in der Karte, wenn es außerhalb von 0,8
bis 1,25 liegt („kann zu hoch sein“ / „kann zu niedrig sein“); am Urteil ändert das nichts.

**Folge, fest:** besteht → Zahl normal, Stufen und Alarm gelten. Nicht bestätigt → Zahl grau mit Satz, keine Stufe, kein Alarm.

**Aus demselben Lauf, je Coin und Ereignis:**
- Grundrate = Anteil der Ursprünge mit Ereignis (ganzer Rückblick).
- Schwelle „erhöht“ = 80. Perzentil der Rückblick-Werte von p; Schwelle „hoch“ = 95. Perzentil (wie die Lampe Schwankung: 80/95).
- Tabelle der Alarme im Rückblick (beschreibend): Eintritte in „hoch“ je Jahr mit der Regel aus Abschnitt 6, Zahl der Eintritte,
  nach denen das Ereignis in der Frist kam, und Zahl der Ereignis-Episoden (aufeinanderfolgende Ursprungstage mit Ereignis), in denen
  das Radar an mindestens einem Tag auf „hoch“ stand (Fassung 2, Abschnitt 12 Nr. 14 — die erste Fassung nannte „ohne ‚hoch‘ am
  Vortag“).

Der Lauf rechnet in einem eigenen Prozess mit niedriger Priorität, legt Urteil, Grundraten und Schwellen in `radar.db` ab und wird
wiederholt, wenn das Ergebnis älter als 30 Tage ist. Jede Ablage trägt ihr Datum.

**Erwartung (vorab):** G7 besteht wahrscheinlich (S3 des Ausblicks besteht bei 7 Tagen mit Steigung um 0,95). G2 ist offen: Tag 2 ist
nie geprüft worden, und Stürze binnen 48 Stunden hängen stärker an Nachrichten. Bei BTC kann p7 zu hoch liegen (das 80-%-Band traf
im Rückblick 84 %).

---

## 4. Achsen und Druck-Index

Jede Achse hat einen Wert von 0 bis 100; höher heißt mehr Druck. Ohne ausreichenden Verlauf ist sie grau und nennt den Grund.

| Nr. | Achse | Leitgröße | Vergleich | im Index |
|---|---|---|---|---|
| A1 | Positionierung | Kontenquote Binance (alle Konten) | Perzentil gegen 90 Tagesstände (wie im Cockpit) | ja |
| A2 | Hebel-Menge | Open Interest Binance in Coins | Perzentil gegen 90 Tagesstände (wie im Cockpit) | ja |
| A3 | Preis des Hebels | Funding Binance, Mittel der letzten 7 Tage, auf ein Jahr gerechnet | Perzentil gegen die Tageswerte der 365 Tage davor (mindestens 180) | ja |
| A4 | Spot-Nachfrage | Spot-Taker-Saldo Binance über 7 Tage: Σ(2·Taker-Kauf − Umsatz) ÷ Σ Umsatz, alle Spot-Paare des Coins | 100 − Perzentil gegen 365 Tage (schwache Nachfrage = hoher Wert) | ja |
| A5 | Liquidations-Nähe | Long-Positionswert mit Liquidationspreis bis −5 % (Heatmap) ÷ Gebote bis −1 % im Hyperliquid-Buch | Perzentil gegen die eigenen Stundenwerte (mindestens 14 Tage, höchstens 90) | nein |
| A6 | Markttiefe | Gebote bis −1 % im Hyperliquid-Buch (USD, Mittel der letzten 60 Minuten — Fassung 2, Abschnitt 12 Nr. 2) | 100 − Perzentil gegen die Stundenmittel der letzten 30 Tage (mindestens 240) | nein |
| A7 | Schwankung | σ des Tages (EWMA der quadrierten Tagesrenditen, Halbwertszeit 20 Tage, wie U142) | Perzentil gegen 365 Tage | ja |
| A8 | Umfeld | Stufen: 0 nichts · 33 Wochenende · 66 Termin binnen 24 h (Verbraucherpreise, Arbeitsmarkt, Fed) · 100 Aktien-Lampe an oder Notbremse ab Stufe 1 | keine Perzentile, der höchste zutreffende Wert | nein |

- A1, A2: der jüngste Stand gegen die Tagesstände; die Zahl ist dieselbe wie in der Liste „Messwerte“ des Cockpits (dort gilt:
  mindestens 60 der 90 Tagesstände, sonst kein Perzentil).
- A5: der Nenner ist derselbe Wert wie A6 (Mittel der letzten 60 Minuten). A8 (Fassung 2, Abschnitt 12 Nr. 3): Ist die Termin- oder die
  Aktien-Lampe grau und könnte sie mehr bedeuten als das Bekannte, steht A8 grau mit Grund — nicht „0“.
- A3, A4, A7: Tageswerte aus `hebel.db` und `swing.db`, Stand des letzten vollen UTC-Tages; die Karte nennt den Tag.
- A4 fehlt für Coins ohne Binance-Spot (HYPE, XMR): grau.
- **Druck-Index** = Mittel der vorhandenen Achsen A1, A2, A3, A4, A7 (mindestens vier). Er ist eine Zusammenfassung von Messwerten.
  Die Karte beschriftet ihn mit „gemessen, ungeprüft“, bis R7 geurteilt ist.
- **Warnzeichen:** Kontenquote ≥ 3 (U142 H1, belegt) steht als eigene Zeile mit dem gemessenen Verhältnis aus U142 (20,3 % gegen 7,3 %)
  und dem Hinweis, dass dort ein anderes Ereignis geprüft wurde.
- Zusätzlich als Text, ohne Achse: Funding Hyperliquid, Funding-Druck, Varianz des Taker-Flusses, Perp-Anteil — aus dem Cockpit.

---

## 5. Regeln R1–R7 (Prüfung mit 23.123, Debug 163)

**Daten:** Tagesreihen der Hebel-Studie (`hl_hebel.daten_laden`): Perp-Tageskerzen, Open Interest, Kontenquote, Funding je Tag, Spot-
und Perp-Kerzen mit Taker-Kauf. **Coins im Urteil:** BTC und ETH, gepoolt. ZEC, XMR, HYPE beschreibend.
**Ereignis:** E7 und E2 nach Abschnitt 1 auf den Tageskerzen (Signal am Schluss von d; Tief der Tage d+1 … d+7 bzw. d+1 … d+2).

| Regel | Signal am Schluss von Tag d |
|---|---|
| R1 Kontenquote | Kontenquote ≥ 3 |
| R2 Hebel-Aufbau im Stillstand | ln OI(d) − ln OI(d−7) im obersten Zehntel der 365 Tage davor **und** \|ln C(d) − ln C(d−7)\| ≤ 0,5 · σ_d · √7 |
| R3 Funding-Niveau | Funding, Mittel der letzten 7 Tage, auf ein Jahr gerechnet ≥ 15 % |
| R4 Spot trägt nicht | ln C(d) − ln C(d−7) > 0 **und** Spot-Taker-Saldo über 7 Tage < 0 **und** Perp-Taker-Saldo über 7 Tage > 0 |
| R5 OI-Überhitzung | Open Interest im Perzentil ≥ 0,90 der 90 Tage davor (zweite Prüfung nach U141 C1; entsprechend vorsichtig zu lesen) |
| R6 Termin | am Tag d+1 stehen Verbraucherpreise, Arbeitsmarktbericht oder ein Fed-Entscheid an |
| R7 Druck-Index | Druck-Index (Abschnitt 4, auf Tagesschlüssen) im obersten Zehntel der 365 Tage davor |

**Maß:** Risikoverhältnis nach Mantel-Haenszel über die Zehntel von σ_d je Coin. So zählt nicht, dass ein Signal bloß hohe Schwankung
anzeigt; die steckt schon im Grundrisiko. Daneben roh: Quote nach Signal, Quote sonst, RR.
**Null:** zirkuläre Verschiebung des Signals um jedes τ von 30 bis 365 Tagen in beide Richtungen (672 Verschiebungen, für beide Coins
dieselbe), p = (1 + Zahl der Verschiebungen mit RR ≥ beobachtet) ÷ 673, einseitig.
**Band:** 90 % aus dem Kalender-Blockbootstrap (60-Tage-Blöcke, für beide Coins dieselben, 1000 Ziehungen).
**Prüfbar:** mindestens 30 Signaltage, 5 Episoden (Signaltage mehr als h Tage auseinander) und 30 Vergleichstage mit gültigem Ereignis.
**Belegt:** prüfbar **und** p nach Holm < 0,05 **und** RR in beiden Kalenderhälften über 1 und über dem Median der Null der Hälfte.
Holm je Ereignis über die prüfbaren der sieben Regeln. E7 ist die Hauptfamilie, E2 die zweite; ein Urteil gilt nur für sein Ereignis.
**Nachweisgrenze:** vor dem echten Lauf auf erfundenen Märkten gemessen (ohne Effekt: höchstens 10 % „belegt“; mit eingepflanztem
RR 2 und RR 3: Anteil „belegt“). Der Bericht nennt sie.

**Erwartung (vorab):** R1 für E7 wahrscheinlich belegt (U142: RR 2,77 auf einem verwandten Ereignis). R2, R3, R4: RR zwischen 1,0 und
1,5 und damit kaum nachweisbar. R5: Hinweis wie in U141, nicht belegt. R6: für E2 denkbar, klein. R7: offen.

**Folgen, fest:** Eine belegte Regel wird Kandidat für einen Aufschlag in Paket 2 (Faktor auf die Chance, nach σ geschichtet
geschätzt, gedeckelt bei 3; er bleibt nur, wenn die erhöhte Zahl im Rückblick besser trifft als das Grundrisiko allein). Eine nicht
belegte Regel bleibt Messwert. Nichts davon wirkt ohne eigene Entscheidung des Nutzers.

**Nur vorwärts** (Historie zu kurz, kein Urteil in 23.123): A5, A6, Optionen, Prognosemärkte, Coinbase-Prämie, Kombinationen aus den
Vorbedingungen des TradeLabors.

---

## 6. Stufen, Alarm, Meldungen

**Stufe je Coin und Ereignis** (nur wenn G besteht und Schwellen vorliegen): normal · erhöht (p ≥ Schwelle „erhöht“) · hoch.
„Hoch“ beginnt, wenn p ≥ Schwelle „hoch“; es endet, wenn p unter 0,8 · Schwelle „hoch“ fällt.

**Alarm:** beim Beginn von „hoch“, wenn für denselben Coin und dasselbe Ereignis in den letzten 12 Stunden kein Alarm kam.
**Entwarnung:** beim Ende von „hoch“, leise. **Hinweis Warnzeichen:** wenn die Kontenquote auf ≥ 3 steigt, nachdem sie unter 2,8 lag;
höchstens einmal in 7 Tagen je Coin.

**Für welche Coins:** Vorgabe nur BTC (das Marktrisiko). Weitere Coins schaltet der Nutzer in der Karte zu. Für einen nicht gewählten
Coin läuft der Zustand mit, aber nichts gilt als gemeldet: keine Sperrzeit aus einem Alarm, den es nicht gab, und später keine
Entwarnung ohne Alarm. Wird ein Coin dazugeschaltet, der schon „hoch“ ist, kommt der Alarm erst beim nächsten Beginn (Fassung 2,
Abschnitt 12 Nr. 4).

| Weg | Alarm | Entwarnung | Hinweis | Bedingung |
|---|---|---|---|---|
| Push (ntfy, `hl_berichte.senden`) | Priorität 5 | Priorität 2 (ohne Ton) | Priorität 3 | Benachrichtigung eingerichtet, Schalter „Push“ an (Vorgabe an); kommt auch bei geschlossenem Dashboard |
| Ton im Dashboard | Sirene 4 s | – | kurzer Ton | Seite offen, „Töne an“ |
| Gesprochene Ansage | „Risikoradar. Bitcoin. Risiko hoch. 31 Prozent für minus 10 Prozent in 7 Tagen.“ | – | – | Seite offen, Schalter „Ansage“ an; kann der Browser nicht sprechen, steht das in der Karte |

**Text jeder Meldung:** Coin, Ereignis, Zahl, Grundrate, die zwei höchsten Achsen, aktive Warnzeichen, Stand der Daten (Ortszeit des Pi
mit dem Kürzel der Zeitzone; Berichte nennen UTC). Kein Pfeil, kein Empfehlungswort. Thema und Schlüssel erscheinen in keinem Text.

**Im Browser** (Fassung 2, Abschnitt 12 Nr. 5): jede Meldung einmal je Browser und nur, wenn sie höchstens 10 Minuten alt ist; mehrere
Alarme zugleich: eine Sirene, die Ansagen nacheinander; die Entwarnung bleibt still. Bei geschlossenem Abschnitt holt die Seite die
Meldungen jede Minute, wenn Ton oder Ansage an ist. Ton und Ansage gibt es nur bei offener Seite — der Push kommt auch ohne sie.

**Takt:** alle 5 Minuten ein Stand je Coin; zur vollen Stunde wird er in `radar.db` abgelegt (Vorwärtsbilanz). Der Alarm prüft jeden
Stand. Der Rückblick misst Eintritte auf Tageswerten; live kann es öfter läuten. Die Bilanz zählt es, und die Schwelle ist im
Dashboard verstellbar (Perzentil 95 → 97,5 → 99).

---

## 7. Anzeige im Cockpit

Karte „Risikoradar“ für den gewählten Coin, unter dem Kernsatz (Fassung 2, Abschnitt 12 Nr. 6: Der Satz des Rückblicks steht
zugeklappt unter „Beleg“; im Kopf steht „Stufe …“, „im Rückblick nicht bestätigt“ oder „noch nicht geprüft“, und eine Zahl ist matt,
solange ihr Rückblick nicht besteht. Statt eines Punkts im Streifen der Coins trägt die Karte die Zeile „Stufe je Coin“ mit Zahl und
Stufe aus der letzten Ablage; ein Tipp wählt den Coin):
1. **Kopf:** p7 groß mit Schwelle, Grundrate und Stufe; p2 darunter. Dazu „Geprüft: G7 besteht (Skill, Steigung, Zeitraum)“ oder
   der Satz, warum nicht.
2. **Radar:** acht Achsen als Netz, graue Achsen gestrichelt; daneben je Achse Wert, Leitgröße in Worten und Stand.
3. **Was den Druck treibt:** die zwei höchsten Achsen in einem Satz; Warnzeichen in eigener Zeile.
4. **Druck-Index** mit dem Vermerk „gemessen, ungeprüft“.
5. **Meldungen:** Schalter Push, Ton, Ansage; Coins; Schwelle; letzter Alarm.
6. **Beleg:** was geprüft ist und was nicht; Grenzen (Nachrichten, Zeitpunkt).

Farben wie die Lampen (aus, Hinweis, Warnung, grau). Der Punkt je Coin im Streifen der sechs Coins aus der ersten Fassung entfällt
(Abschnitt 12 Nr. 6): Die Zeile „Stufe je Coin“ der Karte ersetzt ihn.

---

## 8. Speicher und Betrieb

- `radar.db` neben der Hauptdatenbank: `rd_stand` (Stunde, Coin, Stand als JSON), `rd_alarm` (Zeit, Coin, Ereignis, Art, Zahl, Text,
  gesendet), `rd_meta` (Rückblick mit Datum, Schwellen, Einstellungen, Zustand je Coin). Im täglichen Backup.
- Faden „radar“ im Dashboard-Prozess (`hl_radar.starten`; nicht für Selbsttest-Datenbanken; aus mit `HL_RADAR=0`).
- Liest: `ausblick.db`, `hebel.db`, `swing.db`, `volatil.db`, `makro.db`, Hauptdatenbank. Schreibt nur `radar.db`. Kein Abruf im Netz
  außer dem Push.
- Debug 160 „Risikoradar: Stand als Text“, 161 „Rückblick des Grundrisikos“, 162 „Selbsttest“, 163 (mit 23.123) „Prüfung der Regeln“
  — 163 ist seit 23.122 reserviert. Berichte haben höchstens 150 Zeichen je Zeile.
- Es rechnet nur ein Rückblick zur selben Zeit (Sperre auf einer Datei neben `radar.db`); Debug 161 wartet bis zu 10 Minuten auf einen
  laufenden und zeigt sonst den gespeicherten (Fassung 2, Abschnitt 12 Nr. 7).
- Nach dem Einspielen rechnet der Ausblick einmal sofort, wenn seiner abgelegten Verteilung Tag 2 fehlt (Abschnitt 12 Nr. 8).
- Berichtsplan nach dem Einspielen: 10 Minuten: Debug 160 und 162; 30 Minuten: Debug 161; 12 Stunden: Debug 160.

---

## 9. Proben (Selbsttest ohne Netz)

- Faktor, Schwellen, beide Zahlen von Hand; p7 für BTC gleich dem Kurs-Rechner; Ränder (unter 0,5 %, über 99,5 %, fehlende Rechnung,
  alter Kurs).
- Jede Achse von Hand; Perzentile mit Bindungen; graue Achsen; Index mit vier und mit drei Achsen.
- Rückblick auf erfundenen Märkten: richtig kalibrierte Zahl besteht; zu stark gespreizte Zahl fällt an der Steigung durch; im Mittel
  zu hohe Zahl fällt am Niveau durch (Fassung 2 — die erste Fassung nannte hier „künstlich verdoppelte Zahl fällt an der Steigung
  durch“; das trifft nicht zu, siehe Abschnitt 12 Nr. 1); Zahl ohne Zusammenhang fällt am Skill durch; zu wenige Ereignisse → kein
  Urteil.
- Schwellen und Alarm-Tabelle von Hand; Zustände: Beginn, Ende mit 0,8, Sperrzeit, Entwarnung, Warnzeichen mit 2,8 und 7 Tagen.
- Push an einen nachgebauten Server: Priorität, Text ohne Thema, Schalter aus → nichts gesendet, nicht eingerichtet → nichts gesendet.
  Dazu (Fassung 2) ein echter Versand über `hl_berichte` an einen Webserver auf demselben Rechner.
- Regeln R1–R7 (23.123): jede Regel von Hand, Mantel-Haenszel von Hand, Verschiebung ohne τ = 0, Holm, Hälften, Nullwelten und
  eingepflanzte Effekte.
- Browser: Karte, Radar, graue Achsen, Schalter, Ton und Ansage mit nachgebauter Sprachausgabe, schmaler Bildschirm (390 px).
- Jede Probe mit Mutationstest.

---

## 10. Was das Radar nicht kann

- Einen Schock durch Nachrichten ankündigen.
- Den Zeitpunkt nennen. „Hoch“ heißt: öfter als sonst.
- Mehr sehen, als die Daten hergeben: A5 beruht auf den verfolgten Konten (14–34 % des Open Interest am 18.11.2026, Debug 48).
- Feine Effekte belegen: Ein Risikoverhältnis um 1,2–1,5 ist auf dieser Historie nicht nachweisbar (U142).

---

## 11. Präzisierungen gegenüber der Bewertung (vor jeder Zahl)

1. **Stufen über Perzentile statt über eine Zahl von Alarmen.** Die Zahl der Eintritte fällt nicht gleichmäßig mit der Schwelle
   (eine sehr tiefe Schwelle ergibt einen einzigen langen Zustand). Der Anteil der Tage tut es. Darum 80. und 95. Perzentil; die
   Eintritte je Jahr stehen als Messung im Rückblick.
2. **Sieben Regeln statt neun.** DVOL gegen erwartete Schwankung und Aktienstress entfallen in dieser Runde (weniger Tests, mehr
   Trennschärfe; DVOL hat im Urteil V4 schon nicht getragen, Aktienstress steht als Lampe und in A8). Beide bleiben Kandidaten.
3. **Der Druck-Index zählt fünf Achsen.** Nur sie haben lange Historie; so ist geprüft, was angezeigt wird.
4. **Null der Regeln: Verschiebung statt Vorzeichen-Surrogate.** Das Ereignis misst Tiefs innerhalb des Tages; Surrogate haben nur
   Schlüsse. Die Schwankung wird durch die Schichtung nach σ herausgenommen.
5. **Lieferung in zwei Teilen** (oben).
6. **Sicht des Marktes** (Optionen, Prognosemärkte) kommt mit Paket 2; in 23.122 steht sie nicht in der Karte.

---

## 12. Präzisierungen beim Bau (Fassung 2, 23.11.2026 21:25 — vor jeder Zahl auf echten Daten)

Bis zu diesem Zeitpunkt hat das Modul nur auf erzeugten Reihen gerechnet (Selbsttest und eine Welt in der Größe des Betriebs ohne
echte Kurse). Jede Änderung mit Grund:

1. **Viertes Kriterium „Niveau“ im Rückblick (Abschnitt 3).** Die Steigung der Kalibrierung fängt einen gleichmäßigen Faktor nicht:
   Eine überall um denselben Faktor zu hohe Zahl verschiebt den Achsenabschnitt der Logit-Regression, kaum die Steigung. Die geplante
   Probe „künstlich verdoppelte Zahl fällt an der Steigung durch“ war falsch gedacht — mein Fehler, beim Bau der Probe gefunden.
   Darum zusätzlich: Mittel der Zahl ÷ eingetretene Quote zwischen 0,8 und 1,25. Strenger als die erste Fassung, nicht milder.
2. **A5 und A6 nehmen das Mittel statt des Medians** der Gebote der letzten 60 Minuten und der Stundenwerte. Grund: Das Mittel rechnet
   die Datenbank in einer Abfrage; für den Median müssten rund 1,5 Millionen Zeilen des 5-Sekunden-Rasters in den Speicher. Die letzten
   14 Tage stehen nur im 5-Sekunden-Raster, ältere als Minutenmittel — der Rückgriff braucht beide Tabellen. A6 verlangt mindestens 240
   Stundenmittel (10 Tage), A5 wie festgelegt 14 Tage eigener Stundenwerte (336).
3. **A8 grau statt „0“, wenn eine Lampe grau ist**, die mehr bedeuten könnte als das Bekannte. „0“ hieße „nichts Besonderes“, ohne dass
   es jemand weiß.
4. **Nicht gewählter Coin:** Zustand läuft mit, nichts gilt als gemeldet (Abschnitt 6).
5. **Meldungen im Browser:** einmal je Browser, höchstens 10 Minuten alt, eine Sirene für mehrere Alarme, Entwarnung still (Abschnitt 6).
6. **Karte:** Satz des Rückblicks unter „Beleg“, Zahl matt bis „besteht“, Zeile „Stufe je Coin“ statt eines Punkts im Streifen
   (Abschnitt 7). Grund: Der Streifen gehört zur Antwort des Cockpits; die Zeile der Karte nennt Zahl und Stufe und kommt aus der
   Ablage des Radars. Die Schwelle „hoch“ wählt der Nutzer als „die riskantesten 5 %, 2,5 % oder 1 % der Tage“ (dieselben Perzentile).
7. **Ein Rückblick zur selben Zeit**, Debug 161 wartet (Abschnitt 8). Grund: Takt und Bericht hätten ihn sonst doppelt gerechnet.
8. **Der Ausblick rechnet nach dem Einspielen einmal sofort**, wenn seiner abgelegten Verteilung ein Tag fehlt (Tag 2). Sonst stünde
   die 48-Stunden-Zahl bis zu einer Stunde leer.
9. **Trend im Ausblick:** Die laufende Rechnung des Ausblicks kann einen Trend enthalten, wenn eines seiner Tore offen ist; der
   Rückblick (G7, G2) rechnet ohne Trend, wie S3 des Ausblicks. Enthält die jüngste Rechnung einen, sagt die Karte es in einem Satz.
10. **Zeit in Meldungen:** Ortszeit des Pi mit dem Kürzel der Zeitzone; Berichte bleiben bei UTC.
11. **Debug 163 reserviert** (die Nummer steht in diesem Konzept; der Lauf kommt mit 23.123). Berichte höchstens 150 Zeichen je Zeile.
12. **Grundrate im Rückblick:** Die laufende Grundrate braucht 100 frühere Ursprünge mit abgelaufener Frist — die ersten gewerteten
    Ursprünge liegen darum im April 2022, nicht am 01.01.2022 (Folge der Regel in Abschnitt 3, keine Änderung).
13. **Der Rückblick begrenzt die Zahl wie die Anzeige** (21:30, ebenfalls vor jeder Zahl auf echten Daten): Die Karte kann nur
    Werte zwischen 0,5 % und 99,5 % zeigen (Raster der abgelegten Verteilung; darunter steht „unter 0,5 %“). Der Rückblick rechnet
    darum mit derselben Grenze: Erreicht kein Szenario die Schwelle, zählt der Ursprung mit 0,5 %, nicht mit 0. Geprüft wird so die
    Zahl, die der Nutzer sieht. Ohne die Grenze hinge die Steigung an einem Rechendetail (logit von 0).
14. **Tabelle der Alarme: „Episode gedeckt“ genauer gefasst** (22:04, ebenfalls vor jeder Zahl auf echten Daten; die Tabelle ist
    beschreibend und geht in kein Urteil ein). Eine Ereignis-Episode ist eine Folge aufeinanderfolgender Ursprungstage, nach denen
    das Ereignis in der Frist kam. Gezählt wird, in wie vielen Episoden das Radar an mindestens einem dieser Tage auf „hoch“ stand.
    Die erste Fassung nannte „ohne ‚hoch‘ am Vortag“ — am Tag vor dem ersten Ursprungstag einer Episode liegt das Ereignis aber noch
    außerhalb der Frist; „hoch“ an diesem Tag wäre kein Treffer. Mein Fehler in der Formulierung, beim Schreiben der Dokumente
    gefunden; der Code zählte von Anfang an so wie hier beschrieben.
15. **Der Faden „radar“ übersteht Fehler** (ebenfalls 22:04): Ist `radar.db` beim Start nicht erreichbar oder scheitert ein
    Schritt, meldet der Faden das in der Ausgabe des Dashboards und versucht es beim nächsten Schritt wieder (nach einem Fehler der
    Datenbank mit einer neuen Verbindung). Karte und Debug 160 zeigen in dieser Zeit „Takt: steht seit …“ (kein Schritt seit mehr
    als 15 Minuten); ohne Takt gibt es keinen Alarm.
