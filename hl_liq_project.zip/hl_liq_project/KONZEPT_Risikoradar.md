# KONZEPT Risikoradar (U307, U308) — Risiko eines Rücksetzers in Prozent, acht Achsen, Alarm

Stand 23.11.2026, 20:12 (gemessen), Fable 5.2. **Vorab festgelegt, bevor eine Zahl dieses Moduls auf echten Daten gerechnet wurde.**
**Fassung 2 vom 23.11.2026, 21:25 (gemessen):** Präzisierungen beim Bau, gesammelt in Abschnitt 12 und an den betroffenen Stellen
eingetragen — ebenfalls vor jeder Zahl auf echten Daten (gerechnet wurde bis dahin nur auf erzeugten Reihen).
**Fassung 3 vom 24.11.2026, 09:30 (gemessen):** Abschnitt 13 — das Ergebnis des ersten Rückblicks auf dem Pi, die Nachkalibrierung
(Regel K, Entscheidung des Nutzers vom 24.11.2026 08:52), die Berichtigung der Achsen A5 und A6 (mein Fehler), die Präzisierungen zu
den Regeln R1–R7 und die gemessene Nachweisgrenze. Regel K steht **nach** den ersten Zahlen auf echten Daten; die Präzisierungen zu
R1–R7 stehen **vor** jeder Rechnung der Regeln auf echten Daten.
**Fassung 4 vom 24.11.2026, 19:48 (gemessen):** Abschnitt 14 — was Paket 23.123 auf dem Pi ergab (Regel K, Regeln R1–R7), zwei
Entscheidungen des Nutzers von 19:16, die Karte mit der 48-Stunden-Zahl vorn und **Regel A (Aufschlag für belegte Zeichen)**. Regel A
steht **vor** jeder Rechnung eines Aufschlags auf echten Daten, aber **nach** den Tabellen von Debug 161 und 163 (Offenlegung in 14.5).
**Fassung 5 vom 25.11.2026 (Opus 5.5):** Abschnitt 15 — Regel A auf dem Pi (nicht bestätigt; Offenlegung zum Niveau), die Entscheidung
des Nutzers „Tiefe richtig messen“ und die neue Leitgröße von A5 und A6: die Gebote bis −1 % (U311).
Auf dem Pi läuft 2026-09-23.121 · 967df1fdf8. Grundlage: `BEWERTUNG_Risikoradar_23-11-2026.md` (Bestand, eigene Urteile, Recherche).
Abweichungen nur als neue Fassung mit Datum und Grund, wie bei den übrigen KONZEPT-Dateien.

**Auftrag des Nutzers (23.11.2026 19:41, Kern wörtlich):** „eine Art Risikoradar zu zeigen, und das Risiko in Prozenten
einzuschätzen … Sollte das Risiko zu sehr ansteigen, sollte es zusätzlich eine Audiomitteilung geben. Die neue Funktion sollte zu
sehen sein im Cockpit, so dass man übersichtlich gleich erkennen kann, wie das aktuelle Marktrisiko ist und ob möglicherweise ein
Kursrückgang erfolgen könnte.“

**Entscheidungen des Nutzers (23.11.2026 20:04, Auswahl zum Anklicken):**
1. Ereignis: beide Zahlen — groß „−10 % in 7 Tagen“, darunter „−7 % in 48 Stunden“.
2. Wege der Meldung: Push aufs Handy mit Ton, Ton im Dashboard, gesprochene Ansage. Kein Lautsprecher am Pi.
3. Reihenfolge: Konzept, dann Paket 1 (Karte im Cockpit, Alarm auf dem Belegten, Prüfung der neuen Zeichen auf dem Pi); Aufschläge
   in Paket 2.

**Lieferung (von mir festgelegt, Grund: Größe):** Paket 1 kommt in zwei Teilen. **23.122 (U307):** Karte, Grundrisiko, Achsen,
Druck-Index, Alarm, Rückblick des Grundrisikos. **23.123 (U308):** Prüfung der Regeln R1–R7. Paket 2 (U309, später): Aufschläge für
bestandene Regeln, Sicht des Marktes (kurze Optionen, Prognosemärkte), weitere Messreihen.

---

## 0. Kurzfassung

- **Zwei Zahlen je Coin:** Wahrscheinlichkeit, dass der Kurs in 7 Tagen 10 % tiefer berührt wird (groß), und in 48 Stunden 7 % tiefer
  (klein) — **seit Fassung 4 umgekehrt: die 48-Stunden-Zahl groß, die 7-Tage-Zahl klein (Abschnitt 14.3)**. Beide aus der Verteilung des Ausblicks am jetzigen Kurs. Für andere Coins als BTC gilt die gleichwertige Schwelle nach
  ihrer Schwankung.
- **Jede Zahl steht neben ihrer Grundrate** und trägt eine Stufe: normal · erhöht (riskanteste 20 % der Tage) · hoch (riskanteste 5 %).
- **Geprüft wird vor der Anzeige:** Ein Rückblick ab 2022 rechnet beide Zahlen nach (G7, G2). Besteht eine Zahl nicht, steht sie
  grau mit dem Satz „im Rückblick nicht bestätigt“ und löst keinen Alarm aus.
- **Acht Achsen** zeigen, wo Druck entsteht. Fünf davon haben lange Historie und bilden den Druck-Index. Achsen und Index sind
  Messwerte, keine Vorhersage, bis eine Regel besteht.
- **Alarm** beim Eintritt in „hoch“: Push mit höchster Priorität, Sirene und gesprochene Ansage im Dashboard. Sperrzeit 12 Stunden.
- **Sieben Regeln R1–R7** für Warnzeichen sind hier festgeschrieben und werden mit 23.123 geprüft. Was besteht, darf in Paket 2 die
  Prozentzahl erhöhen.
- **Wirkung:** keine auf Prognose, Labor, Engine, Notbremse.

---

## 1. Ereignisse

Für Coin c zum Zeitpunkt t mit Kurs P:
- **E7:** Das Tief im Zeitraum (t, t + 7 Tage] liegt bei höchstens P · (1 − 0,10 · f_c).
- **E2:** Das Tief im Zeitraum (t, t + 48 Stunden] liegt bei höchstens P · (1 − 0,07 · f_c).

**Faktor f_c** (gleichwertige Schwelle, nach der Regel des Nutzers vom 20.10.2026 für die Akkumulation): f_BTC = 1. Sonst
f_c = σ̄_c ÷ σ̄_BTC, mindestens 1, auf zwei Stellen gerundet. σ̄ ist die Wurzel aus dem Mittel der quadrierten Tagesrenditen
(Tagesschlüsse des Binance-Perpetuals `<COIN>USDT` aus `hebel.db`) über die 365 Tage vor dem Monatsersten; nur Tage, an denen Coin und
BTC einen Schluss haben; mindestens 180 solche Tage, sonst gibt es für den Coin keine Zahl. Der Faktor gilt für den ganzen Monat.
Coins: BTC, ETH, HYPE, ZEC, XMR. PAXG nicht.

Die Karte nennt die Schwelle des Coins in Prozent und als Kurs („−13,9 % = 1.404“).

**Messung im Rückblick:** an Tagesursprüngen 00:00 UTC; das Tief ist das kleinste Tief der 24-Stunden-Blöcke, die in den nächsten
2 bzw. 7 Tagen enden (wie S3 des Ausblicks).

---

## 2. Grundrisiko (die Prozentzahl in 23.122)

- p7 = `hl_ausblick.erreichen_aus_lauf(L, ln(1 − 0,10·f_c), 7)`, p2 = `erreichen_aus_lauf(L, ln(1 − 0,07·f_c), 2)`. L ist die abgelegte
  Verteilung des laufenden Tiefs der jüngsten Rechnung des Ausblicks, angelegt am jetzigen Kurs — dieselbe Quelle wie der
  Kurs-Rechner. Für BTC ist p7 damit dieselbe Zahl, die der Kurs-Rechner für −10 % in 7 Tagen zeigt.
- Dafür legt der Ausblick ab 23.122 die Verteilung zusätzlich für Tag 2 ab (`lauf_quantile`: Horizonte 2, 7, 14, 28). Sonst ändert
  sich am Ausblick nichts.
- Frische: Kurs höchstens 5 Minuten alt, Rechnung des Ausblicks höchstens 3 Stunden alt (strenger als der Kurs-Rechner mit 2 Tagen,
  weil eine Zahl für 48 Stunden sonst veraltet wäre; der Ausblick rechnet im Hintergrund stündlich, bei offenem Abschnitt alle
  30 Minuten — Fassung 2). Sonst steht der Grund statt der Zahl.
  Liegt p unter 0,5 % oder über 99,5 %, steht „unter 0,5 %“ bzw. „über 99,5 %“.
- Anzeige mit einer Nachkommastelle unter 10 %, sonst ganzzahlig.

---

## 3. Rückblick des Grundrisikos (G7, G2) — Debug 161

**Rechnung:** Für jeden Coin und jeden Tagesursprung τ (00:00 UTC) ab 01.01.2022, für den die Bibliothek des Ausblicks mindestens
200 Fenster hat, die vor τ vollständig abgelaufen waren: p7(τ) und p2(τ) aus den Szenarien des Ausblicks mit der damaligen
Schwankungsprognose (kausal, ohne Drift, wie S3), f_c des damaligen Monats. Eingetreten: E7 bzw. E2 nach Abschnitt 1. Jede Zahl
ist wie in der Anzeige auf 0,5 % bis 99,5 % begrenzt (Fassung 2, Abschnitt 12 Nr. 13).

**Vergleich:** die laufende Grundrate g(τ) = Anteil der früheren Ursprünge desselben Coins mit eingetretenem Ereignis, deren Frist bei τ
abgelaufen war (mindestens 100, sonst zählt der Ursprung nicht).

**Maße** (über alle Coins zusammen, je Ereignis): Brier(p), Brier(g), Brier-Skill = 1 − Brier(p) ÷ Brier(g); Steigung der
Kalibrierung (Logit-Regression des Eintritts auf logit p); Zuverlässigkeit in den Klassen 0–2, 2–5, 5–10, 10–20, 20–40, über 40 % mit
90-%-Band (Wilson); p-Wert des Skills aus dem stationären Block-Bootstrap der Tagesmittel (Block 28 Tage, 2000 Ziehungen, einseitig).

**Besteht** (je Ereignis): mindestens 1000 Ursprungstage und 50 eingetretene Ereignisse **und** Skill > 0 mit p < 0,05 **und** Steigung
zwischen 0,8 und 1,2 **und** (Fassung 2, Abschnitt 12 Nr. 1) Niveau zwischen 0,8 und 1,25 — Niveau = Mittel der Zahl ÷ eingetretene
Quote. Sonst „nicht bestätigt“ mit dem Grund; geprüft wird in dieser Reihenfolge: Historie, Skill, Steigung, Niveau. Zwei Urteile, G7
und G2, je für die eigene Zahl; keine weitere Korrektur. Je Coin steht das Niveau als Hinweis in der Karte, wenn es außerhalb von 0,8
bis 1,25 liegt („kann zu hoch sein“ / „kann zu niedrig sein“); am Urteil ändert das nichts.

**Folge, fest:** besteht → Zahl normal, Stufen und Alarm gelten. Nicht bestätigt → Zahl grau mit Satz, keine Stufe, kein Alarm.

**Aus demselben Lauf, je Coin und Ereignis:**
- Grundrate = Anteil der Ursprünge mit Ereignis (ganzer Rückblick).
- Schwelle „erhöht“ = 80. Perzentil der Rückblick-Werte von p; Schwelle „hoch“ = 95. Perzentil (wie die Lampe Schwankung: 80/95).
- Tabelle der Alarme im Rückblick (beschreibend): Eintritte in „hoch“ je Jahr mit der Regel aus Abschnitt 6, Zahl der Eintritte,
  nach denen das Ereignis in der Frist kam, und Zahl der Ereignis-Episoden (aufeinanderfolgende Ursprungstage mit Ereignis), in denen
  das Radar an mindestens einem Tag auf „hoch“ stand (Fassung 2, Abschnitt 12 Nr. 14 — die erste Fassung nannte „ohne ‚hoch‘ am
  Vortag“).

Der Lauf rechnet in einem eigenen Prozess mit niedriger Priorität, legt Urteil, Grundraten und Schwellen in `radar.db` ab und wird
wiederholt, wenn das Ergebnis älter als 30 Tage ist. Jede Ablage trägt ihr Datum.

**Erwartung (vorab):** G7 besteht wahrscheinlich (S3 des Ausblicks besteht bei 7 Tagen mit Steigung um 0,95). G2 ist offen: Tag 2 ist
nie geprüft worden, und Stürze binnen 48 Stunden hängen stärker an Nachrichten. Bei BTC kann p7 zu hoch liegen (das 80-%-Band traf
im Rückblick 84 %).

---

## 4. Achsen und Druck-Index

Jede Achse hat einen Wert von 0 bis 100; höher heißt mehr Druck. Ohne ausreichenden Verlauf ist sie grau und nennt den Grund.

| Nr. | Achse | Leitgröße | Vergleich | im Index |
|---|---|---|---|---|
| A1 | Positionierung | Kontenquote Binance (alle Konten) | Perzentil gegen 90 Tagesstände (wie im Cockpit) | ja |
| A2 | Hebel-Menge | Open Interest Binance in Coins | Perzentil gegen 90 Tagesstände (wie im Cockpit) | ja |
| A3 | Preis des Hebels | Funding Binance, Mittel der letzten 7 Tage, auf ein Jahr gerechnet | Perzentil gegen die Tageswerte der 365 Tage davor (mindestens 180) | ja |
| A4 | Spot-Nachfrage | Spot-Taker-Saldo Binance über 7 Tage: Σ(2·Taker-Kauf − Umsatz) ÷ Σ Umsatz, alle Spot-Paare des Coins | 100 − Perzentil gegen 365 Tage (schwache Nachfrage = hoher Wert) | ja |
| A5 | Liquidations-Nähe | Long-Positionswert mit Liquidationspreis bis −5 % (Heatmap) ÷ Gebote bis −1 % im Hyperliquid-Buch (Fassung 5, Abschnitt 15 — in Fassung 3 die obersten 10 Preisstufen, Abschnitt 13.3) | Perzentil gegen die eigenen Stundenwerte (mindestens 14 Tage, höchstens 90) | nein |
| A6 | Markttiefe | Gebote bis −1 % im Hyperliquid-Buch (USD, Mittel der letzten 60 Minuten aus `book_tiefe` — Fassung 5, Abschnitt 15; davor die obersten 10 Preisstufen, Abschnitt 13.3) | 100 − Perzentil gegen die Stundenmittel der letzten 30 Tage (mindestens 240) | nein |
| A7 | Schwankung | σ des Tages (EWMA der quadrierten Tagesrenditen, Halbwertszeit 20 Tage, wie U142) | Perzentil gegen 365 Tage | ja |
| A8 | Umfeld | Stufen: 0 nichts · 33 Wochenende · 66 Termin binnen 24 h (Verbraucherpreise, Arbeitsmarkt, Fed) · 100 Aktien-Lampe an oder Notbremse ab Stufe 1 | keine Perzentile, der höchste zutreffende Wert | nein |

- A1, A2: der jüngste Stand gegen die Tagesstände; die Zahl ist dieselbe wie in der Liste „Messwerte“ des Cockpits (dort gilt:
  mindestens 60 der 90 Tagesstände, sonst kein Perzentil).
- A5: der Nenner ist derselbe Wert wie A6 (Mittel der letzten 60 Minuten). A8 (Fassung 2, Abschnitt 12 Nr. 3): Ist die Termin- oder die
  Aktien-Lampe grau und könnte sie mehr bedeuten als das Bekannte, steht A8 grau mit Grund — nicht „0“.
- A3, A4, A7: Tageswerte aus `hebel.db` und `swing.db`, Stand des letzten vollen UTC-Tages; die Karte nennt den Tag.
- A4 fehlt für Coins ohne Binance-Spot (HYPE, XMR): grau.
- **Druck-Index** = Mittel der vorhandenen Achsen A1, A2, A3, A4, A7 (mindestens vier). Er ist eine Zusammenfassung von Messwerten.
  Die Karte beschriftet ihn mit „gemessen, ungeprüft“, bis R7 geurteilt ist.
- **Warnzeichen:** Kontenquote ≥ 3 (U142 H1, belegt) steht als eigene Zeile mit dem gemessenen Verhältnis aus U142 (20,3 % gegen 7,3 %)
  und dem Hinweis, dass dort ein anderes Ereignis geprüft wurde.
- Zusätzlich als Text, ohne Achse: Funding Hyperliquid, Funding-Druck, Varianz des Taker-Flusses, Perp-Anteil — aus dem Cockpit.

---

## 5. Regeln R1–R7 (Prüfung mit 23.123, Debug 163)

**Daten:** Tagesreihen der Hebel-Studie (`hl_hebel.daten_laden`): Perp-Tageskerzen, Open Interest, Kontenquote, Funding je Tag, Spot-
und Perp-Kerzen mit Taker-Kauf. **Coins im Urteil:** BTC und ETH, gepoolt. ZEC, XMR, HYPE beschreibend.
**Ereignis:** E7 und E2 nach Abschnitt 1 auf den Tageskerzen (Signal am Schluss von d; Tief der Tage d+1 … d+7 bzw. d+1 … d+2).

| Regel | Signal am Schluss von Tag d |
|---|---|
| R1 Kontenquote | Kontenquote ≥ 3 |
| R2 Hebel-Aufbau im Stillstand | ln OI(d) − ln OI(d−7) im obersten Zehntel der 365 Tage davor **und** \|ln C(d) − ln C(d−7)\| ≤ 0,5 · σ_d · √7 |
| R3 Funding-Niveau | Funding, Mittel der letzten 7 Tage, auf ein Jahr gerechnet ≥ 15 % |
| R4 Spot trägt nicht | ln C(d) − ln C(d−7) > 0 **und** Spot-Taker-Saldo über 7 Tage < 0 **und** Perp-Taker-Saldo über 7 Tage > 0 |
| R5 OI-Überhitzung | Open Interest im Perzentil ≥ 0,90 der 90 Tage davor (zweite Prüfung nach U141 C1; entsprechend vorsichtig zu lesen) |
| R6 Termin | am Tag d+1 stehen Verbraucherpreise, Arbeitsmarktbericht oder ein Fed-Entscheid an |
| R7 Druck-Index | Druck-Index (Abschnitt 4, auf Tagesschlüssen) im obersten Zehntel der 365 Tage davor |

**Maß:** Risikoverhältnis nach Mantel-Haenszel über die Zehntel von σ_d je Coin. So zählt nicht, dass ein Signal bloß hohe Schwankung
anzeigt; die steckt schon im Grundrisiko. Daneben roh: Quote nach Signal, Quote sonst, RR.
**Null:** zirkuläre Verschiebung des Signals um jedes τ von 30 bis 365 Tagen in beide Richtungen (672 Verschiebungen, für beide Coins
dieselbe), p = (1 + Zahl der Verschiebungen mit RR ≥ beobachtet) ÷ 673, einseitig.
**Band:** 90 % aus dem Kalender-Blockbootstrap (60-Tage-Blöcke, für beide Coins dieselben, 1000 Ziehungen).
**Prüfbar:** mindestens 30 Signaltage, 5 Episoden (Signaltage mehr als h Tage auseinander) und 30 Vergleichstage mit gültigem Ereignis.
**Belegt:** prüfbar **und** p nach Holm < 0,05 **und** RR in beiden Kalenderhälften über 1 und über dem Median der Null der Hälfte.
Holm je Ereignis über die prüfbaren der sieben Regeln. E7 ist die Hauptfamilie, E2 die zweite; ein Urteil gilt nur für sein Ereignis.
**Nachweisgrenze:** vor dem echten Lauf auf erfundenen Märkten gemessen (ohne Effekt: höchstens 10 % „belegt“; mit eingepflanztem
RR 2 und RR 3: Anteil „belegt“). Der Bericht nennt sie. Gemessen am 24.11.2026 — Abschnitt 13.5.

**Erwartung (vorab):** R1 für E7 wahrscheinlich belegt (U142: RR 2,77 auf einem verwandten Ereignis). R2, R3, R4: RR zwischen 1,0 und
1,5 und damit kaum nachweisbar. R5: Hinweis wie in U141, nicht belegt. R6: für E2 denkbar, klein. R7: offen.

**Folgen, fest:** Eine belegte Regel wird Kandidat für einen Aufschlag in Paket 2 (Faktor auf die Chance, nach σ geschichtet
geschätzt, gedeckelt bei 3; er bleibt nur, wenn die erhöhte Zahl im Rückblick besser trifft als das Grundrisiko allein). Eine nicht
belegte Regel bleibt Messwert. Nichts davon wirkt ohne eigene Entscheidung des Nutzers.

**Nur vorwärts** (Historie zu kurz, kein Urteil in 23.123): A5, A6, Optionen, Prognosemärkte, Coinbase-Prämie, Kombinationen aus den
Vorbedingungen des TradeLabors.

---

## 6. Stufen, Alarm, Meldungen

**Stufe je Coin und Ereignis** (nur wenn G besteht und Schwellen vorliegen): normal · erhöht (p ≥ Schwelle „erhöht“) · hoch.
„Hoch“ beginnt, wenn p ≥ Schwelle „hoch“; es endet, wenn p unter 0,8 · Schwelle „hoch“ fällt.

**Alarm:** beim Beginn von „hoch“, wenn für denselben Coin und dasselbe Ereignis in den letzten 12 Stunden kein Alarm kam.
**Entwarnung:** beim Ende von „hoch“, leise. **Hinweis Warnzeichen:** wenn die Kontenquote auf ≥ 3 steigt, nachdem sie unter 2,8 lag;
höchstens einmal in 7 Tagen je Coin.

**Für welche Coins:** Vorgabe nur BTC (das Marktrisiko). Weitere Coins schaltet der Nutzer in der Karte zu. Für einen nicht gewählten
Coin läuft der Zustand mit, aber nichts gilt als gemeldet: keine Sperrzeit aus einem Alarm, den es nicht gab, und später keine
Entwarnung ohne Alarm. Wird ein Coin dazugeschaltet, der schon „hoch“ ist, kommt der Alarm erst beim nächsten Beginn (Fassung 2,
Abschnitt 12 Nr. 4).

| Weg | Alarm | Entwarnung | Hinweis | Bedingung |
|---|---|---|---|---|
| Push (ntfy, `hl_berichte.senden`) | Priorität 5 | Priorität 2 (ohne Ton) | Priorität 3 | Benachrichtigung eingerichtet, Schalter „Push“ an (Vorgabe an); kommt auch bei geschlossenem Dashboard |
| Ton im Dashboard | Sirene 4 s | – | kurzer Ton | Seite offen, „Töne an“ |
| Gesprochene Ansage | „Risikoradar. Bitcoin. Risiko hoch. 31 Prozent für minus 10 Prozent in 7 Tagen.“ | – | – | Seite offen, Schalter „Ansage“ an; kann der Browser nicht sprechen, steht das in der Karte |

**Text jeder Meldung:** Coin, Ereignis, Zahl, Grundrate, die zwei höchsten Achsen, aktive Warnzeichen, Stand der Daten (Ortszeit des Pi
mit dem Kürzel der Zeitzone; Berichte nennen UTC). Kein Pfeil, kein Empfehlungswort. Thema und Schlüssel erscheinen in keinem Text.

**Im Browser** (Fassung 2, Abschnitt 12 Nr. 5): jede Meldung einmal je Browser und nur, wenn sie höchstens 10 Minuten alt ist; mehrere
Alarme zugleich: eine Sirene, die Ansagen nacheinander; die Entwarnung bleibt still. Bei geschlossenem Abschnitt holt die Seite die
Meldungen jede Minute, wenn Ton oder Ansage an ist. Ton und Ansage gibt es nur bei offener Seite — der Push kommt auch ohne sie.

**Takt:** alle 5 Minuten ein Stand je Coin; zur vollen Stunde wird er in `radar.db` abgelegt (Vorwärtsbilanz). Der Alarm prüft jeden
Stand. Der Rückblick misst Eintritte auf Tageswerten; live kann es öfter läuten. Die Bilanz zählt es, und die Schwelle ist im
Dashboard verstellbar (Perzentil 95 → 97,5 → 99).

---

## 7. Anzeige im Cockpit

Karte „Risikoradar“ für den gewählten Coin, unter dem Kernsatz (Fassung 2, Abschnitt 12 Nr. 6: Der Satz des Rückblicks steht
zugeklappt unter „Beleg“; im Kopf steht „Stufe …“, „im Rückblick nicht bestätigt“ oder „noch nicht geprüft“, und eine Zahl ist matt,
solange ihr Rückblick nicht besteht. Statt eines Punkts im Streifen der Coins trägt die Karte die Zeile „Stufe je Coin“ mit Zahl und
Stufe aus der letzten Ablage; ein Tipp wählt den Coin):
1. **Kopf:** p7 groß mit Schwelle, Grundrate und Stufe; p2 darunter (seit Fassung 4: p2 groß, p7 klein darunter — Abschnitt 14.3). Dazu „Geprüft: G7 besteht (Skill, Steigung, Zeitraum)“ oder
   der Satz, warum nicht.
2. **Radar:** acht Achsen als Netz, graue Achsen gestrichelt; daneben je Achse Wert, Leitgröße in Worten und Stand.
3. **Was den Druck treibt:** die zwei höchsten Achsen in einem Satz; Warnzeichen in eigener Zeile.
4. **Druck-Index** mit dem Vermerk „gemessen, ungeprüft“.
5. **Meldungen:** Schalter Push, Ton, Ansage; Coins; Schwelle; letzter Alarm.
6. **Beleg:** was geprüft ist und was nicht; Grenzen (Nachrichten, Zeitpunkt).

Farben wie die Lampen (aus, Hinweis, Warnung, grau). Der Punkt je Coin im Streifen der sechs Coins aus der ersten Fassung entfällt
(Abschnitt 12 Nr. 6): Die Zeile „Stufe je Coin“ der Karte ersetzt ihn.

---

## 8. Speicher und Betrieb

- `radar.db` neben der Hauptdatenbank: `rd_stand` (Stunde, Coin, Stand als JSON), `rd_alarm` (Zeit, Coin, Ereignis, Art, Zahl, Text,
  gesendet), `rd_meta` (Rückblick mit Datum, Schwellen, Einstellungen, Zustand je Coin). Im täglichen Backup.
- Faden „radar“ im Dashboard-Prozess (`hl_radar.starten`; nicht für Selbsttest-Datenbanken; aus mit `HL_RADAR=0`).
- Liest: `ausblick.db`, `hebel.db`, `swing.db`, `volatil.db`, `makro.db`, Hauptdatenbank. Schreibt nur `radar.db`. Kein Abruf im Netz
  außer dem Push.
- Debug 160 „Risikoradar: Stand als Text“, 161 „Rückblick des Grundrisikos“, 162 „Selbsttest“, 163 (mit 23.123) „Prüfung der Regeln“
  — 163 ist seit 23.122 reserviert. Berichte haben höchstens 150 Zeichen je Zeile.
- Es rechnet nur ein Rückblick zur selben Zeit (Sperre auf einer Datei neben `radar.db`); Debug 161 wartet bis zu 10 Minuten auf einen
  laufenden und zeigt sonst den gespeicherten (Fassung 2, Abschnitt 12 Nr. 7).
- Nach dem Einspielen rechnet der Ausblick einmal sofort, wenn seiner abgelegten Verteilung Tag 2 fehlt (Abschnitt 12 Nr. 8).
- Berichtsplan nach dem Einspielen: 10 Minuten: Debug 160 und 162; 30 Minuten: Debug 161; 12 Stunden: Debug 160.

---

## 9. Proben (Selbsttest ohne Netz)

- Faktor, Schwellen, beide Zahlen von Hand; p7 für BTC gleich dem Kurs-Rechner; Ränder (unter 0,5 %, über 99,5 %, fehlende Rechnung,
  alter Kurs).
- Jede Achse von Hand; Perzentile mit Bindungen; graue Achsen; Index mit vier und mit drei Achsen.
- Rückblick auf erfundenen Märkten: richtig kalibrierte Zahl besteht; zu stark gespreizte Zahl fällt an der Steigung durch; im Mittel
  zu hohe Zahl fällt am Niveau durch (Fassung 2 — die erste Fassung nannte hier „künstlich verdoppelte Zahl fällt an der Steigung
  durch“; das trifft nicht zu, siehe Abschnitt 12 Nr. 1); Zahl ohne Zusammenhang fällt am Skill durch; zu wenige Ereignisse → kein
  Urteil.
- Schwellen und Alarm-Tabelle von Hand; Zustände: Beginn, Ende mit 0,8, Sperrzeit, Entwarnung, Warnzeichen mit 2,8 und 7 Tagen.
- Push an einen nachgebauten Server: Priorität, Text ohne Thema, Schalter aus → nichts gesendet, nicht eingerichtet → nichts gesendet.
  Dazu (Fassung 2) ein echter Versand über `hl_berichte` an einen Webserver auf demselben Rechner.
- Regeln R1–R7 (23.123): jede Regel von Hand, Mantel-Haenszel von Hand, Verschiebung ohne τ = 0, Holm, Hälften, Nullwelten und
  eingepflanzte Effekte.
- Browser: Karte, Radar, graue Achsen, Schalter, Ton und Ansage mit nachgebauter Sprachausgabe, schmaler Bildschirm (390 px).
- Jede Probe mit Mutationstest.

---

## 10. Was das Radar nicht kann

- Einen Schock durch Nachrichten ankündigen.
- Den Zeitpunkt nennen. „Hoch“ heißt: öfter als sonst.
- Mehr sehen, als die Daten hergeben: A5 beruht auf den verfolgten Konten (14–34 % des Open Interest am 18.11.2026, Debug 48).
- Feine Effekte belegen: Ein Risikoverhältnis um 1,2–1,5 ist auf dieser Historie nicht nachweisbar (U142).

---

## 11. Präzisierungen gegenüber der Bewertung (vor jeder Zahl)

1. **Stufen über Perzentile statt über eine Zahl von Alarmen.** Die Zahl der Eintritte fällt nicht gleichmäßig mit der Schwelle
   (eine sehr tiefe Schwelle ergibt einen einzigen langen Zustand). Der Anteil der Tage tut es. Darum 80. und 95. Perzentil; die
   Eintritte je Jahr stehen als Messung im Rückblick.
2. **Sieben Regeln statt neun.** DVOL gegen erwartete Schwankung und Aktienstress entfallen in dieser Runde (weniger Tests, mehr
   Trennschärfe; DVOL hat im Urteil V4 schon nicht getragen, Aktienstress steht als Lampe und in A8). Beide bleiben Kandidaten.
3. **Der Druck-Index zählt fünf Achsen.** Nur sie haben lange Historie; so ist geprüft, was angezeigt wird.
4. **Null der Regeln: Verschiebung statt Vorzeichen-Surrogate.** Das Ereignis misst Tiefs innerhalb des Tages; Surrogate haben nur
   Schlüsse. Die Schwankung wird durch die Schichtung nach σ herausgenommen.
5. **Lieferung in zwei Teilen** (oben).
6. **Sicht des Marktes** (Optionen, Prognosemärkte) kommt mit Paket 2; in 23.122 steht sie nicht in der Karte.

---

## 12. Präzisierungen beim Bau (Fassung 2, 23.11.2026 21:25 — vor jeder Zahl auf echten Daten)

Bis zu diesem Zeitpunkt hat das Modul nur auf erzeugten Reihen gerechnet (Selbsttest und eine Welt in der Größe des Betriebs ohne
echte Kurse). Jede Änderung mit Grund:

1. **Viertes Kriterium „Niveau“ im Rückblick (Abschnitt 3).** Die Steigung der Kalibrierung fängt einen gleichmäßigen Faktor nicht:
   Eine überall um denselben Faktor zu hohe Zahl verschiebt den Achsenabschnitt der Logit-Regression, kaum die Steigung. Die geplante
   Probe „künstlich verdoppelte Zahl fällt an der Steigung durch“ war falsch gedacht — mein Fehler, beim Bau der Probe gefunden.
   Darum zusätzlich: Mittel der Zahl ÷ eingetretene Quote zwischen 0,8 und 1,25. Strenger als die erste Fassung, nicht milder.
2. **A5 und A6 nehmen das Mittel statt des Medians** der Gebote der letzten 60 Minuten und der Stundenwerte. Grund: Das Mittel rechnet
   die Datenbank in einer Abfrage; für den Median müssten rund 1,5 Millionen Zeilen des 5-Sekunden-Rasters in den Speicher. Die letzten
   14 Tage stehen nur im 5-Sekunden-Raster, ältere als Minutenmittel — der Rückgriff braucht beide Tabellen. A6 verlangt mindestens 240
   Stundenmittel (10 Tage), A5 wie festgelegt 14 Tage eigener Stundenwerte (336).
3. **A8 grau statt „0“, wenn eine Lampe grau ist**, die mehr bedeuten könnte als das Bekannte. „0“ hieße „nichts Besonderes“, ohne dass
   es jemand weiß.
4. **Nicht gewählter Coin:** Zustand läuft mit, nichts gilt als gemeldet (Abschnitt 6).
5. **Meldungen im Browser:** einmal je Browser, höchstens 10 Minuten alt, eine Sirene für mehrere Alarme, Entwarnung still (Abschnitt 6).
6. **Karte:** Satz des Rückblicks unter „Beleg“, Zahl matt bis „besteht“, Zeile „Stufe je Coin“ statt eines Punkts im Streifen
   (Abschnitt 7). Grund: Der Streifen gehört zur Antwort des Cockpits; die Zeile der Karte nennt Zahl und Stufe und kommt aus der
   Ablage des Radars. Die Schwelle „hoch“ wählt der Nutzer als „die riskantesten 5 %, 2,5 % oder 1 % der Tage“ (dieselben Perzentile).
7. **Ein Rückblick zur selben Zeit**, Debug 161 wartet (Abschnitt 8). Grund: Takt und Bericht hätten ihn sonst doppelt gerechnet.
8. **Der Ausblick rechnet nach dem Einspielen einmal sofort**, wenn seiner abgelegten Verteilung ein Tag fehlt (Tag 2). Sonst stünde
   die 48-Stunden-Zahl bis zu einer Stunde leer.
9. **Trend im Ausblick:** Die laufende Rechnung des Ausblicks kann einen Trend enthalten, wenn eines seiner Tore offen ist; der
   Rückblick (G7, G2) rechnet ohne Trend, wie S3 des Ausblicks. Enthält die jüngste Rechnung einen, sagt die Karte es in einem Satz.
10. **Zeit in Meldungen:** Ortszeit des Pi mit dem Kürzel der Zeitzone; Berichte bleiben bei UTC.
11. **Debug 163 reserviert** (die Nummer steht in diesem Konzept; der Lauf kommt mit 23.123). Berichte höchstens 150 Zeichen je Zeile.
12. **Grundrate im Rückblick:** Die laufende Grundrate braucht 100 frühere Ursprünge mit abgelaufener Frist — die ersten gewerteten
    Ursprünge liegen darum im April 2022, nicht am 01.01.2022 (Folge der Regel in Abschnitt 3, keine Änderung).
13. **Der Rückblick begrenzt die Zahl wie die Anzeige** (21:30, ebenfalls vor jeder Zahl auf echten Daten): Die Karte kann nur
    Werte zwischen 0,5 % und 99,5 % zeigen (Raster der abgelegten Verteilung; darunter steht „unter 0,5 %“). Der Rückblick rechnet
    darum mit derselben Grenze: Erreicht kein Szenario die Schwelle, zählt der Ursprung mit 0,5 %, nicht mit 0. Geprüft wird so die
    Zahl, die der Nutzer sieht. Ohne die Grenze hinge die Steigung an einem Rechendetail (logit von 0).
14. **Tabelle der Alarme: „Episode gedeckt“ genauer gefasst** (22:04, ebenfalls vor jeder Zahl auf echten Daten; die Tabelle ist
    beschreibend und geht in kein Urteil ein). Eine Ereignis-Episode ist eine Folge aufeinanderfolgender Ursprungstage, nach denen
    das Ereignis in der Frist kam. Gezählt wird, in wie vielen Episoden das Radar an mindestens einem dieser Tage auf „hoch“ stand.
    Die erste Fassung nannte „ohne ‚hoch‘ am Vortag“ — am Tag vor dem ersten Ursprungstag einer Episode liegt das Ereignis aber noch
    außerhalb der Frist; „hoch“ an diesem Tag wäre kein Treffer. Mein Fehler in der Formulierung, beim Schreiben der Dokumente
    gefunden; der Code zählte von Anfang an so wie hier beschrieben.
15. **Der Faden „radar“ übersteht Fehler** (ebenfalls 22:04): Ist `radar.db` beim Start nicht erreichbar oder scheitert ein
    Schritt, meldet der Faden das in der Ausgabe des Dashboards und versucht es beim nächsten Schritt wieder (nach einem Fehler der
    Datenbank mit einer neuen Verbindung). Karte und Debug 160 zeigen in dieser Zeit „Takt: steht seit …“ (kein Schritt seit mehr
    als 15 Minuten); ohne Takt gibt es keinen Alarm.

---

## 13. Fassung 3 (24.11.2026) — erster Rückblick, Regel K, Berichtigung, Präzisierungen zu R1–R7

### 13.1 Was der erste Rückblick auf dem Pi ergab (Debug 161, 24.11.2026 07:12 UTC, Paket 23.122)

| | Ursprünge · Tage · Ereignisse | Skill (p) | Steigung | Niveau | Urteil |
|---|---|---|---|---|---|
| G7 (−10 % · Faktor in 7 Tagen) | 6.888 · 1.676 · 929 | +4,2 % (0,005) | 0,77 | 1,10 | nicht bestätigt (Steigung unter 0,8) |
| G2 (−7 % · Faktor in 48 Stunden) | 6.913 · 1.681 · 515 | +3,6 % (0,003) | 0,81 | 1,14 | besteht |

Beide Zahlen schlagen zu stark aus: In der höchsten Klasse sagte die 7-Tage-Zahl im Mittel 46,3 % und es kamen 32,7 %; die
48-Stunden-Zahl sagte 45,8 % und es kamen 36,1 %. **Meine Erwartung in Abschnitt 3 war falsch herum** (dort: G7 besteht
wahrscheinlich, G2 offen). Die Regel hat gehalten, was sie sollte: Die 7-Tage-Zahl blieb matt, ohne Stufe und ohne Alarm.

### 13.2 Regel K — Nachkalibrierung (Entscheidung des Nutzers vom 24.11.2026 08:52: „Beide nachkalibrieren“)

Abschnitt 3 sagte „keine weitere Korrektur“. Regel K weicht davon ab. Zur Wahl standen „Beide nachkalibrieren“, „Nur die
7-Tage-Zahl“ und „So lassen“.

- **K1 Form.** logit p′ = a + b · logit p. Die Rohzahl p ist wie in der Anzeige auf 0,5 % bis 99,5 % begrenzt, das Ergebnis ebenso.
  a und b kommen aus einer logistischen Regression des Eintritts auf logit p, über alle Coins zusammen, je Ereignis eine. Dieselbe
  Rechnung wie die Steigung im Rückblick.
- **K2 Kausal.** Je Monatserstem M (UTC) eine Anpassung aus allen Ursprüngen, deren Frist bis dahin abgelaufen war (τ + Frist ≤ M).
  Sie gilt für die Ursprünge des Monats M. Verlangt sind mindestens 365 Ursprungstage und 50 Ereignisse; sonst gibt es für diesen
  Monat keine kalibrierte Zahl.
- **K3 Prüfung.** Die kalibrierte Reihe durchläuft denselben Rückblick wie die Rohzahl (G7k, G2k): dieselben vier Kriterien aus
  Abschnitt 3, dieselbe laufende Grundrate, derselbe Bootstrap. Gezählt werden nur Ursprünge mit kalibrierter Zahl.
- **K4 Folge, fest, je Zahl.** Besteht die kalibrierte Fassung **und** liegt die Anpassung des laufenden Monats vor: Karte, Stufen,
  Schwellen und Alarm gelten für die kalibrierte Zahl; die Karte vermerkt „nachkalibriert“ und nennt die Rohzahl; der Kurs-Rechner
  zeigt weiter die Rohzahl. Die Grundrate („üblich“) bleibt die des ganzen Rückblicks. Besteht sie nicht: Hat die Rohzahl bestanden (G2), bleibt alles wie zuvor; hat sie nicht bestanden (G7),
  bleibt die Zahl matt. **Kein dritter Versuch.**
- **K5 Betrieb.** Die Karte rechnet mit a und b des laufenden Monats aus dem jüngsten Rückblick. Der Rückblick wird neu gerechnet,
  sobald der Monat gewechselt hat (zusätzlich zur 30-Tage-Regel). Bis der neue Rückblick fertig ist, gilt die Anpassung des Vormonats
  weiter; der Satz des Urteils nennt das Datum des Rückblicks.
- **K6 Offenlegung.** Regel K ist eine zweite Prüfung auf denselben Daten, auf denen die Rohzahl schon geprüft wurde. Die Form (K1,
  K2) und „nur für die durchgefallene Zahl“ habe ich am 24.11.2026 um 08:32 festgelegt — da kannte ich die beiden Urteile mit Skill,
  Steigung und Niveau, die Tabelle der Klassen noch nicht. Auf beide Zahlen ausgedehnt wurde sie um 08:52, nachdem ich die Tabelle
  gelesen hatte (Debug 161, hochgeladen 08:43) und der Nutzer entschieden hatte. Ein Bestehen von G7k oder G2k wiegt darum weniger
  als ein Bestehen der Rohzahl. Die Bilanz nach vorn (die Stände je Stunde in `radar.db`) ist die unabhängige Prüfung.

### 13.3 Berichtigung der Achsen A5 und A6 (mein Fehler)

Bis 23.122 hießen die Gebote im Hyperliquid-Buch in Konzept, Karte und Bericht „Gebote bis −1 %“. Das stimmt nicht: Der Recorder
abonniert das Buch ohne Rundung der Preisstufen und liest je Seite nur die obersten 10 Preisstufen (`hl_recorder.on_l2book`:
`levels[0][:10]`). Die Spalte `bid_100` ist die Summe dieser Stufen, soweit sie bis −1 % reichen — bei engen Stufen praktisch
dasselbe wie `bid_10`. Aufgefallen ist es an den Zahlen des Pi (Debug 160, 24.11.2026): BTC 1,4 Mio. USD, ETH 4,3 Mio. USD. Dass
BTC weniger Gebote hätte als ETH, passt nicht zu einer Tiefe bis −1 %; es passt zu zehn Preisstufen, die bei BTC enger liegen.
Belegt ist es durch den Code des Recorders. **Gefunden habe ich es erst an den Zahlen des Pi.**

- Ab Fassung 3 heißt die Größe „Gebote der obersten 10 Preisstufen“. Die Karte sagt im Beleg, dass das nicht die Tiefe bis −1 % ist.
- Nicht betroffen: beide Prozentzahlen, Stufen, Alarm, Druck-Index (A5 und A6 zählen dort nicht), die Perzentile der beiden Achsen
  (sie vergleichen die Größe mit sich selbst).
- Betroffen ist die Lesart: „Liquidationen ÷ Gebote“ misst gegen den vordersten Teil des Buchs, nicht gegen die Tiefe bis −1 %.
- Die echte Tiefe bis −1 % braucht eine andere Aufzeichnung (mehr Stufen oder gerundete Stufen) — eigener Planpunkt, nicht in 23.123.
- Nebenbei berichtigt: Die Tabelle `book_summary` hat ein Raster von 30 Sekunden, nicht von 5 (so stand es in Abschnitt 12 Nr. 2). An
  der Rechnung ändert das nichts; sie mittelt die Zeilen je Stunde.

### 13.4 Präzisierungen zu den Regeln R1–R7 (vor jeder Rechnung der Regeln auf echten Daten)

1. **Faktor:** f des Monats, in dem Tag d+1 liegt (der erste Tag der Frist).
2. **Auswertung** ab 01.09.2020 (Beginn der Auswertung der Hebel-Studie), an Tagen mit definierter Schwankung σ.
3. **Schichten:** die Zehntel von σ je Coin über alle Auswertungstage — für BTC und ETH zusammen 20 Schichten.
4. **„Oberstes Zehntel der 365 Tage davor“** (R2, R7): Mittelrang ≥ 0,90 gegen die 365 Tage davor, mindestens 180 Werte. R5 wie in
   U141: Perzentil gegen 90 Tage davor, mindestens 60.
5. **R6 Termine:** Verbraucherpreise und Arbeitsmarktbericht aus `makro.db` (Veröffentlichungstage), Fed-Entscheide aus dem
   Kalender von `hl_volatil` (ab 27.01.2021). R6 ist nur an Tagen definiert, deren Folgetag in allen drei Kalendern liegt. Termine
   kehren im Monatstakt wieder; ein Teil der Verschiebungen der Null trifft deshalb wieder Termine. Die Null ist für R6 darum
   streng — eher zu wenig „belegt“ als zu viel.
6. **R7 Druck-Index auf Tagesschlüssen:** A1 und A2 als Perzentil gegen 90 Tage davor (mindestens 60), A3, A4 und A7 gegen 365 Tage
   davor (mindestens 180); Mittel aus mindestens vier der fünf. Die Stunden-Achsen des Betriebs gibt es in der Historie nicht.
7. **Episoden** je Coin gezählt und summiert. **Kalenderhälften:** geteilt in der Mitte der Spanne, in der die Regel definiert ist.
8. **Band:** Kalender-Blockbootstrap des geschichteten Risikoverhältnisses (60-Tage-Blöcke, für beide Coins dieselben, 1000 Ziehungen).
9. **Ein Urteil:** Der erste Lauf mit vollständig geladener Historie legt das Urteil in `radar.db` ab; spätere Läufe zeigen es und
   rechnen nicht neu. Vorher ist alles „vorläufig“ und nichts gilt.
10. **R7 ist nicht unabhängig von R1 und R5:** Der Druck-Index enthält Kontenquote (A1) und Open Interest (A2). „R7 belegt“ neben R1
    oder R5 ist kein zweiter, eigener Beleg (Messung in 13.5).

### 13.5 Nachweisgrenze (gemessen am 24.11.2026, 08:55 bis 09:17, vor dem echten Lauf)

Je Fall 200 erfundene Märkte (zwei Coins, je 2.520 Tage, alle sieben Regeln, Zeichen ohne Bezug zum Kurs; in den Fällen mit Effekt
folgt auf einen Signaltag von R1 mit einer festen Wahrscheinlichkeit am nächsten Tag ein Tief). Genannt ist das **gemessene**
geschichtete Risikoverhältnis (Median) — die Stärken waren über die Wahrscheinlichkeit eingestellt, nicht auf genau RR 2 und RR 3.

| Fall | R1 belegt für E7 | R1 belegt für E2 |
|---|---|---|
| ohne Effekt: irgendeine der sieben Regeln „belegt“ | 6 % | 7 % |
| häufiges Zeichen (rund 430 Signaltage), RR 1,8 | 49,5 % | 44,5 % |
| häufiges Zeichen, RR 2,7 bzw. 2,8 | 94 % | 96 % |
| häufiges Zeichen, RR 3,4 bzw. 3,8 | 100 % | 99,5 % |
| seltenes Zeichen (rund 100 Signaltage), RR 1,8 bzw. 1,7 | 16 % | 13,5 % |
| seltenes Zeichen, RR 2,6 | 37,5 % | 41,5 % |
| seltenes Zeichen, RR 3,3 bzw. 3,7 | 65 % | 67,5 % |

- Ohne Effekt bleibt der Anteil unter der Grenze von 10 % aus Abschnitt 5.
- Ein seltenes Zeichen mit einem echten RR um 2 bleibt meist unbelegt. „Nicht belegt“ heißt dort „nicht nachweisbar“.
- Mit starkem Effekt nur in R1 (RR 3,4) wurde R7 in 14 von 80 Märkten (E7) und in 7 von 80 (E2) mit belegt; die übrigen Regeln je
  höchstens zweimal.

### 13.6 Anzeige und Berichte ab 23.123

- **Karte:** Eine nachkalibrierte Zahl trägt den Vermerk „nachkalibriert · roh …“; der Beleg erklärt es in einem Absatz. Der Beleg
  nennt das Urteil der Regeln in einem Satz. Der Druck-Index trägt nach dem Urteil den Vermerk „als Warnzeichen geprüft (R7): belegt
  für … / nicht belegt“ statt „ungeprüft“.
- **Achse Umfeld (A8):** Ist sie grau, nennt sie den Grund, den das Cockpit für die graue Lampe angibt.
- **Debug 160** nennt, wo seine Rechenzeit bleibt, und wie lange der letzte Schritt des Takts gedauert hat (auf dem Pi brauchte der
  Bericht für fünf Coins 26 s; gekürzt wird erst nach dieser Messung).
- **Debug 161** hat den Abschnitt „Nachkalibrierung“ mit G7k und G2k. **Debug 163** ist der Lauf der Regel-Prüfung, **Debug 164**
  ihr Selbsttest. Ist die Historie der Hebel-Studie nicht vollständig geladen, sagt Debug 163 „VORLÄUFIG“ und nennt, was offen ist;
  nichts wird abgelegt. Der Plan startet Debug 163 vierzig Minuten nach dem Einspielen und einen Tag danach noch einmal -- der
  zweite Lauf rechnet das Urteil, falls der erste vorläufig blieb, sonst zeigt er das abgelegte.
- An den Prozentzahlen ändert das Urteil der Regeln nichts. Aufschläge sind Paket 2 und brauchen eine eigene Entscheidung.

### 13.7 Entscheidungen des Nutzers vom 24.11.2026 (Auswahl zum Anklicken)

1. 08:25 — Kurse des Fonds IBIT (U293): „Bei Deribit bleiben“. U293 ist damit geschlossen.
2. 08:25 — Probe-Knopf für den Push: „Nein“. Er wird nicht gebaut.
3. 08:52 — Radar-Zahlen: „Beide nachkalibrieren“ (Regel K, 13.2).

---

## 14. Fassung 4 (24.11.2026, abends) — Ergebnisse auf dem Pi, 48 Stunden vorn, Regel A (Aufschlag)

### 14.1 Was Paket 23.123 auf dem Pi ergab (Debug 160, 161 und 163 vom 24.11.2026, 18:37 bis 19:07)

| | Ursprünge · Tage · Ereignisse | Skill (p) | Steigung | Niveau | Urteil |
|---|---|---|---|---|---|
| G7k (7 Tage, nachkalibriert) | 5.728 · 1.386 · 703 | +3,2 % (0,005) | 0,76 | 1,05 | nicht bestätigt |
| G2k (48 Stunden, nachkalibriert) | 5.733 · 1.386 · 387 | +3,3 % (unter 0,001) | 0,98 | 1,09 | besteht |

- **Die 7-Tage-Zahl bleibt matt** (Regel K4, kein dritter Versuch). Ihr Fehler sitzt am unteren Rand: Sagte die kalibrierte Zahl
  „unter 5 %“ (231 von 5.728 Ursprüngen), kam der Rücksetzer in 12 bis 14 % der Fälle — so oft wie üblich. Darüber passen die Klassen
  (7,9 % → 7,8 % · 14,0 % → 12,7 % · 23,5 % → 22,6 %). **Ein niedriger Wert der 7-Tage-Zahl ist keine Entwarnung.**
- **Berichtigung zu 13.1 (mein Fehler):** Dort zeige ich auf die oberste Klasse. Der größere Fehler der 7-Tage-Zahl stand in derselben
  Tabelle unten (0–2 %: 1,2 % vorhergesagt, 13,5 % eingetreten). Eine Gerade im Logit (Regel K1) kann ihn nicht ausgleichen; das habe
  ich vor der Empfehlung „beide nachkalibrieren“ nicht nachgerechnet.
- **Regeln (Debug 163, Urteil abgelegt 24.11.2026 18:07 UTC, BTC und ETH zusammen):** belegt für E7: R1 (RR σ 2,44); belegt für E2:
  R1 (RR σ 2,67; Quote nach Signal 20,7 %, sonst 8,4 %) und R7 (RR σ 2,45; 17,0 % gegen 7,3 %). R2 bis R6 nicht belegt; R4 lief
  andersherum (RR σ 0,6). R1 war schon in U142 belegt — weitgehend dieselben Daten, kein unabhängiger zweiter Beleg.

### 14.2 Entscheidungen des Nutzers vom 24.11.2026, 19:16 (Auswahl zum Anklicken)

1. Karte: **„48 Stunden groß“** (verworfen: „So lassen“, „7 Tage ausblenden“).
2. Belegte Zeichen: **„Aufschlag bauen“** (verworfen: „Nur als Hinweis“, „Nichts ändern“).

### 14.3 Karte ab 23.124

- Die 48-Stunden-Zahl steht groß oben, die 7-Tage-Zahl klein darunter. Solange die 7-Tage-Zahl nicht bestätigt ist, steht bei ihr der
  Satz „Ein niedriger Wert ist keine Entwarnung.“
- Die Zeile „Stufe je Coin“ zeigt die 48-Stunden-Zahl.
- Alarm, Stufen und Ablage je Stunde bleiben, wie sie sind (je Zahl für sich; nur eine bestandene Zahl bekommt Stufen).

### 14.4 Regel A — Aufschlag für belegte Zeichen (fest, vor jeder Rechnung eines Aufschlags auf echten Daten)

Abschnitt 5 legt fest: „Faktor auf die Chance, nach σ geschichtet geschätzt, gedeckelt bei 3; er bleibt nur, wenn die erhöhte Zahl im
Rückblick besser trifft als das Grundrisiko allein.“ Regel A macht das genau.

- **A1 Geltung.** Nur die 48-Stunden-Zahl (E2), nur die Coins des Urteils (BTC, ETH), nur Regeln, die im abgelegten Urteil für E2
  belegt sind (auf dem Pi: R1 und R7). Grundlage ist die nachkalibrierte Zahl (Regel K); besteht sie nicht, gibt es keinen Aufschlag.
  Die 7-Tage-Zahl bekommt keinen Aufschlag, solange sie nicht bestätigt ist.
- **A2 Zustand je Tag** (Schluss 00:00 UTC, je Coin): die **erste** belegte Regel in der Reihenfolge R1 … R7, deren Zeichen ansteht;
  „keins“, wenn keines ansteht; „unbekannt“, wenn eine belegte Regel an dem Tag nicht definiert ist. R1 hat damit Vorrang; R7 zählt
  nur an Tagen ohne R1 — so misst sein Faktor, was der Druck-Index ohne die Kontenquote ab 3 trägt.
- **A3 Faktor je Zustand, kausal.** Je Monatserstem M: aus allen Tagen d von BTC und ETH, deren Frist abgelaufen war (d + 2 < M),
  das Mantel-Haenszel-**Chancenverhältnis** des Ereignisses E2 zwischen dem Zustand und „keins“, geschichtet nach Coin und Zehntel der
  Schwankung (die Zehntel nur aus den Tagen bis dahin). Verlangt sind mindestens 365 Tage mit bekanntem Zustand, im Zustand mindestens
  30 Tage in 5 Episoden und 30 Tage „keins“; sonst ist der Faktor 1. Der Faktor liegt zwischen 1 und 3 (gedeckelt wie in Abschnitt 5).
  Dazu je Coin der Anteil π der Tage in jedem Zustand (aus denselben Tagen).
- **A4 Anwendung, im Mittel neutral.** Aus der nachkalibrierten Zahl p′ wird die Chance o₀ für „keins“ so bestimmt, dass das Mittel
  über die Zustände wieder p′ ergibt: Σ π_r · P(F_r · o₀) + π₀ · P(o₀) = p′ mit P(o) = o ÷ (1 + o). Gezeigt wird P(F · o₀) für den
  Zustand des Tages (F = 1 bei „keins“), begrenzt auf 0,5 % bis 99,5 %. Bei „unbekannt“ bleibt p′. **Folge in Worten:** Steht ein
  Zeichen an, steigt die Zahl; steht keines an, liegt sie etwas unter p′. Ein reiner Aufschlag würde die Zahl im Mittel zu hoch
  machen (Kriterium „Niveau“) — das ist die eine Abweichung vom Wortlaut „Aufschlag“ in Abschnitt 5.
- **A5 Prüfung (G2a).** Der Rückblick rechnet die Zahl mit Aufschlag an jedem Ursprung von BTC und ETH (Zustand des Vortags, Faktoren
  und Anteile des Monats des Ursprungs); die anderen Coins bleiben bei p′. Sie **besteht**, wenn (a) die Reihe dieselben vier
  Kriterien erfüllt wie G2k und (b) sie auf denselben Ursprüngen besser trifft als p′ allein: mittlerer Brier-Unterschied über 0 mit
  p unter 0,05 (derselbe Block-Bootstrap wie beim Skill: Blöcke von 28 Tagen, 2000 Ziehungen).
- **A6 Folge, fest.** Besteht G2a und liegen die Faktoren des laufenden Monats vor: Karte, Stufen, Schwellen und Alarm gelten für die
  Zahl mit Aufschlag (Schwellen aus ihrer Verteilung im Rückblick je Coin); die Karte nennt das Zeichen und die Zahl ohne es. Besteht
  G2a nicht: Die Zahl bleibt p′; ein anstehendes belegtes Zeichen steht als Hinweis in der Karte. **Kein weiterer Versuch auf diesen
  Daten** — danach entscheidet die Bilanz nach vorn.
- **A7 Betrieb.** Der Zustand kommt einmal am Tag aus den Tagesreihen der Regel-Prüfung (letzter voller Tag) und liegt in `radar.db`.
  Ist er älter als zwei Tage, gilt „unbekannt“. Die Ablage je Stunde hält Zustand und Zahl ohne Aufschlag fest.
- **A8 Offenlegung.** G2a ist die dritte Prüfung der 48-Stunden-Zahl auf denselben Daten (G2, G2k, G2a). R1 wurde auf diesen Daten
  gefunden (U142) und auf ihnen bestätigt (Debug 163). Ein Bestehen wiegt entsprechend weniger; unabhängig ist erst die Bilanz nach
  vorn.

### 14.5 Was ich beim Festlegen von Regel A wusste

Die Tabellen von Debug 161 und Debug 163 vom 24.11.2026 (Urteile, Quoten nach Signal und sonst, RR je Coin, Signaltage), nicht aber:
wie oft R1 und R7 am selben Tag anstehen, die Chancenverhältnisse je Monat, irgendeine Zahl mit Aufschlag. Aus den Quoten nach
Signal habe ich überschlagen, dass ein reiner Aufschlag das Niveau von 1,09 auf etwa 1,2 und darüber heben würde — daher A4.
Gerechnet wurde Regel A bis zur Lieferung von 23.124 nur auf erzeugten Reihen.

### 14.6 Nachweis vor dem echten Lauf

Vor dem ersten Lauf auf dem Pi wird auf erfundenen Reihen gemessen, wie oft G2a besteht, wenn das Zeichen nichts trägt (soll selten
sein) und wenn es ein Chancenverhältnis von 2,5 trägt. Die Zahlen stehen im Bericht (Debug 161) und im Selbsttest (Debug 162).

**Gemessen am 24.11.2026, 22:52:57 bis 23:03:46 (649 s auf zwei Kernen), vor jeder Rechnung von Regel A auf echten Daten.** Je Fall
400 erfundene Reihen: der Markt der Regel-Prüfung (`welt_bauen`, zwei Coins, 2.520 Tage, Zeichen ohne Bezug zum Kurs), je Tag ein
Ursprung um 00:00 UTC des Folgetags mit einer Rohzahl aus der Tagesschwankung, Ursprünge nur aus den letzten 1.681 Tagen (so viele
Ursprungstage hatte G2 auf dem Pi, davon 1.386 nachkalibriert), Faktoren aus der ganzen Historie; darauf der ganze Rückblick mit
Regel K und Regel A, Code wie geliefert (`auf_nachweis` in `hl_radar.py`). Ein Effekt wird eingepflanzt, indem nach einem Tag mit
anstehendem Zeichen ein Tief am Folgetag die Chance des Ereignisses auf das 1,75-Fache hebt; das gemessene Chancenverhältnis liegt
höher (ein eingepflanztes Tief löst auch das Ereignis des Vortags aus) und steht in der Tabelle. Gezählt sind nur Reihen, in denen
die Zahl ohne Aufschlag (G2k) bestand -- ohne sie gibt es keinen Aufschlag (A1), auf dem Pi besteht sie.

| Fall | Reihen mit bestandener Grundlage | davon mit geltendem Aufschlag |
|---|---|---|
| Die Zeichen tragen nichts | 149 | 1 |
| Nur R1 trägt (gemessenes Chancenverhältnis 2,4) | 173 | 32 |
| R1 und R7 tragen (je 2,4) | 215 | 66 |

Je Fall 400 erfundene Reihen. Ohne Effekt galt der Aufschlag in 0,7 % der Reihen, mit einem Effekt in R1 in 18,5 %, mit einem Effekt
in R1 und R7 in 30,7 % (Median des gemessenen Chancenverhältnisses: R1 2,35; im dritten Fall R1 2,37 und R7 2,45). G2a allein
bestand meist (133, 150 und 187 Reihen) -- entscheidend ist „trifft besser“ (1, 35 und 67 Reihen). **Folgerung, vorab
festgehalten:** Die Prüfung ist streng: Ein Aufschlag ohne Wirkung kommt selten durch. Sie ist aber schwach: Selbst Zeichen der Stärke,
die Debug 163 auf dem Pi zeigte (R1 für 48 Stunden: Risikoverhältnis 2,67; R7: 2,45), bestehen sie in diesen Reihen nur in etwa jedem
fünften bis dritten Fall. Besteht der Aufschlag auf dem Pi nicht, heißt das „nicht nachweisbar“, nicht „wirkt nicht“; die Karte zeigt
dann das anstehende Zeichen als Hinweis (A6). Die Regel bleibt, wie sie in 14.4 steht -- die Messung ändert sie nicht.

---

## 15. Fassung 5 (25.11.2026) — Regel A auf dem Pi, Tiefe bis −1 % für A5 und A6 (U311)

### 15.1 Was Paket 23.124 auf dem Pi ergab (Rückblick vom 25.11.2026, 06:35 UTC; Debug 160 und 161)

- **G2a (mit Aufschlag):** 5.738 Ursprünge · 1.387 Tage · 387 Ereignisse, Skill +3,7 % (p 0,001), Steigung 0,91, Niveau 1,14 — die vier
  Kriterien erfüllt. Gegen die Zahl ohne Aufschlag (5.839 Ursprünge, 2.774 davon mit geänderter Zahl): Brier 0,06015 gegen 0,06043,
  Unterschied +2,7 · 10⁻⁴, p 0,257 — **nicht bestätigt**. Nach A6 bleibt die Karte bei der nachkalibrierten Zahl; ein anstehendes belegtes
  Zeichen steht als Hinweis da. **Kein weiterer Versuch auf diesen Daten.** Erwartet war das (14.6: auch mit echtem Effekt bestand der
  Aufschlag nur in 18,5 bis 30,7 % der erfundenen Reihen).
- Faktoren: R1 in 54 Monaten 2,31 bis 3,00 (laufender Monat 3,00 bei einem Chancenverhältnis von 4,29 — der Deckel greift), R7 in
  50 Monaten 2,58 bis 3,00 (laufender Monat 2,98). Ursprünge von BTC und ETH nach Zustand des Vortags: R1 310, R7 262, keins 2.202.
- Mit Aufschlag zu hoch über 20 %: 258 Ursprünge mit 25,3 % vorhergesagt, eingetreten 18,2 %.
- **Niveau 1,14 statt 1,09 — Offenlegung, mein Versäumnis.** A4 hält das Mittel nur, wenn die Zeichen unabhängig von der Zahl ohne
  Aufschlag anstehen und die Anteile der früheren Tage für die geprüften gelten. R7 enthält die Schwankung, und die Zahl ohne Aufschlag
  steigt mit ihr: Dass die Zeichen eher an Tagen mit hoher Zahl anstehen, hatte ich beim Festlegen von A4 nicht bedacht (Anteile je
  Zehntel der Schwankung, wie beim Chancenverhältnis, hätten das weitgehend aufgefangen). Die Anteile an den Ursprüngen (R1 11,2 %,
  R7 9,4 %) liegen nahe bei denen des laufenden Monats; ob die früherer Monate tiefer lagen, zeigt der Bericht nicht. Ab 23.125 nennt
  Debug 161 je Coin und Zustand die Ursprünge, das Mittel der Zahl ohne Aufschlag und den angewandten Anteil — beschreibend, keine neue
  Prüfung. Am Urteil ändert das nichts.

### 15.2 Entscheidung des Nutzers vom 25.11.2026 (Auswahl zum Anklicken)

**„Tiefe richtig messen“** (U311) — verworfen: „Sicht des Marktes“ (U309), „Erst Hänger-Schutz“ (U287, nach Debug 157 vom 25.11. abends).

### 15.3 Messung der Tiefe bis ±1 % (Recorder, Aufgabe „Buch-Tiefe“)

- Je Minute und verfolgtem Coin eine Abfrage `l2Book` mit gerundeten Preisstufen (`nSigFigs`: 2 bis 5 Stellen oder ungerundet; die
  Börse liefert höchstens 20 Stufen je Seite; Gewicht 2 — Dokumentation der Börse, nachgeschlagen am 25.11.2026). Eine Abfrage statt
  eines zweiten Abos: Die Nachrichten des Buchs nennen die Rundung nicht, zwei Abos desselben Coins wären nicht zu unterscheiden.
- **Stellen:** die feinsten, bei denen 19 Stufen noch 1 % des Kurses überdecken (die erste Stufe ist angebrochen). Bei den Kursen vom
  25.11.2026: BTC, HYPE, ZEC und XMR 3 Stellen (Stufen zu 100, 0,1, 1 und 1 USD — 0,14 bis 0,2 % des Kurses), ETH 4 Stellen (1 USD,
  0,06 %; so bis 1.900 USD, darüber 3 Stellen).
- **Gezählt:** Gebote mit einem Preis ab 99 % der Mitte, Forderungen bis 101 % (Preis der Stufe mal Menge). Die Mitte kommt aus dem
  ungerundeten Buch (höchstens 60 s alt), sonst aus der gerundeten Antwort. Eine Seite ist vollständig, wenn weniger als 20 Stufen kamen
  oder die letzte jenseits der Grenze liegt; sonst sofort eine zweite Abfrage eine Stelle gröber, danach eine Stunde lang gleich gröber.
- **Gespeichert:** Tabelle `book_tiefe` (ts, coin, nsig, schritt, mitte, bid_1, ask_1, stufen_b, stufen_a, voll), 35 Tage. Kosten:
  12 Gewicht je Minute für sechs Coins (1 % des Budgets von 1.200); eine Antwort hat rund 2 KB (geschätzt, nicht gemessen).
- **Genauigkeit:** auf ganze Stufen — die Stufe an der Grenze zählt ganz oder gar nicht (eine Stufe ist 0,05 bis 0,5 % des Kurses).
- Bericht **Debug 165** (je Coin Stufen, Stand, letzte Stunde und letzter Tag, Vergleich mit den obersten 10 Stufen), Selbsttest
  **Debug 166**. `book_summary` (die obersten 10 Stufen des ungerundeten Buchs) bleibt, wie sie ist — andere Module lesen sie.

### 15.4 A5 und A6 ab 23.125

- **A6 Markttiefe:** Gebote bis −1 % — Mittel der vollständigen Zeilen der letzten 60 Minuten (mindestens 30), 100 − Perzentil gegen die
  Stundenmittel der letzten 30 Tage aus `book_tiefe` (mindestens 240). Nach dem Einspielen rund 10 Tage grau.
- **A5 Liquidations-Nähe:** Long-Positionswert mit Liquidationspreis bis −5 % ÷ Gebote bis −1 % (derselbe Wert wie A6). Der eigene
  Verlauf zählt erst ab der ersten Stunde, die mit 23.125 abgelegt wurde (rd_meta „tiefe_ab“) — die älteren Werte hatten einen anderen
  Nenner. Nach dem Einspielen 14 Tage grau (336 Stundenwerte).
- Nicht betroffen: beide Prozentzahlen, Stufen, Alarm, Druck-Index (A5 und A6 zählen dort nicht), die Prüfung der Regeln R1–R7.
- Lesart: „Liquidationen ÷ Gebote“ misst jetzt gegen die Tiefe bis −1 %, wie es Fassung 2 vorsah.
