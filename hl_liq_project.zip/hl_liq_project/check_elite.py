#!/usr/bin/env python3
"""
check_elite.py -- Ist die Elite-Positionierung richtig erfasst und berechnet?

Für einen Coin: Wer ist in der Elite (die zehn Konten mit dem höchsten Konto-Score, die im Coin
Schritte hatten)? Welche Klasse hat jedes Konto kontoweit UND in diesem Coin? Welche Position
hält es laut lb_positions (Leaderboard-Schnappschuss) und laut whale_positions (Poller-Ereignisse),
wie alt sind die Stände, stimmen beide Quellen überein? Daraus der Treiber -- einmal wie bisher
(alle Elite-Positionen), einmal nur mit Konten, die in diesem Coin direktional sind -- und der
Anteil des größten Kontos am Bruttowert (Dominanz).

Mit --live wird jedes Elite-Konto einmal live abgefragt (clearinghouseState, 2 Gewicht je Konto):
Seite und Wert im Coin gegen die Datenbank -- so fallen veraltete oder falsche Stände auf.

23.39: Einstufung wie im Dashboard (hl_viz.score_klasse: Verhalten im Coin zuerst, Unbekannte neutral) und ohne Konten, die die
Masterregel gesperrt hat (vorher zeigte das Werkzeug gesperrte Konten in der Elite, das Dashboard nicht). Dazu die Elite, die
das Dashboard gespeichert hat und die Treiber, Recorder-Vorrang und „Elite live folgen“ im Labor tatsächlich nutzen.

    python3 check_elite.py --db /media/seed/marketdatabase/hl_liq/hl_liq.db --coin BTC [--live]
"""
import argparse
import json
import os
import sqlite3
import time
import urllib.request

import hl_forecast
import hl_score
import hl_viz

API = "https://api.hyperliquid.xyz/info"


def live_position(addr: str, coin: str) -> tuple | None:
    body = json.dumps({"type": "clearinghouseState", "user": addr}).encode()
    req = urllib.request.Request(API, data=body, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            d = json.loads(r.read())
    except Exception as e:
        return ("Fehler", 0.0, str(e)[:60])
    for ap in d.get("assetPositions") or []:
        p = ap.get("position") or {}
        if p.get("coin") == coin:
            szi = float(p.get("szi") or 0)
            return ("long" if szi > 0 else "short" if szi < 0 else "flat", float(p.get("positionValue") or 0), "")
    return ("flat", 0.0, "")


def elite_gespeichert(db: str, coin: str) -> tuple:
    """Die vom Dashboard gespeicherte Elite des Coins (forecasts.db neben der Datenbank, nur lesen): (Liste, Zeitpunkt) oder (None, None)."""
    kand = [os.path.join(os.path.dirname(os.path.abspath(db)), "forecasts.db"), hl_forecast.STORE]
    for pfad in kand:
        if not os.path.exists(pfad):
            continue
        try:
            st = sqlite3.connect(f"file:{pfad}?mode=ro", uri=True)
            row = st.execute("SELECT value, updated FROM learned WHERE coin=? AND key='elite'", (coin,)).fetchone()
            st.close()
        except sqlite3.Error:
            continue
        if row:
            try:
                v = json.loads(row[0])
            except ValueError:
                v = []
            return [str(a).lower() for a in (v if isinstance(v, list) else []) if isinstance(a, str)], row[1]
    return None, None


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--coin", default="BTC")
    p.add_argument("--live", action="store_true", help="Elite-Konten live abfragen (2 Gewicht je Konto)")
    a = p.parse_args()
    coin = a.coin.upper()
    con = hl_viz.connect(a.db)
    now = int(time.time())

    # 23.39: Klassen genau wie im Lernzyklus des Dashboards; Leaderboard-Gruppe je Coin für die Spalte „im Coin“
    klasse_of = hl_viz.score_klasse(con, coin)
    lbg = hl_forecast.lb_groups(con, coin)

    print(f"Elite-Positionierung {coin} · {time.strftime('%d.%m.%Y %H:%M')}")
    sc = hl_score.compute_scores(con, coin, klasse_of)
    if not sc:
        print("Kein Konto-Score berechenbar (zu wenig Schritte/Kennzahlen)."); return
    G = hl_viz.gesperrte_konten(con)                                     # 23.39: Masterregel wie im Dashboard -- Gesperrte ohne Score/Elite
    ohne_sperre = [a_ for a_ in hl_score.elite(sc, 10) if a_.lower() in G]
    sc = {a_: v_ for a_, v_ in sc.items() if a_.lower() not in G}
    if ohne_sperre:
        print(f"Masterregel: gesperrt und deshalb nicht in der Elite: {', '.join(a_[:6] + '…' + a_[-4:] for a_ in ohne_sperre)} "
              f"({len(G)} Konten gesperrt oder vorläufig ausgeschlossen)")
    gf = hl_score.elite_filter(con, coin, set(sc))                      # Gewinn- und Aktivitätsschranke
    elite = hl_score.elite(sc, 10, gewinn=gf)
    elite_alt = hl_score.elite(sc, 10, min_n=1, min_t=-99)
    ohne_gewinn = [a for a in hl_score.elite(sc, 10) if a not in elite]
    if ohne_gewinn:
        print("Gewinn-/Aktivitätsschranke schließt aus: " + "; ".join(f"{a[:6]}…{a[-4:]} ({gf[a]['grund']})" for a in ohne_gewinn))
    ohne_beleg = [a for a in elite_alt if a not in elite]
    if ohne_beleg:
        print(f"Ohne Beleg-Regel (ein Schritt, Vorzeichen genügt) wären dabei: {', '.join(a[:6] + '…' + a[-4:] for a in ohne_beleg)}"
              f" — ausgeschlossen (unter {hl_score.ELITE_MIN_SCHRITTE} Schritte, kein positiver Vorlauf oder t < {hl_score.ELITE_MIN_T})")
    if not elite:
        print("Elite ist LEER: kein Konto erfüllt n >= 10, Vorlauf > 0 und t >= 1 — der Treiber Elite-Positionierung entfällt, bis Konten Beleg haben.")
    dir_addrs = hl_forecast.lb_directional_addrs(con, coin)
    names = {r[0].lower(): r[1] for r in con.execute("SELECT addr, name FROM lb_names") if r[1]} if "lb_names" in {r[0] for r in con.execute("SELECT name FROM sqlite_master")} else {}

    last = con.execute("SELECT MAX(ts) FROM lb_positions").fetchone()[0] or 0
    n_ts = con.execute("SELECT COUNT(DISTINCT ts) FROM lb_positions WHERE ts >= ?", (last - 120,)).fetchone()[0]
    print(f"Leaderboard-Schnappschuss: ts {time.strftime('%H:%M:%S', time.localtime(last))} (vor {(now - last) / 60:.0f} min) · "
          f"{'EIN Zeitstempel' if n_ts <= 1 else str(n_ts) + ' Zeitstempel binnen 2 min (Achtung: WHERE ts=MAX(ts) sähe nur den letzten)'}"
          + ("  <- ÄLTER ALS 5 MIN: Leaderboard-Zyklus hängt oder ist gedrosselt (Soll 90-120 s)" if now - last > 300 else ""))
    print(f"Elite (frisch gerechnet): {len(elite)} Konten · davon in {coin} direktional (Leaderboard-Gruppe): {sum(1 for e in elite if e in dir_addrs)}")
    gesp, upd = elite_gespeichert(a.db, coin)
    if gesp is None:
        print("Elite im Einsatz: nichts gespeichert (das Dashboard stellt sie im Lernzyklus einmal täglich je Coin auf)\n")
    else:
        nur_f = [x for x in elite if x not in gesp]; nur_g = [x for x in gesp if x not in elite]
        kz = lambda x: names.get(x) or (x[:6] + "…" + x[-4:])
        print(f"Elite im Einsatz (vom Dashboard gespeichert{', Stand ' + time.strftime('%d.%m. %H:%M', time.localtime(int(upd))) if upd else ''}; "
              f"Treiber, Recorder-Vorrang und „Elite live folgen“): {len(gesp)} Konten"
              + (f" · nur frisch gerechnet: {', '.join(kz(x) for x in nur_f)}" if nur_f else "")
              + (f" · nur gespeichert: {', '.join(kz(x) for x in nur_g)}" if nur_g else "")
              + (" · gleich" if not nur_f and not nur_g else "")
              + (f" · davon inzwischen gesperrt: {', '.join(kz(x) for x in gesp if x in G)} (das Labor kopiert sie nicht)" if any(x in G for x in gesp) else "")
              + "\n")

    print(f"{'Konto':<16}{'Score':>6} {'Klasse':<9} {'im Coin':<8} {'n':>3} {'α4h':>7} {'t':>5} {'uPnL':>7} {'PnL30':>7} {'Tr/T':>5} │ {'lb_positions':<22} {'whale_positions':<28}" + (" │ live" if a.live else ""))
    ul_alt = us_alt = 0.0; ul_neu = us_neu = 0.0; groesste = []
    for addr in elite:
        info = sc.get(addr, {})
        lbpos = con.execute("SELECT side, pos_value FROM lb_positions WHERE ts=? AND coin=? AND lower(addr)=?", (last, coin, addr)).fetchone()
        wp = con.execute("""SELECT event, side, pos_value, ts FROM whale_positions w WHERE w.coin=? AND lower(w.addr)=?
                            AND w.ts = (SELECT MAX(ts) FROM whale_positions x WHERE x.addr=w.addr AND x.coin=w.coin)""", (coin, addr)).fetchone()
        # Regel der Prognose: Leaderboard-Stand vor Wal-Stand; Wal nur wenn letztes Ereignis kein close
        quelle = None
        if lbpos:
            side, val = lbpos[0], lbpos[1] or 0.0; quelle = "lb"
        elif wp and wp[0] != "close":
            side, val = wp[1], wp[2] or 0.0; quelle = "wal"
        else:
            side, val = "flat", 0.0
        if val > 0:
            (ul_alt if side == "long" else us_alt)  # noqa -- nur zur Lesbarkeit
            if side == "long":
                ul_alt += val
            else:
                us_alt += val
            groesste.append((val, addr, side))
            kl_coin = "dir" if addr in dir_addrs else klasse_of(addr)
            if addr in dir_addrs or info.get("klasse", 0) >= 1.0:
                if side == "long":
                    ul_neu += val
                else:
                    us_neu += val
        lbtxt = f"{lbpos[0]} {lbpos[1] / 1e6:.1f} Mio" if lbpos else "—"
        wptxt = f"{wp[0]} {wp[1]} {(wp[2] or 0) / 1e6:.1f} Mio vor {(now - wp[3]) / 3600:.1f} h" if wp else "—"
        widerspruch = " ≠" if (lbpos and wp and wp[0] != "close" and lbpos[0] != wp[1]) else ""
        zeile = (f"{(names.get(addr) or addr[:6] + '…' + addr[-4:]):<16}{info.get('score', 0):>6.2f} {klasse_of(addr):<9} {('dir' if addr in dir_addrs else lbg.get(addr, '?')):<8} "
                 f"{info.get('n') or 0:>3} {(info.get('alpha_4h') if info.get('alpha_4h') is not None else 0) * 100:>+6.2f}% {(info.get('t_4h') if info.get('t_4h') is not None else 0):>+5.1f} "
                 f"{(format(gf.get(addr, {}).get('upnl_pct') * 100, '+.1f') + '%') if gf.get(addr, {}).get('upnl_pct') is not None else '—':>7} "
                 f"{(format(gf.get(addr, {}).get('pnl_30d') / 1e6, '+.1f') + 'M') if gf.get(addr, {}).get('pnl_30d') is not None else '—':>7} "
                 f"{gf.get(addr, {}).get('trades_tag') if gf.get(addr, {}).get('trades_tag') is not None else '—':>5} │ {lbtxt:<22} {wptxt:<28}{widerspruch}")
        if a.live:
            lv = live_position(addr, coin); time.sleep(0.3)
            abw = "" if lv[0] == side or (lv[0] == "flat" and val == 0) else "  <- WEICHT AB"
            zeile += f" │ {lv[0]} {lv[1] / 1e6:.1f} Mio{abw}{(' ' + lv[2]) if lv[2] else ''}"
        print(zeile)

    brutto = ul_alt + us_alt
    print()
    if brutto > 0:
        groesste.sort(reverse=True)
        anteil = groesste[0][0] / brutto
        print(f"Treiber wie bisher (alle Elite-Positionen): long {ul_alt / 1e6:.1f} Mio, short {us_alt / 1e6:.1f} Mio → Score {(ul_alt - us_alt) / brutto:+.2f}")
        print(f"  Dominanz: größtes Konto {groesste[0][1][:6]}… hält {anteil:.0%} des Bruttowerts ({groesste[0][2]} {groesste[0][0] / 1e6:.1f} Mio)"
              + ("  <- ein Konto ist das Signal" if anteil > 0.6 else ""))
    if ul_neu + us_neu > 0:
        print(f"Treiber nur mit im Coin direktionalen Konten: long {ul_neu / 1e6:.1f} Mio, short {us_neu / 1e6:.1f} Mio → Score {(ul_neu - us_neu) / (ul_neu + us_neu):+.2f}")
    else:
        print("Nur mit direktionalen Konten: keine Position -- Treiber würde entfallen")
    # Vergleich mit Smart Money (direktional), derselbe Schnappschuss
    nl = ns = 0; ULs = USs = 0.0; net: dict = {}
    for addr_, c_, side_, val_ in con.execute("SELECT addr, coin, side, pos_value FROM lb_positions WHERE ts=? AND rank<=50", (last,)):
        if addr_.lower() in dir_addrs and c_ == coin:
            net[addr_.lower()] = net.get(addr_.lower(), 0.0) + (val_ or 0) * (1 if side_ == "long" else -1)
    for v in net.values():
        if v > 0: nl += 1; ULs += v
        elif v < 0: ns += 1; USs += -v
    if ULs + USs > 0:
        print(f"Zum Vergleich Smart Money (direktional, Top-50): {nl} long {ULs / 1e6:.1f} Mio gegen {ns} short {USs / 1e6:.1f} Mio → {(ULs - USs) / (ULs + USs):+.2f}")
    print("\nLesart: Steht 'Klasse' (wie im Konto-Score: Verhalten im Coin, sonst kontoweit, sonst Leaderboard-Gruppe) auf mixed/hedge/mm oder")
    print("        'im Coin' nicht auf dir, zählt die Position in der korrigierten Fassung nicht.")
    print("        '≠' = Leaderboard- und Poller-Stand widersprechen sich; 'WEICHT AB' = Datenbank gegen Live-Abfrage.")


if __name__ == "__main__":
    main()
