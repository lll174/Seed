"""
Treiberfamilien (24.09.2026, Wunsch des Nutzers) -- Parallelbetrieb neben der bisherigen Prognose, ändert an ihr nichts.

Die acht Vorschläge aus der Treiber-Durchsicht, alle je Coin (jeder Coin hat seine eigene Dynamik):
  1. Familien statt Einzelstimmen: je Familie der Mittelwert ihrer Treiber (Werte aus forecast_drivers, 15-min-Raster).
     Das beseitigt die Mehrfachzählung ähnlicher Treiber, die v2 übersichert.
  2. Jede Familie auf ihrem eigenen Zeithorizont (1 h, 4 h oder 24 h) bewertet; die anderen Horizonte zum Vergleich.
  3. Ereignisse: zusätzlich nur Fälle mit |Familienwert| >= 0,5 -- viele Treiber sagen nur an den Extremen etwas.
  4. Richtung und Stärke getrennt: die Familie „Stärke“ sagt voraus, OB eine große Bewegung kommt (|Rendite| >= 1,5 σ).
  5. Gewicht nur gegen Beleg (Darwin für Familien): Kandidat -> Bewährung -> aufgestiegen, wöchentlich, erst nach zwei
     belegten Wochen in Folge; Abstieg nach zwei schlechten. Ohne aufgestiegene Familie nennt die Familien-Prognose die
     Basisrate -- ehrlich statt geraten.
  6. Treiber-Hygiene: läuft ein Treiber nur nach (erklärt die Vergangenheit statt der Zukunft), ist er umgekehrt, tot?
  7. Profi-Flow: Netto-Handel der Darwin-Liste (Live-Fills), ab jetzt alle 15 min aufgezeichnet (keine Rückrechnung:
     die Liste selbst ist nach Leistung ausgewählt -- rückwirkend angewandt wäre das ein Blick in die Zukunft).
  8. Kennzahlenkarte: Vorsprung gegen den Zufall, ungesehene Daten (letztes Drittel), Wochenstabilität,
     Überschneidung mit anderen Familien, Wochen ohne Nutzen.
"""
import json
import math
import os
import sqlite3
import sys
import time
import warnings

import hl_forecast as F

FAMILIEN = {
    "Großkonten-Fluss": {"treiber": ["Wal-Flow 30 min", "Leaderboard-Flow 60 min", "Smart-Flow 4 h", "Smart Money (direktional)",
                                     "Direktionale Wale", "Käufe/Verkäufe 24 h (direktional)", "Top-20-Trend 24 h",
                                     "Elite-Positionierung", "Gegen-Flow"], "h": 4, "art": "richtung"},
    "Trend lang": {"treiber": ["MA 200 Tage", "MA 50 Wochen", "7-Tage-Drift"], "h": 24, "art": "richtung"},
    "Momentum kurz": {"treiber": ["60-min-Trend", "RSI 14 (1 h)", "Vol-Spike-Reversion"], "h": 1, "art": "richtung"},
    "Orderfluss": {"treiber": ["Taker-Flow", "Spot-Taker-Flow", "Orderbuch", "Spot-Orderbuch"], "h": 1, "art": "richtung"},
    "Funding": {"treiber": ["Funding", "Funding-Spread"], "h": 24, "art": "richtung"},
    "ETF": {"treiber": ["ETF-Flows", "ETF-Momentum"], "h": 24, "art": "richtung"},
    "Analog": {"treiber": ["Analog-Suche"], "h": 24, "art": "richtung"},
    "Pool-Konten": {"treiber": ["Pool-Positionierung", "Pool-Flow 4 h", "Pool-Timing-Flow"], "h": 4, "art": "richtung"},   # 23.27
    "Kaskaden": {"treiber": ["Kaskaden-Asymmetrie"], "h": 4, "art": "richtung"},   # 23.43: Kaskaden-Gleichung (hl_kaskade), Schatten
    "Profi-Flow": {"treiber": [], "h": 4, "art": "richtung", "live": True},
    "Stärke": {"treiber": ["OI-Überhitzung", "Crowding-Extrem", "Crowding-Trend 7 T", "Liquidationsdruck (3 Börsen)", "Kapitulation"],
               "h": 4, "art": "staerke"},
}
AUSGESCHLOSSEN = {"Coinbase-Prämie": "Konstruktionsfehler: gegen den HL-Perp gemessen, vermischt Coinbase-Nachfrage mit dem Funding-Aufschlag "
                                     "-- außen vor bis zum Neubau gegen Binance-Spot (U56)"}
RASTER = 900
HORIZONTE = (1, 4, 24)
SCHWELLE = 0.15                 # Richtung: Familie „spricht“ ab diesem Betrag
SCHWELLE_EREIGNIS = 0.5         # Ereignis: nur die Extreme
GROSS_K = 1.5                   # große Bewegung: |Rendite| >= 1,5 σ des Horizonts
TAGE = 60
PROFI_MIN_USD = 50_000


def _np():
    import numpy as np
    return np


# ------------------------------------------------------------------------------------------------ Daten
def raster(con_main, st, coin: str, t_von: int, t_bis: int):
    """15-min-Raster wie die Ereignis-Profile: Kurse (mit 7 Tagen Vorlauf) und Treiberwerte (U41 berücksichtigt)."""
    import hl_konstellation as K
    return K._profil_raster(con_main, st, coin, t_von, t_bis, F.cb_seite_ab(con_main))


def familienwerte(S, namen, P, sig) -> dict:
    """Je Familie ein Wert je Rasterpunkt: Mittel der Treiber; „Stärke“ aus Beträgen plus Ruhe vor dem Sturm."""
    np = _np()
    j = {n: i for i, n in enumerate(namen)}; out = {}
    with warnings.catch_warnings(), np.errstate(all="ignore"):
        warnings.simplefilter("ignore", category=RuntimeWarning)
        for f, d in FAMILIEN.items():
            if d.get("live"):
                continue
            cols = [j[n] for n in d["treiber"] if n in j]
            M = S[:, cols] if cols else np.full((len(P), 0), np.nan)
            if d["art"] == "staerke":
                M = np.abs(M)
                lp = np.log(P); r = np.diff(lp, prepend=np.nan); r2 = np.where(np.isnan(r), 0.0, r * r)
                cs = np.concatenate([[0.0], np.cumsum(r2)]); jetzt = np.full(len(P), np.nan)
                jetzt[16:] = np.sqrt(cs[16:len(P)] - cs[:len(P) - 16])            # realisierte 4-h-Schwankung
                ruhe = np.clip(1.0 - jetzt / sig, 0.0, 1.0)                       # ruhiger als sonst = Spannung baut sich auf
                M = np.column_stack([M, ruhe]) if M.shape[1] else ruhe[:, None]
            out[f] = np.nanmean(M, axis=1) if M.shape[1] else np.full(len(P), np.nan)
    return out


def profi_reihe(st, coin: str, g0: int, n: int):
    """Aufgezeichneter Profi-Flow auf das Raster gelegt (Tabelle familien_log)."""
    np = _np(); v = np.full(n, np.nan)
    try:
        for ts, w in st.execute("SELECT ts, value FROM familien_log WHERE coin=? AND familie='Profi-Flow' AND ts>=?", (coin, g0)):
            k = (int(ts) - g0) // RASTER
            if 0 <= k < n and w is not None:
                v[k] = w
    except sqlite3.Error:
        pass
    return v


def profi_jetzt(con_main, coin: str, liste: list, now: int | None = None):
    """Netto-Handel der Darwin-Liste im Coin über 4 h: (Käufe − Verkäufe) / Umsatz, ab PROFI_MIN_USD Umsatz."""
    now = now or int(time.time())
    if not liste:
        return None
    ph = ",".join("?" * len(liste))
    try:
        r = con_main.execute(f"SELECT SUM(CASE WHEN buy=1 THEN notional ELSE -notional END), SUM(notional) FROM lb_fills "
                             f"WHERE coin=? AND ts>=? AND lower(addr) IN ({ph})", (coin, now - 4 * 3600, *liste)).fetchone()
    except sqlite3.Error:
        return None
    if not r or not r[1] or r[1] < PROFI_MIN_USD:
        return None
    return max(-1.0, min(1.0, r[0] / r[1]))


# ------------------------------------------------------------------------------------------------ Bewertung
def _renditen(lp, h_slots: int, bis_k: int):
    np = _np(); n = len(lp); fr = np.full(n, np.nan)
    with np.errstate(all="ignore"):
        fr[:max(0, n - h_slots)] = lp[h_slots:] - lp[:max(0, n - h_slots)]
    fr[bis_k:] = np.nan                                                   # nur abgeschlossene Horizonte
    return fr


def _stat(paare: list) -> dict:
    """Vorsprung = Mittel von (Treffer − Erwartung) über die Fälle (Treffer 0/1, Erwartung des Zufalls je Fall). z seit 23.46 exakt
    (hl_forecast.z_treffer): Bis 23.45 Mittel / Stichproben-Standardfehler -- bei wenigen Fällen mit lauter Treffern ist die
    Streuung 0 bis auf Rundungsrauschen, und z explodierte (Pi 04.10.: Familie „Kaskaden“, n 3, z 1,2 · 10¹⁶); bei kleinem n war
    es auch sonst zu großzügig (5 von 6 bei 50 %: +2,0, exakt +1,53)."""
    n = len(paare)
    lift = (sum(h - e for h, e in paare) / n) if n else None
    if n < 3:
        return {"n": n, "lift": lift, "z": None}
    return {"n": n, "lift": lift, "z": F.z_treffer(paare)}


def bewerten(v, lp, sig, g0: int, a: int, bis_k: int, h: int, art: str, schwelle: float) -> dict:
    """
    Fälle: je Block der Länge h der erste Rasterpunkt, an dem die Familie spricht. Richtung: Treffer, wenn das Vorzeichen
    der Rendite passt; Zufall = Anteil steigender Blöcke im selben Zeitraum (für negative Werte das Gegenstück).
    Stärke: Treffer = |Rendite| >= GROSS_K σ; Zufall = Anteil großer Bewegungen. Dazu ungesehene Daten (letztes Drittel)
    und Wochen.
    """
    np = _np(); hs = h * 3600 // RASTER; fr = _renditen(lp, hs, bis_k)
    alle, faelle = [], []
    for b0 in range(a, bis_k, hs):
        blk = range(b0, min(b0 + hs, bis_k))
        k_alle = next((k for k in blk if not np.isnan(fr[k])), None)
        if k_alle is not None:
            if art == "staerke":
                s_h = sig[k_alle] * math.sqrt(hs / 16) if not np.isnan(sig[k_alle]) else None
                if s_h:
                    alle.append(1 if abs(fr[k_alle]) >= GROSS_K * s_h else 0)
            else:
                alle.append(1 if fr[k_alle] > 0 else 0)
        k = next((k for k in blk if not np.isnan(fr[k]) and not np.isnan(v[k]) and abs(v[k]) >= schwelle), None)
        if k is not None:
            faelle.append(k)
    if not alle:
        return {"n": 0}
    basis = sum(alle) / len(alle)
    werte, zeiten = [], []
    for k in faelle:
        if art == "staerke":
            s_h = sig[k] * math.sqrt(hs / 16) if not np.isnan(sig[k]) else None
            if not s_h:
                continue
            hit = 1 if abs(fr[k]) >= GROSS_K * s_h else 0; erw = basis
        else:
            hit = 1 if (fr[k] > 0) == (v[k] > 0) and fr[k] != 0 else 0; erw = basis if v[k] > 0 else 1 - basis
        werte.append((hit, erw)); zeiten.append(g0 + k * RASTER)
    out = dict(_stat(werte), basis=basis, treffer=(sum(hh for hh, _ in werte) / len(werte)) if werte else None)
    if werte:
        t_min, t_max = min(zeiten), max(zeiten); grenze = t_min + (t_max - t_min) * 2 / 3
        out["is"] = _stat([w for w, t in zip(werte, zeiten) if t <= grenze])
        out["oos"] = _stat([w for w, t in zip(werte, zeiten) if t > grenze])
        wochen: dict = {}
        for (hh, ee), t in zip(werte, zeiten):
            wochen.setdefault(t // 604_800, []).append(hh - ee)
        wl = [(w, sum(x) / len(x)) for w, x in sorted(wochen.items()) if len(x) >= 5]
        out["wochen"] = {"positiv": sum(1 for _, l in wl if l > 0), "gesamt": len(wl)}
        ohne = 0
        for _, l in reversed(wl):
            if l > 0:
                break
            ohne += 1
        out["ohne_nutzen"] = ohne
    return out


HYG_N_MIN = 8                   # Fälle für ein Urteil (wie bis 23.54: mindestens 8 Fenster der Horizontlänge)
HYG_STREU_MIN = 0.02            # Streuung des Werts im Zeitraum; darunter ist kein Zusammenhang messbar
HYG_JUNG_TAGE = 2.0             # erster Wert so viele Tage nach Beginn des Zeitraums: „Werte erst seit …“


def _hyg_corr(x, y):
    np = _np()
    m = ~(np.isnan(x) | np.isnan(y))
    if m.sum() < 8 or np.std(x[m]) == 0 or np.std(y[m]) == 0:
        return None, int(m.sum())
    return float(np.corrcoef(x[m], y[m])[0, 1]), int(m.sum())


def _hyg_faelle(s_col, a: int, bis_k: int, hs: int):
    """
    23.55 (U133): Fälle der Hygiene -- Rasterpunkte MIT Wert im Abstand von mindestens einem Horizont, davor und danach je ein
    ganzes Fenster. Ein Treiber mit Wert an jedem Punkt bekommt genau die Blockanfänge wie bis 23.54. Ereignis-Treiber und junge
    Treiber werden an ihren aktiven Zeiten gemessen statt an Blockanfängen, an denen sie meist schweigen; die Fenster
    überlappen nie.
    """
    np = _np(); ks = []; k = max(a, hs)
    while k < bis_k - hs:
        if not np.isnan(s_col[k]):
            ks.append(k); k += hs
        else:
            k += 1
    return np.array(ks, dtype=int)


def _hyg_ci(r, n: int, zq: float = 1.96):
    """95-%-Intervall eines Korrelationskoeffizienten (Fisher-z): bei wenigen Fällen liegt ein großes r oft noch im Zufall."""
    if r is None or n <= 3:
        return None
    z = math.atanh(max(-0.999999, min(0.999999, r))); se = 1 / math.sqrt(n - 3)
    return [round(math.tanh(z - zq * se), 3), round(math.tanh(z + zq * se), 3)]


def _de(x: float, d: int, vz: bool = False) -> str:
    return (f"{x:+.{d}f}" if vz else f"{x:.{d}f}").replace(".", ",")


def hygiene(S, namen, lp, a: int, bis_k: int, g0: int | None = None) -> list:
    """
    Je Treiber: Zusammenhang mit der VERGANGENEN und der KOMMENDEN Rendite (Horizont seiner Familie, sonst 4 h) an Fällen im
    Abstand der Horizontlänge. „nachlaufend“: erklärt deutlich die Vergangenheit, kaum die Zukunft; „umgekehrt?“: der
    Zusammenhang mit der Zukunft ist in beiden Hälften deutlich negativ.
    23.55 (U133, Nutzerfund 05.10. 23:18): „kein Urteil“ statt „tot“. Bis 23.54 hieß jeder Treiber „tot“, der in weniger als 20 %
    der Zeit einen Wert hatte -- genau die Ereignis-Treiber, die nur bei einem Ereignis einen Wert liefern (Kapitulation,
    OI-Überhitzung …), und Treiber, die erst seit Kurzem rechnen. Jetzt zählen ihre aktiven Zeiten als Fälle (_hyg_faelle);
    reichen sie nicht (< HYG_N_MIN) oder bewegt sich der Wert kaum (Streuung < HYG_STREU_MIN), heißt der Befund „kein Urteil“
    mit Grund -- kein Befund gegen den Treiber. Dazu je Treiber: Anteil aktiv, erster und letzter Zeitpunkt mit Wert.
    """
    np = _np(); fam_h = {n: d["h"] for d in FAMILIEN.values() for n in d["treiber"]}; out = []
    corr = _hyg_corr
    for j, n in enumerate(namen):
        s = S[a:bis_k, j]; aktiv = ~np.isnan(s) if len(s) else np.zeros(0, bool)
        da = float(np.mean(aktiv)) if len(s) else 0.0
        h = fam_h.get(n, 4); hs = h * 3600 // RASTER
        idx = np.nonzero(aktiv)[0]
        zeit = (lambda i: int(g0 + (a + int(i)) * RASTER)) if g0 is not None else (lambda i: None)
        basis = {"treiber": n, "h": h, "anteil": round(da, 2), "ereignis": n in F.EREIGNIS_TREIBER,
                 "erster": zeit(idx[0]) if len(idx) else None, "letzter": zeit(idx[-1]) if len(idx) else None,
                 "familie": next((f for f, d in FAMILIEN.items() if n in d["treiber"]), None)}
        if n in AUSGESCHLOSSEN:
            out.append(dict(basis, flag="ausgeschlossen", grund=AUSGESCHLOSSEN[n])); continue
        ks = _hyg_faelle(S[:, j], a, bis_k, hs)
        if len(ks) < HYG_N_MIN:
            if not len(idx):
                grund = "im Zeitraum nie aktiv"
            elif basis["ereignis"]:
                grund = f"Ereignis-Treiber: {len(ks)} Fälle ({HYG_N_MIN} nötig), aktiv {da * 100:.0f} % der Zeit"
            elif idx[0] >= HYG_JUNG_TAGE * 96:
                grund = f"Werte erst seit {_de((len(s) - idx[0]) / 96, 1)} Tagen: {len(ks)} Fälle ({HYG_N_MIN} nötig)"
            else:
                grund = f"nur zeitweise aktiv ({da * 100:.0f} % der Zeit): {len(ks)} Fälle ({HYG_N_MIN} nötig)"
            out.append(dict(basis, flag="kein Urteil", n=int(len(ks)), grund=grund)); continue
        streu = float(np.nanstd(s))
        if streu < HYG_STREU_MIN:
            gross = float(np.nanmax(np.abs(s))); mittel = float(np.nanmean(s))
            if abs(mittel) >= 5 * HYG_STREU_MIN:            # z. B. Kapitulation: bei jedem Ereignis +0,80 -- kein Vergleich verschiedener Werte
                grund = (f"bei jedem Fall derselbe Wert ({_de(mittel, 2, True)}): ein Zusammenhang braucht verschiedene Werte — "
                         f"die Richtung zeigt die Trefferquote in der Treibertabelle")
            else:
                grund = (f"Wert bewegt sich kaum: Streuung {_de(streu, 3)}, größter Betrag {_de(gross, 2)} "
                         f"(messbar ab Streuung {_de(HYG_STREU_MIN, 2)})")
            out.append(dict(basis, flag="kein Urteil", n=int(len(ks)), streuung=round(streu, 4), grund=grund)); continue
        x = S[ks, j]; fut = lp[ks + hs] - lp[ks]; past = lp[ks] - lp[ks - hs]
        c_vor, nn = corr(x, fut); c_nach, _ = corr(x, past); se = 1 / math.sqrt(max(nn, 1))
        mitte = len(ks) // 2
        c1, n1 = corr(x[:mitte], fut[:mitte]); c2, n2 = corr(x[mitte:], fut[mitte:])
        flag = "ok"
        if c_nach is not None and abs(c_nach) >= 3 * se and abs(c_nach) >= 2 * abs(c_vor or 0):
            flag = "nachlaufend"
        elif c1 is not None and c2 is not None and c1 <= -2 / math.sqrt(max(n1, 1)) and c2 <= -2 / math.sqrt(max(n2, 1)):
            flag = "umgekehrt?"
        out.append(dict(basis, flag=flag, corr_vor=c_vor, corr_nach=c_nach, n=nn,
                        ci_vor=_hyg_ci(c_vor, nn), ci_nach=_hyg_ci(c_nach, nn)))   # 23.55: Intervall zu jedem r
    rang = {"umgekehrt?": 0, "nachlaufend": 1, "kein Urteil": 2, "ausgeschlossen": 3, "ok": 4}
    return sorted(out, key=lambda x: (rang.get(x["flag"], 9), x["treiber"]))


def _hygiene_bis_23_54(S, namen, lp, a: int, bis_k: int) -> list:
    """Die Regel bis 23.54, unverändert -- nur für den Selbsttest: Treiber mit Wert an jedem Punkt müssen bitgleich bleiben."""
    np = _np(); fam_h = {n: d["h"] for d in FAMILIEN.values() for n in d["treiber"]}; out = []
    corr = _hyg_corr
    for j, n in enumerate(namen):
        s = S[a:bis_k, j]; da = float(np.mean(~np.isnan(s))) if len(s) else 0.0
        hs = fam_h.get(n, 4) * 3600 // RASTER; ks = np.arange(max(a, hs), bis_k - hs, hs)
        if n in AUSGESCHLOSSEN:
            out.append({"treiber": n, "flag": "ausgeschlossen", "grund": AUSGESCHLOSSEN[n], "anteil": round(da, 2)}); continue
        if da < 0.2 or len(ks) < 8 or np.nanstd(s) < 0.02:
            out.append({"treiber": n, "flag": "tot", "anteil": round(da, 2), "grund": "kaum Werte oder keine Bewegung"}); continue
        x = S[ks, j]; fut = lp[ks + hs] - lp[ks]; past = lp[ks] - lp[ks - hs]
        c_vor, nn = corr(x, fut); c_nach, _ = corr(x, past); se = 1 / math.sqrt(max(nn, 1))
        mitte = len(ks) // 2
        c1, n1 = corr(x[:mitte], fut[:mitte]); c2, n2 = corr(x[mitte:], fut[mitte:])
        flag = "ok"
        if c_nach is not None and abs(c_nach) >= 3 * se and abs(c_nach) >= 2 * abs(c_vor or 0):
            flag = "nachlaufend"
        elif c1 is not None and c2 is not None and c1 <= -2 / math.sqrt(max(n1, 1)) and c2 <= -2 / math.sqrt(max(n2, 1)):
            flag = "umgekehrt?"
        out.append({"treiber": n, "flag": flag, "h": fam_h.get(n, 4), "corr_vor": c_vor, "corr_nach": c_nach, "n": nn,
                    "anteil": round(da, 2), "familie": next((f for f, d in FAMILIEN.items() if n in d["treiber"]), None)})
    rang = {"umgekehrt?": 0, "nachlaufend": 1, "tot": 2, "ausgeschlossen": 3, "ok": 4}
    return sorted(out, key=lambda x: (rang.get(x["flag"], 9), x["treiber"]))


# ------------------------------------------------------------------------------------------------ Darwin für Familien
def darwin_aktualisieren(st_alt: dict | None, urteile: dict, woche: int) -> dict:
    """
    Wöchentlich: „gut“ = Vorsprung der letzten 14 Tage mit z >= 2, „schlecht“ = z <= 0. Kandidat -> Bewährung nach einer
    guten Woche -> aufgestiegen nach der zweiten in Folge; Bewährung ohne gute Woche -> Kandidat; aufgestiegen wackelt nach
    einer schlechten Woche und fällt nach zwei in Folge zurück. Am selben Wochentag keine Änderung.
    """
    st = st_alt or {}; fam = dict(st.get("familien") or {})
    if st.get("woche") == woche:
        return st
    for f, u in urteile.items():
        e = dict(fam.get(f) or {"stufe": "Kandidat", "gut": 0, "schlecht": 0})
        if u == "gut":
            e["gut"] += 1; e["schlecht"] = 0
        elif u == "schlecht":
            e["schlecht"] += 1; e["gut"] = 0
        else:
            e["schlecht"] = 0
            if e["stufe"] != "aufgestiegen":
                e["gut"] = 0
        if e["stufe"] == "aufgestiegen":
            if e["schlecht"] >= 2:
                e["stufe"] = "Kandidat"; e["gut"] = 0
        elif e["gut"] >= 2:
            e["stufe"] = "aufgestiegen"
        elif e["gut"] == 1:
            e["stufe"] = "Bewährung"
        else:
            e["stufe"] = "Kandidat"
        e["wackelt"] = e["stufe"] == "aufgestiegen" and e["schlecht"] == 1
        fam[f] = e
    return {"woche": woche, "familien": fam}


# ------------------------------------------------------------------------------------------------ Bericht je Coin
def bericht(con_main, coin: str, path: str | None = None, now: int | None = None, tage: int = TAGE, darwin_speichern: bool = True) -> dict:
    np = _np()
    now = now or int(time.time()); path = path or F.STORE
    st = F.store_connect(path)
    try:
        g0, P, S, namen = raster(con_main, st, coin, now - tage * 86_400, now)
        import hl_konstellation as K
        lp, sig = K._profil_sigma(P)
        n = len(P); bis_k = min(n, (now - g0) // RASTER + 1)
        erste = np.where(~np.all(np.isnan(S), axis=1))[0]
        if not len(erste):
            return {"coin": coin, "bereit": False, "hinweis": "noch keine Treiberwerte gespeichert"}
        a = max(int(erste[0]), 7 * 96)
        werte = familienwerte(S, namen, P, sig)
        werte["Profi-Flow"] = profi_reihe(st, coin, g0, n)
        try:
            r = st.execute("SELECT value FROM learned WHERE coin=? AND key='familien_darwin'", (coin,)).fetchone()
            dstate = json.loads(r[0]) if r and r[0] else {}
        except (sqlite3.Error, ValueError):
            dstate = {}
    finally:
        st.close()
    fam_out, urteile = [], {}
    k_jetzt = bis_k - 1
    for f, d in FAMILIEN.items():
        v = werte.get(f)
        if v is None:
            continue
        jetzt_v = next((float(v[k]) for k in range(k_jetzt, max(k_jetzt - 8, -1), -1) if not np.isnan(v[k])), None)
        dauer = {h: bewerten(v, lp, sig, g0, a, bis_k, h, d["art"], SCHWELLE if d["art"] != "staerke" else 0.3) for h in HORIZONTE}
        ereignis = bewerten(v, lp, sig, g0, a, bis_k, d["h"], d["art"], SCHWELLE_EREIGNIS)
        a14 = max(a, bis_k - 14 * 96)
        letzte = bewerten(v, lp, sig, g0, a14, bis_k, d["h"], d["art"], SCHWELLE if d["art"] != "staerke" else 0.3)
        z14, l14 = letzte.get("z"), letzte.get("lift")
        urteile[f] = "gut" if (z14 is not None and z14 >= 2 and (l14 or 0) > 0) else "schlecht" if (z14 is not None and z14 <= 0) else "offen"
        fam_out.append({"familie": f, "art": d["art"], "h": d["h"], "treiber": [t for t in d["treiber"] if t in namen] or (["Darwin-Liste (live)"] if d.get("live") else []),
                        "jetzt": jetzt_v, "ereignis_jetzt": jetzt_v is not None and abs(jetzt_v) >= SCHWELLE_EREIGNIS,
                        "dauer": dauer, "ereignis": ereignis, "letzte14": letzte, "urteil": urteile[f]})
    woche = now // 604_800
    dstate = darwin_aktualisieren(dstate, urteile, woche)
    if darwin_speichern:
        try:
            F.learned_save(coin, "familien_darwin", dstate)
        except Exception:
            pass
    # Überschneidung: Zusammenhang der Familienwerte (alle 4 Rasterpunkte)
    ks = np.arange(a, bis_k, 4); reihen = {x["familie"]: werte[x["familie"]][ks] for x in fam_out}
    for x in fam_out:
        best = (None, 0.0)
        for g, w in reihen.items():
            if g == x["familie"]:
                continue
            m = ~(np.isnan(reihen[x["familie"]]) | np.isnan(w))
            if m.sum() >= 20 and np.std(w[m]) > 0 and np.std(reihen[x["familie"]][m]) > 0:
                c = float(np.corrcoef(reihen[x["familie"]][m], w[m])[0, 1])
                if abs(c) > abs(best[1]):
                    best = (g, c)
        x["ueberschneidung"] = {"mit": best[0], "r": round(best[1], 2)} if best[0] else None
        e = (dstate.get("familien") or {}).get(x["familie"]) or {}
        x["stufe"] = e.get("stufe", "Kandidat"); x["wackelt"] = bool(e.get("wackelt"))
        l14 = x["letzte14"].get("lift")
        x["gewicht"] = round(max(0.0, l14 or 0.0), 3) if x["stufe"] == "aufgestiegen" else 0.0
    # Familien-Prognose: nur aufgestiegene Familien verschieben die Basisrate
    prognose = {}
    for h in HORIZONTE:
        fr = _renditen(lp, h * 3600 // RASTER, bis_k); ok = fr[a:bis_k]; ok = ok[~np.isnan(ok)]
        basis = float(np.mean(ok > 0)) if len(ok) else None
        beitr = [(x["familie"], x["gewicht"] * (1 if (x["jetzt"] or 0) > 0 else -1) * min(1.0, abs(x["jetzt"] or 0) / SCHWELLE_EREIGNIS))
                 for x in fam_out if x["art"] == "richtung" and x["h"] == h and x["gewicht"] > 0 and x["jetzt"] is not None]
        p = None if basis is None else max(0.02, min(0.98, basis + sum(b for _, b in beitr)))
        prognose[h] = {"p": p, "basis": basis, "beitraege": [{"familie": f_, "beitrag": round(b, 3)} for f_, b in beitr]}
    # Verlauf der letzten 72 h für das Chart
    k0 = max(a, bis_k - 72 * 4)
    verlauf = {"t": [int(g0 + k * RASTER) for k in range(k0, bis_k)], "px": [None if np.isnan(P[k]) else float(P[k]) for k in range(k0, bis_k)],
               "familien": {x["familie"]: [None if np.isnan(werte[x["familie"]][k]) else round(float(werte[x["familie"]][k]), 3) for k in range(k0, bis_k)]
                            for x in fam_out}}
    return {"coin": coin, "bereit": True, "ts": now, "seit": int(g0 + a * RASTER), "tage": round((bis_k - a) / 96, 1),
            "familien": fam_out, "prognose": prognose, "hygiene": hygiene(S, namen, lp, a, bis_k, g0), "ausgeschlossen": AUSGESCHLOSSEN,
            "verlauf": verlauf, "woche": woche,
            "hinweis": "Parallelbetrieb: wirkt nicht auf die bisherige Prognose. Gewicht bekommt eine Familie erst nach zwei Wochen in Folge "
                       "mit belegtem Vorsprung (z >= 2 über 14 Tage)."}


def bericht_text(b: dict) -> str:
    q = lambda x: "—" if x is None else f"{x * 100:.0f} %"
    pp = lambda x: "—" if x is None else f"{x * 100:+.1f} pp"
    zz = lambda x: "—" if x is None else f"{x:+.1f}"
    if not b.get("bereit"):
        return f"{b.get('coin')}: {b.get('hinweis')}"
    z = [f"{b['coin']} · Treiberfamilien (Parallelbetrieb) · {b['tage']} Tage Daten · Familien-Prognose: " +
         " · ".join(f"{h} h {q(v['p'])} (Basis {q(v['basis'])})" for h, v in b["prognose"].items())]
    z.append(f"  {'Familie':<18}{'jetzt':>7}  {'Hor.':>4}  {'Stufe':<13}{'Vorsprung':>10} {'z':>5} {'n':>4}  {'ungesehen':>10} {'Wochen+':>8}  Überschneidung")
    for x in b["familien"]:
        e = x["dauer"].get(x["h"]) or {}
        jv = f"{x['jetzt']:+.2f}" if x["jetzt"] is not None else "—"
        z.append(f"  {x['familie']:<18}{jv:>7}  {x['h']:>3}h  "
                 f"{x['stufe'] + (' !' if x['wackelt'] else ''):<13}{pp(e.get('lift')):>10} {zz(e.get('z')):>5} {e.get('n', 0):>4}  "
                 f"{pp((e.get('oos') or {}).get('lift')):>10} {str((e.get('wochen') or {}).get('positiv', 0)) + '/' + str((e.get('wochen') or {}).get('gesamt', 0)):>8}  "
                 + (f"{x['ueberschneidung']['mit']} r {x['ueberschneidung']['r']:+.2f}" if x.get("ueberschneidung") else "—"))
    auff = [h for h in b["hygiene"] if h["flag"] in ("nachlaufend", "umgekehrt?", "ausgeschlossen")]
    ohne = [h for h in b["hygiene"] if h["flag"] == "kein Urteil"]
    z.append("  Hygiene: " + (" · ".join(f"{h['treiber']}: {h['flag']}" for h in auff) if auff else "alle Treiber ohne Auffälligkeit"))
    if ohne:                                                   # 23.55 (U133): kein Befund gegen den Treiber, nur zu wenig Messbares
        z.append("  Ohne Urteil (kein Befund gegen den Treiber): " + " · ".join(f"{h['treiber']} ({h.get('grund')})" for h in ohne))
    return "\n".join(z)


# ------------------------------------------------------------------------------------------------ Selbsttest
PROBE_NOW = 1_790_006_400


def nulltest(verbose: bool = True, seed: int = 5) -> bool:
    """
    Fester Zeitpunkt und Seed. Eingebaut: „Wal-Flow 30 min“ kennt die kommende 4-h-Richtung (Positivkontrolle der Familie
    Großkonten-Fluss), „60-min-Trend“ ist die vergangene Stunde (muss als nachlaufend auffallen), „Orderbuch“ zeigt die
    kommende Stunde umgekehrt (muss als umgekehrt? auffallen), „OI-Überhitzung“ ist vor großen Bewegungen hoch
    (Positivkontrolle Stärke); alles andere Rauschen -- die Familie ETF (nur Rauschen) darf keinen Beleg zeigen.
    23.55 (U133) Hygiene der Ereignis- und jungen Treiber, Werte aus einem eigenen Zufallsstrom (die übrigen Reihen bleiben
    bitgleich): „Kapitulation“ nur in 3 kurzen Schüben (kein Urteil, nicht tot), „Liquidationsdruck“ in Schüben mit Kenntnis
    der kommenden 4 h (Positivkontrolle: wird an seinen Ereignissen gemessen), „Vol-Spike-Reversion“ in Schüben gegen die
    vergangene Stunde (muss als nachlaufend auffallen), „Crowding-Extrem“ Rauschen in Schüben (unauffällig), „Crowding-Trend
    7 T“ erst seit 5 Tagen (genug Fälle, bewertet), „Kaskaden-Asymmetrie“ erst seit 1 Tag (kein Urteil, „erst seit“),
    „Funding“ immer da, aber fast ohne Ausschlag (kein Urteil, „bewegt sich kaum“), „Taker-Flow“ in Schüben mit immer
    demselben Wert (kein Urteil, „derselbe Wert“). Treiber mit Wert an jedem Punkt
    bitgleich zur Regel bis 23.54.
    """
    np = _np(); import tempfile
    rng = np.random.default_rng(seed); now = PROBE_NOW; tage = 37; n = tage * 96
    g_start = (now - tage * 86_400) // RASTER * RASTER
    lp = np.cumsum(rng.normal(0, 0.002, n)) + math.log(100)
    fut4 = np.full(n, 0.0); fut4[:-16] = lp[16:] - lp[:-16]
    fut1 = np.full(n, 0.0); fut1[:-4] = lp[4:] - lp[:-4]
    past1 = np.full(n, 0.0); past1[4:] = lp[4:] - lp[:-4]
    tmp = tempfile.mkdtemp(); con = sqlite3.connect(os.path.join(tmp, "m.db"))
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)",
                    [(g_start + i * RASTER - 60, "AAA", math.exp(lp[i]), math.exp(lp[i]), math.exp(lp[i]), math.exp(lp[i]), 1, 1) for i in range(n)])
    con.commit()
    pfad = os.path.join(tmp, "f.db"); st = F.store_connect(pfad)
    rausch = lambda s_: float(np.clip(rng.normal(0, s_), -1, 1))
    rng2 = np.random.default_rng(seed + 1000)                     # 23.55: eigener Strom -- die übrigen Reihen bleiben bitgleich
    i0 = 7 * 96
    schub = lambda i, alle, lang, ab=0: i >= i0 + ab and (i - i0 - ab) % alle < lang
    kap = {i0 + 300 + 700 * q_ + r_ for q_ in range(3) for r_ in range(4)}       # 3 Schübe zu 1 h
    rows = []
    for i in range(7 * 96, n):
        t = g_start + i * RASTER - 840
        w = {n_: rausch(0.3) for n_ in F.PRIORS}
        w["Wal-Flow 30 min"] = float(np.clip(np.sign(fut4[i]) * 0.7 + rng.normal(0, 0.25), -1, 1))
        w["60-min-Trend"] = float(np.clip(past1[i] / 0.004 * 0.5 + rng.normal(0, 0.05), -1, 1))
        w["Orderbuch"] = float(np.clip(-fut1[i] / 0.004 * 0.5 + rng.normal(0, 0.1), -1, 1))
        w["OI-Überhitzung"] = float(0.9 if abs(fut4[i]) >= 1.5 * 0.008 else abs(rng.normal(0, 0.1)))
        # 23.55 (U133): Ereignis-Treiber und junge Treiber
        for n_ in ("Kapitulation", "Liquidationsdruck (3 Börsen)", "Vol-Spike-Reversion", "Crowding-Extrem", "Crowding-Trend 7 T", "Taker-Flow"):
            w.pop(n_, None)
        if i in kap:
            w["Kapitulation"] = 0.8
        if schub(i, 120, 12, 40):                                   # alle 1,25 Tage 3 h, kennt die kommenden 4 h
            w["Liquidationsdruck (3 Börsen)"] = float(np.clip(fut4[i] / 0.008 * 0.5 + rng2.normal(0, 0.3), -1, 1))
        if schub(i, 96, 8, 20):                                     # täglich 2 h, gegen die vergangene Stunde
            w["Vol-Spike-Reversion"] = float(np.clip(-np.sign(past1[i]) * 0.5 + rng2.normal(0, 0.1), -1, 1))
        if schub(i, 192, 16, 70):                                   # alle 2 Tage 4 h, Rauschen
            w["Crowding-Extrem"] = float(np.clip(rng2.normal(0, 0.4), -1, 1))
        if schub(i, 96, 8, 50):                                     # täglich 2 h, immer derselbe Wert (wie Kapitulation +0,8)
            w["Taker-Flow"] = 0.6
        if i >= n - 5 * 96:                                         # erst seit 5 Tagen (unter 20 % des Zeitraums)
            w["Crowding-Trend 7 T"] = float(np.clip(rng2.normal(0, 0.3), -1, 1))
        if i >= n - 96:                                             # erst seit 1 Tag (nicht in PRIORS, Familie Kaskaden)
            w["Kaskaden-Asymmetrie"] = float(np.clip(rng2.normal(0, 0.3), -1, 1))
        w["Funding"] = float(rng2.normal(0, 0.004))                 # immer da, fast ohne Ausschlag
        rows += [(t, "AAA", n_, v_) for n_, v_ in w.items()]
    st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", rows); st.commit(); st.close()
    b = bericht(con, "AAA", path=pfad, now=now, tage=tage - 7, darwin_speichern=False)
    # 23.55 (U133): dieselben Eingaben wie in bericht() für den Vergleich mit der Regel bis 23.54
    import hl_konstellation as K
    st = F.store_connect(pfad)
    g0_, P_, S_, namen_ = raster(con, st, "AAA", now - (tage - 7) * 86_400, now); st.close()
    lp_, _sig = K._profil_sigma(P_)
    bis_ = min(len(P_), (now - g0_) // RASTER + 1); a_ = max(int(np.where(~np.all(np.isnan(S_), axis=1))[0][0]), 7 * 96)
    alt = {h["treiber"]: h for h in _hygiene_bis_23_54(S_, namen_, lp_, a_, bis_)}
    voll = [nm for j_, nm in enumerate(namen_) if not np.any(np.isnan(S_[a_:bis_, j_]))]
    con.close()
    fam = {x["familie"]: x for x in b["familien"]}; hyg = {h["treiber"]: h for h in b["hygiene"]}
    gk = fam["Großkonten-Fluss"]["dauer"][4]; sk = fam["Stärke"]["dauer"][4]; etf = fam["ETF"]["dauer"][24]
    pruef = [("Großkonten-Fluss (eingebauter Vorläufer) belegt", (gk.get("z") or 0) >= 3, f"Vorsprung {100 * (gk.get('lift') or 0):+.0f} pp, z {gk.get('z') or 0:.1f}"),
             ("Stärke sagt große Bewegungen voraus", (sk.get("z") or 0) >= 2, f"Vorsprung {100 * (sk.get('lift') or 0):+.0f} pp, z {sk.get('z') or 0:.1f}"),
             ("ETF (reines Rauschen) ohne Beleg", abs(etf.get("z") or 0) < 3, f"z {etf.get('z') or 0:+.1f}"),
             ("60-min-Trend als nachlaufend erkannt", hyg["60-min-Trend"]["flag"] == "nachlaufend", hyg["60-min-Trend"]["flag"]),
             ("Orderbuch als umgekehrt erkannt", hyg["Orderbuch"]["flag"] == "umgekehrt?", hyg["Orderbuch"]["flag"]),
             ("Rauschtreiber unauffällig", hyg["ETF-Flows"]["flag"] == "ok", hyg["ETF-Flows"]["flag"]),
             ("Coinbase-Prämie ausgeschlossen", hyg["Coinbase-Prämie"]["flag"] == "ausgeschlossen", hyg["Coinbase-Prämie"]["flag"])]
    # 23.55 (U133): Ereignis- und junge Treiber -- bis 23.54 hießen alle „tot“
    _r = lambda x: "—" if x is None else f"{x:+.2f}"
    kp, ld, vs, ce = hyg["Kapitulation"], hyg["Liquidationsdruck (3 Börsen)"], hyg["Vol-Spike-Reversion"], hyg["Crowding-Extrem"]
    ct, ka, fu, tk = hyg["Crowding-Trend 7 T"], hyg["Kaskaden-Asymmetrie"], hyg["Funding"], hyg["Taker-Flow"]
    tot_alt = [nm for nm in ("Kapitulation", "Liquidationsdruck (3 Börsen)", "Vol-Spike-Reversion", "Crowding-Extrem",
                             "Crowding-Trend 7 T", "Kaskaden-Asymmetrie", "Funding") if alt[nm]["flag"] == "tot"]
    pruef += [("Regel bis 23.54: alle sieben „tot“ (der Fund)", len(tot_alt) == 7, f"{len(tot_alt)} von 7 „tot“"),
              ("Ereignis-Treiber, 3 Schübe: kein Urteil mit Grund", kp["flag"] == "kein Urteil" and kp.get("n") == 3
               and str(kp.get("grund", "")).startswith("Ereignis-Treiber") and kp.get("ereignis") is True, f"{kp['flag']}: {kp.get('grund')}"),
              ("Ereignis-Vorläufer an seinen Ereignissen gemessen", ld["flag"] == "ok" and (ld.get("n") or 0) >= 15
               and (ld.get("corr_vor") or 0) >= 3 / math.sqrt(max(ld.get("n") or 1, 1)),
               f"{ld['flag']}, Zukunft r {_r(ld.get('corr_vor'))}, n {ld.get('n')}, aktiv {(ld.get('anteil') or 0) * 100:.0f} %"),
              ("Nachlaufender Ereignis-Treiber erkannt", vs["flag"] == "nachlaufend",
               f"{vs['flag']}, Vergangenheit r {_r(vs.get('corr_nach'))}, n {vs.get('n')}, aktiv {(vs.get('anteil') or 0) * 100:.0f} %"),
              ("Ereignis-Rauschen unauffällig", ce["flag"] == "ok", f"{ce['flag']}, Zukunft r {_r(ce.get('corr_vor'))}, n {ce.get('n')}"),
              ("Junger Treiber mit genug Fällen bewertet", ct["flag"] == "ok" and (ct.get("n") or 0) >= 25, f"{ct['flag']}, n {ct.get('n')}, aktiv {(ct.get('anteil') or 0) * 100:.0f} %"),
              ("Junger Treiber mit 1 Tag: kein Urteil, „erst seit“", ka["flag"] == "kein Urteil" and str(ka.get("grund", "")).startswith("Werte erst seit 1,0 Tagen"),
               f"{ka['flag']}: {ka.get('grund')}"),
              ("Ruhiger Treiber: kein Urteil, „bewegt sich kaum“", fu["flag"] == "kein Urteil" and str(fu.get("grund", "")).startswith("Wert bewegt sich kaum")
               and fu.get("anteil") == 1.0, f"{fu['flag']}: {fu.get('grund')}"),
              ("Immer derselbe Wert: kein Urteil, „derselbe Wert“", tk["flag"] == "kein Urteil" and (tk.get("n") or 0) >= 8
               and str(tk.get("grund", "")).startswith("bei jedem Fall derselbe Wert (+0,60)"), f"{tk['flag']}, n {tk.get('n')}: {str(tk.get('grund'))[:60]}")]
    ci = ce.get("ci_vor") or [None, None]
    ci_ok = (ci[0] is not None and ci[0] < ce["corr_vor"] < ci[1]
             and abs(math.atanh(ci[1]) - math.atanh(ce["corr_vor"]) - 1.96 / math.sqrt(ce["n"] - 3)) < 2e-3
             and all(h_.get("ci_vor") is None for h_ in hyg.values() if h_["flag"] == "kein Urteil"))
    pruef.append(("Intervall zu r (Fisher-z, 95 %)", ci_ok, f"Ereignis-Rauschen r {_r(ce.get('corr_vor'))} [{ci[0]}; {ci[1]}], n {ce.get('n')}"))
    # Treiber mit Wert an jedem Punkt: Befund, r und n bitgleich zur Regel bis 23.54 („tot“ heißt jetzt „kein Urteil“)
    abw = [nm for nm in voll if nm not in AUSGESCHLOSSEN and (
        {"tot": "kein Urteil"}.get(alt[nm]["flag"], alt[nm]["flag"]) != hyg[nm]["flag"]
        or (alt[nm]["flag"] != "tot" and (alt[nm].get("corr_vor"), alt[nm].get("corr_nach"), alt[nm].get("n"))
            != (hyg[nm].get("corr_vor"), hyg[nm].get("corr_nach"), hyg[nm].get("n"))))]
    pruef.append(("Dauer-Treiber bitgleich zur Regel bis 23.54", len(voll) >= 20 and not abw, f"{len(voll)} Treiber, abweichend: {', '.join(abw) or 'keiner'}"))
    letzt_soll = int(g0_ + (bis_ - 1) * RASTER); erst_soll = int(g0_ + (n - 96) * RASTER)
    zf = [nm for nm in voll if hyg[nm].get("letzter") != letzt_soll]
    pruef.append(("Zeitpunkte: zuletzt und erster Wert", not zf and ka.get("erster") == erst_soll and ka.get("letzter") == letzt_soll,
                  f"zuletzt {letzt_soll} bei {len(voll) - len(zf)} von {len(voll)}, Kaskaden erster {ka.get('erster')} (Soll {erst_soll})"))
    txt = bericht_text(b); z_h = next((z for z in txt.split("\n") if z.startswith("  Hygiene:")), ""); z_o = next((z for z in txt.split("\n") if z.startswith("  Ohne Urteil")), "")
    pruef.append(("Bericht: „ohne Urteil“ getrennt von auffällig", "Kapitulation" not in z_h and "Kapitulation (Ereignis-Treiber" in z_o
                  and "Vol-Spike-Reversion: nachlaufend" in z_h, z_o[:90] + " …"))
    # Darwin-Stufen: gut, gut -> aufgestiegen; schlecht -> wackelt; schlecht -> Kandidat; gleiche Woche keine Änderung
    s_ = None
    folge = []
    for w_, u in ((1, "gut"), (2, "gut"), (2, "schlecht"), (3, "schlecht"), (4, "schlecht")):
        s_ = darwin_aktualisieren(s_, {"X": u}, w_); folge.append(s_["familien"]["X"]["stufe"] + ("!" if s_["familien"]["X"]["wackelt"] else ""))
    pruef.append(("Stufen der Familien", folge == ["Bewährung", "aufgestiegen", "aufgestiegen", "aufgestiegen!", "Kandidat"], " → ".join(folge)))
    # 23.46: wenige Fälle mit lauter Treffern -- bis 23.45 z = 1,2 · 10¹⁶ (Pi, Familie „Kaskaden“, n 3); jetzt exakt und kein „gut“
    s3 = _stat([(1, 0.525)] * 3); s6 = _stat([(1, 0.5)] * 5 + [(0, 0.5)])
    _zf = lambda x: "—" if x is None else f"{x:+.2f}"
    u3 = darwin_aktualisieren(None, {"X": "gut" if (s3["z"] or 0) >= 2 and s3["lift"] > 0 else "offen"}, 1)["familien"]["X"]["stufe"]
    pruef.append(("Wenige Fälle: z begrenzt, kein falsches „gut“", abs((s3["z"] or 0) - 1.4585) < 0.001 and (s6["z"] or 0) < 2 and u3 == "Kandidat",
                  f"3 von 3 bei 52,5 %: Vorsprung {s3['lift'] * 100:+.1f} pp, z {_zf(s3['z'])} → {u3} · 5 von 6 bei 50 %: z {_zf(s6['z'])} "
                  f"(Stichproben-z bis 23.45: +2,0, an der Grenze zu „gut“)"))
    ok = all(p[1] for p in pruef)
    if verbose:
        print("Treiberfamilien -- Selbsttest (fester Zeitpunkt, Seed %d)" % seed)
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<44} {txt}")
        print("  Ergebnis:", "bestanden" if ok else "NICHT bestanden")
    try:
        for f_ in os.listdir(tmp):
            os.remove(os.path.join(tmp, f_))
        os.rmdir(tmp)
    except OSError:
        pass
    return ok


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--bericht" in sys.argv:
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else os.environ.get("HL_DB", "hl_liq.db")
        _con = sqlite3.connect(f"file:{_db}?mode=ro", uri=True)
        st_ = F.store_connect(F.STORE)
        coins = [r[0] for r in st_.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ? ORDER BY coin", (int(time.time()) - 86_400,))]
        st_.close()
        print("Treiberfamilien -- Parallelbetrieb, wirkt nicht auf die Prognose. Stufen: Kandidat -> Bewährung -> aufgestiegen (zwei belegte Wochen).\n")
        for c in coins:
            print(bericht_text(bericht(_con, c, darwin_speichern=False)))
            print()
        _con.close()
        sys.exit(0)
    print("Aufruf: hl_familien.py --nulltest | --bericht --db PFAD")
