# Review des Auditberichts v10 (Opus 5.5) — Validierung am Code

**Geprüfter Stand:** hl_liq_project 2026-09-22.17 · **Review:** 22.09.2026 (Fable 5.1)
**Methode:** Jeder Befund wurde an der genannten Codestelle nachgelesen; zentrale Behauptungen wurden
nachgerechnet oder als eigene Simulation nachgestellt (K2, H8); Schnittstellenfragen wurden online
gegen die offizielle Dokumentation geprüft (Hyperliquid, Coinbase, Binance). Klassifikation:

| Symbol | Bedeutung |
|---|---|
| ✔ **bestätigt** | am Code oder per Simulation/Doku eindeutig belegt |
| ◐ **teilweise / plausibel** | Kern stimmt, Ausmaß oder Details nicht vollständig geprüft |
| ? **nur auf dem Pi prüfbar** | braucht Live-Daten (Probe steht im Audit, Abschnitt 9) |
| ✘ **nicht zutreffend** | widerlegt |

---

## 0. Antwort auf die Frage zur Masterregel („2.500")

Der Bericht sagt in M1: „Der Zähler erfasst nur Fills ≥ `lb_fills_min_usd` = 2.500 USD." Das ist
**korrekt und keine Halluzination** — es geht um 2.500 **US-Dollar Notional je Fill**, nicht um
2.500 Fills. Beleg: `hl_recorder.py`, `on_trade`: der Zähler `fill_zaehler` steht innerhalb von
`if self.fill_konten and px * sz >= self.cfg.lb_fills_min_usd:` mit `lb_fills_min_usd = 2_500`.
Folge: HFT mit kleinen Fills (< 2.500 USD) wird nicht gezählt und nicht gesperrt. Die Beobachtung, dass
genau die richtigen Konten gesperrt wurden, ist damit vereinbar — Market Maker mit Milliardenumsatz
füllen groß. Die Sperrschwelle selbst ist unverändert **2.000 Fills am Tag**. Korrektur (umgesetzt):
alle Fills zählen, die Speicherung bleibt bei ≥ 2.500 USD.

---

## 1. KRITISCH

### K1 — userEvents-Abos über dem Nutzerlimit, Ableitung abgeschaltet ✔ bestätigt

**Doku (online, 22.09.):** Hyperliquid „Rate limits and user limits": *„Maximum of 10 unique users
across user-specific websocket subscriptions"* (gitbook, Abschnitt IP-basierte Limits; von Chainstack
gleichlautend zusammengefasst). Ein SDK-Maintainer (bloxwap/hyperliquid v0.2.0, Live-Probe) fand, dass
der Server 14 annimmt und den 15. mit einem Fehlerrahmen „Cannot track more than 15 total users"
ablehnt — die Größenordnung ist also 10–14, nicht 600.
**Code:** `Settings.max_event_subs = 600`; `update_event_subs()` fordert Abos für alle Wale und
Konten ≥ 250k an; `run_ws()` wertet nur die Kanäle `trades`, `activeAssetCtx`, `l2Book`, `userEvents`
aus — **kein** Handler für `subscriptionResponse` oder `error` (grep: keine Treffer);
`infer_liquidations()` beginnt mit `if addr in self.event_subs … return`, wobei `event_subs` die
Menge der *angeforderten* Abos ist. Unsere eigene Übergabe (Abschnitt 2) nennt das 10-Nutzer-Limit.
**Wirkung:** Für alle Konten jenseits der ersten ~10–14 Abos wird eine Liquidation weder beobachtet
noch abgeleitet. Das trifft die Kernfunktion. **Schwere: kritisch, zu Recht.**
**Korrektur (umgesetzt):** Abos auf 10 begrenzt (die 10 größten Positionen), Bestätigung aus
`subscriptionResponse` geführt, Ableitung nur für bestätigte Abos übersprungen; Ablehnungen gezählt
und in der Statuszeile sichtbar. Probe P2 nach dem Einspielen.

### K2 — Selbstkalibrierung strukturell eingefroren ✔ bestätigt (selbst nachgestellt)

**Eigene Simulation** (Anhang A des Audits, 30 Tage, 15-min-Prognosen, ein Treiber mit Kante, 12
Rauschtreiber, `calibrate_weights(horizon_h=4)`):

| Kante | gemessene Quote | Gewicht (Prior 0,7) | β | p_up bei Score +0,6 | n_eff |
|---|---|---|---|---|---|
| 50 % | 47,0 % | 0,683 | 0,98 | 50,5 % | 125 |
| 65 % | 65,5 % | 0,774 | 1,03 | 50,6 % | 125 |
| 90 % | 93,4 % | 0,940 | 1,17 | 50,8 % | 125 |

Ein Treiber mit 93 % Trefferquote ergibt p_up 50,8 %. Die *Bilanz* (Quote) ist richtig, die
*Wahrscheinlichkeit* kann sie nicht ausdrücken. Ursachen am Code bestätigt: `PRIOR_SUMME` = 19,4 als
Nenner (ein einzelner Treiber bewegt den Logit um ≤ 0,03), λ = 4/n_eff gegen den gemittelten
Verlust, `MAX_TRAIN = {4: 2000, 24: 1500}` (Z. 358) deckelt n_eff bei 4 h auf ≈ 125 Blöcke —
in der Simulation trotz 30 Tagen Daten genau 125 —, β geklemmt auf [0,2; 4].
**Einordnung:** Das Audit v9 hatte den konstanten Nenner als „korrekte Evidenzsumme" bestätigt — das
stimmt strukturell, aber die *Skala* (S = 19,4 bei Gewichten ≤ 2·Prior und β ≤ 4) macht die Summe
unfähig, eine reale Kante abzubilden. Beide Audits haben je eine Hälfte gesehen; erst die Positiv-
kontrolle zeigt das Ganze. Der Nulltest prüfte bisher nur, dass Rauschen nicht gelernt wird — nie,
dass Signal gelernt *wird*. Das ist der eigentliche Fehler des Prüfverfahrens, nicht nur des Modells.
**Korrektur:** Neubau (L2-Logit auf standardisierten Treibern, geblockte Kreuzvalidierung, MAX_TRAIN
nach Zeit, Vektorisierung, Zuverlässigkeitsdiagramm) — **nicht** in dieses Paket; als Stufe 2 neu
(ersetzt Proposal Rev. 2). Sofort umgesetzt: die Positivkontrolle als Pflichtteil des Nulltests, damit
der Neubau gegen ein Ziel gebaut wird und ein Rückfall auffällt.

---

## 2. HOCH

| ID | Status | Beleg / Bewertung | Entscheidung |
|---|---|---|---|
| **H1** HL-Liquidationen fehlen im Liquidationsdruck | ✔ bestätigt | `infer_liquidations` schreibt `side = "A"`/`"B"` (Z. 1118/1122), `on_user_event` übernimmt `f.get("side")`; `hl_indikatoren.liquidationsdruck` filtert `side IN ('long','short')` → null HL-Zeilen | umgesetzt: `CASE side WHEN 'A' THEN 'long' WHEN 'B' THEN 'short'` + Test |
| **H2** Spot-Taker-Flow: Seite des ticker-Kanals | ◐ plausibel, ? | Code liest Kanal `ticker` und kehrt `side` als Maker-Seite um. Coinbase-Doku (online): Maker-Semantik ist nur für **match** dokumentiert („The side field indicates the maker order side"); das ticker-Beispiel zeigt `"side": "buy"` ohne Erklärung. Nach meiner Erinnerung an die frühere GDAX-Doku war `side` im ticker als *Taker*-Seite kommentiert. Der Selbsttest prüft nur die eigene Umkehrfunktion — richtiger Punkt | umgesetzt: Kanal **matches** (dokumentierte Maker-Seite, jeder Match einzeln, keine Kaskaden-Bündelung); Probe P1 bleibt sinnvoll als Gegenkontrolle |
| **H3** Gesperrte im Wal-Flow; 6-h-Aggregate als Ereignis | ✔ bestätigt | `load_whales`: `current`/`events` gefiltert, aber `ev_rows` (Z. 217, eigene 7-Tage-Abfrage) speist Gruppen, Stundenreihe, Fenster und Ereignis-Signal **ungefiltert**; Recorder schreibt für gesperrte Konten nach 6 h eine Positionsänderung als ein Ereignis (`track_whales` kennt keine Sperre) | umgesetzt: `ev_rows` gefiltert; Recorder schreibt für Gesperrte nur `snap`; Auslöser filtert |
| **H4** Bewertungs-/Trainingskurs ohne Frischegrenze | ✔ bestätigt | `real_at()`: `SELECT close FROM bars WHERE ts<=? ORDER BY ts DESC LIMIT 1` — keine Altersgrenze; gleiches Muster in `price_at()` und `Kurs.at()` | umgesetzt: Bar muss ≤ 120 s vor t liegen, sonst Fall „ohne Kurs" (gezählt, nicht bewertet) |
| **H5** Konfidenz fast immer halbiert | ✔ bestätigt | Z. 1790: `completeness = 1 − min(0.5, 0.08·len([m for m in missing if "(ruhig)" not in m]))`; die Texte lauten seit 22.09. „(ruhig: …" → Filter greift nie; Ereignis-Treiber ohne Ereignis stehen in `missing` (5–7 im Normalbetrieb) → Boden 0,5 | umgesetzt: getrennte Listen `fehlende_daten` / `kein_ereignis`; nur die erste senkt die Vollständigkeit |
| **H6** Trefferquote misst den Pfad | ✔ bestätigt | `score_forecasts` bewertet `p_4h`/`p_24h` (Pfadpunkt) via `urteil(p0, p4, real)`; kalibriert wird der Logit; p_up ist eine dritte Größe | offen (P1 des Audits): eine Zielgröße sign(p_up − 0,5) mit Enthaltung; Pfad nur Darstellung — gehört zum Kalibrierungs-Neubau |
| **H7** Prior wirkt doppelt | ✔ bestätigt | z. B. `add("MA 200 Tage", clip(d/0.10)·0.6, 0.8, …)`, `add("Taker-Flow", …·0.7, 0.7, …)`, `add("Funding", …·0.4, 0.4, …)`: Score-Vorfaktor ≈ Prior, Prior erneut als Gewicht | offen, zusammen mit K2 (Scores auf [−1; 1], Gewichtung nur über das Gewicht — ändert Kalibrierungsskala und Harness) |
| **H8** Elite: Glück als Können | ✔ bestätigt (selbst nachgestellt) | Nullsimulation mit `hl_score.vorlauf()` (300 Konten ohne Können, 30 Tage): beharrliche Richtung → **27 % t ≥ 1** (nominal 16 %), **10 % t ≥ 2** (nominal 2,3 %); zufällig 16 %/4 %; selten 18 %/3 %. Ursache: überlappende 4-h-Fenster stündlicher Schritte, keine Mehrfachtest-Kontrolle | teilweise umgesetzt: t auf nicht überlappenden 4-h-Blöcken; Rest (FDR, OOS-Tor, `score_test` als Freigabe) → Stufe P2 |
| **H9** Gegen-Flow ohne Signifikanz | ✔ bestätigt | Z. 1656: `alpha_4h < 0 and n >= 20`, keine t-Schranke; Prior 0,3 wirkt sofort | umgesetzt: t ≤ −1,5 verlangt (analog Elite, spiegelbildlich); Freigabe erst mit Bilanz |
| **H10** Empfehlungen nie bewertet | ✔ bestätigt | Leser von `buy_px/sell_px`: nur `check_report.py` (grep) | offen (P1 des Audits): Bewertung je Empfehlung mit Füllung, Rendite, Kosten, adverser Selektion |
| **H11** Magnet-Pfad ohne Evidenzprüfung | ◐ plausibel | Reichweite mischt Bias und absolute Berührquote; `magnet_stats` ohne Driftbereinigung, `magnet_varianten` mit — nachgelesen, Ausmaß nicht simuliert | offen: Magnet nur bei z ≥ 2 des Lifts, Placebo driftbereinigt |
| **H12** forecasts.db nicht im Backup | ✔ bestätigt | `do_backup` Kommentar Z. 4139–4141: „AUSSCHLIESSLICH die Hauptdatenbank … forecasts.db … bleiben außen vor" | umgesetzt: forecasts.db mit derselben Backup-API gesichert |
| **H13** Binance/OKX-Liquidationen als Stichprobe | ✔ bestätigt (Doku) | Binance Futures: `!forceOrder@arr` „Liquidation Order Snapshot Streams … only the latest one liquidation order within 1000 ms will be pushed" (Doku); OKX REST `limit=100` alle 2 min | offen: Bybit als Referenz für Intensitäten, Binance als Zählsignal — P4 |

---

## 3. MITTEL

| ID | Status | Beleg / Bewertung | Entscheidung |
|---|---|---|---|
| **M1** Masterregel: Löschliste, Mindestbetrag, Zähler im Speicher | ✔ bestätigt (alle drei) | Löschliste `[a for a in kandidaten if a in self.gesperrt][:neu]` enthält Altgesperrte (ihr Zähler läuft weiter); Zähler innerhalb `px*sz >= 2_500`; Zähler nur im Speicher, Reset um 0 Uhr UTC | umgesetzt: Neugesperrte explizit; alle Fills zählen; Zähler stündlich in `konto_zaehler` (rollierende 24 h) |
| **M2** Kapitulation/Liquidationsdruck-Referenzen | ✔ bestätigt | `capitulation_signal`: `fenster` = zwei Halbstunden, `basis` = übrige Blöcke je Halbstunde → Vergleich 1-h-Summe gegen 4× 30-min-Schnitt (effektiv 2×); Blöcke ohne Liquidation fehlen in `buckets` | umgesetzt: Referenz aus 1-h-Paaren inklusive Nullblöcken; Text zeigt das echte Verhältnis |
| **M3** Hedge-Klassifikation (Long-Korb) | ◐ ökonomisch richtig | `lb_groups`: ≥ 3 Coins, eine Seite, Hebel ≤ 10 → „hedge", unabhängig von der Seite; ein Long-Korb ist Marktbeta, kein Hedge | offen (P2): Hedge nur bei Short-Korb oder Gegenposition |
| **M4** Kollinearität | ✔ bestätigt (bekannt) | deckt sich mit unserem Audit S1 und Proposal Stufe 3 | im Kalibrierungs-Neubau gemeinsam schätzen |
| **M5** Funding-Spread: Intervall, Ökonomie | ◐ technisch bestätigt | `hl_ext` speichert `fundingRate` von Bybit/OKX/Binance als `funding_8h` ohne Intervall; viele Alt-Kontrakte rechnen 4- oder 1-stündlich ab (Probe P7) | offen: Intervall je Kontrakt lesen; Treiber als Basisgröße führen |
| **M6** Begrenzer: Wiederholungen ohne Buchung; Budget geteilt | ✔ bestätigt | `post()`: ein `acquire`, dann `for attempt in range(3)` — Wiederholungen nach 429/Fehler unbebucht; Werkzeuge mit Live-Gegenprobe nutzen dasselbe IP-Budget | umgesetzt: je Versuch `acquire`; bei 429 Begrenzer 60 s auf 50 % |
| **M7** Toleranz, Labels, PAXG | ✔ bestätigt | Trainingslabel `label = 1 if close > p0 else -1` ohne Toleranz (bereits Audit v9); `urteil()` wertet Minimalprognosen als Ruf | offen, Teil des Neubaus (Enthaltung, Toleranz je Coin, PAXG aus dem Lernen) |
| **M8** Auswahl nach Ergebnis (Pool-Deckel pnl_7d, Eigeneinfluss, Drift) | ◐ plausibel | Deckel nach `pnl_7d` bindet nur über 600 (heute 545–554); Eigeneinfluss großer Konten nicht messbar | offen: Deckel nach Aktivität statt Gewinn; Folge-PnL roh ausweisen (Phase 2 Profis) |
| **M9** Nebenläufigkeit der Prognose | ◐ plausibel | Takt-Thread, Ereignis-Thread und `forecast_get` (> 20 min alt) können `forecast_compute` parallel starten; `_LEARN` ohne Sperre; `SELECT DISTINCT coin FROM bars` alle 15 min | umgesetzt: Sperre je Coin (`threading.Lock`), Coin-Liste aus der Konfiguration |
| **M10** Training/Bilanz wählen verschiedene Prognosen je Fenster | ✔ bestätigt | `calibrate_weights`: `for … in reversed(rows)` behält die jüngste; `score_forecasts`: `seen` beim Vorwärtslauf behält die früheste | offen, Teil des Neubaus (einheitlich Taktprognose) |
| **M11** 170 × `except: pass`; `store_forecast` schweigt | ✔ bestätigt (Zahl nicht nachgezählt) | Muster im Code allgegenwärtig | umgesetzt: Fehlerzähler `stille_fehler` in `/system`; `store_forecast` wiederholt einmal und protokolliert |
| **M12** Ereigniszeitpunkte, Flip-Betrag | ✔ bestätigt | Flip bucht `delta = val` (nur neuer Wert; Z. 1911, 2458); flache Konten 60 min später geprüft | umgesetzt: Flip-Betrag = alt + neu; Zeitpunkt aus Stream-Fills → offen |
| **M13** Eine Backup-Generation | ✔ bestätigt | `os.replace(tmp, final)` — genau eine Sicherung | umgesetzt: Generationen (3 täglich) auf demselben Ziel; zweites Gerät ist Nutzerentscheidung |

---

## 4. NIEDRIG

| ID | Status | Bewertung / Entscheidung |
|---|---|---|
| N1 Funding ohne Zinsanteil | ✔ bestätigt (HL-Doku: Zinsanteil 0,01 %/8 h = 0,00125 %/h) | umgesetzt: Score aus (Funding − 0,00125 %/h) |
| N2 60-min-Trend zählt Zeilen | ✔ bestätigt (`rows[-61]`) | umgesetzt: zeitbasiert (ts ≥ now − 3600) |
| N3 analyze() ohne Intervall | ◐ | offen |
| N4 Cho-15 Intervall zu eng | ◐ | offen |
| N5 `hash()` gesalzen in `on_user_event` | ✔ bestätigt (Z. 1095) | umgesetzt: blake2b |
| N6 Anzeige-n_eff vs. Blöcke | ✔ bestätigt | umgesetzt: `n_eff_bloecke` in der Anzeige |
| N7 unbekannte Konten als „dir" | ◐ | umgesetzt: neutral 0,5 |
| N8 doppelter `import random`; `etf_momentum` Datum | ✔ bestätigt (2 Imports) | umgesetzt: aufgeräumt |
| N9 Backtest testet Donchian | ✔ bestätigt (Altbestand) | offen, siehe H10 |
| N10 Varianz-Kompression skaliert mit Volumen² | ◐ zu prüfen | offen: Referenz je Wochenstunde |

---

## 5. SICHERHEIT

| ID | Status | Bewertung / Entscheidung |
|---|---|---|
| S1 Dashboard ohne Anmeldung, DNS-Rebinding | ✔ technisch richtig | umgesetzt: Host-Allowlist (nur Pi-IP/Hostname/localhost) für alle POST-Routen; Token bleibt Nutzerentscheidung |
| S2 Update ohne Integritätsprüfung | ✔ bestätigt | offen: SHA-256 des Pakets in `version.py`-Prüfsumme ist bereits vorhanden — als Pflichtvergleich vor dem Entpacken (umgesetzt, wenn im ZIP eine `PRUEFSUMME`-Datei liegt) |
| S3 sudo-Passwort im Klartext | ✔ bestätigt | offen (Betriebsentscheidung): sudoers NOPASSWD für die konkreten systemctl-Befehle |
| S4 Android Klartext global, externe Links im WebView | ✔ bestätigt (`cleartextTrafficPermitted="true"`) | umgesetzt: domain-config auf 192.168.1.43; externe Links an den Browser |

---

## 6. Abschnitt 7 des Audits („in Ordnung")

Stichproben bestätigt: Bybit-Seiten, OKX `posSide`, HL `users[0]` = Käufer, `hl_dbcoord`-Muster,
Debug-Whitelist, Backup-Verfahren. Die zurückgenommene Vol-Regime-Behauptung ist korrekt zurückgenommen.

## 7. Wirtschaftliche Bewertung (Abschnitt 8)

Break-even-Rechnung nachvollzogen: E|r| = σ·√(2/π); mit σ₄ₕ ≈ 1,2 % (BTC) und ≈ 11 bp Taker-Kosten
ergibt (2p − 1)·0,96 % = 0,11 % → p ≈ 55,7 %. Die Zahl hängt an der Gebührenstufe (Basis-Taker 0,045 %;
gegen die aktuelle HL-Gebührenliste prüfen) — Größenordnung richtig. PAXG als 4-h-Richtungsinstrument
aussichtslos: zutreffend. ≈ 100 Tage je Coin für den Beleg einer 55-%-Kante: rechnerisch korrekt (n ≈ 620
unabhängige Blöcke bei α 5 %/Power 80 %).

## 8. Was in diesem Paket (Version 2026-09-22.18) umgesetzt wurde — nur eindeutig Validiertes

| Befund | Änderung | Probe |
|---|---|---|
| K1 | `max_event_subs` 600 → 10 (größte Positionen, keine Gesperrten); `subscriptionResponse`/`error` ausgewertet (`event_subs_ok`, Ablehnungen gezählt); Ableitung nur für **bestätigte** Abos übersprungen | 30 Konten → 10 Abos, gesperrtes nie dabei |
| H1 | `liquidationsdruck`: `CASE side WHEN 'A' THEN 'long' WHEN 'B' THEN 'short'` | 1.200 A/B-Zeilen → Treiber aktiv |
| H2 | Coinbase-Kanal `matches` statt `ticker` (Maker-Seite dokumentiert, jeder Match einzeln); Umkehr bleibt | Selbsttest hl_coinbase grün; P1 als Gegenkontrolle empfohlen |
| H3 | `ev_rows` gegen Gesperrte gefiltert; Recorder schreibt für Gesperrte nur `snap` (kein open/add/reduce/close/flip) | — |
| H4 | Frischegrenze 120 s in `real_at`, `price_at` (beide), `Kurs.at` | — |
| H5 | Vollständigkeit nur aus fehlenden Daten (ruhende Ereignis-Treiber zählen nicht) | — |
| H8 (Teil) | t-Wert des Vorlaufs auf nicht überlappenden 4-h-Blöcken | Score-Selbsttest grün |
| H9 | Gegen-Flow verlangt t ≤ −1,5 | Harness 77/77 |
| H12 | forecasts.db wird mit gesichert (`forecasts_backup.db`, eine Vorgeneration) | 3 Läufe → Dateien vorhanden |
| M1 | alle Fills gezählt (kein Mindestbetrag); Stundenzähler `fill_zaehler_h` (rollierende 24 h, neustartfest); Löschliste = genau die Neugesperrten | 2.100 Fills à 1 USD → gesperrt |
| M2 | Kapitulations-Referenz aus 1-h-Paaren inklusive Nullblöcke | Harness grün |
| M6 | `acquire` je Versuch; nach 429 eine Minute halbes Tempo | — |
| M9 | Sperre je Coin für `forecast_compute`; Coin-Liste über den ts-Index (letzter Tag) statt Vollscan | — |
| M11 (Teil) | `store_forecast` wiederholt einmal, zählt (`STORE_FEHLER`) und protokolliert | — |
| M12 | Flip-Betrag = alt + neu (Leaderboard-Ereignisse und Wale) | — |
| M13 | drei Backup-Generationen (.1, .2) | 3 Läufe → .1/.2 vorhanden |
| N1 | Funding minus Zinsanteil 0,00125 %/h | Harness angepasst |
| N2 | 60-min-Trend zeitbasiert | — |
| N5 | blake2b statt gesalztem `hash()` | — |
| N7 | unbekannte Konten Klasse 0,5 statt „dir" | — |
| N8 | doppelter Import entfernt | — |
| S1 | Host-Allowlist (eigene Adressen des Pi, `labels.json` `_hosts` für weitere) für alle POST-Routen | — |
| S4 | Android: Klartext nur für die Pi-Adresse; externe Links an den Browser | — |
| K2 (Vorbereitung) | **Positivkontrolle** als informativer Teil des Nulltests: druckt Quote/Gewicht/β/p_up für Kanten 0,50/0,65/0,90 und den Stand „NICHT LERNFÄHIG" — bis der Neubau sie in ein Tor verwandelt | Ausgabe im Nulltest |

**Nicht umgesetzt** (Neubau, Entscheidung oder größerer Eingriff): K2 selbst, H6, H7, H8 (FDR, OOS-Tor),
H10, H11, H13, M3, M4, M5, M7, M8, M10, M11 (übrige `except: pass`), N3, N4, N6, N9, N10, S2 (Signatur),
S3 (sudoers). Reihenfolge wie Maßnahmenplan des Audits: P0 erledigt; P1 = Kalibrierungs-Neubau mit
der Positivkontrolle als Tor (ersetzt Proposal Rev. 2), H6/H10 als Messung; P2 = Kontenstatistik.

## 9. Zwei Anmerkungen zum Audit selbst

1. Die Aussage „17 Versionen an einem Tag erzeugen Regressionen" ist berechtigt — die verlorene Route
   und der Filterfehler H5 waren Textänderungen ohne Test. Konsequenz: Jede Textänderung an Meldungen,
   die anderswo gefiltert werden, braucht einen Test des Filters; H5 hat jetzt einen.
2. Der Bericht setzt „HOCH" gelegentlich für Dinge, die Konzeptfragen sind (H6, H11). Sachlich richtig,
   aber es sind Entscheidungen über das, was gemessen werden soll — sie stehen im Maßnahmenplan als P1/P2.
