# HyperBit — Analyzer

**Hyperliquid-Liquidationscluster aufzeichnen und auswerten** (Name seit 23.67, Wunsch des Nutzers; Ordner, Dienste, Datenbanken
und Dateien heißen weiter `hl_…`).

> Entwickelt mit Claude Fable 5.1 (13.–23.09.2026), fortgeführt mit Claude Opus 5.5. Einstieg für eine neue Sitzung: `PROJEKTUEBERGABE_OPUS55_23-09-2026.md`, dann `UPDATE_PLAN.md`.

Werkzeuge, um zu prüfen, ob Liquidationscluster auf Hyperliquid Vorhersagekraft
haben, und um darauf aufbauend eine Handelslogik zu testen.

Zielplattform: Raspberry Pi 5, Debian 13 (Trixie), 64 Bit. Läuft ebenso auf
jedem Debian/Ubuntu mit Python ab 3.11.

## Dateien

| Datei | Zweck |
|---|---|
| `install.py` | Einrichtung, Abhängigkeiten, Selbsttest, systemd |
| `requirements.txt` | Python-Pakete |
| `hl_recorder.py` | zeichnet Cluster live auf, labelt sie im Analysemodus |
| `hl_viz.py` | Live-Chart, Heatmap-PNGs und Dashboard |
| `hl_watchdog.py` | Wächter mit Summer, LED, Push und Totmannschalter |
| `run_all.py` | startet und überwacht alle Dienste gemeinsam |
| `hl_binance.py` | Binance-Liquidationen live, Marktdaten 30 Tage rückwirkend |
| `hl_timestats.py` | zeitbasierte Heatmap: wann Bewegungen gehäuft auftreten |
| `hl_backtest.py` | Trendfolge-Backtest für Perps und Spot |
| `hl_forecast.py` | Prognose, Selbstkalibrierung, Trefferbilanz, Nulltest (`--nulltest`) |
| `hl_score.py` | Konto-Score: Vorlauf, Edge je Umsatz, Konsistenz, Größe, Klasse; Score-Test |
| `hl_coinbase.py` | Coinbase-Spot: Prämie, Taker-Flow, Orderbuch |
| `check_m9.py` | Feuerraten des Ereignis-Signals alt/neu (Vorher-Nachher auf echten Daten) |
| `hl_ext.py` | Sammler der Fremdbörsen-Reihen (läuft im Dienst hl-binance) |
| `hl_indikatoren.py` | neue Treiber/Regime-Flags aus vorhandenen Tabellen (OI-Perzentil, Crowding, ETF-Momentum, Vol-Regime, Funding-Spread, Liquidationsdruck, Varianz-Kompression) |
| `hl_dbcoord.py` | prozessübergreifende Schreibkoordination (eine Sperre für alle Schreiber) |
| `hl_labor.py` | TradeLabor: simulierter Handel mit allen Daten (Strategien, Ausführungsmodell, Kennzahlen, Selbsttest); seit 23.69 die Akkumulation (U180, nur Kauf, eigene Bilanz, `--akku-rueckblick --db`, Konzept `KONZEPT_Akkumulation.md`) |
| `hl_fusion.py` | Fusionsprognose (Expertenmischung), Kalibrierung v3 (v2 über alle Coins geteilt), Kostenschwelle — im Schatten; Selbsttest `--nulltest`, Stand `--stand` (seit 23.42, Konzept `KONZEPT_Fusion.md`) |
| `hl_kaskade.py` | Kaskaden-Gleichung: Wurzelgesetz der Marktwirkung auf die Liquidationscluster der Heatmap → Kipppunkt, Ende, Mehrweg, P(Rutsch ≥ 2 σ); Kalibrierung Y je Coin mit Placebo und Seitenspiegel — im Schatten; Selbsttest `--nulltest`, Stand `--stand` (seit 23.43, Konzept `KONZEPT_Fusion.md` Abschnitt 4b) |
| `hl_magnet.py` | Magnet-Test (U110): berührt der Kurs Liquidationscluster öfter als ein Zufallsweg mit der richtigen Schwankung? Überschuss je Größenklasse mit Spiegel und Placebo — nur Messung, kein Treiber; Selbsttest `--nulltest`, Stand `--stand`, jetzt rechnen `--kalibrieren` (seit 23.45, Konzept `KONZEPT_Fusion.md` Abschnitt 4 „U110“) |
| `hl_regime.py` | Regime-Modul (U138), Phase 0: Vorprüfung auf der Historie -- Zwei-Uhren-Profil, Bewegungsgröße (HAR), Beine gegen die Zufallsgeometrie, Beinende, Kalender K1–K3, Wochenmomentum, Fenster, Regime-Analog, Bruchmelder; nur Bericht, eigene Datei `regime.db`; `--vorpruefung`, `--laden`, Selbsttest `--selbsttest` (seit 23.59, Konzept `KONZEPT_Regime.md`; K3 seit 23.60 je Stunde, driftneutral; Ergebnis des ersten Laufs `KONZEPT_Regime.md` 9.4) |
| `hl_swing.py` | Swing-Trades (U140): Tageskerzen aus eigener Datei `swing.db` (Binance-Futures, 30-min-Kerzen und Funding ab 2020; Swing-Takt im Dashboard lädt laufend nach), vier Strategien und zwei Kontrollen als gemeinsame Funktionen für Historie und TradeLabor, Vorprüfung auf der Historie mit Kosten, Funding, Zeitpunkt-Placebo und vorab festgelegtem Urteil; `--vorpruefung`, `--laden`, Selbsttest `--selbsttest` (seit 23.61, Konzept `KONZEPT_Swing.md`; seit 23.62 auch die Dip-Regeln Z1/Z2 und RSI) |
| `hl_zyklus.py` | Zyklus-Studie (U141): Rallyes und Rücksetzer auf den langen Tagesschlüssen (Coin Metrics ab 2013) gegen 1000 Zufallswege, „Dip halten“ gegen HODL, Trendfilter und Schwankungssteuerung, Warnsignale vor Rücksetzern, Gegenprobe mit Ausführung; nur lesend; `--studie`, Selbsttest `--selbsttest` (seit 23.62, Konzept `KONZEPT_Zyklen.md`) |
| `hl_hebel.py` | Hebel-Studie (U142): Binance-Positionierung (Konten, Top-Trader, Taker, OI) und Perp-Anteil am Volumen vor Rücksetzern und Liquidationswellen; eigene Datei `hebel.db` mit dem Binance-Archiv ab 2020 (Hebel-Takt im Dashboard lädt im Hintergrund) und der Sicherung von Liquidationen und Buchtiefe; nur lesend gegenüber `hl_liq.db`; `--studie`, `--laden`, Selbsttest `--selbsttest` (seit 23.63; 23.64 Kerzenschlüssel mit Markt, beschreibende H1-Ergänzungen; Konzept `KONZEPT_Hebel.md`) |
| `hl_chartbild.py` | Chartbild (U143 Stufe 1): die Lage je Coin in Worten -- Trend, Bein wie U141, Swing-Hochs/-Tiefs, Niveaus der Großkonten und Liquidationscluster, 80-%-Band für 1 und 7 Tage wie P0.2 mit Trefferquote, RSI, Funding-Druck, Positionierung, Fear & Greed; jede Zeile mit Prüfstand; nur lesend, kein Signal; `--text`, Selbsttest `--selbsttest`, Demo-Datenbanken `--demo` (seit 23.65; Konzept `KONZEPT_Chartbild.md`) |
| `hl_chartbild_js.py` | Skript des Abschnitts „CB Chartbild“ (`/chartbild.js`): Tageschart, Tabellen, Fadenkreuz (seit 23.65) |
| `hl_ausblick.py` | Ausblick 4 Wochen (U146): Breite (HAR-X), Form (echte Pfade ohne Trend), Richtung nur nach bestandenem Tor, Ziellevels mit Erreich- und Schluss-Wahrscheinlichkeit, bedingte Szenarien mit dem S&P 500, Stressfächer; Takt im Dashboard (30 min bei offenem Abschnitt, stündlich, bei Schock; Rückblick nachts und sonntags); eigene Datei `ausblick.db`, nur lesend auf alles andere; `--prognose`, `--rueckblick`, `--text`, Selbsttest `--selbsttest [--nur …]` (seit 23.66; Konzept `KONZEPT_Ausblick.md`) |
| `hl_ausblick_js.py` | Skript des Abschnitts „AU Ausblick“ (`/ausblick.js`): Fächer, Niveaus, Szenario-Abfrage, Reiter Spannen/Ziellevels/Gewichte/Bilanz/Korrelationen/Aktienmarkt/Was fehlt (seit 23.66) |
| `hl_datentage.py` | Studie Datentage (U154): schwanken BTC und ETH im Fenster 8:30–10:30 New York an US-Terminen (Verbraucherpreise, Arbeitsmarktbericht; beschreibend Erzeugerpreise, Erstanträge) stärker als an Werktagen ohne Termin im selben Monat? Nur Schwankung, nicht Richtung; vorab festgelegt (`KONZEPT_Makro.md` 11.7); liest `swing.db` und `makro.db`, schreibt nichts; `--studie --db`, Selbsttest `--selbsttest [--schnell]` (seit 23.67) |
| `hl_aktien.py` | Aktien-Archiv und Barometer (U148): FRED (S&P 500, Nasdaq-100, VIX, VIX3M, Baa − 10 J, STLFSI4, NFCI, Hochzinsaufschlag), Hyperliquid HIP-3 `xyz` rund um die Uhr, Deribit-DVOL, CFTC, FINRA, Farside, Cboe, SEC (Strategy); jeder Wert mit Abrufzeit in `aktien.db`, Revisionen als neue Fassung; Studie U147 und Kurzstudie K1/K2; `--abrufen`, `--text`, `--u147`, `--k12`, Selbsttest `--selbsttest` (seit 23.66; Recherche `RECHERCHE_Aktienmarkt_11-10-2026.md`) |
| `hl_adressfluss.py` | Adress-Strom: jeder Trade je Minute und Adresse in `adressfluss.db` (Recorder), Lesen und Bericht |
| `check_fills.py`, `check_sources.py` | Fill-Abholstand mit Live-Probe; Rundum-Funktionstest aller Quellen |
| `check_abdeckung.py` | Abdeckung der Heatmap im Verlauf (U159, seit 23.68): je Coin und Tag, snapshot_meta, Poller-Anteil, Neustarts, Tag 1 nach einem Neustart gegen danach; nur lesend |
| `hl_notbremse.py` | Notbremse (U206, seit 23.76): Dienst `hl-notbremse` -- jede Minute Krypto- und Aktien-Korb, Gleichlauf X, Krypto allein Y, Long-Liquidationen Λ, Stufe 0/1/2 in `notbremse.db`; das Tor `darf()` für Welt A des TradeLabors (`labor_a.db`), Termine, Handbremse; `--status`, Selbsttest `--selbsttest [--nur …]` (Konzept `KONZEPT_Notbremse.md`) |
| `check_notbremse.py` | Debug-Werkzeug der Notbremse: Zustand (Standard), `--zerlegung 2026-10-22` (Schritt 0), `--rueckblick` (Stufen, Empfindlichkeit, Labor-Rückwärtstest Welt A gegen B, Positivkontrollen); seit 23.77 `--rueckblick-start`, `--rueckblick-stand`, `--rueckblick-stopp` (der Rückblick als eigene systemd-Einheit aus der Debug-Konsole, Bericht danach unter „Neue Berichte“); Selbsttest `--selbsttest`; liest die Daten nur |
| `check_system.py` | Systemdiagnose ohne SSH (seit 23.77): letzter Neustart, Systemprotokoll vor dem Neustart (Dashboard, Kernel: Speicher, Platte/USB, Strom, Hänger; sauber oder abrupt beendet), Wächter-Log, Lücken im CPU-Verlauf, Berichte der letzten 24 h, Speicher, Strom, Prozesse; seit 23.78 Hänger-Abzüge und Dashboard-Log, Lücken des Dashboards über 7 Tage und um die längste: Wächter mit Abständen, Recorder, Lebenszeichen der Dashboard-Teile in den Datenbanken; Befund. Debug „★ System: letzter Neustart und Ausfälle“; `--fenster VON BIS`, `--journal-dauerhaft an\|aus` (Debug „System: Systemprotokoll dauerhaft speichern“), `--selbsttest`; seit 23.80 `--poller` (Debug „★ Recorder: Poller-Kapazität“: Bedarf gegen Budget je Stufe, Modell, U218) |
| `hl_volumen.py` | Volumen-Studie (U221, seit 23.81): laufen die Einstiege der Strategien bei hohem oder niedrigem Volumen bzw. Taker-Saldo besser? Teil A Trades des TradeLabors (Welt B) mit RV und TS vor dem Einstieg, Urteil erst am 08.11.; Teil B die vier Swing-Strategien seit 2020 mit dem Tagesumsatz von Binance; vorab festgelegt (`KONZEPT_Volumen.md`), liest nur, schreibt nichts; `--studie --db`, `--selbsttest` |
| `notbremse_termine.json` | Termine der Notbremse (UTC; im Zeitraum Stufe 1). Pflegt der Nutzer, `update.py` überschreibt sie nicht. Vorgabe: US-Wahlnacht 03.11. 23:00 bis 04.11. 08:00 UTC |

## Installation

```bash
python3 install.py            # venv, Pakete, Selbsttest
python3 install.py --enable   # zusätzlich: Autostart beim Booten einrichten
python3 install.py --check    # nur prüfen, nichts verändern
```

`--enable` erzeugt die systemd-Units, kopiert sie nach `/etc/systemd/system`,
aktiviert sie und prüft anschließend, ob alle drei laufen. Danach starten
Recorder, Binance-Stream und Dashboard automatisch bei jedem Boot.

Debian Trixie erlaubt kein `pip install` in die System-Python-Installation
(PEP 668). Das Skript legt deshalb ein venv unter `.venv/` an. Alle Aufrufe
danach über `.venv/bin/python`.

## Aktualisieren

**Per Knopf im Dashboard** (Panel „Aktualisierung", ganz unten): lädt das
Archiv von GitHub (`--update-url`, Standard: das Projekt-Repository), prüft es
und startet `update.py` in einer eigenen systemd-Einheit `hl-update`, die den
Neustart des Dashboards überlebt. Die Seite zeigt das Update-Log und lädt sich
am Ende selbst neu. Die Datenbank-Sicherung in Schritt 2 kann bei ~14 GB auf
die SD-Karte deutlich länger als eine halbe Stunde dauern (die Prüfung der
Kopie ist der lange Teil).

**Seit 23.66 (U145):** Sicherungen derselben Datenbank laufen nie mehr
gleichzeitig (Sperre auf `<db>.backup.lock`, Zwischendateien je Prozess,
`backup.json` atomar). `update.py` übernimmt ein Backup jünger als 24 h, wartet
sonst bis 90 min auf eine laufende Sicherung des Recorders und übernimmt sie --
oder legt selbst eine an. Das Log erscheint Zeile für Zeile. Läuft ein Update,
meldet ein zweiter Klick das, ohne Archiv oder Log anzufassen; nach einem
Neuladen der Seite verfolgt sie das laufende Update weiter.
**Das Einspielen von 23.66 selbst läuft noch mit dem alten `update.py`:**
dafür gilt ein letztes Mal, nur zu drücken, wenn die Kachel „Letztes Backup“
eine Uhrzeit zeigt (sonst erst System → Speicherorte → „Jetzt sichern“ und
warten, bis eine Uhrzeit erscheint).
Voraussetzung: `sudo.txt` mit dem sudo-Passwort
im Projektordner, Rechte 600 (`chmod 600 sudo.txt`) — sonst verweigert der
Server. **Sicherheitshinweis:** Wer das Dashboard im WLAN erreicht, kann damit
Root-Aktionen auslösen. Sicherer ist eine sudoers-Regel ohne Passwortdatei:

    sudo visudo -f /etc/sudoers.d/hl-liq
    seed ALL=(root) NOPASSWD: /usr/bin/systemctl, /usr/bin/systemd-run, /usr/bin/cp * /etc/systemd/system/, /usr/bin/rm -rf */__pycache__

Dann `sudo.txt` löschen; `update.py` und der Knopf funktionieren ohne Passwort.

**Per Terminal:**

```bash
python3 update.py                    # neuestes hl_liq_project*.zip aus ~/Downloads
python3 update.py /pfad/archiv.zip
```

Sichert erst die Datenbank und die bisherigen Skripte, stoppt die Dienste,
spielt das Archiv ein (Datenbank, Backups, Logs bleiben unberührt), prüft die
Syntax — bei Fehlern wird die Sicherung zurückgespielt — erzeugt und
installiert die systemd-Units neu und startet die Dienste. Findet auch
Archive mit `-2`/`-3`-Suffix, die der Browser beim mehrfachen Herunterladen
anhängt, und räumt entsprechende Altlasten wie `hl_viz-2.py` weg.
Die Sicherung liegt danach unter `updates/vor_<Zeitstempel>/`.

**Welche Dateien eingespielt werden:** die Liste `PROJECT_FILES` in `update.py`
(Skripte und die Konzept-/Recherche-Dokumente), dazu weitere `.py`/`.json` aus
dem Archiv -- diese aber ohne Sicherung und ohne Zurückspielen. Andere
Dokumente spielt `update.py` nicht ein. Ein Paket wird immer vom `update.py`
des installierten Stands eingespielt: Seit 23.69 stehen `check_abdeckung.py`,
`KONZEPT_Akkumulation.md` und `RECHERCHE_Boersenfluesse_17-10-2026.md` in der
Liste. 23.69 wurde nicht eingespielt; 23.70 kam mit dem `update.py` von 23.68
auf den Pi, also ohne die beiden Dokumente. Das nächste Paket (23.71 wurde
nicht eingespielt, 23.72 enthält es) spielt das `update.py` von 23.70 ein,
damit kamen sie (Probe 20.10. mit beiden Ständen; U182: Probe der Liste im
Selbsttest). 23.72 läuft seit dem 20.10. auf dem Pi; 23.73 und 23.74 spielt
das `update.py` von 23.72 bzw. 23.73 ein (Proben 20.10.: alle Skripte und die
geänderten Dokumente gleich dem Paket). 23.74 läuft seit dem 20.10.; 23.75 spielt das
`update.py` von 23.74 ein (Probe 22.10.: alle Skripte und die sechs geänderten Dokumente gleich dem
Paket). Danach offene Dashboard-Seiten anderer Geräte einmal neu laden: Seit 23.75 gehen die Aktionen
per POST, eine alte Seite bekommt 405.

## Datenbank auf ein anderes Medium verschieben

```bash
python3 migrate_db.py            # zeigt eingehängte Medien, fragt nach Auswahl
python3 migrate_db.py --target /mnt/ssd/hl
```

Stoppt die Dienste, wartet bis kein Prozess mehr an der Datenbank hängt,
faltet die WAL ein, prüft die Quelle, kopiert Datenbank und Backup-Ordner,
prüft die Kopie (integrity_check, Zeilenzahlen aller Tabellen), lässt den
Backup-Ordner auf dem Pi (getrennt vom Zielmedium), bietet
einen fstab-Eintrag an, damit das Medium nach Neustart wieder da ist,
stellt die Units um, startet die Dienste und wartet, bis der Recorder am
neuen Ort schreibt. Erst dann wird die alte Datenbank umbenannt — nicht
gelöscht. FAT/exFAT/NTFS werden abgelehnt; SQLite braucht ext4.

## Schreiblast auf der SD-Karte

Der Recorder hat keine eigenen Zwischendateien — seine Puffer liegen im RAM
und gehen alle 30 s per Commit in die Datenbank. Der eigentliche Zwischen-
speicher ist die WAL-Datei, die SQLite zwingend neben die Datenbank legt;
nach `migrate_db.py` liegt sie damit auf dem externen Medium.

**Schreibverstärkung — der Unterschied zwischen Zuwachs und Schreiblast.**
Die Datenbank wächst um wenige MB pro Stunde; geschrieben wird ein Vielfaches
davon. Grund: SQLite schreibt jede geänderte 4-KB-Seite erst ins WAL und beim
Checkpoint noch einmal in die Datei. Viele kleine Änderungen auf zufälligen
Seiten einer großen Tabelle kosten deshalb ein Hundertfaches ihrer Datenmenge.
Eine Messung am 11.09.2026 ergab 0,49 GB/h bei 2 MB/h Zuwachs — zwölf Gigabyte
am Tag auf den Stick. Vier Maßnahmen, zusammen etwa −80 %:

- Der Trade-Feed schrieb jede gesehene Adresse sofort in `addresses` (rund
  1.000 Aktualisierungen/min auf eine 130.000-Zeilen-Tabelle). Jetzt im
  Speicher gesammelt: neue Adressen alle 10 min, `last_trade` stündlich.
- Der Poller schrieb jede Abfrage. Jetzt nur, wenn sich der Positionswert um
  mindestens 2 % geändert hat; `last_poll` wird stündlich gesammelt
  geschrieben und ist im Speicher immer aktuell (`due_addresses` filtert
  danach, es wird also nichts doppelt abgefragt).
- `book_summary` alle 30 s statt alle 5 s — das Dashboard liest ohnehin nur
  die jüngste Zeile.
- Commit alle 30 s statt 10 s: mehrfach geänderte Seiten gehen einmal ins Log.

Im Labor gemessen (eine Stunde Betrieb simuliert: 19.200 Abfragen, 60.000
Trades, WAL-Autocheckpoint aus, damit die WAL genau die geschriebenen Seiten
sammelt): vorher 114 MB, nachher 4 MB je Stunde — 97 % weniger. Auf dem Stick
etwa das Doppelte, weil der Checkpoint dieselben Seiten noch einmal in die
Datei kopiert.

Nebenwirkung: Nach einem Stromausfall stehen `last_poll` und `last_trade`
einiger Adressen bis zu eine Stunde in der Vergangenheit — der Recorder fragt
sie dann früher erneut ab, es gehen keine Daten verloren. Messen lässt sich
alles mit Debug → „Schreiblast messen (5 min)" oder
`python3 check_writes.py --seconds 300`; Teil 3 zeigt die echte Schreibrate des
Datenträgers, Teil 1 den Zuwachs je Tabelle.

**Browser auf dem Pi — der größte SD-Karten-Schreiber.** Eine Messung am
11.09.2026 ergab: Recorder, Dashboard und Binance-Modul schrieben zusammen
4,2 MB in fünf Minuten (alles auf das externe Medium), Firefox auf demselben Pi
196,7 MB auf die SD-Karte — 2,4 GB/h. Ursache: Die Seite holt alle 5 s neue
Daten, der Browser legt jede Antwort in seinen Plattencache und sichert
nebenbei die Sitzung. Zwei Gegenmaßnahmen sind eingebaut: alle Antworten
tragen `Cache-Control: no-store` (der Browser darf sie nicht mehr auf die Karte
schreiben) und werden gepackt ausgeliefert, wenn der Browser es unterstützt
(71 % weniger Daten, Stufe 1, kaum Rechenzeit). Was zusätzlich hilft, falls das
Dashboard dauerhaft auf dem Pi offen steht: in `about:config`
`browser.cache.disk.enable = false` und
`browser.sessionstore.interval = 600000`; oder das Dashboard schlicht vom Handy
oder PC aus ansehen. Prüfen: Debug → „Browser auf dem Pi".

**Auswahl der fälligen Adressen läuft im Speicher.** Seit `last_poll` nur noch
stündlich gesammelt geschrieben wird, darf die Auswahl nicht mehr per SQL nach
`last_poll` sortieren — frisch abgefragte Adressen sähen dort maximal
überfällig aus und verstopften die Kandidatenliste (beobachtet: API-Auslastung
fiel von 85 % auf 16 %). Der Recorder hält deshalb alle Adressen mit
`last_poll`, `pos_value`, `last_trade` und `first_seen` im Speicher
(`addr_meta`, bei 130.000 Adressen rund 30 MB, Laden 0,35 s) und trifft die
Auswahl dort in einem Durchgang: ~55 ms alle 5 s, dafür entfallen drei
SQL-Abfragen über die große Tabelle. Diagnose: Die API-Kachel zeigt jetzt
„Poller 27/27 je Runde · fällig: 3.371 mit Position, 122.000 neu, 4.000 leer".
Steht dort „Stapel nicht voll", findet der Poller zu wenige fällige Adressen —
dann stimmt etwas mit der Auswahl oder es ist schlicht alles frisch abgefragt.

**Was im Backup steckt — und was nicht.** Das tägliche Backup kopiert
**ausschließlich** die Hauptdatenbank über die SQLite-Backup-API in eine
einzelne Datei (`hl_liq_backup.db`) plus eine kleine `backup.json`.
`forecasts.db`, `sys_history.json` und sämtliche WAL-Dateien liegen zwar im
selben Ordner, werden aber **nie** mitkopiert — sonst wüchse das Backup-Medium
(meist die SD-Karte) unnötig. Vor jedem Lauf prüft der Recorder den freien
Platz: nötig sind Datenbankgröße plus 10 % Reserve, weil altes und neues
Backup kurzzeitig nebeneinander liegen. Reicht er nicht, wird das Backup
übersprungen, das vorhandene bleibt unangetastet, und die Kachel „Letztes
Backup" zeigt ⚠ mit dem fehlenden Platz. Wer die Lernhistorie sichern will,
kopiert `forecasts.db` von Hand mit.

**Prognosedateien.** `forecasts.db` (Prognosen, gelernte Gewichte, Lernstand)
und `sys_history.json` (Temperatur- und CPU-Verlauf) liegen neben der
Hauptdatenbank — also auf dem externen Medium, nicht auf der SD-Karte. Den
Ordner findet das Dashboard über den `--db`-Pfad der systemd-Einheit, sonst
über `HL_DB`; mit `HL_FORECAST_DB` lässt er sich frei setzen. Ist der Ordner
nicht beschreibbar, bleibt alles im Projektordner. `update.py` verschiebt
vorhandene Dateien beim Aktualisieren mitsamt ihrer WAL, der Lernstand geht
also nicht verloren. Der Pfad steht im Prognose-Abschnitt unter „Zeitprofil"
und in `check_writes.py` (Teil 4).

Zusätzlich:

- Sortierpuffer aller Verbindungen im RAM (`temp_store=MEMORY`), nicht in
  `/var/tmp`.
- Logdateien (`recorder.log`, `binance.log`, `watchdog.log`) wandern mit der
  Migration nach `<Ziel>/logs/`; einstellbar über `install.py --log-dir`.
- Was bewusst auf der SD-Karte bleibt: das tägliche Backup und das
  systemd-Journal. Wer auch das Journal von der SD-Karte nehmen will:
  `Storage=volatile` in `/etc/systemd/journald.conf` hält es im RAM
  (geht bei Neustart verloren).

## Auf dem Handy

Das Dashboard passt sich ab 700 px Breite an Handy-Bildschirme an: Bedien-
elemente untereinander mit großen Tippflächen, Kacheln in zwei Spalten, alle
Charts in voller Breite mit angepasster Höhe, Tooltips per Tippen. Geprüft in
Chromium bei 412×915 (6,8 Zoll) in beiden Lagen.

Zwei Wege aufs Handy, beide brauchen `--host 0.0.0.0` (die Unit setzt es):

- **Web-App ohne Installation:** Chrome → `http://<Pi-Adresse>:8765` → Menü
  ⋮ → „Zum Startbildschirm hinzufügen". Manifest und Icon liefert der Server.
- **Android-App:** der Ordner `android/` ist ein Android-Studio-Projekt (WebView
  mit Adressverwaltung, Ziehen-zum-Neuladen, Fehlermeldung). Bauen: Studio →
  Build → Build APK(s). Details in `android/README_APP.md`.

## Audit 13.09.2026 — behobene Befunde

Ein externes Audit fand vier kritische Fehler. Alle wurden vor der Korrektur einzeln
nachgestellt:

* **Binance-Zeitstempel in Millisekunden** (`bnc_liquidations.ts`), gelesen in Sekunden.
  Da Millisekunden immer größer sind, war jeder Zeitfilter wahr: die Binance-Heatmap
  blieb leer, „Summen der letzten Stunde" waren Allzeitsummen. `parse_force_order`
  rechnet jetzt auf Sekunden um, `db_connect` migriert Altzeilen einmalig
  (`ts/1000 WHERE ts > 1e11`). **Merksatz: In diesem Projekt sind Zeitstempel Sekunden.**
* **Seiten vertauscht:** Die Seite wird beim Schreiben normalisiert, beim Lesen wurde sie
  aus dem ersten Buchstaben neu geraten — `"LONG".startswith("S")` ist falsch, also wurde
  aus long short. Jetzt durchgereicht, alte Rohwerte (`SELL`/`BUY`) weiterhin verstanden.
* **Kapitulationssignal:** feuerte wegen des Zeitfehlers nie und hätte nach dessen
  Behebung die Seiten vertauscht. Zusätzlich vergleicht es jetzt nur abgeschlossene
  Halbstundenblöcke gegen den Durchschnitt der übrigen.
* **Gelernte Gewichte zurückgesetzt**, weil die Kalibrierung auf diesen Signalen lief.

Dazu: Absturz von `--whale-analyze` bei unter 24 h Historie, unerreichbare
Watchdog-Entwarnung, unbegrenzt wachsende Zwischenspeicher, Maskierung aller Namen aus
fremder Hand (`esc()`), CSRF-Schutz für POST über eine eigene Kopfzeile, Grenzen für
Abfrageparameter und den Update-Download. Seit 23.75 (Audit v10 vom 22.10.) gehen auch die
schreibenden Aktionen der Seite nur per POST (Backup-Ziel setzen, Backup jetzt, alte Backups löschen, Konfluenz-Eintrag; per GET
Antwort 405), und der Chart liest unter 4-h-Kerzen höchstens 90 Tage, ab 4 h bis 5 Jahre.

**Offen und bewusst nicht geändert:** Das Dashboard lauscht weiter auf allen Adressen,
damit der Zugriff vom Handy erhalten bleibt. Wer es dichter will, bindet es an 127.0.0.1
und nutzt einen SSH-Tunnel; dazu käme eine Anmeldung mit Zufallstoken. Ebenfalls offen:
Positionen über einen Neustart hinweg sichern, mehrere statistische Verzerrungen
(Toleranzzone der Trefferquote, Doppelzählung in der Magnet-Statistik, Z-Basis ohne
Null-Stunden) und die Leistungsvorschläge.

## Konto-Score — wer hat recht, nicht nur wer ist groß (13.09.2026, Sitzung 2)

Die goldene Regel des Projekts lautet: Bei den größten Konten liegt das meiste Wissen.
`hl_score.py` macht sie messbar. Je Konto und Coin ein Score in [0, 1], täglich neu,
Schnappschuss in `forecasts.db` (Tabelle `account_score`):

| Anteil | Komponente | Woher |
|---|---|---|
| 35 % | **Vorlauf** — Folgerendite der eigenen Schritte nach 4 h, driftbereinigt, je Stunde ein Schritt, Bayes-geschrumpft (n / (n + 20)) | `whale_positions`, `lb_events`, `bars` |
| 25 % | **Edge je Umsatz** — PnL / Umsatz, 30 Tage sonst 7 | `lb_stats` (neu: alle vier Leaderboard-Fenster mit Umsatz, stündlich für Kandidaten und Wale) |
| 20 % | **Konsistenz** — positive Fenster von Tag / Woche / Monat / Gesamt | `lb_stats` |
| 10 % | **Größe** — log₁₀ Positionswert, rangnormiert | `addresses` |
| 10 % | **Klasse** — direktional 1,0 · gemischt 0,6 · Hedge / MM 0 | Verhaltensklassen |

Größe ist bewusst klein gewichtet: Sie ist die **Hypothese** der goldenen Regel, nicht
ihr Beweis. Der **Score-Test** (wöchentlich, `learned.score_test`) misst die
Rangkorrelation des Scores von vor sieben Tagen mit dem Vorlauf der Folgewoche — je
Komponente. Liegt „Größe" bei null, ist die Regel in ihrer Größen-Form für diesen
Markt widerlegt, und die Anteile werden nachgezogen.

Drei Treiber lesen den Score: **Smart-Flow 4 h** (Fluss aller bewerteten Konten, mit
Score gewichtet, Wurzel des Notionals), **Elite-Positionierung** (Netto-Ausrichtung der
zehn besten Konten) und **Gegen-Flow** (Fluss der Konten mit belegt negativem Vorlauf,
invertiert; Prior 0,3, Experiment). Die Flow-Treiber für Hedge-, Market-Maker- und
gemischte Konten sind dafür gestrichen — ihre Fills tragen keine Richtung. Die Elite-Liste
(`learn.elite`) ist zugleich die Vorgabe für WebSocket-Abonnements (zehn Nutzer je IP). Seit 23.39 kopiert das Labor die
Elite („Elite live folgen“, siehe TradeLabor), und das Werkzeug „Elite-Positionierung prüfen“ (`check_elite.py`) stuft genau
wie das Dashboard ein (`hl_viz.score_klasse`), lässt von der Masterregel Gesperrte weg und zeigt die gespeicherte Elite, die
Treiber, Recorder und Labor tatsächlich nutzen. Bis 23.38 zeigte es gesperrte Konten in der Elite, die das Dashboard längst
ausschloss.

## Kalibrierung v2 — K2-Neubau (23.09.2026)

Das alte Modell (v1) konnte eine echte Treiber-Kante nicht abbilden (Audit v10, K2: ein Treiber mit 93 %
Trefferquote ergab p_up 50,8 %). `hl_kalib.py` ist der Neubau: L2-regularisierte logistische Regression
auf standardisierten Treiber-Scores mit Achsenabschnitt, ohne den Nenner 19,4 und ohne β; der Prior ist
Ausgangspunkt, der mit der Datenmenge verschwindet (Zielvektor Prior·max(0, 1−n_eff/200)); λ per
geblockter Kreuzvalidierung mit Embargo (1-SE-Regel); 90 Tage nach Zeit; Toleranz-Labels; eine Prognose je
Block. **Abnahme:** die Positivkontrolle (Selbsttest-Schritt 22): Kante 0,65 → p_up 0,60–0,70, Rauschen bewegt
p um < 5 Punkte gegen die Basis — heute: 63,4 % / 0,6 Punkte. v2 läuft zunächst im **Schatten**: Sie
rechnet stündlich je Coin und Horizont, ihre Wahrscheinlichkeit steht als `p_up_v2` in jeder Prognose,
die Kachel „Kalibrierung v2" zeigt OOF-Quote, Brier-Skill, Zuverlässigkeitsdiagramm und die direkte
Bilanz v1 gegen v2 auf den gespeicherten Prognosen. Umschalten: Debug „Kalibrierung v2 AKTIVIEREN"
(Schalter in forecasts.db, jederzeit zurück). Nach dem Umschalten trägt v2 die angezeigte P(aufwärts).
Seit 23.47 (U120) misst der Brier-Skill der Kachel gegen denselben Kalibrierschritt mit c = 0 („gegen c 0“). Bei c = 0 ist
er genau 0, und die Quote heißt „Basisrate“: Sie ist dann nur der Anteil der häufigeren Richtung. Vorher wurde gegen die
OOF-Klimatologie gemessen; so zeigte schon die reine Basisrate Skill (Pi 05.10.: +0,005 bis +0,053). Die alte Zahl steht als
`brier_skill_klima` im Debug.
Seit 23.86 (U230) steht die direkte Bilanz v1/v2 auch im Bericht „Kalibrierung v2: Stand“ (Debug Nr. 89, in der Wochenprüfung):
je Coin Quote, Brier, Brier-Skill, n und Enthaltungen, dieselbe Rechnung wie die Kachel (`score_forecasts`), dazu die Zahl der
U7b-Regel (Quote und Brier-Skill v2 ≥ v1 bei je mindestens 100 Fällen; die Zuverlässigkeit prüft der Bericht nicht). Am 26.10.
wurde nach der Regel nicht umgeschaltet (UEBERGABE 3χχχχ).

## Masterregel Sperre (22.09.2026)

Ein Konto mit **mehr als 300 gebündelten Trades in 24 h** (je Coin, Minute und Richtung — dieselbe Einheit wie die
Aktivitätsschranke der Elite; seit 23.13, vorher 2.000 Fills: Fills sind Ausführungen, keine Entscheidungen) ist eine
Maschine (Market Maker, HFT). **Seit 23.29 gilt die Zwei-Tage-Regel:** Nach dem ersten Tag über 300 wird das Konto vorläufig
ausgeschlossen; liegt es binnen 7 Tagen an einem zweiten Tag darüber, wird es **dauerhaft gesperrt** (Tabelle `konto_status`,
automatisch beim Fill-Lauf), sonst nach 7 Tagen wieder frei. So bleibt ein Mensch mit einem einzigen extremen Tag erhalten. Die
Sperren der alten Fills-Regel werden einmalig neu bewertet, sobald 24 volle Stunden Trade-Zählung vorliegen: wer höchstens
300 gebündelte Trades hat, wird freigegeben (Status `frei`, Grund im Protokoll). Wirkung im ganzen System:
kein Verhaltenssignal (Direktionale Wale, Wal-Flow, Konto-Score, Elite, Smart-Flow, Gegen-Flow), keine
Order-Abfrage, keine Fill-Speicherung, der Leaderboard-Zyklus überspringt das Konto. Seine Positionen
wurden bis 23.85 noch alle 6 Stunden abgefragt (gedacht als Liquidationsstufe in der Heatmap; bei Überlast
nie erreicht); seit 23.86 gar nicht mehr (U220, Entscheidung 26.10.: oft Hedge-Positionen von Market-Makern,
das Budget geht an die größten Konten). In Tabellen erscheint die Marke GESPERRT. Manuell in `labels.json`: `"sperre": true`
sperrt, `"sperre": false` schützt ein Konto vor der Automatik. Werkzeug: Debug „Masterregel Sperre".

## Treiber-Signale: Pfeile, Blitze, Töne (22.09.2026)

In der Treibertabelle steht neben dem Namen ein grüner ▲ oder roter ▼, wenn sich der Score seit der
letzten Prognose um mindestens 0,05 geändert hat; ab 0,5 ein Doppelpfeil. Ein roter ⚡ markiert einen
**Umschwung**: mindestens zwei der fünf gewichtigsten Treiber sind binnen 10 Minuten um ≥ 0,5 gefallen
(grün, wenn gestiegen). Töne (Web-Audio, keine Dateien): springt ein Ereignis-Treiber an, ertönt bei
negativem Score 5 s eine Sirene, bei positivem 3 s „die Kasse klingelt"; ein Umschwung nach unten löst
ebenfalls die Sirene aus, nach oben die Kasse. Browser erlauben Ton erst nach einer Berührung: Schalter
„🔔 Töne" über der Tabelle (bleibt gespeichert), „Probe" spielt beide Töne. Der Verlauf je Coin liegt
60 Minuten im Browser (localStorage) und wird nur bei einer NEUEN Prognose fortgeschrieben.

## Version (22.09.2026)

Die Systemkachel zeigt **„Version"**: die Projektversion aus `version.py` (von Hand gepflegt, z. B.
`2026-09-22.1`) und eine Prüfsumme über alle Projektdateien (automatisch). Jedes gelieferte Paket
nennt beide Werte; stimmen sie mit der Kachel überein, läuft genau dieser Stand. `python3 version.py`
druckt sie auf der Kommandozeile.

## Letztes Backup wiederherstellen (14.09.2026)

Im Abschnitt „Aktualisierung" steht neben dem Update-Knopf **„Letztes Backup wiederherstellen"**.
Er spielt die Projektdateien aus dem jüngsten Ordner `updates/vor_*` zurück — der Sicherung, die
`update.py` vor jedem Update anlegt. **Datenbanken und Laufzeitzustand werden nicht berührt**:
`*.db`, `*.db-wal`, `*.db-shm`, `forecasts.db`, `sys_history.json`, `labels_cache.json`, `sudo.txt`
sind ausdrücklich ausgenommen, auch wenn sie im Backup-Ordner liegen. Vor dem Zurückspielen wird
der jetzige Stand nach `updates/vor_<stamp>_rueck` gesichert — die Wiederherstellung ist damit selbst
rückgängig zu machen (der Knopf zeigt dann diesen Ordner als jüngstes Backup). Ablauf wie beim
Update: Dienste stoppen, Dateien kopieren, Syntax prüfen (bei Fehler: alter Stand bleibt, Dienste
starten wieder), Dienste starten; Log in `updates/last_update.log`. Kommandozeile:
`python3 update.py --restore-last` (mit Rückfrage) bzw. `--restore-last --yes`; `--backup-info`
zeigt, welches Backup dran wäre.

## Reihen der Fremdbörsen (14.09.2026, `hl_ext.py`)

Bis 14.09. wurden Bybit, OKX, Crypto.com, die Binance-Verhältnisse, das Binance-Orderbuch
und die ETF-Flüsse nur live abgefragt; ihr Beitrag lag als fertiger Treiberwert im
Prognose-Payload, die Rohreihe ging verloren. Seitdem sammelt `hl_ext.py` sie als
Zusatzaufgaben im Dienst `hl-binance` (eigene Verbindung, eigene Threads):

| Tabelle | Inhalt | Takt | Vorhalt |
|---|---|---|---|
| `ext_metrics` | je Börse (bybit, okx, cdc) und Coin: `last`, `oi_coins`/`oi_usd`, `funding_8h`, `taker_ls` mit `taker_span_s` und `taker_n`, `ls_account`, Volumen | 5 min | 90 T |
| `bnc_metrics` | Binance `taker_ls`, `global_ls_account`, `top_ls_position`, `top_ls_account` im 5-min-Raster (Zeitstempel der API), zusätzlich zum Open Interest | 5 min | wie bisher |
| `bnc_book` | Binance-Orderbuch: bid/ask/mid, Tiefe ±5/25/100 bps, Wände je 0,25-%-Stufe (USD, ab 2 % der Tiefe, mind. 100 k) — wie `cb_book` | 5 min | 60 T |
| `ext_liquidations` | Bybit (WebSocket `allLiquidation`, vollständig) und OKX (REST, alle 2 min): `side` = **liquidierte Position** (`long`/`short`), Preis, Menge in Coins, Notional USD, `uid` gegen Duplikate | live / 2 min | 90 T |
| `etf_flows` | Farside: eine Zeile je Tag und Coin (BTC, ETH), Mio USD | 6 h | unbegrenzt |

Seitenbedeutung nach Doku geprüft: Bybit `S = Buy` heißt *Long liquidiert*; OKX liefert
`posSide`. Nicht gelistete Paare (Bybit `retCode 10001`, OKX `51001`, Crypto.com `40004`)
werden je Börse für einen Tag ausgelassen; andere Fehler werden gezählt, nicht gesperrt.

Ratenbudget je 5 Minuten: Bybit 18 Aufrufe (Limit 600 je 5 s), OKX ~26 plus 4 je 2 min
(Limit 20 je 2 s je Endpunkt, rubik 5 je 2 s), Crypto.com 12 (100/s), Binance 24
Verhältnis-Aufrufe und 60 Gewicht Orderbuch (von 2.400 je Minute). Zwischen den Aufrufen
0,3 s Pause; ein Kennzahlenlauf dauert rund eine Minute. Datenbankwachstum etwa 4 MB/Tag.

`hl_binance.py --status` zeigt Zeilen und Alter je Tabelle sowie die Sammler-Zähler;
die Quellenzeile „Bybit/OKX/Crypto.com gespeichert" im Netzwerkstatus, `hl_ext.py` als
Selbsttest (Parser und Seitenlogik gegen dokumentierte Beispielnachrichten). **Die
Prognose-Treiber lesen weiterhin live** — die Reihen sind zunächst Vorrat für Backtests
und neue Treiber (einheitliche Taker-Fenster, Kapitulation über drei Börsen).

## Statistik — Stichprobe, Intervalle, Nulltest (13.09.2026, Sitzung 2)

Alle 15 Minuten entsteht eine Prognose; bewertet wird sie nach 4 und nach 24 Stunden.
Zwei benachbarte Fenster teilen sich damit fast ihr ganzes Ergebnis — 96 Fenster sind
bei 24 h **eine** unabhängige Beobachtung, bei 4 h sind es sechs. Seit dieser Sitzung
rechnet das System deshalb überall mit **n_eff = Zahl getrennter Horizont-Blöcke** (bei
lückenlosen Fenstern ≈ Fenster / 16 für 4 h, Fenster / 96 für 24 h; bei geklumpten
Ereignis-Treibern die Zahl der Episoden):

* **Kalibrierung** (`hl_forecast.calibrate_weights`): zwei Spuren, 4 h (Hauptspur, alle
  15 min) und 24 h (stündlich). Regularisierung `lam = 4 / n_eff` statt `4 / n` — mit der
  alten Formel war der Prior bei 2.000 Fenstern praktisch abgeschafft (λ = 0,002), auf
  reinem Rauschen wanderten Gewichte um bis zu 0,12. Lernstart ab n_eff 40 (rund eine
  Woche für 4 h, rund 40 Tage für 24 h); ein einzelner Treiber verlässt seinen Prior erst
  ab eigenen unabhängigen Fällen — 50 auf der 4-h-Spur, 30 auf der 24-h-Spur (die in 60
  Tagen Vorhalt nie mehr als ~60 Blöcke sieht). Die 24-h-Spur trainiert mit einem Fenster
  je Stunde. Dazu ein gelernter Maßstab **β** (Prior 1): Er sagt, wie viel
  Wahrscheinlichkeit der Richtungsdruck wert ist; die gespeicherte **p_up** ist damit eine
  prüfbare Wahrscheinlichkeit, keine Vorgabe. Tabellen `weights_h` (je Horizont) und
  `learned.cal_4` / `cal_24`; `weights` bleibt als Spiegel der Hauptspur.
* **Trefferbilanz** (`score_forecasts`): eine Prognose je 15-min-Fenster, Wilson-Intervall
  auf n_eff, **Basisrate** (Quote von „immer aufwärts" in denselben Fenstern — nur der
  Abstand dazu ist Können), **Brier-Skill** der gespeicherten Wahrscheinlichkeit. Grün ist
  eine Quote erst, wenn ihr Intervall ganz über der Basisrate liegt.
* **Ensemble**: Beta-Posterior je Modell (50 Pseudo-Beobachtungen, Nullpunkt 0,5) statt
  „Trefferquote minus 0,4"; gedeckelt auf 30–70 %, bis beide Modelle n_eff 50 haben.
* **Magnet-Statistik**: Placebo-Niveau in gleichem Abstand auf der anderen Seite, **Lift**
  = Berührquote / Placebo, Intervall auf getrennten 12-h-Blöcken. Lift 1,0 heißt: kein
  Magnet.
* **Analog-Suche**: p_up gegen die unbedingte Basisrate der Historie gemessen, mit
  Intervall (50 Analoge streuen um ±7 Punkte). **Zeitprofil**: rollierend 180 Tage.
* **Ereignis-Signale (M9)**: Rang in der vollständigen Wochenreihe (inklusive
  Nullstunden) ≥ 98 % **plus** absolute Untergrenze (Wale 1 Mio, Leaderboard 500 k netto)
  **plus** Breite. Ein Perzentil allein feuert per Konstruktion mit fester Rate.
  `check_m9.py --db …` zeigt die Feuerraten alt/neu der letzten 7 Tage.
* **Nulltest** (`hl_forecast.py --nulltest`, Teil von `install.py --selftest`): die ganze
  Strecke auf reinem Rauschen. Soll aus der Mathematik — Quote 50 %, Brier-Skill 0,
  Gewichte beim Prior, Magnet-Lift 1, Rang-Signal ~2 % — nicht aus dem heutigen Ergebnis.
  Ein solcher Test kann keinen Fehler festschreiben.
* **Einheiten-Invarianten** (`hl_recorder.py --audit`): jede Zeitspalte in Sekunden
  (`MAX < 1e11`), die zwei bewussten ms-Spalten in Millisekunden, Seiten überall
  `long`/`short`. Eine Millisekunden-Zeile lässt den Audit mit Exit 1 enden.

## Betrieb

**Aufgaben werden überwacht.** Die neun Dauerläufer des Recorders (Feeds,
Polling, Snapshots, Flush, Backup, Orders, Leaderboard, Leaderboard-Fills,
Temperatur) laufen unter einer Aufsicht: Wirft eine Aufgabe eine Ausnahme, wird
sie mit Typ, Meldung und Codezeile ins Journal geschrieben, in `meta` vermerkt
und nach 5 Sekunden neu gestartet (Wartezeit verdoppelt sich bis höchstens
5 Minuten). Das Dashboard zeigt oben eine rote Leiste: „Aufgabe Leaderboard
abgestürzt (3× · zuletzt 17:12): AttributeError …", ebenso wenn sich der
Recorder länger als 3 Minuten nicht gemeldet hat. Vorher endete eine gescheiterte
Aufgabe still — ein fehlender Methodenname legte das Leaderboard 30 Stunden lahm,
ohne dass irgendwo etwas stand.

Alles zusammen im Vordergrund, etwa in tmux oder einer SSH-Sitzung:

```bash
.venv/bin/python run_all.py --host 0.0.0.0
```

Der Supervisor startet Recorder, Binance-Stream und Dashboard, mischt deren
Ausgaben mit Präfix in ein Log und startet abgestürzte Teilprozesse mit
wachsender Wartezeit neu. Strg-C beendet alles sauber.

Für echten Dauerbetrieb über Neustarts hinweg stattdessen `install.py --enable`.

**Nicht beides gleichzeitig.** Laufen die systemd-Dienste, sind Recorder,
Binance-Stream und Dashboard bereits gestartet. `run_all.py` würde dieselben
Prozesse ein zweites Mal starten, und das Dashboard scheitert dann mit
`Address already in use`. Der Supervisor prüft das inzwischen vorab und
verweigert den Start mit einem Hinweis.

```bash
systemctl status hl-dashboard hl-recorder hl-binance   # laufen sie schon?
sudo systemctl stop hl-recorder hl-binance hl-dashboard # für den Supervisor
sudo ss -ltnp | grep 8765                              # wer hält den Port?
```

Einzeln geht weiterhin:

```bash
.venv/bin/python hl_recorder.py --status               # Fortschritt
.venv/bin/python hl_viz.py --serve --host 0.0.0.0      # nur Dashboard
```

### Takte — drei unabhängige Schleifen

| Was | Takt | Stellschraube |
|---|---|---|
| Adressabfragen | laufend, gestaffelt nach Größe | `--polls-per-min`, `--hot-refresh`, `--cold-refresh` |
| Heatmap-Snapshot | alle 10 min | `--snapshot-sec` |
| Bars und Liquidationen | fortlaufend aus dem Stream | — |
| Binance Open Interest | alle 10 min | `--oi-interval` |

Der Poller läuft dauerhaft, nicht im Snapshot-Takt. Große Positionen werden
alle 3 Minuten abgefragt, mittlere alle 30; kleine (unter 25.000 USD) seit 23.86
nur nach eigenem Handel, sonst höchstens einmal am Tag (U220). Ein Snapshot ist
deshalb ein Mosaik aus unterschiedlich alten Abfragen.

Bei 240 Abfragen pro Minute reicht das Budget für grob 500 große plus 2.000
kleine Adressen. Darüber hinaus dehnen sich die Abstände still aus. Der
Recorder meldet deshalb alle 10 Minuten das Datenalter, die Zahl überfälliger
Adressen und die Auslastung — steht dort dauerhaft über 90 %, hinkt er
hinterher.

Binance ergänzen (kein API-Key nötig):

```bash
.venv/bin/python hl_binance.py --backfill    # 30 Tage OI, Ratios, Kerzen
.venv/bin/python hl_binance.py               # Liquidationen live
.venv/bin/python hl_binance.py --status
```

Zeitbasierte Heatmap (braucht keine eigene Aufzeichnung, nutzt Binance-Historie):

```bash
.venv/bin/python hl_timestats.py --coin BTC --years 3 --png
.venv/bin/python hl_timestats.py --coin BTC --tz Europe/Berlin --json danger.json
```

Zählt je Wochentag und 30-Minuten-Fenster, wie oft die Bewegung 1 % bzw. 3 %
überschreitet. 7 × 48 = 336 Felder. Weil 336 gleichzeitige Tests bei 5 % Niveau
allein zufällig rund 17 Treffer erzeugen, rechnet das Skript
Wilson-Konfidenzintervalle mit Bonferroni-Korrektur und markiert nur Felder,
deren Untergrenze über der Grundrate liegt. Gegen reines Rauschen geprüft:
0 von 336 Feldern überleben die Korrektur.

Eine vorab formulierte Vermutung gezielt prüfen (ein Test statt 336, daher
ohne Korrektur und deutlich aussagekräftiger):

```bash
.venv/bin/python hl_timestats.py --coin BTC --no-fetch \
    --test-window 02:00-05:00 --tz Europe/Berlin --thresholds 0.01 0.03
```

Vergleicht das Fenster gegen den Rest des Tages, mit Konfidenzintervallen,
Zwei-Stichproben-Test und einer Aufschlüsselung Jahr für Jahr — letztere zeigt,
ob der Effekt stabil ist oder aus einem einzelnen Jahr stammt. Fenster über
Mitternacht hinweg und ein Wochentagsfilter (`--weekdays 0,1,2,3,4`) werden
unterstützt.

**Die Kernthese — Cluster als Magnet:**

```bash
.venv/bin/python hl_recorder.py --magnet-analyze --coin BTC
```

Je Stunde: größtes Short-Cluster oberhalb, größtes Long-Cluster unterhalb.
Welches wird zuerst erreicht? Drei Regeln im Vergleich — Größe (die These),
Nähe (reine Geometrie), Zufall. Entscheidend ist die Teilmenge, in der Größe
und Nähe *verschiedene* Ziele nennen; nur dort ist die These von der
Geometrie unterscheidbar. Die Messlatte dort ist nicht 50 %, sondern die
geometrische Erwartung eines driftlosen Pfads (d_nah / (d_nah + d_fern)).

Geprüft: Auf Zufallsdaten sieht die Größe-Regel naiv nach 60 % Treffern aus,
weil große Cluster meist auch nah sind — in der uneinigen Teilmenge bleibt
davon nichts über der Geometrie (z = 0,9). Auf Daten mit eingebautem Magneten
findet der Test ihn deutlich (z = 7,7).

Haben Wal-Aktionen Vorhersagekraft?

```bash
.venv/bin/python hl_recorder.py --whale-analyze --coin BTC
```

Misst die Kursbewegung nach jeder Wal-Aktion in der implizierten Richtung —
und dasselbe an zufälligen Zeitpunkten als Kontrollgruppe. Erst der Unterschied
sagt etwas: In einem steigenden Markt „haben" auch zufällige Longs meist recht.
Ein Blick auf die ersten fünf Minuten trennt Impact (die Wal-Order bewegt den
Kurs selbst) von Information (der Kurs läuft erst später). Und selbst ein
Vorsprung ist kein Insiderwissen: Ein großer Short kann eine abgesicherte
Spot-Position sein, und was jeder sehen kann, ist im Kurs meist schon drin.

Stimmen die Daten in sich?

```bash
.venv/bin/python hl_recorder.py --audit
```

Der Wächter fragt, ob die Daten frisch sind. Der Audit fragt, ob sie
*stimmen*: Sind alle Kerzen minutengenau, wie viele Minuten fehlen? Deckt der
Markpreis-Feed die Handelsminuten ab? Hat jeder Snapshot einen Qualitätsstempel,
und stimmt dessen Positionszahl exakt mit der Heatmap überein? Ist der
Snapshot-Takt regelmäßig, wie viele Neustarts gab es? Liegt die Abdeckung in
einem plausiblen Bereich? Hat jeder Wal einen sauberen Lebenszyklus — keine
doppelte Eröffnung, keine Änderung ohne Eröffnung? Gibt es Duplikate in den
Cluster-Events? Geprüft mit gezielt beschädigten Datenbanken: Alle eingebauten
Fehler werden gefunden.

Ergebnisse zum Weitergeben oder Hochladen exportieren:

```bash
.venv/bin/python hl_recorder.py --analyze --coin BTC     # zuerst labeln
.venv/bin/python hl_recorder.py --export export.zip      # dann exportieren
```

Die Datenbank wird nach Monaten hunderte Megabyte groß und ist nicht mehr
handhabbar. Das Export-Paket enthält nur die gelabelten Ereignisse und
Aggregate und bleibt bei wenigen hundert Kilobyte: `cluster_events.csv` mit
abgeleiteten Zeitspalten, Tagesabdeckung für Bars und Snapshots,
`time_heatmap.csv`, stündlich aggregierte Binance-Liquidationen und eine
`meta.json` mit Zeitraum, Umfang und Datenqualität. Rohdaten verlassen den
Pi nicht.

Nach einigen Wochen:

```bash
.venv/bin/python hl_recorder.py --analyze --coin BTC
.venv/bin/python hl_viz.py --coin BTC --hours 168
```

Backtest der Trendfolge, unabhängig vom Recorder:

```bash
.venv/bin/python hl_backtest.py --coin BTC --interval 4h --days 700 --plot
.venv/bin/python hl_backtest.py --spot --coin HYPE --interval 4h --days 700
```

## Wer steckt hinter einer Wallet?

Die Wal-Tabelle nennt je Wallet, wenn bekannt, den Namen dahinter — aus fünf
Quellen, in dieser Reihenfolge:

1. `labels.json` im Projektordner — eigene Pflege, hat Vorrang, wird von
   Updates nie überschrieben. Format: Adresse (klein) → `name`, `kategorie`,
   `quelle`. Vorbelegt mit den Protokolladressen von Hyperliquid (HLP-Vault,
   Assistance Fund, HLP-Strategie-Vaults).
2. Hyperliquid-Leaderboard — selbst gewählte Anzeigenamen; kein API-Gewicht,
   alle 6 h neu.
3. Etherscan-Namenstags über `octal.art/etherscan-labels` (Börsen, Fonds,
   Market Maker) und Arbiscan-Tags aus dem offenen Datensatz
   brianleect/etherscan-labels — dieselbe Adresse zahlt ihr USDC über Arbitrum
   ein, dort verrät die Herkunft oft den Besitzer.
4. `vaultDetails` — ist die Adresse ein Hyperliquid-Vault? Kostet API-Gewicht
   20 und teilt sich das Limit mit dem Recorder; deshalb höchstens eine
   Abfrage pro Minute, Ergebnis 7 Tage im Cache (`labels_cache.json`).
5. Verhaltensklasse aus den eigenen Daten: „Hedge-Muster" (mehrere Coins, eine
   Seite, Hebel ≤ 10 — typisch für Market Maker und Basis-Trader),
   „Market-Maker-Muster" (beidseitig viele ruhende Limits), „direktional".

Dazu je Wallet Links zu HypurrScan, Arbiscan und Arkham. „unbekannt" heißt:
keine Quelle kennt einen Namen — das ist bei den meisten Walen der Fall; die
Verhaltensklasse ist dann oft die nützlichere Information. Mit einem
Nansen- oder Arkham-Schlüssel ließe sich eine Entitätsabfrage anschließen.

## Coinbase-Spot als eigene Quelle

`hl_coinbase.py` zeichnet den US-regulierten Spotmarkt auf — eigener Dienst,
eigene Ratengrenze (10 Anfragen/s), unabhängig vom Hyperliquid-Budget. Quellen:
der WebSocket-Ticker (liefert bei jedem Handel Preis, Menge, Seite und die
Buchspitze), das Orderbuch alle 30 s und Minutenkerzen alle 15 min zum Füllen
von Lücken. Tabellen: `cb_bars` (Minutenkerzen mit Taker-Käufen und -Verkäufen
in USD), `cb_book` (Tiefe bei ±5/25/100 Basispunkten plus Wände), `cb_meta`.

**Vorzeichen-Falle:** Coinbase gibt im Feld `side` die **Maker**-Seite an.
`side=sell` heißt, eine ruhende Verkaufsorder wurde getroffen — der Taker hat
also gekauft. Das ist genau umgekehrt zu Binance und Hyperliquid; ein Fehler
dort würde jedes Flow-Signal umdrehen. `hl_coinbase.py --selftest` prüft es.

Daraus entstehen drei Prognose-Treiber: **Coinbase-Prämie** (Spot gegen
Perp-Kurs in Basispunkten, gemessen als Z-Wert gegen die eigene 7-Tage-Reihe,
Startgewicht 0,8), **Spot-Taker-Flow** (0,7) und **Spot-Orderbuch** (0,4).
Warum Spot: Er muss ohne Hebel bezahlt werden. Dazu Regeln in der Konfluenz,
eine Kachel und Zeilen im Netzwerkstatus.

## Dashboard

**Netzwerkstatus (Abschnitt über der Aktualisierung).** Alles, was ins Netz geht,
an einer Stelle: ein Chart mit dem verbrauchten API-Gewicht je Minute, getrennt
nach Verbraucher (Poller, Orders, Fills, Leaderboard) und gestapelt gegen die
Grenze von 1.200 je Minute; darunter der Zeitplan aller wiederkehrenden Aufgaben
mit letzter Ausführung, Dauer, Ergebnis und nächster Fälligkeit; dazu Ratengrenze,
429er, Temperaturschutz, Poller-Zustand, Fill-Abholstand und die gemeldeten Fehler
mit Aufgabe, Zeitpunkt und Meldung. Die Angaben, die vorher über Kacheln und
Abschnitte verteilt waren (API-Kachel, Poller-Zeile, Abholstand im Leaderboard),
stehen nur noch hier.

**Deckel des API-Gewichts (hart seit 23.38).** Der Recorder vergibt Gewicht nur, solange die Summe im gleitenden
60-s-Fenster unter 1.080 bleibt (90 % von 1.200, bei Temperaturschutz entsprechend weniger). Bis 23.37 konnten die
Eimer des Begrenzers ihren Füllstand obendrauf ausgeben: in der ersten Minute nach jedem Start rund 1.470, im Betrieb
bis ~1.120 (Vollbericht 30.09.: 1.092/1.080). Jetzt startet der Begrenzer leer, und seine Eimer werden nie voller als der
Platz im Fenster. Der Durchsatz sinkt dadurch um etwa 2,5 %.

**Last-Schutz (seit 23.35).** Mehrere offene Seiten fragen dieselben Daten ab. Läuft eine Anfrage schon, rechnet der Server sie
nicht ein zweites Mal: Wer gleichzeitig fragt, bekommt die vorige Antwort (bis 10 min alt) oder die laufende. Auch die Seite
schickt dieselbe Anfrage nicht erneut, solange die Antwort aussteht. Der jüngste Stand der Wal-Positionen kommt aus den letzten
6 h, nicht mehr aus der ganzen, täglich um ~60.000 Zeilen wachsenden Tabelle. Am 29./30.09. hatte genau das einen Stau
ausgelöst: Das Dashboard lag dauerhaft bei 366 % CPU. Diagnose, falls es wieder hoch geht: Debug „Dashboard-Threads“ zeigt
für jeden Thread die Stelle, an der er gerade rechnet, und seinen CPU-Anteil. Seit 23.36 steht darunter die CPU des ganzen
Prozesses: „Rest, kurze Anfragen“ ist der Anteil der Anfragen, die zu kurz leben, um in einer Probe aufzutauchen, dazu die
Zahl der Anfragen je Sekunde. Auch der Recorder liest beim Start nur noch die letzten 24 h der Wal-Tabelle (vorher die ganze,
40 s und mehr ohne Aufzeichnung). Die Exposure-Zeitreihe über der Wal-Tabelle zählt gesperrte Konten nicht mehr.

**Aufbau.** Ein Kopf, der beim Scrollen oben bleibt: Coin-Auswahl, „Neu laden"
und eine Navigation zu den sechs Abschnitten. Darunter die Kacheln, dann die
nummerierten Abschnitte — Live-Chart, Konfluenz, Orders & Stops, Heatmap,
Momentaufnahme, Wale — und ganz unten die Aktualisierung. Jeder Abschnitt
klappt am Titel ein und aus; der Zustand bleibt im Browser gespeichert. Das
„ⓘ" im Titel zeigt die Erklärung des Abschnitts. Bedienelemente stehen dort,
wo sie wirken: Raster, FVG-Schalter und FVG-Mindestgröße beim Chart, der
Zeitraum bei der Heatmap.

**Datenquelle.** Die Auswahl „Quelle" im Kopf schaltet alle Abschnitte um:

- *Hyperliquid Daten* — wie bisher: eigene Kerzen, erwartete Liquidations-
  cluster aus den Positionen, Orders der Großkonten, Wale.
- *Binance Daten* — Kerzen von Binance (live, sonst `bnc_bars`/`daily_bars`),
  Marken und Heatmap aus den **eingetretenen** Liquidationen
  (`bnc_liquidations`), Orderbuch mit Tiefe statt Konten-Orders, statt der Wale
  die Kennzahlen Open Interest, Long/Short (Konten, Top-Trader) und Taker-Flow
  (`bnc_metrics`, live nachgeladen). Konfluenz mit Binance-Regeln: Taker-Flow
  ±1, einseitige Konten als Hinweis, laufende Kaskade als „Abwarten" (der
  Punkt Top-Trader-Positionierung ist seit 23.67 entfernt, U151). Bekannte Lücken
  bis 23.68 (U166): Das Hinweisfenster des Charts bricht an eingetretenen Marken
  mit einem Skriptfehler ab, FVG und Orderbuch zeigen „NaN %“, die
  Schlüsselniveaus fehlen. Die Wahl der Quelle merkt sich der Browser.
- *Data Mix Fusion* — der Hyperliquid-Stand plus Binance und Crypto.com: Binance-Orderbuch
  je Preisstufe zu den Orders **addiert** (beides ruhende Orders), eingetretene
  Liquidationen beider Börsen als Marker im Chart (Binance orange, HL magenta)
  und in der Heatmap, Binance-Liquidationen der letzten 24 h als Overlay in der
  Momentaufnahme (nicht addiert — Erwartung und Ereignis sind verschiedene
  Größen), Volumen beider Börsen summiert, Binance-Kennzahlen unter den Walen,
  Konfluenz mit beiden Regelsätzen und Funding-Vergleich.

**Crypto.com als dritte Börse** (Binance- und Fusionsmodus): Open Interest,
24-h- und Stundenvolumen, Taker-Flow aus den letzten 150 Trades, Prämie des
Perpetuals gegen den Index (Funding-Näherung), Orderbuch — in der Fusion je
Preisstufe zu HL-Orders und Binance-Buch addiert. Die Konfluenz rechnet den
Taker-Flow **börsenübergreifend**, nach Volumen gewichtet, als einen Punkt;
sind die Börsen uneins, gibt es keinen Punkt, nur den Hinweis. Eine
gegenläufige Prämie zum Hyperliquid-Funding erscheint als Hinweis. Die
Marktdaten sind öffentlich — kein Schlüssel nötig. Coins, die Crypto.com nicht
handelt, zeigen „—".

**Bybit und OKX** (Binance- und Fusionsmodus, öffentliche Endpunkte, kein
Schlüssel): Open Interest, Funding, 24-h-Volumen, Long/Short-Konten, Taker-Flow
(Bybit aus 500 Trades, OKX aus der 5-min-Statistik), OKX zusätzlich die
jüngsten Liquidationen. Kacheln: „Open Interest N Börsen" mit Aufteilung,
„Taker börsenübergreifend" volumengewichtet, „Long/Short Konten je Börse",
„Funding Ø Börsen". Konfluenz: der Taker-Flow aller erreichbaren Börsen ist
ein Punkt; börsenübergreifend einseitige Konten (Ø ≥ 2,5 : 1 oder ≤ 0,6 : 1) und
OKX-Liquidationen ab 5 Mio/h sind Hinweise.

**ETF-Flows** (BTC und ETH, jede Quelle): tägliche Netto-Flüsse der US-Spot-
ETFs, einmal pro Stunde von der Farside-Tabelle gelesen; mit CoinGlass-Schlüssel
in `accesstokens.json` stattdessen von CoinGlass. Kachel mit letztem Tag,
5-Tage-Summe und Serie. Konfluenz: ein Punkt, wenn letzter Tag und 5-Tage-Summe
dasselbe Vorzeichen haben, sonst Hinweis. Ein Tageswert — Regime, nicht Timing.

**Leaderboard und Smart Money.** Beim Start lädt der Recorder das Leaderboard
**zuerst** — Konten, Positionen und die Trendzeile der laufenden Stunde stehen,
bevor Feeds und Polling beginnen; das Dashboard ist damit sofort vollständig.
Danach lädt der Recorder alle 10 Minuten das
Hyperliquid-Leaderboard, geht die Konten nach 30-Tage-PnL von oben durch und behält die ersten 50, die
auf dem Perp-Konto tatsächlich Positionen halten (`--lb-top`, aus den besten
400, `--lb-candidates`). Das ist nötig, weil das Leaderboard Spot, Vault-Anteile
und Unterkonten mitzählt — die Spitze nach PnL sind Vaults und Market Maker
ohne Perp-Position. Flache Konten werden eine Stunde gemerkt, damit die Auswahl
nicht jede Runde das volle Gewicht kostet (erster Durchgang bis zu 400 Abfragen,
danach etwa 60 je Runde). „Kontowert" ist das Perp-Konto (`marginSummary`),
nicht der Leaderboard-Wert. Tabellen: `lb_accounts` (Rang, Name,
Kontowert, PnL 30 T / 7 T), `lb_positions` (Coin, Seite, Wert, Hebel, Einstieg,
Liq.-Preis, unreal. PnL, Kurs) je Abfrage und `lb_trend` einmal pro Stunde je
Coin für Top 20 und Top 50: Konten und Wert je Seite, Netto, Kurs — die
Zeitreihe für die spätere Auswertung, ob die Positionierung der Besten dem Kurs
vorausläuft. Dashboard-Abschnitt 7 zeigt die Top 20 mit allen Positionen und
PnL (gruppiert wie die Wale, Export als Chart und Liste) und den Trend-Chart des
gewählten Coins: Long- und Short-Wert je Stunde, Netto als Linie, Kurs weiß.
Kachel „Leaderboard Top 20 — BTC-Trend“: Konten und Wert je Seite in BTC,
Netto und dessen Veränderung gegen 24 h und 7 Tage. Konfluenz: Drehung des
Netto-Vorzeichens oder Aufbau ≥ 25 % innerhalb 24 h als Hinweis. Die
Smart-Money-Kachel (Top 50) liest dieselbe Abfrage; Punkt ab 1,5-fachem Übergewicht.

**Käufe und Verkäufe der Top-Konten** (Abschnitt 8). Der Recorder holt etwa
90 s nach dem Start und dann stündlich für die 50 Top-Konten die Fills der
letzten 3 Tage (`userFillsByTime`, Gewicht 20 je Konto, eine Seite à 2.000
Fills je Lauf, Perp **und** Spot, nur Fills ab 5.000 USD — Market-Maker-Staub
bleibt draußen; ältere Fills werden gelöscht, die Tabelle bleibt klein) und
die Spot-Bestände (`spotClearinghouseState`, Gewicht 2) — rund 1.100 Gewicht
pro Stunde. Der Abholstand je Konto steht in `lb_cursor` und richtet sich nach dem neuesten
**geholten** Fill, nicht nach dem neuesten gespeicherten: Ein Konto, dessen Fills
sämtlich unter 5.000 USD liegen, hätte sonst nie einen neueren Eintrag, und die
Abholung liefe für immer gegen dieselbe Stelle (beobachtet: die Trade-Liste stand
18 Stunden still). Kommt ein Konto trotz drei Seiten à 2.000 Fills mehr als 6 Stunden
in Rückstand, springt die Abholung auf die letzten 2 Stunden. Der übersprungene
Zeitraum wird in `lb_gaps` festgehalten und im Vollbericht aufgelistet — eine Lücke,
von der man weiß, ist brauchbar; eine unbekannte verfälscht jede Auswertung — eine Lücke ist besser
als dauerhafter Rückstand, weil die Signale von den letzten Stunden leben.
Teilausführungen einer Order werden in den Tabellen je Minute gebündelt (»17×«),
sonst füllen Dutzende identischer Zeilen die Ansicht.
Tabellen `lb_fills` (dedupliziert über Konto und tid; Spot-Paare
über `spotMeta` auf den Basistoken abgebildet, UBTC → BTC, UETH → ETH,
USOL → SOL) und `lb_spot` (Stundenstand mit Einstandswert und USD-Wert).
Nach jedem Fill-Lauf folgen in der Ereignisschleife Stundenaggregat, Masterregel, Verdichten und Löschen
sowie die Vielhandler-Regel; seit 23.75 steht ihre Dauer im Vollbericht (Abschnitt Recorder, zuletzt und
höchstens seit dem Start) -- erst messen, dann über einen Umbau entscheiden (Audit v10 vom 22.10., M-3).
Dashboard: Übersicht je Coin — Käufe, Verkäufe, Konten je Seite, Netto 3 T und
24 h, Spot-Anteil, realisierter PnL —, die größten Trades im gewählten Coin mit
der Kursentwicklung seit dem Trade aus Sicht des Traders, die Spot-Bestände mit
Entwicklung seit Einstand. Kaufdruck = Open Long + Close Short + Spot-Kauf.
Kachel „Leaderboard Käufe/Verkäufe" mit Netto 24 h und 3 T. Die Summen rechnet
SQLite über die Spalte `buy`, das Ergebnis wird im Hintergrund alle 30 s
erneuert — der Chart-Aufruf wartet nie darauf.
Abschnitt 9 zeigt dieselben Fills für die letzten 48 Stunden: je Stunde
Kauf- und Verkaufsdruck im gewählten Coin als Balken, den aufgelaufenen Netto-
Wert als Linie, den Kurs weiß; darunter die Übersicht je Coin und alle Trades ab
50k, neueste zuerst — für ganz aktuelle Signale. Konfluenz: ein
Punkt ab 1,5-fachem Übergewicht in 24 h bei mindestens 1 Mio und 3 Konten.

**accesstokens.json** — eine normale Datei im Projektordner für Schlüssel
optionaler Quellen (CoinGlass, CryptoQuant, Glassnode, Nansen, Arkham), leer
vorbelegt; `update.py` überschreibt sie nie. Nichts davon ist heute nötig;
sobald ein Schlüssel eingetragen ist, kann die jeweilige Quelle angeschlossen
werden. Für Tests ohne Netz liefert `HL_TEST_STUBS=1` feste Crypto.com-Antworten.

Die Wahl bleibt im Browser gespeichert. Live-Abrufe von Binance (Kerzen kurzer
Raster, Orderbuch, Funding, Verhältnisse) werden 15 s bis 5 min im Speicher
gehalten; ohne Netz greift die Datenbank, das Orderbuch meldet sich dann ab.

**Debug-Konsole** (Abschnitt ganz unten): startet ein Diagnoseskript oder liest
ein Journal aus einer festen Liste — Leaderboard-Diagnose, Order-Abfragen,
Tageskerzen, Speicherbelegung, Recorder-Audit und -Status, Binance-Status,
Journale der drei Dienste, Update-Log, Dienststatus, Datenträger. Läuft als
Dashboard-Benutzer ohne sudo, kein freies Kommando. Ganz oben steht **„★ VOLLBERICHT"** — ein Lauf, der
den kompletten Systemzustand sammelt (seit 23.68, U168: jede Tabelle wird genau einmal gezählt, die große Heatmap zuletzt; ein
Zeitbudget von 8 min für die Zählung, was danach fehlt, steht als „nicht gezählt (Zeitbudget)“; jeder Abschnitt erscheint sofort mit
seiner Laufzeit; die Kontrolle des Zuwachses zählt nur die Zeilen der letzten zwei Minuten; der Berichtsplan meldet „nahe der
Zeitgrenze“ ab 600 s. Bis 23.67 zählte er jede Tabelle dreimal und brach am 14.10. an der Grenze von 15 min ab): Dateiversionen und
Dienste, Tabellenstände mit Zuwachs je Stunde, API-Gewicht und Poller-Zustand,
Aufgabenabstürze, Temperaturschutz und Backup, Leaderboard und Wal-Gruppen mit
Flow, Lernstand und Trefferquoten der Prognose, Temperatur und Speicher, dazu
die auffälligen Journalzeilen aller drei Dienste. Die Stundenraten werden aus den Zeitstempeln gezaehlt, nicht aus einem kurzen Fenster hochgerechnet — ein Strom, der in Schueben schreibt, ergab sonst je nach Messzeitpunkt 0/h oder 353.000/h. Dazu eine Zeile „Groesste Luecke in den letzten 24 h“ je Datenstrom: Ein stiller Ausfall zeigt sich nicht an der Zeilenzahl, sondern am Abstand zwischen zwei Eintraegen. Ein Fehler in einem Abschnitt
bricht den Bericht nicht ab, sondern steht darin. Gedacht zum Einfügen in einen
Chat — „Als Datei" für lange Berichte. Die Ausgabe erscheint in einem
Textfeld. „Konsole kopieren" legt sie mit Kopfzeile (Lauf, Zeit, Coin, Quelle,
Exit-Code) in die Zwischenablage — auch über HTTP, wo die Zwischenablage-API
gesperrt ist, per Kopierbefehl aus dem Textfeld. „Alles markieren" wählt den
Text für das Handy-Menü aus, „Als Datei" speichert ihn als .txt zum Teilen. Journale
brauchen Leserecht (Gruppe `systemd-journal`: `sudo usermod -aG systemd-journal seed`). Seit 23.84 hat jeder Lauf eine feste
Nummer; ins Feld „Nr.“ tippen wählt ihn aus (Abschnitt „Debug-Nummern“ unten).

**Temperaturschutz im Recorder.** Der Recorder liest alle 30 s die
CPU-Temperatur und drosselt sich in drei Stufen, jeweils mit 3 °C Hysterese
beim Verlassen: ab 70 °C 15 % weniger API-Gewicht pro Minute und 15 % längere
Takte (Positions-Polling aller Stufen, Order-Abfragen, Leaderboard, Fills); ab
75 °C 30 % / 45 %; ab 80 °C 50 % / doppelte Takte. Die Feeds laufen unverändert
weiter — sie kosten kein Gewicht, nur die Abfragen werden gestreckt. Stufe und
Faktoren stehen im Journal, in der API-Kachel („Temperaturschutz Stufe 1:
Gewicht −15 %, Takte +15 %") und im System-Abschnitt.

**System — Temperatur und Zustand des Pi** (ganz unten, unter Debug). Der
Dashboard-Server misst alle 60 Sekunden CPU-Temperatur (Thermal-Zone, sonst
`vcgencmd`), Drosselungsflags der Firmware (Unterspannung, Takt begrenzt,
gedrosselt, Temperaturlimit — jeweils jetzt und seit Start), CPU-Takt,
CPU-Last gesamt in Prozent (aus `/proc/stat`, gemittelt über die Minute) mit
Last 1/5/15 min, RAM gesamt / frei (MemAvailable) mit belegtem Anteil, freien Platz auf System- und Datenbank-Datenträger und Laufzeit; er
hält 24 Stunden Verlauf, die Seite fragt jede Minute nach. Kacheln mit Farben
(grün < 60, gelb < 70, orange < 80, rot ≥ 80 °C — der Pi 5 drosselt ab 80 °C)
und ein Verlaufs-Chart: Temperatur gelb mit den Linien 70 und 80 °C, CPU-Last
blau auf der rechten Skala 0–100 %. Endpunkt `/system`.

**Fehlerleiste.** Rote Leiste oben bei Verbindungs- oder Skriptfehlern.
Verbindungsfehler verschwinden von selbst, sobald wieder Daten ankommen —
etwa wenn das Handy den Browser aus dem Hintergrund holt: Die Seite erkennt
den sichtbaren Tab, lädt sofort neu und räumt die Leiste mit der ersten
erfolgreichen Antwort weg. Skriptfehler bleiben stehen, die gehen nicht von
allein weg.

**PNG-Export.** Das „⤓" im Titel eines Abschnitts (und der Link unter dem
Binance-Kennzahlen-Chart) speichert den Chart als PNG in dreifacher
Auflösung — der Chart wird dafür neu gezeichnet, nicht hochskaliert, Linien
und Schrift bleiben scharf. Kopfzeile mit Titel, Coin, Quelle und Zeitstempel,
Dateiname `hl_<chart>_<coin>_<quelle>_<datum-uhrzeit>.png`. Bei 1.370 px
Chartbreite ergibt das rund 4.200 px Breite. Der Wal-Abschnitt hat zwei
Exporte: „⤓ Chart“ für das Exposure-Chart und „⤓ Liste“ für die gruppierte
Wal-Liste mit allen Positionen, Namen und Verhaltensklassen — bei sehr langen
Listen in mehreren Teilen (`_teil1`, `_teil2`), damit die Bildhöhe die
Browser-Grenze nicht überschreitet.

**Was bleibt bei Neustart und Update erhalten.** Alles, was zählt, liegt in
Dateien: die Aufzeichnung in der Datenbank auf dem USB-Stick; Prognosen,
gelernte Gewichte und der Lernstand (Analog, Magneten, Zeitprofil) in
`forecasts.db` im Projektordner; Wallet-Zuordnungen in `labels.json` und
`labels_cache.json`; Schlüssel in `accesstokens.json`; der Systemverlauf
(Temperatur, CPU) in `updates/sys_history.json`, alle 5 Minuten gesichert.
`update.py` ersetzt nur die Programmdateien und rührt diese Dateien nicht an.
Im Browser bleiben Quelle und eingeklappte Abschnitte gespeichert. Neu aufgebaut
werden nach einem Neustart nur Zwischenspeicher: Live-Abfragen der Börsen, die
Positionskarte des Recorders (nach einer Abfragerunde wieder voll) und die
Merkliste flacher Leaderboard-Konten (der erste Durchgang prüft bis zu 400
Konten, danach wieder 60). `forecasts.db` ist NICHT Teil des
Datenbank-Backups — wer sie sichern will, kopiert die Datei mit.

**Prognose-Chart bedienen.** Ansicht 24 h / 3 T / alles, ◀ ▶ zum Blättern,
„jetzt" zentriert. Ziehen mit Maus oder Finger scrollt, Mausrad und Pinch
zoomen, Fahren oder Tippen zeigt Stunde, Prognose, Band und reines Modell.
Unter 30 h Spanne Stundenraster, unter 5 Tagen 6-Stunden-Raster; die
Preisskala folgt dem sichtbaren Ausschnitt.

**AI-Prognose** (Abschnitt nach der Konfluenz, Modul `hl_forecast.py`). Alle
15 Minuten je Coin im Hintergrund, sofort auf Abruf beim ersten Mal. Vier Teile:
Regime und Drift (MA 200 T, MA 50 W, 60-min-Trend, RSI, 7-Tage-Drift);
Richtungsdruck nur aus direktionalen Konten (direktionale Wale, direktionales
Smart Money, Käufe/Verkäufe direktionaler Leaderboard-Konten 24 h,
Top-20-Trend) plus Taker-Flow aller Börsen, Funding gegen die Menge, ETF-Flows,
Orderbuch; Magneten (Liq-Cluster ziehen, Wände bremsen, gekreuzter Stop-Auslöser
wird zur Kaskade); Pfad Stunde für Stunde bis 7 Tage mit Band aus der
realisierten Volatilität × √t. Ergebnis: Bias mit Konfidenz, optimaler Kaufpreis
und Verkaufspreis im Fenster 4–12 h mit Begründung (an Wänden und Clustern
ausgerichtet; bei klarem Gegendruck „nicht ratsam"), nächste Bewegung, 7-Tage-
Endpunkt mit Band, alle Treiber mit Richtung und Gewicht. Jede Prognose landet
in `forecasts.db` (eigene Datei des Dashboards); nach 4 und 24 h wird die
Richtung gegen den echten Kurs geprüft — Trefferquote und mittlerer Fehler
stehen in der Kachel. Endpunkt `/forecast?coin`. Kein Orakel: ein Modell aus
sichtbaren Daten, dessen Trefferquote über die Wochen zeigt, was es taugt.

**Leaderboard-Flow — Positionsänderungen der Top-Konten als Ereignisse.**
Der Recorder fragt die 50 Top-Konten alle 5 Minuten ab und leitet aus dem
Vergleich zweier Stände Ereignisse ab: open, add, reduce (ab 2 % Änderung),
close, flip — Tabelle `lb_events`. Das Dashboard rechnet daraus den
Leaderboard-Flow der direktionalen Konten über 60 Minuten und 3 Stunden, mit
Z-Score gegen die eigenen Stundenflüsse; ab 500k brutto und zwei Konten ein
Konfluenz-Punkt, ab Z 2,5 und drei Konten ein Ereignis-Signal mit zwei Punkten,
in der Prognose ein Treiber mit Gewicht 1,0. Der Wächter reagiert auch auf
diese Ereignisse mit einer Sofortberechnung. Abschnitt 7 zeigt den Flow live
und die letzten Änderungen der Top-Konten; nicht-direktionale sind ausgegraut.
Latenz: bis zu 5 Minuten (Abfragetakt) — die Fills (stündlich) bleiben die
Quelle für Perp und Spot im Detail.

**Ereignisse werden aus der Positions-GRÖSSE abgeleitet, nicht aus dem Wert.**
Der USD-Wert einer Position ändert sich auch, wenn nur der Kurs läuft: Eine
113-Mio-Position schwankt bei 1 % Kursbewegung um 1,1 Mio, ohne dass jemand
handelt. Deshalb vergleicht der Recorder die Größe (`szi`) zweier Stände;
`delta_usd` ist die gehandelte Menge mal Kurs. Die Schwelle ist absolut statt
prozentual: Wale ab 25.000 USD gehandelt (`--event-min-usd`),
Leaderboard-Konten ab 12.500 (`--lb-event-min-usd`). Verglichen wird gegen den
zuletzt **protokollierten** Stand, nicht gegen den letzten Schnappschuss: Fünf
Zukäufe von je 20.000 blieben sonst einzeln unter der Schwelle und verschwänden,
obwohl sie zusammen 100.000 ergeben. So summieren sie sich zu zwei Ereignissen
à 40.000. Hintergrund: Große Konten
halten eine **Kernposition** und handeln mit kleinen Anteilen um sie herum —
Short in den Dip, Rückkauf im Long. Bei einer 2-%-Schwelle fiel genau dieses
Verhalten durch, obwohl es die eigentliche Strategie ist; zugleich erzeugte die
Wertmessung in bewegten Phasen erfundene Ereignisse. Die Flow-Schwellen sind
entsprechend gesenkt (Wale 150k brutto, Leaderboard 75k); den Maßstab setzt
ohnehin der Z-Score gegen die eigene 7-Tage-Verteilung.

**Abdeckung und Schwellen (Stand 13.09.2026).** Verfolgt werden **75** Top-Konten
(vorher 50) aus den besten 600 nach 30-Tage-PnL. Der Grund: Von 50 Konten halten
nur etwa zwölf überhaupt BTC — die Abdeckung je Coin hängt an der Zahl der Konten,
nicht an der Schwelle. Alle Betragsschwellen wurden halbiert: Wal-Ereignis 25.000,
Leaderboard-Ereignis 12.500, Fill 2.500, Kontowert 250.000, Wal-Flow-Signal 150.000
brutto, Leaderboard-Flow 75.000, Anzeige 50.000 (3 Tage) und 25.000 (48 h).
Mehrbedarf an API-Gewicht: rund 19 Einheiten je Minute, von 85 auf etwa 87 Prozent.
Mehr Daten: `lb_fills` etwa doppelt so viele Zeilen (75 statt 43 MB für 3 Tage).

**Gruppen statt Ausschluss — und die Klasse gilt je Coin.** Die
Verhaltensklasse wird für jedes Konto **in jedem Coin einzeln** bestimmt: Wer
BTC short und ETH long hält, ist kontoweit „gemischt", in BTC aber klar
positioniert. Maßgeblich ist das Verhalten im betrachteten Coin. Vier Gruppen:
direktional, Hedge, Market Maker, gemischt. Hat ein Konto in diesem Coin gerade
keine Position (etwa weil es sie geschlossen hat), gilt seine kontoweite Klasse —
ein Market Maker bleibt ein Market Maker. Konten, die nicht mehr in der Wal-Liste
stehen, aber im Zeitraum Ereignisse hatten, zählen mit; sonst fiele der Ausstieg
eines Wals aus jeder Gruppe heraus. **Keine Gruppe wird ausgeschlossen** —
jede bekommt ihren eigenen Flow mit eigenem Z-Score und in der Prognose einen
eigenen Treiber (Startgewichte 1,3 / 0,4 / 0,4 / 0,6). Welche Gruppe wirklich
Vorlauf hat, misst die Selbstkalibrierung an der Trefferquote; Ausschließen
wäre eine Annahme, Messen ist Wissen. In der Konfluenz geben vorerst nur die
direktionalen Konten Punkte, die übrigen erscheinen als Hinweis — das ändert
sich, sobald die Trefferquoten vorliegen. Kachel und Ereignisliste zeigen alle
Gruppen; die Liste färbt nach der Klasse im gewählten Coin.

**Wal-Flow — Positionsänderungen als Ereignis-Signal.** Wale ab 20 Mio werden
jede Minute abgefragt; ihre Positionsänderungen sind das schnellste Signal des
Systems und reagieren auf Nachrichten, bevor sie lesbar sind. Der Wal-Flow
summiert für die direktionalen Wale die Änderungen der letzten 15, 30 und 60
Minuten im gewählten Coin: Long eröffnet/aufgestockt oder Short reduziert/
geschlossen zählt als Kauf, umgekehrt als Verkauf. Maßstab ist der Z-Score
gegen die eigene Verteilung der Stundenflüsse der letzten 7 Tage; die Breite
zählt, wie viele Wale in dieselbe Richtung gingen. Ab Z 2,5 und vier Walen
gilt ein **Ereignis-Signal**: in der Konfluenz zwei Punkte statt einem, in der
Prognose ein Treiber mit Gewicht 1,3 (× 1,5 beim Ereignis), die erste Bewegung
wird kürzer angesetzt. Kachel „Wal-Flow 30 min" mit ⚡ beim Ereignis. Der Flow
zählt ab 1 Mio brutto und zwei Walen; qualifiziert sich das 30-min-Fenster
nicht, gilt das 60-min-Fenster — so werden auch langsame Serien kleiner Schritte
erfasst. **Sofortberechnung:** ein Wächter prüft alle 30 s, ob ein direktionaler
Wal seine Position geändert hat, und rechnet die Prognose dann sofort neu
(höchstens alle 2 min je Coin); die Seite fragt die Prognose jede Minute ab.
Die Zeile „Wal-Flow live" im Prognose-Abschnitt aktualisiert sich alle 20 s und
sagt, ob der Fluss die Prognoserichtung bestätigt oder ihr widerspricht. In der
Liste „Letzte Änderungen" trägt jeder Wal seine Verhaltensklasse; nicht-
direktionale sind ausgegraut.

**Selbstoptimierung der Prognose.** Fünf Bausteine, alle aus vorhandenen Daten:

1. *Gelernte Gewichte* — je Treiber wird aus den gespeicherten Prognosen die
   Trefferquote seines Vorzeichens gemessen; ab 40 bewerteten Prognosen lernt
   ein Logit auf die 24-h-Richtung die Gewichte, mit dem Prior als Anker (wenig
   Daten: Prior hält; viel Evidenz: Daten gewinnen) und der Grenze 0 bis 2 ×
   Prior — ein Treiber wird auf- oder abgewertet, nie umgedreht. Trainiert wird
   auf höchstens den jüngsten 2.000 Fenstern mit 14 Tagen Halbwertszeit: die
   Laufzeit bleibt bei rund 2,5 s auf dem Pi konstant, und ein Regimewechsel
   wird nachvollzogen statt ausgemittelt. Zeitlicher Verlauf bei etwa 90
   bewerteten Fenstern am Tag: ab 40 beginnt das Lernen, nach 1–2 Tagen ist die
   Rangfolge der Treiber erkennbar, nach etwa 5 Tagen (500 Fenster) sind die
   Gewichte stabil, danach ändern sie sich nur noch mit dem Marktregime. Tabelle
   `weights` in `forecasts.db`, alle 15 min. Prognosen mit der aktuellen
   Gewichtsversion werden getrennt bewertet: „Out-of-sample" ist die ehrliche
   Trefferquote, nicht an den Daten gemessen, mit denen kalibriert wurde.
2. *Analog-Suche* — die Kursreihe muss **bis jetzt reichen**: die Historie kommt
   aus `klines30` (von `hl_timestats` einmalig geladen), die letzten Tage werden
   aus `bnc_bars` bzw. den eigenen Bars angestückelt. Ohne das endete die Reihe
   dort, wo `hl_timestats` zuletzt lief — gemessen acht Tage zurück, und die
   Analoge passten zu einem Markt, den es nicht mehr gab. Zustandsvektor (Renditen 1/7/30 T, Volatilität, RSI, Lage
   zum 7-Tage-Mittel, Tageszeit, Wochentag) gegen bis zu drei Jahre
   30-min-Kerzen; die 50 ähnlichsten Momente, mindestens 6 h auseinander, die
   letzten 7 Tage ausgeschlossen. Ihre tatsächlichen Verläufe liefern Median
   und 20/80-Quantile je Horizont, als Treiber und als Pfad im Ensemble.
3. *Magnet-Statistik* — aus Heatmap-Snapshots (einer je 15 min, 14 Tage):
   Wahrscheinlichkeit, dass ein großes Cluster binnen 12 h erreicht wird,
   Überschuss darüber hinaus und Rückkehr danach, nach Abstandsklassen 0–1,
   1–2, 2–3 %. Ersetzt die festen Annahmen des Pfadmodells; stündlich.
4. *Zeitprofil* — Volatilität je Wochentag und Stunde aus der Kurshistorie
   skaliert das Band je Stunde voraus.
5. *Ensemble und Kapitulation* — Modellpfad und Analog-Median werden nach den
   laufenden Trefferquoten beider Modelle gemischt (Prior 60/40); ein Schub
   eingetretener Liquidationen (≥ 4 × Durchschnitt) wird zum Treiber
   „Kapitulation".

Alles läuft im Hintergrund; der Abschnitt zeigt den Lernstand offen, dazu den
**Lernplan** mit konkreten Zeitpunkten: gespeicherte und bewertete Prognosen,
nächste 4-h- und 24-h-Bewertung, voraussichtlicher Lernbeginn (die 40.
Prognose plus 24 h), letzte Prüfung und letzte Änderung der Gewichte, nächste
Prüfung, Stände von Analog-Suche, Magnet-Statistik und Zeitprofil, nächste
Prognose. Der Abschnitt zeigt außerdem gelernte
Gewichte mit Trefferquote je Treiber, Ensemble-Gewichte mit Herkunft,
Analog-Ergebnis mit den nächsten Beispielen, Magnet-Statistik, Out-of-sample.

**Kaskadenprognose.** Die Konfluenz nennt bei drohenden Kaskaden Auslöser, Art
und Ziel: „Verkaufskaskade (Long-Squeeze) ab 76.850 (−0,65 %): Druck 58,9 Mio
gegen Aufnahme 59,1 Mio — Ziel ≈ 75.900 (−1,9 %) · Kette: … · größte Aufnahme
39 Mio bei 76.100". Modell: vom Kurs weg in 0,25-%-Stufen; Auslöser ist das
erste Stop- oder Liquidationscluster ab 25 % des Stundenvolumens (mind. 5 Mio);
ab dort summiert sich der Druck aus Stops und Liquidationen derselben Richtung,
dagegen die Aufnahme aus ruhenden Limits (Support/Resistance, Take-Profits)
plus 5 % des Stundenvolumens je Stufe als organische Aufnahme; das Ziel ist die
Stufe, auf der die aufgelaufene Aufnahme den aufgelaufenen Druck einholt.
Long-Squeeze = Kaskade nach unten (Longs werden gestoppt und liquidiert),
Short-Squeeze = nach oben. Liegt der Auslöser innerhalb 3 %, zeichnet der
Live-Chart Auslöser (orange gestrichelt) und Ziel (orange gepunktet) ein. Ein
Modell aus sichtbaren Orders — es kennt weder Orders, die erst in der Kaskade
kommen, noch die Gegenseite auf anderen Börsen; „offen" heißt, die sichtbare
Aufnahme reicht im Modell nicht.

**Kacheln und Einheiten.** Jedes Label nennt die Einheit: USD für Kurs,
Notional, Volumen und Open Interest; Prozent für Trend und MA-Abstand;
„Anzahl" für Adressen; 0–100 für den RSI. Verhältnis-Kacheln (Long/Short
Konten, Long/Short Top-Trader, Taker Kauf/Verkauf) zeigen „a : 1" und darunter
die Aufteilung in Prozent — „1,27 : 1" heißt 56 % long, 44 % short. Jede
Kachel trägt die Definition als Tooltip (Maus darüber, am Handy lange
antippen). Die Binance-Verhältnisse stammen aus den Binance-Endpunkten
`globalLongShortAccountRatio` (Konten), `topLongShortPositionRatio`
(Positionswert der größten Konten) und `takerlongshortRatio` (aggressives
Kauf- zu Verkaufsvolumen, 5-min-Fenster).

**FVG-Mindestgröße.** Ein Fair Value Gap ist die Lücke zwischen dem Hoch von
Kerze 1 und dem Tief von Kerze 3 (bullisch) bzw. umgekehrt (bärisch). Die
Mindestgröße ist diese Lücke als Anteil des Kurses — 0,05 % bei 80.000 USD
sind 40 USD. Kleinere Lücken gelten als Rauschen und werden weder gezeichnet
noch in der Konfluenz gezählt.


Drei Panels auf `http://<pi>:8765`, jedes mit Überschrift, Legende und
Achsenbeschriftung. Mit der Maus darüberfahren oder antippen zeigt eine Box mit
den Werten an dieser Stelle — Zeitpunkt, Preisniveau, Notional, Perzentil-Rang
und Art der Liquidation.

- **Live-Chart** — Kerzen mit den aktuellen Liquidationslevels als waagerechte
  Linien. Rot unterhalb des Kurses sind Long-Liquidationen, grün oberhalb
  Short-Liquidationen. Durchgezogene Linien liegen bei mindestens dem halben
  Stundenvolumen und können den Kurs bewegen, gestrichelte werden eher
  absorbiert. Aktualisiert alle 5 Sekunden, Zeitraster von 1 min bis 1 h.
  **Volumen je Kerze** (seit 23.87, U232): Balken im unteren Fünftel des Charts,
  Farbe wie die Kerze, Höhe relativ zur größten Kerze im Bild. Die Preisskala reicht
  dafür nach unten weiter; Kerzen, Linien und Marken bleiben über dem Band. Einheit
  ist der Coin (BTC, ETH, …); der Tooltip im Band zeigt Volumen, ≈ USD und die
  Börse. Unter 4 h und in „Fusion“ ist es das Volumen der eigenen Hyperliquid-Bars,
  in der Quelle Binance das von Binance, im Tages- und Wochenchart das von Binance
  (`daily_bars`). Der 4-h-Chart setzt sich aus Binance (älterer Teil) und den eigenen
  Bars (letzte 8 Tage) zusammen: Binance handelt ein Vielfaches, deshalb hat jede
  Strecke ihre eigene Skala, getrennt durch eine gestrichelte Linie, und die Infozeile
  nennt beide. Der Schalter „Volumen an/aus“ neben „FVG“ blendet die Balken aus; der
  Browser merkt sich die Wahl. Hinweis: Bis zum Recorder-Fix U222 (23.82) waren
  einzelne Minuten-Bars von Hyperliquid zu klein (späte Trades), ihr Volumen also auch.
- **Chartbild** (seit 23.65, Abschnitt „CB“ direkt nach dem Live-Chart) — die Lage des Coins in Worten und im Tageschart: Trend,
  Bein, Swings, Niveaus, erwartete Spanne, Positionierung; jede Zeile mit Prüfstand, kein Signal (Abschnitt „Chartbild“ unten).
- **Fair Value Gaps** im Live-Chart, rein aus den Kerzen berechnet, nichts
  wird gespeichert. Dreikerzen-Lücken: bullisch, wenn das Tief der dritten
  Kerze über dem Hoch der ersten liegt, bärisch spiegelbildlich. Offene Zonen
  kräftig mit gestricheltem Rahmen und Teilfüllungsbalken, gefüllte blass bis
  zur füllenden Kerze. Ein Schalter neben der Coin-Auswahl blendet sie ein oder aus,
  die Mindestgröße ist wählbar (0,05 / 0,1 / 0,25 %). Die Infozeile nennt offene Zonen je Richtung und die nächste zum Kurs;
  der Tooltip zeigt Zone, Größe und Füllgrad.
- **Chart-Raster** — 1 min bis 1 h aus den eigenen Minutenbars; dazu
  „4 h · 30 Tage", „1 Tag · 1 Jahr" und „1 Woche · 5 Jahre" aus den
  vorhandenen Tabellen: 4 h aus `klines30` (Binance-30-min-Kerzen, falls
  `hl_timestats` sie geladen hat), die jüngsten Stunden aus den eigenen Bars;
  Tage und Wochen aus `daily_bars` (5 Jahre, von `hl_binance`). Fehlt eine
  Tabelle, holt das Dashboard die Kerzen direkt von Binance (5 min im
  Speicher gehalten). Die Infozeile nennt die Quelle, die Zeitachse zeigt bei
  Tagen und Wochen das Datum.
- **Gleitende Durchschnitte** — zwei Kacheln in der Kopfzeile: MA 50 Wochen
  und MA 200 Tage, grün mit ▲ wenn der Kurs darüber steht, rot mit ▼ darunter,
  jeweils mit Abstand in Prozent. Der Tooltip zeigt zusätzlich MA 50 Tage und
  MA 200 Wochen sowie Golden/Death Cross. Berechnet aus Tageskerzen in
  `daily_bars`, die `hl_binance.py` beim Start und alle 6 h nachlädt (5 Jahre;
  Quelle je Coin: Binance-Futures, sonst Binance-Spot, sonst Hyperliquid —
  XMR etwa führt Binance nicht mehr). Primärschlüssel (Tag, Coin), Nachladen
  ersetzt statt zu doppeln. Manuell: `hl_binance.py --backfill-daily`.
  Liegen die Linien im sichtbaren Preisbereich, erscheinen sie gestrichelt
  im Chart.
- **Stop-Orders der Wale** — eigenes Panel. Trigger-Orders stehen nicht im
  Orderbuch; sie werden erst am Auslösepreis zu Market-Orders, wie
  Liquidationen. Der Recorder fragt alle Adressen mit Positionen ab 20 Mio USD
  alle 2 Minuten nach ihren offenen Orders (`frontendOpenOrders`, Gewicht 20)
  und speichert sie in `trigger_orders`. Das Panel zeigt je Preisniveau
  Sell-Stops (rot, Verkaufskaskade nach unten), Buy-Stops (grün, Kaufkaskade
  nach oben), Take-Profits (grau, absorbieren) und Limit-Orders (blau) mit
  Notional, Zahl der Wale und Abstand zum Kurs. Budget über `--stop-budget`
  (Gewicht/min, Standard 240) und `--stop-interval`.
- **API-Budget** — Kachel mit dem Hyperliquid-Gewicht der letzten Minute
  gegen das Limit von 1200 (grün unter 70 %, gelb bis 90 %, rot darüber).
  Der Limiter rechnet jetzt in Gewicht: Positionsabfrage 2, Order-Abfrage 20.
  Wächter und Audit warnen ab 80 %.
- **Wartende Orders und Stops** — eigenes Panel: Sell-Stops (rot, Verkaufs-
  kaskade), Buy-Stops (grün, Kaufkaskade), Limit-Käufe (cyan, Kaufwand),
  Limit-Verkäufe (violett, Verkaufswand), Take-Profits (grau). Kaufseite links,
  Verkaufsseite rechts einer Mittelachse, je Preisstufe ein nach Art gestapelter
  Balken, fester Preisbereich ±30 %. Darunter die Live-Auswertung: Support
  (größte Kaufwand unter dem Kurs), Resistance (größte Verkaufswand darüber),
  höchste Take-Profits beider Seiten, größte und nächste Stop-Cluster, Stop-
  Summen innerhalb 2 %. Dieselben Niveaus erscheinen als beschriftete Linien im
  Live-Chart (Support cyan, Resistance violett, Take-Profits grau gestrichelt,
  Stops gepunktet) und gehen in die Konfluenz ein. Fahren oder Tippen zeigt in
  allen vier Charts ein Fadenkreuz mit dem Preis am Rand. Quelle ist `frontendOpenOrders` je Adresse — Trigger-
  Orders stehen nicht im Orderbuch, nur dort. Abgefragt werden alle Konten ab 250k USD,
  gestaffelt nach Größe — ab 20 Mio alle 10 min, 5–20 Mio alle 45 min, 1–5 Mio alle
  3 h, darunter alle 6 h — in einem Gewichtsbudget von 320/min (`--stop-budget`,
  `--stop-min-usd`, `--stop-interval`). Bei ~1.200 Kandidaten ist ein einheitlicher
  Takt unmöglich; das Panel zeigt je Konto den jüngsten Stand und dessen Alter.
  Tabelle `trigger_orders`, jede Abfrage als Zeitscheibe. Dazu alle 10 Minuten
  `order_levels`: Support, Resistance, Take-Profit- und Stop-Niveaus, Stop-Summen
  innerhalb 2 % und der Ordermix (Notional je Art innerhalb ±30 %) je Coin — mit
  derselben Rechnung wie das Dashboard, als Zeitreihe neben der Heatmap. Damit
  lässt sich später prüfen, ob der Kurs zum Liquidationscluster, zur Kaufwand
  oder zum Stop-Cluster zog, und wie sich der Ordermix vorher verhielt.
- **API-Last / Minute** — Kachel mit verbrauchtem Gewicht, Prozent und Reserve.
  Der Recorder deckelt sich selbst bei 90 % der 1.200 Einheiten (seit 17.09.; davon 20 % Reserve nur für Fills); Positions-
  abfragen (Gewicht 2) und Order-Abfragen (Gewicht 20) teilen sich den Deckel,
  Wale werden nie von Großkonten verdrängt. Der Wächter warnt ab 85 %.
- **Konfluenz** — eine Kachel plus ein Panel, das zählt, wie viele der
  sichtbaren Faktoren in dieselbe Richtung zeigen: frisch abgeräumte
  Liquidationscluster, offene FVGs am Kurs, RSI-Extreme, Orderbuch-Imbalance,
  Funding, Ausrichtung der direktionalen Wale (Hedges und Market Maker ausgenommen), Lage des Kurses zum MA 200 Tage und zum MA 50
  Wochen (je ein Punkt), Kauf-/Verkaufswände aus ruhenden Limit-Orders (je ein
  Punkt), Stop-Cluster dicht am Kurs („Abwarten", Kaskade droht; zusammen mit
  einem Liquidationscluster auf derselben Seite „doppelter Magnet"),
  Take-Profits als Hinweis. Ein großes Cluster dicht am Kurs ergibt — ebenso
  große Wal-Stops innerhalb 0,8 % (ab 25 % des Stundenvolumens, mindestens
  5 Mio); liegen Stops und Liquidationscluster auf derselben Seite, meldet
  das Panel einen „doppelten Magneten". Solche Fälle ergeben
  „Abwarten — Anlauf wahrscheinlich" statt einer Richtung. Ab drei Punkten
  netto steht „Kauf-" oder „Verkaufs-Konfluenz". Jede Regel und jede Schwelle
  steht im Panel. Trägt ein Faktor ein Preisniveau — Kaskadentief, Squeeze-Hoch,
  FVG am Kurs — wird es als Kauf- oder Verkaufszone im Chart eingezeichnet — als
  Fenster am rechten Rand über die letzten Kerzen, nicht als Band über die
  Historie, denn die Zone ist ein Zustand jetzt.
  Stammen die Punkte nur aus Wale, Orderbuch, Funding oder RSI, gibt es keine
  Zone, und das Panel sagt warum. Eine Danger-Time aus der Zeit-Heatmap
  erscheint als Warnung ohne Richtung. **Das ist eine Zählung sichtbarer Faktoren, keine Prognose
  und nicht validiert** — die zugrunde liegende These ist genau das, was der
  Recorder erst noch belegen muss.
- **Heatmap** — Cluster über die Zeit, mit Kurslinie und eingetretenen
  Liquidationen. Die Farbe richtet sich nach dem *Rang* einer Zelle unter
  allen anderen, nicht nach ihrem Absolutwert, und wird zusätzlich mit einer
  Potenz gestaucht — sonst leuchtet die ganze Fläche gleichmäßig. Der Regler
  „Liquiditäts-Schwelle" blendet alles unterhalb eines Perzentils aus
  (Standard 70). Für die PNG-Variante: `--threshold 0.9`.
- **Depth** — Schnitt durch den aktuellen Moment, alle Level nach Notional.
- **Kennzahlenleiste** — neben Kurs, Cluster-Summen und Adressen auch der
  60-Minuten-Trend, der RSI 14 auf dem gewählten Raster, das letzte Backup
  (grün unter 26 h, gelb bis 50 h, danach rot) und der Zustand der Datenbank
  per `quick_check`, stündlich geprüft. Beim Darüberfahren stehen Details.
- **Wale** — Netto-Ausrichtung aller Positionen ab 20 Mio. USD gegen den
  Kurs, darunter jede offene Wal-Position mit Einstieg, Liquidationspreis,
  Abstand dorthin und unrealisiertem PnL, und die letzten Änderungen.

## Tick-Aufzeichnung bei Kaskaden

Minutenkerzen reichen für die Cluster-Frage, nicht aber, um einen Flash-Crash
Tick für Tick nachzuspielen. Der Recorder hält deshalb die letzten 30 Minuten
aller Rohtrades der verfolgten Coins im Speicher. Erkennt er eine schnelle
Bewegung — 1 % in 60 s, 0,4 % in 10 s oder fünf Liquidations-Fills in 30 s —
sichert er das Fenster von 5 Minuten davor bis 10 Minuten danach in `ticks`,
parallel dazu die Markpreise in `mark_ticks`. Hält die Bewegung an, verlängert
sich der Nachlauf; bei ruhigem Handel endet er. Ein Ereignis je Bewegung, kein
Doppelauslösen. Schwellen über `--tick-move`, `--tick-flash`, `--tick-liqs`,
Fenster über `--tick-pre`, `--tick-post`.

Was zusätzlich mitläuft, damit sich der Zeitraum *vor* einem Crash erkennen
und das *Ende* treffen lässt:

- **Orderbuch-Kennzahlen alle 5 s** (`book_summary`): Tiefe in USD innerhalb
  10, 25, 50 und 100 Basispunkten je Seite, Spread, Imbalance. Ausdünnende
  Bid-Tiefe und kippende Imbalance sind die verlässlichsten Vorläufer.
  In Ereignisfenstern zusätzlich vollständige Top-10-Snapshots (`book_ticks`),
  damit sich der Füllpreis eines eigenen Verkaufs oder Kaufs realistisch
  simulieren lässt.
- **10-Sekunden-Bars mit Aggressorseite** (`bars10`): Taker-Käufe gegen
  Taker-Verkäufe, Liquidationsfills und -notional, größter Einzeltrade.
  Aussetzende Liquidationsfills und ein Volumenhöhepunkt markieren das Ende.
- **Nähe zum Cluster je Minute** (`proximity`): größtes Cluster über und unter
  dem Kurs innerhalb 5 %, mit Abstand — die Größe für die Magnet-These in
  hoher Auflösung.
- **Kontrollfenster**: ein- bis zweimal täglich ein zufälliges Fenster ohne
  Auslöser. Ohne diese Fälle kennt eine Simulation nur die Treffer, nie die
  Fehlalarme.

Für Simulationen: `--export --with-ticks` gibt Rohtrades, Buch-Snapshots und
die drei Zeitreihen mit. Ohne den Schalter enthält der Export nur die
Ereignisliste.

**Hinweis zu PAXG.** Gold-gebunden, daher schwankungsarm und auf Hyperliquid
dünn gehandelt. Zwei Folgen: Die Tick-Auslöser (1 %/60 s, 0,4 %/10 s) greifen
dort selten, und wenn, dann eher durch Einzeltrades in einem leeren Buch als
durch Kaskaden. Und die Liquidationscluster fallen klein aus. Für die
Cluster-These ist PAXG damit ein Randfall — interessant eher als Vergleich
zu BTC bei Makro-Ereignissen als als eigenständiges Handelsziel. Auf Binance
wird PAXG nur aufgezeichnet, wenn dort ein USDT-Perp existiert; sonst
überspringt das Modul den Coin mit Meldung.

## Verbindungen zum Router

Der Recorder hält höchstens sechs gleichzeitige HTTP-Verbindungen und
verwendet sie wieder (Keep-Alive 120 s). Ohne diese Begrenzung öffnete jede
Abfragerunde bis zu 80 neue TCP+TLS-Verbindungen — rund 20.000 pro Stunde.
Das heizt die CPU (TLS-Handshakes) und füllt die NAT-Tabelle eines
Heimrouters; ist sie voll, bekommt jedes Gerät im Haus für neue Verbindungen
ein Timeout, minutenlang auch nach dem Stoppen des Recorders. Prüfen auf dem
Pi mit `ss -s`: die Zahl bei `timewait` sollte zweistellig bleiben. Ist der
Router einmal voll, hilft sein Neustart sofort.

## Liquidationen — woher sie kommen

Der öffentliche Trade-Feed von Hyperliquid kennzeichnet Liquidationen nicht
(`WsTrade` hat nur coin, side, px, sz, hash, time, tid, users). Bis zum 8.9.
blieb die Tabelle `liquidations` deshalb leer — die Marker in der Heatmap,
`n_liqs` der Tick-Ereignisse und der Liquidations-Auslöser hingen an einem
Feld, das nie kommt. Seitdem zwei eigene Quellen:

- **`userEvents`-Abos** für die Darwin-Liste, ohne Liste für Wale und Konten ab 250k (höchstens 10: so viele Nutzer
  erlaubt Hyperliquid je IP; `--max-event-subs`, bis 23.74 stand dort der Standard 600 und überschrieb die Einstellung):
  Fills mit `liquidation`-Objekt in Echtzeit, kostet kein REST-Gewicht. Diese
  Liquidationen speisen auch die 10-s-Bars und den Liquidations-Auslöser. Der
  Vollbericht (Abschnitt Recorder) zeigt seit 23.75 Zahl und Quelle der Abos, bestätigte,
  abgelehnte und die Grenze.
- **Ableitung aus dem Polling** für alle anderen Konten: Position zwischen zwei
  Abfragen verschwunden oder auf unter 10 % geschrumpft, und der Kurs hat in
  der Zwischenzeit den Liquidationspreis berührt (Minutenkerze) → Liquidation,
  `method = inferred`, Zeitpunkt = berührende Kerze. Verzögert um das
  Abfrageintervall, dafür vollständig.

Der Audit weist beide Anteile aus.

## Datenqualität — was der Recorder dafür tut

- **Abdeckung wird gemessen.** Zu jedem Snapshot steht in `coverage`, welchen
  Anteil des offiziellen Open Interest die verfolgten Positionen ausmachen. Das
  verwandelt eine unbekannte Unvollständigkeit in eine Zahl — und sagt, ab wann
  die Heatmap repräsentativ ist. Der Wächter warnt seit 23.80, wenn ein Coin unter
  die Hälfte seines Normalwerts fällt (Median der letzten 7 Tage); bis 23.79 unter
  25 % -- bei zu knappem Abfragebudget war das der Dauerzustand (U218).
- **Markpreis statt Handelspreis.** Liquidationen lösen am Markpreis aus. Aus
  `activeAssetCtx` werden Mark-, Oracle- und Mid-Preis, Funding und Open
  Interest je Minute in `ctx_bars` festgehalten, damit die Berührungserkennung
  denselben Preis nutzt wie die Börse.
- **Cross oder isoliert.** Der Liquidationspreis einer Cross-Margin-Position
  hängt am ganzen Konto und wandert, ohne dass sich die Position ändert. Die
  Heatmap speichert je Zelle den Cross-Anteil, damit sich stabile von
  wandernden Clustern trennen lassen.
- **Priorität nach Größe.** Vier Stufen nach Positionswert zum Markpreis:
  Wale ab 20 Mio. USD alle 60 s, große ab 500k alle 3 min (bis 23.85 ab 250k),
  mittlere ab 25k alle 30 min, darunter seit 23.86 nur nach eigenem Handel,
  sonst höchstens täglich (bis 23.85 alle 2 h; zurück mit `--klein-regelmaessig`).
  Gesperrte Konten (Masterregel) fragt der Poller seit 23.86 nicht mehr ab. Das
  Budget fließt nach oben (`--whale-notional`, `--hot-notional`, `--min-notional`).
- **Wal-Protokoll.** Positionen über der Wal-Schwelle landen in
  `whale_positions` — nur Änderungen (öffnet, stockt auf, reduziert, schließt,
  dreht) plus ein Zeitreihenpunkt je Snapshot. Änderungen unter 2 % gelten als
  Rauschen. Hysterese: Wer einmal Wal war, bleibt bis unter die halbe Schwelle
  in Beobachtung.
- **Breite Adress-Entdeckung.** Standardmäßig werden alle Perp-Feeds
  abonniert, nicht nur die verfolgten Coins. Wer BTC hält, handelt vielleicht
  gerade nur SOL — sonst bliebe seine BTC-Position unsichtbar. Bars entstehen
  weiterhin nur für die verfolgten Coins. Abschaltbar mit `--no-discover-all`.
- **Alterung.** Positionsdaten, die älter als `--max-pos-age` sind (Standard
  1 h), gehen nicht in den Snapshot. Ein Wallet kann längst geschlossen haben,
  ohne dass wir es wissen. Lieber ein dünnerer, ehrlicher Snapshot. Seit 23.86
  zählt das Alter ab der letzten erfolgreichen Abfrage; bis 23.85 ließ ein
  Fehlschlag alte Positionen frisch aussehen.
- **Qualitätsstempel.** Jeder Snapshot trägt in `snapshot_meta` mit, wie alt
  die Daten waren, wie viele Positionen wegen Alter fehlten, wie groß der
  Rückstand war und wie lange der Prozess schon lief. Damit lassen sich
  Snapshots nach einem Neustart oder aus der Anlaufphase später ausschließen.
- **Abfragereihenfolge in drei Gruppen mit festem Budgetanteil.** Adressen
  mit Position (65 %): fällige Wale immer zuerst, dann nach Überfälligkeit
  relativ zum Intervall ihrer Stufe. Nie abgefragte Adressen (25 %): älteste
  zuerst — ohne festen Anteil würden sie mit „unendlicher" Überfälligkeit
  alles verdrängen. Bekannt leere Adressen (10 %): nur, wenn sie seit der
  letzten Abfrage wieder gehandelt haben, sonst höchstens einmal täglich.
  Eine leere Adresse ohne neuen Trade kann keine neue Position haben — wir
  sehen ja alle Feeds. Das macht die breite Entdeckung erst tragbar: Zehn-
  tausende Staubadressen kosten danach praktisch nichts mehr. Seit 23.86
  stehen in dieser Gruppe auch die kleinen Konten (unter 25.000 USD), zuletzt
  gehandelte zuerst.
- **Vorrang nach großem Handel (seit 23.86).** Eine leere oder kleine Adresse
  mit mindestens 25.000 USD Handel seit ihrer letzten Abfrage (Summe aus dem
  Trade-Feed; `--vorrang-ab`, 0 schaltet ab) kommt vor die fälligen Konten von
  Rang 1 (groß, Pool, mittel), höchstens ein Zehntel der Runde. Sonst könnten
  die vielen kleinen Konten in der dritten Gruppe neue große Positionen
  verdrängen.
- **Pause nach Fehlschlägen (seit 23.86).** Scheitert eine Abfrage ganz, ist
  die Adresse zuerst nach dem halben Takt ihrer Stufe wieder dran (höchstens
  5 min), nach jedem weiteren Fehlschlag doppelt so spät -- gedeckelt beim
  Vierfachen des Takts (mindestens 5 min), für leere und kleine Konten bei
  6 h. Ihr Handel bleibt drei Fehlschläge lang Auslöser.
- **Hebel und Einstieg je Zelle.** Die Heatmap speichert den
  notional-gewichteten Hebel und Einstiegskurs. Ein Cluster aus 50x-Positionen
  verhält sich anders als einer aus 3x-Positionen.
- **Kein Doppelzählen.** `--analyze` ersetzt die Ereignisse eines Coins statt
  sie anzuhängen.
- **Späte Trades ergänzen, statt zu ersetzen (seit 23.82, U222).** Minuten-Bars
  und 10-s-Stücke werden gut 3 s nach ihrem Ende geschrieben (Schreibtakt 10 s
  auf :03, :13, …) und gehalten, bis die Börsenzeit 15 min über ihre Minute
  hinaus ist. Kommt ein Trade später, wird die Zeile mit allen Trades neu
  geschrieben; was danach noch kommt, zählt nicht (fast sicher eine
  Wiederholung). Trades werden je Coin nach Zeit und `tid` entdoppelt; nach
  einem Neustart zählen Trades bis zur Börsenzeit des vorigen Dienstes
  (`meta` `u222_hw_ms`) nicht, seine letzte Minute wird mit ihrer Zeile
  zusammengeführt. Vorher ersetzte ein spätes Bruchstück die fertige Zeile
  (4–8 % der Minuten je Coin, Oktober 2026). Zähler `u222_*` in `meta`;
  Selbsttest `hl_recorder.py --selbsttest-bars`.

## Wie die Aufzeichnung funktioniert

1. Der WebSocket-Feed `trades` liefert zu jedem Trade die Wallet-Adressen.
   Daraus wächst ein Adressregister.
2. `clearinghouseState` liefert pro Adresse die offenen Positionen mit dem
   echten `liquidationPx` — anders als CEX-Heatmaps ist das keine Schätzung.
3. Alle Liquidationspreise werden in ein logarithmisches Preisraster
   aggregiert und alle fünf Minuten als Snapshot gespeichert.
4. Parallel laufen 1-Minuten-Bars aus dem Trade-Feed mit, damit sich später
   Forward-Returns berechnen lassen.

## Pi-spezifische Hinweise

**Backup.** Der Recorder erstellt fünf Minuten nach dem Start und danach
täglich eine Kopie nach `dbbackup/hl_liq_backup.db`, im laufenden Betrieb
über die SQLite-Backup-API — in einem einzigen Schritt. Schrittweise mit
Pausen wäre eine Endlosschleife: Ändert eine andere Verbindung die Quelle
zwischen zwei Schritten, beginnt die API von vorn, und der Recorder schreibt
alle 10 s. Dauer = Datenbankgröße geteilt durch die Schreibgeschwindigkeit
des Zielmediums, bei 1,5 GB auf SD-Karte ein bis drei Minuten, danach die
Integritätsprüfung. Die Kopie wird erst mit `integrity_check`
geprüft und ersetzt das alte Backup nur, wenn sie in Ordnung ist — eine
bereits beschädigte Datenbank kann das letzte gute Backup also nicht
überschreiben. Manuell: `hl_recorder.py --backup`. Der Zielordner lässt
sich mit `--backup-dir` festlegen; der Recorder trägt ihn beim Start in die
Tabelle `meta` ein, und Dashboard, Wächter und Audit lesen ihn dort — eine
Quelle für alle. Liegt die Datenbank auf einem USB-Medium, gehört das Backup
auf die SD-Karte des Pi (`migrate_db.py` richtet das so ein): Ein Backup auf
demselben Datenträger schützt vor Beschädigung, nicht vor dessen Ausfall.
Der Recorder meldet beim Start, ob beides auf demselben Datenträger liegt. Wiederherstellen: Dienste stoppen, Datei kopieren, starten.

**Arbeitsspeicher.** 4 GB reichen deutlich. Gemessen auf einer Datenbank mit
90 Tagen Aufzeichnung (2,8 Mio. Heatmap-Zeilen, 223 MB):

| Prozess | Spitzenspeicher |
|---|---|
| Recorder mit 20.000 Adressen / 40.000 Positionen | 44 MB |
| Dashboard, auch bei 7-Tage-Ansicht | 108 MB |
| Binance-Stream | rund 40 MB |
| `--analyze` über 90 Tage | 173 MB, 6 s |

Zusammen unter 400 MB. Ein kleineres Snapshot-Intervall erhöht den Bedarf
leicht, weil mehr Zeilen entstehen — es senkt ihn nicht.

**Datensicherheit bei Neustart und Stromausfall.** Die Datenbank läuft im
WAL-Modus. Bars, Liquidationen und Adressen werden alle 10 Sekunden committet
(`--flush-sec`), die WAL-Datei alle 15 Minuten zusammengefaltet, damit sie
nicht unbegrenzt wächst.

| Fall | Verlust |
|---|---|
| Geplanter Neustart (systemd sendet SIGTERM) | nichts |
| Absturz eines Dienstes | nichts, der Supervisor startet neu |
| Harter Stromausfall | bis zu 10 Sekunden |
| Stromausfall mit `--durable` | nichts, dafür mehr Schreibzugriffe |

Getestet mit SIGKILL mitten im Schreibbetrieb: Die Datenbank bestand danach
in allen Läufen `PRAGMA integrity_check`, und die vor dem letzten Commit
geschriebenen Daten waren vollständig vorhanden.

`--durable` schaltet auf `synchronous=FULL`, also fsync bei jedem Commit. Auf
einer USB-SSD unproblematisch, auf einer SD-Karte erhöht es den Verschleiß
spürbar.

**SD-Karte.** Der Recorder schreibt dauerhaft. Bei drei Coins wächst die
Datenbank bei 10-Minuten-Snapshots um etwa 0,2 GB pro Monat. Auf einem
124-GB-Datenträger reicht das für Jahre. Für Monatsbetrieb eine USB-SSD verwenden
und `--db /pfad/zur/ssd/hl_liq.db` setzen.

**Uhrzeit.** Ohne NTP-Synchronisation sind die Zeitstempel wertlos.
`sudo timedatectl set-ntp true`, das Installskript prüft es.

**Dashboard im Netz.** `--host 0.0.0.0` macht es im LAN erreichbar, ohne
Passwort. Nur im eigenen Heimnetz betreiben, nicht ins Internet stellen.

**Dauerbetrieb.** `install.py --enable` richtet drei systemd-Dienste mit
`Restart=always` ein, damit Recorder, Binance-Stream und Dashboard Neustarts
und getrennte SSH-Sitzungen überleben.

## Alarm bei Ausfällen

```bash
.venv/bin/python hl_watchdog.py --once                # einmalig prüfen
.venv/bin/python hl_watchdog.py --test-alarm          # Signalgeber testen
```

Zwei Ebenen, weil eine allein nicht genügt:

**Lokal** — Alarmton über die Audioausgabe, alle 120 Sekunden wiederholt,
solange die Störung anhält (`--alarm-interval`). Bei Warnung ein aufsteigender
Zweiklang, bei kritischem Zustand eine Sirene, beides aus Rechteckschwingungen
im Stil der 8-Bit-Ära und zur Laufzeit erzeugt. Funktioniert ohne Internet,
also gerade dann, wenn der Ausfall die Verbindung betrifft.

> Der Raspberry Pi 5 hat **keinen eingebauten Lautsprecher** und seit dem
> Modell 5 auch keine 3,5-mm-Klinkenbuchse mehr. Ton braucht HDMI mit
> angeschlossenem Bildschirm, einen USB-Soundstick, Bluetooth oder ein
> I2S-DAC-HAT. `hl_watchdog.py --test-alarm` sagt dir, was gefunden wurde.
> Ohne Audioausgabe bleiben die ACT-LED (`--led`) und der Totmannschalter.

Nötig ist ein Abspielprogramm: `sudo apt install alsa-utils`. Optional lässt
sich zusätzlich ein Summer an einem GPIO-Pin betreiben (`--buzzer 18`), auf
dem Pi 5 über `gpiozero` mit `lgpio`.

**Extern** — ein Lebenszeichen an einen Dienst wie healthchecks.io
(`--heartbeat https://hc-ping.com/UUID`). Der Wert liegt im Ausbleiben: Ist
der Pi tot oder offline, alarmiert der Dienst dich. Das ist die einzige Ebene,
die einen Totalausfall überhaupt melden kann. Zusätzlich Push über
`--ntfy DEIN-TOPIC`, solange die Verbindung steht.

Geprüft werden Alter der Bars und Snapshots, stille Einzel-Feeds, Rückstand
des Pollers, Binance-Daten, Plattenplatz, NTP-Synchronisation und der Zustand
der systemd-Dienste; seit 23.78 auch, ob das Dashboard auf seinem Port
antwortet (Zeile „Dashboard“: Prozess läuft, Seite antwortet nicht = hängt;
`--dashboard-url`, `--selbsttest`). Die Verbindungsprüfung verlangt den erwarteten Inhalt,
nicht nur einen Statuscode — ein Captive Portal oder eine Router-Fehlerseite
antwortet sonst mit HTTP 200 und sähe wie eine intakte Verbindung aus.

**Poller und Abdeckung (seit 23.80, U218).** Bis 23.79 stand der Wächter
dauernd auf KRITISCH: Das Abfragebudget des Pollers reicht nur für einen
Bruchteil der eingestellten Abstände (der Recorder meldet „Auslastung 396 %“),
also lag das 90-%-Quantil des Abfragealters (über alle Konten, auch die kleinen
im 2-h-Takt) immer über 2 h und die Abdeckung einzelner Coins unter 25 % -- ein
echter Ausfall fiel im roten Wächter nicht mehr auf. Jetzt:
- **Poller KRITISCH**, wenn er steht (letzte Runde laut `meta` `jobs` über
  5 min her; sonst alle 5 s) oder der Snapshot leer ist; **WARNUNG**, wenn der
  Anteil zu alter Positionen im Snapshot mehr als 20 Prozentpunkte über seinem
  Normalwert liegt (Median der letzten 7 Tage, ohne die 45 min nach einem
  Neustart des Recorders) oder mindestens 97 % beträgt.
- **Abdeckung WARNUNG**, wenn ein Coin unter die Hälfte seines Normalwerts fällt
  (ohne Normalwert, also unter 6 h Verlauf: unter 2 %).
- In den 45 min nach einem Neustart des Recorders kein Alarm, nur „Anlauf“ (die
  Abdeckung fällt dann 15–35 min lang) -- außer bei 3 und mehr Starts in 2 h
  (WARNUNG „Neustart-Schleife?“). Das bekannt zu knappe Budget steht als Text in
  der Zeile, nicht als Alarm.

Wo das Budget hingeht, zeigt Debug „★ Recorder: Poller-Kapazität“
(`check_system.py --poller`, liest nur): Konten und Positionswert je Stufe (Wale,
Elite, groß, Pool, mittel, klein, gesperrt), Bedarf gegen Budget mit der
gemessenen Rate des Pollers (`api_load`), gemessenes Alter, Snapshot und
Abdeckung gegen ihren Normalwert und Varianten im Modell. Das Modell rechnet die
Auswahl des Recorders (`due_addresses`) nach; eine Probe vergleicht seine Werte
mit dem Quelltext des Recorders. Seit 23.86 (U220, U231): gesperrte Konten ohne
Abfrage und nicht im Nenner von „frisch“, kleine nach eigenem Handel, „groß“ ab
500.000 USD; die Gegenprobe Pool zählt wie der Recorder jedes Mitglied (auch als
Wal oder Elite). Die Abstände je Stufe misst seit 23.86 der Recorder selbst, von
einer erfolgreichen Abfrage zur nächsten (je volle Stunde in `meta`
`poller_abstaende`). Der Bericht stellt sie dem Modell gegenüber, sobald die
Laufzeit zu Beginn der Stunde das Doppelte des größeren Abstands (Modell oder
Messung) erreicht hat -- das ist das Hauptmaß der Messung nach der Änderung
(UEBERGABE 3ψψψψ). Die Rückrechnung aus dem gespeicherten Alter (Versatz des
stündlichen Schreibens = Alter der Wale) steht nur beschreibend daneben: Sie
fällt zu kurz aus, weil der Recorder manche Konten sofort schreibt. Der Anteil
zu alter Positionen wird nur bei ähnlicher Laufzeit verglichen (der Recorder lädt
beim Start keine Positionen); dazu Handel je Stufe, die Größe der drei Gruppen
der letzten Auswahl, die wartenden leeren und kleinen Konten und der Vorrang nach
großem Handel (Abfragen seit dem Start, `meta` `poller_vorrang`). Die Statuszeile
des Recorders („Auslastung“) rechnet seit 23.86 wie das Modell, mit der
eingestellten Rate.

## Wie Cluster und Kurs zusammenfinden

Alle Zeitstempel sind Unix-Sekunden, also zeitzonenfrei — die Systemzeitzone
des Pi spielt keine Rolle. Zu jedem Heatmap-Snapshot sucht die Auswertung per
Binärsuche die passende Minutenkerze und leitet daraus Abstand zum Cluster,
Stundenvolumen und Forward-Returns ab.

Eine Bar entsteht aber nur, wenn in der Minute gehandelt wurde. In dünnen
Märkten und Nachtstunden kann die nächste Kerze Minuten entfernt liegen —
ihr Preis gehört dann nicht mehr zum Snapshot. Liegt der Abstand über
`--max-gap` (Standard 120 s), wird das Ereignis verworfen und am Ende
gemeldet, statt still mit falschem Bezug zu rechnen.

Voraussetzung dafür ist eine korrekt gehende Uhr: Die Bars tragen Börsenzeit,
die Snapshots die Zeit des Pi. Driftet sie, passt die Zuordnung nicht mehr.
Deshalb prüft der Wächter die NTP-Synchronisation.

## Zwei Datenquellen, getrennt gehalten

Hyperliquid liefert **gemessene** Positionen mit echtem Liquidationspreis,
Binance liefert **aggregierte** Marktdaten und Liquidationsereignisse. Beides
landet in derselben Datei, aber in getrennten Tabellen (`heatmap` gegen
`bnc_*`). Nicht vermischen — die Aussagekraft ist unterschiedlich.

Rückwirkend abrufbar sind bei Binance nur Open Interest, Long/Short-Ratios und
Kerzen. Liquidationen gibt es dort nicht als Verlauf, die sammelt nur der
Live-Stream. Und Binance pusht je Symbol nur die größte Order pro Sekunde: Das
gespeicherte Kaskadenvolumen ist eine Untergrenze, kein exakter Wert.

## Bilanz der Kauf- und Verkaufsempfehlungen (seit 23.16)

Die Kachel „Bilanz der Empfehlungen“ zeigt, was die Empfehlungen gebracht hätten, nach Gebühren und gegen die
naheliegenden Alternativen:
- **Kauf:** Limit gegen sofort kaufen (Markt) und nie kaufen.
- **Verkauf, für eine offene Long-Position:** Limit gegen sofort verkaufen und halten.

So wird gerechnet:
- Je Coin und Tag zählt die erste Empfehlung.
- Das Limit liegt ab der Prognose 12 h.
- Bewertet wird alles 24 h nach der Prognose.

Grün heißt, das Limit schlägt die Markt-Variante mit 95 % Sicherheit, rot heißt, es ist sicher schlechter. Details je
Coin, auch getrennt nach „ausdrücklich empfohlen“ ja/nein, zeigt der Debug-Eintrag „★ Bilanz der
Kauf-/Verkaufsempfehlungen (U8)“. Die Gebühren entsprechen der Hyperliquid-Basisstufe (Maker 0,015 %, Taker 0,045 %);
Funding ist nicht enthalten. Aussagekräftig wird die Bilanz erst nach einigen Wochen.

## Ereignis-Profile: was geschah vor Rutschen und Anstiegen (seit 23.18)

Der Debug-Eintrag „★ Ereignis-Profile (U43)“ zeigt für jeden Treiber, wie er in den 12 Stunden vor großen Bewegungen
stand. Als groß gilt eine Bewegung in 4 Stunden von mindestens dem Doppelten der üblichen Schwankung. Jeder Wert wird
mit normalen Zeiten gleicher Schwankung verglichen.

Ein Stern markiert eine Abweichung, die über einer Schwelle aus zufällig verschobenen Zeitpunkten liegt; sie ist also
kein Zufallsfund. So lassen sich Vorläufer (weichen schon Stunden vorher ab) von Mitläufern (reagieren erst mit der
Bewegung) unterscheiden. Solange es wenige Fälle gibt, ist die Schwelle hoch und markiert wenig; das heißt zunächst
nur: noch nicht belegbar.

## Vorbedingungen: was vor Bewegungen ≥ 3 % lag (seit 23.7, Zählung neu seit 23.53)

In der Prognose-Ansicht steht unter den Konstellationen der Abschnitt „Vorbedingungen“. Er zeigt je Treiber, wie oft er
vor einem Anstieg bzw. Rückgang von mindestens 3 % binnen 24 Stunden schon in diese Richtung zeigte, gegen alle anderen
Zeiten (Basis). Die Tabelle erscheint ab 3 Ereignissen je Richtung.

So wird gezählt (seit 23.53):
- Bezugspunkt ist jede gespeicherte Prognose, die erste je 15 Minuten. Ein Zeitpunkt zählt, wenn der Kurs binnen 24 Stunden
  danach mindestens 3 % von seinem Kurs aus lief.
- Ein Ereignis ist eine Bewegung. Zeitpunkte gehören zusammen, solange die Bewegung läuft oder sie auf dasselbe Tief bzw.
  Hoch zulaufen. Ein neues Ereignis beginnt, wenn der Kurs am Extrem der vorigen Bewegung angekommen war (bis auf 1,5 %) oder
  sich zwischendurch um 3 % zurückbewegt hat.
- Die Vorbedingung ist der früheste Zeitpunkt eines Ereignisses.
- Je Richtung stehen darunter die erfassten Ereignisse, auch wenn es für eine Tabelle noch zu wenige sind: Zeitpunkt,
  Bewegung in Prozent und wann Tief bzw. Hoch erreicht war. Über beiden Spalten stehen der Zeitraum der Rückschau und der
  Zeitpunkt der Berechnung (stündlich).

Bis 23.52 war Bezug nur der Beginn jedes 4-Stunden-Blocks. Lag das Hoch mitten im Block, wirkte ein Rückgang kleiner, als er
war, und blieb oft unter 3 %. Außerdem wurden Ereignisse zusammengelegt, die weniger als 24 Stunden auseinanderlagen.

Der Debug-Eintrag „★ Vorbedingungen: Ereignisliste (U131)“ zeigt je Coin:
- alle erfassten Ereignisse,
- den Abgleich mit den Kursdaten: welche Bewegungen der Chart zeigt (Hoch bzw. Tief jedes 15-Minuten-Abschnitts als Bezug),
  welche davon nicht erfasst sind und warum (seit 23.58):
  - „im benachbarten Ereignis enthalten“: Ein Prognosepunkt sah die Bewegung (mindestens 3 %), gehört aber zum Ereignis davor.
  - „binnen 24 h höchstens …“: die größte Bewegung, die ein Prognosepunkt sah. Zwischen Beginn und Extrem zählt seine eigene
    24-Stunden-Bewegung, in den 24 Stunden vor dem Extrem sein Weg bis dorthin. Dazu der Docht: wie weit das 15-Minuten-Hoch
    bzw. -Tief über bzw. unter dem extremsten Kurs derselben Prognosepunkte lag. Knapp unter 3 % ist der 15-Minuten-Takt; ein
    Docht von mehreren Prozent bei BTC spricht eher für einen Ausreißer in den Kursdaten.
  - „keine Prognose … gespeichert“: In diesen Zeiträumen gibt es gar keinen Prognosepunkt (Lücke der Ablage).
  - 23.56 maß nur die Punkte zwischen Beginn und Extrem. Bewegungen, die frühere Punkte schon gesehen hatten, erschienen dann
    als „höchstens -2,9 %“ oder als Lücke (eigener Fehler, in 23.58 berichtigt),
- die bisherige Zählung zum Vergleich.

Er läuft einmalig am 06.10. um 20:45 als Bericht (`u131-vorbedingungen`) und danach in der Wochenprüfung.

Die Rückschau reicht so weit wie die gespeicherten Prognosen (höchstens 60 Tage). Bewegungen der letzten 24 Stunden sind
noch offen.

## Verlauf der Treiber (seit 23.19)

Unter dem Prognose-Chart zeigt eine Tafel, wie sich die Treiber über die letzten 24 oder 72 Stunden entwickelt haben:
- oben der Kurs,
- unten der Bias (weiße, dicke Linie) und einzelne Treiber auf der Skala −1 bis +1.

Treiber lassen sich durch Antippen an- oder abwählen. Rote und grüne Bänder markieren Rutsche und Anstiege nach der
Definition der Ereignis-Profile; sie erscheinen erst 4 Stunden nach ihrem Beginn. So sieht man, ob Treiber vor einer
Bewegung schon gekippt waren. Die Tafel ist rein beschreibend und keine Vorhersage.

## Berichtsplan: Diagnosen laufen von selbst (seit 23.20)

Das Dashboard führt die Debug-Einträge, die Claude zu bestimmten Zeitpunkten braucht, selbst aus, zum Beispiel jeden
Mittwoch um 19:00 die Wochenprüfung. Es speichert die Ausgaben auf dem Pi im Projektordner unter `berichte/`.

Im Debug-Bereich stehen:
- der Plan mit Stand (offen, erledigt, verpasst),
- die gespeicherten Berichte,
- der Knopf **„Neue Berichte (n)“**: eine Sammeldatei nur mit Berichten, die du noch nicht abgeholt hast. Abgeholte
  Berichte erscheinen danach gedimmt; „Letzten Abruf nochmal“ liefert dieselbe Datei erneut, falls ein Download
  schiefging. Diese eine Datei lädst du in den Chat hoch.
- zwei Links für alle Berichte der letzten 24 Stunden bzw. 7 Tage.

War der Dienst zur geplanten Zeit aus, wird der Termin bis zu 12 Stunden später nachgeholt. Abschalten lässt sich der
Plan mit der Umgebungsvariable `HL_BERICHTE=0`.

Ein Termin ist kein eigener Eintrag im Debug-Menü: Er startet zu seiner Zeit einen oder mehrere Debug-Läufe von selbst; der Bericht
erscheint danach unter „Neue Berichte“. Seit 23.84 nennt jede Zeile die Nummern dieser Läufe, z. B. „27.10. 09:40 Extrem-Wende nach
Video … (Lauf Nr. 26)“. Von Hand lässt sich derselbe Lauf jederzeit über seine Nummer starten; Studien mit Stichtag rechnen davor
vorläufig.

## Aktive Profis als Darwin-Liste (seit 23.22, Regeln v2 seit 23.37, v3 seit 23.38)

Die Liste der Aktiven Profis ändert sich einmal täglich, bei der ersten Bewertung nach 02:00 Uhr (00 UTC). Seit 23.37
gilt: **streng hinein, großzügig bleiben.**
- **Aufnahme (alles Pflicht):** 2–150 gebündelte Trades am Tag in den verfolgten Coins, Gewinn über 7 und über 30 Tage
  positiv, mindestens 6 bewertbare Ein- und Ausstiege in 14 Tagen, Glückswahrscheinlichkeit höchstens 1 % und
  mindestens 10 Punkte Vorsprung vor dem Zufall.
- **Verbleib:** mindestens 1 Trade am Tag, Gewinn über 30 Tage positiv, mindestens 4 Ein- und Ausstiege, Timing weiter
  über dem Zufall (Glück höchstens 50 %).
- **Abstieg:** erst nach 3 Tagesentscheidungen in Folge ohne Verbleib. Dazwischen zeigt die Karte „Fehltag 1 von 3“
  mit dem Grund.
- **Seit 23.38 (Regeln v3):** Diese Schonung gilt nur für Konten, die über die strenge Aufnahme kamen. Jeder Weg auf die
  Liste verlangt sie, auch die Rückkehr eines zu Unrecht Gesperrten. Beim Umstieg auf v3 blieb nur, wer die Aufnahme unter
  v2 bestanden hatte oder sie jetzt erfüllte; Altmitglieder aus v1 und die Rückkehr über die Verbleib-Regel beim Umstieg
  auf v2 gingen sonst sofort, mit Grund in „Zu- und Abgänge“. `check_profis` zeigt je Mitglied „streng seit …“.
- Sortiert wird nach dem vorsichtig geschätzten Timing-Beleg, nicht nach der Rendite. Viele gut getimte Ausstiege
  schlagen wenige glückliche.

Warum zwei Regeln: Bis 23.36 galt eine Regel für beides (7 Tage, Glück höchstens 5 %, Abstieg nach 2 Tagen). Mit etwa
10 Entscheidungen in 7 Tagen kippte ein gutes Konto schon, wenn ein einziger Treffer aus dem Fenster fiel (7 von 10 bei
32 % Zufall: 1,6 %; 6 von 10: 6,4 %). Gleichzeitig kam bei rund 200 geprüften Konten fast täglich eines nur durch Glück
hinein. In der Simulation (200 Konten ohne, 10 mit 20 Punkten Vorsprung) standen die Könner nur 30 % der Zeit auf der
Liste, mit den neuen Regeln 68 %. Zufallsaufnahmen fielen von 8,8 auf 0,9 je Woche, Könner, die hinausfliegen, von 3,4
auf 0,5 je Woche.

Jede Karte zeigt, ob das Konto die Verbleib-Regel gerade erfüllt („Verbleib erfüllt“ oder den Grund). Unter den Karten
stehen die **Zu- und Abgänge der letzten 7 Tage mit Grund** und Mitglieder, die gerade nicht bewertet werden (gesperrt,
nicht mehr im Pool). Die Pool-Tabelle zeigt für Mitglieder den Verbleib, für alle anderen den ersten Grund gegen die
Aufnahme. Debug „★ Aktive Profis“ druckt dasselbe als Text.

**Schatten der Darwin-Liste (seit 23.57, U136).** Die Aufnahme bleibt bei Glück höchstens 1 %. Im Hintergrund wird beobachtet,
ob Konten, die knapp scheitern, später besser treffen als der Rest des Pools:
- Einmal am Tag kommt jedes geprüfte Konto in eine Gruppe: „≤ 1 %“ (die Aufnahmen), „1–3 %“ und „3–5 %“ (alles erfüllt außer
  der Glücksschwelle) oder die Kontrolle (Glück über 5 %). Die Gruppe gilt ab dem Eintritt und wechselt danach nicht mehr; nur
  aus der Kontrolle führt ein Weg in ein Band.
- Gezählt werden nur Ein- und Ausstiege nach dem Eintritt, mit derselben Regel wie die Liste (2 % binnen 12 h).
- Verglichen wird mit der Kontrolle, nicht nur mit der Zufallsquote: Konten handeln eher in bewegten Phasen, dann treffen
  auch Zufallsentscheidungen öfter.
- Das Urteil ist vorab festgelegt (`KONZEPT_Aktive_Profis.md` Abschnitt 11) und fällt am 18.11.2026 (sonst 16.12.). Bis dahin
  zeigt „★ Aktive Profis“ jede Woche den Zwischenstand. Liste, TradeLabor und Familien lesen den Schatten nicht.
- In der Tabelle steht „Konten (mit Entsch.)“, z. B. „48 (0)“: 48 Konten eingetragen, davon 0 mit gezählten Entscheidungen
  (seit 23.58 in einer Spalte; vorher lasen sich zwei Spalten wie eine).

Jede Karte zeigt die Timing-Bilanz:
- Einstiege und Ausstiege, jeweils Long und Short, mit Trefferzahl und Zufallsquote.
- „Zuerst richtig“: wie oft der Kurs erst 2 % in die richtige Richtung lief, bevor er 2 % in die falsche lief.
- Den Vorsprung gegenüber dem Zufall nach 1, 4 und 12 Stunden.

Darunter stehen bis zu 30 Trades je Konto und eine gemeinsame Zeitleiste aller Profis.

**Woher die Ein- und Ausstiege kommen (seit 23.34):** aus drei Quellen — Wal-Positionen, Leaderboard-Ereignisse und
`pool_positions`, die Positionsänderungen ALLER Pool-Konten (10-min-Raster, Positionen ab 50k, Änderungen ab 10k). Bis
23.33 fehlte die dritte Quelle in der Bewertung. Konten unter der Wal-Schwelle und außerhalb des Leaderboard-Trackings hatten
deshalb keine bewertbaren Ein- und Ausstiege, obwohl sie handelten — die Liste trocknete aus („qualifiziert 0“). Dieselbe
Entscheidung aus mehreren Quellen binnen 15 min zählt einmal. `check_profis.py` zeigt die Zahl je Quelle und ordnet die
Ausschlussgründe richtig zu: Aktivität, Gewinn 7 T, zu wenige Ein-/Ausstiege, Timing nicht belegt, Einstiege widerlegt.

**Fills der Liste ohne Mindestbetrag (seit 23.34):** Der Recorder sammelt die Fills der Darwin-Konten auch unter
2.500 USD, im Stream, per userEvents und im REST-Abgleich. Gedeckelt sind es höchstens 200 kleine Fills je Konto, Stunde
und Quelle. Für alle anderen Konten bleibt die Grenze. `pool_fills_hourly` zählt weiter nur Fills ab 2.500 USD, damit die
Aktivität der Listen-Konten mit dem übrigen Pool vergleichbar bleibt. **Seit 23.37 gilt das auch für die Masterregel:** Sie zählt
gespeicherte Fills nur ab 2.500 USD. Von 23.34 bis 23.36 zählten die kleinen Fills mit. Darwin-Konten wurden so strenger
gemessen als alle anderen, und gerade die besten (Echtzeit-Plätze, jeder Fill kommt an) rutschten über 300 gebündelte
Trades, wurden vorläufig gesperrt und fielen von der Liste. Die Sperren seit dem 29.09. werden einmalig mit der richtigen
Zählung geprüft. Wer zu Unrecht gesperrt war, wird freigegeben und sofort mit der Verbleib-Regel geprüft; erfüllt er
sie, steht er wieder auf der Liste („zurück: zu Unrecht gesperrt“; seit 23.38 nur mit erfüllter Aufnahme). Seit 23.38 gibt die
Neubewertung nur frei, wenn die gespeicherten Fills mit den kleinen die Sperre nachvollziehen und ohne sie höchstens 300
ergeben; eine Freigabe ohne ein einziges mitgezähltes kleines Bündel (0xb078…de15 am 30.09.) wurde einmalig zurückgenommen
(Debug „Masterregel Sperre“). Die Richtung eines Stream-Fills stimmt jetzt auch
bei Konten ohne jede Position: Wer in den letzten 20 min abgefragt wurde und keine Position hat, ist flach, also
eröffnet er. Nach der eigenen frischen Eröffnung gilt deren Seite bis zum nächsten Positionsstand.

## Speicherorte: Backup auf ein anderes Laufwerk (seit 23.23)

Im Bereich „System“ zeigt der Block „Speicherorte“, wo die Datenbank liegt und wohin gesichert wird.

So verlegst du das Backup:
1. „Backup-Pfad ändern“ antippen.
2. Auf dem Pi einen Ordner auswählen, zum Beispiel auf einem USB-Laufwerk unter `/media/…`.
3. „Übernehmen“ antippen. Vorher wird geprüft, ob der Ordner beschreibbar ist, auf einem anderen Gerät als die
   Datenbank liegt und Platz für zwei Generationen hat.

Das nächste Backup geht an den neuen Ort. Mit „Jetzt sichern“ geht es sofort los. Erst wenn dort ein Backup gelungen
ist, bietet der Block an, die alten Backups, zum Beispiel auf der SD-Karte, zu löschen.

Den Datenbankpfad selbst verlegst du vorerst im Terminal mit `python3 migrate_db.py`.

## Konfluenz im Chart und ihre Bilanz (seit 23.24)

Die Konfluenz zählt Kauf- und Verkaufspunkte aus Chart-Faktoren und zeichnet eine Zone ein. Droht ein Anlauf, etwa
durch Sell-Stops oder ein großes Long-Cluster dicht unter dem Kurs, zeigt sie keine Kaufzone darüber. Sie verweist
dann auf das Kaskadenziel („erst nach Abholung“).

Unter dem Konfluenz-Kasten steht ihre Bilanz: wie oft Richtung und Zonen richtig lagen, gegen den Zufall. Aufgezeichnet
wird nur, solange eine Dashboard-Seite offen ist, weil der Browser die Konfluenz berechnet. Er rechnet sie aus der gewählten
Datenquelle, und Binance und Data Mix Fusion haben eigene Regeln. Bis 23.67 speicherte die Bilanz die Quelle nicht und mischte
deshalb Einträge verschiedener Regelwerke (eigener Konstruktionsfehler). **Seit 23.68 (U170)** meldet die Seite die Quelle der
Nutzlast, aus der sie rechnete (Tabelle `konfluenz_log_src`, Schlüssel Coin, Slot und Quelle); die Bilanz zeigt Hyperliquid als
Hauptzeile, Binance und Fusion getrennt, die älteren Einträge als „Quelle unbekannt (vor 23.68)“. Ebenso
`python3 hl_forecast.py --konfluenz`.

**Seit 23.67 (U151, Entscheidung des Nutzers 11.10. nach der Hebel-Studie U142):**
- Der Punkt „Binance Top-Trader netto long/short“ (±1) ist entfernt. Die Regel stand fast immer auf Kauf, und ihr Vorlauf war
  nicht belegt (H2).
- Der Hinweis „Binance: n× mehr Long- als Short-Konten — einseitig, Kaskadenrisiko nach unten“ (ab 3×) nennt die geprüften Quoten:
  danach binnen 7 Tagen ein Rücksetzer um mehr als das 1,5-Fache der üblichen Wochenschwankung in 20 % der Fälle, sonst in 7 % —
  in 4 von 5 Fällen keiner. Er bleibt ein Hinweis ohne Punkt.
- Die Bilanz zeigt die Fälle seit der Regeländerung getrennt („Seit der Regeländerung“). Stichtag ist die erste Meldung eines
  Browsers mit dem neuen Regelstand; die Tabelle `konfluenz_regel` im Prognosespeicher merkt ihn. Ebenso im Text:
  `python3 hl_forecast.py --konfluenz`.

## Treiberfamilien im Parallelbetrieb (seit 23.25)

Der Abschnitt „Treiberfamilien“ fasst ähnliche Treiber zu Familien zusammen, etwa alle Flüsse großer Konten zu einer.
Er prüft jede Familie auf ihrem eigenen Zeithorizont gegen den Zufall, je Coin getrennt. Er läuft neben der bisherigen
Prognose und verändert sie nicht.

**Gewicht:** Eine Familie bekommt erst Gewicht, wenn sie zwei Wochen in Folge einen belegten Vorsprung zeigt.
Stufen: Kandidat, dann Bewährung, dann aufgestiegen. Bis dahin nennt die Familien-Prognose ehrlich die Basisrate.

**Besondere Familien**
- „Stärke“ sagt voraus, ob eine große Bewegung kommt, nicht wohin.
- „Profi-Flow“ ist der Netto-Handel der Darwin-Liste. Er wird ab jetzt aufgezeichnet.
- „Kaskaden“ (seit 23.43) enthält nur den Schatten-Treiber „Kaskaden-Asymmetrie“ der Kaskaden-Gleichung. Sie prüft, ob
  die Asymmetrie der berechneten Kaskadenreichweite die Richtung der nächsten 4 h vorhersagt. Sie geht nicht in v3 ein.

**Treiber-Hygiene:** Die aufklappbare Liste zeigt Treiber, die nur nachlaufen („nachlaufend“) oder in beiden Hälften des
Zeitraums in die Gegenrichtung zeigen („umgekehrt?“).
- Seit 23.55 (U133) wird jeder Treiber an seinen aktiven Zeiten gemessen: Zeitpunkte mit Wert, im Abstand von mindestens einem
  Horizont. Ereignis-Treiber (Kapitulation, OI-Überhitzung, Crowding-Extrem, Vol-Spike-Reversion, Liquidationsdruck) haben nur bei
  einem Ereignis einen Wert; sie werden an ihren Ereignissen bewertet und nicht mehr als „tot“ geführt.
- Ab 8 Fällen gibt es ein Urteil. Sonst steht „kein Urteil“ mit Grund: zu wenige Ereignisse, Werte erst seit kurzem, der Wert bewegt
  sich kaum (z. B. Funding in ruhigen Zeiten) oder er ist bei jedem Fall gleich (Kapitulation +0,8). „kein Urteil“ ist kein Befund
  gegen den Treiber und zählt nicht als auffällig.
- Spalten: Zusammenhang mit der kommenden und der vergangenen Rendite (r, darunter das 95-%-Intervall), Horizont, Fälle, aktiv
  (Anteil der Zeit mit Wert) und zuletzt (letzter Zeitpunkt mit Wert).
- Bei 10 bis 20 Fällen sind die Intervalle breit; ob ein Treiber die Richtung trifft, zeigt die Trefferquote in der Treibertabelle.

**z (seit 23.46 exakt):** z sagt, wie unwahrscheinlich so viele Treffer rein zufällig wären; ab 2 gilt der Vorsprung als belegt.
Gerechnet wird es exakt aus der Verteilung der Treffer unter dem Zufall, höchstens etwa 7, und erst ab 3 Fällen. Bis 23.45 teilte
die Rechnung durch die Streuung der eigenen Fälle. Bei wenigen gleichen Treffern war die praktisch 0, und z explodierte: Auf dem Pi
stand bei „Kaskaden“ mit 3 Fällen z = 1,2 · 10¹⁶; exakt sind es +1,46.

## Heatmap-Anker (seit 23.28)

Oben in der AI-Prognose steht der Kasten „Heatmap-Anker“. Er zeigt, auf welcher Seite des Kurses die stärkeren
Liquidationscluster liegen, gemessen am Stundenvolumen des Coins und im Abstand in Schwankungseinheiten. Dazu kommt
der Stand der täglichen Bilanz: Hat diese Seite den Kurs bisher tatsächlich angezogen, und zwar trendbereinigt?

Steht ein sehr starkes Cluster gegen die Richtung der Prognose, färbt sich der Kasten orange. Auf die Prognose selbst
wirkt der Anker erst, wenn er belegt ist: trendbereinigt z ≥ 2 in zwei Horizonten. Seit 23.46 ist dieses z exakt gerechnet, wie
bei den Treiberfamilien. Vorher konnte es bei wenigen gleichen Treffern explodieren und einen Beleg vortäuschen.

## TradeLabor: simulierter Handel mit allen Daten (seit 23.33)

Der Abschnitt „TradeLabor“ zeigt live, was gut 30 Handelsregeln mit den Daten des Systems anfangen würden. Gehandelt
wird nur auf dem Papier: keine Order an eine Börse, kein API-Gewicht, keine Wirkung auf Prognose oder Treiber.

**Aufbau**
- Jede Strategie handelt je Coin (BTC, ETH, ZEC, HYPE, seit 23.34 auch XMR) ein eigenes Konto mit 10.000 USD je Trade.
  Jedes Konto zählt ab seinem eigenen Start (XMR ab dem Update); die Tagesrendite teilt durch diese Kontotage.
- Die Regeln werden beim ersten Start eingefroren. Eine Änderung ergibt eine neue Kennung mit eigener Bilanz, die alte
  bleibt stehen. Jedes Ergebnis ist damit ein echter Vorwärtstest.
- Gruppen: Händler (Wale, Leaderboard, Smart Money, Pool, Darwin-Liste, Elite, jeweils folgen und dagegen), Prognose (v1,
  v2, Fusion und Fusion mit Kostenschwelle seit 23.42, Kauf-/Verkaufspreise), Treiberfamilien, Ereignisse (Kaskade, Docht,
  Magnet, Kaskaden-Kipppunkt seit 23.43, Funding-Extrem, Ausbruch nach Ruhe, TWAP-Druck), Swing (seit 23.61: Trend-Ausbruch,
  Rücksetzer im Trend, Ausbruch nach Ruhe, Gegenbewegung nach Übertreibung, dazu zwei Zufalls-Kontrollen; seit 23.68 mit fester
  Größe 10.000 USD wie alle, neue Kennungen, U164; bis 23.67 Größe nach Risiko, siehe „Swing-Trades“), Grid (Grid Long, Grid Short,
  seit 23.40; 10.000 USD je Coin, auf die Stufen verteilt -- ein Los ist ein Teil davon), Kontrolle (Zufall, Halten Long).

**Ausführung, bewusst vorsichtig gerechnet**
- Markt-Order: Buchmitte plus halber Spread plus Marktauswirkung aus der Buchtiefe (Orderbuch alle 5 s).
- Limit-Order: gefüllt nur, wenn der Kurs durch den Preis läuft.
- Gebühren Taker 0,045 %, Maker 0,015 %. Funding stündlich. XMR ist auf Hyperliquid ein HIP-3-Markt: Zur
  Protokollgebühr kommt der Anteil des Betreibers (0–300 %). Bis 23.67 waren 100 % angenommen, also doppelte Sätze; gemessen zahlen
  echte XMR-Fills etwa die Hälfte der Standard-Perps. **Seit 23.68 (U160, Entscheidung des Nutzers 13.10.)** rechnet das Labor XMR
  mit den normalen Sätzen; der Zeitpunkt des Wechsels steht im Labor-Zustand, im Bericht und in der Kachel „Gesamt“. Trades über
  den Wechsel zahlen den Einstieg doppelt, den Ausstieg normal. Die Kostenschwelle der Fusion rechnete XMR bis 23.84 doppelt; seit
  23.85 folgt sie dem Labor. Die Gebühren-Prüfung im Bericht vergleicht weiter mit echten Fills.
- Liegen Stop und Ziel in derselben Minute, gilt der Stop.

**Auswertung**
- „Glück“: Wahrscheinlichkeit, dass die beste aller Strategien rein zufällig so gut aussähe (Student-t, mal Zahl der
  Strategien). Erst unter 5 % ernst nehmen.
- Blöcke (seit 23.34): t, Glück, Hälften und Stufen zählen Blöcke, nicht einzelne Trades. Trades einer Strategie, die im
  selben Block ihres Horizonts eröffnet wurden, sind eine Beobachtung. Das ist meist dasselbe Signal in mehreren
  korrelierten Coins. Vorher zählte jeder Coin-Trade einzeln, und vier gleichzeitige Trades vervierfachten scheinbar den
  Beleg. Die Tabelle zeigt „Trades (Blöcke)“.
- Stufen: Kandidat → Bewährung (15 Blöcke, t ≥ 2, Summe > 0) → bewährt (30 Blöcke, t ≥ 3, beide Hälften positiv,
  14 Tage). Negativ: 30 Blöcke, t ≤ −2.
- Hebel-Wahl 1×, 3×, 5×, 10×: alle Ergebnisse hochgerechnet. Erreicht der Rückgang im Trade 90 % der Marge, zählt der
  Trade als liquidiert (−100 % der Marge).

**Erster Blick nach 14 Tagen (Bericht 11.10. 19:31, ausgewertet 13.10.; UEBERGABE 3ζζζ):** 5.204 Trades, netto −104.833 USD,
davon 37.387 USD Gebühren. Keine Strategie ist bewährt, sieben sind negativ, „Glück“ steht überall bei 100 %. „Folgen“ schnitt in
allen vier Fluss-Paaren schlechter ab als „dagegen“, ohne Beleg. Nächster Stand am 25.10. 19:30.

**Reiter:** Live (Signaltafel je Strategie und Coin), Positionen, Strategien, Chart (Kurs mit Ein- und Ausstiegen,
Bilanzverlauf), Datenfluss (jeder Eingang mit Alter und Nutzern), Ereignisse, Trades, Akkumulation (gebaut mit 23.69, auf dem Pi ab 23.70).

**Akkumulation (gebaut mit 23.69, auf dem Pi ab 23.70, Anzeige berichtigt mit 23.71 und 23.73, Korrekturkauf seit 23.72, Faktor gegenüber BTC seit 23.74; U180, U184–U189; Konzept `KONZEPT_Akkumulation.md`):**
eine Strategie, die nur kauft und nie verkauft, je Coin eine eigene Bilanz, Kapital ohne Obergrenze.
- Je Kauf 5.000 USD (seit 23.70; seit 23.74 geteilt durch den Faktor gegenüber BTC) als Spot-Kauf zum Marktpreis (Gebühr 0,070 % einmal
  beim Kauf; kein Hebel, kein Funding, keine Kosten beim Halten). Der Kurs kommt aus dem Perp-Buch von Hyperliquid.
- **Faktor gegenüber BTC (seit 23.74, Wunsch des Nutzers 20.10.):** je Coin die Schwankung (σ_Tag aus den 30-min-Renditen, quadratisch
  gemittelt) geteilt durch die von BTC in den 365 Tagen vor dem Start des Coins im Labor, mindestens 1; einmal beim ersten Takt bestimmt
  und gespeichert (`labor_akku_faktor`), danach fest. Er teilt den Betrag je Kauf und macht die Korrektur-Schwelle A4 gleichwertig
  (0,93 hoch Faktor statt 7 %); A1–A3 rechnen ohnehin mit σ₇ des Coins.
- **A0 Startkauf (seit 23.70):** Der erste Kauf je Coin kommt sofort (unter der Sperre). Beim ersten Takt rechnet das Labor die Käufe
  rückwirkend ab dem Start des Coins im Labor nach (1-min-Kerzen, Regel ohne Heatmap, Vermerk „nachgerechnet“) -- so hat die
  Akkumulation denselben Zeitraum wie die übrigen Strategien. Die Heatmap-Regel wirkt erst live.
- **A1 Rücksetzer:** Kurs mindestens 2 σ₇ unter dem höchsten Kurs der letzten 7 Tage (σ₇ = σ_Tag · √7), kein Kauf in den 7 Tagen davor.
  **A3 Nachkauf:** binnen 7 Tagen nach einem Kauf je weiteres σ₇ tiefer. **A2 Heatmap** (nur die Hauptstrategie): schon ein σ₇ unter
  dem 7-Tage-Hoch und am heißen Long-Cluster (mindestens 25 % des Stundenvolumens); steht die Binance-Konten-Quote bei 3 oder höher
  (U142 H1), wartet A2. **Sperre:** kein Kauf ab 1,2 × der 200-Tage-Linie. Eine Kontrolle ohne Heatmap läuft mit.
- **A4 Korrektur (seit 23.72, Wunsch des Nutzers 20.10.):** 7 % unter dem höchsten Kurs der letzten 48 Stunden ein Korrekturkauf, binnen
  14 Tagen danach je weitere 7 % tiefer ein Nachkauf; seit 23.74 gelten die 7 % für BTC, die übrigen Coins kaufen bei 0,93 hoch Faktor
  (z. B. Faktor 3: 19,6 %); eigene Spur ohne Sperre (kauft also auch ZEC oder XMR über 1,2 × der 200-Tage-Linie), ändert an A0–A3
  nichts; rückwirkend ab dem Start des Coins. Neue Regeln ergeben neue Kennungen -- die Bilanzen von 23.70 und 23.72 stehen im Reiter
  unter „frühere Regeln“.
- **Reiter „Akkumulation“:** unter den Regeln die Tabelle **„Schwellen je Coin“** (seit 23.74: Faktor, Betrag je Kauf,
  Korrektur-Schwelle, Rücksetzer A1, Heatmap A2 und Nachkauf A3 mit σ₇ von heute, Sperre; dieselbe Tabelle im Labor-Bericht);
  Gesamtübersicht (Käufe, eingesetzt, Wert, Gewinn), darunter **„Alle Käufe“** (seit 23.71: jeder Kauf
  einzeln über alle Coins, neueste zuerst, die neuesten 10 und ein Knopf für alle), Wachstum (eingesetzt als Stufe, Wert als Linie, je
  UTC-Tag, alle Coins oder je Coin, mit Fadenkreuz und der Tabelle **„Stand je Tag“** -- keine Kaufliste, sondern je Zeile der Bestand am
  Tagesende; seit 23.73 mit der Spalte „Kauf an diesem Tag“ („—“ oder ⊕ mit dem Kauf) und „eingesetzt gesamt“), je Coin die Bilanz und die Lage („Kauf ab …“, „gesperrt“,
  „Startkauf ausstehend“, Konten, Cluster), „Zeitpunkt gegen Zufall“ ab 5 Käufen nach den Regeln (ohne Startkauf; beschreibend: auch
  ohne Vorhersagekraft meist positiv) und zum Aufklappen jedes Los mit seinem Gewinn (Startkauf und „nachgerechnet“ gekennzeichnet).
  Kachel „Akkumulation“ in der Kopfzeile, Käufe mit ⊕ unter „Ereignisse“ (Seite „spot“).
- **Rückblick seit 2020:** Debug „★ Akkumulation: Rückblick seit 2020 (U180)“ (`hl_labor.py --akku-rueckblick --db …`, einige
  Minuten): die Regel ohne Heatmap und ohne Startkauf auf den Kerzen aus `swing.db`; maßgeblich ist das Zeitpunkt-Maß Q gegen 200
  Vorzeichen-Surrogate (Zufallswege aus den eigenen Renditen). Berichtsplan 20.10. 08:45 (zweiter Termin 21.10.).

**Bilanzverlauf (ab 23.68, U167):** Im Reiter Chart zeigt der Bilanzverlauf das kumulierte Netto jeder Strategie (1×, alle Coins).
- Unter dem Chart steht eine Liste mit allen Strategien. Jede hat ein Häkchen und zeigt Trefferquote, Ø/Tag und Summe; die Liste ist
  zugleich die Legende.
- Standard ist „Top 10“: die zehn aktiven Strategien mit mindestens 20 Trades, ohne Kontrollen, nach Trefferquote (Wahl des Nutzers).
  Wählbar ist auch „nach Ø/Tag“ oder „nach Summe“. Zufall und Halten Long laufen grau als Vergleich mit.
- Knöpfe „Alle“ und „Keine“; die alten Regelversionen sind zugeklappt.
- Die Farbe gehört zur Strategie und bleibt beim Ein- und Ausblenden anderer gleich: acht Farben, die Plätze 9–16 dieselben Farben
  gestrichelt, ab der 17. Linie grau.
- Die Achse richtet sich nach den eingeblendeten Linien. Finger oder Maus im Chart zeigen alle Werte zu diesem Zeitpunkt; die Auswahl
  merkt sich der Browser.
- Eine hohe Trefferquote heißt nicht Gewinn: Viele kleine Gewinne und wenige große Verluste ergeben eine hohe Quote und trotzdem ein
  Minus, so bei den Grid-Bots.

**Darwin-Liste live folgen, Version 2 (seit 23.34, neue Kennung):** Eröffnungen eines Listen-Kontos werden je Coin und
Seite über 15 min netto aufsummiert, auch in kleinen Stücken; Schließungen dazwischen ziehen ab. Ab 10k (der jüngste Fill
höchstens 3 min alt) steigt die Strategie ein, je Eröffnung einmal. Der Folge-Ausstieg kommt, sobald das Konto mindestens
die Hälfte davon wieder geschlossen hat. Version 1 zählte nur, was in einem Takt zusammenkam — eine in Stücke unter 10k
zerlegte Eröffnung blieb unsichtbar. Die alte Bilanz bleibt als „alte Regelversion“ stehen. Seit 23.37 tragen „Darwin
folgen“ und „Darwin gegen“ noch einmal eine neue Kennung (`liste=2`): Die Liste entsteht nach den Regeln v2, die Bilanz
soll nicht zwei verschieden zusammengesetzte Listen vermischen. Seit 23.38 aus demselben Grund `liste=3` (Regeln v3).

**Elite live folgen (seit 23.39):** die zweite Kopier-Vorlage, nach genau derselben Regel wie die Darwin-Liste und ebenfalls
mit Gegenprobe („Gegen die Elite“). Kopiert wird die Elite des jeweiligen Coins, also die Konten, die das Dashboard täglich
nach Konto-Score mit belegtem 4-h-Vorlauf, Gewinn- und Aktivitätsschranke auswählt; von der Masterregel Gesperrte nie. Der
Recorder sammelt dafür die Fills der Elite im Stream (ab 2.500 USD, ohne API-Gewicht). So lassen sich beide Vorlagen direkt
vergleichen: Aktive Profis (belegtes Timing der Ein- und Ausstiege) gegen Elite (belegter Vorlauf der Positionsänderungen).
Die Elite ist dabei nur mit Fills ab 2.500 USD sichtbar, die Darwin-Liste auch mit kleineren. Der Bericht zeigt neben der
Darwin-Prüfung eine **Elite-Prüfung** (Elite je Coin, Fills, Eröffnungen ≥ 10k, Einstiege).

**Grid-Bots (seit 23.40):** „Grid Long“ und das Spiegelbild „Grid Short“ (Gruppe „Grid“), je Coin ein Konto über
10.000 USD, auf die Stufen verteilt.
- **Range:** aus den 1-min-Kursen der letzten 24 h, 10. bis 90. Perzentil; nach einem Ausstieg nur aus Kursen ab dann.
  Aufgebaut wird nur ohne Trend gegen das Grid (Netto-Bewegung höchstens 1-mal ihre eigene Schwankung dagegen, 2-mal mit
  ihm) und mit dem Kurs im mittleren Teil der Range. 4–12 Stufen mit mindestens 0,2 % Abstand.
- **Handel:** Jeder Abstand zwischen zwei Stufen hält ein Los oder eine Einstiegs-Order. Long kauft unten und verkauft eine
  Stufe höher (Maker), Short umgekehrt; danach liegt dort wieder ein Einstieg. Beim Aufbau kauft das Grid den klassischen
  Startbestand (die Stufen jenseits des Kurses) zum Marktpreis. Stündlich nachgeführt, wenn sich die Range deutlich
  verschoben hat; vorhandene Lose behalten ihr Ziel, das Kapital wird nie überschritten.
- **Starke Bewegung in Grid-Richtung** (Squeeze bzw. Kaskade, ≥ 3 σ in 5 oder 15 min in der Gewinnhälfte, Ausbruch aus der
  Range): keine Verkäufe mehr, alle Lose halten, Trailing-Stop 1,5 σ(1 h) vom Extrem — das Maximum ist erkannt, wenn der
  Kurs so weit zurückfällt. Danach 2 h Pause.
- **Notausstieg** (Kaskade gegen das Grid, ≥ 3 σ in 15 min in der ungünstigen Hälfte, Kurs eine Stufe jenseits der Range):
  alle Lose zum Marktpreis, Pause 4 h, nach dem zweiten binnen 24 h 12 h, nach dem dritten 24 h.
- **Bewertung nach Bestandswert:** Ein Grid zeigt laufend kleine realisierte Gewinne, während sich Verluste im Bestand
  sammeln können. Deshalb zählen Summe, Ø/Tag und Blöcke (= Tage) das Tagesergebnis aus realisiertem Gewinn und Änderung
  des unrealisierten Bestands. Positionen zeigt die Grids gebündelt, der Chart mit gewähltem Grid Range, Notlinie und
  Trailing-Stop, der Bericht einen Abschnitt „Grid-Bots“.
- **Praxis-Hinweis:** Hyperliquid kennt je Konto und Coin nur eine Netto-Position (kein Hedge-Modus). Long und Short in einem
  Konto würden sich verrechnen; das Labor rechnet jede Strategie als eigenes Konto, live entspräche das je Grid einem
  Sub-Account (eigene Positionen und Margin; bis 10 ab 100.000 USD Handelsvolumen). Beide Grids nutzen dieselbe Range, solange
  sie dasselbe 24-h-Fenster sehen; nach einem Ausstieg oder beim Nachführen können sie auseinanderlaufen.

**Betrieb:** Takt 15 s im Dashboard-Dienst, Stand im Prognosespeicher (Tabellen `labor_*`). Abschalten mit
`HL_LABOR=0` in der Unit. Bericht: Debug „★ TradeLabor“ (`hl_labor.py --bericht --db PFAD`), wöchentlich im Berichtsplan.
Seit 23.34 listet er alle offenen Positionen und enthält zwei Prüfungen: die **Darwin-Prüfung** (Listengröße, Fills der
Liste in 24 h mit Richtung, Eröffnungen ab 10k binnen 15 min nach der Live-Regel nachgerechnet, Einstiege der
Strategie) und die **Gebühren-Prüfung** (Gebührensatz echter Fills XMR gegen BTC/ETH). **Seit 23.68:** eine Tabelle je Strategie
und Coin (Trades, Blöcke, Treffer, Ø netto, Summe, Gebühren, Ø Abstand zur Buchmitte; XMR vor und nach dem Gebührenwechsel getrennt,
U161) und je Grid und Coin die letzten 7 Tage. Im Dashboard (U163): Spalte „Größe“ (USD je Trade bzw. je Grid-Los, in der
Hebel-Ansicht mal Hebel) mit „Los“ bei Grid-Losen, bei Auswahl eines Grids die Tabelle „Grid je Coin und Tag“ (Lose, realisiert,
Änderung des Bestands, Tagesergebnis in USD und in % des 10.000-USD-Kontos), „Ø/Tag“ zusätzlich in USD je Coin-Konto.

## Adress-Strom (seit 23.33)

Jeder Trade im Hyperliquid-Feed trägt beide Adressen und die Seite des Nehmers. Der Recorder fasst das je Minute, Coin
und Adresse zusammen: Nehmer- und Geber-Käufe und -Verkäufe, Anzahl, TWAP-Anteil. Er schreibt es in eine eigene Datei
`adressfluss.db` neben der Datenbank.

- 0 API-Gewicht, denn der Feed läuft ohnehin. Keine Schreiblast auf `hl_liq.db`, nicht im Backup.
- Vorhalt 14 Tage (`--af-tage`, 0 = aus). Deckel 3 GB (`--af-max-gb`): darüber werden die ältesten Stunden gelöscht.
  Erwartet: grob 40–80 MB je Tag.
- Null-Hash: Trades ohne eigene Transaktion, nach allem, was bekannt ist, TWAP-Teilaufträge. Der Netzwerkstatus zeigt den
  Anteil, Debug „Adress-Strom“ die größten TWAP-Adressen.
- Nutzer: TradeLabor (TWAP-Druck, Datenfluss). Als Nächstes der informierte Fluss je Adresse (U75, sobald einige Tage
  Daten vorliegen) und die Trennung TWAP gegen ausgelöste Orders.

**Handläufe im Debug** (seit 23.33): Jeder von Hand gestartete Debug-Lauf landet zusätzlich als Datei in `berichte/`
(Name endet auf `_manuell`) und erscheint unter „Neue Berichte“.

## Fusionsprognose, Kalibrierung v3 und Kostenschwelle (seit 23.42)

Stufe 1 des Konzepts `KONZEPT_Fusion.md`: alle Quellen zu EINER Wahrscheinlichkeit verschmelzen und nur handeln, wenn der
Vorsprung die Kosten trägt. Alles läuft **im Schatten**: Die angezeigte P(aufwärts), Pfad, Bias und Kaufpreise bleiben v1
(bzw. v2, wenn deren Schalter gesetzt ist). Modul `hl_fusion.py`.

**Kostenschwelle je Coin und Horizont.** Ein Richtungsurteil mit Trefferquote p bringt im Mittel (2p − 1) · E|r|. Es lohnt
sich erst ab p* = ½ + Kosten / (2 · E|r|). E|r| ist die gemessene mittlere Bewegung des Coins in den letzten 30 Tagen, die
Kosten sind ein Hin- und Rückweg (Taker: Gebühr plus halber Spread; Maker: Gebühr; Sätze wie im Labor, XMR seit 23.85 auch
hier normal). Bei BTC-typischer Schwankung
braucht ein 4-h-Handel als Taker rund 57 % Trefferquote, als Maker rund 52 %.

**Kalibrierung v3.** v2 über alle Coins geteilt, auf den sieben Richtungsfamilien statt auf einzelnen Treibern: Was in allen
Coins gleich wirkt, wird gemeinsam geschätzt; eine Abweichung je Coin gibt es nur gegen Beleg. Stündlich neu (erstmals 5 min
nach dem Start). Ohne Beleg nennt v3 je Coin die Basisrate.

**Fusionsprognose.** Eine Mischung der Experten Basisrate, v1, v2, v3 und Analog-Suche. Nach jedem aufgelösten 4-h- bzw.
24-h-Block bekommt mehr Gewicht, wer das Ergebnis besser vorhergesagt hat (Log-Verlust). Mathematisch garantiert: höchstens
um eine feste Konstante schlechter als der beste einzelne Experte. Jede Fusionszahl steht fest, bevor ihr Ergebnis bekannt
ist. Beim ersten Start werden die gespeicherten Prognosen der letzten 60 Tage nachgetragen, ebenfalls ohne Blick in die Zukunft.

**Wo man es sieht**
- AI-Prognose, Kachel „P(aufwärts) Fusion — Schatten“: Fusion 4 h und 24 h, Anteile der Experten, v3 allein, Kostenschwelle
  (Taker/Maker) und ob die Fusion für ihre Richtung darüber liegt.
- Selbstoptimierung, Kachel „Fusion und Kalibrierung v3“: v3-Modell (n, n_eff, Coins, λ, Teilen, c, OOF-Quote, Brier-Skill)
  und die Bilanz der Fusion je Horizont mit dem **Abstand zur Basisrate ± 1 Standardfehler** („nicht belegt“, „belegt besser“
  oder „belegt schlechter“).
- Debug „★ Fusion und v3“: Stand je Coin (Kostenschwelle für 1/4/12/24 h, Gewichte, Bilanz, nur live gestellte Blöcke) und
  am Ende alle Coins zusammen mit Zeitblöcken als Klumpen. Läuft wöchentlich im Berichtsplan (W11), dazu am 11.10. 19:30
  (erste Woche) und am 25.10. 19:30 (Auswertung U108).
- Debug „Fusion, v3 und Kostenschwelle: Selbsttest“ (`python3 hl_fusion.py --nulltest`, rund 30 s, auch Installationsschritt).
- TradeLabor, Gruppe Prognose: „Prognose Fusion“ (feste Schwelle wie v1) und „Fusion mit Kostenschwelle“ (handelt nur, wenn
  |2p − 1| · E|r 4 h| mindestens das 1,5-Fache der Kosten zum Marktpreis aus dem aktuellen Buch erreicht).

**Was man erwarten darf:** Ohne echte Kante in den Experten ist die Fusion ungefähr die Basisrate, im Log-Verlust sogar
etwas schlechter (der Preis der Mischung, in der Probe 0,004 je Block). Die Daten sind knapp: Mit rund 240 effektiven 4-h-Blöcken
je Coin hat die Trefferquote einen Standardfehler von gut 3 Punkten. Ein Urteil gibt es frühestens nach drei Wochen live
(Auswertung U108 ab 25.10.); umgeschaltet wird nur mit Beleg.

**Erster Blick (Bericht 11.10. 19:30, ausgewertet 13.10.; `KONZEPT_Fusion.md` 6.1):** Die Fusion ist auf 4 h nicht belegt besser
als die Basisrate (−0,0032 ± 0,0029 je Block) und gegen keinen Experten belegt schlechter; v1 liegt knapp vorn. Alle Vorhersagen
liegen beim Münzwurf (Log-Verlust um ln 2 = 0,693). Vorab festgehaltene Erwartung für den 25.10.: Die Fusion bleibt im Schatten.
Ab 23.68 rechnet der Bericht auch Kriterium 5 (E|r| gegen die eingetretene Bewegung, U162).

**Urteil 25.10. (U108, `KONZEPT_Fusion.md` 6.3): Die Fusion bleibt im Schatten.** Gegen die Basisrate −0,0022 ± 0,0016 je Block
(−1,4 SE, belegt erst unter −2 SE); gegen keinen Experten belegt schlechter (v1 +1,8 SE). Keine 4-h-Vorhersage schlägt den Münzwurf
erkennbar.

**Seit 23.85 im Bericht** (`KONZEPT_Fusion.md` 6.4): je Coin und über alle Coins die Zeile „gegen Münzwurf“ (Log-Verlust minus
ln 2 = 0,6931; nur beschreibend, kein Experte); Kriterium 5 mit dem Abstand zu 1 in Standardfehlern, aus den ungerundeten Werten (U190).

## Kaskaden-Gleichung (seit 23.43)

Stufe 2b des Konzepts `KONZEPT_Fusion.md` (Abschnitt 4b), Modul `hl_kaskade.py`. Antwort auf die Frage nach einer Gleichung,
die den Kurs vorausberechnet: Für den Kurs selbst gibt es keine, für seine **Verteilung** schon. Der erste Baustein ist der
Teil, für den nur dieses System die Daten hat: die Liquidationscluster der Heatmap. Alles läuft **im Schatten** und ändert
weder die angezeigte Prognose noch v1, v2, v3 oder die Fusion.

**Die Gleichung.** Ein erzwungener Fluss Q (USD) verschiebt den Kurs nach dem Wurzelgesetz der Marktwirkung um
I = Y · σ_Tag · √(Q / V_Tag) (Tóth u. a. 2011). Erreicht ein Rutsch die Long-Cluster unter dem Kurs, schieben deren
Liquidationen ihn weiter. Reicht das bis zum nächsten Cluster, läuft die Kaskade weiter. Nach oben gilt dasselbe mit den
Short-Clustern. Die Rechnung ist exakt (geschlossene Form, mit 120.000 Fixpunkt-Vergleichen geprüft). Daraus folgen:
- **Kipppunkt:** der kleinste Rutsch (bzw. Anstieg), ab dem die Kaskade mindestens 0,5 σ(4 h) weiter trägt, und ihr **Ende**.
- **P(Rutsch ≥ 2 σ):** die Wahrscheinlichkeit binnen 4 h (bzw. 1 h), mit Clustern und zum Vergleich ohne Heatmap (derselbe
  Zufallsweg ohne die Cluster). Seit 23.44 mit **gemischter Schwankung**: Die Schwankung einer Stunde streut um die gemessene
  (7 Tage, Streuung τ). Ohne diese Mischung kamen große Ausschläge auf dem Pi rund doppelt so oft vor wie vorhergesagt.
- **Kaskaden-Asymmetrie:** erwartete Reichweite oben gegen unten, −1 … +1. Sie ist ein Schatten-Treiber mit Gewicht 0.

**Kalibrierung.** Y wird je Coin und Horizont (1 h, 4 h) aus der eigenen Historie geschätzt, alle 6 h (erstmals 15 min nach
dem Start). Dazu gehören geblockte Kreuzvalidierung, die 1-SE-Regel zugunsten des kleineren Y und mindestens 120 Blöcke
(1 h: 5 Tage, 4 h: 20 Tage). **Belegt** ist Y erst, wenn vier Bedingungen erfüllt sind:
- Y > 0 ist gewählt.
- Der Vorsprung liegt über 2 Standardfehlern.
- Das **Placebo** wählt Y = 0. Es nutzt die Heatmap von drei Tagen vorher.
- Der **Seitenspiegel** ist beim gleichen Y deutlich schlechter. Er nutzt dieselben Cluster mit vertauschten Seiten (seit
  23.44 beim gleichen Y verglichen; vorher konnte der Spiegel mit Y = 0 antreten und schützte dann nicht).

Der Seitenspiegel trennt echte Kaskaden-Mechanik von einem bloßen Mitlaufen der Schwankung. Bis Y belegt ist, rechnen
Kipppunkt und Treiber mit Y = 1 (Literaturwert). Die Wahrscheinlichkeiten nehmen das kalibrierte Modell; mit Y = 0 ist das
der Zufallsweg.

**Wo man es sieht**
- AI-Prognose, Kachel „Kaskaden-Gleichung — Schatten“:
  - fett der untere Kipppunkt → Ende (Kurs und Abstand in %), darunter der obere;
  - dann Y (belegt oder Literaturwert, mit Grund), die Asymmetrie, P(Rutsch ≥ 2 σ) und P(Anstieg ≥ 2 σ) binnen 4 h (solange
    4 h nicht kalibriert ist: 1 h) und zum Vergleich ohne Heatmap;
  - zuletzt der Stand der Kalibrierung je Horizont.
- Treiber-Tabelle: „Kaskaden-Asymmetrie“ mit dem Etikett „Schatten“.
- Treiberfamilien: Familie „Kaskaden“.
- Debug:
  - „★ Kaskaden-Gleichung (Schatten)“: Stand je Coin mit Kipppunkten, Reichweite, Y, c und τ je Horizont, Abstand ± SE,
    Brier-Skill, Placebo, Seitenspiegel und Abdeckung der Heatmap. Seit 23.44 außerdem:
    - „vorhergesagt gegen eingetreten“ für Ausschläge ≥ 2 σ und ≥ 1 σ mit ✓ (innerhalb 2 SE) oder ✗;
    - Zuverlässigkeit nur für Klassen mit mindestens 20 Fällen;
    - die Richtungsprobe ab 20 Blöcken, dazu eine Zeile über alle Coins mit dem Hinweis auf den Mehrfachtest.
  - „Kaskaden-Gleichung: jetzt kalibrieren“.
  - „Kaskaden-Gleichung: Selbsttest“ (`python3 hl_kaskade.py --nulltest`, seit 23.44 rund 40 s, auf dem Pi rund 1,5 min, auch
    Installationsschritt).
- Berichtsplan: wöchentlich in der Wochenprüfung (W12, mittwochs 19:00), dazu einmalig am 11.10. 19:45 (Stand und Selbsttest
  nach der ersten Woche) und am 25.10. 19:45 (Auswertung U115).
- TradeLabor, Gruppe Ereignisse: „Kaskaden-Kipppunkt“. Fällt der Kurs durch den unteren Kipppunkt, geht die Strategie Short
  bis zum berechneten Ende; steigt er durch den oberen, Long. Sie handelt nur, wenn der Weg zum Ende das 1,5-Fache der Kosten
  zum Marktpreis deckt. Stop 0,5 σ(1 h) hinter dem Kipppunkt, spätestens nach 2 h, je Kipppunkt einmal. Vergleich:
  „Kaskaden-Fortsetzung“ (dieselbe Idee ohne Gleichung).

**Was man erwarten darf**
- 1 h ist mit den vorhandenen Heatmap-Ständen sofort kalibrierbar. 4 h braucht etwa 20 Tage Aufzeichnung, das Placebo drei
  Tage mehr.
- Die Heatmap sieht nur die verfolgten Konten. Kipppunkte können deshalb zu weit weg liegen.
- Wahrscheinlich ist Y bei BTC und ETH klein oder nicht belegt, bei den dünneren Coins eher sichtbar. „Nicht belegt“ ist ein
  Ergebnis, kein Fehler.
- Ein Urteil gibt es ab dem 25.10. (U115). Eingeschaltet wird nur mit Beleg, als Sprung-Teil der Verteilungsprognose (U116).
  **Urteil 25.10. (`KONZEPT_Fusion.md` 4b.1d): nicht belegt.** BTC und ETH 1 h erfüllen drei von vier Bedingungen, der Seitenspiegel
  fehlt; vorhergesagt ≈ eingetreten 24 von 24; Richtung 47 % ± 3 %. Die Gleichung bleibt im Schatten.
- **Erste Zahlen vom Pi (04.10., 26,7 Tage):**
  - Nichts belegt. BTC 1 h kam am nächsten: Vorsprung 2,6 SE, Placebo ohne Befund, aber der Spiegel nur 1,4 SE schlechter.
  - Die Heatmap deckt 25–29 % des OI ab.
  - Große Ausschläge waren in allen Coins zu niedrig vorhergesagt, z. B. ≥ 2 σ BTC 1 h 2,9 % gegen 5,8 % eingetreten. Behoben in
    23.44 (gemischte Schwankung).
- **Nach dem Update auf 23.44:** Die alten Kalibrierungen gelten nicht mehr (Modellversion 2). Bis zum ersten Takt 15 min nach dem
  Start steht in der Kachel „Kalibrierung ausstehend“; Debug „Kaskaden-Gleichung: jetzt kalibrieren“ geht sofort. Danach liegen
  die Wahrscheinlichkeiten großer Ausschläge höher (etwa 5 % statt 3 % für ≥ 2 σ binnen 1 h). Treiber und Kipppunkte bleiben
  unverändert.
- **Zweite Kalibrierung (Pi, 04.10. 20:55, mit 23.44):** vorhergesagt ≈ eingetreten in allen Coins und Horizonten (22 von 22 ✓),
  z. B. ≥ 2 σ BTC 1 h 5,3 % gegen 5,7 % eingetreten. Nichts belegt; HYPE 4 h erfüllte drei Bedingungen und scheiterte am Spiegel.
  Zahlen in `KONZEPT_Fusion.md` 4b.1b.

## Magnet-Test (seit 23.45)

Stufe 2 des Konzepts (`KONZEPT_Fusion.md`, Abschnitt 4 „U110“), Modul `hl_magnet.py`. **Nur Messung:** Er ändert weder Prognose
noch Treiber, v1, v2, v3, Fusion oder Labor.

**Die Frage.** Berührt der Kurs Liquidationscluster öfter, als ein Zufallsweg mit der richtigen Schwankung erwarten lässt? Dann
zögen Cluster den Kurs an. Die Kaskaden-Gleichung fragt, ob es nach dem Erreichen weitergeht; der Magnet-Test fragt nach dem
Erreichen selbst.

**Die Rechnung.**
- Nullmodell: die Wahrscheinlichkeit, dass der Kurs binnen 1 h bzw. 4 h ein Niveau im Abstand d erreicht, mit derselben gemischten
  Schwankung wie in der Kaskaden-Gleichung, ohne Cluster. Die Parameter kommen je Block aus den anderen Zeitabschnitten
  (out-of-fold), damit kein Block sich selbst bewertet.
- Fälle: je Block, Seite und Größenklasse (klein < 0,5 %, mittel 0,5–2 %, groß ab 2 % des Tagesumsatzes) das nächste Cluster bis
  3 σ.
- Überschuss = berührt minus vorhergesagt, beide Seiten gleich gewichtet. So hebt sich ein Trend auf.
- Kontrollen: Spiegel (dasselbe Niveau auf der anderen Seite), Placebo (Tiefen und Größen der Karte von drei Tagen vorher),
  Zufallsniveaus (zeigen, ob das Nullmodell bei 0,25–3 σ trifft).
- **Belegt** je Klasse und Horizont, wenn alle vier gelten:
  - mindestens 60 wirksame Fälle; beide Seiten sind nötig (wirksam = 4 · unten · oben / (unten + oben));
  - Überschuss über 2 Standardfehlern;
  - Überschuss minus Spiegel über 2 Standardfehlern;
  - Überschuss minus Placebo über 2 Standardfehlern.

**Wo man es sieht**
- Debug „★ Magnet-Test (U110)“: je Coin und Horizont das Nullmodell (c, τ); je Klasse die Fälle (unten, oben, wirksam), die mittlere
  Tiefe, berührt gegen vorhergesagt, Überschuss ± SE, Spiegel und Placebo. Dazu das Urteil mit der fehlenden Bedingung, z. B.
  „nicht belegt (nur eine Seite, Placebo ≤ 2 SE)“, und die Zeile „Nullmodell an Zufallsniveaus“.
- Debug „Magnet-Test: jetzt rechnen“ (sonst alle 6 h im Dashboard, erstmals 20 min nach dem Start).
- Debug „Magnet-Test: Selbsttest“ (`python3 hl_magnet.py --nulltest`, rund 20 s, auf dem Pi rund 40 s; auch Installationsschritt).
- Berichtsplan: wöchentlich in der Wochenprüfung (W13, mittwochs 19:00). Einmalig am 11.10. 20:00 (Stand und Selbsttest nach der
  ersten Woche) und am 25.10. 20:00 (Auswertung).

**Was man erwarten darf**
- Für 1 h zählen vor allem Cluster nah am Kurs: 3 σ sind bei BTC rund 1 %, für 4 h rund 2 %. Große Cluster liegen oft weiter weg
  oder nur auf einer Seite; dann lautet das Urteil „nur eine Seite“.
- Wahrscheinlich ist der Überschuss klein. „Nicht belegt“ ist ein Ergebnis.
- 36 Tests je Lauf (6 Coins, 2 Horizonte, 3 Klassen): Ein einzelner Befund knapp über 2 SE kann Zufall sein. Belastbar ist erst,
  was über Wochen bleibt. Erst dann kommt ein Treiber „Zug“.
- **Urteil 25.10. (47,5 Tage): nichts belegt** -- 21 urteilsfähige Klassen, keine mit Überschuss über 2 SE. Kein Treiber „Zug“; der
  Test läuft als Messung im Wochenbericht weiter.
- **Grenze:** Belegt heißt, die Karte sagt Berührungen vorher. Ob das Cluster zieht oder an einem Niveau liegt, zu dem der Kurs
  ohnehin läuft, trennt der Test nicht.

## Makro-Chart (seit 23.47)

Abschnitt „MK Makro“ im Dashboard (nach dem TradeLabor), Module `hl_makro.py`, `hl_makro_js.py`, `hl_makro_signal.py` (seit
23.49) und `hl_makro_korr.py` (seit 23.52), Konzept `KONZEPT_Makro.md`,
Recherche `RECHERCHE_Makro_Chart_05-10-2026.md`. Die Frage ist nicht „was passiert in den nächsten Stunden?“, sondern **wo der Markt
im Zyklus steht** (Monate bis Jahre, Tagesdaten). Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor.

**Was man sieht**
- **Überblick:** ein Satz zur Lage, die Zonenkarte und der Chart „Kurs und Kostenbasen“. Die Zonenkarte zeigt je Treiber den
  Tagesschluss, „jetzt“ mit dem Live-Kurs, die Lage als Perzentil der eigenen Historie (0 = tiefster, 100 = höchster Wert bis zu
  diesem Tag), den Bezug und die Einordnung (unterstes Zehntel … oberstes Zehntel). Auf dem Handy erscheint sie als Karten.
  - **Verlauf je Indikator (seit 23.51):** unter der Zonenkarte für jede Zeile ein kleiner Chart mit der Reihe hinter der Zahl, im
    gewählten Zeitraum. Je Chart eine eigene Skala, eine Bezugslinie (1, 0 oder 50) und ein Punkt auf dem letzten Tagesschluss;
    Fadenkreuz und Tabelle wie in den Tabs.
  - Die letzten zwei Jahre sind tägliche Werte, davor jeder siebte Tag. Miner nur 4 Jahre (fester Gerätetyp). Lücken bleiben
    Lücken (z. B. solange das OI-Archiv lädt), keine Verbindungslinie.
  - Auf breiten Bildschirmen nebeneinander (bei 1280 px drei Spalten), auf dem Handy untereinander. Die Tage seit dem Halving haben
    keinen eigenen Chart.
- **Bewertung:** Realized Price, Delta Price, MVRV mit Hoch und Tief je Halving-Epoche, MVRV-Perzentil (seit Beginn und 4 Jahre),
  MVRV-Z. Die Coins sind BTC, ETH und ZEC.
- **Trend:** Power Law mit Bändern und kausalem Perzentil, die Exponenten über die Zeit, der 200-Wochen-MA mit Abstand (BTC, ETH,
  ZEC, XMR) und die Halving-Zyklen übereinander.
- **Kohorten** (BGeometrics, letzte 4 Jahre): Kurzfrist- und Langfrist-Kostenbasis, True Market Mean, STH-MVRV, aSOPR, LTH-SOPR,
  AVIV und realisierte Verluste. Grau markiert ist die Zeit, in der der Kurs unter der Kurzfrist-Kostenbasis lag. Frei enden die
  Werte 7 Tage vor heute (Echtzeit nur im Abo).
- **Miner:**
  - Kurs und Stromkosten je BTC als Szenario. Ausgangsszenario ist ein Antminer S21 XP mit 13,5 J/TH bei 7,5 US-Cent/kWh.
  - Gerät, J/TH, Strompreis, Währung (US- oder Euro-Cent) und ein Aufschlag sind oben einstellbar; das Band zeigt ± 2,5 ct, gestrichelt
    die ältere Flotte S19 XP.
  - Darunter Kurs ÷ Kosten, Puell Multiple, Hash Ribbons und Difficulty Ribbon.
  - Hash Ribbons markieren eine Kapitulation erst, wenn die Lücke zwischen SMA30 und SMA60 tiefer ist als das Rauschen der
    Tageshashrate (3 σ/√60, rund 3,5 %). Flache Kreuzungen werden nur gezählt.
- **Hebel & Stimmung:** Funding (Binance, % p. a., 30-Tage-Mittel), Open Interest ÷ Marktkapitalisierung, DVOL, Fear & Greed und
  Wochen-RSI.
- **Kapitalfluss:** Stablecoin-Angebot, Stablecoin Supply Ratio und ETF-Nettoflüsse BTC/ETH (kumuliert und 30 Tage).
- **Makro:** Nettoliquidität, globaler Liquiditätsproxy (Fed + EZB + BoJ), M2, Realzins, Dollar, Hochzinsspread und Leitzins. Unter
  jeder Reihe steht ihre rollierende Korrelation mit BTC samt Zufallsband ±2/√n und einem Regimetext.
- **Arbeitsmarkt und Preise der USA (seit 23.67, U153; `KONZEPT_Makro.md` 11):** fünf Charts unter „Makro“, nur Anzeige, sie wirken
  auf nichts.
  - Arbeitslosenquote (UNRATE), neue Stellen je Monat mit 3-Monats-Mittel (PAYEMS), Erstanträge auf Arbeitslosenhilfe als
    4-Wochen-Mittel (ICSA, nur über vier lückenlose Wochen).
  - Vorjahresraten wie bei BLS aus den nicht bereinigten Reihen (Verbraucherpreise gesamt CPIAUCNS und Kern CPILFENS,
    Erzeugerpreise PPIFID); Monatsraten aus den bereinigten (CPIAUCSL, CPILFESL, PPIFIS).
  - Je Chart Kursleiste, Fadenkreuz, Tabelle, Quelle und der nächste passende Termin; oben „Termine der nächsten 14 Tage“, alle um
    8:30 New York, angezeigt in Ortszeit (in Berlin 14:30, in der Woche 25.10.–01.11. 13:30).
  - Korrelation mit BTC wie bei den übrigen Reihen, nicht unter den Vorjahresraten.
  - **Lücke Oktober 2025** (Stillstand der US-Regierung, nie erhoben) bleibt Lücke: Das Fadenkreuz zeigt dort „—“, über die Lücke
    gibt es keine Rate (auch bei der Vorjahresrate für Oktober 2026 nicht, wie bei BLS).
  - Speicher: Jeder neue oder geänderte Wert kommt mit Abrufzeit in `mk_fassung` (die Stellenzahlen werden zweimal korrigiert);
    die Erstveröffentlichungen holt der Takt einmal im Monat aus ALFRED, die Termine einmal am Tag über `fred/release/dates`. Beides
    nur mit FRED-Schlüssel.
- **Daten:** jede Quelle mit letztem Erfolg und Fehler, alle Reihen mit Zeitraum, das BGeometrics-Budget, das Binance-Archiv, das
  Archiv der Tagesstände und die Lizenzen.
  - Je Reihe stehen Alter und Grenze des letzten Werts. Eine Warnzeile nennt Reihen, die zu alt sind, und Reihen, die nach einem
    erfolgreichen Abruf fehlen.
  - Der Grund: Verschwindet eine Metrik aus einem freien Katalog oder ändert eine Seite ihr Format, scheitert oft kein Abruf. Die
    Reihe bleibt nur stehen.
  - Grenzen je Quelle: Coin Metrics 5 Tage, Farside 7, BGeometrics 9 (frei mit 7 Tagen Verzug), FRED täglich 10, wöchentlich 14
    bis 21, M2 und BoJ 100.
  - Fehler stehen als eigene Zeile unter dem Ziel, mit dem nächsten Versuch.
- **FRED-Schlüssel (seit 23.48):** Ohne Schlüssel antwortet `fredgraph.csv` seit Mitte August 2026 vielerorts nicht. Dann bleiben
  die Tabs Makro und Euro-Cent leer.
  - Abhilfe: kostenlosen Schlüssel holen (Konto bei fredaccount.stlouisfed.org, „API Keys“ → „Request API Key“).
  - Im Tab „Daten“ ins Feld kopieren und „prüfen und speichern“ drücken.
  - Oder im Projektordner: `.venv/bin/python hl_makro.py --db <hl_liq.db> --fred-schluessel <SCHLÜSSEL>`.
  - Der Schlüssel landet in `accesstokens.json` unter `"fred"` (das Update überschreibt die Datei nie). Die Umgebungsvariable
    `FRED_API_KEY` hat Vorrang.
  - FRED wird binnen einer Minute abgerufen; die Charts folgen binnen rund 10 Minuten.
- Bedienung:
  - Oben gibt es eine Filterzeile (Zeitraum 1 J … Alles, Coin wo sinnvoll).
  - Jeder Chart hat ein Fadenkreuz mit allen Werten am Tag und den Knopf „Tabelle“ (Monatsenden).
  - Unter jedem Chart steht die Quelle.
- **Kursleiste (seit 23.54, U132):** Unter jedem Kennzahl-Chart steht der Kurs in Orange in einem eigenen Feld.
  - Das Feld hat eine eigene log. Skala und dieselbe Zeitachse wie der Chart darüber (dessen Zeitraum; der Kurs verlängert ihn nie).
    Das Fadenkreuz geht durch beide, der Tooltip nennt den Kurs am selben Tag, die Tabelle hat eine Kursspalte.
  - Bewusst keine zweite y-Achse im selben Feld: Deren Bereich ist frei wählbar, und mit passender Wahl laufen fast beliebige zwei
    Reihen im Bild gleich.
  - Gleichlauf im Bild ist kein Beleg. Viele Kennzahlen sind aus dem Kurs gerechnet (MVRV, Puell, Abstand zum 200-Wochen-MA …) und
    laufen deshalb mit ihm. Ob eine Kennzahl die künftige Rendite vorhersagt, misst „Makro × Kurs“ (Debug, U130).
  - In Bewertung und Trend mit ETH zeigen die Charts der Münze deren Kurs („Kurs ETH“).
  - Keine Leiste haben Charts, die den Kurs schon zeigen (dort hellgrau), „Halving-Zyklen übereinander“ (Zeitachse in Tagen) und die
    Korrelationscharts im Tab Makro.
  - Der Schalter „BTC-Kurs“ neben dem Zeitraum blendet die Leisten aus; der Browser merkt sich die Wahl.

**Signale je Chart (seit 23.49, U126)** — in den Tabs Bewertung, Trend, Kohorten und Miner, für jeden Chart mit Referenzlinie
(Kurs gegen Realized Price, Delta Price, Power-Law-Fair-Value, 200-Wochen-MA, Kurzfrist- und Langfrist-Kostenbasis, True Market
Mean, Stromkosten; Puell gegen 1), je Zeitraum aus der Filterzeile:
- **Abweichung** zur Referenzlinie in %, **Median** der Abweichung im Zeitraum (gepunktete Linie im Chart).
- **Rückblick:** tiefster und höchster Stand, ideale Wendepunkte ▲▼ — erst im Nachhinein bekannt, kein Signal.
- **Live-Signal:** Kauf, wenn die heutige Abweichung im untersten Zehntel des Zeitraums liegt, Verkauf im obersten Zehntel; nur mit
  Daten bis zum jeweiligen Tag. Die Schwellen stehen gleitend im Signal-Chart, die Signalzeiten als Flächen.
- **Bilanz** (aufklappbar): Rendite 90/180/365 Tage nach dem ersten Tag jeder Signal-Episode gegen gleich viele Zufallstage aus
  derselben Zeit; „belegt“ erst bei p < 0,025 (am Zufallsweg kalibriert, rund 5 % Fehlurteile). Bei vielen Tests ist etwa jeder
  zwanzigste zufällig belegt; die Seite nennt die Erwartung daneben.
- **Prognose „Rückkehr zum Median“:** Wert in 3/6/12 Monaten mit 80-%-Band aus den eigenen Prognosefehlern der letzten 4 Jahre,
  Halbwertszeit der Rückkehr, Abdeckung des Bands im Rückblick (Soll 80 %) und Fehler gegen „die Abweichung bleibt“.
- **Live gegen Nachrechnung:** Der Tagesstand wird einmal am Tag festgeschrieben (`mk_signal`). Unter der Signaltabelle steht, ob
  die archivierten Live-Werte mit der Nachrechnung übereinstimmen. Weicht etwas ab, hat eine Quelle alte Werte geändert, und die
  Bilanz zeigt nicht genau, was live zu sehen war.
- **Ergebnis auf echten Daten (bis 23.05.2026):** 3 von 322 Bilanz-Tests belegt, der Zufall allein ließe etwa 16 erwarten. Die
  Zonen beschreiben eine Lage, sie sagen keine Rendite voraus. Verkaufssignale kamen zu früh (Momentum). Kein Anlagerat.

**Bewusst nicht gezeigt:**
- Ampeln und feste Schwellen aus 2013–2021 (MVRV 3,7, NUPL 0,75, Puell 4, Pi Cycle …). Sie haben 2025/26 oben und unten versagt.
  Die Signale seit 23.49 sind relativ zum gewählten Zeitraum, mit Bilanz.
- Ein Gesamtwert aus mehreren Perzentilen oder Signalen. Er wäre ungetestet.

**Daten und Betrieb**
- **Speicher:** Eigene Datei `makro.db` neben `hl_liq.db`; die Hauptdatenbank wird nur gelesen, für den Live-Kurs. Die
  Testdatenbank mit allen Quellen hat 178.508 Zeilen und 7,8 MB. Danach kommen rund 50 Zeilen am Tag dazu.
- **Sicherung:** Der Recorder sichert `makro.db` mit dem täglichen Backup als `makro_backup.db`.
- **Takt im Dashboard:**
  - Er beginnt 90 s nach dem Start. Der erste Lauf holt jede Quelle mit ganzer Historie (wenige Minuten).
  - Danach läuft nur das jüngste Stück mit Überlappung, je Quelle alle 6–12 h.
  - BGeometrics holt einen Endpunkt alle 8 min, höchstens 7 je Stunde und 14 am Tag (frei sind 8 und 15).
  - Das Binance-Archiv für Open Interest seit 09/2020 lädt eine Tagesdatei je 20 s, rückwärts mit den jüngsten Tagen zuerst
    (seit 23.50): das letzte Jahr nach rund 2 h, alles nach rund 12 h. Bis dahin steht unter dem OI-Chart der Ladestand, und die
    Zonenkarte zeigt für Open Interest kein Perzentil.
  - Fehler einer Quelle halten die anderen nicht an: 15 min Pause, verdoppelt bis 6 h. Antwortet ein Host nicht, werden die
    übrigen Ziele dieser Quelle in der Runde übersprungen (seit 23.48).
- **Archiv:** Einmal am Tag wird der Stand der Zonenkarte festgeschrieben (`mk_stand`), ebenso die Power-Law-Parameter je Monat
  (`mk_pl`) und seit 23.49 der Tagesstand der Signale (`mk_signal`, rund 63 Zeilen am Tag). Das ist die eigene, revisionsfreie Bilanz.
- **Signale rechnen:** einmal je Datentag (in der Sandbox 4 s, auf dem Pi geschätzt 10–15 s), danach aus dem Zwischenspeicher.
- **Debug-Einträge:**
  - „★ Makro: Stand und Quellen“: Quellen, Frische je Reihe, Budget, Archiv, Zonenkarte und Exponent; seit 23.49 je Paar und
    Zeitraum Lage, Live-Signal, Belegtes, Prognose 12 Monate mit Band und die Zeile „Live gegen Nachrechnung“. Seit 23.56 eine
    Summenzeile: belegt N von M Tests, wie viele der Zufall allein liefert (3–5 % Fehlurteile je Test), und wie viele
    Live-Signale eine belegte Bilanz ihrer eigenen Seite haben.
  - „Makro: jetzt abrufen“: alle Quellen sofort.
  - „Makro: Selbsttest“: 56 Prüfungen, rund 10 s; auch Installationsschritt.
  - „Makro: Selbsttest der Signale (U126)“: 12 Prüfungen, rund 3 s; auch Installationsschritt.
  - „★ Makro × Kurs (U130, Teil A)“ (seit 23.52): 15 Makro-Merkmale gegen die BTC-Rendite der folgenden 1, 7 und 30 Tage -- wie stark
    ist die Wechselwirkung? Je Test ρ, ρ² (Anteil der erklärten Streuung), p gegen Phasen-Surrogate, beide Hälften (bis 2021 / ab
    2022); belegt nur mit Korrektur für viele Tests UND gleichem Vorzeichen in beiden Hälften. Vorab festgelegt in
    `KONZEPT_Makro.md` Abschnitt 10. Selbsttest dazu: 9 Prüfungen, rund 15 s; auch Installationsschritt. Seit 23.56 gelten
    DVOL und ETF-Fluss in der Nachrechnung gegen `mk_stand` als vorläufig, wenn sie am offenen Tag festgeschrieben wurden
    (Tageskerze läuft, Flüsse des Tags noch nicht veröffentlicht) -- kein Widerspruch. Seit 23.85 (U229) schlüsselt der Bericht die
    SSR-Nachrechnung nach Ursache auf; nur der nachweislich offene Tag der Stablecoin-Summe zählt als vorläufig (`KONZEPT_Makro.md` 10.8).
  - „★ Makro-Regime × 4-h-Prognosen (U130, Teil B)“ (Debug Nr. 127, seit 23.85; `python3 hl_makro_korr.py --teil-b --db …`): Hängt
    die Güte der 4-h-Prognosen (v1, v2, Fusion) vom Makro-Regime ab? Neun Teilungen (Funding, OI, DVOL, Fear & Greed, Kurs unter der
    Kurzfrist-Kostenbasis, MVRV), Regime am Tag t aus Werten von t − 2 (Kostenbasis t − 9); Maß: Brier-Vorsprung gegen die Basisrate
    im Regime minus außerhalb; Hauptfamilie: die Krypto-Coins zusammen (27 Tests), je Coin nur beschreibend. Belegt nur mit Placebo-p
    < 0,025 (Kalender um ganze Wochen verschoben), Benjamini-Hochberg und beiden Hälften -- **genau ein Urteil am 15.01.2027**, vorher
    beschreibend. Vorab festgelegt in `KONZEPT_Makro.md` 10.7, 10.7a (nach unabhängiger Durchsicht) und 10.7b (Kalibrierung). Liest nur.
  - „Makro-Regime: Prüfung auf den echten Kalendern“ (Debug Nr. 128): künstliche Prognosen über die echten Regime-Kalender, Fehlurteile
    je Test und je Welt (einige Minuten); besteht sie nicht, gilt für das Urteil Bonferroni (10.7b). Selbsttest von Teil A und B:
    „Makro × Kurs: Selbsttest“ (Nr. 57, 21 Prüfungen, rund 15 s; auch Installationsschritt).
- **Berichtsplan:**
  - Einmalig am 06.10. um 20:15 (`u121-makro-erstlauf`, Stand und Selbsttest nach dem ersten Tag).
  - Einmalig am 06.10. um 20:30 und am 25.10. um 20:15 (`u130-makro-korr`, `u130-makro-korr-2510`: Makro × Kurs). Urteil Teil A
    am 25.10.: 0 von 45 belegt (`KONZEPT_Makro.md` 10.6). Teil B (seit 23.85): 27.10. 10:00 erster Lauf mit Teil A (U229),
    01.11. 10:00 Prüfung auf echten Kalendern, 25.11. und 23.12. 20:15 Zwischenblicke, 15.01.2027 20:15 Urteil.
  - Einmalig am 08.10. um 20:15 (`u126-makro-signale`: Rechenzeit, Signale, Nachrechnung) und am 05.11. um 20:15
    (`u127-makro-nachrechnung`: Live gegen Nachrechnung nach einem Monat).
  - Danach wöchentlich in der Wochenprüfung.
- **Abschalten:** Umgebungsvariable `HL_MAKRO=0` in der Dashboard-Unit.
- **Lizenzen:**
  - Coin Metrics CC BY-NC 4.0 (Namensnennung, nicht kommerziell).
  - alternative.me verlangt die Quellenangabe am Chart.
  - ICE-Daten (Hochzinsspread) nicht weitergeben.
  - Farside und BGeometrics nur privat.

## Regime-Modul (Konzept seit 07.10.2026, Phase 0 seit 23.59, erster Lauf 08.10.)

Konzept `KONZEPT_Regime.md` (U138), Recherche `RECHERCHE_Regime_07-10-2026.md`. Ziel: die jüngsten 4–8 Wochen lesen und daraus
die nächsten Schritte als Verteilung ableiten -- wie groß und wann (Schwankungsprofil, Spannweite über 1–7 Tage,
Berührwahrscheinlichkeiten), in welchem Zustand (Regime, laufendes Bein, Rücksetzer-Zone) und was die Teilnehmer an den
Wendepunkten tun.
- **Grundregel:** Die Historie (drei Jahre 30-min-Kerzen) schätzt Profile und Parameter; das 4–8-Wochen-Fenster liefert nur den
  Zustand.
- **Jede Anzeige steht neben ihrer Zufallsbaseline.** Stufen von 2–3 Tagen und höhere Hochs nach höheren Tiefs in zwei von drei
  Fällen liefert schon ein Zufallsweg; ein Fenster wie „fällt immer zwischen 2 und 5 Uhr“ findet man in 4–8 Wochen fast immer
  irgendwo.

**Phase 0 (seit 23.59): Vorprüfung auf der Historie.** Debug-Eintrag „★ Regime: Vorprüfung auf der Historie (U138, Phase 0)“,
geplant einmal am 08.10. um 21:00 (`u138-vorpruefung`; bitte hochladen), jederzeit auch von Hand.
- **Daten:** 30-min-Kerzen der USDT-Perpetuals, bis drei Jahre je Coin, in einer eigenen Datei `regime.db` neben der
  Hauptdatenbank. Quelle je Coin ist die mit der längeren Historie (Binance-Futures, sonst Bybit), festgehalten beim ersten Laden.
  `klines30` in `hl_liq.db` bleibt unberührt -- die Analog-Suche der Prognose liest sie.
- **Dauer:** Der erste Lauf lädt rund 3 Jahre je Coin (einige Minuten, höchstens 7 min, sonst lädt der nächste Lauf weiter);
  danach nur Neues. Das Rechnen dauert auf dem Pi geschätzt 4–8 min (Sandbox: rund 2 min für sechs Coins), mit niedriger
  Priorität neben den Diensten. Speicher unter 200 MB.
- **Inhalt:** Prüfstand je Coin (belegt / nicht belegt), danach je Prüfung die Zahlen mit Vergleichsgröße:
  - P0.1 Zwei-Uhren-Profil der Schwankung und ob der US-Buckel New York oder UTC folgt;
  - P0.2 Bewegungsgröße (HAR gegen EWMA und die 7-Tage-Schwankung des heutigen Bands, 80-%-Band, Berührquoten, Spannweite);
  - P0.3 Beine gegen 100 Vorzeichen-Surrogate (Überschießen, Dauer, höhere Tiefs und Hochs, Rücksetzer, Asymmetrie) und die
    Stufen in Prozent und Tagen;
  - P0.4 „Ist das laufende Extremum schon endgültig?“ gegen D/θ;
  - P0.5 Kalender K1 (02–05 Uhr Berlin), K2 (Samstagnacht), K3 (US-Kernsitzung gegen den Rest, seit 23.60 je Stunde verglichen,
    damit die Drift nicht mitzählt), 24 Stunden, 7 Wochentage, Persistenz;
  - P0.6 Wochenmomentum BTC/ETH (Brier, Deflated Sharpe, PBO);
  - P0.7 Fenster 2/4/8 Wochen gegen Fixed Share;
  - P0.8 Regime-Analog gegen die bestehende Analog-Suche und den Zufallsweg (CRPS);
  - P0.9 Bruchmelder (CUSUM) mit Fehlalarmen und Verzögerung.
- **Lesart:** „Belegt“ heißt nur, dass die vorab festgelegte Bedingung (`KONZEPT_Regime.md` 9.1a) erfüllt ist. Belegtes wird
  Kandidat für Phase 1 (Schatten); nichts davon wirkt auf Prognose, Fusion, v3, Kaskaden, Labor oder Familien.
- **Weitere Einträge:** „Regime: Historie laden bzw. ergänzen“ und „Regime: Selbsttest“ (ohne Netz, rund 1 min; auch
  Installationsschritt).

**Ergebnis des ersten Laufs (08.10. 02:06, Einzelheiten `KONZEPT_Regime.md` 9.4):**
- **Belegt:** nur Kalendereffekte bei XMR (02–05 Uhr Berlin steigend, US-Sitzung schwächer, Stundenmuster beständig) und bei PAXG
  (US-Sitzung, noch mit dem rohen K3), dazu die Fensterkombination bei ZEC und XMR.
- **Nicht vorhersagbar ist die Richtung:** Die Beine sind Zufallsgeometrie, und es gibt weder Momentum noch Analoge, die besser
  sind als der Zufallsweg.
- **Tragfähig ist die Größe:** HAR für den nächsten Tag; ein glattes Tagesprofil der Schwankung statt des heutigen Zellenprofils.
- **K3 seit 23.60 je Stunde:** Bis 23.59 maß K3 die Drift mit (eigener Fehler, U139). Der Bericht zeigt daneben das rohe K3 und das,
  was die Drift allein ergäbe.

**Zweiter Lauf (08.10. 21:00, Einzelheiten `KONZEPT_Regime.md` 9.5):** K3 je Stunde nur bei XMR belegt (−45 bp je Sitzung); bei
PAXG war es die Drift. Sonst wie im ersten Lauf. Einzelne Urteile über die Beine kippen schon mit einem Tag mehr Daten und zählen
deshalb nicht.

## Swing-Trades (seit 23.61)

Konzept `KONZEPT_Swing.md` (U140). Positionen über Tage: Entscheidung einmal am Tag nach dem Tagesschluss 00:00 UTC, Haltedauer
1–30 Tage, Stop und Größe aus der Tagesschwankung σ_Tag. Alle Regeln und das Urteil standen fest, bevor eine echte Kerze gerechnet
wurde; nichts ist an die Historie angepasst.

**Vier Strategien und zwei Kontrollen** (Gruppe „Swing“ im TradeLabor, je Strategie und Coin höchstens eine Position):
- **Trend-Ausbruch:** Schluss über dem 20-Tage-Hoch (Short: unter dem Tief); Stop 2 σ, Nachzieh-Stop 3 σ vom besten Schluss,
  Ausstieg unter dem 10-Tage-Tief, höchstens 30 Tage. Die am breitesten belegte Swing-Regel; lebt von wenigen großen Trends.
- **Rücksetzer im Trend:** im Aufwärtstrend (20-Tage-Mittel über dem 50-Tage-Mittel, Schluss darüber) nach einem Rücksetzer
  von mindestens 2 σ unter das 10-Tage-Hoch; Ziel zurück zum Hoch (mindestens 1,5 σ), Stop 2 σ, höchstens 10 Tage.
- **Ausbruch nach Ruhe:** Schwankung der letzten 10 Tage im untersten Fünftel des Jahres, dann Schluss außerhalb des
  10-Tage-Bereichs; Stop 1,5 σ, Nachzieh-Stop 3 σ, höchstens 20 Tage.
- **Gegenbewegung nach Übertreibung:** 3-Tage-Bewegung über 2,5 σ·√3, und das Funding zeigt die Masse auf der Seite der
  Bewegung (nach einem Absturz mindestens 1 Standardabweichung unter dem Mittel der 30 Tage davor); Einstieg dagegen, Ziel halber
  Rücklauf (mindestens 1 σ), Stop 2 σ, höchstens 5 Tage.
- **Kontrollen:** Zufall (10 % je Tag, Ausstiege wie Trend-Ausbruch) und Zufall im Trend (Ausstiege wie Rücksetzer). Was die
  Strategie mehr verdient als ihre Kontrolle, ist der Wert ihres Zeitpunkts.

**Größe:** Bis 23.67 riskierte jede Position 100 USD bis zum Stop (Notional = 100 USD ÷ Stop-Abstand, höchstens 10.000 USD).
**Seit 23.68 (U164, Entscheidung des Nutzers 13.10.)** handeln alle Swing- und Zyklus-Strategien im Labor mit fester Größe 10.000 USD
wie die übrigen; neue Kennungen, die alten sind abgelöst (offene Positionen beim Wechsel zum Marktpreis geschlossen, „Regelversion
abgelöst“). Stop, Ziel und Ausstiege bleiben, die Studie bleibt bitgleich. Ergebnisse zählen weiter in R (netto ÷ (10.000 ×
Stop-Abstand)), das von der Größe nicht abhängt; der Labor-Bericht hat dafür einen Abschnitt „Swing (U140)“. Für echtes Geld bliebe
die Größe nach Risiko die Empfehlung.

**Daten:** eigene Datei `swing.db` neben der Hauptdatenbank (30-min-Kerzen und Funding von Binance-Futures ab 2020). Der
Swing-Takt im Dashboard-Dienst prüft alle 5 min, ob die letzte fertige Kerze fehlt, und lädt nach (je Runde höchstens 4 min;
das erste Laden der Historie dauert so einige Runden). Abschalten mit `HL_SWING=0`. Das Labor liest die Datei nur. Ohne frische
Tageskerze keine neuen Einstiege („veraltet“ in der Live-Tafel); Stops laufen weiter auf den Hyperliquid-Minutenkerzen.

**Vorprüfung auf der Historie:** Debug-Eintrag „★ Swing: Vorprüfung auf der Historie (U140)“, geplant 08.10. 21:30 und 09.10.
07:30 (jeweils erst „Swing: Historie laden“, dann die Vorprüfung; bitte hochladen), jederzeit auch von Hand.
- Jede Strategie mit genau den Labor-Regeln auf allen Coins, mit Gebühren, Abstand zur Mitte und Funding.
- **Belegt** heißt: ≥ 60 Trades, Tagesergebnis im Mittel positiv mit p < 0,05, Mehrertrag gegen ein Zeitpunkt-Placebo (gleiche
  Ausstiege, zufällige Tage) nach Holm über die vier p < 0,05, beide Hälften positiv, Deflated Sharpe ≥ 0,95.
- Dazu je Strategie Treffer, Profitfaktor, Haltedauer, Rückgang, Zerlegung je Trade (Kurs, Abstand, Gebühren, Funding), je
  Coin und je Jahr.
- Rechenzeit auf dem Pi geschätzt 2–3 min.
- **Lesart:** Ein Sharpe um 0,5 ist auf sechs Jahren nicht nachweisbar; „nicht belegt“ heißt nicht „wirkungslos“. Belegtes wird
  Kandidat für mehr Gewicht im Labor-Vergleich. Echtes Geld nur nach belegter Historie und mindestens 6 Monaten Labor ohne
  Widerspruch, nie automatisch.

**Weitere Einträge:** „Swing: Historie laden bzw. ergänzen“ und „Swing: Selbsttest“ (ohne Netz, unter 1 min; auch
Installationsschritt).

**Ergebnis des ersten Laufs (08.10. 21:30, Einzelheiten `KONZEPT_Swing.md` 6b):** nichts belegt.
- Ausbruch nach Ruhe: im Mittel +0,34 R je Trade (Sharpe 0,72), in allen Coins und jedem Jahr positiv, aber p 0,10.
- Trend-Ausbruch: +0,17 R (Sharpe 0,49); trägt bei BTC und ETH, nicht bei ZEC und XMR.
- Rücksetzer im Trend: +0,04 R, kaum mehr als zufällige Einstiege an Trendtagen.
- Gegenbewegung nach Übertreibung: −0,20 R; die Gegenbewegung kam nicht.
- Alle sechs Strategien laufen im Labor weiter. Echtes Geld ist damit nicht begründet.

## Zyklen: Rallyes, Rücksetzer, Warnsignale und „Dip halten“ (seit 23.62)

Konzept `KONZEPT_Zyklen.md` (U141). Anlass: die Frage des Nutzers vom 08.10. — „Dump bestätigt → kaufen, laufen lassen, vor dem
nächsten Rücksetzer raus; wie lange dauert der Zyklus, nach wie vielen Prozent kommt der Rücksetzer, welche Signale kündigen ihn
an, was ist die sicherste Strategie?“. Alle Regeln und Urteile standen fest, bevor ein echter Kurs gerechnet wurde.

**Die Studie** (Debug „★ Zyklen: Rallyes, Rücksetzer, Warnsignale (U141)“, `python3 hl_zyklus.py --studie --db <hl_liq.db>`,
einige Minuten; nur lesend) rechnet auf den langen Tagesschlüssen von Coin Metrics in `makro.db` (BTC ab 2013, ETH und XMR ab
2016, ZEC ab 2017); HYPE (aus `swing.db`, ab 05/2025) und Gold/PAXG (aus `regime.db`, rund 3 Jahre) nur beschreibend.
- **Aktueller Stand je Coin** (oben im Bericht): Abstand zum 90-Tage-Hoch und zum Höchststand, das laufende Bein bei 10/20/30 %
  (seit wann, wie weit, ab welchem Kurs die Gegenrichtung bestätigt wäre), ob „Dip halten“ heute ein Signal hätte, die
  Warnsignale heute. Nur Lage, keine Empfehlung.
- **Teil A Zyklen:** Rallye = Tief bis Hoch, bestätigt nach X % Anstieg; Rücksetzer = Hoch bis Tief, bestätigt nach X % Fall
  (X = 10/20/30 %, Gold 3/5/10 %). Je Coin Zahl und Größe der Rallyes (Median, Quartile), Dauer, Rücksetzer, Zyklus Tief→Tief,
  der Weg ab der Bestätigung und die Runde „bestätigt kaufen, bestätigt verkaufen“ — jeweils gegen 1000 Zufallswege, die Drift
  und Schwankung der echten Kurse behalten. **Urteil** je Schwelle: sind die Rallyes länger oder kürzer als Zufall (gepoolt über
  die vier Coins, Holm über 3, beide Hälften)?
- **Teil B Strategien** (nur Long, Tagesschluss, Kosten 0,10 % je Seite bei BTC/ETH, sonst 0,20 %): HODL, T200 (über dem
  200-Tage-Mittel), VOL (Anteil nach Schwankung), **Z1 Dip halten** (Dump ≥ 5 σ_Tag vom 20-Tage-Hoch, bestätigt durch 1 σ Erholung
  bei noch 1 σ Abstand zum Hoch; Stop 1 σ unter dem Tief, Nachzieh-Stop 3 σ, höchstens 60 Tage), Z2 (dazu raus bei RSI ≥ 80 oder
  Funding-Druck ≥ 2), Z3 (dazu raus bei der typischen Rallye), Z0 (Zufall mit den Ausstiegen von Z1). Urteile: **Timing** (Z1–Z3
  besser als auf den Zufallswegen) und **sicherer als HODL** (Sharpe im Kern-Portfolio BTC+ETH, Blockbootstrap, Holm über 5,
  beide Hälften); dazu CAGR, größter Rückgang, Calmar, Anteil im Markt, Trades je Jahr, schlechtestes Jahr.
- **Teil C Warnsignale:** OI-Überhitzung (wie im Dashboard), Funding-Druck, RSI ≥ 80, Fear & Greed ≥ 80 gegen einen Rücksetzer
  von mindestens 1,5 σ·√14 in den nächsten 14 Tagen; Risikoverhältnis mit Intervall, Null aus den Zufallswegen (zählt nur
  Richtung, nicht bloß mehr Schwankung). „Crowding“ hat keine lange Historie und läuft vorwärts im Labor.
- **Teil D Gegenprobe:** Z1 und Z2 mit echter Ausführung (Binance-30-min-Kerzen ab 2020, Kosten, Funding; beschreibend).
- **Ehrliche Erwartung:** Auf einem Zufallsweg ist eine Rallye nach der Bestätigung im Mittel noch einmal so lang wie die
  Bestätigungsschwelle (exponentiell verteilt) — dann gibt es kein festes Prozentziel, das sicher vor dem Rücksetzer liegt, und
  „bestätigt kaufen, bestätigt verkaufen“ bringt vor Kosten nur die Drift. Die Studie misst, ob die echten Kurse davon abweichen.
- Berichtsplan: einmalig am 09.10. um 12:00 (`u141-zyklen`; verpasst wird bis 12 h nachgeholt) und am 10.10. um 07:45
  (`u141-zyklen-2`, nur falls der erste fehlte). Selbsttest „Zyklen: Selbsttest“ (ohne Netz, unter 1 min; auch Installationsschritt).

**Im TradeLabor** (Gruppe „Swing“, eigene Kennungen; die 44 bestehenden unverändert): „Zyklus: Dip halten (Z1)“, „Zyklus: Dip
halten, raus bei Überhitzung (Z2)“ und die Kontrolle „Zyklus: Zufall long“ (3 % je Tag, Ausstiege wie Z1). Entscheidung nach dem
Tagesschluss aus `swing.db` wie die übrigen Swing-Strategien, seit 23.68 mit fester Größe 10.000 USD (U164, neue Kennungen; bis
23.67 100 USD Risiko bis zum Stop); im Mittel nur wenige Trades je
Coin und Monat. Dieselben Regeln wie in der Studie (`hl_swing`, Art „dip“; Tag für Tag gleich geprüft).

## Hebel: Positionierung und Perp-Anteil vor Liquidationswellen (seit 23.63)

Konzept `KONZEPT_Hebel.md` (U142). Anlass: die Fragen des Nutzers vom 09.10. — Top-Trader-Daten von Binance, Market Maker und
„wenn es Leverage bei 95 % gegenüber 5 % Spot ist, wird fast immer eine Liquidierung durchgeführt“ (Bewertung in UEBERGABE 3νν und
`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md`). Alle Regeln und Urteile standen fest, bevor eine echte Zahl gerechnet wurde.

**Daten** (eigene Datei `hebel.db` neben der Hauptdatenbank; `hl_liq.db` wird nur gelesen):
- Binance-Archiv data.binance.vision: Tagesdateien „metrics“ (OI in Coins und USD, Top-Trader nach Konten und nach Positionen, alle
  Konten, Taker) für BTC, ETH, ZEC, XMR, HYPE ab 01.09.2020 — eine Zeile je Stunde; Tageskerzen der USDⓈ-M-, COIN-M- und
  Spot-Märkte ab 2020 (BTC/ETH: Perps USDT/USDC/BUSD und USD_PERP, Spot USDT/FDUSD/USDC/BUSD/TUSD; die übrigen Coins nur der Kurs).
- **Hebel-Takt** im Dashboard-Prozess: alle 5 min höchstens 4 min laden, 0,35 s Pause je Datei; erste Füllung rund 2–3 h, danach
  stündlich die neuen Tage. Aus mit `HL_HEBEL=0`. Debug „Hebel: Historie laden“ lädt bis 10 min im Vordergrund.
- **Sicherung:** stündlich die Liquidationen von Bybit/OKX (`ext_liquidations`, Vorhaltefrist 90 Tage) und die Binance-Buchtiefe
  ohne Wände (`bnc_book`, 60 Tage) nach `hebel.db` — dort bleiben sie.

**Die Studie** (Debug „★ Hebel: Positionierung und Hebel gegen Spot (U142)“, `python3 hl_hebel.py --studie --db <hl_liq.db>`,
einige Minuten), vier Hauptprüfungen (Holm über die prüfbaren, beide Hälften):
- **H1** „Konten ≥ 3“ (Hinweis „Kaskadenrisiko nach unten“ im Dashboard) kündigt einen Rücksetzer in 7 Tagen an — gegen 1000
  Vorzeichen-Surrogate (zählt nur Richtung).
- **H2** Die Top-Trader-Regel der Konfluenz (Positionsverhältnis ≥ 1,5 Kauf, ≤ 0,67 Verkauf) und die Richtung des nächsten Tages —
  zweiseitig (folgen oder dagegen).
- **H3** Perp-Anteil am Binance-Volumen ≥ 95 % (die Regel des Nutzers, wie formuliert) und **H4** Perp-Anteil im obersten Zehntel
  der eigenen 90 Tage kündigen eine **Liquidationswelle** in 7 Tagen an: das stündliche OI (in Coins) fällt um mindestens
  1,5 × seiner Schwankung × √7, und der Kurs schlägt um mindestens 1,5 σ × √7 aus (Hoch oder Tief). Null: Zeitverschiebung des
  Signals um 30–365 Tage (behält jede Ballung, löst nur „Signal vor Welle“).
- Beschreibend: Perzentil-Varianten aller Verhältnisse, andere Horizonte, Richtung der Wellen gegen die überfüllte Seite, je Jahr,
  Perp-Anteil je Jahr mit den Spotpaaren, OI ÷ Spotvolumen, **Abgleich Archiv gegen die Live-Reihe** (`bnc_metrics`; prüft die
  Zuordnung der Archivspalten und meldet Zeilen mit Millisekunden-Zeitstempel), gesicherte Liquidationen; oben der Stand heute.
- **Urteil nur bei vollständig geladener Historie**, sonst „vorläufig“. Nachweisgrenze (synthetisch kalibriert): ein RR um 2 wird
  etwa jedes zweite Mal belegt; ein RR um 1,2–1,5 ist mit sechs Jahren und zwei Coins nicht nachweisbar.
- Berichtsplan: 10.10. 08:15 (`u142-hebel`, lädt vorher bis 10 min nach) und 11.10. 08:15 (`u142-hebel-2`). Selbsttest „Hebel:
  Selbsttest“ (ohne Netz, unter 1 min; auch Installationsschritt). Die Konfluenz bleibt bis zum Urteil unverändert.

**Erster Lauf (10.10. 08:16) und 23.64** (`KONZEPT_Hebel.md` 12.3 und 13): H1 erfüllt die Bedingung (RR 2,77; 20,3 % gegen 7,4 %),
H2 nicht (die Top-Trader-Regel steht fast immer auf „Kauf“), H3/H4 blieben ohne Daten — ein Ladefehler: Kerzendateien wurden ohne
Markt gemerkt, die Spotpaare BTC/ETH gegen USDT, USDC und BUSD galten neben dem gleichnamigen Perp als geladen. Seit 23.64 stehen sie
unter „markt:symbol“; `hebel.db` wird beim ersten Öffnen einmalig umgestellt, danach lädt der Takt die Spotpaare nach (10–20 min).
Der Ladestand prüft jetzt die gemerkten Dateien gegen die Zeilen („Widerspruch“ = nicht vollständig). Beschreibend und eigens
gekennzeichnet („Nachträglich ergänzt“): H1 mit dem Konten-Stand 1 h und 24 h früher und H1 geschichtet nach der Rendite der 7 Tage
davor — die Vorzeichen-Surrogate sind blind für Momentum; erst die Schichtung zeigt, ob der Konten-Stand mehr sagt als die Vorwoche.
Endgültig: Lauf 11.10. 08:15.

**Endgültiges Ergebnis (Lauf 11.10. 08:16, `KONZEPT_Hebel.md` 13.5):** H1 **belegt** -- nach „Konten ≥ 3“ folgte in 7 Tagen ein
Rücksetzer (ein Schlusskurs in den 7 Tagen danach mindestens 1,5 Wochenschwankungen unter dem Schluss des Signaltags) in 20,3 % der Fälle gegen 7,3 % an anderen Tagen
(RR 2,77); das hält auch, wenn man nur Tage mit gleich verlaufener Vorwoche vergleicht (RR 2,52). In 4 von 5 Fällen kam **kein**
solcher Rücksetzer: ein Risikohinweis, keine Vorhersage. H2 (Top-Trader-Regel der Konfluenz → Richtung) **nicht belegt**. H3 **nicht
prüfbar**: Der Perp-Anteil am Binance-Volumen lag bei BTC und ETH seit 2020 an keinem Tag bei 95 % (90-%-Quantil eines Jahres
höchstens 91,0 % bzw. 93,8 %). H4 **nicht belegt**: Nach einem Perp-Anteil im obersten Zehntel kamen Liquidationswellen eher seltener
(2,9 % gegen 5,5 %). **Entschieden am 11.10. 23:30:** Der Hinweis „Kaskadenrisiko nach unten“ bekommt die gemessenen Quoten, der
Top-Trader-Punkt fällt aus der Konfluenz -- **umgesetzt mit 23.67 (U151)**, siehe „Konfluenz im Chart“. Welche Kennzahl die 95 %
meinten, klärte U152 mit einer Liste gängiger Kennzahlen (`RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md`). **Entschieden am
13.10.:** gemeint ist CryptoQuants Bitcoin-Messung über alle Börsen („9 von 10 Trades sind Futures“). Ab 23.68 sammelt der Pi sie
kostenlos mit einem eigenen Schlüssel des Nutzers; geprüft wird die Regel wie formuliert als U158 (`KONZEPT_Hebel.md` 14), sobald
genug Tage mit 95 % da sind.

**CryptoQuant-Anteil der Derivate und S5 (seit 23.68, U158, `KONZEPT_Hebel.md` 14):**
- **Kennzahl:** D = Perps ÷ (Perps + Spot) über alle Börsen, in BTC, je UTC-Tag, aus der CryptoQuant-API
  (`btc/market-data/price-ohlcv`, `all_exchange`). Grundlage ist der kostenlose Schlüssel des Nutzers (Stufe Basic: Tageswerte,
  30 Tage Rückschau).
- **Schlüssel:** im Makro-Abschnitt, Tab „Daten“, Feld „CryptoQuant-Schlüssel (kostenlos)“, Knopf „prüfen und speichern“; oder in
  `accesstokens.json` → `cryptoquant.api_key`. Der Schlüssel steht in keinem Fehlertext und keinem Bericht. **Nicht in den Chat
  schreiben.**
- **Abruf:** Der Hebel-Takt ruft einmal am Tag nach 01:00 UTC ab, je Markt die letzten 30 Tage. Ausfälle bis 30 Tage füllen sich so
  von selbst. Jede Zahl steht mit Abrufzeit in `hebel.db` (`hb_cq`); eine Korrektur ist eine neue Fassung.
- **Chart:** „Anteil der Perpetuals am BTC-Volumen, alle Börsen“ mit der 95-%-Linie im Tab „Hebel & Stimmung“.
- **S5:** D ≥ 95 % vor einer Liquidationswelle in 7 Tagen (wie H3). Null aus der zirkulären Verschiebung um 30 … L − 30 Tage;
  prüfbar ab 30 Signaltagen in 3 Episoden, 30 Tagen ohne Signal und 180 Tagen Reihe. Die erste prüfbare Auswertung ist das Urteil;
  sie wird festgehalten.
- **Nachweisgrenze** (Selbsttest): Bei dreifachem Risiko belegt die Prüfung mit 450 Tagen Reihe nur etwa jeden vierten Fall, mit
  drei Jahren drei von vier.
- **Debug:** „★ Hebel: CryptoQuant-Anteil der Derivate (U158)“ (auch im Wochenbericht) und „CryptoQuant jetzt abrufen“;
  Berichtsplan 19.10. 20:15 für den ersten echten Abruf. Wirkt auf nichts.

## Chartbild: die Lage je Coin in Worten (seit 23.65)

Konzept `KONZEPT_Chartbild.md` (U143 Stufe 1). Anlass: der Wunsch vom 09.10. nach einer Chartanalyse wie bei TradingView, gestützt
durch alle gesammelten Daten, und die Frage vom 10.10. „Wo finde ich die Chart Analysen“. Stufe 1 ist die **Anzeige**: Sie beschreibt
die Lage, sie handelt nicht und gibt kein Signal -- die Studien U141, U142 und U110 haben für keinen der Bausteine ein belegtes
Timing gezeigt, mit einer Ausnahme seit dem endgültigen U142-Lauf vom 11.10.: Konten ≥ 3 gingen häufiger einem Rücksetzer in
7 Tagen voraus (U142 H1; seit 23.66 nennt die Lesart diese Regel). Jede Zeile nennt ihren **Prüfstand** mit Datum.

**Seit 23.66 (`KONZEPT_Chartbild.md` 9.2):** Der Regime-Takt im Dashboard ergänzt die 30-min-Kerzen von PAXG in `regime.db` laufend
(alle 5 min nachgesehen) -- das PAXG-Band ist damit von selbst da. Das größte Liquidationscluster zählt erst ab einem halben
Stundenvolumen (ohne Stundenvolumen keins, mit Grund). Die Lesart nennt die belegte Kontenregel (U142 H1) und ob sie gerade erfüllt
ist; der Bein-Satz spricht von Schlüssen statt Hochs; gerundete Nullen stehen ohne Vorzeichen.

**Wo:** Abschnitt „CB Chartbild“ direkt nach dem Live-Chart (Navigation „Chartbild“), für den Coin aus dem Kopf der Seite (BTC, ETH,
HYPE, ZEC, XMR, PAXG). Die Seite fragt nur, solange der Abschnitt offen und sichtbar ist (alle 2 min, beim Coin-Wechsel sofort).
Als Text für alle Coins: Debug „★ Chartbild: Lage aller Coins als Text“ (`python3 hl_chartbild.py --text --db <hl_liq.db>`).

**Was:**
- **Lesart** in fünf bis sechs Sätzen: Trend (Abstand zur 200-Tage-Linie, Richtung der 50-Tage-Linie), Bein (Directional Change wie
  U141: ein Rücksetzer gilt ab 10 % unter dem Hoch als bestätigt, PAXG ab 3 %), nächste Niveaus darunter und darüber (Abstand in % und
  in Tages-σ), erwartete Spanne (80 %) für den nächsten Tagesschluss und in 7 Tagen mit der Trefferquote der letzten 365 Tage, Lage
  daneben (RSI, Funding-Druck, OI- und Konten-Perzentil, Fear & Greed), „Lagebeschreibung, kein Signal.“
- **Tageschart** (1/3/6/12/24 Monate; Ebenen Bein, Swings, Niveaus, Spanne einzeln schaltbar; Tabelle statt Bild): Kerzen hohl = Tag
  im Plus, gefüllt = Tag im Minus, 50-Tage-Linie blau, 200-Tage-Linie gelbbraun, Bein als Zickzack (pink, laufend gestrichelt),
  Swing-Hochs ▼ und -Tiefs ▲. Rechts der gestrichelten Linie „heute“: die Niveaus als Momentaufnahme (Orders und Liquidationscluster
  gibt es nur jetzt, deshalb reichen ihre Linien nicht in die Vergangenheit) mit Nummer wie in der Tabelle, und der Fächer der
  80-%-Spanne zu den Strichen „heute“ und „+7 T“. RSI 14 im eigenen Feld darunter.
- **Tabellen:** Niveaus (von oben nach unten, die Zeile „Kurs jetzt“ an ihrem Platz), Bein je Schwelle mit Größe und Dauer der
  abgeschlossenen Rallyes und Rücksetzer, Spanne, Lage daneben mit 90-Tage-Verlauf, Prüfstände, „Was fehlt“ (mit Grund) und
  „Bewusst nicht gezeigt“ (PAXG: kein Funding, keine Binance-Positionierung, kein Krypto-Stimmungsindex).

**Woher:** nur lesend aus `hl_liq.db` (abgeschlossene Tageskerzen `daily_bars`, 1-min-Kerzen, Orders der Großkonten, Heatmap,
`bnc_metrics`), `swing.db` (30-min-Kerzen und Funding), `regime.db` (PAXG), `hebel.db` (Tagesstände der Positionierung) und
`makro.db` (Fear & Greed). Dieselben Rechnungen wie die Studien und der Live-Chart. Jede Quelle hat eine Frischegrenze (Tageskerzen
3 Tage, Kurs 15 min, Orders 6 h, Heatmap 30 min, 30-min-Kerzen 2 Tage …); ist sie überschritten, fehlt der Baustein mit Grund, der
Rest erscheint trotzdem. Wirkt auf nichts: kein Treiber, keine Konfluenz, kein Labor, keine Prognose.

**Prüfung:** Selbsttest „Chartbild: Selbsttest“ (ohne Netz, rund 10 s; auch Installationsschritt) -- Bausteine von Hand, gleich der
Studien (Bein wie `hl_zyklus`, Band wie `hl_regime.har_prognosen`), Kausalität, Band-Kontrolle auf acht synthetischen Märkten, Lesart
ohne Empfehlungswörter, Frische, Ende zu Ende über das Dashboard. Stufe 2 (Halten Niveaus öfter als zufällige gleichen Abstands?)
und Stufe 3 (Chart-Trader im Labor) sind eigene Schritte mit Zustimmung.

## Ausblick 4 Wochen (seit 23.66)

Konzept `KONZEPT_Ausblick.md` (U146), vorab festgelegt am 11.10., ergänzt am selben Abend um Takt und Aktienmarkt (13), gebaut mit
23.66 (Nachtrag 12.1). Abschnitt „AU Ausblick“ nach dem Chartbild, für den Coin aus dem Kopf der Seite. Er zeigt eine Verteilung,
keine Vorhersage einer Richtung, und wirkt auf nichts sonst (keine Konfluenz, kein Labor, keine Prognose, kein Treiber).

**Bild:** Tageskerzen der letzten 3/6/12 Monate (bei weniger als 4 px je Tag die Schlusslinie), ab dem Anker der Fächer für 28 Tage:
Median, Bänder 50/80/90 % (gestaffelte Deckkraft), Striche der 80-%-Spanne bei +1/+2/+4 Wochen, gestrichelte Klammern für den
Stressfächer (das unruhigste Jahr seit 2020), seit 23.68 rechts daneben gepunktete Klammern für die Größe der Stressphase, Niveaus
des Chartbilds ab dem Anker mit Nummer und Preis. Fadenkreuz mit Quantilen je Tag.

**Größe der Stressphase (seit 23.68, U156, `KONZEPT_Ausblick.md` 13.14):**
- Ein Szenario, kein Modell für heute: die tatsächlichen Wege der eigenen Fenster des Coins aus der unruhigsten Phase seit 2020,
  ohne deren Trend, am heutigen Startpreis.
- Reiter „Spannen“: eigene Tabelle mit 80 und 90 % bei 7, 14 und 28 Tagen und „damals x-mal so breit wie heute“ (80 %, 28 Tage).
  Dazu eine eigene Textzeile.
- HYPE hat in der Phase keine eigene Geschichte und bekommt einen Hinweis; PAXG zeigt den Fächer nicht. Er wirkt auf nichts.
- **Eigener Fehler bis 23.67:** Die gestrichelte Klammer bei +4 Wochen lag außerhalb des Zeichenbereichs und war kaum zu sehen.
  Rechts der Marke bleiben jetzt 16 px frei.

**Reiter:** Spannen (1/2/4 Wochen), Ziellevels (je Niveau: Wahrscheinlichkeit, es bis +7/+14/+28 Tage zu erreichen, und am Ende
jenseits zu schließen), Gewichte (36 Datenquellen mit Gewicht, Spur, Beitrag, p nach Holm und Status „trägt“/„Hinweis“/„trägt
nicht“/„zu kurz“; das Tor je Horizont), Bilanz (Deckung und Trefferquoten vorwärts), Korrelationen, Aktienmarkt, Was fehlt.

**Szenario-Abfrage:** „Steht der S&P 500 in 1/2/4 Wochen um x % anders …“ -- bedingte Spanne des Coins aus den Fenstern der Bibliothek
mit ähnlichem S&P-Pfad (Kern mit lokal-linearer Korrektur, Grundlage in Episoden), unter 15 Episoden aus der t-Kopula; dazu die
Ereignisform „fällt um mindestens 10 % in 4 Wochen“. Die S&P-Koordinate ist trendbereinigt: reine Abhängigkeit, keine Richtung.

**Takt:** Neuberechnung alle 30 min, solange der Abschnitt offen ist; stündlich im Hintergrund; an jedem 6-h-Anker (00/06/12/18 UTC)
für die Vorwärtsbilanz; sofort bei einem Schock (30-min-Bewegung über 5 typische, 6-h-Schwankung über dem Vierfachen, S&P-500-Perp
in 6 h über 3 typische -- auch am Wochenende; danach 24 h „Ausnahmelage“; seit 23.69 (U179) mit Beginn und Ende, beim S&P-Perp
„bei Auslösung Börse geschlossen“ und „nur ein Hinweis“: die S&P-Bewegung geht in keine Spanne ein). Der Rückblick (Breite S1, Tor, Gewichte mit Nullläufen,
Ziellevels S3, gemeinsame Form S4) läuft in der ersten Nacht nach dem Einspielen (01–06 UTC) und danach sonntags ab 02:00 UTC, als
eigener Prozess mit nice 10; gleich danach rechnet die Prognose mit dem neuen Stand. Log: `ausblick_takt.log` neben `ausblick.db`.

**Debug:** „★ Ausblick 4 Wochen: Stand aller Coins als Text“, „Ausblick: Rückblick und Gewichte jetzt rechnen“, „Ausblick: jetzt
neu rechnen“, „Ausblick: Selbsttest“, seit 23.69 „★ Ausblick: Zählung der Regel (c) am S&P-500-Perp (U179)“ (je Fensterart
Varianzverhältnis Q und Anteil über der Schwelle, Auslösungen; beschreibend, Berichtsplan 20.10. 21:15). Berichtsplan: 12.10. 08:30 (nach der ersten Nacht; zweiter Termin 13.10.), danach sonntags
08:30.

**Aktienmarkt (Reiter und `hl_aktien.py`, U148):** beschreibend, nicht geprüft -- Barometer rund um die Uhr über `xyz` (S&P 500,
Nasdaq-100, VIX, die Top 10, MSTR, STRC, COIN), Gleichlauf BTC–S&P (Korrelation der Tagesrenditen über 60/120/260 Handelstage mit
90-%-Intervall, Beta nach unten und oben), die Tafel „BTC fiel
an x von n S&P-Verlusttagen“ (Studie U147), Stress (VIX-Laufzeitstruktur, Kreditspreads, STLFSI4, NFCI), ETF-Flüsse und
IBIT-Leerverkäufe, CME-Positionierung, Strategy-Bestände (SEC). Jeder Wert steht mit Abrufzeit in `aktien.db`; eine Revision ist
eine neue Fassung, die alte bleibt. Abruf nach Plan (FRED nach 18:15 New York, CFTC freitags nach 16:00, `xyz` alle 30 min …) mit
Schutzschalter je Quelle. Debug: „★ Aktienmarkt: Stand als Text“, „Aktien: alle Quellen jetzt abrufen“, „★ Studie U147“,
„Kurzstudie K1/K2“, „Aktien: Selbsttest“; Berichtsplan 12.10. 21:30 (zweiter Termin 13.10.). SEC-User-Agent
`hl_liq_project admin@localhost.com` (änderbar über `HL_SEC_UA` oder `accesstokens.json` → `sec.user_agent`).

**Prüfung:** Selbsttest „Ausblick: Selbsttest“ in 11 Gruppen (`python3 hl_ausblick.py --selbsttest --nur basis,pfad`; ohne `--nur`
alle, einige Minuten; auch Installationsschritt): Pfadstatistik von Hand, Breite auf Märkten mit Schwankungsballung, Null-Universen,
Positivkontrolle, Kopula und Ereignisform gegen die Wahrheit, HAR-X, Kausalität (auch des ganzen Laufs: Prognose aus einer bei τ
abgeschnittenen Datenbank = Prognose für τ), Schockregel, Takt, Ende zu Ende. Erwartung vorab: geprüfte Breite und Ziellevels,
Richtung sehr wahrscheinlich nicht belegt -- also ein driftfreier Fächer.

**Erster Rückblick (12.10. 01:00 UTC, `KONZEPT_Ausblick.md` 12.2):** Breite S1 besteht bei keinem Horizont (gegen den naiven
Vergleich gewinnt B0 nur bei 7 Tagen knapp; PAXG-Band zu eng, 57 % statt 80 %) -- angezeigt bleibt B0, weil B1 nicht signifikant
besser ist. Richtung: Tor überall zu, alle 36 Kandidaten „trägt nicht“. Ziellevels S3 bestehen. Die gemeinsame Form mit dem S&P 500
(S4) ist belegt, unter Aktienstress aber nicht kalibriert. **Seit 23.67** steht das am Fächer: die Deckung mit „zu eng/zu weit
(Soll 80 %)“, an den Szenarien „unter Aktienstress im Rückblick nicht kalibriert“, und der Stressfächer heißt „Form der unruhigsten
Phase seit 2020 … bei heutiger Schwankung“ mit 80 und 90 % (er übernimmt die Form jener Zeit, nicht ihre Größe; ab 23.68 kommt auf
Wunsch des Nutzers ein zweiter Fächer in der Größe jener Zeit dazu, als Szenario, `KONZEPT_Ausblick.md` 13.14). **Seit 23.69
(U178)** nennen beide den tatsächlichen Zeitraum ihrer Fenster und die Zahl von möglichen, etwa „Fenster mit Start 01.10.2020–
22.02.2021, 580 von 1.460 möglichen; März 2020 nicht enthalten“ (die Bibliothek beginnt auf dem Pi erst im Oktober 2020). Studie U147: „fällt
BTC immer, wenn der S&P 500 fällt?“ -- nicht bestätigt (seit 2020 an 64 % der Verlusttage, unter −1 % 77 %, unter −2 % 84 %;
4 Wochen unter −5 %: 9 von 9). K1/K2 nicht belegt.

**Strategy-Bestand seit 23.69 (U177):** Aus einem 8-K mit Tabelle zählt die größte Zahl der Spalte „Aggregate BTC Holdings“ ohne
„$“ (bis 23.68 die erste, oft die gekauften BTC: „zuletzt +846.001 BTC“ am 18.10.). Ein Bestand mehr als 30 % unter dem der Vorwoche
wird nicht übernommen und im Bericht genannt; schon falsch gespeicherte werden einmal neu gelesen; „zuletzt“ rechnet nur mit
plausiblen Beständen.

**Aktienmarkt seit 23.67:** Fehlertexte einzeilig (ein XML-Fehlerkörper wird auf seinen Code gekürzt); die Strategy-Aktienzahl kommt,
wo das Deckblatt sie nicht meldet, aus der Bilanz oder dem gewichteten Quartalsdurchschnitt, mit Angabe der Abgrenzung; ein auf `xyz`
eingestellter Markt (VIX) wird nicht mehr abgefragt und nicht gezeigt, sondern als „eingestellt“ genannt; die Quellenliste zeigt
Ortszeit; der Text hat die Abschnitte „KRYPTO-AKTIEN UND POSITIONIERUNG“ (ETF-Flüsse, CME, Leerverkäufe, Strategy) und „STRUKTUR“.
Berichtsplan sonntags 08:30: Ausblick, Aktienmarkt und Chartbild als Text.

## Datentage: Schwankung an US-Terminen (seit 23.67)

Studie U154, vorab festgelegt am 13.10. vor dem Bau (`KONZEPT_Makro.md` 11.7), Modul `hl_datentage.py`. Frage: Schwanken BTC und ETH
im Fenster 8:30–10:30 New York an Tagen mit US-Daten stärker als an Werktagen desselben Monats ohne Termin? Nur die Schwankung, nicht
die Richtung -- ohne die Erwartungen der Volkswirte gibt es keine Überraschungsgröße.

- **Urteil** für Verbraucherpreise (H1) und Arbeitsmarktbericht (H2): p nach Holm unter 0,05 (Null: jeder Termin auf einen zufälligen
  Vergleichstag desselben Monats verschoben, 10.000 Ziehungen) und Effekt in beiden Hälften. Faktor der Varianz mit 90-%-Intervall
  (Blockbootstrap über Monate), je Jahr.
- **Beschreibend:** Erzeugerpreise, Erstanträge, je Coin, ganzer UTC-Tag, mittlere absolute Fensterrendite; Gegenprobe der Termine
  gegen die Tage der Erstveröffentlichung (ALFRED).
- **Daten:** Termine aus `makro.db` (U153, ab 2020), Kurse aus `swing.db` (30-min-Kerzen der Binance-Perps). Schreibt nichts, wirkt
  auf nichts. Wenn belegt, entscheidet der Nutzer eigens über eine Nutzung (Ausblick oder U116); jede Nutzung muss außerhalb der
  Stichprobe gegen das bestehende HAR gewinnen.
- **Debug:** „★ Datentage: Schwankung an US-Terminen (U154)“, „Datentage: Selbsttest“; Berichtsplan 15.10. 21:45 (zweiter Termin
  16.10. 21:45). Der Makro-Stand mit den neuen Reihen läuft 15.10. 20:15.
- **Prüfung:** Selbsttest auf synthetischen Märkten mit Tagesprofil, Schwankungsballung und dicken Rändern: eingepflanzter Faktor 1,5
  in 40 von 40 Märkten belegt, ohne Effekt in 1 von 40; Nachweisgrenze Faktor 1,2 in 22, 1,3 in 33 von 40. Erwartung vorab: beide
  belegt (H1 Faktor 1,5–3, H2 1,3–2), seit 2024 kleiner.
- **Erster Lauf auf dem Pi (15.10. 21:45):** H1 und H2 belegt. Verbraucherpreise Faktor der Varianz 2,45 (90 %: 1,95–3,08),
  Arbeitsmarktbericht 1,90 (1,58–2,29), je p nach Holm 0,0002 und in beiden Hälften; über den ganzen Tag nur 1,19 bzw. 1,02;
  Erzeugerpreise und Erstanträge ohne Effekt. Die Erwartung „seit 2024 kleiner“ traf nicht zu. Die Gegenprobe fand 6 bzw. 3
  Kalendertage ohne Erstveröffentlichung (vermutlich Stillstand 2025; sie verkleinern den Faktor, das Urteil hält; U171 nennt die
  Tage). Entscheidung des Nutzers: ein Hinweis an Datentagen mit 23.68 (U172, nur Anzeige), die Termine als Zutat der Schwankung
  der nächsten Stunden erst nach dem 25.10. und nur, wenn sie vorwärts gegen das HAR gewinnen (U173); nicht im 4-Wochen-Ausblick.
  Einzelheiten `KONZEPT_Makro.md` 11.9.
- **Hinweis an Datentagen (seit 23.68, U172, nur Anzeige):**
  - Wann: an Tagen mit Verbraucherpreisen oder Arbeitsmarktbericht von 00:00 Ortszeit bis 10:30 New York, als Zeile über der
    KPI-Zeile.
  - Inhalt (Muster): „Heute 14:30: Verbraucherpreise der USA. In den zwei Stunden danach Kursausschläge im Mittel rund 1,7-mal so
    groß … über den ganzen Tag kaum größer. Keine Richtung.“
  - Die Zahlen stammen aus dem jüngsten Studienlauf (`mk_meta` „datentage:stand“; Studie wöchentlich sonntags 21:45). Ohne Stand
    oder ohne Urteil steht nur der Termin; dieselben Zahlen erscheinen bei den Terminen im Makro-Tab.
  - Erzeugerpreise und Erstanträge ohne Hinweis. Wirkt auf nichts.
- **Gegenprobe mit Tagen (seit 23.68, U171):** Der Bericht nennt die abweichenden Tage. Termine, die ALFRED noch nicht hat, stehen
  als „noch nicht in ALFRED (Abruf monatlich)“. Dazu beschreibend der Faktor nur mit Tagen, die beide Quellen kennen.

## Notbremse: marktweite Long-Sperre bei Schocks (seit 23.76)

Regeln vorab festgelegt in `KONZEPT_Notbremse.md` (Fassung 1, 23.10.2026; U206). Kurz: Fallen Krypto und Aktien **gemeinsam**
ungewöhnlich, oder bricht Krypto allein mit einer Liquidationswelle ein, sperrt die Notbremse neue und größere Longs -- **nur in Welt A**,
einer Kopie des TradeLabors. Das TradeLabor, wie es im Dashboard steht (Welt B), läuft unverändert weiter; der Unterschied A − B in USD
ist der gemessene Nutzen (oder Preis) der Bremse.

- **Dienst `hl-notbremse`** (`hl_notbremse.py --db …`, Log `notbremse.log`): jede Minute bei Sekunde 5 (UTC) die Mids beider Körbe
  (`allMids` je Dex, Gewicht 2: Haupt-Dex, `xyz`, `felix` für XMR), Maße, Stufe; eine Zeile in `nb_zustand` auch ohne Auslösung.
  Beim ersten Start holt er die Historie (15-min-Kerzen 60 Tage, 1-min-Kerzen 4 Tage, `candleSnapshot` mit eigenem Budget von im
  Mittel 40 Gewicht je Minute, rund zweieinhalb Stunden) und rechnet danach die erste Kalibrierung auf den Daten bis 20.10. 23:59 UTC.
  Bis dahin gelten die Startwerte (−2,5 / −4,0 / −5,0) und ohne σ ist X undefiniert („Kalibrierung läuft“). Neukalibrierung am 1. jedes
  Monats um 00:30 UTC. Der Dienst startet mit dem Dashboard (`Wants=` in dessen Unit), auch nach einem Update mit älterer `update.py`.
- **Stufen:** 1 = Long-Sperre (Gleichlauf X ≤ θ1, ein Termin oder die Handbremse), 2 = Schock (X ≤ θ2X oder Krypto allein Y ≤ θ2Y bei
  Long-Liquidationen im 99. Perzentil, oder Handbremse „Schock“). Frei frühestens 120 min nach der letzten Bedingung (Stufe 2: 240 min),
  wenn es seit 30 min ruhig ist. Ist der Zustand älter als 3 min, eröffnet Welt A keine Longs („Notbremse veraltet“, Banner rot).
- **Wirkung in Welt A:** keine neuen Longs, kein Nachkaufen (auch Grid-Kauf-Lose und Akkumulation), offene Long-Limits storniert, eine
  Füllung im Sperrzeitraum verworfen. Schließen, Stopps, Ziele und Shorts bleiben frei. Gesperrtes protokolliert `nb_blockiert`.
- **Anzeige:** Banner im Kopf jeder Seite (Stufe 1 gelb, Stufe 2 rot, mit „Sperre aufheben“), Knopf **⛔ Notbremse** (Handbremse:
  1 h, 4 h, 24 h, bis auf Widerruf, Schock 4 h, Sperre aufheben; freiwilliger Grund), Abschnitt **NB Notbremse** (G je Korb und Fenster,
  X/Y/Λ mit Schwellen, Episoden mit D und Varianten V1–V3, gesperrte Vorgänge, D je Tag, Termine, Körbe, Kalibrierungen). Im TradeLabor die
  Kachel „Notbremse“ (mit / ohne / Unterschied seit dem Start der Welt A) und in „Strategien“ die Spalte „Unterschied“. Ein Ton beim Wechsel
  auf Stufe 1 und ein anderer auf Stufe 2 (über den Schalter „Töne“). Im Bericht „★ TradeLabor“ der Abschnitt „Notbremse“.
- **Termine** in `notbremse_termine.json` (UTC, Format `2026-11-03T23:00Z`); der Dienst liest die Datei bei jeder Änderung neu.
- **Nach dem Einspielen zuerst:** Debug „★ Notbremse: Zerlegung des 22.10.“ (`check_notbremse.py --zerlegung 2026-10-22`) und abends
  den Rückblick. **Seit 23.77 aus der Debug-Konsole, ohne SSH:** „★ Notbremse: Rückblick vollständig im Hintergrund STARTEN“ startet ihn
  als eigene systemd-Einheit (`hl-rueckblick-…`, wie das Update mit `sudo.txt`): niedrige Priorität (nice 15, Platte im Leerlauf), bei
  Speichernot beendet ihn der Kernel zuerst (OOM-Wert 900), er bricht selbst mit Teilergebnis ab, wenn weniger als 400 MB bzw. 10 % des
  Arbeitsspeichers frei sind, Zeitbudget 8 h, harte Grenze 10 h. Er läuft weiter, wenn die Seite zu ist oder das Dashboard neu startet.
  „★ Notbremse: Rückblick im Hintergrund -- Stand und Ergebnis“ zeigt Fortschritt und Speicher, am Ende den ganzen Bericht; der liegt
  dann auch unter „Neue Berichte“ (`…_notbremse_rueckblick.txt`, ohne Ende `…_abgebrochen.txt`). Abbrechen: „… abbrechen“. Per SSH
  ginge es weiter mit `nohup .venv/bin/python check_notbremse.py --rueckblick > rueckblick_notbremse.txt 2>&1 &`
  (`--ohne-labor` für die schnelle Fassung ohne Rückwärtstest, `--ohne-binance` ohne die Positivkontrollen, `--takt 600` gröber,
  `--max-stunden 8` Zeitbudget). Die Positivkontrollen laden Monatsdateien von data.binance.vision und legen sie verdichtet in
  `notbremse_binance/` neben der Datenbank ab.
- **Dateien:** `notbremse.db` (neben `hl_liq.db`), `labor_a.db` (neben `forecasts.db`); beide und `notbremse_termine.json` im Backup.
  Schalter: `HL_NOTBREMSE=0` (keine Welt A), `HL_NOTBREMSE_DB`, `HL_LABOR_A_DB`, `HL_NOTBREMSE_TERMINE` (andere Orte, für Tests).
- **Last:** je Minute 3 Abfragen à Gewicht 2; die Historie einmalig im Mittel 40 je Minute; Welt A rechnet im Labor-Takt ohne eigene Eingaben.
- **Noch nicht:** Ebene B (Prognosemärkte, Schlagzeilen mit KI) kommt mit U207 und läuft zuerst 30 Tage im Schatten.

## Volumen: Einstiege der Strategien nach Volumen (seit 23.81)

Studie U221, vorab festgelegt am 24.10. vor dem Bau (`KONZEPT_Volumen.md`, unabhängig durchgesehen, freigegeben 03:17), Modul
`hl_volumen.py`. Frage des Nutzers: „wir brauchen für alle trading strategien eine volumen analyse“; seine Wahl „Erst messen, dann
filtern“. Die Studie liest nur und fließt nirgends ein (weder Labor noch Konfluenz, Prognose, Fusion, v3, Kaskaden, v1-Lernen).

- **Kennzahlen zum Zeitpunkt der Entscheidung**, nur aus Daten davor, aus der eigenen Hyperliquid-Aufzeichnung:
  - **RV** relatives Volumen: Umsatz in USD im Fenster vor dem Einstieg ÷ Median desselben Fensters zur gleichen Uhrzeit an den Tagen
    gleicher Art (Werktag oder Wochenende, in der Mitte des Fensters bestimmt) der 28 Tage davor.
  - **TS** Taker-Saldo in Handelsrichtung: (Taker-Kauf − Taker-Verkauf) ÷ beides, abzüglich des üblichen Werts zur gleichen Uhrzeit;
    für Shorts umgekehrt. Positiv heißt: Die Aggressoren drückten stärker als sonst in unsere Richtung.
  - Fenster 60 min bei Horizont bis 12 h, sonst 24 h. Limit-Einstiege zählen ab der gelegten Order (t0).
- **Prüfgröße D** = Ø Netto-Ertrag im oberen Drittel − im unteren, je Schicht (Kennung × Long/Short × Werktag/Wochenende) gebildet.
- **Teil A (live):** alle geschlossenen Trades des TradeLabors in Welt B, ab 28 Tagen + 24 h Aufzeichnung. Hauptprüfungen A1 (RV)
  und A2 (TS) gepoolt über einen festen Pool (ohne Zufalls-Kontrollen, volumengekoppelte Auslöser, „…_gegen“, Grid, Akkumulation);
  Nullmodell: die fertigen Reihen um ±24 … ±336 h verschoben (626 Verschiebungen); Holm, beide Hälften; je Strategie mit
  Normalnäherung der Null, Holm und BH. **Urteil erst am 08.11.2026** (Trades geschlossen vor 00:00 UTC), jeder Lauf davor heißt
  „vorläufig“.
- **Teil B (Historie):** die vier Swing-Strategien seit 2020 (`hl_swing.lauf`, Daten bis 23.10.2026) mit Tagesumsatz und Taker-Kauf
  des USDⓈ-M-Perps aus `hebel.db`; Verschiebung um ±30 … ±365 Tage; urteilt, sobald die Historie vollständig ist.
- **Beschreibend:** Gruppen, Ø netto und Treffer je Drittel, Kontrolle „Zufall“ (Markteffekt) und D − D(Zufall), Binance-RV,
  Coinbase-Taker-Saldo, Spitze (größter 5-min-Umsatz), Welt A, Grid, Akkumulation, je Coin, Werktag/Wochenende, Long/Short,
  Datenlage (fragliche Minuten -- `bars` gegen `bars10`, Befund U222 --, Seitenprüfung), Teil B je Jahr und Zufalls-Swing; Stand
  heute je Coin und die Drittelgrenzen der offenen Positionen (nur Lage).
- **Seit 23.82 (Entscheidung des Nutzers 25.10. vor dem Urteil, `KONZEPT_Volumen.md` 12.19–12.24):** Der erste Lauf hatte 74 % der
  Trades ohne Kennzahl, weil jede fragliche Minute (Befund U222, `bars` gegen Σ `bars10`) als Lücke zählte. Jetzt ist der Umsatz je Minute
  der größere Wert aus `bars` und den 10-s-Stücken, und nur „nicht aufgezeichnet“ ist eine Lücke; die alte Regel steht beschreibend unter
  den Hauptprüfungen. Die Datenlage trennt die fraglichen Minuten nach Art (Minuten-Bar zu klein / 10-s-Stück zu klein, Hoch/Tief enger);
  ein Band erscheint nur, wenn es ein D gibt.
- **Folgen:** Nur „belegt“ führt zu einem Vorschlag für Stufe 2 (neue Labor-Variante mit Volumenfilter, eigener Plan-Punkt), nicht vor
  dem 25.10. und nicht vor dem Urteil; belegt nur in Teil B erst nach Bestätigung im Labor.
- **Debug:** „★ Volumen: Einstiege der Strategien nach Volumen (U221)“ (`hl_volumen.py --studie --db …`), „Volumen-Studie:
  Selbsttest“, seit 23.82 „★ Recorder: fragliche Minuten in bars/bars10 …“ (`hl_volumen.py --datenlage --db …`: nur die Datenlage der
  letzten 28 Tage je Coin und Tag und die Zähler des Recorders, ohne Trades; Berichtsplan 27.10. und 29.10. 09:20). Berichtsplan: 24.10. 21:15 (Teil B mit Urteil, Teil A vorläufig), 25.10. und 01.11. 09:15 (vorläufig), **08.11. 09:15
  Urteil Teil A**. Laufzeit hier bei Höchstgröße (6 Coins × 162 Tage Minuten, 20.000 Trades) 48 s und 320 MB; auf dem Pi einige
  Minuten (der Bericht nennt sie), Grenze der geplanten Berichte 15 min.
- **Prüfung:** Selbsttest mit 24 Proben (Rechnung von Hand, Kausalität, Gültigkeit, Seitenprüfung, t0 bei Limit, Drittel, Holm/BH,
  Verschiebung, Positiv- und Negativkontrollen, Störgrößen Wochenende/Long-Short/Montag, Pool fest, Teil B über `hl_swing`, Urteil erst
  am Stichtag, Markteffekt, Bausteine, neue gegen alte Regel, Band nur mit Punktschätzung, `bars10` über die Lesestücke, Ende zu Ende auf
  erfundenen Datenbanken mit überschriebenen Minuten); Mutationen siehe UEBERGABE.

## Extrem-Wende: eine Strategie aus einem Video nachgebaut (seit 23.83)

Plan-Punkt U226, Wunsch des Nutzers am 25.10.: „Hol dir das video von https://m.youtube.com/watch?v=grMDEn7QbJA. Und baue diese
Strategie nach.“ Das Video war von hier aus nicht erreichbar; nachgebaut nach dem Transkript, das der Nutzer angehängt hat. Seine Wahl:
„Studie und gleich ins Labor“, „Eine Hauptregel, Rest beschreibend“, „Nur BTC 8h“. Vorab festgelegt in `KONZEPT_Wende.md` (10:41,
unabhängig durchgesehen, vor jedem Lauf auf echten Daten geändert, auf Nullmärkten kalibriert und der Endstand ein zweites Mal
durchgesehen: Abschnitt 8), Modul `hl_wende.py`.
Die Studie liest nur; nichts fließt in Konfluenz, Prognose, Fusion, v3, Kaskaden oder v1-Lernen.

- **Regel laut Video:** BTC, 8-h-Kerzen (UTC 00/08/16, aus den Binance-30-min-Kerzen in `swing.db`). Im Fenster der 765 Kerzen bis zur
  Flip-Kerze ist eine Kerze rot, wenn ihr Hoch zu den höchsten 10 % gehört, blau, wenn ihr Tief zu den tiefsten 10 % gehört. Short, wenn
  seit dem letzten bullischen Flip mindestens eine rote Kerze kam und dann die EMA 8 unter die EMA 89 fällt; Einstieg zum Schluss der
  Flip-Kerze; Stop 0,1 % über dem höchsten Hoch der roten Kerzen. Long gespiegelt (blaue Kerzen, bullischer Flip).
- **Was das Video offenlässt, ist festgelegt:** „höchste 10 %“ in zwei Lesarten (A Rang: 90-%-Quantil der Hochs; B Spanne: oberes
  Zehntel zwischen tiefstem Tief und höchstem Hoch) -- welche gilt, entscheidet allein das Nachrechnen der sechs im Video genannten
  Trades und der Zahl von 35 Signalen (16 Long, 19 Short) seit November 2021, ohne Gewinnzahlen. Hauptregel für den Ausstieg: Ziel 1R
  als Limit, Stop als Markt, höchstens 120 Tage; Kosten und Funding wie `hl_swing`.
- **Urteil:** H1 -- treffen die Trades ihr Ziel öfter als dieselben Trades zu anderen Zeiten? (alle gemeinsam im Kreis um mindestens 120
  Tage verschoben, Stop-Abstand nach der Schwankung vor dem Einstieg skaliert; Schwelle α_H1 = 0,038 aus der Kalibrierung auf
  Nullmärkten). Dazu H2 (Ø R nach Kosten > 0, Cluster-robust über Gruppen überlappender Trades), beide Hälften, mindestens 30 Trades in
  20 Gruppen. Daten fest bis zum Stichtag 27.10.2026; es zählen Signale ab 01.11.2021, die mehr als 120 Tage vor dem Datenende
  geschlossen haben.
  Wortlaut: „auf der Stichprobe des Videos bestätigt / nicht bestätigt / nicht prüfbar“ -- es ist die Stichprobe, auf der der Autor das
  Setup gezeigt hat; unabhängig sind erst die Signale vor November 2021 (beschreibend) und das Labor.
- **Ehrliche Erwartung:** Bei rund 40 Trades braucht H1 etwa zwei Drittel Treffer. Ein Vorteil wie im Video (+5 Prozentpunkte bis 1R)
  wird so nur selten bestätigt; „nicht bestätigt“ heißt dann: nicht von Glück zu trennen, nicht: widerlegt.
- **Beschreibend:** Signalliste; Vergleich mit den Zahlen des Videos (ohne Kosten, ohne Zeitgrenze; „perfekt“ nur als Obergrenze im
  Nachhinein); Ausstiege 1R/2R/3R/bis zum Stop/Gegen-Flip gegen dieselben Trades verschoben; Treffer je Stufe 0,5R … 5R; Kontrolle „Flip
  ohne Extrem“; Empfindlichkeit (Lesart × Fenster 500/765/1.050, Färbung je Kerze, Stop „Block“); die Zeit vor dem Video (2020–21);
  Stand jetzt (Lage des Ribbons, wäre der nächste Flip ein Signal, mit welchem Stop); Labor-Abgleich; Befunde zur Prüfung.
- **Labor:** zwei Strategien in der Gruppe Swing, nur BTC -- `wende_rang` (Lesart A) und `wende_spanne` (B), weil die Lesart erst die
  Studie auf dem Pi entscheidet. Einstieg zum Marktpreis höchstens 60 min nach dem Schluss der Flip-Kerze und einmal je Signal; Stop und
  Ziel 1R ab der Mitte; höchstens 120 Tage; Größe fest 10.000 USD; Welt A sperrt Longs wie überall. Ein Signal entfällt, wenn beim
  Schluss der Flip-Kerze oder danach eine Position offen war oder der Kurs beim ersten Prüfen jenseits oder zu nah am Stop liegt (Rand
  mindestens 5 bps und die Hälfte des Abstands am Schluss) -- wie in der Historie. Verfallene (zu spät gesehen) und ausgelassene Signale
  zählt die Tafel getrennt.
  Kennungen `wende_rang@6fdc1dde`, `wende_spanne@c1d92651`; eine Goldprobe im Selbsttest meldet, wenn ein Umbau die Signale ändert (dann
  `wende_v` erhöhen, neue Kennung).
- **Debug:** „★ Wende: Extrem-Wende nach Video (BTC 8 h, U226)“ (`hl_wende.py --studie --db …`, liest nur) und „Wende: Selbsttest“;
  `hl_wende.py --stand --db …` zeigt nur die Lage jetzt; `hl_labor.py --selbsttest-wende` nur die Labor-Proben;
  `hl_wende.py --kalibrieren N --variante V [--teil k/m] [--seed S]` die Kalibrierung. Berichtsplan 27.10. 09:40 (urteilt).
- **Prüfung:** Selbsttest mit 22 Proben (Kerzen, EMA und Flips, Lesarten und Grenzfälle von Hand, konstruiertes Signal, Varianten,
  Kausalität, erste Passage, Handel und Kosten von Hand, Stufen, Gegen-Flip, Statistik und Urteil von Hand, Verschiebung mit Skalierung,
  Nachrechnen mit Toleranzen, Labor-Abgleich, Goldprobe, Labor-Daten, Ende zu Ende mit Stichtag, kurzer Nulltest, Positivkontrolle);
  Labor-Proben 4; Kalibrierung und Mutationen siehe UEBERGABE und KONZEPT 3.9.

## Debug-Nummern: jeder Lauf hat eine feste Nummer (seit 23.84)

Plan-Punkt U227, Wunsch des Nutzers am 25.10.: Die Debug-Läufe sind zu viele, um sie nach Namen zu finden. Claude soll „Debug Nr. 26“
sagen können, und im Menü soll man eine Nummer eingeben und ausführen können -- ohne Dateien umzubenennen und ohne neue Probleme.

- **Die Nummer:** 1–124 sind die Reihenfolge des Menüs am 25.10.2026, 125 und 126 kamen mit 23.84 dazu. Eine Nummer ändert sich nie
  und wird nie neu vergeben: Neue Läufe bekommen die nächste freie Nummer; fällt ein Lauf weg, bleibt seine Nummer leer („gibt es nicht
  mehr“). Dateien und interne Namen bleiben, wie sie sind.
- **Im Menü** beginnt jeder Eintrag mit seiner Nummer („26 · ★ Wende: …“); die Reihenfolge bleibt.
- **Feld „Nr.“** vor dem Menü: Nummer eintippen -- der Lauf ist im Menü gewählt, sein Name steht darunter. Gestartet wird erst mit
  „Ausführen“; Enter wählt nur aus. Beim Antippen ist der Inhalt markiert, Tippen ersetzt ihn (aus „26“ wird nie „126“). Eine
  unbekannte Nummer sperrt „Ausführen“ („Nr. 999 gibt es nicht“), auch wenn sie während eines Laufs getippt wurde. Nach dem Start und
  bei einer Wahl im Menü von Hand ist das Feld wieder leer -- die Nummer steht im Menü. Bis die Seite die Nummern geladen hat, ist
  „Ausführen“ gesperrt; gelingt das nicht, steht es in der Zeile neben den Knöpfen.
- **Schalter fragen nach:** Sechs Läufe schalten etwas um -- 17/19 Notbremse-Rückblick starten/stoppen, 28/29 Systemprotokoll an/aus,
  93/94 Kalibrierung v2 an/aus. „Ausführen“ öffnet darunter eine Nachfrage mit „Ja, ausführen“ und „Abbrechen“ (auf der Seite selbst,
  kein Browser-Dialog -- den zeigt die Android-App nicht); wer das Menü oder die Nummer ändert, schließt sie. Der Server nimmt einen
  Schalter nur mit dieser Bestätigung an, auch von einer älteren offenen Seite nicht: ein Tippfehler schaltet nichts um.
- **Die Nummer steht überall:** im Kopf der Konsole und jedes Berichts („# Nr. 26 · …“), im Dateinamen von „Als Datei“
  (`nr26_wende_studie_…txt`, benannt nach dem Lauf, aus dem der Text stammt), im Berichtsplan („(Lauf Nr. 26)“). Die Dateinamen unter
  `berichte/` bleiben wie bisher; ihr Kopf trägt die Nummer.
- **Liste zum Nachschlagen:** Lauf **125 „Debug-Liste“** zeigt alle Läufe nach Nummer, markiert die Schalter und nennt den nächsten
  Termin im Berichtsplan (auch `hl_viz.py --debug-liste --db …`). Lauf **126** ist der Selbsttest dazu (`hl_viz.py --selbsttest-debugnr`,
  auch Schritt der Installation).
- **Für Entwickler, fest:** `_DEBUG_REIHE` in `hl_viz.py` nur hinten verlängern -- nie löschen, umstellen oder dazwischen einfügen;
  Schlüssel in `debug_commands` nie umbenennen (der Lauf bekäme eine neue Nummer). Nach neuen Läufen einen Prüfpunkt hinten an
  `_DEBUG_REIHE_PRUEFPUNKTE` anfügen, alte nie ändern. Der Selbsttest prüft alle Prüfpunkte und 19 feste Stichproben; ein neuer Lauf
  ohne Nummer fällt dort durch. Ein Lauf, der etwas umschaltet, schreibt das Schaltwort groß (AKTIVIEREN, EINSCHALTEN, AUSSCHALTEN,
  STARTEN, STOPPEN) und steht in `DEBUG_SCHALTER` -- der Selbsttest prüft beides.

## Prognosemärkte: Kalshi, Polymarket und Hyperliquid-Ereignismärkte (seit 23.88)

Plan-Punkt U235, Wunsch des Nutzers am 27.10.: einen eigenen Abschnitt „Prediction Markets“ bauen, alle verfügbaren Daten über die
Prognosen ziehen, sie in einer Datenbank sammeln und ihre Vorhersagegüte prüfen wie bei den anderen Treibern -- mit einem Rückblick auf
alte Daten, wo es sie gibt. Grundlage: `RECHERCHE_Prognosemaerkte_27-10-2026.md`; vorab festgelegt in `KONZEPT_Prognosemaerkte.md`
(unabhängig durchgesehen, Nachtrag 13.1 mit den festen Regeln R1–R15, Nachtrag 13.2 beim Einbau). Modul `hl_prognosemarkt.py`, Skript
der Seite `hl_prognosemarkt_js.py`, eigene Datei `prognosemarkt.db` neben der Hauptdatenbank.
**Nur lesen, wirkt auf nichts:** keine Prognose, kein Treiber-Gewicht, keine Fusion, kein Labor. Kein Konto, kein Schlüssel, kein Handel.

- **Quellen:** Kalshi (öffentliche REST-API), Polymarket (Gamma, CLOB, Data API v2), Hyperliquid HIP-4 (`outcomeMeta`, Bücher,
  Ergebnisse), dazu 1-min-Spot von Coinbase (BTC, ETH) und Binance (ZEC, HYPE-Perp) als Vergleich. Keine 5-Minuten-Märkte (dokumentierte
  Manipulation der Abrechnung).
- **Dienst:** ein Faden „prognosemarkt“ im Dashboard, Start 60 s nach dem Dashboard. Beim ersten Start der **Erstlauf** (Formatprüfung je
  Quelle: Felder, Anzahlen, Uhrabweichung des Pi, Sperren) -- er setzt den **Stichtag**: Der Rückblick umfasst Märkte mit
  Handelsschluss davor, alles danach gehört zur späteren Vorwärtsrunde. Danach je Runde der Takt (Kalshi 15 min und Makro jede Minute,
  Tagesleitern alle 5 min, Polymarket Auf/Ab jede Minute, Leitern alle 5 min, HIP-4 Bücher jede Minute, Spot jede Minute) und bis zu 10 s
  Rückblick. Pausen je Quelle: 429 → 60 s (verdoppelt bis 15 min), drei Fehler in Folge → 15 min (verdoppelt bis 6 h). Hyperliquid mit
  eigenem Deckel von **20 Gewicht je Minute** (im Mittel rund 12); der Recorder bleibt bei seinen 1.080. Aus mit `HL_PM=0`; `HL_PM_DB`
  lenkt die Datei um; nicht für Selbsttest-Datenbanken.
- **Rückblick:** Kalshi liefert abgelaufene Märkte mit 1-min- bzw. 60-min-Kerzen ohne Konto -- 15-min-Märkte BTC, ETH, HYPE, ZEC seit
  ihrem Start, Tagesleitern `KXBTCD`, Makro-Leitern (Inflation seit Juni 2021, Arbeitsmarkt, Fed); dazu Spot ab 400 Tagen vor dem ersten
  BTC-Markt (für das Schwankungsmodell), Binance-Perp-Renditen um jeden Makro-Termin und die Nullprobe aus einer zweiten Börse. Polymarket
  gibt alte Kurse nur grob heraus, HIP-4 nur Ergebnisse. Fortschritt je Teil im Reiter „Rückblick“; ein Teil ist fertig bei mindestens
  95 % erledigten Arbeitsschritten.
- **Drei Prüfungen, ein gemeinsames Urteil (vorab festgelegt, Nachtrag 13.1):**
  - **H1** -- Weiß der Kalshi-15-min-Markt für BTC **vor** dem Fensterbeginn (bei B − 60 s) etwas über die Richtung? Maß: Kovarianz
    c = cov(p_M − 0,5, y), mindestens 4.000 Fenster an 60 Tagen.
  - **H2** -- Sind die Wahrscheinlichkeiten der Kalshi-Tagesleiter (17:00 ET) besser verteilt als das beste kausale Modell
    (Coinbase-Spot, log-HAR mit Wochentags- und Makrofaktor)? Kein Richtungstest. Vorlauf 24/18/12/6 h nach Abdeckung, mindestens
    100 Tage.
  - **H3** -- Sagt die Kalshi-Inflationsüberraschung u = Ist − Median die BTC-Rendite 08:30–09:00 ET voraus (Spearman, erwartet
    negativ)? Mindestens 30 Termine; zwei Placebos müssen null sein.
  - Studentisierter Block-Bootstrap über 7-Tage-Blöcke, gewichteter Holm (H1 0,25 · H2 0,25 · H3 0,5), „belegt“ nur mit richtigem
    Vorzeichen in beiden Hälften. Das Urteil fällt **einmal**, sobald alle Teile fertig sind und die Prüfungen vor dem Urteil bestanden
    sind (Positivkontrollen und Nullproben auf echten Daten). **Bis dahin zeigen Bericht und Anzeige nur Zählungen** -- keine Treffer,
    keine Brier-Werte, keine Renditen (R4). Erwartung vorab: H1 nicht prüfbar oder nicht belegt, H2 offen, H3 etwa ein Münzwurf bis
    wahrscheinlich.
- **Abschnitt „PM Prognosemärkte“** (Navigation „Prognosemärkte“), fragt nur, solange er offen und sichtbar ist (höchstens einmal je
  Minute und Reiter):
  - **Überblick:** laufende und nächste Auf/Ab-Fenster (Kalshi 15 min, Polymarket 15 min bis Tag) mit Ja-Kurs, Spread und Alter, daneben
    das **Spotmodell** (driftfrei aus dem Spot und der Schwankung der letzten 1, 7 und 30 Tage; vor dem Beginn genau 50 %) -- ein Ja-Kurs
    nahe dem Spotmodell ist ein Echo des Spots; HIP-4-Kursziele; Spot BTC und ETH.
  - **Krypto:** Schwellen-, Spannen- und Berührungsleitern mit Ja-Kurs, rekalibriert (Le 2026, nur lange Horizonte) und Spotmodell.
  - **Makro:** Erwartung vor dem nächsten Termin (Median und Streuung der Leiter); vergangene Termine mit Überraschung und BTC-Rendite
    erst nach dem Urteil.
  - **Ereignisse:** Ja-Kurse mit Änderung gegen 1 h und 24 h, ⚑ bei Sprüngen ab 10 Prozentpunkten.
  - **Bilanz:** vor dem Urteil die Zählung (gezählt gegen Mindestzahl, Freigabe, was noch fehlt), danach H1–H3 mit Maß, Intervall,
    p (Holm), Hälften und Urteil, die Prüfungen vor dem Urteil und Beschreibendes (ohne p-Werte).
  - **Rückblick:** Teile mit Stand, Abdeckung, Schritten, Fehlern; Stichtag, Kalshi-Archivgrenze, Erstlauf.
  - **Daten:** Abrufe der letzten 24 h je Quelle (ok, 404, 429, gesperrt, Fehler), Pausen, Hyperliquid-Gewicht je Minute gegen den
    Deckel, Frische der Live-Kurse, Fehler, Zeilen; „Dienst: letzter Zustand vor …“ zeigt, ob der Faden läuft.
  Hinweis über jedem Reiter: „Echo des Spots, kein Signal“. Keine Kauf- oder Verkaufswörter; Farbe nur für Zustände, immer mit Zeichen.
- **Debug:** Nr. 129 „★ Prognosemärkte: Stand und Quellen“ (`hl_prognosemarkt.py --stand --db …`, mit Erstlauf und Dienst),
  130 „★ … Auswertung“ (`--auswertung`: vor dem Urteil Zählung, sonst das Urteil), 131 „Formatprüfung erneut“ (`--erstlauf`), 132
  „Selbsttest“ (`--selbsttest`), 133 „Mutationsprüfung“ (`--mutationen`, auf dem Pi rund 15 min). Weiter: `--nutzlast TAB` (JSON eines
  Reiters), `--rueckblick N` (N Schritte von Hand), `--takt S`. Berichtsplan: 30.10. 12:00 und 31.10. 08:45 (Erstlauf, Stand, Zählung),
  01.11. 20:45 und 03.11. 20:45 (Urteil oder Zählung), dazu in der Wochenprüfung.
- **Speicher:** `prognosemarkt.db` wächst geschätzt um 1–4 GB im Jahr (Live-Kurse; gleiche Werte verlängern nur die vorige Zeile;
  Abrufprotokoll 90 Tage); die tägliche Sicherung des Recorders nimmt sie mit.
- **Prüfung:** Selbsttest des Moduls (Zeitachsen mit Sommerzeit, Parser je Quelle, Kausalität, Bootstrap mit Positivkontrolle und
  Nullprobe, Holm, Hälften, Abruf-Pausen, Rückblick mit Cursor und Ausnahmen, Ende zu Ende gegen ein Ersatz-Netz, R4 in der Nutzlast);
  30 Mutationen müssen ihn rot machen; `hl_viz.py --selbsttest-prognosemarkt` (Endpunkte, R4 über den Server, Skript, Seite, Dienst,
  Debug-Läufe) -- beide Schritte der Installation.
- **Grenzen:** Kein Endpunkt war vor dem Einspielen erreichbar (Sandbox); Formate stammen aus Dokumentation und Spiegeln und werden im
  Erstlauf geprüft -- weicht etwas ab, steht es vor jeder Auswertung als Nachtrag im Konzept. Unterschiedliche Referenzkurse
  (CF-Index bei Kalshi, Chainlink oder Binance bei Polymarket, Mark-Preis bei HIP-4) gegen den Coinbase-Spot: das Spotmodell ist nur
  Anzeige. Rechtliches: Deutschland ist bei Polymarket „nur Schließen“ (Handel); gelesen werden nur öffentliche Kurse.

## Weboberfläche nicht erreichbar (seit 23.77; Selbstheilung seit 23.78)

Am 23.10. antwortete der Pi auf Ping, Port 8765 aber nicht; SSH ist aus, ein Bildschirm hängt nicht dran. Der Systembericht zeigte danach:
Der Dashboard-Prozess lebte (systemd und Wächter: „aktiv“), maß aber ab 09:31 nichts mehr -- er hing knapp 5 Stunden bis zum Neustart.
- **Seit 23.78 heilt sich das Dashboard selbst:** Ein Faden fragt jede Minute die eigene Seite `/lebt` ab (ohne Datenbank). Nur wenn sie
  antwortet, meldet er systemd ein Lebenszeichen (`WatchdogSec=900`, `NotifyAccess=main` in der Unit). Bleibt es 15 Minuten aus, beendet
  systemd das Dashboard und startet es nach 20 s neu. Vorher hält es fest, **wo jeder Faden stand**: 5 Minuten nach der letzten Antwort und
  beim Beenden schreibt faulthandler die Stapel aller Fäden nach `logs/dashboard_haenger.log` (das geht auch, wenn ein Faden das GIL
  festhält); antwortet nur der Webserver nicht, kommt schon nach etwa 2 Minuten ein Abzug mit Fadennamen dazu. Stockt ein Teil im
  Hintergrund (Systemverlauf, TradeLabor, Prognose), ohne dass die Seite hängt, gibt es einen Abzug ohne Neustart. Die Ausgabe des
  Dashboards steht seit 23.78 mit Zeitstempel in `logs/dashboard.log` (vorher nur im flüchtigen Journal); beide Dateien werden beim Start
  gekürzt (20 MB bzw. 2 MB). Kein Speicherabbild auf der SD-Karte (`LimitCORE=0`). Der Wächter prüft zusätzlich den Port (Zeile „Dashboard“).
  Aus mit `HL_LEBENSZEICHEN=0` (nur für Tests). Probe: `hl_viz.py --selbsttest-lebt` (mit nachgebautem systemd, Positivkontrolle: ein Faden
  hält das GIL fest).
- **Verlauf im Abschnitt „System“ (seit 23.79):** Fehlen mehr als 3 Minuten Messungen, zeigt die Grafik dort eine graue Fläche „keine
  Messung“ mit Uhrzeiten, und die Zeile darunter nennt die Lücken. Bis 23.78 verband sie den letzten Wert vor der Lücke mit dem ersten danach
  (am 23.10. eine schräge Linie bis 100 % -- gemessen war in der Zeit nichts).
- **Ohne SSH:** Der Pi 5 hat einen Ein-/Aus-Taster. Mit Desktop zweimal kurz drücken = sauber herunterfahren (bei Lite einmal); danach
  einmal drücken zum Starten. Nicht lang gedrückt halten (hartes Ausschalten). Strom ziehen nur als letzter Ausweg. Mit 23.78 sollte das nur
  noch nötig sein, wenn der ganze Pi hängt.
- **Danach, wenn die Seite wieder geht:** Debug „★ System: letzter Neustart und Ausfälle“ (`check_system.py`, liest nur). Er zeigt das
  Systemprotokoll **vor** dem Neustart (Dashboard: Abstürze und letzte Zeilen; Kernel: Speicher, Platte/USB, Strom, Hänger; endete der
  vorige Start sauber oder abrupt), die Meldungen des Wächters der letzten 24 h und seine letzten Prüfungen vor dem Neustart, Lücken im
  CPU-Verlauf des Dashboards (dann stand oder hing es), die Berichte und Debug-Läufe der letzten 24 h, Speicher, Platte, Strom
  (`vcgencmd get_throttled`) und Prozesse jetzt, dazu Update- und Notbremse-Log. Seit 23.78 außerdem: Hänger-Schutz an/aus und ob der
  letzte Neustart vom Wächter kam, die **Hänger-Abzüge** (wo stand welcher Faden), die Zeilen „Lebenszeichen“ und das Ende von
  `dashboard.log`, die **Lücken des Dashboards über 7 Tage** (aus den Prognosen, alle 15 min je Coin) und **um die längste Lücke**: alle
  Wächter-Prüfungen mit ihren Abständen (verzögert = der Pi selbst war überlastet), Recorder-Meldungen (z. B. das tägliche Backup) und die
  **Lebenszeichen der Dashboard-Teile in den Datenbanken** (Prognose, TradeLabor, Welt A, Ausblick, Makro, Aktien, Seite im Browser) gegen
  Recorder und Notbremse-Dienst als eigene Dienste -- stand das ganze Dashboard oder nur ein Teil, und wann gab es das letzte Lebenszeichen?
  Gezählt wird im Kern der Lücke (je 15 min Rand, so genau sind ihre Grenzen). **Seit 23.79** zählen beim TradeLabor nur Einträge, die es
  immer zur Zeit des Takts schreibt (Limit, Storno, Stop nachgezogen, Verfall, Kaskade): Füllungen, Ausstiege und Grid tragen die Zeit der
  Kerze, und nach einem Neustart spielt das Labor die verpassten Kerzen nach -- solche Einträge liegen dann zeitlich in der Lücke, wurden aber
  erst danach geschrieben. Der Bericht erkennt das an der Schreibreihenfolge (Rücksprünge, Einträge hinter dem ersten nach der Lücke) und
  nennt es („nachgeholt“). 23.78 zählte sie mit und meldete für den 23.10. fälschlich „nur Teile standen“. Ein Fenster von Hand: `check_system.py --fenster
  2026-10-23T09:31 2026-10-23T14:28`. Am Ende ein kurzer **Befund**.
- **Systemprotokoll dauerhaft (nur wenn du es willst):** Debug „System: Systemprotokoll dauerhaft speichern -- EINSCHALTEN“ legt
  `/etc/systemd/journald.conf.d/90-hl-dauerhaft.conf` an (`Storage=persistent`, höchstens 200 MB, 2 GB bleiben frei), erstellt
  `/var/log/journal` und startet journald neu; danach überleben Kernel-Meldungen (Speicher voll, USB-Fehler, Unterspannung) einen Neustart.
  „… AUSSCHALTEN“ stellt den alten Zustand her und löscht die gespeicherten Protokolle. Beides braucht `sudo.txt`; das Passwort geht nur
  über stdin, keiner der Befehle liest es.
- **Rückgängig (Letztes Backup wiederherstellen):** Seit 23.78 erzeugt die Wiederherstellung auch die Units neu, mit dem `install.py` des
  zurückgespielten Stands -- ein älteres Dashboard sendet keine Lebenszeichen und würde mit der neuen Unit sonst alle 15 min neu gestartet.
- **Mit SSH** (`ssh seed@IP-DES-PI`): `systemctl status hl-dashboard`, `tail -n 80 /media/seed/marketdatabase/hl_liq/logs/dashboard.log`
  (seit 23.78; vorher `journalctl -u hl-dashboard -n 80`), `sudo systemctl restart hl-dashboard`.

## Neu in 23.68 (17.10.2026)

Kurz, Einzelheiten in den Abschnitten und in `UEBERGABE_13-09-2026.md` 3ξξξ:
- **Vollbericht** in einem Durchgang mit Zeitbudget und Laufzeit je Abschnitt (U168).
- **Kurs-Chart mit „Binance Daten“:**
  - kein Skriptfehler mehr im Hinweisfenster;
  - eingetretene Marken als „liquidiert … USD · n Liquidationen“;
  - FVGs mit der Mindestgröße der Anfrage, Abstände von FVGs und Orderbuch-Stufen; fehlende Werte als „—“ statt „NaN“;
  - Börsenbücher als „Orderbuch der Börse“ statt „0 Konten“ (U166).
- **Konfluenz-Bilanz je Quelle** (U170).
- **Hinweis an Datentagen** und Gegenprobe mit Tagen (U172, U171); Makro-Text „USA“ klarer (U169).
- **TradeLabor:**
  - XMR mit normaler Gebühr (U160);
  - Tabelle je Strategie und Coin (U161);
  - Grid in USD vergleichbar (U163);
  - Swing und Zyklus mit fester Größe 10.000 USD und neuen Kennungen (U164);
  - Bilanzverlauf mit allen Strategien und Häkchen (U167).
- **Fusion:** Kriterium 5 im Bericht (U162). Die Fusion rechnet unverändert.
- **Aktienmarkt:** unvollständige Farside-Tage markiert, die Summen nur über vollständige Tage (U165).
- **Ausblick:** zusätzlich der Fächer in der Größe der Stressphase (U156).
- **Hebel:** CryptoQuant-Anteil der Derivate und Prüfung S5 (U158).
- **Neues Werkzeug** `check_abdeckung.py`: Abdeckung der Heatmap im Verlauf mit Neustarts (U159; Debug „abdeckung“, im Wochenbericht).

## Grenzen

Die Heatmap ist unvollständig. Sichtbar werden nur Wallets, die gehandelt
haben, während der Recorder lief. Die Abdeckung wächst über Wochen, wird aber
nie vollständig — für relative Verteilungen reicht das, für absolute
Notional-Zahlen nicht.

Historische Positionsdaten gibt es nicht. Die These lässt sich nur vorwärts
prüfen, nicht rückwirkend. Zwei bis drei Monate sind ein realistischer
Zeitraum, bevor die Zahlen etwas bedeuten, weil Marktphasen stark korrelieren.

Handel mit Perpetuals und Kryptowährungen kann zum Totalverlust führen. Diese
Werkzeuge treffen keine Aussage darüber, ob eine Strategie funktioniert —
sie helfen nur beim Messen.
