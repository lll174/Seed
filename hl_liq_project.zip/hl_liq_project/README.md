# Hyperliquid — Liquidationscluster aufzeichnen und auswerten

Werkzeuge, um zu prüfen, ob Liquidationscluster auf Hyperliquid Vorhersagekraft
haben, und um darauf aufbauend eine Handelslogik zu testen.

Zielplattform: Raspberry Pi 5, Debian 13 (Trixie), 64 Bit. Läuft ebenso auf
jedem Debian/Ubuntu mit Python ab 3.11.

## Dateien

| Datei | Zweck |
|---|---|
| `install.py` | Einrichtung, Abhängigkeiten, Selbsttest, systemd |
| `requirements.txt` | Python-Pakete |
| `hl_recorder.py` | zeichnet Cluster live auf, labelt sie im Analysemodus |
| `hl_viz.py` | Live-Chart, Heatmap-PNGs und Dashboard |
| `hl_watchdog.py` | Wächter mit Summer, LED, Push und Totmannschalter |
| `run_all.py` | startet und überwacht alle Dienste gemeinsam |
| `hl_binance.py` | Binance-Liquidationen live, Marktdaten 30 Tage rückwirkend |
| `hl_timestats.py` | zeitbasierte Heatmap: wann Bewegungen gehäuft auftreten |
| `hl_backtest.py` | Trendfolge-Backtest für Perps und Spot |

## Installation

```bash
python3 install.py            # venv, Pakete, Selbsttest
python3 install.py --enable   # zusätzlich: Autostart beim Booten einrichten
python3 install.py --check    # nur prüfen, nichts verändern
```

`--enable` erzeugt die systemd-Units, kopiert sie nach `/etc/systemd/system`,
aktiviert sie und prüft anschließend, ob alle drei laufen. Danach starten
Recorder, Binance-Stream und Dashboard automatisch bei jedem Boot.

Debian Trixie erlaubt kein `pip install` in die System-Python-Installation
(PEP 668). Das Skript legt deshalb ein venv unter `.venv/` an. Alle Aufrufe
danach über `.venv/bin/python`.

## Aktualisieren

**Per Knopf im Dashboard** (Panel „Aktualisierung", ganz unten): lädt das
Archiv von GitHub (`--update-url`, Standard: das Projekt-Repository), prüft es
und startet `update.py` in einer eigenen systemd-Einheit `hl-update`, die den
Neustart des Dashboards überlebt. Die Seite zeigt das Update-Log live und
lädt sich am Ende selbst neu. Voraussetzung: `sudo.txt` mit dem sudo-Passwort
im Projektordner, Rechte 600 (`chmod 600 sudo.txt`) — sonst verweigert der
Server. **Sicherheitshinweis:** Wer das Dashboard im WLAN erreicht, kann damit
Root-Aktionen auslösen. Sicherer ist eine sudoers-Regel ohne Passwortdatei:

    sudo visudo -f /etc/sudoers.d/hl-liq
    seed ALL=(root) NOPASSWD: /usr/bin/systemctl, /usr/bin/systemd-run, /usr/bin/cp * /etc/systemd/system/, /usr/bin/rm -rf */__pycache__

Dann `sudo.txt` löschen; `update.py` und der Knopf funktionieren ohne Passwort.

**Per Terminal:**

```bash
python3 update.py                    # neuestes hl_liq_project*.zip aus ~/Downloads
python3 update.py /pfad/archiv.zip
```

Sichert erst die Datenbank und die bisherigen Skripte, stoppt die Dienste,
spielt das Archiv ein (Datenbank, Backups, Logs bleiben unberührt), prüft die
Syntax — bei Fehlern wird die Sicherung zurückgespielt — erzeugt und
installiert die systemd-Units neu und startet die Dienste. Findet auch
Archive mit `-2`/`-3`-Suffix, die der Browser beim mehrfachen Herunterladen
anhängt, und räumt entsprechende Altlasten wie `hl_viz-2.py` weg.
Die Sicherung liegt danach unter `updates/vor_<Zeitstempel>/`.

## Datenbank auf ein anderes Medium verschieben

```bash
python3 migrate_db.py            # zeigt eingehängte Medien, fragt nach Auswahl
python3 migrate_db.py --target /mnt/ssd/hl
```

Stoppt die Dienste, wartet bis kein Prozess mehr an der Datenbank hängt,
faltet die WAL ein, prüft die Quelle, kopiert Datenbank und Backup-Ordner,
prüft die Kopie (integrity_check, Zeilenzahlen aller Tabellen), lässt den
Backup-Ordner auf dem Pi (getrennt vom Zielmedium), bietet
einen fstab-Eintrag an, damit das Medium nach Neustart wieder da ist,
stellt die Units um, startet die Dienste und wartet, bis der Recorder am
neuen Ort schreibt. Erst dann wird die alte Datenbank umbenannt — nicht
gelöscht. FAT/exFAT/NTFS werden abgelehnt; SQLite braucht ext4.

## Schreiblast auf der SD-Karte

Der Recorder hat keine eigenen Zwischendateien — seine Puffer liegen im RAM
und gehen alle 10 s per Commit in die Datenbank. Der eigentliche Zwischen-
speicher ist die WAL-Datei, die SQLite zwingend neben die Datenbank legt;
nach `migrate_db.py` liegt sie damit auf dem externen Medium. Zusätzlich:

- Sortierpuffer aller Verbindungen im RAM (`temp_store=MEMORY`), nicht in
  `/var/tmp`.
- Logdateien (`recorder.log`, `binance.log`, `watchdog.log`) wandern mit der
  Migration nach `<Ziel>/logs/`; einstellbar über `install.py --log-dir`.
- Was bewusst auf der SD-Karte bleibt: das tägliche Backup und das
  systemd-Journal. Wer auch das Journal von der SD-Karte nehmen will:
  `Storage=volatile` in `/etc/systemd/journald.conf` hält es im RAM
  (geht bei Neustart verloren).

## Auf dem Handy

Das Dashboard passt sich ab 700 px Breite an Handy-Bildschirme an: Bedien-
elemente untereinander mit großen Tippflächen, Kacheln in zwei Spalten, alle
Charts in voller Breite mit angepasster Höhe, Tooltips per Tippen. Geprüft in
Chromium bei 412×915 (6,8 Zoll) in beiden Lagen.

Zwei Wege aufs Handy, beide brauchen `--host 0.0.0.0` (die Unit setzt es):

- **Web-App ohne Installation:** Chrome → `http://<Pi-Adresse>:8765` → Menü
  ⋮ → „Zum Startbildschirm hinzufügen". Manifest und Icon liefert der Server.
- **Android-App:** der Ordner `android/` ist ein Android-Studio-Projekt (WebView
  mit Adressverwaltung, Ziehen-zum-Neuladen, Fehlermeldung). Bauen: Studio →
  Build → Build APK(s). Details in `android/README_APP.md`.

## Betrieb

Alles zusammen im Vordergrund, etwa in tmux oder einer SSH-Sitzung:

```bash
.venv/bin/python run_all.py --host 0.0.0.0
```

Der Supervisor startet Recorder, Binance-Stream und Dashboard, mischt deren
Ausgaben mit Präfix in ein Log und startet abgestürzte Teilprozesse mit
wachsender Wartezeit neu. Strg-C beendet alles sauber.

Für echten Dauerbetrieb über Neustarts hinweg stattdessen `install.py --enable`.

**Nicht beides gleichzeitig.** Laufen die systemd-Dienste, sind Recorder,
Binance-Stream und Dashboard bereits gestartet. `run_all.py` würde dieselben
Prozesse ein zweites Mal starten, und das Dashboard scheitert dann mit
`Address already in use`. Der Supervisor prüft das inzwischen vorab und
verweigert den Start mit einem Hinweis.

```bash
systemctl status hl-dashboard hl-recorder hl-binance   # laufen sie schon?
sudo systemctl stop hl-recorder hl-binance hl-dashboard # für den Supervisor
sudo ss -ltnp | grep 8765                              # wer hält den Port?
```

Einzeln geht weiterhin:

```bash
.venv/bin/python hl_recorder.py --status               # Fortschritt
.venv/bin/python hl_viz.py --serve --host 0.0.0.0      # nur Dashboard
```

### Takte — drei unabhängige Schleifen

| Was | Takt | Stellschraube |
|---|---|---|
| Adressabfragen | laufend, gestaffelt nach Größe | `--polls-per-min`, `--hot-refresh`, `--cold-refresh` |
| Heatmap-Snapshot | alle 10 min | `--snapshot-sec` |
| Bars und Liquidationen | fortlaufend aus dem Stream | — |
| Binance Open Interest | alle 10 min | `--oi-interval` |

Der Poller läuft dauerhaft, nicht im Snapshot-Takt. Große Positionen werden
alle 3 Minuten abgefragt, kleine alle 30, aufgegebene alle 2 Stunden. Ein
Snapshot ist deshalb ein Mosaik aus unterschiedlich alten Abfragen.

Bei 240 Abfragen pro Minute reicht das Budget für grob 500 große plus 2.000
kleine Adressen. Darüber hinaus dehnen sich die Abstände still aus. Der
Recorder meldet deshalb alle 10 Minuten das Datenalter, die Zahl überfälliger
Adressen und die Auslastung — steht dort dauerhaft über 90 %, hinkt er
hinterher.

Binance ergänzen (kein API-Key nötig):

```bash
.venv/bin/python hl_binance.py --backfill    # 30 Tage OI, Ratios, Kerzen
.venv/bin/python hl_binance.py               # Liquidationen live
.venv/bin/python hl_binance.py --status
```

Zeitbasierte Heatmap (braucht keine eigene Aufzeichnung, nutzt Binance-Historie):

```bash
.venv/bin/python hl_timestats.py --coin BTC --years 3 --png
.venv/bin/python hl_timestats.py --coin BTC --tz Europe/Berlin --json danger.json
```

Zählt je Wochentag und 30-Minuten-Fenster, wie oft die Bewegung 1 % bzw. 3 %
überschreitet. 7 × 48 = 336 Felder. Weil 336 gleichzeitige Tests bei 5 % Niveau
allein zufällig rund 17 Treffer erzeugen, rechnet das Skript
Wilson-Konfidenzintervalle mit Bonferroni-Korrektur und markiert nur Felder,
deren Untergrenze über der Grundrate liegt. Gegen reines Rauschen geprüft:
0 von 336 Feldern überleben die Korrektur.

Eine vorab formulierte Vermutung gezielt prüfen (ein Test statt 336, daher
ohne Korrektur und deutlich aussagekräftiger):

```bash
.venv/bin/python hl_timestats.py --coin BTC --no-fetch \
    --test-window 02:00-05:00 --tz Europe/Berlin --thresholds 0.01 0.03
```

Vergleicht das Fenster gegen den Rest des Tages, mit Konfidenzintervallen,
Zwei-Stichproben-Test und einer Aufschlüsselung Jahr für Jahr — letztere zeigt,
ob der Effekt stabil ist oder aus einem einzelnen Jahr stammt. Fenster über
Mitternacht hinweg und ein Wochentagsfilter (`--weekdays 0,1,2,3,4`) werden
unterstützt.

**Die Kernthese — Cluster als Magnet:**

```bash
.venv/bin/python hl_recorder.py --magnet-analyze --coin BTC
```

Je Stunde: größtes Short-Cluster oberhalb, größtes Long-Cluster unterhalb.
Welches wird zuerst erreicht? Drei Regeln im Vergleich — Größe (die These),
Nähe (reine Geometrie), Zufall. Entscheidend ist die Teilmenge, in der Größe
und Nähe *verschiedene* Ziele nennen; nur dort ist die These von der
Geometrie unterscheidbar. Die Messlatte dort ist nicht 50 %, sondern die
geometrische Erwartung eines driftlosen Pfads (d_nah / (d_nah + d_fern)).

Geprüft: Auf Zufallsdaten sieht die Größe-Regel naiv nach 60 % Treffern aus,
weil große Cluster meist auch nah sind — in der uneinigen Teilmenge bleibt
davon nichts über der Geometrie (z = 0,9). Auf Daten mit eingebautem Magneten
findet der Test ihn deutlich (z = 7,7).

Haben Wal-Aktionen Vorhersagekraft?

```bash
.venv/bin/python hl_recorder.py --whale-analyze --coin BTC
```

Misst die Kursbewegung nach jeder Wal-Aktion in der implizierten Richtung —
und dasselbe an zufälligen Zeitpunkten als Kontrollgruppe. Erst der Unterschied
sagt etwas: In einem steigenden Markt „haben" auch zufällige Longs meist recht.
Ein Blick auf die ersten fünf Minuten trennt Impact (die Wal-Order bewegt den
Kurs selbst) von Information (der Kurs läuft erst später). Und selbst ein
Vorsprung ist kein Insiderwissen: Ein großer Short kann eine abgesicherte
Spot-Position sein, und was jeder sehen kann, ist im Kurs meist schon drin.

Stimmen die Daten in sich?

```bash
.venv/bin/python hl_recorder.py --audit
```

Der Wächter fragt, ob die Daten frisch sind. Der Audit fragt, ob sie
*stimmen*: Sind alle Kerzen minutengenau, wie viele Minuten fehlen? Deckt der
Markpreis-Feed die Handelsminuten ab? Hat jeder Snapshot einen Qualitätsstempel,
und stimmt dessen Positionszahl exakt mit der Heatmap überein? Ist der
Snapshot-Takt regelmäßig, wie viele Neustarts gab es? Liegt die Abdeckung in
einem plausiblen Bereich? Hat jeder Wal einen sauberen Lebenszyklus — keine
doppelte Eröffnung, keine Änderung ohne Eröffnung? Gibt es Duplikate in den
Cluster-Events? Geprüft mit gezielt beschädigten Datenbanken: Alle eingebauten
Fehler werden gefunden.

Ergebnisse zum Weitergeben oder Hochladen exportieren:

```bash
.venv/bin/python hl_recorder.py --analyze --coin BTC     # zuerst labeln
.venv/bin/python hl_recorder.py --export export.zip      # dann exportieren
```

Die Datenbank wird nach Monaten hunderte Megabyte groß und ist nicht mehr
handhabbar. Das Export-Paket enthält nur die gelabelten Ereignisse und
Aggregate und bleibt bei wenigen hundert Kilobyte: `cluster_events.csv` mit
abgeleiteten Zeitspalten, Tagesabdeckung für Bars und Snapshots,
`time_heatmap.csv`, stündlich aggregierte Binance-Liquidationen und eine
`meta.json` mit Zeitraum, Umfang und Datenqualität. Rohdaten verlassen den
Pi nicht.

Nach einigen Wochen:

```bash
.venv/bin/python hl_recorder.py --analyze --coin BTC
.venv/bin/python hl_viz.py --coin BTC --hours 168
```

Backtest der Trendfolge, unabhängig vom Recorder:

```bash
.venv/bin/python hl_backtest.py --coin BTC --interval 4h --days 700 --plot
.venv/bin/python hl_backtest.py --spot --coin HYPE --interval 4h --days 700
```

## Wer steckt hinter einer Wallet?

Die Wal-Tabelle nennt je Wallet, wenn bekannt, den Namen dahinter — aus fünf
Quellen, in dieser Reihenfolge:

1. `labels.json` im Projektordner — eigene Pflege, hat Vorrang, wird von
   Updates nie überschrieben. Format: Adresse (klein) → `name`, `kategorie`,
   `quelle`. Vorbelegt mit den Protokolladressen von Hyperliquid (HLP-Vault,
   Assistance Fund, HLP-Strategie-Vaults).
2. Hyperliquid-Leaderboard — selbst gewählte Anzeigenamen; kein API-Gewicht,
   alle 6 h neu.
3. Etherscan-Namenstags über `octal.art/etherscan-labels` (Börsen, Fonds,
   Market Maker) und Arbiscan-Tags aus dem offenen Datensatz
   brianleect/etherscan-labels — dieselbe Adresse zahlt ihr USDC über Arbitrum
   ein, dort verrät die Herkunft oft den Besitzer.
4. `vaultDetails` — ist die Adresse ein Hyperliquid-Vault? Kostet API-Gewicht
   20 und teilt sich das Limit mit dem Recorder; deshalb höchstens eine
   Abfrage pro Minute, Ergebnis 7 Tage im Cache (`labels_cache.json`).
5. Verhaltensklasse aus den eigenen Daten: „Hedge-Muster" (mehrere Coins, eine
   Seite, Hebel ≤ 10 — typisch für Market Maker und Basis-Trader),
   „Market-Maker-Muster" (beidseitig viele ruhende Limits), „direktional".

Dazu je Wallet Links zu HypurrScan, Arbiscan und Arkham. „unbekannt" heißt:
keine Quelle kennt einen Namen — das ist bei den meisten Walen der Fall; die
Verhaltensklasse ist dann oft die nützlichere Information. Mit einem
Nansen- oder Arkham-Schlüssel ließe sich eine Entitätsabfrage anschließen.

## Dashboard

**Aufbau.** Ein Kopf, der beim Scrollen oben bleibt: Coin-Auswahl, „Neu laden"
und eine Navigation zu den sechs Abschnitten. Darunter die Kacheln, dann die
nummerierten Abschnitte — Live-Chart, Konfluenz, Orders & Stops, Heatmap,
Momentaufnahme, Wale — und ganz unten die Aktualisierung. Jeder Abschnitt
klappt am Titel ein und aus; der Zustand bleibt im Browser gespeichert. Das
„ⓘ" im Titel zeigt die Erklärung des Abschnitts. Bedienelemente stehen dort,
wo sie wirken: Raster, FVG-Schalter und FVG-Mindestgröße beim Chart, der
Zeitraum bei der Heatmap.

**Datenquelle.** Die Auswahl „Quelle" im Kopf schaltet alle Abschnitte um:

- *Hyperliquid Daten* — wie bisher: eigene Kerzen, erwartete Liquidations-
  cluster aus den Positionen, Orders der Großkonten, Wale.
- *Binance Daten* — Kerzen von Binance (live, sonst `bnc_bars`/`daily_bars`),
  Marken und Heatmap aus den **eingetretenen** Liquidationen
  (`bnc_liquidations`), Orderbuch mit Tiefe statt Konten-Orders, statt der Wale
  die Kennzahlen Open Interest, Long/Short (Konten, Top-Trader) und Taker-Flow
  (`bnc_metrics`, live nachgeladen). Konfluenz mit Binance-Regeln: Taker-Flow
  ±1, Top-Trader-Positionierung ±1, einseitige Konten als Hinweis, laufende
  Kaskade als „Abwarten".
- *Data Mix Fusion* — der Hyperliquid-Stand plus Binance und Crypto.com: Binance-Orderbuch
  je Preisstufe zu den Orders **addiert** (beides ruhende Orders), eingetretene
  Liquidationen beider Börsen als Marker im Chart (Binance orange, HL magenta)
  und in der Heatmap, Binance-Liquidationen der letzten 24 h als Overlay in der
  Momentaufnahme (nicht addiert — Erwartung und Ereignis sind verschiedene
  Größen), Volumen beider Börsen summiert, Binance-Kennzahlen unter den Walen,
  Konfluenz mit beiden Regelsätzen und Funding-Vergleich.

**Crypto.com als dritte Börse** (Binance- und Fusionsmodus): Open Interest,
24-h- und Stundenvolumen, Taker-Flow aus den letzten 150 Trades, Prämie des
Perpetuals gegen den Index (Funding-Näherung), Orderbuch — in der Fusion je
Preisstufe zu HL-Orders und Binance-Buch addiert. Die Konfluenz rechnet den
Taker-Flow **börsenübergreifend**, nach Volumen gewichtet, als einen Punkt;
sind die Börsen uneins, gibt es keinen Punkt, nur den Hinweis. Eine
gegenläufige Prämie zum Hyperliquid-Funding erscheint als Hinweis. Die
Marktdaten sind öffentlich — kein Schlüssel nötig. Coins, die Crypto.com nicht
handelt, zeigen „—".

**Bybit und OKX** (Binance- und Fusionsmodus, öffentliche Endpunkte, kein
Schlüssel): Open Interest, Funding, 24-h-Volumen, Long/Short-Konten, Taker-Flow
(Bybit aus 500 Trades, OKX aus der 5-min-Statistik), OKX zusätzlich die
jüngsten Liquidationen. Kacheln: „Open Interest N Börsen" mit Aufteilung,
„Taker börsenübergreifend" volumengewichtet, „Long/Short Konten je Börse",
„Funding Ø Börsen". Konfluenz: der Taker-Flow aller erreichbaren Börsen ist
ein Punkt; börsenübergreifend einseitige Konten (Ø ≥ 2,5 : 1 oder ≤ 0,6 : 1) und
OKX-Liquidationen ab 5 Mio/h sind Hinweise.

**ETF-Flows** (BTC und ETH, jede Quelle): tägliche Netto-Flüsse der US-Spot-
ETFs, einmal pro Stunde von der Farside-Tabelle gelesen; mit CoinGlass-Schlüssel
in `accesstokens.json` stattdessen von CoinGlass. Kachel mit letztem Tag,
5-Tage-Summe und Serie. Konfluenz: ein Punkt, wenn letzter Tag und 5-Tage-Summe
dasselbe Vorzeichen haben, sonst Hinweis. Ein Tageswert — Regime, nicht Timing.

**Leaderboard und Smart Money.** Beim Start lädt der Recorder das Leaderboard
**zuerst** — Konten, Positionen und die Trendzeile der laufenden Stunde stehen,
bevor Feeds und Polling beginnen; das Dashboard ist damit sofort vollständig.
Danach lädt der Recorder alle 10 Minuten das
Hyperliquid-Leaderboard, geht die Konten nach 30-Tage-PnL von oben durch und behält die ersten 50, die
auf dem Perp-Konto tatsächlich Positionen halten (`--lb-top`, aus den besten
400, `--lb-candidates`). Das ist nötig, weil das Leaderboard Spot, Vault-Anteile
und Unterkonten mitzählt — die Spitze nach PnL sind Vaults und Market Maker
ohne Perp-Position. Flache Konten werden eine Stunde gemerkt, damit die Auswahl
nicht jede Runde das volle Gewicht kostet (erster Durchgang bis zu 400 Abfragen,
danach etwa 60 je Runde). „Kontowert" ist das Perp-Konto (`marginSummary`),
nicht der Leaderboard-Wert. Tabellen: `lb_accounts` (Rang, Name,
Kontowert, PnL 30 T / 7 T), `lb_positions` (Coin, Seite, Wert, Hebel, Einstieg,
Liq.-Preis, unreal. PnL, Kurs) je Abfrage und `lb_trend` einmal pro Stunde je
Coin für Top 20 und Top 50: Konten und Wert je Seite, Netto, Kurs — die
Zeitreihe für die spätere Auswertung, ob die Positionierung der Besten dem Kurs
vorausläuft. Dashboard-Abschnitt 7 zeigt die Top 20 mit allen Positionen und
PnL (gruppiert wie die Wale, Export als Chart und Liste) und den Trend-Chart des
gewählten Coins: Long- und Short-Wert je Stunde, Netto als Linie, Kurs weiß.
Kachel „Leaderboard Top 20 — BTC-Trend“: Konten und Wert je Seite in BTC,
Netto und dessen Veränderung gegen 24 h und 7 Tage. Konfluenz: Drehung des
Netto-Vorzeichens oder Aufbau ≥ 25 % innerhalb 24 h als Hinweis. Die
Smart-Money-Kachel (Top 50) liest dieselbe Abfrage; Punkt ab 1,5-fachem Übergewicht.

**accesstokens.json** — eine normale Datei im Projektordner für Schlüssel
optionaler Quellen (CoinGlass, CryptoQuant, Glassnode, Nansen, Arkham), leer
vorbelegt; `update.py` überschreibt sie nie. Nichts davon ist heute nötig;
sobald ein Schlüssel eingetragen ist, kann die jeweilige Quelle angeschlossen
werden. Für Tests ohne Netz liefert `HL_TEST_STUBS=1` feste Crypto.com-Antworten.

Die Wahl bleibt im Browser gespeichert. Live-Abrufe von Binance (Kerzen kurzer
Raster, Orderbuch, Funding, Verhältnisse) werden 15 s bis 5 min im Speicher
gehalten; ohne Netz greift die Datenbank, das Orderbuch meldet sich dann ab.

**Debug-Konsole** (Abschnitt ganz unten): startet ein Diagnoseskript oder liest
ein Journal aus einer festen Liste — Leaderboard-Diagnose, Order-Abfragen,
Tageskerzen, Speicherbelegung, Recorder-Audit und -Status, Binance-Status,
Journale der drei Dienste, Update-Log, Dienststatus, Datenträger. Läuft als
Dashboard-Benutzer ohne sudo, kein freies Kommando. Die Ausgabe erscheint wie
im Terminal, „Kopieren" legt sie mit Kopfzeile (Lauf, Zeit, Coin, Quelle,
Exit-Code) in die Zwischenablage — zum Einfügen in den Chat. Journale
brauchen Leserecht (Gruppe `systemd-journal`: `sudo usermod -aG systemd-journal seed`).

**Fehlerleiste.** Rote Leiste oben bei Verbindungs- oder Skriptfehlern.
Verbindungsfehler verschwinden von selbst, sobald wieder Daten ankommen —
etwa wenn das Handy den Browser aus dem Hintergrund holt: Die Seite erkennt
den sichtbaren Tab, lädt sofort neu und räumt die Leiste mit der ersten
erfolgreichen Antwort weg. Skriptfehler bleiben stehen, die gehen nicht von
allein weg.

**PNG-Export.** Das „⤓" im Titel eines Abschnitts (und der Link unter dem
Binance-Kennzahlen-Chart) speichert den Chart als PNG in dreifacher
Auflösung — der Chart wird dafür neu gezeichnet, nicht hochskaliert, Linien
und Schrift bleiben scharf. Kopfzeile mit Titel, Coin, Quelle und Zeitstempel,
Dateiname `hl_<chart>_<coin>_<quelle>_<datum-uhrzeit>.png`. Bei 1.370 px
Chartbreite ergibt das rund 4.200 px Breite. Der Wal-Abschnitt hat zwei
Exporte: „⤓ Chart“ für das Exposure-Chart und „⤓ Liste“ für die gruppierte
Wal-Liste mit allen Positionen, Namen und Verhaltensklassen — bei sehr langen
Listen in mehreren Teilen (`_teil1`, `_teil2`), damit die Bildhöhe die
Browser-Grenze nicht überschreitet.

**Kacheln und Einheiten.** Jedes Label nennt die Einheit: USD für Kurs,
Notional, Volumen und Open Interest; Prozent für Trend und MA-Abstand;
„Anzahl" für Adressen; 0–100 für den RSI. Verhältnis-Kacheln (Long/Short
Konten, Long/Short Top-Trader, Taker Kauf/Verkauf) zeigen „a : 1" und darunter
die Aufteilung in Prozent — „1,27 : 1" heißt 56 % long, 44 % short. Jede
Kachel trägt die Definition als Tooltip (Maus darüber, am Handy lange
antippen). Die Binance-Verhältnisse stammen aus den Binance-Endpunkten
`globalLongShortAccountRatio` (Konten), `topLongShortPositionRatio`
(Positionswert der größten Konten) und `takerlongshortRatio` (aggressives
Kauf- zu Verkaufsvolumen, 5-min-Fenster).

**FVG-Mindestgröße.** Ein Fair Value Gap ist die Lücke zwischen dem Hoch von
Kerze 1 und dem Tief von Kerze 3 (bullisch) bzw. umgekehrt (bärisch). Die
Mindestgröße ist diese Lücke als Anteil des Kurses — 0,05 % bei 80.000 USD
sind 40 USD. Kleinere Lücken gelten als Rauschen und werden weder gezeichnet
noch in der Konfluenz gezählt.


Drei Panels auf `http://<pi>:8765`, jedes mit Überschrift, Legende und
Achsenbeschriftung. Mit der Maus darüberfahren oder antippen zeigt eine Box mit
den Werten an dieser Stelle — Zeitpunkt, Preisniveau, Notional, Perzentil-Rang
und Art der Liquidation.

- **Live-Chart** — Kerzen mit den aktuellen Liquidationslevels als waagerechte
  Linien. Rot unterhalb des Kurses sind Long-Liquidationen, grün oberhalb
  Short-Liquidationen. Durchgezogene Linien liegen bei mindestens dem halben
  Stundenvolumen und können den Kurs bewegen, gestrichelte werden eher
  absorbiert. Aktualisiert alle 5 Sekunden, Zeitraster von 1 min bis 1 h.
- **Fair Value Gaps** im Live-Chart, rein aus den Kerzen berechnet, nichts
  wird gespeichert. Dreikerzen-Lücken: bullisch, wenn das Tief der dritten
  Kerze über dem Hoch der ersten liegt, bärisch spiegelbildlich. Offene Zonen
  kräftig mit gestricheltem Rahmen und Teilfüllungsbalken, gefüllte blass bis
  zur füllenden Kerze. Ein Schalter neben der Coin-Auswahl blendet sie ein oder aus,
  die Mindestgröße ist wählbar (0,05 / 0,1 / 0,25 %). Die Infozeile nennt offene Zonen je Richtung und die nächste zum Kurs;
  der Tooltip zeigt Zone, Größe und Füllgrad.
- **Chart-Raster** — 1 min bis 1 h aus den eigenen Minutenbars; dazu
  „4 h · 30 Tage", „1 Tag · 1 Jahr" und „1 Woche · 5 Jahre" aus den
  vorhandenen Tabellen: 4 h aus `klines30` (Binance-30-min-Kerzen, falls
  `hl_timestats` sie geladen hat), die jüngsten Stunden aus den eigenen Bars;
  Tage und Wochen aus `daily_bars` (5 Jahre, von `hl_binance`). Fehlt eine
  Tabelle, holt das Dashboard die Kerzen direkt von Binance (5 min im
  Speicher gehalten). Die Infozeile nennt die Quelle, die Zeitachse zeigt bei
  Tagen und Wochen das Datum.
- **Gleitende Durchschnitte** — zwei Kacheln in der Kopfzeile: MA 50 Wochen
  und MA 200 Tage, grün mit ▲ wenn der Kurs darüber steht, rot mit ▼ darunter,
  jeweils mit Abstand in Prozent. Der Tooltip zeigt zusätzlich MA 50 Tage und
  MA 200 Wochen sowie Golden/Death Cross. Berechnet aus Tageskerzen in
  `daily_bars`, die `hl_binance.py` beim Start und alle 6 h nachlädt (5 Jahre;
  Quelle je Coin: Binance-Futures, sonst Binance-Spot, sonst Hyperliquid —
  XMR etwa führt Binance nicht mehr). Primärschlüssel (Tag, Coin), Nachladen
  ersetzt statt zu doppeln. Manuell: `hl_binance.py --backfill-daily`.
  Liegen die Linien im sichtbaren Preisbereich, erscheinen sie gestrichelt
  im Chart.
- **Stop-Orders der Wale** — eigenes Panel. Trigger-Orders stehen nicht im
  Orderbuch; sie werden erst am Auslösepreis zu Market-Orders, wie
  Liquidationen. Der Recorder fragt alle Adressen mit Positionen ab 20 Mio USD
  alle 2 Minuten nach ihren offenen Orders (`frontendOpenOrders`, Gewicht 20)
  und speichert sie in `trigger_orders`. Das Panel zeigt je Preisniveau
  Sell-Stops (rot, Verkaufskaskade nach unten), Buy-Stops (grün, Kaufkaskade
  nach oben), Take-Profits (grau, absorbieren) und Limit-Orders (blau) mit
  Notional, Zahl der Wale und Abstand zum Kurs. Budget über `--stop-budget`
  (Gewicht/min, Standard 240) und `--stop-interval`.
- **API-Budget** — Kachel mit dem Hyperliquid-Gewicht der letzten Minute
  gegen das Limit von 1200 (grün unter 70 %, gelb bis 90 %, rot darüber).
  Der Limiter rechnet jetzt in Gewicht: Positionsabfrage 2, Order-Abfrage 20.
  Wächter und Audit warnen ab 80 %.
- **Wartende Orders und Stops** — eigenes Panel: Sell-Stops (rot, Verkaufs-
  kaskade), Buy-Stops (grün, Kaufkaskade), Limit-Käufe (cyan, Kaufwand),
  Limit-Verkäufe (violett, Verkaufswand), Take-Profits (grau). Kaufseite links,
  Verkaufsseite rechts einer Mittelachse, je Preisstufe ein nach Art gestapelter
  Balken, fester Preisbereich ±30 %. Darunter die Live-Auswertung: Support
  (größte Kaufwand unter dem Kurs), Resistance (größte Verkaufswand darüber),
  höchste Take-Profits beider Seiten, größte und nächste Stop-Cluster, Stop-
  Summen innerhalb 2 %. Dieselben Niveaus erscheinen als beschriftete Linien im
  Live-Chart (Support cyan, Resistance violett, Take-Profits grau gestrichelt,
  Stops gepunktet) und gehen in die Konfluenz ein. Fahren oder Tippen zeigt in
  allen vier Charts ein Fadenkreuz mit dem Preis am Rand. Quelle ist `frontendOpenOrders` je Adresse — Trigger-
  Orders stehen nicht im Orderbuch, nur dort. Abgefragt werden alle Konten ab 250k USD,
  gestaffelt nach Größe — ab 20 Mio alle 10 min, 5–20 Mio alle 45 min, 1–5 Mio alle
  3 h, darunter alle 6 h — in einem Gewichtsbudget von 320/min (`--stop-budget`,
  `--stop-min-usd`, `--stop-interval`). Bei ~1.200 Kandidaten ist ein einheitlicher
  Takt unmöglich; das Panel zeigt je Konto den jüngsten Stand und dessen Alter.
  Tabelle `trigger_orders`, jede Abfrage als Zeitscheibe. Dazu alle 10 Minuten
  `order_levels`: Support, Resistance, Take-Profit- und Stop-Niveaus, Stop-Summen
  innerhalb 2 % und der Ordermix (Notional je Art innerhalb ±30 %) je Coin — mit
  derselben Rechnung wie das Dashboard, als Zeitreihe neben der Heatmap. Damit
  lässt sich später prüfen, ob der Kurs zum Liquidationscluster, zur Kaufwand
  oder zum Stop-Cluster zog, und wie sich der Ordermix vorher verhielt.
- **API-Last / Minute** — Kachel mit verbrauchtem Gewicht, Prozent und Reserve.
  Der Recorder deckelt sich selbst bei 85 % der 1.200 Einheiten; Positions-
  abfragen (Gewicht 2) und Order-Abfragen (Gewicht 20) teilen sich den Deckel,
  Wale werden nie von Großkonten verdrängt. Der Wächter warnt ab 85 %.
- **Konfluenz** — eine Kachel plus ein Panel, das zählt, wie viele der
  sichtbaren Faktoren in dieselbe Richtung zeigen: frisch abgeräumte
  Liquidationscluster, offene FVGs am Kurs, RSI-Extreme, Orderbuch-Imbalance,
  Funding, Ausrichtung der direktionalen Wale (Hedges und Market Maker ausgenommen), Lage des Kurses zum MA 200 Tage und zum MA 50
  Wochen (je ein Punkt), Kauf-/Verkaufswände aus ruhenden Limit-Orders (je ein
  Punkt), Stop-Cluster dicht am Kurs („Abwarten", Kaskade droht; zusammen mit
  einem Liquidationscluster auf derselben Seite „doppelter Magnet"),
  Take-Profits als Hinweis. Ein großes Cluster dicht am Kurs ergibt — ebenso
  große Wal-Stops innerhalb 0,8 % (ab 25 % des Stundenvolumens, mindestens
  5 Mio); liegen Stops und Liquidationscluster auf derselben Seite, meldet
  das Panel einen „doppelten Magneten". Solche Fälle ergeben
  „Abwarten — Anlauf wahrscheinlich" statt einer Richtung. Ab drei Punkten
  netto steht „Kauf-" oder „Verkaufs-Konfluenz". Jede Regel und jede Schwelle
  steht im Panel. Trägt ein Faktor ein Preisniveau — Kaskadentief, Squeeze-Hoch,
  FVG am Kurs — wird es als Kauf- oder Verkaufszone im Chart eingezeichnet — als
  Fenster am rechten Rand über die letzten Kerzen, nicht als Band über die
  Historie, denn die Zone ist ein Zustand jetzt.
  Stammen die Punkte nur aus Wale, Orderbuch, Funding oder RSI, gibt es keine
  Zone, und das Panel sagt warum. Eine Danger-Time aus der Zeit-Heatmap
  erscheint als Warnung ohne Richtung. **Das ist eine Zählung sichtbarer Faktoren, keine Prognose
  und nicht validiert** — die zugrunde liegende These ist genau das, was der
  Recorder erst noch belegen muss.
- **Heatmap** — Cluster über die Zeit, mit Kurslinie und eingetretenen
  Liquidationen. Die Farbe richtet sich nach dem *Rang* einer Zelle unter
  allen anderen, nicht nach ihrem Absolutwert, und wird zusätzlich mit einer
  Potenz gestaucht — sonst leuchtet die ganze Fläche gleichmäßig. Der Regler
  „Liquiditäts-Schwelle" blendet alles unterhalb eines Perzentils aus
  (Standard 70). Für die PNG-Variante: `--threshold 0.9`.
- **Depth** — Schnitt durch den aktuellen Moment, alle Level nach Notional.
- **Kennzahlenleiste** — neben Kurs, Cluster-Summen und Adressen auch der
  60-Minuten-Trend, der RSI 14 auf dem gewählten Raster, das letzte Backup
  (grün unter 26 h, gelb bis 50 h, danach rot) und der Zustand der Datenbank
  per `quick_check`, stündlich geprüft. Beim Darüberfahren stehen Details.
- **Wale** — Netto-Ausrichtung aller Positionen ab 20 Mio. USD gegen den
  Kurs, darunter jede offene Wal-Position mit Einstieg, Liquidationspreis,
  Abstand dorthin und unrealisiertem PnL, und die letzten Änderungen.

## Tick-Aufzeichnung bei Kaskaden

Minutenkerzen reichen für die Cluster-Frage, nicht aber, um einen Flash-Crash
Tick für Tick nachzuspielen. Der Recorder hält deshalb die letzten 30 Minuten
aller Rohtrades der verfolgten Coins im Speicher. Erkennt er eine schnelle
Bewegung — 1 % in 60 s, 0,4 % in 10 s oder fünf Liquidations-Fills in 30 s —
sichert er das Fenster von 5 Minuten davor bis 10 Minuten danach in `ticks`,
parallel dazu die Markpreise in `mark_ticks`. Hält die Bewegung an, verlängert
sich der Nachlauf; bei ruhigem Handel endet er. Ein Ereignis je Bewegung, kein
Doppelauslösen. Schwellen über `--tick-move`, `--tick-flash`, `--tick-liqs`,
Fenster über `--tick-pre`, `--tick-post`.

Was zusätzlich mitläuft, damit sich der Zeitraum *vor* einem Crash erkennen
und das *Ende* treffen lässt:

- **Orderbuch-Kennzahlen alle 5 s** (`book_summary`): Tiefe in USD innerhalb
  10, 25, 50 und 100 Basispunkten je Seite, Spread, Imbalance. Ausdünnende
  Bid-Tiefe und kippende Imbalance sind die verlässlichsten Vorläufer.
  In Ereignisfenstern zusätzlich vollständige Top-10-Snapshots (`book_ticks`),
  damit sich der Füllpreis eines eigenen Verkaufs oder Kaufs realistisch
  simulieren lässt.
- **10-Sekunden-Bars mit Aggressorseite** (`bars10`): Taker-Käufe gegen
  Taker-Verkäufe, Liquidationsfills und -notional, größter Einzeltrade.
  Aussetzende Liquidationsfills und ein Volumenhöhepunkt markieren das Ende.
- **Nähe zum Cluster je Minute** (`proximity`): größtes Cluster über und unter
  dem Kurs innerhalb 5 %, mit Abstand — die Größe für die Magnet-These in
  hoher Auflösung.
- **Kontrollfenster**: ein- bis zweimal täglich ein zufälliges Fenster ohne
  Auslöser. Ohne diese Fälle kennt eine Simulation nur die Treffer, nie die
  Fehlalarme.

Für Simulationen: `--export --with-ticks` gibt Rohtrades, Buch-Snapshots und
die drei Zeitreihen mit. Ohne den Schalter enthält der Export nur die
Ereignisliste.

**Hinweis zu PAXG.** Gold-gebunden, daher schwankungsarm und auf Hyperliquid
dünn gehandelt. Zwei Folgen: Die Tick-Auslöser (1 %/60 s, 0,4 %/10 s) greifen
dort selten, und wenn, dann eher durch Einzeltrades in einem leeren Buch als
durch Kaskaden. Und die Liquidationscluster fallen klein aus. Für die
Cluster-These ist PAXG damit ein Randfall — interessant eher als Vergleich
zu BTC bei Makro-Ereignissen als als eigenständiges Handelsziel. Auf Binance
wird PAXG nur aufgezeichnet, wenn dort ein USDT-Perp existiert; sonst
überspringt das Modul den Coin mit Meldung.

## Verbindungen zum Router

Der Recorder hält höchstens sechs gleichzeitige HTTP-Verbindungen und
verwendet sie wieder (Keep-Alive 120 s). Ohne diese Begrenzung öffnete jede
Abfragerunde bis zu 80 neue TCP+TLS-Verbindungen — rund 20.000 pro Stunde.
Das heizt die CPU (TLS-Handshakes) und füllt die NAT-Tabelle eines
Heimrouters; ist sie voll, bekommt jedes Gerät im Haus für neue Verbindungen
ein Timeout, minutenlang auch nach dem Stoppen des Recorders. Prüfen auf dem
Pi mit `ss -s`: die Zahl bei `timewait` sollte zweistellig bleiben. Ist der
Router einmal voll, hilft sein Neustart sofort.

## Liquidationen — woher sie kommen

Der öffentliche Trade-Feed von Hyperliquid kennzeichnet Liquidationen nicht
(`WsTrade` hat nur coin, side, px, sz, hash, time, tid, users). Bis zum 8.9.
blieb die Tabelle `liquidations` deshalb leer — die Marker in der Heatmap,
`n_liqs` der Tick-Ereignisse und der Liquidations-Auslöser hingen an einem
Feld, das nie kommt. Seitdem zwei eigene Quellen:

- **`userEvents`-Abos** für Wale und Konten ab 250k (bis 600, `--max-event-subs`):
  Fills mit `liquidation`-Objekt in Echtzeit, kostet kein REST-Gewicht. Diese
  Liquidationen speisen auch die 10-s-Bars und den Liquidations-Auslöser.
- **Ableitung aus dem Polling** für alle anderen Konten: Position zwischen zwei
  Abfragen verschwunden oder auf unter 10 % geschrumpft, und der Kurs hat in
  der Zwischenzeit den Liquidationspreis berührt (Minutenkerze) → Liquidation,
  `method = inferred`, Zeitpunkt = berührende Kerze. Verzögert um das
  Abfrageintervall, dafür vollständig.

Der Audit weist beide Anteile aus.

## Datenqualität — was der Recorder dafür tut

- **Abdeckung wird gemessen.** Zu jedem Snapshot steht in `coverage`, welchen
  Anteil des offiziellen Open Interest die verfolgten Positionen ausmachen. Das
  verwandelt eine unbekannte Unvollständigkeit in eine Zahl — und sagt, ab wann
  die Heatmap repräsentativ ist. Der Wächter warnt unter 25 %.
- **Markpreis statt Handelspreis.** Liquidationen lösen am Markpreis aus. Aus
  `activeAssetCtx` werden Mark-, Oracle- und Mid-Preis, Funding und Open
  Interest je Minute in `ctx_bars` festgehalten, damit die Berührungserkennung
  denselben Preis nutzt wie die Börse.
- **Cross oder isoliert.** Der Liquidationspreis einer Cross-Margin-Position
  hängt am ganzen Konto und wandert, ohne dass sich die Position ändert. Die
  Heatmap speichert je Zelle den Cross-Anteil, damit sich stabile von
  wandernden Clustern trennen lassen.
- **Priorität nach Größe.** Vier Stufen nach Positionswert zum Markpreis:
  Wale ab 20 Mio. USD alle 60 s, große ab 250k alle 3 min, mittlere ab 25k
  alle 30 min, darunter nur noch alle 2 h. Das Budget fließt nach oben
  (`--whale-notional`, `--hot-notional`, `--min-notional`).
- **Wal-Protokoll.** Positionen über der Wal-Schwelle landen in
  `whale_positions` — nur Änderungen (öffnet, stockt auf, reduziert, schließt,
  dreht) plus ein Zeitreihenpunkt je Snapshot. Änderungen unter 2 % gelten als
  Rauschen. Hysterese: Wer einmal Wal war, bleibt bis unter die halbe Schwelle
  in Beobachtung.
- **Breite Adress-Entdeckung.** Standardmäßig werden alle Perp-Feeds
  abonniert, nicht nur die verfolgten Coins. Wer BTC hält, handelt vielleicht
  gerade nur SOL — sonst bliebe seine BTC-Position unsichtbar. Bars entstehen
  weiterhin nur für die verfolgten Coins. Abschaltbar mit `--no-discover-all`.
- **Alterung.** Positionsdaten, die älter als `--max-pos-age` sind (Standard
  1 h), gehen nicht in den Snapshot. Ein Wallet kann längst geschlossen haben,
  ohne dass wir es wissen. Lieber ein dünnerer, ehrlicher Snapshot.
- **Qualitätsstempel.** Jeder Snapshot trägt in `snapshot_meta` mit, wie alt
  die Daten waren, wie viele Positionen wegen Alter fehlten, wie groß der
  Rückstand war und wie lange der Prozess schon lief. Damit lassen sich
  Snapshots nach einem Neustart oder aus der Anlaufphase später ausschließen.
- **Abfragereihenfolge in drei Gruppen mit festem Budgetanteil.** Adressen
  mit Position (65 %): fällige Wale immer zuerst, dann nach Überfälligkeit
  relativ zum Intervall ihrer Stufe. Nie abgefragte Adressen (25 %): älteste
  zuerst — ohne festen Anteil würden sie mit „unendlicher" Überfälligkeit
  alles verdrängen. Bekannt leere Adressen (10 %): nur, wenn sie seit der
  letzten Abfrage wieder gehandelt haben, sonst höchstens einmal täglich.
  Eine leere Adresse ohne neuen Trade kann keine neue Position haben — wir
  sehen ja alle Feeds. Das macht die breite Entdeckung erst tragbar: Zehn-
  tausende Staubadressen kosten danach praktisch nichts mehr.
- **Hebel und Einstieg je Zelle.** Die Heatmap speichert den
  notional-gewichteten Hebel und Einstiegskurs. Ein Cluster aus 50x-Positionen
  verhält sich anders als einer aus 3x-Positionen.
- **Kein Doppelzählen.** `--analyze` ersetzt die Ereignisse eines Coins statt
  sie anzuhängen.

## Wie die Aufzeichnung funktioniert

1. Der WebSocket-Feed `trades` liefert zu jedem Trade die Wallet-Adressen.
   Daraus wächst ein Adressregister.
2. `clearinghouseState` liefert pro Adresse die offenen Positionen mit dem
   echten `liquidationPx` — anders als CEX-Heatmaps ist das keine Schätzung.
3. Alle Liquidationspreise werden in ein logarithmisches Preisraster
   aggregiert und alle fünf Minuten als Snapshot gespeichert.
4. Parallel laufen 1-Minuten-Bars aus dem Trade-Feed mit, damit sich später
   Forward-Returns berechnen lassen.

## Pi-spezifische Hinweise

**Backup.** Der Recorder erstellt fünf Minuten nach dem Start und danach
täglich eine Kopie nach `dbbackup/hl_liq_backup.db`, im laufenden Betrieb
über die SQLite-Backup-API — in einem einzigen Schritt. Schrittweise mit
Pausen wäre eine Endlosschleife: Ändert eine andere Verbindung die Quelle
zwischen zwei Schritten, beginnt die API von vorn, und der Recorder schreibt
alle 10 s. Dauer = Datenbankgröße geteilt durch die Schreibgeschwindigkeit
des Zielmediums, bei 1,5 GB auf SD-Karte ein bis drei Minuten, danach die
Integritätsprüfung. Die Kopie wird erst mit `integrity_check`
geprüft und ersetzt das alte Backup nur, wenn sie in Ordnung ist — eine
bereits beschädigte Datenbank kann das letzte gute Backup also nicht
überschreiben. Manuell: `hl_recorder.py --backup`. Der Zielordner lässt
sich mit `--backup-dir` festlegen; der Recorder trägt ihn beim Start in die
Tabelle `meta` ein, und Dashboard, Wächter und Audit lesen ihn dort — eine
Quelle für alle. Liegt die Datenbank auf einem USB-Medium, gehört das Backup
auf die SD-Karte des Pi (`migrate_db.py` richtet das so ein): Ein Backup auf
demselben Datenträger schützt vor Beschädigung, nicht vor dessen Ausfall.
Der Recorder meldet beim Start, ob beides auf demselben Datenträger liegt. Wiederherstellen: Dienste stoppen, Datei kopieren, starten.

**Arbeitsspeicher.** 4 GB reichen deutlich. Gemessen auf einer Datenbank mit
90 Tagen Aufzeichnung (2,8 Mio. Heatmap-Zeilen, 223 MB):

| Prozess | Spitzenspeicher |
|---|---|
| Recorder mit 20.000 Adressen / 40.000 Positionen | 44 MB |
| Dashboard, auch bei 7-Tage-Ansicht | 108 MB |
| Binance-Stream | rund 40 MB |
| `--analyze` über 90 Tage | 173 MB, 6 s |

Zusammen unter 400 MB. Ein kleineres Snapshot-Intervall erhöht den Bedarf
leicht, weil mehr Zeilen entstehen — es senkt ihn nicht.

**Datensicherheit bei Neustart und Stromausfall.** Die Datenbank läuft im
WAL-Modus. Bars, Liquidationen und Adressen werden alle 10 Sekunden committet
(`--flush-sec`), die WAL-Datei alle 15 Minuten zusammengefaltet, damit sie
nicht unbegrenzt wächst.

| Fall | Verlust |
|---|---|
| Geplanter Neustart (systemd sendet SIGTERM) | nichts |
| Absturz eines Dienstes | nichts, der Supervisor startet neu |
| Harter Stromausfall | bis zu 10 Sekunden |
| Stromausfall mit `--durable` | nichts, dafür mehr Schreibzugriffe |

Getestet mit SIGKILL mitten im Schreibbetrieb: Die Datenbank bestand danach
in allen Läufen `PRAGMA integrity_check`, und die vor dem letzten Commit
geschriebenen Daten waren vollständig vorhanden.

`--durable` schaltet auf `synchronous=FULL`, also fsync bei jedem Commit. Auf
einer USB-SSD unproblematisch, auf einer SD-Karte erhöht es den Verschleiß
spürbar.

**SD-Karte.** Der Recorder schreibt dauerhaft. Bei drei Coins wächst die
Datenbank bei 10-Minuten-Snapshots um etwa 0,2 GB pro Monat. Auf einem
124-GB-Datenträger reicht das für Jahre. Für Monatsbetrieb eine USB-SSD verwenden
und `--db /pfad/zur/ssd/hl_liq.db` setzen.

**Uhrzeit.** Ohne NTP-Synchronisation sind die Zeitstempel wertlos.
`sudo timedatectl set-ntp true`, das Installskript prüft es.

**Dashboard im Netz.** `--host 0.0.0.0` macht es im LAN erreichbar, ohne
Passwort. Nur im eigenen Heimnetz betreiben, nicht ins Internet stellen.

**Dauerbetrieb.** `install.py --enable` richtet drei systemd-Dienste mit
`Restart=always` ein, damit Recorder, Binance-Stream und Dashboard Neustarts
und getrennte SSH-Sitzungen überleben.

## Alarm bei Ausfällen

```bash
.venv/bin/python hl_watchdog.py --once                # einmalig prüfen
.venv/bin/python hl_watchdog.py --test-alarm          # Signalgeber testen
```

Zwei Ebenen, weil eine allein nicht genügt:

**Lokal** — Alarmton über die Audioausgabe, alle 120 Sekunden wiederholt,
solange die Störung anhält (`--alarm-interval`). Bei Warnung ein aufsteigender
Zweiklang, bei kritischem Zustand eine Sirene, beides aus Rechteckschwingungen
im Stil der 8-Bit-Ära und zur Laufzeit erzeugt. Funktioniert ohne Internet,
also gerade dann, wenn der Ausfall die Verbindung betrifft.

> Der Raspberry Pi 5 hat **keinen eingebauten Lautsprecher** und seit dem
> Modell 5 auch keine 3,5-mm-Klinkenbuchse mehr. Ton braucht HDMI mit
> angeschlossenem Bildschirm, einen USB-Soundstick, Bluetooth oder ein
> I2S-DAC-HAT. `hl_watchdog.py --test-alarm` sagt dir, was gefunden wurde.
> Ohne Audioausgabe bleiben die ACT-LED (`--led`) und der Totmannschalter.

Nötig ist ein Abspielprogramm: `sudo apt install alsa-utils`. Optional lässt
sich zusätzlich ein Summer an einem GPIO-Pin betreiben (`--buzzer 18`), auf
dem Pi 5 über `gpiozero` mit `lgpio`.

**Extern** — ein Lebenszeichen an einen Dienst wie healthchecks.io
(`--heartbeat https://hc-ping.com/UUID`). Der Wert liegt im Ausbleiben: Ist
der Pi tot oder offline, alarmiert der Dienst dich. Das ist die einzige Ebene,
die einen Totalausfall überhaupt melden kann. Zusätzlich Push über
`--ntfy DEIN-TOPIC`, solange die Verbindung steht.

Geprüft werden Alter der Bars und Snapshots, stille Einzel-Feeds, Rückstand
des Pollers, Binance-Daten, Plattenplatz, NTP-Synchronisation und der Zustand
der systemd-Dienste. Die Verbindungsprüfung verlangt den erwarteten Inhalt,
nicht nur einen Statuscode — ein Captive Portal oder eine Router-Fehlerseite
antwortet sonst mit HTTP 200 und sähe wie eine intakte Verbindung aus.

## Wie Cluster und Kurs zusammenfinden

Alle Zeitstempel sind Unix-Sekunden, also zeitzonenfrei — die Systemzeitzone
des Pi spielt keine Rolle. Zu jedem Heatmap-Snapshot sucht die Auswertung per
Binärsuche die passende Minutenkerze und leitet daraus Abstand zum Cluster,
Stundenvolumen und Forward-Returns ab.

Eine Bar entsteht aber nur, wenn in der Minute gehandelt wurde. In dünnen
Märkten und Nachtstunden kann die nächste Kerze Minuten entfernt liegen —
ihr Preis gehört dann nicht mehr zum Snapshot. Liegt der Abstand über
`--max-gap` (Standard 120 s), wird das Ereignis verworfen und am Ende
gemeldet, statt still mit falschem Bezug zu rechnen.

Voraussetzung dafür ist eine korrekt gehende Uhr: Die Bars tragen Börsenzeit,
die Snapshots die Zeit des Pi. Driftet sie, passt die Zuordnung nicht mehr.
Deshalb prüft der Wächter die NTP-Synchronisation.

## Zwei Datenquellen, getrennt gehalten

Hyperliquid liefert **gemessene** Positionen mit echtem Liquidationspreis,
Binance liefert **aggregierte** Marktdaten und Liquidationsereignisse. Beides
landet in derselben Datei, aber in getrennten Tabellen (`heatmap` gegen
`bnc_*`). Nicht vermischen — die Aussagekraft ist unterschiedlich.

Rückwirkend abrufbar sind bei Binance nur Open Interest, Long/Short-Ratios und
Kerzen. Liquidationen gibt es dort nicht als Verlauf, die sammelt nur der
Live-Stream. Und Binance pusht je Symbol nur die größte Order pro Sekunde: Das
gespeicherte Kaskadenvolumen ist eine Untergrenze, kein exakter Wert.

## Grenzen

Die Heatmap ist unvollständig. Sichtbar werden nur Wallets, die gehandelt
haben, während der Recorder lief. Die Abdeckung wächst über Wochen, wird aber
nie vollständig — für relative Verteilungen reicht das, für absolute
Notional-Zahlen nicht.

Historische Positionsdaten gibt es nicht. Die These lässt sich nur vorwärts
prüfen, nicht rückwirkend. Zwei bis drei Monate sind ein realistischer
Zeitraum, bevor die Zahlen etwas bedeuten, weil Marktphasen stark korrelieren.

Handel mit Perpetuals und Kryptowährungen kann zum Totalverlust führen. Diese
Werkzeuge treffen keine Aussage darüber, ob eine Strategie funktioniert —
sie helfen nur beim Messen.
