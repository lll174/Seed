# Hyperliquid — Liquidationscluster aufzeichnen und auswerten

Werkzeuge, um zu prüfen, ob Liquidationscluster auf Hyperliquid Vorhersagekraft
haben, und um darauf aufbauend eine Handelslogik zu testen.

Zielplattform: Raspberry Pi 5, Debian 13 (Trixie), 64 Bit. Läuft ebenso auf
jedem Debian/Ubuntu mit Python ab 3.11.

## Dateien

| Datei | Zweck |
|---|---|
| `install.py` | Einrichtung, Abhängigkeiten, Selbsttest, systemd |
| `requirements.txt` | Python-Pakete |
| `hl_recorder.py` | zeichnet Cluster live auf, labelt sie im Analysemodus |
| `hl_viz.py` | Live-Chart, Heatmap-PNGs und Dashboard |
| `hl_watchdog.py` | Wächter mit Summer, LED, Push und Totmannschalter |
| `run_all.py` | startet und überwacht alle Dienste gemeinsam |
| `hl_binance.py` | Binance-Liquidationen live, Marktdaten 30 Tage rückwirkend |
| `hl_timestats.py` | zeitbasierte Heatmap: wann Bewegungen gehäuft auftreten |
| `hl_backtest.py` | Trendfolge-Backtest für Perps und Spot |

## Installation

```bash
python3 install.py            # venv, Pakete, Selbsttest
python3 install.py --enable   # zusätzlich: Autostart beim Booten einrichten
python3 install.py --check    # nur prüfen, nichts verändern
```

`--enable` erzeugt die systemd-Units, kopiert sie nach `/etc/systemd/system`,
aktiviert sie und prüft anschließend, ob alle drei laufen. Danach starten
Recorder, Binance-Stream und Dashboard automatisch bei jedem Boot.

Debian Trixie erlaubt kein `pip install` in die System-Python-Installation
(PEP 668). Das Skript legt deshalb ein venv unter `.venv/` an. Alle Aufrufe
danach über `.venv/bin/python`.

## Betrieb

Alles zusammen im Vordergrund, etwa in tmux oder einer SSH-Sitzung:

```bash
.venv/bin/python run_all.py --host 0.0.0.0
```

Der Supervisor startet Recorder, Binance-Stream und Dashboard, mischt deren
Ausgaben mit Präfix in ein Log und startet abgestürzte Teilprozesse mit
wachsender Wartezeit neu. Strg-C beendet alles sauber.

Für echten Dauerbetrieb über Neustarts hinweg stattdessen `install.py --enable`.

Einzeln geht weiterhin:

```bash
.venv/bin/python hl_recorder.py --status               # Fortschritt
.venv/bin/python hl_viz.py --serve --host 0.0.0.0      # nur Dashboard
```

### Takte — drei unabhängige Schleifen

| Was | Takt | Stellschraube |
|---|---|---|
| Adressabfragen | laufend, gestaffelt nach Größe | `--polls-per-min`, `--hot-refresh`, `--cold-refresh` |
| Heatmap-Snapshot | alle 10 min | `--snapshot-sec` |
| Bars und Liquidationen | fortlaufend aus dem Stream | — |
| Binance Open Interest | alle 10 min | `--oi-interval` |

Der Poller läuft dauerhaft, nicht im Snapshot-Takt. Große Positionen werden
alle 3 Minuten abgefragt, kleine alle 30, aufgegebene alle 2 Stunden. Ein
Snapshot ist deshalb ein Mosaik aus unterschiedlich alten Abfragen.

Bei 240 Abfragen pro Minute reicht das Budget für grob 500 große plus 2.000
kleine Adressen. Darüber hinaus dehnen sich die Abstände still aus. Der
Recorder meldet deshalb alle 10 Minuten das Datenalter, die Zahl überfälliger
Adressen und die Auslastung — steht dort dauerhaft über 90 %, hinkt er
hinterher.

Binance ergänzen (kein API-Key nötig):

```bash
.venv/bin/python hl_binance.py --backfill    # 30 Tage OI, Ratios, Kerzen
.venv/bin/python hl_binance.py               # Liquidationen live
.venv/bin/python hl_binance.py --status
```

Zeitbasierte Heatmap (braucht keine eigene Aufzeichnung, nutzt Binance-Historie):

```bash
.venv/bin/python hl_timestats.py --coin BTC --years 3 --png
.venv/bin/python hl_timestats.py --coin BTC --tz Europe/Berlin --json danger.json
```

Zählt je Wochentag und 30-Minuten-Fenster, wie oft die Bewegung 1 % bzw. 3 %
überschreitet. 7 × 48 = 336 Felder. Weil 336 gleichzeitige Tests bei 5 % Niveau
allein zufällig rund 17 Treffer erzeugen, rechnet das Skript
Wilson-Konfidenzintervalle mit Bonferroni-Korrektur und markiert nur Felder,
deren Untergrenze über der Grundrate liegt. Gegen reines Rauschen geprüft:
0 von 336 Feldern überleben die Korrektur.

Eine vorab formulierte Vermutung gezielt prüfen (ein Test statt 336, daher
ohne Korrektur und deutlich aussagekräftiger):

```bash
.venv/bin/python hl_timestats.py --coin BTC --no-fetch \
    --test-window 02:00-05:00 --tz Europe/Berlin --thresholds 0.01 0.03
```

Vergleicht das Fenster gegen den Rest des Tages, mit Konfidenzintervallen,
Zwei-Stichproben-Test und einer Aufschlüsselung Jahr für Jahr — letztere zeigt,
ob der Effekt stabil ist oder aus einem einzelnen Jahr stammt. Fenster über
Mitternacht hinweg und ein Wochentagsfilter (`--weekdays 0,1,2,3,4`) werden
unterstützt.

Nach einigen Wochen:

```bash
.venv/bin/python hl_recorder.py --analyze --coin BTC
.venv/bin/python hl_viz.py --coin BTC --hours 168
```

Backtest der Trendfolge, unabhängig vom Recorder:

```bash
.venv/bin/python hl_backtest.py --coin BTC --interval 4h --days 700 --plot
.venv/bin/python hl_backtest.py --spot --coin HYPE --interval 4h --days 700
```

## Dashboard

Drei Panels auf `http://<pi>:8765`:

- **Live-Chart** — Kerzen mit den aktuellen Liquidationslevels als waagerechte
  Linien. Rot unterhalb des Kurses sind Long-Liquidationen, grün oberhalb
  Short-Liquidationen. Durchgezogene Linien liegen bei mindestens dem halben
  Stundenvolumen und können den Kurs bewegen, gestrichelte werden eher
  absorbiert. Aktualisiert alle 5 Sekunden, Zeitraster von 1 min bis 1 h.
- **Heatmap** — Cluster über die Zeit, mit Kurslinie und eingetretenen
  Liquidationen.
- **Depth** — Schnitt durch den aktuellen Moment, alle Level nach Notional.

## Wie die Aufzeichnung funktioniert

1. Der WebSocket-Feed `trades` liefert zu jedem Trade die Wallet-Adressen.
   Daraus wächst ein Adressregister.
2. `clearinghouseState` liefert pro Adresse die offenen Positionen mit dem
   echten `liquidationPx` — anders als CEX-Heatmaps ist das keine Schätzung.
3. Alle Liquidationspreise werden in ein logarithmisches Preisraster
   aggregiert und alle fünf Minuten als Snapshot gespeichert.
4. Parallel laufen 1-Minuten-Bars aus dem Trade-Feed mit, damit sich später
   Forward-Returns berechnen lassen.

## Pi-spezifische Hinweise

**Arbeitsspeicher.** 4 GB reichen deutlich. Gemessen auf einer Datenbank mit
90 Tagen Aufzeichnung (2,8 Mio. Heatmap-Zeilen, 223 MB):

| Prozess | Spitzenspeicher |
|---|---|
| Recorder mit 20.000 Adressen / 40.000 Positionen | 44 MB |
| Dashboard, auch bei 7-Tage-Ansicht | 108 MB |
| Binance-Stream | rund 40 MB |
| `--analyze` über 90 Tage | 173 MB, 6 s |

Zusammen unter 400 MB. Ein kleineres Snapshot-Intervall erhöht den Bedarf
leicht, weil mehr Zeilen entstehen — es senkt ihn nicht.

**Datensicherheit bei Neustart und Stromausfall.** Die Datenbank läuft im
WAL-Modus. Bars, Liquidationen und Adressen werden alle 10 Sekunden committet
(`--flush-sec`), die WAL-Datei alle 15 Minuten zusammengefaltet, damit sie
nicht unbegrenzt wächst.

| Fall | Verlust |
|---|---|
| Geplanter Neustart (systemd sendet SIGTERM) | nichts |
| Absturz eines Dienstes | nichts, der Supervisor startet neu |
| Harter Stromausfall | bis zu 10 Sekunden |
| Stromausfall mit `--durable` | nichts, dafür mehr Schreibzugriffe |

Getestet mit SIGKILL mitten im Schreibbetrieb: Die Datenbank bestand danach
in allen Läufen `PRAGMA integrity_check`, und die vor dem letzten Commit
geschriebenen Daten waren vollständig vorhanden.

`--durable` schaltet auf `synchronous=FULL`, also fsync bei jedem Commit. Auf
einer USB-SSD unproblematisch, auf einer SD-Karte erhöht es den Verschleiß
spürbar.

**SD-Karte.** Der Recorder schreibt dauerhaft. Bei drei Coins wächst die
Datenbank bei 10-Minuten-Snapshots um etwa 0,2 GB pro Monat. Auf einem
124-GB-Datenträger reicht das für Jahre. Für Monatsbetrieb eine USB-SSD verwenden
und `--db /pfad/zur/ssd/hl_liq.db` setzen.

**Uhrzeit.** Ohne NTP-Synchronisation sind die Zeitstempel wertlos.
`sudo timedatectl set-ntp true`, das Installskript prüft es.

**Dashboard im Netz.** `--host 0.0.0.0` macht es im LAN erreichbar, ohne
Passwort. Nur im eigenen Heimnetz betreiben, nicht ins Internet stellen.

**Dauerbetrieb.** `install.py --enable` richtet drei systemd-Dienste mit
`Restart=always` ein, damit Recorder, Binance-Stream und Dashboard Neustarts
und getrennte SSH-Sitzungen überleben.

## Alarm bei Ausfällen

```bash
.venv/bin/python hl_watchdog.py --once                # einmalig prüfen
.venv/bin/python hl_watchdog.py --test-alarm          # Signalgeber testen
```

Zwei Ebenen, weil eine allein nicht genügt:

**Lokal** — Alarmton über die Audioausgabe, alle 120 Sekunden wiederholt,
solange die Störung anhält (`--alarm-interval`). Bei Warnung ein aufsteigender
Zweiklang, bei kritischem Zustand eine Sirene, beides aus Rechteckschwingungen
im Stil der 8-Bit-Ära und zur Laufzeit erzeugt. Funktioniert ohne Internet,
also gerade dann, wenn der Ausfall die Verbindung betrifft.

> Der Raspberry Pi 5 hat **keinen eingebauten Lautsprecher** und seit dem
> Modell 5 auch keine 3,5-mm-Klinkenbuchse mehr. Ton braucht HDMI mit
> angeschlossenem Bildschirm, einen USB-Soundstick, Bluetooth oder ein
> I2S-DAC-HAT. `hl_watchdog.py --test-alarm` sagt dir, was gefunden wurde.
> Ohne Audioausgabe bleiben die ACT-LED (`--led`) und der Totmannschalter.

Nötig ist ein Abspielprogramm: `sudo apt install alsa-utils`. Optional lässt
sich zusätzlich ein Summer an einem GPIO-Pin betreiben (`--buzzer 18`), auf
dem Pi 5 über `gpiozero` mit `lgpio`.

**Extern** — ein Lebenszeichen an einen Dienst wie healthchecks.io
(`--heartbeat https://hc-ping.com/UUID`). Der Wert liegt im Ausbleiben: Ist
der Pi tot oder offline, alarmiert der Dienst dich. Das ist die einzige Ebene,
die einen Totalausfall überhaupt melden kann. Zusätzlich Push über
`--ntfy DEIN-TOPIC`, solange die Verbindung steht.

Geprüft werden Alter der Bars und Snapshots, stille Einzel-Feeds, Rückstand
des Pollers, Binance-Daten, Plattenplatz, NTP-Synchronisation und der Zustand
der systemd-Dienste. Die Verbindungsprüfung verlangt den erwarteten Inhalt,
nicht nur einen Statuscode — ein Captive Portal oder eine Router-Fehlerseite
antwortet sonst mit HTTP 200 und sähe wie eine intakte Verbindung aus.

## Zwei Datenquellen, getrennt gehalten

Hyperliquid liefert **gemessene** Positionen mit echtem Liquidationspreis,
Binance liefert **aggregierte** Marktdaten und Liquidationsereignisse. Beides
landet in derselben Datei, aber in getrennten Tabellen (`heatmap` gegen
`bnc_*`). Nicht vermischen — die Aussagekraft ist unterschiedlich.

Rückwirkend abrufbar sind bei Binance nur Open Interest, Long/Short-Ratios und
Kerzen. Liquidationen gibt es dort nicht als Verlauf, die sammelt nur der
Live-Stream. Und Binance pusht je Symbol nur die größte Order pro Sekunde: Das
gespeicherte Kaskadenvolumen ist eine Untergrenze, kein exakter Wert.

## Grenzen

Die Heatmap ist unvollständig. Sichtbar werden nur Wallets, die gehandelt
haben, während der Recorder lief. Die Abdeckung wächst über Wochen, wird aber
nie vollständig — für relative Verteilungen reicht das, für absolute
Notional-Zahlen nicht.

Historische Positionsdaten gibt es nicht. Die These lässt sich nur vorwärts
prüfen, nicht rückwirkend. Zwei bis drei Monate sind ein realistischer
Zeitraum, bevor die Zahlen etwas bedeuten, weil Marktphasen stark korrelieren.

Handel mit Perpetuals und Kryptowährungen kann zum Totalverlust führen. Diese
Werkzeuge treffen keine Aussage darüber, ob eine Strategie funktioniert —
sie helfen nur beim Messen.
