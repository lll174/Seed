# Hyperliquid — Liquidationscluster aufzeichnen und auswerten

> Entwickelt mit Claude Fable 5.1 (13.–23.09.2026), fortgeführt mit Claude Opus 5.5. Einstieg für eine neue Sitzung: `PROJEKTUEBERGABE_OPUS55_23-09-2026.md`, dann `UPDATE_PLAN.md`.

Werkzeuge, um zu prüfen, ob Liquidationscluster auf Hyperliquid Vorhersagekraft
haben, und um darauf aufbauend eine Handelslogik zu testen.

Zielplattform: Raspberry Pi 5, Debian 13 (Trixie), 64 Bit. Läuft ebenso auf
jedem Debian/Ubuntu mit Python ab 3.11.

## Dateien

| Datei | Zweck |
|---|---|
| `install.py` | Einrichtung, Abhängigkeiten, Selbsttest, systemd |
| `requirements.txt` | Python-Pakete |
| `hl_recorder.py` | zeichnet Cluster live auf, labelt sie im Analysemodus |
| `hl_viz.py` | Live-Chart, Heatmap-PNGs und Dashboard |
| `hl_watchdog.py` | Wächter mit Summer, LED, Push und Totmannschalter |
| `run_all.py` | startet und überwacht alle Dienste gemeinsam |
| `hl_binance.py` | Binance-Liquidationen live, Marktdaten 30 Tage rückwirkend |
| `hl_timestats.py` | zeitbasierte Heatmap: wann Bewegungen gehäuft auftreten |
| `hl_backtest.py` | Trendfolge-Backtest für Perps und Spot |
| `hl_forecast.py` | Prognose, Selbstkalibrierung, Trefferbilanz, Nulltest (`--nulltest`) |
| `hl_score.py` | Konto-Score: Vorlauf, Edge je Umsatz, Konsistenz, Größe, Klasse; Score-Test |
| `hl_coinbase.py` | Coinbase-Spot: Prämie, Taker-Flow, Orderbuch |
| `check_m9.py` | Feuerraten des Ereignis-Signals alt/neu (Vorher-Nachher auf echten Daten) |
| `hl_ext.py` | Sammler der Fremdbörsen-Reihen (läuft im Dienst hl-binance) |
| `hl_indikatoren.py` | neue Treiber/Regime-Flags aus vorhandenen Tabellen (OI-Perzentil, Crowding, ETF-Momentum, Vol-Regime, Funding-Spread, Liquidationsdruck, Varianz-Kompression) |
| `hl_dbcoord.py` | prozessübergreifende Schreibkoordination (eine Sperre für alle Schreiber) |
| `hl_labor.py` | TradeLabor: simulierter Handel mit allen Daten (Strategien, Ausführungsmodell, Kennzahlen, Selbsttest) |
| `hl_fusion.py` | Fusionsprognose (Expertenmischung), Kalibrierung v3 (v2 über alle Coins geteilt), Kostenschwelle — im Schatten; Selbsttest `--nulltest`, Stand `--stand` (seit 23.42, Konzept `KONZEPT_Fusion.md`) |
| `hl_kaskade.py` | Kaskaden-Gleichung: Wurzelgesetz der Marktwirkung auf die Liquidationscluster der Heatmap → Kipppunkt, Ende, Mehrweg, P(Rutsch ≥ 2 σ); Kalibrierung Y je Coin mit Placebo und Seitenspiegel — im Schatten; Selbsttest `--nulltest`, Stand `--stand` (seit 23.43, Konzept `KONZEPT_Fusion.md` Abschnitt 4b) |
| `hl_adressfluss.py` | Adress-Strom: jeder Trade je Minute und Adresse in `adressfluss.db` (Recorder), Lesen und Bericht |
| `check_fills.py`, `check_sources.py` | Fill-Abholstand mit Live-Probe; Rundum-Funktionstest aller Quellen |

## Installation

```bash
python3 install.py            # venv, Pakete, Selbsttest
python3 install.py --enable   # zusätzlich: Autostart beim Booten einrichten
python3 install.py --check    # nur prüfen, nichts verändern
```

`--enable` erzeugt die systemd-Units, kopiert sie nach `/etc/systemd/system`,
aktiviert sie und prüft anschließend, ob alle drei laufen. Danach starten
Recorder, Binance-Stream und Dashboard automatisch bei jedem Boot.

Debian Trixie erlaubt kein `pip install` in die System-Python-Installation
(PEP 668). Das Skript legt deshalb ein venv unter `.venv/` an. Alle Aufrufe
danach über `.venv/bin/python`.

## Aktualisieren

**Per Knopf im Dashboard** (Panel „Aktualisierung", ganz unten): lädt das
Archiv von GitHub (`--update-url`, Standard: das Projekt-Repository), prüft es
und startet `update.py` in einer eigenen systemd-Einheit `hl-update`, die den
Neustart des Dashboards überlebt. Die Seite zeigt das Update-Log live und
lädt sich am Ende selbst neu. Voraussetzung: `sudo.txt` mit dem sudo-Passwort
im Projektordner, Rechte 600 (`chmod 600 sudo.txt`) — sonst verweigert der
Server. **Sicherheitshinweis:** Wer das Dashboard im WLAN erreicht, kann damit
Root-Aktionen auslösen. Sicherer ist eine sudoers-Regel ohne Passwortdatei:

    sudo visudo -f /etc/sudoers.d/hl-liq
    seed ALL=(root) NOPASSWD: /usr/bin/systemctl, /usr/bin/systemd-run, /usr/bin/cp * /etc/systemd/system/, /usr/bin/rm -rf */__pycache__

Dann `sudo.txt` löschen; `update.py` und der Knopf funktionieren ohne Passwort.

**Per Terminal:**

```bash
python3 update.py                    # neuestes hl_liq_project*.zip aus ~/Downloads
python3 update.py /pfad/archiv.zip
```

Sichert erst die Datenbank und die bisherigen Skripte, stoppt die Dienste,
spielt das Archiv ein (Datenbank, Backups, Logs bleiben unberührt), prüft die
Syntax — bei Fehlern wird die Sicherung zurückgespielt — erzeugt und
installiert die systemd-Units neu und startet die Dienste. Findet auch
Archive mit `-2`/`-3`-Suffix, die der Browser beim mehrfachen Herunterladen
anhängt, und räumt entsprechende Altlasten wie `hl_viz-2.py` weg.
Die Sicherung liegt danach unter `updates/vor_<Zeitstempel>/`.

## Datenbank auf ein anderes Medium verschieben

```bash
python3 migrate_db.py            # zeigt eingehängte Medien, fragt nach Auswahl
python3 migrate_db.py --target /mnt/ssd/hl
```

Stoppt die Dienste, wartet bis kein Prozess mehr an der Datenbank hängt,
faltet die WAL ein, prüft die Quelle, kopiert Datenbank und Backup-Ordner,
prüft die Kopie (integrity_check, Zeilenzahlen aller Tabellen), lässt den
Backup-Ordner auf dem Pi (getrennt vom Zielmedium), bietet
einen fstab-Eintrag an, damit das Medium nach Neustart wieder da ist,
stellt die Units um, startet die Dienste und wartet, bis der Recorder am
neuen Ort schreibt. Erst dann wird die alte Datenbank umbenannt — nicht
gelöscht. FAT/exFAT/NTFS werden abgelehnt; SQLite braucht ext4.

## Schreiblast auf der SD-Karte

Der Recorder hat keine eigenen Zwischendateien — seine Puffer liegen im RAM
und gehen alle 30 s per Commit in die Datenbank. Der eigentliche Zwischen-
speicher ist die WAL-Datei, die SQLite zwingend neben die Datenbank legt;
nach `migrate_db.py` liegt sie damit auf dem externen Medium.

**Schreibverstärkung — der Unterschied zwischen Zuwachs und Schreiblast.**
Die Datenbank wächst um wenige MB pro Stunde; geschrieben wird ein Vielfaches
davon. Grund: SQLite schreibt jede geänderte 4-KB-Seite erst ins WAL und beim
Checkpoint noch einmal in die Datei. Viele kleine Änderungen auf zufälligen
Seiten einer großen Tabelle kosten deshalb ein Hundertfaches ihrer Datenmenge.
Eine Messung am 11.09.2026 ergab 0,49 GB/h bei 2 MB/h Zuwachs — zwölf Gigabyte
am Tag auf den Stick. Vier Maßnahmen, zusammen etwa −80 %:

- Der Trade-Feed schrieb jede gesehene Adresse sofort in `addresses` (rund
  1.000 Aktualisierungen/min auf eine 130.000-Zeilen-Tabelle). Jetzt im
  Speicher gesammelt: neue Adressen alle 10 min, `last_trade` stündlich.
- Der Poller schrieb jede Abfrage. Jetzt nur, wenn sich der Positionswert um
  mindestens 2 % geändert hat; `last_poll` wird stündlich gesammelt
  geschrieben und ist im Speicher immer aktuell (`due_addresses` filtert
  danach, es wird also nichts doppelt abgefragt).
- `book_summary` alle 30 s statt alle 5 s — das Dashboard liest ohnehin nur
  die jüngste Zeile.
- Commit alle 30 s statt 10 s: mehrfach geänderte Seiten gehen einmal ins Log.

Im Labor gemessen (eine Stunde Betrieb simuliert: 19.200 Abfragen, 60.000
Trades, WAL-Autocheckpoint aus, damit die WAL genau die geschriebenen Seiten
sammelt): vorher 114 MB, nachher 4 MB je Stunde — 97 % weniger. Auf dem Stick
etwa das Doppelte, weil der Checkpoint dieselben Seiten noch einmal in die
Datei kopiert.

Nebenwirkung: Nach einem Stromausfall stehen `last_poll` und `last_trade`
einiger Adressen bis zu eine Stunde in der Vergangenheit — der Recorder fragt
sie dann früher erneut ab, es gehen keine Daten verloren. Messen lässt sich
alles mit Debug → „Schreiblast messen (5 min)" oder
`python3 check_writes.py --seconds 300`; Teil 3 zeigt die echte Schreibrate des
Datenträgers, Teil 1 den Zuwachs je Tabelle.

**Browser auf dem Pi — der größte SD-Karten-Schreiber.** Eine Messung am
11.09.2026 ergab: Recorder, Dashboard und Binance-Modul schrieben zusammen
4,2 MB in fünf Minuten (alles auf das externe Medium), Firefox auf demselben Pi
196,7 MB auf die SD-Karte — 2,4 GB/h. Ursache: Die Seite holt alle 5 s neue
Daten, der Browser legt jede Antwort in seinen Plattencache und sichert
nebenbei die Sitzung. Zwei Gegenmaßnahmen sind eingebaut: alle Antworten
tragen `Cache-Control: no-store` (der Browser darf sie nicht mehr auf die Karte
schreiben) und werden gepackt ausgeliefert, wenn der Browser es unterstützt
(71 % weniger Daten, Stufe 1, kaum Rechenzeit). Was zusätzlich hilft, falls das
Dashboard dauerhaft auf dem Pi offen steht: in `about:config`
`browser.cache.disk.enable = false` und
`browser.sessionstore.interval = 600000`; oder das Dashboard schlicht vom Handy
oder PC aus ansehen. Prüfen: Debug → „Browser auf dem Pi".

**Auswahl der fälligen Adressen läuft im Speicher.** Seit `last_poll` nur noch
stündlich gesammelt geschrieben wird, darf die Auswahl nicht mehr per SQL nach
`last_poll` sortieren — frisch abgefragte Adressen sähen dort maximal
überfällig aus und verstopften die Kandidatenliste (beobachtet: API-Auslastung
fiel von 85 % auf 16 %). Der Recorder hält deshalb alle Adressen mit
`last_poll`, `pos_value`, `last_trade` und `first_seen` im Speicher
(`addr_meta`, bei 130.000 Adressen rund 30 MB, Laden 0,35 s) und trifft die
Auswahl dort in einem Durchgang: ~55 ms alle 5 s, dafür entfallen drei
SQL-Abfragen über die große Tabelle. Diagnose: Die API-Kachel zeigt jetzt
„Poller 27/27 je Runde · fällig: 3.371 mit Position, 122.000 neu, 4.000 leer".
Steht dort „Stapel nicht voll", findet der Poller zu wenige fällige Adressen —
dann stimmt etwas mit der Auswahl oder es ist schlicht alles frisch abgefragt.

**Was im Backup steckt — und was nicht.** Das tägliche Backup kopiert
**ausschließlich** die Hauptdatenbank über die SQLite-Backup-API in eine
einzelne Datei (`hl_liq_backup.db`) plus eine kleine `backup.json`.
`forecasts.db`, `sys_history.json` und sämtliche WAL-Dateien liegen zwar im
selben Ordner, werden aber **nie** mitkopiert — sonst wüchse das Backup-Medium
(meist die SD-Karte) unnötig. Vor jedem Lauf prüft der Recorder den freien
Platz: nötig sind Datenbankgröße plus 10 % Reserve, weil altes und neues
Backup kurzzeitig nebeneinander liegen. Reicht er nicht, wird das Backup
übersprungen, das vorhandene bleibt unangetastet, und die Kachel „Letztes
Backup" zeigt ⚠ mit dem fehlenden Platz. Wer die Lernhistorie sichern will,
kopiert `forecasts.db` von Hand mit.

**Prognosedateien.** `forecasts.db` (Prognosen, gelernte Gewichte, Lernstand)
und `sys_history.json` (Temperatur- und CPU-Verlauf) liegen neben der
Hauptdatenbank — also auf dem externen Medium, nicht auf der SD-Karte. Den
Ordner findet das Dashboard über den `--db`-Pfad der systemd-Einheit, sonst
über `HL_DB`; mit `HL_FORECAST_DB` lässt er sich frei setzen. Ist der Ordner
nicht beschreibbar, bleibt alles im Projektordner. `update.py` verschiebt
vorhandene Dateien beim Aktualisieren mitsamt ihrer WAL, der Lernstand geht
also nicht verloren. Der Pfad steht im Prognose-Abschnitt unter „Zeitprofil"
und in `check_writes.py` (Teil 4).

Zusätzlich:

- Sortierpuffer aller Verbindungen im RAM (`temp_store=MEMORY`), nicht in
  `/var/tmp`.
- Logdateien (`recorder.log`, `binance.log`, `watchdog.log`) wandern mit der
  Migration nach `<Ziel>/logs/`; einstellbar über `install.py --log-dir`.
- Was bewusst auf der SD-Karte bleibt: das tägliche Backup und das
  systemd-Journal. Wer auch das Journal von der SD-Karte nehmen will:
  `Storage=volatile` in `/etc/systemd/journald.conf` hält es im RAM
  (geht bei Neustart verloren).

## Auf dem Handy

Das Dashboard passt sich ab 700 px Breite an Handy-Bildschirme an: Bedien-
elemente untereinander mit großen Tippflächen, Kacheln in zwei Spalten, alle
Charts in voller Breite mit angepasster Höhe, Tooltips per Tippen. Geprüft in
Chromium bei 412×915 (6,8 Zoll) in beiden Lagen.

Zwei Wege aufs Handy, beide brauchen `--host 0.0.0.0` (die Unit setzt es):

- **Web-App ohne Installation:** Chrome → `http://<Pi-Adresse>:8765` → Menü
  ⋮ → „Zum Startbildschirm hinzufügen". Manifest und Icon liefert der Server.
- **Android-App:** der Ordner `android/` ist ein Android-Studio-Projekt (WebView
  mit Adressverwaltung, Ziehen-zum-Neuladen, Fehlermeldung). Bauen: Studio →
  Build → Build APK(s). Details in `android/README_APP.md`.

## Audit 13.09.2026 — behobene Befunde

Ein externes Audit fand vier kritische Fehler. Alle wurden vor der Korrektur einzeln
nachgestellt:

* **Binance-Zeitstempel in Millisekunden** (`bnc_liquidations.ts`), gelesen in Sekunden.
  Da Millisekunden immer größer sind, war jeder Zeitfilter wahr: die Binance-Heatmap
  blieb leer, „Summen der letzten Stunde" waren Allzeitsummen. `parse_force_order`
  rechnet jetzt auf Sekunden um, `db_connect` migriert Altzeilen einmalig
  (`ts/1000 WHERE ts > 1e11`). **Merksatz: In diesem Projekt sind Zeitstempel Sekunden.**
* **Seiten vertauscht:** Die Seite wird beim Schreiben normalisiert, beim Lesen wurde sie
  aus dem ersten Buchstaben neu geraten — `"LONG".startswith("S")` ist falsch, also wurde
  aus long short. Jetzt durchgereicht, alte Rohwerte (`SELL`/`BUY`) weiterhin verstanden.
* **Kapitulationssignal:** feuerte wegen des Zeitfehlers nie und hätte nach dessen
  Behebung die Seiten vertauscht. Zusätzlich vergleicht es jetzt nur abgeschlossene
  Halbstundenblöcke gegen den Durchschnitt der übrigen.
* **Gelernte Gewichte zurückgesetzt**, weil die Kalibrierung auf diesen Signalen lief.

Dazu: Absturz von `--whale-analyze` bei unter 24 h Historie, unerreichbare
Watchdog-Entwarnung, unbegrenzt wachsende Zwischenspeicher, Maskierung aller Namen aus
fremder Hand (`esc()`), CSRF-Schutz für POST über eine eigene Kopfzeile, Grenzen für
Abfrageparameter und den Update-Download.

**Offen und bewusst nicht geändert:** Das Dashboard lauscht weiter auf allen Adressen,
damit der Zugriff vom Handy erhalten bleibt. Wer es dichter will, bindet es an 127.0.0.1
und nutzt einen SSH-Tunnel; dazu käme eine Anmeldung mit Zufallstoken. Ebenfalls offen:
Positionen über einen Neustart hinweg sichern, mehrere statistische Verzerrungen
(Toleranzzone der Trefferquote, Doppelzählung in der Magnet-Statistik, Z-Basis ohne
Null-Stunden) und die Leistungsvorschläge.

## Konto-Score — wer hat recht, nicht nur wer ist groß (13.09.2026, Sitzung 2)

Die goldene Regel des Projekts lautet: Bei den größten Konten liegt das meiste Wissen.
`hl_score.py` macht sie messbar. Je Konto und Coin ein Score in [0, 1], täglich neu,
Schnappschuss in `forecasts.db` (Tabelle `account_score`):

| Anteil | Komponente | Woher |
|---|---|---|
| 35 % | **Vorlauf** — Folgerendite der eigenen Schritte nach 4 h, driftbereinigt, je Stunde ein Schritt, Bayes-geschrumpft (n / (n + 20)) | `whale_positions`, `lb_events`, `bars` |
| 25 % | **Edge je Umsatz** — PnL / Umsatz, 30 Tage sonst 7 | `lb_stats` (neu: alle vier Leaderboard-Fenster mit Umsatz, stündlich für Kandidaten und Wale) |
| 20 % | **Konsistenz** — positive Fenster von Tag / Woche / Monat / Gesamt | `lb_stats` |
| 10 % | **Größe** — log₁₀ Positionswert, rangnormiert | `addresses` |
| 10 % | **Klasse** — direktional 1,0 · gemischt 0,6 · Hedge / MM 0 | Verhaltensklassen |

Größe ist bewusst klein gewichtet: Sie ist die **Hypothese** der goldenen Regel, nicht
ihr Beweis. Der **Score-Test** (wöchentlich, `learned.score_test`) misst die
Rangkorrelation des Scores von vor sieben Tagen mit dem Vorlauf der Folgewoche — je
Komponente. Liegt „Größe" bei null, ist die Regel in ihrer Größen-Form für diesen
Markt widerlegt, und die Anteile werden nachgezogen.

Drei Treiber lesen den Score: **Smart-Flow 4 h** (Fluss aller bewerteten Konten, mit
Score gewichtet, Wurzel des Notionals), **Elite-Positionierung** (Netto-Ausrichtung der
zehn besten Konten) und **Gegen-Flow** (Fluss der Konten mit belegt negativem Vorlauf,
invertiert; Prior 0,3, Experiment). Die Flow-Treiber für Hedge-, Market-Maker- und
gemischte Konten sind dafür gestrichen — ihre Fills tragen keine Richtung. Die Elite-Liste
(`learn.elite`) ist zugleich die Vorgabe für WebSocket-Abonnements (zehn Nutzer je IP). Seit 23.39 kopiert das Labor die
Elite („Elite live folgen“, siehe TradeLabor), und das Werkzeug „Elite-Positionierung prüfen“ (`check_elite.py`) stuft genau
wie das Dashboard ein (`hl_viz.score_klasse`), lässt von der Masterregel Gesperrte weg und zeigt die gespeicherte Elite, die
Treiber, Recorder und Labor tatsächlich nutzen. Bis 23.38 zeigte es gesperrte Konten in der Elite, die das Dashboard längst
ausschloss.

## Kalibrierung v2 — K2-Neubau (23.09.2026)

Das alte Modell (v1) konnte eine echte Treiber-Kante nicht abbilden (Audit v10, K2: ein Treiber mit 93 %
Trefferquote ergab p_up 50,8 %). `hl_kalib.py` ist der Neubau: L2-regularisierte logistische Regression
auf standardisierten Treiber-Scores mit Achsenabschnitt, ohne den Nenner 19,4 und ohne β; der Prior ist
Ausgangspunkt, der mit der Datenmenge verschwindet (Zielvektor Prior·max(0, 1−n_eff/200)); λ per
geblockter Kreuzvalidierung mit Embargo (1-SE-Regel); 90 Tage nach Zeit; Toleranz-Labels; eine Prognose je
Block. **Abnahme:** die Positivkontrolle (Selbsttest-Schritt 22): Kante 0,65 → p_up 0,60–0,70, Rauschen bewegt
p um < 5 Punkte gegen die Basis — heute: 63,4 % / 0,6 Punkte. v2 läuft zunächst im **Schatten**: Sie
rechnet stündlich je Coin und Horizont, ihre Wahrscheinlichkeit steht als `p_up_v2` in jeder Prognose,
die Kachel „Kalibrierung v2" zeigt OOF-Quote, Brier-Skill, Zuverlässigkeitsdiagramm und die direkte
Bilanz v1 gegen v2 auf den gespeicherten Prognosen. Umschalten: Debug „Kalibrierung v2 AKTIVIEREN"
(Schalter in forecasts.db, jederzeit zurück). Nach dem Umschalten trägt v2 die angezeigte P(aufwärts).

## Masterregel Sperre (22.09.2026)

Ein Konto mit **mehr als 300 gebündelten Trades in 24 h** (je Coin, Minute und Richtung — dieselbe Einheit wie die
Aktivitätsschranke der Elite; seit 23.13, vorher 2.000 Fills: Fills sind Ausführungen, keine Entscheidungen) ist eine
Maschine (Market Maker, HFT). **Seit 23.29 gilt die Zwei-Tage-Regel:** Nach dem ersten Tag über 300 wird das Konto vorläufig
ausgeschlossen; liegt es binnen 7 Tagen an einem zweiten Tag darüber, wird es **dauerhaft gesperrt** (Tabelle `konto_status`,
automatisch beim Fill-Lauf), sonst nach 7 Tagen wieder frei. So bleibt ein Mensch mit einem einzigen extremen Tag erhalten. Die
Sperren der alten Fills-Regel werden einmalig neu bewertet, sobald 24 volle Stunden Trade-Zählung vorliegen: wer höchstens
300 gebündelte Trades hat, wird freigegeben (Status `frei`, Grund im Protokoll). Wirkung im ganzen System:
kein Verhaltenssignal (Direktionale Wale, Wal-Flow, Konto-Score, Elite, Smart-Flow, Gegen-Flow), keine
Order-Abfrage, keine Fill-Speicherung, der Leaderboard-Zyklus überspringt das Konto; seine Positionen
werden nur noch alle 6 Stunden abgefragt (Liquidationsstufe), damit seine Liquidationspreise in der
Heatmap bleiben. In Tabellen erscheint die Marke GESPERRT. Manuell in `labels.json`: `"sperre": true`
sperrt, `"sperre": false` schützt ein Konto vor der Automatik. Werkzeug: Debug „Masterregel Sperre".

## Treiber-Signale: Pfeile, Blitze, Töne (22.09.2026)

In der Treibertabelle steht neben dem Namen ein grüner ▲ oder roter ▼, wenn sich der Score seit der
letzten Prognose um mindestens 0,05 geändert hat; ab 0,5 ein Doppelpfeil. Ein roter ⚡ markiert einen
**Umschwung**: mindestens zwei der fünf gewichtigsten Treiber sind binnen 10 Minuten um ≥ 0,5 gefallen
(grün, wenn gestiegen). Töne (Web-Audio, keine Dateien): springt ein Ereignis-Treiber an, ertönt bei
negativem Score 5 s eine Sirene, bei positivem 3 s „die Kasse klingelt"; ein Umschwung nach unten löst
ebenfalls die Sirene aus, nach oben die Kasse. Browser erlauben Ton erst nach einer Berührung: Schalter
„🔔 Töne" über der Tabelle (bleibt gespeichert), „Probe" spielt beide Töne. Der Verlauf je Coin liegt
60 Minuten im Browser (localStorage) und wird nur bei einer NEUEN Prognose fortgeschrieben.

## Version (22.09.2026)

Die Systemkachel zeigt **„Version"**: die Projektversion aus `version.py` (von Hand gepflegt, z. B.
`2026-09-22.1`) und eine Prüfsumme über alle Projektdateien (automatisch). Jedes gelieferte Paket
nennt beide Werte; stimmen sie mit der Kachel überein, läuft genau dieser Stand. `python3 version.py`
druckt sie auf der Kommandozeile.

## Letztes Backup wiederherstellen (14.09.2026)

Im Abschnitt „Aktualisierung" steht neben dem Update-Knopf **„Letztes Backup wiederherstellen"**.
Er spielt die Projektdateien aus dem jüngsten Ordner `updates/vor_*` zurück — der Sicherung, die
`update.py` vor jedem Update anlegt. **Datenbanken und Laufzeitzustand werden nicht berührt**:
`*.db`, `*.db-wal`, `*.db-shm`, `forecasts.db`, `sys_history.json`, `labels_cache.json`, `sudo.txt`
sind ausdrücklich ausgenommen, auch wenn sie im Backup-Ordner liegen. Vor dem Zurückspielen wird
der jetzige Stand nach `updates/vor_<stamp>_rueck` gesichert — die Wiederherstellung ist damit selbst
rückgängig zu machen (der Knopf zeigt dann diesen Ordner als jüngstes Backup). Ablauf wie beim
Update: Dienste stoppen, Dateien kopieren, Syntax prüfen (bei Fehler: alter Stand bleibt, Dienste
starten wieder), Dienste starten; Log in `updates/last_update.log`. Kommandozeile:
`python3 update.py --restore-last` (mit Rückfrage) bzw. `--restore-last --yes`; `--backup-info`
zeigt, welches Backup dran wäre.

## Reihen der Fremdbörsen (14.09.2026, `hl_ext.py`)

Bis 14.09. wurden Bybit, OKX, Crypto.com, die Binance-Verhältnisse, das Binance-Orderbuch
und die ETF-Flüsse nur live abgefragt; ihr Beitrag lag als fertiger Treiberwert im
Prognose-Payload, die Rohreihe ging verloren. Seitdem sammelt `hl_ext.py` sie als
Zusatzaufgaben im Dienst `hl-binance` (eigene Verbindung, eigene Threads):

| Tabelle | Inhalt | Takt | Vorhalt |
|---|---|---|---|
| `ext_metrics` | je Börse (bybit, okx, cdc) und Coin: `last`, `oi_coins`/`oi_usd`, `funding_8h`, `taker_ls` mit `taker_span_s` und `taker_n`, `ls_account`, Volumen | 5 min | 90 T |
| `bnc_metrics` | Binance `taker_ls`, `global_ls_account`, `top_ls_position`, `top_ls_account` im 5-min-Raster (Zeitstempel der API), zusätzlich zum Open Interest | 5 min | wie bisher |
| `bnc_book` | Binance-Orderbuch: bid/ask/mid, Tiefe ±5/25/100 bps, Wände je 0,25-%-Stufe (USD, ab 2 % der Tiefe, mind. 100 k) — wie `cb_book` | 5 min | 60 T |
| `ext_liquidations` | Bybit (WebSocket `allLiquidation`, vollständig) und OKX (REST, alle 2 min): `side` = **liquidierte Position** (`long`/`short`), Preis, Menge in Coins, Notional USD, `uid` gegen Duplikate | live / 2 min | 90 T |
| `etf_flows` | Farside: eine Zeile je Tag und Coin (BTC, ETH), Mio USD | 6 h | unbegrenzt |

Seitenbedeutung nach Doku geprüft: Bybit `S = Buy` heißt *Long liquidiert*; OKX liefert
`posSide`. Nicht gelistete Paare (Bybit `retCode 10001`, OKX `51001`, Crypto.com `40004`)
werden je Börse für einen Tag ausgelassen; andere Fehler werden gezählt, nicht gesperrt.

Ratenbudget je 5 Minuten: Bybit 18 Aufrufe (Limit 600 je 5 s), OKX ~26 plus 4 je 2 min
(Limit 20 je 2 s je Endpunkt, rubik 5 je 2 s), Crypto.com 12 (100/s), Binance 24
Verhältnis-Aufrufe und 60 Gewicht Orderbuch (von 2.400 je Minute). Zwischen den Aufrufen
0,3 s Pause; ein Kennzahlenlauf dauert rund eine Minute. Datenbankwachstum etwa 4 MB/Tag.

`hl_binance.py --status` zeigt Zeilen und Alter je Tabelle sowie die Sammler-Zähler;
die Quellenzeile „Bybit/OKX/Crypto.com gespeichert" im Netzwerkstatus, `hl_ext.py` als
Selbsttest (Parser und Seitenlogik gegen dokumentierte Beispielnachrichten). **Die
Prognose-Treiber lesen weiterhin live** — die Reihen sind zunächst Vorrat für Backtests
und neue Treiber (einheitliche Taker-Fenster, Kapitulation über drei Börsen).

## Statistik — Stichprobe, Intervalle, Nulltest (13.09.2026, Sitzung 2)

Alle 15 Minuten entsteht eine Prognose; bewertet wird sie nach 4 und nach 24 Stunden.
Zwei benachbarte Fenster teilen sich damit fast ihr ganzes Ergebnis — 96 Fenster sind
bei 24 h **eine** unabhängige Beobachtung, bei 4 h sind es sechs. Seit dieser Sitzung
rechnet das System deshalb überall mit **n_eff = Zahl getrennter Horizont-Blöcke** (bei
lückenlosen Fenstern ≈ Fenster / 16 für 4 h, Fenster / 96 für 24 h; bei geklumpten
Ereignis-Treibern die Zahl der Episoden):

* **Kalibrierung** (`hl_forecast.calibrate_weights`): zwei Spuren, 4 h (Hauptspur, alle
  15 min) und 24 h (stündlich). Regularisierung `lam = 4 / n_eff` statt `4 / n` — mit der
  alten Formel war der Prior bei 2.000 Fenstern praktisch abgeschafft (λ = 0,002), auf
  reinem Rauschen wanderten Gewichte um bis zu 0,12. Lernstart ab n_eff 40 (rund eine
  Woche für 4 h, rund 40 Tage für 24 h); ein einzelner Treiber verlässt seinen Prior erst
  ab eigenen unabhängigen Fällen — 50 auf der 4-h-Spur, 30 auf der 24-h-Spur (die in 60
  Tagen Vorhalt nie mehr als ~60 Blöcke sieht). Die 24-h-Spur trainiert mit einem Fenster
  je Stunde. Dazu ein gelernter Maßstab **β** (Prior 1): Er sagt, wie viel
  Wahrscheinlichkeit der Richtungsdruck wert ist; die gespeicherte **p_up** ist damit eine
  prüfbare Wahrscheinlichkeit, keine Vorgabe. Tabellen `weights_h` (je Horizont) und
  `learned.cal_4` / `cal_24`; `weights` bleibt als Spiegel der Hauptspur.
* **Trefferbilanz** (`score_forecasts`): eine Prognose je 15-min-Fenster, Wilson-Intervall
  auf n_eff, **Basisrate** (Quote von „immer aufwärts" in denselben Fenstern — nur der
  Abstand dazu ist Können), **Brier-Skill** der gespeicherten Wahrscheinlichkeit. Grün ist
  eine Quote erst, wenn ihr Intervall ganz über der Basisrate liegt.
* **Ensemble**: Beta-Posterior je Modell (50 Pseudo-Beobachtungen, Nullpunkt 0,5) statt
  „Trefferquote minus 0,4"; gedeckelt auf 30–70 %, bis beide Modelle n_eff 50 haben.
* **Magnet-Statistik**: Placebo-Niveau in gleichem Abstand auf der anderen Seite, **Lift**
  = Berührquote / Placebo, Intervall auf getrennten 12-h-Blöcken. Lift 1,0 heißt: kein
  Magnet.
* **Analog-Suche**: p_up gegen die unbedingte Basisrate der Historie gemessen, mit
  Intervall (50 Analoge streuen um ±7 Punkte). **Zeitprofil**: rollierend 180 Tage.
* **Ereignis-Signale (M9)**: Rang in der vollständigen Wochenreihe (inklusive
  Nullstunden) ≥ 98 % **plus** absolute Untergrenze (Wale 1 Mio, Leaderboard 500 k netto)
  **plus** Breite. Ein Perzentil allein feuert per Konstruktion mit fester Rate.
  `check_m9.py --db …` zeigt die Feuerraten alt/neu der letzten 7 Tage.
* **Nulltest** (`hl_forecast.py --nulltest`, Teil von `install.py --selftest`): die ganze
  Strecke auf reinem Rauschen. Soll aus der Mathematik — Quote 50 %, Brier-Skill 0,
  Gewichte beim Prior, Magnet-Lift 1, Rang-Signal ~2 % — nicht aus dem heutigen Ergebnis.
  Ein solcher Test kann keinen Fehler festschreiben.
* **Einheiten-Invarianten** (`hl_recorder.py --audit`): jede Zeitspalte in Sekunden
  (`MAX < 1e11`), die zwei bewussten ms-Spalten in Millisekunden, Seiten überall
  `long`/`short`. Eine Millisekunden-Zeile lässt den Audit mit Exit 1 enden.

## Betrieb

**Aufgaben werden überwacht.** Die neun Dauerläufer des Recorders (Feeds,
Polling, Snapshots, Flush, Backup, Orders, Leaderboard, Leaderboard-Fills,
Temperatur) laufen unter einer Aufsicht: Wirft eine Aufgabe eine Ausnahme, wird
sie mit Typ, Meldung und Codezeile ins Journal geschrieben, in `meta` vermerkt
und nach 5 Sekunden neu gestartet (Wartezeit verdoppelt sich bis höchstens
5 Minuten). Das Dashboard zeigt oben eine rote Leiste: „Aufgabe Leaderboard
abgestürzt (3× · zuletzt 17:12): AttributeError …", ebenso wenn sich der
Recorder länger als 3 Minuten nicht gemeldet hat. Vorher endete eine gescheiterte
Aufgabe still — ein fehlender Methodenname legte das Leaderboard 30 Stunden lahm,
ohne dass irgendwo etwas stand.

Alles zusammen im Vordergrund, etwa in tmux oder einer SSH-Sitzung:

```bash
.venv/bin/python run_all.py --host 0.0.0.0
```

Der Supervisor startet Recorder, Binance-Stream und Dashboard, mischt deren
Ausgaben mit Präfix in ein Log und startet abgestürzte Teilprozesse mit
wachsender Wartezeit neu. Strg-C beendet alles sauber.

Für echten Dauerbetrieb über Neustarts hinweg stattdessen `install.py --enable`.

**Nicht beides gleichzeitig.** Laufen die systemd-Dienste, sind Recorder,
Binance-Stream und Dashboard bereits gestartet. `run_all.py` würde dieselben
Prozesse ein zweites Mal starten, und das Dashboard scheitert dann mit
`Address already in use`. Der Supervisor prüft das inzwischen vorab und
verweigert den Start mit einem Hinweis.

```bash
systemctl status hl-dashboard hl-recorder hl-binance   # laufen sie schon?
sudo systemctl stop hl-recorder hl-binance hl-dashboard # für den Supervisor
sudo ss -ltnp | grep 8765                              # wer hält den Port?
```

Einzeln geht weiterhin:

```bash
.venv/bin/python hl_recorder.py --status               # Fortschritt
.venv/bin/python hl_viz.py --serve --host 0.0.0.0      # nur Dashboard
```

### Takte — drei unabhängige Schleifen

| Was | Takt | Stellschraube |
|---|---|---|
| Adressabfragen | laufend, gestaffelt nach Größe | `--polls-per-min`, `--hot-refresh`, `--cold-refresh` |
| Heatmap-Snapshot | alle 10 min | `--snapshot-sec` |
| Bars und Liquidationen | fortlaufend aus dem Stream | — |
| Binance Open Interest | alle 10 min | `--oi-interval` |

Der Poller läuft dauerhaft, nicht im Snapshot-Takt. Große Positionen werden
alle 3 Minuten abgefragt, kleine alle 30, aufgegebene alle 2 Stunden. Ein
Snapshot ist deshalb ein Mosaik aus unterschiedlich alten Abfragen.

Bei 240 Abfragen pro Minute reicht das Budget für grob 500 große plus 2.000
kleine Adressen. Darüber hinaus dehnen sich die Abstände still aus. Der
Recorder meldet deshalb alle 10 Minuten das Datenalter, die Zahl überfälliger
Adressen und die Auslastung — steht dort dauerhaft über 90 %, hinkt er
hinterher.

Binance ergänzen (kein API-Key nötig):

```bash
.venv/bin/python hl_binance.py --backfill    # 30 Tage OI, Ratios, Kerzen
.venv/bin/python hl_binance.py               # Liquidationen live
.venv/bin/python hl_binance.py --status
```

Zeitbasierte Heatmap (braucht keine eigene Aufzeichnung, nutzt Binance-Historie):

```bash
.venv/bin/python hl_timestats.py --coin BTC --years 3 --png
.venv/bin/python hl_timestats.py --coin BTC --tz Europe/Berlin --json danger.json
```

Zählt je Wochentag und 30-Minuten-Fenster, wie oft die Bewegung 1 % bzw. 3 %
überschreitet. 7 × 48 = 336 Felder. Weil 336 gleichzeitige Tests bei 5 % Niveau
allein zufällig rund 17 Treffer erzeugen, rechnet das Skript
Wilson-Konfidenzintervalle mit Bonferroni-Korrektur und markiert nur Felder,
deren Untergrenze über der Grundrate liegt. Gegen reines Rauschen geprüft:
0 von 336 Feldern überleben die Korrektur.

Eine vorab formulierte Vermutung gezielt prüfen (ein Test statt 336, daher
ohne Korrektur und deutlich aussagekräftiger):

```bash
.venv/bin/python hl_timestats.py --coin BTC --no-fetch \
    --test-window 02:00-05:00 --tz Europe/Berlin --thresholds 0.01 0.03
```

Vergleicht das Fenster gegen den Rest des Tages, mit Konfidenzintervallen,
Zwei-Stichproben-Test und einer Aufschlüsselung Jahr für Jahr — letztere zeigt,
ob der Effekt stabil ist oder aus einem einzelnen Jahr stammt. Fenster über
Mitternacht hinweg und ein Wochentagsfilter (`--weekdays 0,1,2,3,4`) werden
unterstützt.

**Die Kernthese — Cluster als Magnet:**

```bash
.venv/bin/python hl_recorder.py --magnet-analyze --coin BTC
```

Je Stunde: größtes Short-Cluster oberhalb, größtes Long-Cluster unterhalb.
Welches wird zuerst erreicht? Drei Regeln im Vergleich — Größe (die These),
Nähe (reine Geometrie), Zufall. Entscheidend ist die Teilmenge, in der Größe
und Nähe *verschiedene* Ziele nennen; nur dort ist die These von der
Geometrie unterscheidbar. Die Messlatte dort ist nicht 50 %, sondern die
geometrische Erwartung eines driftlosen Pfads (d_nah / (d_nah + d_fern)).

Geprüft: Auf Zufallsdaten sieht die Größe-Regel naiv nach 60 % Treffern aus,
weil große Cluster meist auch nah sind — in der uneinigen Teilmenge bleibt
davon nichts über der Geometrie (z = 0,9). Auf Daten mit eingebautem Magneten
findet der Test ihn deutlich (z = 7,7).

Haben Wal-Aktionen Vorhersagekraft?

```bash
.venv/bin/python hl_recorder.py --whale-analyze --coin BTC
```

Misst die Kursbewegung nach jeder Wal-Aktion in der implizierten Richtung —
und dasselbe an zufälligen Zeitpunkten als Kontrollgruppe. Erst der Unterschied
sagt etwas: In einem steigenden Markt „haben" auch zufällige Longs meist recht.
Ein Blick auf die ersten fünf Minuten trennt Impact (die Wal-Order bewegt den
Kurs selbst) von Information (der Kurs läuft erst später). Und selbst ein
Vorsprung ist kein Insiderwissen: Ein großer Short kann eine abgesicherte
Spot-Position sein, und was jeder sehen kann, ist im Kurs meist schon drin.

Stimmen die Daten in sich?

```bash
.venv/bin/python hl_recorder.py --audit
```

Der Wächter fragt, ob die Daten frisch sind. Der Audit fragt, ob sie
*stimmen*: Sind alle Kerzen minutengenau, wie viele Minuten fehlen? Deckt der
Markpreis-Feed die Handelsminuten ab? Hat jeder Snapshot einen Qualitätsstempel,
und stimmt dessen Positionszahl exakt mit der Heatmap überein? Ist der
Snapshot-Takt regelmäßig, wie viele Neustarts gab es? Liegt die Abdeckung in
einem plausiblen Bereich? Hat jeder Wal einen sauberen Lebenszyklus — keine
doppelte Eröffnung, keine Änderung ohne Eröffnung? Gibt es Duplikate in den
Cluster-Events? Geprüft mit gezielt beschädigten Datenbanken: Alle eingebauten
Fehler werden gefunden.

Ergebnisse zum Weitergeben oder Hochladen exportieren:

```bash
.venv/bin/python hl_recorder.py --analyze --coin BTC     # zuerst labeln
.venv/bin/python hl_recorder.py --export export.zip      # dann exportieren
```

Die Datenbank wird nach Monaten hunderte Megabyte groß und ist nicht mehr
handhabbar. Das Export-Paket enthält nur die gelabelten Ereignisse und
Aggregate und bleibt bei wenigen hundert Kilobyte: `cluster_events.csv` mit
abgeleiteten Zeitspalten, Tagesabdeckung für Bars und Snapshots,
`time_heatmap.csv`, stündlich aggregierte Binance-Liquidationen und eine
`meta.json` mit Zeitraum, Umfang und Datenqualität. Rohdaten verlassen den
Pi nicht.

Nach einigen Wochen:

```bash
.venv/bin/python hl_recorder.py --analyze --coin BTC
.venv/bin/python hl_viz.py --coin BTC --hours 168
```

Backtest der Trendfolge, unabhängig vom Recorder:

```bash
.venv/bin/python hl_backtest.py --coin BTC --interval 4h --days 700 --plot
.venv/bin/python hl_backtest.py --spot --coin HYPE --interval 4h --days 700
```

## Wer steckt hinter einer Wallet?

Die Wal-Tabelle nennt je Wallet, wenn bekannt, den Namen dahinter — aus fünf
Quellen, in dieser Reihenfolge:

1. `labels.json` im Projektordner — eigene Pflege, hat Vorrang, wird von
   Updates nie überschrieben. Format: Adresse (klein) → `name`, `kategorie`,
   `quelle`. Vorbelegt mit den Protokolladressen von Hyperliquid (HLP-Vault,
   Assistance Fund, HLP-Strategie-Vaults).
2. Hyperliquid-Leaderboard — selbst gewählte Anzeigenamen; kein API-Gewicht,
   alle 6 h neu.
3. Etherscan-Namenstags über `octal.art/etherscan-labels` (Börsen, Fonds,
   Market Maker) und Arbiscan-Tags aus dem offenen Datensatz
   brianleect/etherscan-labels — dieselbe Adresse zahlt ihr USDC über Arbitrum
   ein, dort verrät die Herkunft oft den Besitzer.
4. `vaultDetails` — ist die Adresse ein Hyperliquid-Vault? Kostet API-Gewicht
   20 und teilt sich das Limit mit dem Recorder; deshalb höchstens eine
   Abfrage pro Minute, Ergebnis 7 Tage im Cache (`labels_cache.json`).
5. Verhaltensklasse aus den eigenen Daten: „Hedge-Muster" (mehrere Coins, eine
   Seite, Hebel ≤ 10 — typisch für Market Maker und Basis-Trader),
   „Market-Maker-Muster" (beidseitig viele ruhende Limits), „direktional".

Dazu je Wallet Links zu HypurrScan, Arbiscan und Arkham. „unbekannt" heißt:
keine Quelle kennt einen Namen — das ist bei den meisten Walen der Fall; die
Verhaltensklasse ist dann oft die nützlichere Information. Mit einem
Nansen- oder Arkham-Schlüssel ließe sich eine Entitätsabfrage anschließen.

## Coinbase-Spot als eigene Quelle

`hl_coinbase.py` zeichnet den US-regulierten Spotmarkt auf — eigener Dienst,
eigene Ratengrenze (10 Anfragen/s), unabhängig vom Hyperliquid-Budget. Quellen:
der WebSocket-Ticker (liefert bei jedem Handel Preis, Menge, Seite und die
Buchspitze), das Orderbuch alle 30 s und Minutenkerzen alle 15 min zum Füllen
von Lücken. Tabellen: `cb_bars` (Minutenkerzen mit Taker-Käufen und -Verkäufen
in USD), `cb_book` (Tiefe bei ±5/25/100 Basispunkten plus Wände), `cb_meta`.

**Vorzeichen-Falle:** Coinbase gibt im Feld `side` die **Maker**-Seite an.
`side=sell` heißt, eine ruhende Verkaufsorder wurde getroffen — der Taker hat
also gekauft. Das ist genau umgekehrt zu Binance und Hyperliquid; ein Fehler
dort würde jedes Flow-Signal umdrehen. `hl_coinbase.py --selftest` prüft es.

Daraus entstehen drei Prognose-Treiber: **Coinbase-Prämie** (Spot gegen
Perp-Kurs in Basispunkten, gemessen als Z-Wert gegen die eigene 7-Tage-Reihe,
Startgewicht 0,8), **Spot-Taker-Flow** (0,7) und **Spot-Orderbuch** (0,4).
Warum Spot: Er muss ohne Hebel bezahlt werden. Dazu Regeln in der Konfluenz,
eine Kachel und Zeilen im Netzwerkstatus.

## Dashboard

**Netzwerkstatus (Abschnitt über der Aktualisierung).** Alles, was ins Netz geht,
an einer Stelle: ein Chart mit dem verbrauchten API-Gewicht je Minute, getrennt
nach Verbraucher (Poller, Orders, Fills, Leaderboard) und gestapelt gegen die
Grenze von 1.200 je Minute; darunter der Zeitplan aller wiederkehrenden Aufgaben
mit letzter Ausführung, Dauer, Ergebnis und nächster Fälligkeit; dazu Ratengrenze,
429er, Temperaturschutz, Poller-Zustand, Fill-Abholstand und die gemeldeten Fehler
mit Aufgabe, Zeitpunkt und Meldung. Die Angaben, die vorher über Kacheln und
Abschnitte verteilt waren (API-Kachel, Poller-Zeile, Abholstand im Leaderboard),
stehen nur noch hier.

**Deckel des API-Gewichts (hart seit 23.38).** Der Recorder vergibt Gewicht nur, solange die Summe im gleitenden
60-s-Fenster unter 1.080 bleibt (90 % von 1.200, bei Temperaturschutz entsprechend weniger). Bis 23.37 konnten die
Eimer des Begrenzers ihren Füllstand obendrauf ausgeben: in der ersten Minute nach jedem Start rund 1.470, im Betrieb
bis ~1.120 (Vollbericht 30.09.: 1.092/1.080). Jetzt startet der Begrenzer leer, und seine Eimer werden nie voller als der
Platz im Fenster. Der Durchsatz sinkt dadurch um etwa 2,5 %.

**Last-Schutz (seit 23.35).** Mehrere offene Seiten fragen dieselben Daten ab. Läuft eine Anfrage schon, rechnet der Server sie
nicht ein zweites Mal: Wer gleichzeitig fragt, bekommt die vorige Antwort (bis 10 min alt) oder die laufende. Auch die Seite
schickt dieselbe Anfrage nicht erneut, solange die Antwort aussteht. Der jüngste Stand der Wal-Positionen kommt aus den letzten
6 h, nicht mehr aus der ganzen, täglich um ~60.000 Zeilen wachsenden Tabelle. Am 29./30.09. hatte genau das einen Stau
ausgelöst: Das Dashboard lag dauerhaft bei 366 % CPU. Diagnose, falls es wieder hoch geht: Debug „Dashboard-Threads“ zeigt
für jeden Thread die Stelle, an der er gerade rechnet, und seinen CPU-Anteil. Seit 23.36 steht darunter die CPU des ganzen
Prozesses: „Rest, kurze Anfragen“ ist der Anteil der Anfragen, die zu kurz leben, um in einer Probe aufzutauchen, dazu die
Zahl der Anfragen je Sekunde. Auch der Recorder liest beim Start nur noch die letzten 24 h der Wal-Tabelle (vorher die ganze,
40 s und mehr ohne Aufzeichnung). Die Exposure-Zeitreihe über der Wal-Tabelle zählt gesperrte Konten nicht mehr.

**Aufbau.** Ein Kopf, der beim Scrollen oben bleibt: Coin-Auswahl, „Neu laden"
und eine Navigation zu den sechs Abschnitten. Darunter die Kacheln, dann die
nummerierten Abschnitte — Live-Chart, Konfluenz, Orders & Stops, Heatmap,
Momentaufnahme, Wale — und ganz unten die Aktualisierung. Jeder Abschnitt
klappt am Titel ein und aus; der Zustand bleibt im Browser gespeichert. Das
„ⓘ" im Titel zeigt die Erklärung des Abschnitts. Bedienelemente stehen dort,
wo sie wirken: Raster, FVG-Schalter und FVG-Mindestgröße beim Chart, der
Zeitraum bei der Heatmap.

**Datenquelle.** Die Auswahl „Quelle" im Kopf schaltet alle Abschnitte um:

- *Hyperliquid Daten* — wie bisher: eigene Kerzen, erwartete Liquidations-
  cluster aus den Positionen, Orders der Großkonten, Wale.
- *Binance Daten* — Kerzen von Binance (live, sonst `bnc_bars`/`daily_bars`),
  Marken und Heatmap aus den **eingetretenen** Liquidationen
  (`bnc_liquidations`), Orderbuch mit Tiefe statt Konten-Orders, statt der Wale
  die Kennzahlen Open Interest, Long/Short (Konten, Top-Trader) und Taker-Flow
  (`bnc_metrics`, live nachgeladen). Konfluenz mit Binance-Regeln: Taker-Flow
  ±1, Top-Trader-Positionierung ±1, einseitige Konten als Hinweis, laufende
  Kaskade als „Abwarten".
- *Data Mix Fusion* — der Hyperliquid-Stand plus Binance und Crypto.com: Binance-Orderbuch
  je Preisstufe zu den Orders **addiert** (beides ruhende Orders), eingetretene
  Liquidationen beider Börsen als Marker im Chart (Binance orange, HL magenta)
  und in der Heatmap, Binance-Liquidationen der letzten 24 h als Overlay in der
  Momentaufnahme (nicht addiert — Erwartung und Ereignis sind verschiedene
  Größen), Volumen beider Börsen summiert, Binance-Kennzahlen unter den Walen,
  Konfluenz mit beiden Regelsätzen und Funding-Vergleich.

**Crypto.com als dritte Börse** (Binance- und Fusionsmodus): Open Interest,
24-h- und Stundenvolumen, Taker-Flow aus den letzten 150 Trades, Prämie des
Perpetuals gegen den Index (Funding-Näherung), Orderbuch — in der Fusion je
Preisstufe zu HL-Orders und Binance-Buch addiert. Die Konfluenz rechnet den
Taker-Flow **börsenübergreifend**, nach Volumen gewichtet, als einen Punkt;
sind die Börsen uneins, gibt es keinen Punkt, nur den Hinweis. Eine
gegenläufige Prämie zum Hyperliquid-Funding erscheint als Hinweis. Die
Marktdaten sind öffentlich — kein Schlüssel nötig. Coins, die Crypto.com nicht
handelt, zeigen „—".

**Bybit und OKX** (Binance- und Fusionsmodus, öffentliche Endpunkte, kein
Schlüssel): Open Interest, Funding, 24-h-Volumen, Long/Short-Konten, Taker-Flow
(Bybit aus 500 Trades, OKX aus der 5-min-Statistik), OKX zusätzlich die
jüngsten Liquidationen. Kacheln: „Open Interest N Börsen" mit Aufteilung,
„Taker börsenübergreifend" volumengewichtet, „Long/Short Konten je Börse",
„Funding Ø Börsen". Konfluenz: der Taker-Flow aller erreichbaren Börsen ist
ein Punkt; börsenübergreifend einseitige Konten (Ø ≥ 2,5 : 1 oder ≤ 0,6 : 1) und
OKX-Liquidationen ab 5 Mio/h sind Hinweise.

**ETF-Flows** (BTC und ETH, jede Quelle): tägliche Netto-Flüsse der US-Spot-
ETFs, einmal pro Stunde von der Farside-Tabelle gelesen; mit CoinGlass-Schlüssel
in `accesstokens.json` stattdessen von CoinGlass. Kachel mit letztem Tag,
5-Tage-Summe und Serie. Konfluenz: ein Punkt, wenn letzter Tag und 5-Tage-Summe
dasselbe Vorzeichen haben, sonst Hinweis. Ein Tageswert — Regime, nicht Timing.

**Leaderboard und Smart Money.** Beim Start lädt der Recorder das Leaderboard
**zuerst** — Konten, Positionen und die Trendzeile der laufenden Stunde stehen,
bevor Feeds und Polling beginnen; das Dashboard ist damit sofort vollständig.
Danach lädt der Recorder alle 10 Minuten das
Hyperliquid-Leaderboard, geht die Konten nach 30-Tage-PnL von oben durch und behält die ersten 50, die
auf dem Perp-Konto tatsächlich Positionen halten (`--lb-top`, aus den besten
400, `--lb-candidates`). Das ist nötig, weil das Leaderboard Spot, Vault-Anteile
und Unterkonten mitzählt — die Spitze nach PnL sind Vaults und Market Maker
ohne Perp-Position. Flache Konten werden eine Stunde gemerkt, damit die Auswahl
nicht jede Runde das volle Gewicht kostet (erster Durchgang bis zu 400 Abfragen,
danach etwa 60 je Runde). „Kontowert" ist das Perp-Konto (`marginSummary`),
nicht der Leaderboard-Wert. Tabellen: `lb_accounts` (Rang, Name,
Kontowert, PnL 30 T / 7 T), `lb_positions` (Coin, Seite, Wert, Hebel, Einstieg,
Liq.-Preis, unreal. PnL, Kurs) je Abfrage und `lb_trend` einmal pro Stunde je
Coin für Top 20 und Top 50: Konten und Wert je Seite, Netto, Kurs — die
Zeitreihe für die spätere Auswertung, ob die Positionierung der Besten dem Kurs
vorausläuft. Dashboard-Abschnitt 7 zeigt die Top 20 mit allen Positionen und
PnL (gruppiert wie die Wale, Export als Chart und Liste) und den Trend-Chart des
gewählten Coins: Long- und Short-Wert je Stunde, Netto als Linie, Kurs weiß.
Kachel „Leaderboard Top 20 — BTC-Trend“: Konten und Wert je Seite in BTC,
Netto und dessen Veränderung gegen 24 h und 7 Tage. Konfluenz: Drehung des
Netto-Vorzeichens oder Aufbau ≥ 25 % innerhalb 24 h als Hinweis. Die
Smart-Money-Kachel (Top 50) liest dieselbe Abfrage; Punkt ab 1,5-fachem Übergewicht.

**Käufe und Verkäufe der Top-Konten** (Abschnitt 8). Der Recorder holt etwa
90 s nach dem Start und dann stündlich für die 50 Top-Konten die Fills der
letzten 3 Tage (`userFillsByTime`, Gewicht 20 je Konto, eine Seite à 2.000
Fills je Lauf, Perp **und** Spot, nur Fills ab 5.000 USD — Market-Maker-Staub
bleibt draußen; ältere Fills werden gelöscht, die Tabelle bleibt klein) und
die Spot-Bestände (`spotClearinghouseState`, Gewicht 2) — rund 1.100 Gewicht
pro Stunde. Der Abholstand je Konto steht in `lb_cursor` und richtet sich nach dem neuesten
**geholten** Fill, nicht nach dem neuesten gespeicherten: Ein Konto, dessen Fills
sämtlich unter 5.000 USD liegen, hätte sonst nie einen neueren Eintrag, und die
Abholung liefe für immer gegen dieselbe Stelle (beobachtet: die Trade-Liste stand
18 Stunden still). Kommt ein Konto trotz drei Seiten à 2.000 Fills mehr als 6 Stunden
in Rückstand, springt die Abholung auf die letzten 2 Stunden. Der übersprungene
Zeitraum wird in `lb_gaps` festgehalten und im Vollbericht aufgelistet — eine Lücke,
von der man weiß, ist brauchbar; eine unbekannte verfälscht jede Auswertung — eine Lücke ist besser
als dauerhafter Rückstand, weil die Signale von den letzten Stunden leben.
Teilausführungen einer Order werden in den Tabellen je Minute gebündelt (»17×«),
sonst füllen Dutzende identischer Zeilen die Ansicht.
Tabellen `lb_fills` (dedupliziert über Konto und tid; Spot-Paare
über `spotMeta` auf den Basistoken abgebildet, UBTC → BTC, UETH → ETH,
USOL → SOL) und `lb_spot` (Stundenstand mit Einstandswert und USD-Wert).
Dashboard: Übersicht je Coin — Käufe, Verkäufe, Konten je Seite, Netto 3 T und
24 h, Spot-Anteil, realisierter PnL —, die größten Trades im gewählten Coin mit
der Kursentwicklung seit dem Trade aus Sicht des Traders, die Spot-Bestände mit
Entwicklung seit Einstand. Kaufdruck = Open Long + Close Short + Spot-Kauf.
Kachel „Leaderboard Käufe/Verkäufe" mit Netto 24 h und 3 T. Die Summen rechnet
SQLite über die Spalte `buy`, das Ergebnis wird im Hintergrund alle 30 s
erneuert — der Chart-Aufruf wartet nie darauf.
Abschnitt 9 zeigt dieselben Fills für die letzten 48 Stunden: je Stunde
Kauf- und Verkaufsdruck im gewählten Coin als Balken, den aufgelaufenen Netto-
Wert als Linie, den Kurs weiß; darunter die Übersicht je Coin und alle Trades ab
50k, neueste zuerst — für ganz aktuelle Signale. Konfluenz: ein
Punkt ab 1,5-fachem Übergewicht in 24 h bei mindestens 1 Mio und 3 Konten.

**accesstokens.json** — eine normale Datei im Projektordner für Schlüssel
optionaler Quellen (CoinGlass, CryptoQuant, Glassnode, Nansen, Arkham), leer
vorbelegt; `update.py` überschreibt sie nie. Nichts davon ist heute nötig;
sobald ein Schlüssel eingetragen ist, kann die jeweilige Quelle angeschlossen
werden. Für Tests ohne Netz liefert `HL_TEST_STUBS=1` feste Crypto.com-Antworten.

Die Wahl bleibt im Browser gespeichert. Live-Abrufe von Binance (Kerzen kurzer
Raster, Orderbuch, Funding, Verhältnisse) werden 15 s bis 5 min im Speicher
gehalten; ohne Netz greift die Datenbank, das Orderbuch meldet sich dann ab.

**Debug-Konsole** (Abschnitt ganz unten): startet ein Diagnoseskript oder liest
ein Journal aus einer festen Liste — Leaderboard-Diagnose, Order-Abfragen,
Tageskerzen, Speicherbelegung, Recorder-Audit und -Status, Binance-Status,
Journale der drei Dienste, Update-Log, Dienststatus, Datenträger. Läuft als
Dashboard-Benutzer ohne sudo, kein freies Kommando. Ganz oben steht **„★ VOLLBERICHT"** — ein Lauf, der
in zwei Minuten den kompletten Systemzustand sammelt: Dateiversionen und
Dienste, Tabellenstände mit Zuwachs je Stunde, API-Gewicht und Poller-Zustand,
Aufgabenabstürze, Temperaturschutz und Backup, Leaderboard und Wal-Gruppen mit
Flow, Lernstand und Trefferquoten der Prognose, Temperatur und Speicher, dazu
die auffälligen Journalzeilen aller drei Dienste. Die Stundenraten werden aus den Zeitstempeln gezaehlt, nicht aus einem kurzen Fenster hochgerechnet — ein Strom, der in Schueben schreibt, ergab sonst je nach Messzeitpunkt 0/h oder 353.000/h. Dazu eine Zeile „Groesste Luecke in den letzten 24 h“ je Datenstrom: Ein stiller Ausfall zeigt sich nicht an der Zeilenzahl, sondern am Abstand zwischen zwei Eintraegen. Ein Fehler in einem Abschnitt
bricht den Bericht nicht ab, sondern steht darin. Gedacht zum Einfügen in einen
Chat — „Als Datei" für lange Berichte. Die Ausgabe erscheint in einem
Textfeld. „Konsole kopieren" legt sie mit Kopfzeile (Lauf, Zeit, Coin, Quelle,
Exit-Code) in die Zwischenablage — auch über HTTP, wo die Zwischenablage-API
gesperrt ist, per Kopierbefehl aus dem Textfeld. „Alles markieren" wählt den
Text für das Handy-Menü aus, „Als Datei" speichert ihn als .txt zum Teilen. Journale
brauchen Leserecht (Gruppe `systemd-journal`: `sudo usermod -aG systemd-journal seed`).

**Temperaturschutz im Recorder.** Der Recorder liest alle 30 s die
CPU-Temperatur und drosselt sich in drei Stufen, jeweils mit 3 °C Hysterese
beim Verlassen: ab 70 °C 15 % weniger API-Gewicht pro Minute und 15 % längere
Takte (Positions-Polling aller Stufen, Order-Abfragen, Leaderboard, Fills); ab
75 °C 30 % / 45 %; ab 80 °C 50 % / doppelte Takte. Die Feeds laufen unverändert
weiter — sie kosten kein Gewicht, nur die Abfragen werden gestreckt. Stufe und
Faktoren stehen im Journal, in der API-Kachel („Temperaturschutz Stufe 1:
Gewicht −15 %, Takte +15 %") und im System-Abschnitt.

**System — Temperatur und Zustand des Pi** (ganz unten, unter Debug). Der
Dashboard-Server misst alle 60 Sekunden CPU-Temperatur (Thermal-Zone, sonst
`vcgencmd`), Drosselungsflags der Firmware (Unterspannung, Takt begrenzt,
gedrosselt, Temperaturlimit — jeweils jetzt und seit Start), CPU-Takt,
CPU-Last gesamt in Prozent (aus `/proc/stat`, gemittelt über die Minute) mit
Last 1/5/15 min, RAM gesamt / frei (MemAvailable) mit belegtem Anteil, freien Platz auf System- und Datenbank-Datenträger und Laufzeit; er
hält 24 Stunden Verlauf, die Seite fragt jede Minute nach. Kacheln mit Farben
(grün < 60, gelb < 70, orange < 80, rot ≥ 80 °C — der Pi 5 drosselt ab 80 °C)
und ein Verlaufs-Chart: Temperatur gelb mit den Linien 70 und 80 °C, CPU-Last
blau auf der rechten Skala 0–100 %. Endpunkt `/system`.

**Fehlerleiste.** Rote Leiste oben bei Verbindungs- oder Skriptfehlern.
Verbindungsfehler verschwinden von selbst, sobald wieder Daten ankommen —
etwa wenn das Handy den Browser aus dem Hintergrund holt: Die Seite erkennt
den sichtbaren Tab, lädt sofort neu und räumt die Leiste mit der ersten
erfolgreichen Antwort weg. Skriptfehler bleiben stehen, die gehen nicht von
allein weg.

**PNG-Export.** Das „⤓" im Titel eines Abschnitts (und der Link unter dem
Binance-Kennzahlen-Chart) speichert den Chart als PNG in dreifacher
Auflösung — der Chart wird dafür neu gezeichnet, nicht hochskaliert, Linien
und Schrift bleiben scharf. Kopfzeile mit Titel, Coin, Quelle und Zeitstempel,
Dateiname `hl_<chart>_<coin>_<quelle>_<datum-uhrzeit>.png`. Bei 1.370 px
Chartbreite ergibt das rund 4.200 px Breite. Der Wal-Abschnitt hat zwei
Exporte: „⤓ Chart“ für das Exposure-Chart und „⤓ Liste“ für die gruppierte
Wal-Liste mit allen Positionen, Namen und Verhaltensklassen — bei sehr langen
Listen in mehreren Teilen (`_teil1`, `_teil2`), damit die Bildhöhe die
Browser-Grenze nicht überschreitet.

**Was bleibt bei Neustart und Update erhalten.** Alles, was zählt, liegt in
Dateien: die Aufzeichnung in der Datenbank auf dem USB-Stick; Prognosen,
gelernte Gewichte und der Lernstand (Analog, Magneten, Zeitprofil) in
`forecasts.db` im Projektordner; Wallet-Zuordnungen in `labels.json` und
`labels_cache.json`; Schlüssel in `accesstokens.json`; der Systemverlauf
(Temperatur, CPU) in `updates/sys_history.json`, alle 5 Minuten gesichert.
`update.py` ersetzt nur die Programmdateien und rührt diese Dateien nicht an.
Im Browser bleiben Quelle und eingeklappte Abschnitte gespeichert. Neu aufgebaut
werden nach einem Neustart nur Zwischenspeicher: Live-Abfragen der Börsen, die
Positionskarte des Recorders (nach einer Abfragerunde wieder voll) und die
Merkliste flacher Leaderboard-Konten (der erste Durchgang prüft bis zu 400
Konten, danach wieder 60). `forecasts.db` ist NICHT Teil des
Datenbank-Backups — wer sie sichern will, kopiert die Datei mit.

**Prognose-Chart bedienen.** Ansicht 24 h / 3 T / alles, ◀ ▶ zum Blättern,
„jetzt" zentriert. Ziehen mit Maus oder Finger scrollt, Mausrad und Pinch
zoomen, Fahren oder Tippen zeigt Stunde, Prognose, Band und reines Modell.
Unter 30 h Spanne Stundenraster, unter 5 Tagen 6-Stunden-Raster; die
Preisskala folgt dem sichtbaren Ausschnitt.

**AI-Prognose** (Abschnitt nach der Konfluenz, Modul `hl_forecast.py`). Alle
15 Minuten je Coin im Hintergrund, sofort auf Abruf beim ersten Mal. Vier Teile:
Regime und Drift (MA 200 T, MA 50 W, 60-min-Trend, RSI, 7-Tage-Drift);
Richtungsdruck nur aus direktionalen Konten (direktionale Wale, direktionales
Smart Money, Käufe/Verkäufe direktionaler Leaderboard-Konten 24 h,
Top-20-Trend) plus Taker-Flow aller Börsen, Funding gegen die Menge, ETF-Flows,
Orderbuch; Magneten (Liq-Cluster ziehen, Wände bremsen, gekreuzter Stop-Auslöser
wird zur Kaskade); Pfad Stunde für Stunde bis 7 Tage mit Band aus der
realisierten Volatilität × √t. Ergebnis: Bias mit Konfidenz, optimaler Kaufpreis
und Verkaufspreis im Fenster 4–12 h mit Begründung (an Wänden und Clustern
ausgerichtet; bei klarem Gegendruck „nicht ratsam"), nächste Bewegung, 7-Tage-
Endpunkt mit Band, alle Treiber mit Richtung und Gewicht. Jede Prognose landet
in `forecasts.db` (eigene Datei des Dashboards); nach 4 und 24 h wird die
Richtung gegen den echten Kurs geprüft — Trefferquote und mittlerer Fehler
stehen in der Kachel. Endpunkt `/forecast?coin`. Kein Orakel: ein Modell aus
sichtbaren Daten, dessen Trefferquote über die Wochen zeigt, was es taugt.

**Leaderboard-Flow — Positionsänderungen der Top-Konten als Ereignisse.**
Der Recorder fragt die 50 Top-Konten alle 5 Minuten ab und leitet aus dem
Vergleich zweier Stände Ereignisse ab: open, add, reduce (ab 2 % Änderung),
close, flip — Tabelle `lb_events`. Das Dashboard rechnet daraus den
Leaderboard-Flow der direktionalen Konten über 60 Minuten und 3 Stunden, mit
Z-Score gegen die eigenen Stundenflüsse; ab 500k brutto und zwei Konten ein
Konfluenz-Punkt, ab Z 2,5 und drei Konten ein Ereignis-Signal mit zwei Punkten,
in der Prognose ein Treiber mit Gewicht 1,0. Der Wächter reagiert auch auf
diese Ereignisse mit einer Sofortberechnung. Abschnitt 7 zeigt den Flow live
und die letzten Änderungen der Top-Konten; nicht-direktionale sind ausgegraut.
Latenz: bis zu 5 Minuten (Abfragetakt) — die Fills (stündlich) bleiben die
Quelle für Perp und Spot im Detail.

**Ereignisse werden aus der Positions-GRÖSSE abgeleitet, nicht aus dem Wert.**
Der USD-Wert einer Position ändert sich auch, wenn nur der Kurs läuft: Eine
113-Mio-Position schwankt bei 1 % Kursbewegung um 1,1 Mio, ohne dass jemand
handelt. Deshalb vergleicht der Recorder die Größe (`szi`) zweier Stände;
`delta_usd` ist die gehandelte Menge mal Kurs. Die Schwelle ist absolut statt
prozentual: Wale ab 25.000 USD gehandelt (`--event-min-usd`),
Leaderboard-Konten ab 12.500 (`--lb-event-min-usd`). Verglichen wird gegen den
zuletzt **protokollierten** Stand, nicht gegen den letzten Schnappschuss: Fünf
Zukäufe von je 20.000 blieben sonst einzeln unter der Schwelle und verschwänden,
obwohl sie zusammen 100.000 ergeben. So summieren sie sich zu zwei Ereignissen
à 40.000. Hintergrund: Große Konten
halten eine **Kernposition** und handeln mit kleinen Anteilen um sie herum —
Short in den Dip, Rückkauf im Long. Bei einer 2-%-Schwelle fiel genau dieses
Verhalten durch, obwohl es die eigentliche Strategie ist; zugleich erzeugte die
Wertmessung in bewegten Phasen erfundene Ereignisse. Die Flow-Schwellen sind
entsprechend gesenkt (Wale 150k brutto, Leaderboard 75k); den Maßstab setzt
ohnehin der Z-Score gegen die eigene 7-Tage-Verteilung.

**Abdeckung und Schwellen (Stand 13.09.2026).** Verfolgt werden **75** Top-Konten
(vorher 50) aus den besten 600 nach 30-Tage-PnL. Der Grund: Von 50 Konten halten
nur etwa zwölf überhaupt BTC — die Abdeckung je Coin hängt an der Zahl der Konten,
nicht an der Schwelle. Alle Betragsschwellen wurden halbiert: Wal-Ereignis 25.000,
Leaderboard-Ereignis 12.500, Fill 2.500, Kontowert 250.000, Wal-Flow-Signal 150.000
brutto, Leaderboard-Flow 75.000, Anzeige 50.000 (3 Tage) und 25.000 (48 h).
Mehrbedarf an API-Gewicht: rund 19 Einheiten je Minute, von 85 auf etwa 87 Prozent.
Mehr Daten: `lb_fills` etwa doppelt so viele Zeilen (75 statt 43 MB für 3 Tage).

**Gruppen statt Ausschluss — und die Klasse gilt je Coin.** Die
Verhaltensklasse wird für jedes Konto **in jedem Coin einzeln** bestimmt: Wer
BTC short und ETH long hält, ist kontoweit „gemischt", in BTC aber klar
positioniert. Maßgeblich ist das Verhalten im betrachteten Coin. Vier Gruppen:
direktional, Hedge, Market Maker, gemischt. Hat ein Konto in diesem Coin gerade
keine Position (etwa weil es sie geschlossen hat), gilt seine kontoweite Klasse —
ein Market Maker bleibt ein Market Maker. Konten, die nicht mehr in der Wal-Liste
stehen, aber im Zeitraum Ereignisse hatten, zählen mit; sonst fiele der Ausstieg
eines Wals aus jeder Gruppe heraus. **Keine Gruppe wird ausgeschlossen** —
jede bekommt ihren eigenen Flow mit eigenem Z-Score und in der Prognose einen
eigenen Treiber (Startgewichte 1,3 / 0,4 / 0,4 / 0,6). Welche Gruppe wirklich
Vorlauf hat, misst die Selbstkalibrierung an der Trefferquote; Ausschließen
wäre eine Annahme, Messen ist Wissen. In der Konfluenz geben vorerst nur die
direktionalen Konten Punkte, die übrigen erscheinen als Hinweis — das ändert
sich, sobald die Trefferquoten vorliegen. Kachel und Ereignisliste zeigen alle
Gruppen; die Liste färbt nach der Klasse im gewählten Coin.

**Wal-Flow — Positionsänderungen als Ereignis-Signal.** Wale ab 20 Mio werden
jede Minute abgefragt; ihre Positionsänderungen sind das schnellste Signal des
Systems und reagieren auf Nachrichten, bevor sie lesbar sind. Der Wal-Flow
summiert für die direktionalen Wale die Änderungen der letzten 15, 30 und 60
Minuten im gewählten Coin: Long eröffnet/aufgestockt oder Short reduziert/
geschlossen zählt als Kauf, umgekehrt als Verkauf. Maßstab ist der Z-Score
gegen die eigene Verteilung der Stundenflüsse der letzten 7 Tage; die Breite
zählt, wie viele Wale in dieselbe Richtung gingen. Ab Z 2,5 und vier Walen
gilt ein **Ereignis-Signal**: in der Konfluenz zwei Punkte statt einem, in der
Prognose ein Treiber mit Gewicht 1,3 (× 1,5 beim Ereignis), die erste Bewegung
wird kürzer angesetzt. Kachel „Wal-Flow 30 min" mit ⚡ beim Ereignis. Der Flow
zählt ab 1 Mio brutto und zwei Walen; qualifiziert sich das 30-min-Fenster
nicht, gilt das 60-min-Fenster — so werden auch langsame Serien kleiner Schritte
erfasst. **Sofortberechnung:** ein Wächter prüft alle 30 s, ob ein direktionaler
Wal seine Position geändert hat, und rechnet die Prognose dann sofort neu
(höchstens alle 2 min je Coin); die Seite fragt die Prognose jede Minute ab.
Die Zeile „Wal-Flow live" im Prognose-Abschnitt aktualisiert sich alle 20 s und
sagt, ob der Fluss die Prognoserichtung bestätigt oder ihr widerspricht. In der
Liste „Letzte Änderungen" trägt jeder Wal seine Verhaltensklasse; nicht-
direktionale sind ausgegraut.

**Selbstoptimierung der Prognose.** Fünf Bausteine, alle aus vorhandenen Daten:

1. *Gelernte Gewichte* — je Treiber wird aus den gespeicherten Prognosen die
   Trefferquote seines Vorzeichens gemessen; ab 40 bewerteten Prognosen lernt
   ein Logit auf die 24-h-Richtung die Gewichte, mit dem Prior als Anker (wenig
   Daten: Prior hält; viel Evidenz: Daten gewinnen) und der Grenze 0 bis 2 ×
   Prior — ein Treiber wird auf- oder abgewertet, nie umgedreht. Trainiert wird
   auf höchstens den jüngsten 2.000 Fenstern mit 14 Tagen Halbwertszeit: die
   Laufzeit bleibt bei rund 2,5 s auf dem Pi konstant, und ein Regimewechsel
   wird nachvollzogen statt ausgemittelt. Zeitlicher Verlauf bei etwa 90
   bewerteten Fenstern am Tag: ab 40 beginnt das Lernen, nach 1–2 Tagen ist die
   Rangfolge der Treiber erkennbar, nach etwa 5 Tagen (500 Fenster) sind die
   Gewichte stabil, danach ändern sie sich nur noch mit dem Marktregime. Tabelle
   `weights` in `forecasts.db`, alle 15 min. Prognosen mit der aktuellen
   Gewichtsversion werden getrennt bewertet: „Out-of-sample" ist die ehrliche
   Trefferquote, nicht an den Daten gemessen, mit denen kalibriert wurde.
2. *Analog-Suche* — die Kursreihe muss **bis jetzt reichen**: die Historie kommt
   aus `klines30` (von `hl_timestats` einmalig geladen), die letzten Tage werden
   aus `bnc_bars` bzw. den eigenen Bars angestückelt. Ohne das endete die Reihe
   dort, wo `hl_timestats` zuletzt lief — gemessen acht Tage zurück, und die
   Analoge passten zu einem Markt, den es nicht mehr gab. Zustandsvektor (Renditen 1/7/30 T, Volatilität, RSI, Lage
   zum 7-Tage-Mittel, Tageszeit, Wochentag) gegen bis zu drei Jahre
   30-min-Kerzen; die 50 ähnlichsten Momente, mindestens 6 h auseinander, die
   letzten 7 Tage ausgeschlossen. Ihre tatsächlichen Verläufe liefern Median
   und 20/80-Quantile je Horizont, als Treiber und als Pfad im Ensemble.
3. *Magnet-Statistik* — aus Heatmap-Snapshots (einer je 15 min, 14 Tage):
   Wahrscheinlichkeit, dass ein großes Cluster binnen 12 h erreicht wird,
   Überschuss darüber hinaus und Rückkehr danach, nach Abstandsklassen 0–1,
   1–2, 2–3 %. Ersetzt die festen Annahmen des Pfadmodells; stündlich.
4. *Zeitprofil* — Volatilität je Wochentag und Stunde aus der Kurshistorie
   skaliert das Band je Stunde voraus.
5. *Ensemble und Kapitulation* — Modellpfad und Analog-Median werden nach den
   laufenden Trefferquoten beider Modelle gemischt (Prior 60/40); ein Schub
   eingetretener Liquidationen (≥ 4 × Durchschnitt) wird zum Treiber
   „Kapitulation".

Alles läuft im Hintergrund; der Abschnitt zeigt den Lernstand offen, dazu den
**Lernplan** mit konkreten Zeitpunkten: gespeicherte und bewertete Prognosen,
nächste 4-h- und 24-h-Bewertung, voraussichtlicher Lernbeginn (die 40.
Prognose plus 24 h), letzte Prüfung und letzte Änderung der Gewichte, nächste
Prüfung, Stände von Analog-Suche, Magnet-Statistik und Zeitprofil, nächste
Prognose. Der Abschnitt zeigt außerdem gelernte
Gewichte mit Trefferquote je Treiber, Ensemble-Gewichte mit Herkunft,
Analog-Ergebnis mit den nächsten Beispielen, Magnet-Statistik, Out-of-sample.

**Kaskadenprognose.** Die Konfluenz nennt bei drohenden Kaskaden Auslöser, Art
und Ziel: „Verkaufskaskade (Long-Squeeze) ab 76.850 (−0,65 %): Druck 58,9 Mio
gegen Aufnahme 59,1 Mio — Ziel ≈ 75.900 (−1,9 %) · Kette: … · größte Aufnahme
39 Mio bei 76.100". Modell: vom Kurs weg in 0,25-%-Stufen; Auslöser ist das
erste Stop- oder Liquidationscluster ab 25 % des Stundenvolumens (mind. 5 Mio);
ab dort summiert sich der Druck aus Stops und Liquidationen derselben Richtung,
dagegen die Aufnahme aus ruhenden Limits (Support/Resistance, Take-Profits)
plus 5 % des Stundenvolumens je Stufe als organische Aufnahme; das Ziel ist die
Stufe, auf der die aufgelaufene Aufnahme den aufgelaufenen Druck einholt.
Long-Squeeze = Kaskade nach unten (Longs werden gestoppt und liquidiert),
Short-Squeeze = nach oben. Liegt der Auslöser innerhalb 3 %, zeichnet der
Live-Chart Auslöser (orange gestrichelt) und Ziel (orange gepunktet) ein. Ein
Modell aus sichtbaren Orders — es kennt weder Orders, die erst in der Kaskade
kommen, noch die Gegenseite auf anderen Börsen; „offen" heißt, die sichtbare
Aufnahme reicht im Modell nicht.

**Kacheln und Einheiten.** Jedes Label nennt die Einheit: USD für Kurs,
Notional, Volumen und Open Interest; Prozent für Trend und MA-Abstand;
„Anzahl" für Adressen; 0–100 für den RSI. Verhältnis-Kacheln (Long/Short
Konten, Long/Short Top-Trader, Taker Kauf/Verkauf) zeigen „a : 1" und darunter
die Aufteilung in Prozent — „1,27 : 1" heißt 56 % long, 44 % short. Jede
Kachel trägt die Definition als Tooltip (Maus darüber, am Handy lange
antippen). Die Binance-Verhältnisse stammen aus den Binance-Endpunkten
`globalLongShortAccountRatio` (Konten), `topLongShortPositionRatio`
(Positionswert der größten Konten) und `takerlongshortRatio` (aggressives
Kauf- zu Verkaufsvolumen, 5-min-Fenster).

**FVG-Mindestgröße.** Ein Fair Value Gap ist die Lücke zwischen dem Hoch von
Kerze 1 und dem Tief von Kerze 3 (bullisch) bzw. umgekehrt (bärisch). Die
Mindestgröße ist diese Lücke als Anteil des Kurses — 0,05 % bei 80.000 USD
sind 40 USD. Kleinere Lücken gelten als Rauschen und werden weder gezeichnet
noch in der Konfluenz gezählt.


Drei Panels auf `http://<pi>:8765`, jedes mit Überschrift, Legende und
Achsenbeschriftung. Mit der Maus darüberfahren oder antippen zeigt eine Box mit
den Werten an dieser Stelle — Zeitpunkt, Preisniveau, Notional, Perzentil-Rang
und Art der Liquidation.

- **Live-Chart** — Kerzen mit den aktuellen Liquidationslevels als waagerechte
  Linien. Rot unterhalb des Kurses sind Long-Liquidationen, grün oberhalb
  Short-Liquidationen. Durchgezogene Linien liegen bei mindestens dem halben
  Stundenvolumen und können den Kurs bewegen, gestrichelte werden eher
  absorbiert. Aktualisiert alle 5 Sekunden, Zeitraster von 1 min bis 1 h.
- **Fair Value Gaps** im Live-Chart, rein aus den Kerzen berechnet, nichts
  wird gespeichert. Dreikerzen-Lücken: bullisch, wenn das Tief der dritten
  Kerze über dem Hoch der ersten liegt, bärisch spiegelbildlich. Offene Zonen
  kräftig mit gestricheltem Rahmen und Teilfüllungsbalken, gefüllte blass bis
  zur füllenden Kerze. Ein Schalter neben der Coin-Auswahl blendet sie ein oder aus,
  die Mindestgröße ist wählbar (0,05 / 0,1 / 0,25 %). Die Infozeile nennt offene Zonen je Richtung und die nächste zum Kurs;
  der Tooltip zeigt Zone, Größe und Füllgrad.
- **Chart-Raster** — 1 min bis 1 h aus den eigenen Minutenbars; dazu
  „4 h · 30 Tage", „1 Tag · 1 Jahr" und „1 Woche · 5 Jahre" aus den
  vorhandenen Tabellen: 4 h aus `klines30` (Binance-30-min-Kerzen, falls
  `hl_timestats` sie geladen hat), die jüngsten Stunden aus den eigenen Bars;
  Tage und Wochen aus `daily_bars` (5 Jahre, von `hl_binance`). Fehlt eine
  Tabelle, holt das Dashboard die Kerzen direkt von Binance (5 min im
  Speicher gehalten). Die Infozeile nennt die Quelle, die Zeitachse zeigt bei
  Tagen und Wochen das Datum.
- **Gleitende Durchschnitte** — zwei Kacheln in der Kopfzeile: MA 50 Wochen
  und MA 200 Tage, grün mit ▲ wenn der Kurs darüber steht, rot mit ▼ darunter,
  jeweils mit Abstand in Prozent. Der Tooltip zeigt zusätzlich MA 50 Tage und
  MA 200 Wochen sowie Golden/Death Cross. Berechnet aus Tageskerzen in
  `daily_bars`, die `hl_binance.py` beim Start und alle 6 h nachlädt (5 Jahre;
  Quelle je Coin: Binance-Futures, sonst Binance-Spot, sonst Hyperliquid —
  XMR etwa führt Binance nicht mehr). Primärschlüssel (Tag, Coin), Nachladen
  ersetzt statt zu doppeln. Manuell: `hl_binance.py --backfill-daily`.
  Liegen die Linien im sichtbaren Preisbereich, erscheinen sie gestrichelt
  im Chart.
- **Stop-Orders der Wale** — eigenes Panel. Trigger-Orders stehen nicht im
  Orderbuch; sie werden erst am Auslösepreis zu Market-Orders, wie
  Liquidationen. Der Recorder fragt alle Adressen mit Positionen ab 20 Mio USD
  alle 2 Minuten nach ihren offenen Orders (`frontendOpenOrders`, Gewicht 20)
  und speichert sie in `trigger_orders`. Das Panel zeigt je Preisniveau
  Sell-Stops (rot, Verkaufskaskade nach unten), Buy-Stops (grün, Kaufkaskade
  nach oben), Take-Profits (grau, absorbieren) und Limit-Orders (blau) mit
  Notional, Zahl der Wale und Abstand zum Kurs. Budget über `--stop-budget`
  (Gewicht/min, Standard 240) und `--stop-interval`.
- **API-Budget** — Kachel mit dem Hyperliquid-Gewicht der letzten Minute
  gegen das Limit von 1200 (grün unter 70 %, gelb bis 90 %, rot darüber).
  Der Limiter rechnet jetzt in Gewicht: Positionsabfrage 2, Order-Abfrage 20.
  Wächter und Audit warnen ab 80 %.
- **Wartende Orders und Stops** — eigenes Panel: Sell-Stops (rot, Verkaufs-
  kaskade), Buy-Stops (grün, Kaufkaskade), Limit-Käufe (cyan, Kaufwand),
  Limit-Verkäufe (violett, Verkaufswand), Take-Profits (grau). Kaufseite links,
  Verkaufsseite rechts einer Mittelachse, je Preisstufe ein nach Art gestapelter
  Balken, fester Preisbereich ±30 %. Darunter die Live-Auswertung: Support
  (größte Kaufwand unter dem Kurs), Resistance (größte Verkaufswand darüber),
  höchste Take-Profits beider Seiten, größte und nächste Stop-Cluster, Stop-
  Summen innerhalb 2 %. Dieselben Niveaus erscheinen als beschriftete Linien im
  Live-Chart (Support cyan, Resistance violett, Take-Profits grau gestrichelt,
  Stops gepunktet) und gehen in die Konfluenz ein. Fahren oder Tippen zeigt in
  allen vier Charts ein Fadenkreuz mit dem Preis am Rand. Quelle ist `frontendOpenOrders` je Adresse — Trigger-
  Orders stehen nicht im Orderbuch, nur dort. Abgefragt werden alle Konten ab 250k USD,
  gestaffelt nach Größe — ab 20 Mio alle 10 min, 5–20 Mio alle 45 min, 1–5 Mio alle
  3 h, darunter alle 6 h — in einem Gewichtsbudget von 320/min (`--stop-budget`,
  `--stop-min-usd`, `--stop-interval`). Bei ~1.200 Kandidaten ist ein einheitlicher
  Takt unmöglich; das Panel zeigt je Konto den jüngsten Stand und dessen Alter.
  Tabelle `trigger_orders`, jede Abfrage als Zeitscheibe. Dazu alle 10 Minuten
  `order_levels`: Support, Resistance, Take-Profit- und Stop-Niveaus, Stop-Summen
  innerhalb 2 % und der Ordermix (Notional je Art innerhalb ±30 %) je Coin — mit
  derselben Rechnung wie das Dashboard, als Zeitreihe neben der Heatmap. Damit
  lässt sich später prüfen, ob der Kurs zum Liquidationscluster, zur Kaufwand
  oder zum Stop-Cluster zog, und wie sich der Ordermix vorher verhielt.
- **API-Last / Minute** — Kachel mit verbrauchtem Gewicht, Prozent und Reserve.
  Der Recorder deckelt sich selbst bei 90 % der 1.200 Einheiten (seit 17.09.; davon 20 % Reserve nur für Fills); Positions-
  abfragen (Gewicht 2) und Order-Abfragen (Gewicht 20) teilen sich den Deckel,
  Wale werden nie von Großkonten verdrängt. Der Wächter warnt ab 85 %.
- **Konfluenz** — eine Kachel plus ein Panel, das zählt, wie viele der
  sichtbaren Faktoren in dieselbe Richtung zeigen: frisch abgeräumte
  Liquidationscluster, offene FVGs am Kurs, RSI-Extreme, Orderbuch-Imbalance,
  Funding, Ausrichtung der direktionalen Wale (Hedges und Market Maker ausgenommen), Lage des Kurses zum MA 200 Tage und zum MA 50
  Wochen (je ein Punkt), Kauf-/Verkaufswände aus ruhenden Limit-Orders (je ein
  Punkt), Stop-Cluster dicht am Kurs („Abwarten", Kaskade droht; zusammen mit
  einem Liquidationscluster auf derselben Seite „doppelter Magnet"),
  Take-Profits als Hinweis. Ein großes Cluster dicht am Kurs ergibt — ebenso
  große Wal-Stops innerhalb 0,8 % (ab 25 % des Stundenvolumens, mindestens
  5 Mio); liegen Stops und Liquidationscluster auf derselben Seite, meldet
  das Panel einen „doppelten Magneten". Solche Fälle ergeben
  „Abwarten — Anlauf wahrscheinlich" statt einer Richtung. Ab drei Punkten
  netto steht „Kauf-" oder „Verkaufs-Konfluenz". Jede Regel und jede Schwelle
  steht im Panel. Trägt ein Faktor ein Preisniveau — Kaskadentief, Squeeze-Hoch,
  FVG am Kurs — wird es als Kauf- oder Verkaufszone im Chart eingezeichnet — als
  Fenster am rechten Rand über die letzten Kerzen, nicht als Band über die
  Historie, denn die Zone ist ein Zustand jetzt.
  Stammen die Punkte nur aus Wale, Orderbuch, Funding oder RSI, gibt es keine
  Zone, und das Panel sagt warum. Eine Danger-Time aus der Zeit-Heatmap
  erscheint als Warnung ohne Richtung. **Das ist eine Zählung sichtbarer Faktoren, keine Prognose
  und nicht validiert** — die zugrunde liegende These ist genau das, was der
  Recorder erst noch belegen muss.
- **Heatmap** — Cluster über die Zeit, mit Kurslinie und eingetretenen
  Liquidationen. Die Farbe richtet sich nach dem *Rang* einer Zelle unter
  allen anderen, nicht nach ihrem Absolutwert, und wird zusätzlich mit einer
  Potenz gestaucht — sonst leuchtet die ganze Fläche gleichmäßig. Der Regler
  „Liquiditäts-Schwelle" blendet alles unterhalb eines Perzentils aus
  (Standard 70). Für die PNG-Variante: `--threshold 0.9`.
- **Depth** — Schnitt durch den aktuellen Moment, alle Level nach Notional.
- **Kennzahlenleiste** — neben Kurs, Cluster-Summen und Adressen auch der
  60-Minuten-Trend, der RSI 14 auf dem gewählten Raster, das letzte Backup
  (grün unter 26 h, gelb bis 50 h, danach rot) und der Zustand der Datenbank
  per `quick_check`, stündlich geprüft. Beim Darüberfahren stehen Details.
- **Wale** — Netto-Ausrichtung aller Positionen ab 20 Mio. USD gegen den
  Kurs, darunter jede offene Wal-Position mit Einstieg, Liquidationspreis,
  Abstand dorthin und unrealisiertem PnL, und die letzten Änderungen.

## Tick-Aufzeichnung bei Kaskaden

Minutenkerzen reichen für die Cluster-Frage, nicht aber, um einen Flash-Crash
Tick für Tick nachzuspielen. Der Recorder hält deshalb die letzten 30 Minuten
aller Rohtrades der verfolgten Coins im Speicher. Erkennt er eine schnelle
Bewegung — 1 % in 60 s, 0,4 % in 10 s oder fünf Liquidations-Fills in 30 s —
sichert er das Fenster von 5 Minuten davor bis 10 Minuten danach in `ticks`,
parallel dazu die Markpreise in `mark_ticks`. Hält die Bewegung an, verlängert
sich der Nachlauf; bei ruhigem Handel endet er. Ein Ereignis je Bewegung, kein
Doppelauslösen. Schwellen über `--tick-move`, `--tick-flash`, `--tick-liqs`,
Fenster über `--tick-pre`, `--tick-post`.

Was zusätzlich mitläuft, damit sich der Zeitraum *vor* einem Crash erkennen
und das *Ende* treffen lässt:

- **Orderbuch-Kennzahlen alle 5 s** (`book_summary`): Tiefe in USD innerhalb
  10, 25, 50 und 100 Basispunkten je Seite, Spread, Imbalance. Ausdünnende
  Bid-Tiefe und kippende Imbalance sind die verlässlichsten Vorläufer.
  In Ereignisfenstern zusätzlich vollständige Top-10-Snapshots (`book_ticks`),
  damit sich der Füllpreis eines eigenen Verkaufs oder Kaufs realistisch
  simulieren lässt.
- **10-Sekunden-Bars mit Aggressorseite** (`bars10`): Taker-Käufe gegen
  Taker-Verkäufe, Liquidationsfills und -notional, größter Einzeltrade.
  Aussetzende Liquidationsfills und ein Volumenhöhepunkt markieren das Ende.
- **Nähe zum Cluster je Minute** (`proximity`): größtes Cluster über und unter
  dem Kurs innerhalb 5 %, mit Abstand — die Größe für die Magnet-These in
  hoher Auflösung.
- **Kontrollfenster**: ein- bis zweimal täglich ein zufälliges Fenster ohne
  Auslöser. Ohne diese Fälle kennt eine Simulation nur die Treffer, nie die
  Fehlalarme.

Für Simulationen: `--export --with-ticks` gibt Rohtrades, Buch-Snapshots und
die drei Zeitreihen mit. Ohne den Schalter enthält der Export nur die
Ereignisliste.

**Hinweis zu PAXG.** Gold-gebunden, daher schwankungsarm und auf Hyperliquid
dünn gehandelt. Zwei Folgen: Die Tick-Auslöser (1 %/60 s, 0,4 %/10 s) greifen
dort selten, und wenn, dann eher durch Einzeltrades in einem leeren Buch als
durch Kaskaden. Und die Liquidationscluster fallen klein aus. Für die
Cluster-These ist PAXG damit ein Randfall — interessant eher als Vergleich
zu BTC bei Makro-Ereignissen als als eigenständiges Handelsziel. Auf Binance
wird PAXG nur aufgezeichnet, wenn dort ein USDT-Perp existiert; sonst
überspringt das Modul den Coin mit Meldung.

## Verbindungen zum Router

Der Recorder hält höchstens sechs gleichzeitige HTTP-Verbindungen und
verwendet sie wieder (Keep-Alive 120 s). Ohne diese Begrenzung öffnete jede
Abfragerunde bis zu 80 neue TCP+TLS-Verbindungen — rund 20.000 pro Stunde.
Das heizt die CPU (TLS-Handshakes) und füllt die NAT-Tabelle eines
Heimrouters; ist sie voll, bekommt jedes Gerät im Haus für neue Verbindungen
ein Timeout, minutenlang auch nach dem Stoppen des Recorders. Prüfen auf dem
Pi mit `ss -s`: die Zahl bei `timewait` sollte zweistellig bleiben. Ist der
Router einmal voll, hilft sein Neustart sofort.

## Liquidationen — woher sie kommen

Der öffentliche Trade-Feed von Hyperliquid kennzeichnet Liquidationen nicht
(`WsTrade` hat nur coin, side, px, sz, hash, time, tid, users). Bis zum 8.9.
blieb die Tabelle `liquidations` deshalb leer — die Marker in der Heatmap,
`n_liqs` der Tick-Ereignisse und der Liquidations-Auslöser hingen an einem
Feld, das nie kommt. Seitdem zwei eigene Quellen:

- **`userEvents`-Abos** für Wale und Konten ab 250k (bis 600, `--max-event-subs`):
  Fills mit `liquidation`-Objekt in Echtzeit, kostet kein REST-Gewicht. Diese
  Liquidationen speisen auch die 10-s-Bars und den Liquidations-Auslöser.
- **Ableitung aus dem Polling** für alle anderen Konten: Position zwischen zwei
  Abfragen verschwunden oder auf unter 10 % geschrumpft, und der Kurs hat in
  der Zwischenzeit den Liquidationspreis berührt (Minutenkerze) → Liquidation,
  `method = inferred`, Zeitpunkt = berührende Kerze. Verzögert um das
  Abfrageintervall, dafür vollständig.

Der Audit weist beide Anteile aus.

## Datenqualität — was der Recorder dafür tut

- **Abdeckung wird gemessen.** Zu jedem Snapshot steht in `coverage`, welchen
  Anteil des offiziellen Open Interest die verfolgten Positionen ausmachen. Das
  verwandelt eine unbekannte Unvollständigkeit in eine Zahl — und sagt, ab wann
  die Heatmap repräsentativ ist. Der Wächter warnt unter 25 %.
- **Markpreis statt Handelspreis.** Liquidationen lösen am Markpreis aus. Aus
  `activeAssetCtx` werden Mark-, Oracle- und Mid-Preis, Funding und Open
  Interest je Minute in `ctx_bars` festgehalten, damit die Berührungserkennung
  denselben Preis nutzt wie die Börse.
- **Cross oder isoliert.** Der Liquidationspreis einer Cross-Margin-Position
  hängt am ganzen Konto und wandert, ohne dass sich die Position ändert. Die
  Heatmap speichert je Zelle den Cross-Anteil, damit sich stabile von
  wandernden Clustern trennen lassen.
- **Priorität nach Größe.** Vier Stufen nach Positionswert zum Markpreis:
  Wale ab 20 Mio. USD alle 60 s, große ab 250k alle 3 min, mittlere ab 25k
  alle 30 min, darunter nur noch alle 2 h. Das Budget fließt nach oben
  (`--whale-notional`, `--hot-notional`, `--min-notional`).
- **Wal-Protokoll.** Positionen über der Wal-Schwelle landen in
  `whale_positions` — nur Änderungen (öffnet, stockt auf, reduziert, schließt,
  dreht) plus ein Zeitreihenpunkt je Snapshot. Änderungen unter 2 % gelten als
  Rauschen. Hysterese: Wer einmal Wal war, bleibt bis unter die halbe Schwelle
  in Beobachtung.
- **Breite Adress-Entdeckung.** Standardmäßig werden alle Perp-Feeds
  abonniert, nicht nur die verfolgten Coins. Wer BTC hält, handelt vielleicht
  gerade nur SOL — sonst bliebe seine BTC-Position unsichtbar. Bars entstehen
  weiterhin nur für die verfolgten Coins. Abschaltbar mit `--no-discover-all`.
- **Alterung.** Positionsdaten, die älter als `--max-pos-age` sind (Standard
  1 h), gehen nicht in den Snapshot. Ein Wallet kann längst geschlossen haben,
  ohne dass wir es wissen. Lieber ein dünnerer, ehrlicher Snapshot.
- **Qualitätsstempel.** Jeder Snapshot trägt in `snapshot_meta` mit, wie alt
  die Daten waren, wie viele Positionen wegen Alter fehlten, wie groß der
  Rückstand war und wie lange der Prozess schon lief. Damit lassen sich
  Snapshots nach einem Neustart oder aus der Anlaufphase später ausschließen.
- **Abfragereihenfolge in drei Gruppen mit festem Budgetanteil.** Adressen
  mit Position (65 %): fällige Wale immer zuerst, dann nach Überfälligkeit
  relativ zum Intervall ihrer Stufe. Nie abgefragte Adressen (25 %): älteste
  zuerst — ohne festen Anteil würden sie mit „unendlicher" Überfälligkeit
  alles verdrängen. Bekannt leere Adressen (10 %): nur, wenn sie seit der
  letzten Abfrage wieder gehandelt haben, sonst höchstens einmal täglich.
  Eine leere Adresse ohne neuen Trade kann keine neue Position haben — wir
  sehen ja alle Feeds. Das macht die breite Entdeckung erst tragbar: Zehn-
  tausende Staubadressen kosten danach praktisch nichts mehr.
- **Hebel und Einstieg je Zelle.** Die Heatmap speichert den
  notional-gewichteten Hebel und Einstiegskurs. Ein Cluster aus 50x-Positionen
  verhält sich anders als einer aus 3x-Positionen.
- **Kein Doppelzählen.** `--analyze` ersetzt die Ereignisse eines Coins statt
  sie anzuhängen.

## Wie die Aufzeichnung funktioniert

1. Der WebSocket-Feed `trades` liefert zu jedem Trade die Wallet-Adressen.
   Daraus wächst ein Adressregister.
2. `clearinghouseState` liefert pro Adresse die offenen Positionen mit dem
   echten `liquidationPx` — anders als CEX-Heatmaps ist das keine Schätzung.
3. Alle Liquidationspreise werden in ein logarithmisches Preisraster
   aggregiert und alle fünf Minuten als Snapshot gespeichert.
4. Parallel laufen 1-Minuten-Bars aus dem Trade-Feed mit, damit sich später
   Forward-Returns berechnen lassen.

## Pi-spezifische Hinweise

**Backup.** Der Recorder erstellt fünf Minuten nach dem Start und danach
täglich eine Kopie nach `dbbackup/hl_liq_backup.db`, im laufenden Betrieb
über die SQLite-Backup-API — in einem einzigen Schritt. Schrittweise mit
Pausen wäre eine Endlosschleife: Ändert eine andere Verbindung die Quelle
zwischen zwei Schritten, beginnt die API von vorn, und der Recorder schreibt
alle 10 s. Dauer = Datenbankgröße geteilt durch die Schreibgeschwindigkeit
des Zielmediums, bei 1,5 GB auf SD-Karte ein bis drei Minuten, danach die
Integritätsprüfung. Die Kopie wird erst mit `integrity_check`
geprüft und ersetzt das alte Backup nur, wenn sie in Ordnung ist — eine
bereits beschädigte Datenbank kann das letzte gute Backup also nicht
überschreiben. Manuell: `hl_recorder.py --backup`. Der Zielordner lässt
sich mit `--backup-dir` festlegen; der Recorder trägt ihn beim Start in die
Tabelle `meta` ein, und Dashboard, Wächter und Audit lesen ihn dort — eine
Quelle für alle. Liegt die Datenbank auf einem USB-Medium, gehört das Backup
auf die SD-Karte des Pi (`migrate_db.py` richtet das so ein): Ein Backup auf
demselben Datenträger schützt vor Beschädigung, nicht vor dessen Ausfall.
Der Recorder meldet beim Start, ob beides auf demselben Datenträger liegt. Wiederherstellen: Dienste stoppen, Datei kopieren, starten.

**Arbeitsspeicher.** 4 GB reichen deutlich. Gemessen auf einer Datenbank mit
90 Tagen Aufzeichnung (2,8 Mio. Heatmap-Zeilen, 223 MB):

| Prozess | Spitzenspeicher |
|---|---|
| Recorder mit 20.000 Adressen / 40.000 Positionen | 44 MB |
| Dashboard, auch bei 7-Tage-Ansicht | 108 MB |
| Binance-Stream | rund 40 MB |
| `--analyze` über 90 Tage | 173 MB, 6 s |

Zusammen unter 400 MB. Ein kleineres Snapshot-Intervall erhöht den Bedarf
leicht, weil mehr Zeilen entstehen — es senkt ihn nicht.

**Datensicherheit bei Neustart und Stromausfall.** Die Datenbank läuft im
WAL-Modus. Bars, Liquidationen und Adressen werden alle 10 Sekunden committet
(`--flush-sec`), die WAL-Datei alle 15 Minuten zusammengefaltet, damit sie
nicht unbegrenzt wächst.

| Fall | Verlust |
|---|---|
| Geplanter Neustart (systemd sendet SIGTERM) | nichts |
| Absturz eines Dienstes | nichts, der Supervisor startet neu |
| Harter Stromausfall | bis zu 10 Sekunden |
| Stromausfall mit `--durable` | nichts, dafür mehr Schreibzugriffe |

Getestet mit SIGKILL mitten im Schreibbetrieb: Die Datenbank bestand danach
in allen Läufen `PRAGMA integrity_check`, und die vor dem letzten Commit
geschriebenen Daten waren vollständig vorhanden.

`--durable` schaltet auf `synchronous=FULL`, also fsync bei jedem Commit. Auf
einer USB-SSD unproblematisch, auf einer SD-Karte erhöht es den Verschleiß
spürbar.

**SD-Karte.** Der Recorder schreibt dauerhaft. Bei drei Coins wächst die
Datenbank bei 10-Minuten-Snapshots um etwa 0,2 GB pro Monat. Auf einem
124-GB-Datenträger reicht das für Jahre. Für Monatsbetrieb eine USB-SSD verwenden
und `--db /pfad/zur/ssd/hl_liq.db` setzen.

**Uhrzeit.** Ohne NTP-Synchronisation sind die Zeitstempel wertlos.
`sudo timedatectl set-ntp true`, das Installskript prüft es.

**Dashboard im Netz.** `--host 0.0.0.0` macht es im LAN erreichbar, ohne
Passwort. Nur im eigenen Heimnetz betreiben, nicht ins Internet stellen.

**Dauerbetrieb.** `install.py --enable` richtet drei systemd-Dienste mit
`Restart=always` ein, damit Recorder, Binance-Stream und Dashboard Neustarts
und getrennte SSH-Sitzungen überleben.

## Alarm bei Ausfällen

```bash
.venv/bin/python hl_watchdog.py --once                # einmalig prüfen
.venv/bin/python hl_watchdog.py --test-alarm          # Signalgeber testen
```

Zwei Ebenen, weil eine allein nicht genügt:

**Lokal** — Alarmton über die Audioausgabe, alle 120 Sekunden wiederholt,
solange die Störung anhält (`--alarm-interval`). Bei Warnung ein aufsteigender
Zweiklang, bei kritischem Zustand eine Sirene, beides aus Rechteckschwingungen
im Stil der 8-Bit-Ära und zur Laufzeit erzeugt. Funktioniert ohne Internet,
also gerade dann, wenn der Ausfall die Verbindung betrifft.

> Der Raspberry Pi 5 hat **keinen eingebauten Lautsprecher** und seit dem
> Modell 5 auch keine 3,5-mm-Klinkenbuchse mehr. Ton braucht HDMI mit
> angeschlossenem Bildschirm, einen USB-Soundstick, Bluetooth oder ein
> I2S-DAC-HAT. `hl_watchdog.py --test-alarm` sagt dir, was gefunden wurde.
> Ohne Audioausgabe bleiben die ACT-LED (`--led`) und der Totmannschalter.

Nötig ist ein Abspielprogramm: `sudo apt install alsa-utils`. Optional lässt
sich zusätzlich ein Summer an einem GPIO-Pin betreiben (`--buzzer 18`), auf
dem Pi 5 über `gpiozero` mit `lgpio`.

**Extern** — ein Lebenszeichen an einen Dienst wie healthchecks.io
(`--heartbeat https://hc-ping.com/UUID`). Der Wert liegt im Ausbleiben: Ist
der Pi tot oder offline, alarmiert der Dienst dich. Das ist die einzige Ebene,
die einen Totalausfall überhaupt melden kann. Zusätzlich Push über
`--ntfy DEIN-TOPIC`, solange die Verbindung steht.

Geprüft werden Alter der Bars und Snapshots, stille Einzel-Feeds, Rückstand
des Pollers, Binance-Daten, Plattenplatz, NTP-Synchronisation und der Zustand
der systemd-Dienste. Die Verbindungsprüfung verlangt den erwarteten Inhalt,
nicht nur einen Statuscode — ein Captive Portal oder eine Router-Fehlerseite
antwortet sonst mit HTTP 200 und sähe wie eine intakte Verbindung aus.

## Wie Cluster und Kurs zusammenfinden

Alle Zeitstempel sind Unix-Sekunden, also zeitzonenfrei — die Systemzeitzone
des Pi spielt keine Rolle. Zu jedem Heatmap-Snapshot sucht die Auswertung per
Binärsuche die passende Minutenkerze und leitet daraus Abstand zum Cluster,
Stundenvolumen und Forward-Returns ab.

Eine Bar entsteht aber nur, wenn in der Minute gehandelt wurde. In dünnen
Märkten und Nachtstunden kann die nächste Kerze Minuten entfernt liegen —
ihr Preis gehört dann nicht mehr zum Snapshot. Liegt der Abstand über
`--max-gap` (Standard 120 s), wird das Ereignis verworfen und am Ende
gemeldet, statt still mit falschem Bezug zu rechnen.

Voraussetzung dafür ist eine korrekt gehende Uhr: Die Bars tragen Börsenzeit,
die Snapshots die Zeit des Pi. Driftet sie, passt die Zuordnung nicht mehr.
Deshalb prüft der Wächter die NTP-Synchronisation.

## Zwei Datenquellen, getrennt gehalten

Hyperliquid liefert **gemessene** Positionen mit echtem Liquidationspreis,
Binance liefert **aggregierte** Marktdaten und Liquidationsereignisse. Beides
landet in derselben Datei, aber in getrennten Tabellen (`heatmap` gegen
`bnc_*`). Nicht vermischen — die Aussagekraft ist unterschiedlich.

Rückwirkend abrufbar sind bei Binance nur Open Interest, Long/Short-Ratios und
Kerzen. Liquidationen gibt es dort nicht als Verlauf, die sammelt nur der
Live-Stream. Und Binance pusht je Symbol nur die größte Order pro Sekunde: Das
gespeicherte Kaskadenvolumen ist eine Untergrenze, kein exakter Wert.

## Bilanz der Kauf- und Verkaufsempfehlungen (seit 23.16)

Die Kachel „Bilanz der Empfehlungen“ zeigt, was die Empfehlungen gebracht hätten, nach Gebühren und gegen die
naheliegenden Alternativen:
- **Kauf:** Limit gegen sofort kaufen (Markt) und nie kaufen.
- **Verkauf, für eine offene Long-Position:** Limit gegen sofort verkaufen und halten.

So wird gerechnet:
- Je Coin und Tag zählt die erste Empfehlung.
- Das Limit liegt ab der Prognose 12 h.
- Bewertet wird alles 24 h nach der Prognose.

Grün heißt, das Limit schlägt die Markt-Variante mit 95 % Sicherheit, rot heißt, es ist sicher schlechter. Details je
Coin, auch getrennt nach „ausdrücklich empfohlen“ ja/nein, zeigt der Debug-Eintrag „★ Bilanz der
Kauf-/Verkaufsempfehlungen (U8)“. Die Gebühren entsprechen der Hyperliquid-Basisstufe (Maker 0,015 %, Taker 0,045 %);
Funding ist nicht enthalten. Aussagekräftig wird die Bilanz erst nach einigen Wochen.

## Ereignis-Profile: was geschah vor Rutschen und Anstiegen (seit 23.18)

Der Debug-Eintrag „★ Ereignis-Profile (U43)“ zeigt für jeden Treiber, wie er in den 12 Stunden vor großen Bewegungen
stand. Als groß gilt eine Bewegung in 4 Stunden von mindestens dem Doppelten der üblichen Schwankung. Jeder Wert wird
mit normalen Zeiten gleicher Schwankung verglichen.

Ein Stern markiert eine Abweichung, die über einer Schwelle aus zufällig verschobenen Zeitpunkten liegt; sie ist also
kein Zufallsfund. So lassen sich Vorläufer (weichen schon Stunden vorher ab) von Mitläufern (reagieren erst mit der
Bewegung) unterscheiden. Solange es wenige Fälle gibt, ist die Schwelle hoch und markiert wenig; das heißt zunächst
nur: noch nicht belegbar.

## Verlauf der Treiber (seit 23.19)

Unter dem Prognose-Chart zeigt eine Tafel, wie sich die Treiber über die letzten 24 oder 72 Stunden entwickelt haben:
- oben der Kurs,
- unten der Bias (weiße, dicke Linie) und einzelne Treiber auf der Skala −1 bis +1.

Treiber lassen sich durch Antippen an- oder abwählen. Rote und grüne Bänder markieren Rutsche und Anstiege nach der
Definition der Ereignis-Profile; sie erscheinen erst 4 Stunden nach ihrem Beginn. So sieht man, ob Treiber vor einer
Bewegung schon gekippt waren. Die Tafel ist rein beschreibend und keine Vorhersage.

## Berichtsplan: Diagnosen laufen von selbst (seit 23.20)

Das Dashboard führt die Debug-Einträge, die Claude zu bestimmten Zeitpunkten braucht, selbst aus, zum Beispiel jeden
Mittwoch um 19:00 die Wochenprüfung. Es speichert die Ausgaben auf dem Pi im Projektordner unter `berichte/`.

Im Debug-Bereich stehen:
- der Plan mit Stand (offen, erledigt, verpasst),
- die gespeicherten Berichte,
- der Knopf **„Neue Berichte (n)“**: eine Sammeldatei nur mit Berichten, die du noch nicht abgeholt hast. Abgeholte
  Berichte erscheinen danach gedimmt; „Letzten Abruf nochmal“ liefert dieselbe Datei erneut, falls ein Download
  schiefging. Diese eine Datei lädst du in den Chat hoch.
- zwei Links für alle Berichte der letzten 24 Stunden bzw. 7 Tage.

War der Dienst zur geplanten Zeit aus, wird der Termin bis zu 12 Stunden später nachgeholt. Abschalten lässt sich der
Plan mit der Umgebungsvariable `HL_BERICHTE=0`.

## Aktive Profis als Darwin-Liste (seit 23.22, Regeln v2 seit 23.37, v3 seit 23.38)

Die Liste der Aktiven Profis ändert sich einmal täglich, bei der ersten Bewertung nach 02:00 Uhr (00 UTC). Seit 23.37
gilt: **streng hinein, großzügig bleiben.**
- **Aufnahme (alles Pflicht):** 2–150 gebündelte Trades am Tag in den verfolgten Coins, Gewinn über 7 und über 30 Tage
  positiv, mindestens 6 bewertbare Ein- und Ausstiege in 14 Tagen, Glückswahrscheinlichkeit höchstens 1 % und
  mindestens 10 Punkte Vorsprung vor dem Zufall.
- **Verbleib:** mindestens 1 Trade am Tag, Gewinn über 30 Tage positiv, mindestens 4 Ein- und Ausstiege, Timing weiter
  über dem Zufall (Glück höchstens 50 %).
- **Abstieg:** erst nach 3 Tagesentscheidungen in Folge ohne Verbleib. Dazwischen zeigt die Karte „Fehltag 1 von 3“
  mit dem Grund.
- **Seit 23.38 (Regeln v3):** Diese Schonung gilt nur für Konten, die über die strenge Aufnahme kamen. Jeder Weg auf die
  Liste verlangt sie, auch die Rückkehr eines zu Unrecht Gesperrten. Beim Umstieg auf v3 blieb nur, wer die Aufnahme unter
  v2 bestanden hatte oder sie jetzt erfüllte; Altmitglieder aus v1 und die Rückkehr über die Verbleib-Regel beim Umstieg
  auf v2 gingen sonst sofort, mit Grund in „Zu- und Abgänge“. `check_profis` zeigt je Mitglied „streng seit …“.
- Sortiert wird nach dem vorsichtig geschätzten Timing-Beleg, nicht nach der Rendite. Viele gut getimte Ausstiege
  schlagen wenige glückliche.

Warum zwei Regeln: Bis 23.36 galt eine Regel für beides (7 Tage, Glück höchstens 5 %, Abstieg nach 2 Tagen). Mit etwa
10 Entscheidungen in 7 Tagen kippte ein gutes Konto schon, wenn ein einziger Treffer aus dem Fenster fiel (7 von 10 bei
32 % Zufall: 1,6 %; 6 von 10: 6,4 %). Gleichzeitig kam bei rund 200 geprüften Konten fast täglich eines nur durch Glück
hinein. In der Simulation (200 Konten ohne, 10 mit 20 Punkten Vorsprung) standen die Könner nur 30 % der Zeit auf der
Liste, mit den neuen Regeln 68 %. Zufallsaufnahmen fielen von 8,8 auf 0,9 je Woche, Könner, die hinausfliegen, von 3,4
auf 0,5 je Woche.

Jede Karte zeigt, ob das Konto die Verbleib-Regel gerade erfüllt („Verbleib erfüllt“ oder den Grund). Unter den Karten
stehen die **Zu- und Abgänge der letzten 7 Tage mit Grund** und Mitglieder, die gerade nicht bewertet werden (gesperrt,
nicht mehr im Pool). Die Pool-Tabelle zeigt für Mitglieder den Verbleib, für alle anderen den ersten Grund gegen die
Aufnahme. Debug „★ Aktive Profis“ druckt dasselbe als Text.

Jede Karte zeigt die Timing-Bilanz:
- Einstiege und Ausstiege, jeweils Long und Short, mit Trefferzahl und Zufallsquote.
- „Zuerst richtig“: wie oft der Kurs erst 2 % in die richtige Richtung lief, bevor er 2 % in die falsche lief.
- Den Vorsprung gegenüber dem Zufall nach 1, 4 und 12 Stunden.

Darunter stehen bis zu 30 Trades je Konto und eine gemeinsame Zeitleiste aller Profis.

**Woher die Ein- und Ausstiege kommen (seit 23.34):** aus drei Quellen — Wal-Positionen, Leaderboard-Ereignisse und
`pool_positions`, die Positionsänderungen ALLER Pool-Konten (10-min-Raster, Positionen ab 50k, Änderungen ab 10k). Bis
23.33 fehlte die dritte Quelle in der Bewertung. Konten unter der Wal-Schwelle und außerhalb des Leaderboard-Trackings hatten
deshalb keine bewertbaren Ein- und Ausstiege, obwohl sie handelten — die Liste trocknete aus („qualifiziert 0“). Dieselbe
Entscheidung aus mehreren Quellen binnen 15 min zählt einmal. `check_profis.py` zeigt die Zahl je Quelle und ordnet die
Ausschlussgründe richtig zu: Aktivität, Gewinn 7 T, zu wenige Ein-/Ausstiege, Timing nicht belegt, Einstiege widerlegt.

**Fills der Liste ohne Mindestbetrag (seit 23.34):** Der Recorder sammelt die Fills der Darwin-Konten auch unter
2.500 USD, im Stream, per userEvents und im REST-Abgleich. Gedeckelt sind es höchstens 200 kleine Fills je Konto, Stunde
und Quelle. Für alle anderen Konten bleibt die Grenze. `pool_fills_hourly` zählt weiter nur Fills ab 2.500 USD, damit die
Aktivität der Listen-Konten mit dem übrigen Pool vergleichbar bleibt. **Seit 23.37 gilt das auch für die Masterregel:** Sie zählt
gespeicherte Fills nur ab 2.500 USD. Von 23.34 bis 23.36 zählten die kleinen Fills mit. Darwin-Konten wurden so strenger
gemessen als alle anderen, und gerade die besten (Echtzeit-Plätze, jeder Fill kommt an) rutschten über 300 gebündelte
Trades, wurden vorläufig gesperrt und fielen von der Liste. Die Sperren seit dem 29.09. werden einmalig mit der richtigen
Zählung geprüft. Wer zu Unrecht gesperrt war, wird freigegeben und sofort mit der Verbleib-Regel geprüft; erfüllt er
sie, steht er wieder auf der Liste („zurück: zu Unrecht gesperrt“; seit 23.38 nur mit erfüllter Aufnahme). Seit 23.38 gibt die
Neubewertung nur frei, wenn die gespeicherten Fills mit den kleinen die Sperre nachvollziehen und ohne sie höchstens 300
ergeben; eine Freigabe ohne ein einziges mitgezähltes kleines Bündel (0xb078…de15 am 30.09.) wurde einmalig zurückgenommen
(Debug „Masterregel Sperre“). Die Richtung eines Stream-Fills stimmt jetzt auch
bei Konten ohne jede Position: Wer in den letzten 20 min abgefragt wurde und keine Position hat, ist flach, also
eröffnet er. Nach der eigenen frischen Eröffnung gilt deren Seite bis zum nächsten Positionsstand.

## Speicherorte: Backup auf ein anderes Laufwerk (seit 23.23)

Im Bereich „System“ zeigt der Block „Speicherorte“, wo die Datenbank liegt und wohin gesichert wird.

So verlegst du das Backup:
1. „Backup-Pfad ändern“ antippen.
2. Auf dem Pi einen Ordner auswählen, zum Beispiel auf einem USB-Laufwerk unter `/media/…`.
3. „Übernehmen“ antippen. Vorher wird geprüft, ob der Ordner beschreibbar ist, auf einem anderen Gerät als die
   Datenbank liegt und Platz für zwei Generationen hat.

Das nächste Backup geht an den neuen Ort. Mit „Jetzt sichern“ geht es sofort los. Erst wenn dort ein Backup gelungen
ist, bietet der Block an, die alten Backups, zum Beispiel auf der SD-Karte, zu löschen.

Den Datenbankpfad selbst verlegst du vorerst im Terminal mit `python3 migrate_db.py`.

## Konfluenz im Chart und ihre Bilanz (seit 23.24)

Die Konfluenz zählt Kauf- und Verkaufspunkte aus Chart-Faktoren und zeichnet eine Zone ein. Droht ein Anlauf, etwa
durch Sell-Stops oder ein großes Long-Cluster dicht unter dem Kurs, zeigt sie keine Kaufzone darüber. Sie verweist
dann auf das Kaskadenziel („erst nach Abholung“).

Unter dem Konfluenz-Kasten steht ihre Bilanz: wie oft Richtung und Zonen richtig lagen, gegen den Zufall. Aufgezeichnet
wird nur, solange eine Dashboard-Seite offen ist, weil der Browser die Konfluenz berechnet.

## Treiberfamilien im Parallelbetrieb (seit 23.25)

Der Abschnitt „Treiberfamilien“ fasst ähnliche Treiber zu Familien zusammen, etwa alle Flüsse großer Konten zu einer.
Er prüft jede Familie auf ihrem eigenen Zeithorizont gegen den Zufall, je Coin getrennt. Er läuft neben der bisherigen
Prognose und verändert sie nicht.

**Gewicht:** Eine Familie bekommt erst Gewicht, wenn sie zwei Wochen in Folge einen belegten Vorsprung zeigt.
Stufen: Kandidat, dann Bewährung, dann aufgestiegen. Bis dahin nennt die Familien-Prognose ehrlich die Basisrate.

**Besondere Familien**
- „Stärke“ sagt voraus, ob eine große Bewegung kommt, nicht wohin.
- „Profi-Flow“ ist der Netto-Handel der Darwin-Liste. Er wird ab jetzt aufgezeichnet.
- „Kaskaden“ (seit 23.43) enthält nur den Schatten-Treiber „Kaskaden-Asymmetrie“ der Kaskaden-Gleichung. Sie prüft, ob
  die Asymmetrie der berechneten Kaskadenreichweite die Richtung der nächsten 4 h vorhersagt. Sie geht nicht in v3 ein.

**Treiber-Hygiene:** Die aufklappbare Liste zeigt Treiber, die nur nachlaufen, in die Gegenrichtung zeigen oder keine
Werte liefern.

## Heatmap-Anker (seit 23.28)

Oben in der AI-Prognose steht der Kasten „Heatmap-Anker“. Er zeigt, auf welcher Seite des Kurses die stärkeren
Liquidationscluster liegen, gemessen am Stundenvolumen des Coins und im Abstand in Schwankungseinheiten. Dazu kommt
der Stand der täglichen Bilanz: Hat diese Seite den Kurs bisher tatsächlich angezogen, und zwar trendbereinigt?

Steht ein sehr starkes Cluster gegen die Richtung der Prognose, färbt sich der Kasten orange. Auf die Prognose selbst
wirkt der Anker erst, wenn er belegt ist.

## TradeLabor: simulierter Handel mit allen Daten (seit 23.33)

Der Abschnitt „TradeLabor“ zeigt live, was gut 30 Handelsregeln mit den Daten des Systems anfangen würden. Gehandelt
wird nur auf dem Papier: keine Order an eine Börse, kein API-Gewicht, keine Wirkung auf Prognose oder Treiber.

**Aufbau**
- Jede Strategie handelt je Coin (BTC, ETH, ZEC, HYPE, seit 23.34 auch XMR) ein eigenes Konto mit 10.000 USD je Trade.
  Jedes Konto zählt ab seinem eigenen Start (XMR ab dem Update); die Tagesrendite teilt durch diese Kontotage.
- Die Regeln werden beim ersten Start eingefroren. Eine Änderung ergibt eine neue Kennung mit eigener Bilanz, die alte
  bleibt stehen. Jedes Ergebnis ist damit ein echter Vorwärtstest.
- Gruppen: Händler (Wale, Leaderboard, Smart Money, Pool, Darwin-Liste, Elite, jeweils folgen und dagegen), Prognose (v1,
  v2, Fusion und Fusion mit Kostenschwelle seit 23.42, Kauf-/Verkaufspreise), Treiberfamilien, Ereignisse (Kaskade, Docht,
  Magnet, Kaskaden-Kipppunkt seit 23.43, Funding-Extrem, Ausbruch nach Ruhe, TWAP-Druck), Grid (Grid Long, Grid Short, seit 23.40), Kontrolle (Zufall,
  Halten Long).

**Ausführung, bewusst vorsichtig gerechnet**
- Markt-Order: Buchmitte plus halber Spread plus Marktauswirkung aus der Buchtiefe (Orderbuch alle 5 s).
- Limit-Order: gefüllt nur, wenn der Kurs durch den Preis läuft.
- Gebühren Taker 0,045 %, Maker 0,015 %. Funding stündlich. XMR ist auf Hyperliquid ein HIP-3-Markt: Zur
  Protokollgebühr kommt der Anteil des Betreibers (0–300 %). Angenommen sind 100 %, also doppelte Sätze. Die
  Gebühren-Prüfung im Bericht vergleicht das mit echten Fills.
- Liegen Stop und Ziel in derselben Minute, gilt der Stop.

**Auswertung**
- „Glück“: Wahrscheinlichkeit, dass die beste aller Strategien rein zufällig so gut aussähe (Student-t, mal Zahl der
  Strategien). Erst unter 5 % ernst nehmen.
- Blöcke (seit 23.34): t, Glück, Hälften und Stufen zählen Blöcke, nicht einzelne Trades. Trades einer Strategie, die im
  selben Block ihres Horizonts eröffnet wurden, sind eine Beobachtung. Das ist meist dasselbe Signal in mehreren
  korrelierten Coins. Vorher zählte jeder Coin-Trade einzeln, und vier gleichzeitige Trades vervierfachten scheinbar den
  Beleg. Die Tabelle zeigt „Trades (Blöcke)“.
- Stufen: Kandidat → Bewährung (15 Blöcke, t ≥ 2, Summe > 0) → bewährt (30 Blöcke, t ≥ 3, beide Hälften positiv,
  14 Tage). Negativ: 30 Blöcke, t ≤ −2.
- Hebel-Wahl 1×, 3×, 5×, 10×: alle Ergebnisse hochgerechnet. Erreicht der Rückgang im Trade 90 % der Marge, zählt der
  Trade als liquidiert (−100 % der Marge).

**Reiter:** Live (Signaltafel je Strategie und Coin), Positionen, Strategien, Chart (Kurs mit Ein- und Ausstiegen,
Bilanzverlauf), Datenfluss (jeder Eingang mit Alter und Nutzern), Ereignisse, Trades.

**Darwin-Liste live folgen, Version 2 (seit 23.34, neue Kennung):** Eröffnungen eines Listen-Kontos werden je Coin und
Seite über 15 min netto aufsummiert, auch in kleinen Stücken; Schließungen dazwischen ziehen ab. Ab 10k (der jüngste Fill
höchstens 3 min alt) steigt die Strategie ein, je Eröffnung einmal. Der Folge-Ausstieg kommt, sobald das Konto mindestens
die Hälfte davon wieder geschlossen hat. Version 1 zählte nur, was in einem Takt zusammenkam — eine in Stücke unter 10k
zerlegte Eröffnung blieb unsichtbar. Die alte Bilanz bleibt als „alte Regelversion“ stehen. Seit 23.37 tragen „Darwin
folgen“ und „Darwin gegen“ noch einmal eine neue Kennung (`liste=2`): Die Liste entsteht nach den Regeln v2, die Bilanz
soll nicht zwei verschieden zusammengesetzte Listen vermischen. Seit 23.38 aus demselben Grund `liste=3` (Regeln v3).

**Elite live folgen (seit 23.39):** die zweite Kopier-Vorlage, nach genau derselben Regel wie die Darwin-Liste und ebenfalls
mit Gegenprobe („Gegen die Elite“). Kopiert wird die Elite des jeweiligen Coins, also die Konten, die das Dashboard täglich
nach Konto-Score mit belegtem 4-h-Vorlauf, Gewinn- und Aktivitätsschranke auswählt; von der Masterregel Gesperrte nie. Der
Recorder sammelt dafür die Fills der Elite im Stream (ab 2.500 USD, ohne API-Gewicht). So lassen sich beide Vorlagen direkt
vergleichen: Aktive Profis (belegtes Timing der Ein- und Ausstiege) gegen Elite (belegter Vorlauf der Positionsänderungen).
Die Elite ist dabei nur mit Fills ab 2.500 USD sichtbar, die Darwin-Liste auch mit kleineren. Der Bericht zeigt neben der
Darwin-Prüfung eine **Elite-Prüfung** (Elite je Coin, Fills, Eröffnungen ≥ 10k, Einstiege).

**Grid-Bots (seit 23.40):** „Grid Long“ und das Spiegelbild „Grid Short“ (Gruppe „Grid“), je Coin ein Konto über
10.000 USD, auf die Stufen verteilt.
- **Range:** aus den 1-min-Kursen der letzten 24 h, 10. bis 90. Perzentil; nach einem Ausstieg nur aus Kursen ab dann.
  Aufgebaut wird nur ohne Trend gegen das Grid (Netto-Bewegung höchstens 1-mal ihre eigene Schwankung dagegen, 2-mal mit
  ihm) und mit dem Kurs im mittleren Teil der Range. 4–12 Stufen mit mindestens 0,2 % Abstand.
- **Handel:** Jeder Abstand zwischen zwei Stufen hält ein Los oder eine Einstiegs-Order. Long kauft unten und verkauft eine
  Stufe höher (Maker), Short umgekehrt; danach liegt dort wieder ein Einstieg. Beim Aufbau kauft das Grid den klassischen
  Startbestand (die Stufen jenseits des Kurses) zum Marktpreis. Stündlich nachgeführt, wenn sich die Range deutlich
  verschoben hat; vorhandene Lose behalten ihr Ziel, das Kapital wird nie überschritten.
- **Starke Bewegung in Grid-Richtung** (Squeeze bzw. Kaskade, ≥ 3 σ in 5 oder 15 min in der Gewinnhälfte, Ausbruch aus der
  Range): keine Verkäufe mehr, alle Lose halten, Trailing-Stop 1,5 σ(1 h) vom Extrem — das Maximum ist erkannt, wenn der
  Kurs so weit zurückfällt. Danach 2 h Pause.
- **Notausstieg** (Kaskade gegen das Grid, ≥ 3 σ in 15 min in der ungünstigen Hälfte, Kurs eine Stufe jenseits der Range):
  alle Lose zum Marktpreis, Pause 4 h, nach dem zweiten binnen 24 h 12 h, nach dem dritten 24 h.
- **Bewertung nach Bestandswert:** Ein Grid zeigt laufend kleine realisierte Gewinne, während sich Verluste im Bestand
  sammeln können. Deshalb zählen Summe, Ø/Tag und Blöcke (= Tage) das Tagesergebnis aus realisiertem Gewinn und Änderung
  des unrealisierten Bestands. Positionen zeigt die Grids gebündelt, der Chart mit gewähltem Grid Range, Notlinie und
  Trailing-Stop, der Bericht einen Abschnitt „Grid-Bots“.
- **Praxis-Hinweis:** Hyperliquid kennt je Konto und Coin nur eine Netto-Position (kein Hedge-Modus). Long und Short in einem
  Konto würden sich verrechnen; das Labor rechnet jede Strategie als eigenes Konto, live entspräche das je Grid einem
  Sub-Account (eigene Positionen und Margin; bis 10 ab 100.000 USD Handelsvolumen). Beide Grids nutzen dieselbe Range, solange
  sie dasselbe 24-h-Fenster sehen; nach einem Ausstieg oder beim Nachführen können sie auseinanderlaufen.

**Betrieb:** Takt 15 s im Dashboard-Dienst, Stand im Prognosespeicher (Tabellen `labor_*`). Abschalten mit
`HL_LABOR=0` in der Unit. Bericht: Debug „★ TradeLabor“ (`hl_labor.py --bericht --db PFAD`), wöchentlich im Berichtsplan.
Seit 23.34 listet er alle offenen Positionen und enthält zwei Prüfungen: die **Darwin-Prüfung** (Listengröße, Fills der
Liste in 24 h mit Richtung, Eröffnungen ab 10k binnen 15 min nach der Live-Regel nachgerechnet, Einstiege der
Strategie) und die **Gebühren-Prüfung** (Gebührensatz echter Fills XMR gegen BTC/ETH).

## Adress-Strom (seit 23.33)

Jeder Trade im Hyperliquid-Feed trägt beide Adressen und die Seite des Nehmers. Der Recorder fasst das je Minute, Coin
und Adresse zusammen: Nehmer- und Geber-Käufe und -Verkäufe, Anzahl, TWAP-Anteil. Er schreibt es in eine eigene Datei
`adressfluss.db` neben der Datenbank.

- 0 API-Gewicht, denn der Feed läuft ohnehin. Keine Schreiblast auf `hl_liq.db`, nicht im Backup.
- Vorhalt 14 Tage (`--af-tage`, 0 = aus). Deckel 3 GB (`--af-max-gb`): darüber werden die ältesten Stunden gelöscht.
  Erwartet: grob 40–80 MB je Tag.
- Null-Hash: Trades ohne eigene Transaktion, nach allem, was bekannt ist, TWAP-Teilaufträge. Der Netzwerkstatus zeigt den
  Anteil, Debug „Adress-Strom“ die größten TWAP-Adressen.
- Nutzer: TradeLabor (TWAP-Druck, Datenfluss). Als Nächstes der informierte Fluss je Adresse (U75, sobald einige Tage
  Daten vorliegen) und die Trennung TWAP gegen ausgelöste Orders.

**Handläufe im Debug** (seit 23.33): Jeder von Hand gestartete Debug-Lauf landet zusätzlich als Datei in `berichte/`
(Name endet auf `_manuell`) und erscheint unter „Neue Berichte“.

## Fusionsprognose, Kalibrierung v3 und Kostenschwelle (seit 23.42)

Stufe 1 des Konzepts `KONZEPT_Fusion.md`: alle Quellen zu EINER Wahrscheinlichkeit verschmelzen und nur handeln, wenn der
Vorsprung die Kosten trägt. Alles läuft **im Schatten**: Die angezeigte P(aufwärts), Pfad, Bias und Kaufpreise bleiben v1
(bzw. v2, wenn deren Schalter gesetzt ist). Modul `hl_fusion.py`.

**Kostenschwelle je Coin und Horizont.** Ein Richtungsurteil mit Trefferquote p bringt im Mittel (2p − 1) · E|r|. Es lohnt
sich erst ab p* = ½ + Kosten / (2 · E|r|). E|r| ist die gemessene mittlere Bewegung des Coins in den letzten 30 Tagen, die
Kosten sind ein Hin- und Rückweg (Taker: Gebühr plus halber Spread; Maker: Gebühr; XMR doppelt). Bei BTC-typischer Schwankung
braucht ein 4-h-Handel als Taker rund 57 % Trefferquote, als Maker rund 52 %.

**Kalibrierung v3.** v2 über alle Coins geteilt, auf den sieben Richtungsfamilien statt auf einzelnen Treibern: Was in allen
Coins gleich wirkt, wird gemeinsam geschätzt; eine Abweichung je Coin gibt es nur gegen Beleg. Stündlich neu (erstmals 5 min
nach dem Start). Ohne Beleg nennt v3 je Coin die Basisrate.

**Fusionsprognose.** Eine Mischung der Experten Basisrate, v1, v2, v3 und Analog-Suche. Nach jedem aufgelösten 4-h- bzw.
24-h-Block bekommt mehr Gewicht, wer das Ergebnis besser vorhergesagt hat (Log-Verlust). Mathematisch garantiert: höchstens
um eine feste Konstante schlechter als der beste einzelne Experte. Jede Fusionszahl steht fest, bevor ihr Ergebnis bekannt
ist. Beim ersten Start werden die gespeicherten Prognosen der letzten 60 Tage nachgetragen, ebenfalls ohne Blick in die Zukunft.

**Wo man es sieht**
- AI-Prognose, Kachel „P(aufwärts) Fusion — Schatten“: Fusion 4 h und 24 h, Anteile der Experten, v3 allein, Kostenschwelle
  (Taker/Maker) und ob die Fusion für ihre Richtung darüber liegt.
- Selbstoptimierung, Kachel „Fusion und Kalibrierung v3“: v3-Modell (n, n_eff, Coins, λ, Teilen, c, OOF-Quote, Brier-Skill)
  und die Bilanz der Fusion je Horizont mit dem **Abstand zur Basisrate ± 1 Standardfehler** („nicht belegt“, „belegt besser“
  oder „belegt schlechter“).
- Debug „★ Fusion und v3“: Stand je Coin (Kostenschwelle für 1/4/12/24 h, Gewichte, Bilanz, nur live gestellte Blöcke) und
  am Ende alle Coins zusammen mit Zeitblöcken als Klumpen. Läuft wöchentlich im Berichtsplan (W11), dazu am 11.10. 19:30
  (erste Woche) und am 25.10. 19:30 (Auswertung U108).
- Debug „Fusion, v3 und Kostenschwelle: Selbsttest“ (`python3 hl_fusion.py --nulltest`, rund 30 s, auch Installationsschritt).
- TradeLabor, Gruppe Prognose: „Prognose Fusion“ (feste Schwelle wie v1) und „Fusion mit Kostenschwelle“ (handelt nur, wenn
  |2p − 1| · E|r 4 h| mindestens das 1,5-Fache der Kosten zum Marktpreis aus dem aktuellen Buch erreicht).

**Was man erwarten darf:** Ohne echte Kante in den Experten ist die Fusion ungefähr die Basisrate, im Log-Verlust sogar
etwas schlechter (der Preis der Mischung, in der Probe 0,004 je Block). Die Daten sind knapp: Mit rund 240 effektiven 4-h-Blöcken
je Coin hat die Trefferquote einen Standardfehler von gut 3 Punkten. Ein Urteil gibt es frühestens nach drei Wochen live
(Auswertung U108 ab 25.10.); umgeschaltet wird nur mit Beleg.

## Kaskaden-Gleichung (seit 23.43)

Stufe 2b des Konzepts `KONZEPT_Fusion.md` (Abschnitt 4b), Modul `hl_kaskade.py`. Antwort auf die Frage nach einer Gleichung,
die den Kurs vorausberechnet: Für den Kurs selbst gibt es keine, für seine **Verteilung** schon. Der erste Baustein ist der
Teil, für den nur dieses System die Daten hat: die Liquidationscluster der Heatmap. Alles läuft **im Schatten** und ändert
weder die angezeigte Prognose noch v1, v2, v3 oder die Fusion.

**Die Gleichung.** Ein erzwungener Fluss Q (USD) verschiebt den Kurs nach dem Wurzelgesetz der Marktwirkung um
I = Y · σ_Tag · √(Q / V_Tag) (Tóth u. a. 2011). Erreicht ein Rutsch die Long-Cluster unter dem Kurs, schieben deren
Liquidationen ihn weiter. Reicht das bis zum nächsten Cluster, läuft die Kaskade weiter. Nach oben gilt dasselbe mit den
Short-Clustern. Die Rechnung ist exakt (geschlossene Form, mit 120.000 Fixpunkt-Vergleichen geprüft). Daraus folgen:
- **Kipppunkt:** der kleinste Rutsch (bzw. Anstieg), ab dem die Kaskade mindestens 0,5 σ(4 h) weiter trägt, und ihr **Ende**.
- **P(Rutsch ≥ 2 σ):** die Wahrscheinlichkeit binnen 4 h (bzw. 1 h), mit Clustern und zum Vergleich ohne Heatmap (derselbe
  Zufallsweg ohne die Cluster).
- **Kaskaden-Asymmetrie:** erwartete Reichweite oben gegen unten, −1 … +1. Sie ist ein Schatten-Treiber mit Gewicht 0.

**Kalibrierung.** Y wird je Coin und Horizont (1 h, 4 h) aus der eigenen Historie geschätzt, alle 6 h (erstmals 15 min nach
dem Start). Dazu gehören geblockte Kreuzvalidierung, die 1-SE-Regel zugunsten des kleineren Y und mindestens 120 Blöcke
(1 h: 5 Tage, 4 h: 20 Tage). **Belegt** ist Y erst, wenn vier Bedingungen erfüllt sind:
- Y > 0 ist gewählt.
- Der Vorsprung liegt über 2 Standardfehlern.
- Das **Placebo** wählt Y = 0. Es nutzt die Heatmap von drei Tagen vorher.
- Der **Seitenspiegel** ist deutlich schlechter. Er nutzt dieselben Cluster mit vertauschten Seiten.

Der Seitenspiegel trennt echte Kaskaden-Mechanik von einem bloßen Mitlaufen der Schwankung. Bis Y belegt ist, rechnen
Kipppunkt und Treiber mit Y = 1 (Literaturwert). Die Wahrscheinlichkeiten nehmen das kalibrierte Modell; mit Y = 0 ist das
der Zufallsweg.

**Wo man es sieht**
- AI-Prognose, Kachel „Kaskaden-Gleichung — Schatten“:
  - fett der untere Kipppunkt → Ende (Kurs und Abstand in %), darunter der obere;
  - dann Y (belegt oder Literaturwert, mit Grund), die Asymmetrie, P(Rutsch ≥ 2 σ) und P(Anstieg ≥ 2 σ) binnen 4 h (solange
    4 h nicht kalibriert ist: 1 h) und zum Vergleich ohne Heatmap;
  - zuletzt der Stand der Kalibrierung je Horizont.
- Treiber-Tabelle: „Kaskaden-Asymmetrie“ mit dem Etikett „Schatten“.
- Treiberfamilien: Familie „Kaskaden“.
- Debug:
  - „★ Kaskaden-Gleichung (Schatten)“: Stand je Coin mit Kipppunkten, Reichweite, Y je Horizont, Abstand ± SE, Brier-Skill,
    Zuverlässigkeit, Placebo, Seitenspiegel, Richtungsprobe der Asymmetrie und Abdeckung der Heatmap.
  - „Kaskaden-Gleichung: jetzt kalibrieren“.
  - „Kaskaden-Gleichung: Selbsttest“ (`python3 hl_kaskade.py --nulltest`, rund 15 s, auch Installationsschritt).
- Berichtsplan: wöchentlich in der Wochenprüfung (W12, mittwochs 19:00), dazu einmalig am 11.10. 19:45 (Stand und Selbsttest
  nach der ersten Woche) und am 25.10. 19:45 (Auswertung U115).
- TradeLabor, Gruppe Ereignisse: „Kaskaden-Kipppunkt“. Fällt der Kurs durch den unteren Kipppunkt, geht die Strategie Short
  bis zum berechneten Ende; steigt er durch den oberen, Long. Sie handelt nur, wenn der Weg zum Ende das 1,5-Fache der Kosten
  zum Marktpreis deckt. Stop 0,5 σ(1 h) hinter dem Kipppunkt, spätestens nach 2 h, je Kipppunkt einmal. Vergleich:
  „Kaskaden-Fortsetzung“ (dieselbe Idee ohne Gleichung).

**Was man erwarten darf**
- 1 h ist mit den vorhandenen Heatmap-Ständen sofort kalibrierbar. 4 h braucht etwa 20 Tage Aufzeichnung, das Placebo drei
  Tage mehr.
- Die Heatmap sieht nur die verfolgten Konten. Kipppunkte können deshalb zu weit weg liegen.
- Wahrscheinlich ist Y bei BTC und ETH klein oder nicht belegt, bei den dünneren Coins eher sichtbar. „Nicht belegt“ ist ein
  Ergebnis, kein Fehler.
- Ein Urteil gibt es ab dem 25.10. (U115). Eingeschaltet wird nur mit Beleg, als Sprung-Teil der Verteilungsprognose (U116).

## Grenzen

Die Heatmap ist unvollständig. Sichtbar werden nur Wallets, die gehandelt
haben, während der Recorder lief. Die Abdeckung wächst über Wochen, wird aber
nie vollständig — für relative Verteilungen reicht das, für absolute
Notional-Zahlen nicht.

Historische Positionsdaten gibt es nicht. Die These lässt sich nur vorwärts
prüfen, nicht rückwirkend. Zwei bis drei Monate sind ein realistischer
Zeitraum, bevor die Zahlen etwas bedeuten, weil Marktphasen stark korrelieren.

Handel mit Perpetuals und Kryptowährungen kann zum Totalverlust führen. Diese
Werkzeuge treffen keine Aussage darüber, ob eine Strategie funktioniert —
sie helfen nur beim Messen.
