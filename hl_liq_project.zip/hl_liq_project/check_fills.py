#!/usr/bin/env python3
"""
check_fills.py -- Wer hängt in der Fill-Abholung hinterher, und warum?

Liest nur. Verbindet den Abholstand (lb_cursor) mit der Klasse des Kontos (direktional,
gemischt, Hedge, Market Maker), seiner Herkunft (Leaderboard-Konto, Wal, beides) und der
Zahl der Fills je Tag -- denn die Kosten der Abholung wachsen mit der Fill-Zahl
(20 Gewicht je Seite plus 1 je 20 Einträge). Die Vermutung des Änderungskonzepts:
Die Rückständigen sind die Vielhandler, und Vielhandler sind meist Market Maker, deren
Fills keine Richtung tragen.

    python3 check_fills.py --db /media/seed/marketdatabase/hl_liq/hl_liq.db [--stunden 3]
"""
import argparse
import time

import hl_viz


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--stunden", type=float, default=3.0, help="ab so vielen Stunden gilt ein Konto als im Rückstand")
    a = p.parse_args()
    con = hl_viz.connect(a.db)
    now = int(time.time())

    cursor = {r[0].lower(): (r[1] or 0) for r in con.execute("SELECT addr, ts FROM lb_cursor")}
    if not cursor:
        print("lb_cursor ist leer -- der Recorder hat noch keine Fills abgeholt.")
        return
    last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    lb = {}
    if last:
        for r in con.execute("SELECT addr, rank, name, account_value FROM lb_accounts WHERE ts=?", (last,)):
            lb[r[0].lower()] = {"rank": r[1], "name": r[2], "value": r[3]}
    posval = {r[0].lower(): (r[1] or 0) for r in con.execute("SELECT addr, pos_value FROM addresses WHERE pos_value > 0")}
    bmap = hl_viz.behavior_map(con)
    pcoin = hl_viz.behavior_per_coin(con)
    gruppen: dict = {}
    for (addr_l, coin), e in pcoin.items():
        gruppen.setdefault(addr_l, set()).add(e["group"])
    fills = {r[0].lower(): r[1] for r in con.execute(
        "SELECT addr, COUNT(*) FROM lb_fills WHERE ts >= ? GROUP BY addr", (now - 7 * 86400,))}

    def klasse(addr_l: str) -> str:
        g = gruppen.get(addr_l)
        if g:
            if g == {"dir"}:
                return "direktional"
            if "mm" in g:
                return "Market Maker"
            if "hedge" in g:
                return "Hedge"
            return "gemischt"
        cls = bmap.get(addr_l, "")
        if cls.startswith("Market-Maker"):
            return "Market Maker"
        if cls.startswith("Hedge"):
            return "Hedge"
        if cls.startswith("gemischt"):
            return "gemischt"
        return "direktional" if cls else "unklassifiziert"

    zeilen = []
    for addr_l, ts in cursor.items():
        lag_h = (now - ts) / 3600 if ts else float("inf")
        herkunft = ("Leaderboard" if addr_l in lb else "") + ("+Wal" if posval.get(addr_l, 0) >= 20e6 else "")
        zeilen.append({"addr": addr_l, "lag_h": lag_h, "klasse": klasse(addr_l), "herkunft": herkunft.strip("+") or "nur Poller",
                       "fills_tag": fills.get(addr_l, 0) / 7.0, "wert": posval.get(addr_l) or (lb.get(addr_l) or {}).get("value") or 0,
                       "name": (lb.get(addr_l) or {}).get("name") or ""})
    zeilen.sort(key=lambda z: -z["lag_h"])
    hinten = [z for z in zeilen if z["lag_h"] > a.stunden]
    print(f"Fill-Abholstand: {len(hinten)} von {len(zeilen)} Konten mehr als {a.stunden:g} h im Rückstand\n")

    print("1. Rückständige Konten (schlechteste zuerst)")
    print(f"   {'Konto':<14} {'Rückstand':>9}  {'Klasse':<14} {'Herkunft':<15} {'Fills/Tag':>9}  {'Wert':>9}  Name")
    for z in hinten[:40]:
        lag = "nie" if z["lag_h"] == float("inf") else (f"{z['lag_h']:.1f} h" if z["lag_h"] < 48 else f"{z['lag_h'] / 24:.1f} T")
        print(f"   {z['addr'][:6]}…{z['addr'][-4:]:<4} {lag:>9}  {z['klasse']:<14} {z['herkunft']:<15} {z['fills_tag']:>9,.0f}  {z['wert'] / 1e6:>7.1f} M  {z['name'][:24]}")

    print("\n2. Nach Klasse -- wer erzeugt die Fills, wer hängt?")
    print(f"   {'Klasse':<14} {'Konten':>6} {'im Rückstand':>12} {'Fills/Tag gesamt':>16} {'Ø Fills/Tag':>12} {'Ø Rückstand':>12}")
    for k in ("direktional", "gemischt", "Hedge", "Market Maker", "unklassifiziert"):
        g = [z for z in zeilen if z["klasse"] == k]
        if not g:
            continue
        h = [z for z in g if z["lag_h"] > a.stunden]
        endlich = [z["lag_h"] for z in g if z["lag_h"] != float("inf")]
        print(f"   {k:<14} {len(g):>6} {len(h):>12} {sum(z['fills_tag'] for z in g):>16,.0f} {sum(z['fills_tag'] for z in g) / len(g):>12,.0f} "
              f"{(sum(endlich) / len(endlich) if endlich else 0):>10.1f} h")

    gesamt = sum(z["fills_tag"] for z in zeilen) or 1
    nicht_dir = sum(z["fills_tag"] for z in zeilen if z["klasse"] in ("Hedge", "Market Maker"))
    print(f"\n3. Anteil der Fills von Hedge- und Market-Maker-Konten: {nicht_dir / gesamt:.0%} aller Fills"
          f" -- das ist der Anteil, den 'Fills nur für direktionale Konten' (Konzept 2.4) einspart.")
    print("   Gewicht je Abholung: 20 + Fills/20. Ein Konto mit 5.000 Fills am Tag kostet allein ~270 Einheiten täglich,")
    print("   ein direktionales mit 20 Fills kostet 21.")


if __name__ == "__main__":
    main()
