#!/usr/bin/env python3
"""
check_fills.py -- Wer hängt in der Fill-Abholung hinterher, und warum?

Verbindet den Abholstand (lb_cursor) mit der Klasse des Kontos (direktional, gemischt,
Hedge, Market Maker), seiner Herkunft (Leaderboard-Konto, Wal) und der Zahl der Fills je
Tag. Unterscheidet Konten, die die Abholung überhaupt noch bedient (aktueller
Leaderboard-Schnappschuss), von veralteten Ständen ausgeschiedener Konten -- Letztere
sind kein Rückstand, nur Altlast in lb_cursor.

Dazu eine Live-Probe: Für die am weitesten zurückliegenden Konten der aktuellen Auswahl
wird EINE Fill-Abfrage gestellt (userFillsByTime ab dem gespeicherten Stand, je Konto
20 Gewicht plus 1 je 20 Einträge). Antwortet die API nicht oder mit einem Fehler, liegt
der Rückstand am Konto; antwortet sie mit vollen Seiten, handelt das Konto schneller als
wir abholen; antwortet sie normal, liegt es an der Zuteilung im Recorder.

    python3 check_fills.py --db /media/seed/marketdatabase/hl_liq/hl_liq.db [--stunden 3] [--probe 3] [--keine-probe]
"""
import argparse
import json
import time
import urllib.error
import urllib.request

import hl_viz

API = "https://api.hyperliquid.xyz/info"


def probe(addr: str, seit_ts: int) -> str:
    """Eine Fill-Abfrage ab seit_ts; liefert eine Zeile Befund."""
    body = json.dumps({"type": "userFillsByTime", "user": addr, "startTime": max(0, seit_ts) * 1000}).encode()
    req = urllib.request.Request(API, data=body, headers={"Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read(); code = r.status
    except urllib.error.HTTPError as e:
        return f"HTTP {e.code} nach {time.time() - t0:.1f} s: {e.read()[:120]!r}"
    except Exception as e:
        return f"keine Antwort ({type(e).__name__}: {e}) nach {time.time() - t0:.1f} s"
    dt = time.time() - t0
    try:
        data = json.loads(raw)
    except ValueError:
        return f"HTTP {code}, kein JSON ({len(raw)} Bytes) nach {dt:.1f} s"
    if not isinstance(data, list):
        return f"HTTP {code}, unerwartete Form {type(data).__name__}: {str(data)[:120]} nach {dt:.1f} s"
    if not data:
        return f"leere Liste nach {dt:.1f} s -- seit dem Stand keine Fills; der Recorder müsste den Stand auf 'jetzt' setzen"
    t_min = min(int(f.get("time", 0)) for f in data) // 1000; t_max = max(int(f.get("time", 0)) for f in data) // 1000
    befund = (f"{len(data)} Fills ({'VOLLE Seite' if len(data) >= 2000 else 'Teilseite'}), {len(raw) / 1024:.0f} kB in {dt:.1f} s, "
              f"Fills von vor {(time.time() - t_min) / 3600:.1f} h bis vor {(time.time() - t_max) / 3600:.1f} h · Gewicht {20 + len(data) // 20}")
    if len(data) < 2000 and t_max <= seit_ts + 3600 + 600:
        befund += ("\n      -> INAKTIV: seit dem Stand keine neuen Fills, alles Gelieferte stammt aus dem Überlappungsfenster. Kein Rückstand."
                   " (Bis 13.09. hielt die Cursor-Logik solche Konten für rückständig; behoben: Teilseite = bis jetzt gelesen.)")
    return befund


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--stunden", type=float, default=3.0, help="ab so vielen Stunden gilt ein Konto als im Rückstand")
    p.add_argument("--probe", type=int, default=3, help="so viele der schlechtesten Konten der Auswahl live abfragen")
    p.add_argument("--keine-probe", action="store_true")
    a = p.parse_args()
    con = hl_viz.connect(a.db)
    now = int(time.time())

    cursor = {r[0].lower(): (r[1] or 0) for r in con.execute("SELECT addr, ts FROM lb_cursor")}
    if not cursor:
        print("lb_cursor ist leer -- der Recorder hat noch keine Fills abgeholt.")
        return
    last = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
    lb = {}
    if last:
        for r in con.execute("SELECT addr, rank, name, account_value FROM lb_accounts WHERE ts=?", (last,)):
            lb[r[0].lower()] = {"rank": r[1], "name": r[2], "value": r[3]}
    posval = {r[0].lower(): (r[1] or 0) for r in con.execute("SELECT addr, pos_value FROM addresses WHERE pos_value > 0")}
    bmap = hl_viz.behavior_map(con)
    pcoin = hl_viz.behavior_per_coin(con)
    gruppen: dict = {}
    for (addr_l, coin), e in pcoin.items():
        gruppen.setdefault(addr_l, set()).add(e["group"])
    fills = {r[0].lower(): r[1] for r in con.execute(
        "SELECT addr, COUNT(*) FROM lb_fills WHERE ts >= ? GROUP BY addr", (now - 7 * 86400,))}
    meta = dict(con.execute("SELECT k, v FROM meta"))

    def klasse(addr_l: str) -> str:
        g = gruppen.get(addr_l)
        if g:
            if g == {"dir"}:
                return "direktional"
            if "mm" in g:
                return "Market Maker"
            if "hedge" in g:
                return "Hedge"
            return "gemischt"
        cls = bmap.get(addr_l, "")
        if cls.startswith("Market-Maker"):
            return "Market Maker"
        if cls.startswith("Hedge"):
            return "Hedge"
        if cls.startswith("gemischt"):
            return "gemischt"
        return "direktional" if cls else "unklassifiziert"

    zeilen = []
    for addr_l, ts in cursor.items():
        lag_h = (now - ts) / 3600 if ts else float("inf")
        herkunft = ("Leaderboard" if addr_l in lb else "") + ("+Wal" if posval.get(addr_l, 0) >= 20e6 else "")
        zeilen.append({"addr": addr_l, "lag_h": lag_h, "klasse": klasse(addr_l), "herkunft": herkunft.strip("+") or "ausgeschieden",
                       "aktiv": addr_l in lb, "ts": ts,
                       "fills_tag": fills.get(addr_l, 0) / 7.0, "wert": posval.get(addr_l) or (lb.get(addr_l) or {}).get("value") or 0,
                       "name": (lb.get(addr_l) or {}).get("name") or ""})
    zeilen.sort(key=lambda z: -z["lag_h"])
    aktiv = [z for z in zeilen if z["aktiv"]]
    hinten = [z for z in aktiv if z["lag_h"] > a.stunden]
    alt = [z for z in zeilen if not z["aktiv"]]
    print(f"Abholstand: {len(hinten)} von {len(aktiv)} Konten der aktuellen Auswahl mehr als {a.stunden:g} h im Rückstand")
    print(f"Dazu {len(alt)} veraltete Stände ausgeschiedener Konten in lb_cursor (werden nicht mehr abgeholt; kein Rückstand,"
          f" aber sie verfälschen die Kachel 'Fill-Abholstand', wenn sie mitgezählt werden)")
    print(f"Recorder-Zähler: vertagt (lb_fills_deferred) {meta.get('lb_fills_deferred', '—')} · Sprünge (lb_fills_jump) {meta.get('lb_fills_jump', '—')}"
          f" · db_locked {meta.get('db_locked', '—')} · Poller-Drossel {meta.get('poller_drossel', '—')}\n")

    print("1. Rückständige Konten der aktuellen Auswahl (schlechteste zuerst)")
    print(f"   {'Konto':<14} {'Rückstand':>9}  {'Klasse':<14} {'Herkunft':<15} {'Fills/Tag*':>10}  {'Wert':>9}  Name")
    for z in hinten[:40]:
        lag = "nie" if z["lag_h"] == float("inf") else (f"{z['lag_h']:.1f} h" if z["lag_h"] < 48 else f"{z['lag_h'] / 24:.1f} T")
        print(f"   {z['addr'][:6]}…{z['addr'][-4:]:<4} {lag:>9}  {z['klasse']:<14} {z['herkunft']:<15} {z['fills_tag']:>10,.0f}  {z['wert'] / 1e6:>7.1f} M  {z['name'][:24]}")
    print("   * aus den GESPEICHERTEN Fills der letzten 7 Tage -- bei Rückstand zu niedrig, weil die jüngsten Fills fehlen")

    print("\n2. Nach Klasse (aktuelle Auswahl) -- wer erzeugt die Fills, wer hängt?")
    print(f"   {'Klasse':<14} {'Konten':>6} {'im Rückstand':>12} {'Fills/Tag gesamt':>16} {'Ø Fills/Tag':>12} {'Ø Rückstand':>12}")
    for k in ("direktional", "gemischt", "Hedge", "Market Maker", "unklassifiziert"):
        g = [z for z in aktiv if z["klasse"] == k]
        if not g:
            continue
        h = [z for z in g if z["lag_h"] > a.stunden]
        endlich = [z["lag_h"] for z in g if z["lag_h"] != float("inf")]
        print(f"   {k:<14} {len(g):>6} {len(h):>12} {sum(z['fills_tag'] for z in g):>16,.0f} {sum(z['fills_tag'] for z in g) / len(g):>12,.0f} "
              f"{(sum(endlich) / len(endlich) if endlich else 0):>10.1f} h")
    gesamt = sum(z["fills_tag"] for z in aktiv) or 1
    nicht_dir = sum(z["fills_tag"] for z in aktiv if z["klasse"] in ("Hedge", "Market Maker"))
    print(f"   Anteil der Fills von Hedge- und Market-Maker-Konten: {nicht_dir / gesamt:.0%} (das spart 'Fills nur für direktionale Konten')")

    if alt:
        print("\n3. Veraltete Stände ausgeschiedener Konten (Auswahl):")
        for z in alt[:8]:
            print(f"   {z['addr'][:6]}…{z['addr'][-4:]}  {z['lag_h'] / 24:.1f} T alt · {z['klasse']} · Wert {z['wert'] / 1e6:.1f} M")

    if not a.keine_probe and hinten:
        print(f"\n4. Live-Probe: je eine Fill-Abfrage ab dem gespeicherten Stand für die {min(a.probe, len(hinten))} schlechtesten Konten")
        for z in hinten[:a.probe]:
            print(f"   {z['addr'][:6]}…{z['addr'][-4:]} (Stand vor {z['lag_h']:.1f} h): {probe(z['addr'], z['ts'] - 600)}")
            time.sleep(0.5)
        print("   Lesart: 'keine Antwort'/HTTP-Fehler -> das Konto selbst blockiert die Abholung (Stand darf nicht weiterrücken);")
        print("           'VOLLE Seite' -> das Konto handelt schneller als die Seiten je Lauf; 'Teilseite'/'leer' -> die Zuteilung im Recorder")
        print("           kommt nicht bis zu diesem Konto (Budget je Lauf zu klein oder Lauf bricht vorher ab -> Journal hl-recorder).")


if __name__ == "__main__":
    main()
