# KONZEPT Trading Engine (U241) – nur belegte Strategien handeln, gescheiterte erkennen, Papierkonto mit gemeinsamem Kapital

**Stand:** 03.11.2026, **Fassung 3** ab 23:10 (gemessen), nach zwei unabhängigen Durchsichten (Fassung 1 von 22:08, Fassung 2 von 22:49;
was falsch war, steht in Abschnitt 13). Entscheidung des Nutzers 03.11. 23:23 „Wie vorgeschlagen“ (Abschnitt 12). **Gebaut als Paket
23.93 (04.11.2026), Regeln unverändert; beim Bau festgelegte Einzelheiten, die unabhängige Durchsicht des Codes und die Proben in
Abschnitt 15.** Auf dem Pi lief beim Bau 2026-09-23.91 · cb6d059ba2. **Seit Paket 23.94** löst ein Button im Reiter die Bremse statt
Debug 142 (Wunsch des Nutzers 04.11. 02:57; Abschnitt 15, Punkt 17). Nichts davon handelt mit echtem Geld.

## 0. Kurz

- **Heute kann das TradeLabor das nicht.** Es zeigt Stufen (Kandidat, Bewährung, bewährt, negativ), schaltet aber nichts ab; „aktiv“
  heißt dort nur „aktuelle Regelversion“. Jede Strategie handelt ihr eigenes Konto mit 10.000 USD je Trade, ohne gemeinsames Kapital.
- **Die heutigen Stufen taugen nicht als Schalter.** Täglich angesehen, erreicht eine Strategie, die nach Kosten genau null verdient,
  in zwei Jahren mit 22–26 % irgendwann „Bewährung“ und mit 19–22 % „negativ“ – rein zufällig (Simulation, Abschnitt 6).
- **Vorschlag: ein Reiter „Engine“ im TradeLabor.** Das Labor läuft unverändert als Schatten weiter. Die Engine übernimmt nur die
  Trades der Strategien, die sie gerade für belegt hält, auf ein Papierkonto (100.000 USD, 10.000 USD je Trade, höchstens 10
  Positionen). Sie zählt ab ihrem Start und entscheidet aus der ganzen bisherigen Bilanz des Labors.
- **Aufnahme** nur mit Beleg, gemessen am Geld in Kalenderzeit: über die ganze Geschichte **oder** über die **letzten 17 Wochen**
  (rund 120 Tage). Das Fenster ist die Tür für die Rückkehr in einer neuen Phase. Nach einem schlechten Jahr kommt eine Strategie im
  folgenden guten Jahr zurück: bei starkem Vorsprung (netto +0,30 % je Trade, 3 Trades je Tag) in 99,7 % der Fälle, bei +0,20 % in
  91 %, bei +0,15 % in 65 % – im Median 4 bis 6 Monate nach dem Wechsel.
- **Pause**, wenn eine aktive Strategie nachlässt: im Median 20 Tage nach dem Ende ihres Vorsprungs (90 %: 41 Tage). Grundlos selten:
  eine gleichbleibend gute Strategie im Mittel 0,6- bis 0,7-mal in zwei Jahren; eine ruhige Zeit mit wenigen Trades ist kein Grund.
- **„Gescheitert“** ist eine Bezeichnung mit strenger Bedingung: mindestens 90 Tage und 13 Wochen, deutlich negativ (t ≤ −3), in
  beiden Hälften **und** in Monaten mit steigendem wie mit fallendem BTC. So fällt eine Long-lastige Strategie nicht wegen einer
  Abwärtsphase (zu Unrecht in 0,5 % der Fälle). Gelöscht wird nichts; zurück kommt eine gescheiterte Strategie über das 17-Wochen-Fenster.
- **Ehrliche Erwartung:** Nach dem Bericht vom 28.10. erfüllt keine Strategie die Aufnahme (beste t +1,3, verlangt 4,0). Die Engine
  bliebe zunächst ohne Trade. Gewinn macht sie erst, wenn eine Strategie einen echten Vorsprung nach Kosten hat. **Die Engine
  begrenzt Verluste, sie erzeugt keinen Vorsprung.**

## 1. Frage des Nutzers (03.11.2026, 21:48) und Befund

Kann das TradeLabor automatisch erkennen, wann eine Strategie definitiv und nachhaltig nicht profitabel ist, sie abschalten und so
auf lange Sicht nur noch profitabel handeln? Eine grundsätzlich gute Strategie soll nicht wegen einer schlechten Marktphase fallen,
und eine bis dahin erfolglose soll in einer neuen Phase (etwa einer stark bullischen) nach längerer Beobachtung wieder zum Zug kommen.
Vorschlag des Nutzers: ein Unterpunkt „Trading Engine“, der neu zu zählen beginnt, aus der bisherigen Bilanz Schlüsse zieht und
selbst entscheidet, mit welchen Strategien er auf Papier handelt, wie es mit echtem Geld wäre. (Die Nachricht endete mitten im Satz;
gelesen wie hier beschrieben.)

**Befund im Code (`hl_labor.py`, Paket 23.92):**
- `_stat` vergibt Stufen: Bewährung ab 15 Blöcken mit t ≥ 2 und Summe > 0; bewährt ab 30 Blöcken mit t ≥ 3, beiden Hälften positiv und
  14 Tagen; negativ ab 30 Blöcken mit t ≤ −2. „Glück“ = einseitiges p mal Zahl der aktiven Strategien.
- Die Stufen sind nur Anzeige. `labor_strategie.aktiv` wechselt nur mit der Regelversion.
- Kein gemeinsames Kapital, keine Höchstzahl offener Positionen, keine Auswahl.

**Datenlage (Bericht Nr. 13 vom 28.10.2026, 19:17):** 49 Strategien × 5 Coins, 12.794 geschlossene Trades, netto −206.846,96 USD
(Gebühren 81.272,89). Stufen: Kandidat 36, Bewährung 0, bewährt 0, negativ 13, darunter „Zufall (Kontrolle)“ (t −2,1): Wer zufällig
handelt, zahlt Kosten. Beste Strategie Funding-Extrem +4.019 USD (30 Blöcke, t +1,3). Streuung je Block, aus Ø und t
zurückgerechnet, rund 0,4–3,5 %; von 0,06 bis 30 Trades je Tag (über alle Coins).

## 2. Wann ist eine Strategie gescheitert – und wann nur in einer schlechten Phase?

- **Netto = Können + Marktrichtung × Anteil Long/Short − Kosten.** Eine Strategie, die meist Long geht, verliert in einer
  Abwärtsphase auch mit gutem Timing, und gewinnt in einer Aufwärtsphase auch ohne.
- **Darum zählt für „gescheitert“ die Monatsart:** Verliert eine Strategie in Monaten mit steigendem BTC **und** in Monaten mit
  fallendem BTC, liegt es nicht an der Phase. Verliert sie nur in fallenden Monaten, ist sie nicht gescheitert, sondern Long-lastig.
  In einer Zeit, in der nur eine Monatsart vorkommt, kann deshalb keine Strategie „gescheitert“ heißen – gewollt.
- **Pausieren ist etwas anderes:** Die Engine schützt ihr Kapital, sobald eine aktive Strategie deutlich schlechter läuft als bei
  der Aufnahme – egal warum, auch wegen der Phase. Pause ist schnell und rückgängig; „gescheitert“ ist langsam und streng.
- **Rückkehr in einer neuen Phase:** Die Aufnahme darf sich auf die letzten 17 Wochen allein stützen. Eine lange schlechte
  Vergangenheit verhindert die Rückkehr nicht. Wie schnell sie gelingt, hängt an der Stärke des neuen Vorsprungs (Abschnitt 6).
- **Warum nicht einfach „negativ seit X Tagen“?** Bei regelmäßigem Hinsehen überschreitet jede Zufallsreihe irgendwann eine feste
  Schwelle. Die Schwellen unten sind deshalb für wöchentliche Prüfung über zwei Jahre ausgelegt und in der Simulation geprüft, auch mit
  schweren Rändern, Schwankungsballung, schiefer Verteilung, langsam wanderndem Erfolg, der echten Handelshäufigkeit und einem
  gemeinsamen Markt für alle Strategien.
- Literatur: Vorsprünge schrumpfen außerhalb der Stichprobe (Renditen von 97 Aktien-Anomalien nach der Stichprobe 26 %, nach der
  Veröffentlichung 58 % niedriger; McLean & Pontiff 2016) – die Engine muss nachlassende Strategien also erkennen. Bei vielen
  geprüften Ideen braucht ein Beleg ein höheres t (Harvey, Liu & Zhu 2016: t > 3; Bailey & López de Prado 2014: Sharpe nach der Zahl
  der Versuche abwerten). Faktoren mit gutem Vorjahr liefen bei Aktien im Mittel weiter besser (Ehsani & Linnainmaa 2022) – ob das für
  kurzfristige Krypto-Strategien gilt, zeigt erst die Vorwärtsbilanz der Engine.

## 3. Aufbau

- **Labor = Schatten.** Unverändert: alle Strategien, alle Regelversionen, alle Berichte, Welt A und B der Notbremse. Kein Code des
  Labors ändert sich; die Engine liest nur.
- **Engine = Auswahl.** Öffnet das Labor (Welt B) einen Trade einer Strategie, die in diesem Moment in der Engine aktiv ist, übernimmt
  die Engine ihn mit denselben Kursen, Kosten und Ausstiegen, sofern ihr Konto Platz hat (Abschnitt 5). Bei Limit-Orders zählt der
  Zeitpunkt der Füllung. Das Ergebnis der Engine ist die Summe der übernommenen Labor-Trades.
- **Zählung:** Das Engine-Konto beginnt am Tag nach dem Einspielen um 00:00 UTC mit 100.000 USD. Die Entscheidungen nutzen die Bilanz
  der aktuellen Regelversion seit ihrem Start im Labor.
- **Umfang der ersten Fassung: 34 Strategien mit höchstens 24 h Haltedauer** – Händler (8), Darwin (2), Elite (2), Prognose (4),
  Kauf-/Verkaufspreise (1), Familien (9), Ereignisse (Kaskaden-Umkehr, Kaskaden-Fortsetzung, Docht fangen, Magnet,
  Kaskaden-Kipppunkt, Funding-Extrem, Ausbruch nach Ruhe, TWAP-Druck).
- **Nicht in der ersten Fassung:** Swing, Zyklus und Extrem-Wende (Haltedauer bis 30, 60 bzw. 120 Tage: eine einzige Position hielte
  monatelang einen der 10 Plätze, ihre Ergebnisse kommen Wochen zu spät für eine Pause), die Grids (übernommener Bestand bei der
  Aufnahme und das Ende bei einer Pause sind nicht sauber bestimmt), die Akkumulation (kein Trade, eigene Bilanz) und alle Kontrollen
  (Vergleich, nie Kandidat). Für sie bräuchte es eigene Regeln.

## 4. Regeln (vorab festgelegt)

### 4.1 Daten je Strategie
- **Tagessumme** in USD: Netto aller Trades, die an diesem UTC-Tag eröffnet wurden (Gebühren, Abstand zur Buchmitte, Funding wie im
  Labor), als Summe wie im Konto der Engine; dazu die Zahl dieser Trades. Tage ohne Trade zählen mit 0. Ein Tag gilt erst, wenn alle
  seine Trades geschlossen sind; offene Trades zählen nie.
- **Ausfall:** Ein Tag, an dem das Labor länger als 1 h nicht lief, fehlt (er zählt nicht als Tag ohne Trade); eine Woche mit einem
  fehlenden Tag fällt aus den Tests.
- **Wochensumme:** Montag bis Sonntag (UTC), nur vollständige Wochen.
- **Monatsart:** Kalendermonat (UTC) mit steigendem oder fallendem BTC-Schlusskurs; nur abgeschlossene Monate.

### 4.2 Aufnahme – wöchentlich, dienstags 00:30 UTC
Geprüft wird die Woche bis Sonntag, sobald alle ihre Trades geschlossen sind (sonst am nächsten Tag um 00:30 UTC). Eine Strategie,
die nicht aktiv ist, wird aufgenommen, wenn **(A) oder (B)** gilt:
- **(A) ganze Geschichte:** mindestens **9 Wochen** und 30 Trades, t der Wochensummen **≥ 4,0**, beide Hälften der Wochen positiv;
- **(B) letzte 17 Wochen** (rund 120 Tage): mindestens 30 Trades, t **≥ 4,5**, beide Hälften der 17 Wochen positiv.

Dazu:
- **nach einer Pause** frühestens 30 Tage danach; über (A) nur, wenn die Summe seit der Pause positiv ist (die alte gute Geschichte
  soll eine eingebrochene Strategie nicht zurückholen), über (B) ohne diese Bedingung (das Fenster misst die jüngste Zeit selbst);
- **nach „gescheitert“** nur über (B).

### 4.3 Pause – täglich, 00:30 UTC
- **CUSUM (Page 1954) in Handelszeit** seit der Aufnahme: Bezug ist die halbe Netto-Rendite je Trade, mit der die Strategie aufgenommen
  wurde, vorsichtig gerechnet (Mittel minus ein Standardfehler), in Vielfachen ihrer Streuung je Trade. Je vollständigem Tag wächst eine
  Summe um (Zahl der Trades × Bezug − Tagessumme ÷ Streuung), höchstens um 3 · √(Zahl der Trades) in jede Richtung, nie unter 0. Ein
  Tag ohne Trade ändert nichts – eine ruhige Zeit ist kein Nachlassen.
- **Grenze je Strategie:** so, dass eine unveränderte Strategie im Mittel erst nach **zwei Jahren** grundlos pausiert (Siegmunds
  Näherung, gerechnet in Trades: 730 Tage × Trades je Tag bei der Aufnahme). Erreicht die Summe die Grenze, pausiert die Strategie.
- Offene Positionen der Engine laufen nach den Regeln der Strategie zu Ende (höchstens 24 h; Entscheidung 4).

### 4.4 Gescheitert – Bezeichnung, wöchentlich
Gezählt seit dem Start der Regelversion, nach einer Rückkehr seit der Rückkehr; alle Bedingungen:
1. mindestens **13 Wochen und 90 Tage**;
2. t der Wochensummen **≤ −3**;
3. beide Hälften negativ;
4. **Tagesmittel negativ in Monaten mit steigendem und in Monaten mit fallendem BTC**, je mindestens 28 Tage.
- Folge: Die Strategie kann nur noch über (B) aufgenommen werden. Ist sie gerade aktiv, pausiert sie. Im Labor läuft sie weiter. Wird
  sie wieder aufgenommen, heißt sie „zurückgekehrt am …“.

### 4.5 Was die Engine nicht tut
- keine Auswahl je Coin (34 statt 170 Kandidaten; je Coin sind die Zahlen zu klein); kein Hebel; keine Änderung an den Regeln einer
  Strategie; kein Nachjustieren der Schwellen innerhalb einer Runde (Abschnitt 10); kein echtes Geld.

## 5. Engine-Konto (Papier, wie mit echtem Geld)

- 100.000 USD Startkapital; je übernommenem Trade 10.000 USD wie im Labor (1×, gleiche Kosten).
- **Höchstens 10 offene Positionen** (= 100 % des Kapitals), **höchstens 4 je Coin** und **höchstens 6 in dieselbe Richtung**
  (gegen gleichlaufende Strategien, die zusammen in einer Phase aufgenommen werden). Ist kein Platz frei, wird der Trade ausgelassen
  und gezählt („Kapazität“).
- **Bremse:** Fällt das Konto 10 % unter seinen Höchststand, pausiert die Engine alle Strategien und meldet es; weiter nur nach
  Entscheidung des Nutzers (Entscheidung 6). Damit hängt die Vorwärtsbilanz ab dann auch an dieser Entscheidung.
- Grundlage Welt B (das Labor ohne Notbremse); Welt A beschreibend daneben (Entscheidung 5).

## 6. Warum diese Schwellen: Simulation Fassung 3 (03.11.2026, 23:09–23:10, Sandbox)

Synthetische Strategien über 735 Tage (105 Wochen), Regeln wie in Abschnitt 4 (ohne Mindestzahl von 30 Trades, ohne Ausfälle).
Je Trade: Student-t-Ränder (ν = 3) oder linksschief, Schwankungsballung, Kosten 0,15 %; der Richtungsanteil folgt der echten
Marktbewegung (Phasen auf, seitwärts, ab mit ±0,4 % je Tag, Wechsel im Mittel alle 60 Tage, dazu 3 % Tagesschwankung), die Monatsart
kommt aus derselben Bewegung. Damit liegt die Streuung je Trade bei rund 1,1 % (4 h) bzw. 3,6 % (24 h, Long-lastig). Werte als Summe in
% von 10.000 USD (1 Punkt = 100 USD), zwei Jahre, 1.000 Wiederholungen je Zeile.

**Heutige Stufen, täglich angesehen (Fassung-1-Simulation, Blöcke):** Eine Strategie mit netto 0 erreicht in zwei Jahren mit 22–26 %
„Bewährung“, mit 1,7–2,2 % „bewährt“ und mit 19–22 % „negativ“; eine gute Long-lastige Strategie (24 h) wird in 12 % der Fälle
„negativ“; eine nachlassende bleibt im Median 210 Tage nach dem Ende ihres Vorsprungs „in Bewährung“.

**Regeln dieses Konzepts, je Strategie:**

| Strategie (3 Trades/Tag, wenn nicht anders genannt) | aufgenommen (Median Tage) | Pausen je 2 J | „gescheitert“ (Median Tage) | Engine / ungefiltert |
|---|---|---|---|---|
| kein Können (netto −0,15) | 0 % | – | 99,7 % (148) | 0 / −331 |
| Können = Kosten (netto 0) | 0,7 % | 0,01 | 0,9 % | 0 / +2 |
| dasselbe mit 19 Trades je Tag | 0,6 % | 0,01 | 2,1 % | 0 / 0 |
| gut (netto +0,15) | 99 % (169) | 0,66 | 0 % | 215 / 332 (65 %) |
| stark (netto +0,30) | 100 % (64) | 0,63 | 0 % | 566 / 661 (86 %) |
| gut, selten (1 Trade/Tag, netto +0,30) | 99,8 % (141) | 0,60 | 0 % | 159 / 220 (72 %) |
| **gut, Long-lastig, 24 h** (1/Tag, netto +0,15 ohne Phase) | **5,5 %** (302) | 0,05 | 0,5 % | 1 / 114 (1 %) |
| Können = Kosten, Long-lastig, 24 h | 1,6 % | 0,01 | 2,8 % | 0 / −8 |
| schlecht (netto −0,30) | 0 % | – | 100 % (92) | 0 / −663 |
| nachlassend (180 T +0,30, dann −0,15) | 97 % (64) | 1,15 | 0,3 % | **71 / −88** |
| gut, 120 Tage ruhig (3 → 0,3 Trades/Tag) | 100 % (64) | 0,51 | 0 % | 468 / 563; in der Ruhe pausiert 0,6 % |

**Rückkehr in einer neuen Phase** (ein Jahr netto −0,30, dann ein gutes Jahr; bzw. gut – schlecht – gut):

| Gutes Jahr danach | zurück im guten Jahr | Median Tage nach dem Wechsel | Engine im guten Jahr / ungefiltert |
|---|---|---|---|
| netto +0,30, 3 Trades/Tag | 99,7 % | 119 | 199 / 332 (60 %) |
| netto +0,20, 3 Trades/Tag | 90,7 % | 140 | 90 / 221 (41 %) |
| netto +0,15, 3 Trades/Tag | 64,8 % | 189 | 38 / 166 (23 %) |
| netto +0,30, 1 Trade/Tag | 74,5 % | 168 | 35 / 110 (32 %) |
| 180 T gut, 270 T schlecht (pausiert), dann +0,30 | 97,6 % | 118 | 129 / 256 (50 %) |

- **Nachlassend:** nach dem Ende des Vorsprungs pausiert die Engine im Median nach **20 Tagen** (90 %: 41 Tage) und verliert danach
  10,6 Punkte.
- **Preis der Vorsicht:** Gute Strategien bringen in der Engine 65–86 % dessen, was sie ungefiltert brächten; nach einem Phasenwechsel
  23–60 %. **Eine gute, aber Long-lastige Strategie mit 24 h Haltedauer lässt sich in zwei Jahren fast nie belegen** (5,5 %): Ihr
  Ergebnis geht in der Marktbewegung unter. Sie heißt dafür auch nicht gescheitert (0,5 %). Faustregel für die nötige Zeit: rund
  (4 · σ_Woche ÷ μ_Woche)² Wochen.
- **Die Engine als Ganzes** (200 Welten, die 34 Kandidaten mit ihrer echten Handelshäufigkeit vom 28.10., alle mit netto 0, ein
  gemeinsamer Markt je Welt): mindestens eine grundlose Aufnahme in zwei Jahren in **22,5 %** der Welten (im Mittel 0,27), Ergebnis im
  Mittel −1,7 Punkte, in den schlechtesten 5 % −21 Punkte (rund −2.100 USD). **Mit leicht wanderndem Erfolg** (0,25 % der Streuung,
  Persistenz 0,9 über Tage): **51 %** (im Mittel 0,70), Ergebnis im Mittel −0,7 Punkte, schlechteste 5 % −38 Punkte. Zehn Long-lastige
  Strategien mit netto 0 im selben Markt: mindestens eine Aufnahme in 11,5 %, drei zugleich in 1 %, im Mittel +0,8 Punkte, schlechteste
  5 % −18 Punkte. Die echten Strategien liegen meist deutlich unter null; für sie ist die Aufnahme noch seltener.
- **Schiefe und Seltenheit** (Kalibrierung Fassung 2 und Durchsicht): Linksschief bei 3 bzw. 19 Trades je Tag 1,4 % bzw. 0,9 %
  Aufnahme bei netto 0; bei 0,3 Trades je Tag und linksschief 2,25 % – deshalb die Mindestzahl von 30 Trades in (A) und (B).
- **Strengere Schwellen 4,5 / 5,0** (Entscheidung 2): Aufnahme bei netto 0 je Strategie 0,3 %; als Ganzes 10,5 % (mit Wandern 30 %),
  schlechteste 5 % −10 bzw. −22 Punkte. Dafür langsamer und weniger Ertrag: gut 189 statt 215 Punkte (−12 %), selten −9 %, stark −2 %;
  Rückkehr bei +0,15 in 51 % statt 65 %, bei +0,30 182 statt 199 Punkte.
- **Gegen Fassung 1:** Pausen einer guten Strategie 0,6–0,7 statt 2,6 in zwei Jahren; Rückkehr nach einem schlechten Jahr (stark)
  99,7 % statt 2,75 %.
- Grenzen der Simulation: Kosten fest; Kapazität und Bremse nicht gerechnet; die Mindestzahl von 30 Trades und Ausfälle nicht gerechnet
  (sie betreffen keine Zeile mit mindestens 1 Trade je Tag). Die echte Probe ist die Vorwärtsbilanz.

## 7. Was heute daraus folgt (Erwartung vorab, Stand 28.10.)

- Die Strategien laufen seit dem 27.09. (Sonntag); die erste volle Woche begann am 28.09. **Frühestens am 01.12.2026** sind 9 volle
  Wochen da (Aufnahme nach (A)), **frühestens am 29.12.2026** 13 Wochen und 90 Tage („gescheitert“), (B) ab dem 26.01.2027 – für
  Strategien, deren Regelversion später begann, entsprechend später.
- **Aufnahme:** wahrscheinlich keine (beste t +1,3 in Blöcken; verlangt 4,0 in Wochen).
- **Gescheitert:** frühestens am 29.12., am ehesten die mit großem negativem t (Familie Orderfluss −19,1, Großkonten-Fluss −6,1, TWAP
  −4,4) – sofern sie in steigenden und fallenden Monaten verlieren.
- **Engine-Konto:** zunächst ohne Trade. Das ist das richtige Ergebnis, solange nichts belegt ist; der Vergleich mit den −206.847 USD
  des Labors ist deshalb kein Verdienst der Engine.

## 8. Anzeige, Debug, Berichtsplan

- **Reiter „Engine“ im TradeLabor:** Kopf (Konto, Netto seit Start, größter Rückgang, aktive Strategien, offene Positionen, ausgelassen
  wegen Kapazität; daneben Labor gesamt und Halten Long im selben Zeitraum); Tabelle je Strategie (Zustand, seit, Grund in Worten,
  Wochen, Trades, t ganze Geschichte, t letzte 17 Wochen, Stand der Überwachung in % der Grenze, Tagesmittel in steigenden und
  fallenden Monaten); Protokoll aller Entscheidungen (Zeit, Strategie, alt → neu, Zahlen); Kontoverlauf mit Labor und Halten Long;
  Tabelle statt Bild. Der Zustand heißt in der Datenbank `engine_zustand`, nicht `aktiv` (das Wort ist im Labor belegt).
- **Debug (Nummern beim Bau, nächste freie 138):** „★ Trading Engine: Stand“, „Trading Engine: Rückblick seit dem 27.09.
  (beschreibend)“, „Trading Engine: Selbsttest“, „Trading Engine: Mutationsprüfung“. (Beim Bau kam 142 als Schalter zum Lösen der
  Bremse dazu; seit 23.94 ersetzt durch den Button „Bremse lösen“ im Reiter, Abschnitt 15, Punkt 17.)
- **Berichtsplan:** Stand in der Wochenprüfung (mittwochs 19:00), der Rückblick einmal am Tag nach dem Einspielen.
- **Rückblick:** die Regeln ab dem 27.09. Tag für Tag auf die Labor-Trades angewandt, nur mit Daten bis zum jeweiligen Tag – was die
  Engine getan hätte. Beschreibend: Er ändert keine Schwelle.

## 9. Proben (Selbsttest ohne Netz, Mutationen, Browser)

- **Rechnung von Hand:** Tagessumme nach Einstiegstag, vollständige Tage, Ausfalltag, Wochensummen, t, Hälften, (A) und (B),
  Mindestzahl Trades, CUSUM-Zuwachs in Handelszeit und Grenze aus Siegmunds Näherung, Monatsart, Abkühlung für (A) und (B).
- **Nullprobe:** 34 Strategien mit netto 0 und der Handelshäufigkeit vom 28.10., gemeinsamer Markt, zwei Jahre → im Mittel höchstens
  0,5 grundlose Aufnahmen je Welt und Ergebnis der Engine im Mittel nicht unter −5 Punkten (Simulation: 0,27 und −1,7). Mit wanderndem
  Erfolg wären es 0,70 – das ist eine Eigenschaft der Regeln, kein Fehler im Code, und steht im Bericht.
- **Positivkontrolle:** eingepflanzte Strategie mit netto +0,3 % → aufgenommen, Median höchstens 80 Tage; nach dem Ende des Vorsprungs
  pausiert, Median höchstens 30 Tage.
- **Rückkehr:** ein Jahr −0,3, dann +0,3 → im guten Jahr aufgenommen in mindestens 95 % der Welten; gut – schlecht (pausiert) – gut →
  mindestens 90 %.
- **Ruhe:** gute Strategie mit 120 ruhigen Tagen (ein Zehntel der Trades) → pausiert in höchstens 5 %.
- **Phase:** gute Long-lastige Strategie in einer 120-Tage-Abwärtsphase → nicht „gescheitert“.
- **Kausal:** Trades nach dem Prüfzeitpunkt beliebig ändern → kein Zustand bis dahin ändert sich; ein offener Trade zählt nie.
- **Konto:** Kapazität (11. Position ausgelassen), Grenzen je Coin und Richtung, Bremse bei −10 %, Limit-Order nach Zustand bei der
  Füllung.
- **Mutationen (müssen rot werden):** Mittel statt Summe je Tag; offene Trades mitgezählt; Ausfalltag als 0; Wochen nicht vollständig;
  nur (A), ohne das 17-Wochen-Fenster; ohne Abkühlung; Abkühlung mit Summe auch für (B); CUSUM in Tagen statt in Trades; Bezug ohne
  Abschlag; Grenze fest statt aus der Laufzeit; ohne Kappung; „gescheitert“ ohne Monatsbedingung; „gescheitert“ ohne Hälften; nach
  „gescheitert“ (A) erlaubt; ohne Mindestzahl Trades; Trades pausierter Strategien übernommen; Kapazität ignoriert; Kontrollen als
  Kandidat; Zustand mit Trades nach dem Prüfzeitpunkt.
- **Browser:** Reiter „Engine“ bei 1280 und 390 px, drei Datenstände (leer, mit aktiver Strategie, mit Pause und „gescheitert“).

## 10. Bewertung der Engine selbst (vorab)

- **Nach 90 und nach 180 Tagen Engine:** Netto der Engine mit 90-%-Intervall (Blockbootstrap über Wochen) gegen 0, gegen das Labor
  gesamt (gleicher Zeitraum, auf 100.000 USD umgerechnet) und gegen Halten Long; größter Rückgang. Beschreibend.
- „Aufgenommen“ heißt „vorläufig belegt“, nicht „bewiesen“: Grundlose Aufnahmen kommen vor (Abschnitt 6). Darum bleibt
- **echtes Geld** wie bisher eine eigene Entscheidung des Nutzers: frühestens nach 6 Monaten Engine ohne Widerspruch und nie
  automatisch.
- Kein Nachjustieren innerhalb der Runde. Eine Änderung der Regeln ergibt eine neue Fassung mit eigenem Start; die alte Bilanz bleibt.

## 11. Grenzen

- Die Engine kann nur auswählen, was das Labor anbietet. Bleibt jede Strategie unter ihren Kosten, bleibt die Engine flach.
- Sie erkennt eine gute Phase erst, wenn sie sich in den Daten zeigt: Rückkehr im Median 4 bis 6 Monate nach dem Wechsel, bei kleinem
  Vorsprung oft gar nicht im selben Jahr. Wer nur in kurzen Phasen trägt, wird spät oder nie aufgenommen.
- Strategien, deren Ergebnis von der Marktbewegung überdeckt wird (Long-lastig, lange Haltedauer), lassen sich kaum belegen.
- Die Kosten im Labor sind vorsichtig gerechnet (Taker, Abstand zur Mitte, Marktauswirkung), aber nicht mit echten Fills geprüft.

## 12. Entscheidungen beim Nutzer

1. **Engine bauen** als Reiter „Engine“ im TradeLabor, nur Papier, liest das Labor nur (Vorschlag: ja, als Paket 23.93; Einspielen
   nicht in den Minuten um So 08.11. 09:15).
2. **Schwellen der Aufnahme:** **4,0 ganze Geschichte / 4,5 letzte 17 Wochen (Vorschlag)** – schneller; als Ganzes in 22–51 % der
   Welten mindestens eine grundlose Aufnahme in zwei Jahren, im Mittel ohne nennenswerten Verlust (schlechteste 5 %: −2.100 bis
   −3.800 USD); oder 4,5 / 5,0 – 10–30 %, dafür langsamer und bis 12 % weniger Ertrag guter Strategien.
3. **Konto:** **100.000 USD, 10.000 USD je Trade, höchstens 10 Positionen, 4 je Coin, 6 in dieselbe Richtung (Vorschlag)**.
4. **Bei Pause:** offene Positionen **regulär zu Ende laufen lassen (Vorschlag)** oder sofort schließen.
5. **Grundlage:** **Welt B (Vorschlag)** oder Welt A mit Notbremse.
6. **Bremse:** **−10 % vom Höchststand, weiter nur nach deiner Entscheidung (Vorschlag)** · −15 % · keine.

**Entscheidung des Nutzers (03.11.2026, 23:23, Zeitpunkt der Nachricht):** „Wie vorgeschlagen“ – alle sechs Punkte wie vorgeschlagen:
Bau als Paket 23.93; Schwellen 4,0 / 4,5; Konto 100.000 USD, 10.000 USD je Trade, höchstens 10 Positionen, 4 je Coin, 6 in dieselbe
Richtung; offene Positionen laufen bei einer Pause zu Ende; Grundlage Welt B; Bremse −10 % vom Höchststand, weiter nur nach Entscheidung
des Nutzers. Der Nebenbefund (Abschnitt 14) bleibt offen.

## 13. Fassungen und Durchsichten (eigene Fehler)

**Durchsicht 1 (Bericht 22:40) zu Fassung 1 (22:08):**
- **Vergleich mit Zufallseinstiegen verzerrt (schwer):** Fassung 1 maß einen „Vorsprung“ gegen 50 zufällige Einstiege in ±3,5 Tagen
  um den echten Einstieg. Diese Einstiege enthielten die Kursbewegung, die das Signal ausgelöst hat. Auf reinen Zufallskursen, wo kein
  Können möglich ist und Vorsprung minus Kosten genau −0,15 % sein müsste, ergab sich für Trend- und Ausbruchsregeln mit 24 h bis 10
  Tagen Haltedauer −0,7 bis −2,0 % je Trade und für eine Gegenbewegungsregel +0,4 %. Profitable Trendregeln wären „gescheitert“,
  verlustreiche Gegenbewegungsregeln nie. Meine Simulation zog den Vorsprung als Zufallszahl statt aus Kursen und konnte das nicht
  zeigen. **Eigener Fehler. Gestrichen;** die Phase trennt jetzt die Monatsbedingung. Auch die Grid-Kontrolle (mittlerer Bestand des
  Tages) blickte in die Zukunft (+0,59 % je Tag ohne Können).
- **Kein Vergessen (schwer):** Aufnahme nur über die ganze Geschichte – nach einem schlechten Jahr kam eine starke Strategie im guten
  Jahr nur in 2,75 % der Fälle zurück. Jetzt Fenster (B).
- **Abhängigkeit in Kalenderzeit (schwer):** Newey-West über 5 Blöcke hielt die Fehlerraten bei vielen Blöcken je Tag nicht, wenn der
  Erfolg langsam wandert (bis 29 % statt 0,8 %). Jetzt Tages- und Wochensummen.
- **Weitere:** zu häufige grundlose Pausen (2,6 in zwei Jahren); Mittel je Block statt der Summe, die das Konto bucht; halb offene
  Blöcke bei der Prüfung; Fehlerrate der Engine als Ganzes nicht genannt; Nullprobe zu schwach; die Bedingung „Vorsprung t ≥ 1“
  änderte die Aufnahme um weniger als 0,5 Prozentpunkte; eine ungünstige Zahl fehlte in der Zusammenfassung; ein Fehler in der
  Simulation (Zählung für „gescheitert“ nach einer Rückkehr).

**Durchsicht 2 (Bericht 23:07) zu Fassung 2 (22:49):** Die Befunde von Durchsicht 1 sind behoben; alle Zahlen von Fassung 2
ließen sich bitgleich nachrechnen. Neu:
- **Abkühlung ohne Gedächtnis (schwer):** Die Bedingung „Summe seit der Pause positiv“ galt auch für (B). Eine Strategie, die gut war,
  in einer langen schlechten Phase pausierte und dann wieder gut wurde, kam nur in 61 % der Fälle zurück (Median 237 Tage). Jetzt gilt
  die Summe nur für (A): 97,6 %, 118 Tage.
- **Messfehler bei der Pausendauer:** „Pause nach 10 Tagen (90 %: 25)“ zählte Tage ohne Trade als Pause. Richtig: 20 Tage (90 %: 41).
  **Eigener Fehler** in der Auswertung.
- **Rückkehr überzeichnet:** „99 %, egal wie schlecht vorher“ galt nur für den stärksten Vorsprung; jetzt mit der Tabelle je Stärke.
- **CUSUM in Tagen verwechselte Ruhe mit Nachlassen:** Eine unveränderte Strategie mit einer ruhigen Zeit (ein Zehntel der Trades)
  pausierte in 87 % der Fälle. Jetzt in Handelszeit: 0,6 %.
- **Fehlerrate der Engine als Ganzes zu günstig:** gerechnet mit 3 Trades je Tag, unabhängigen Märkten und ohne Wandern. Mit der echten
  Handelshäufigkeit, einem gemeinsamen Markt und leichtem Wandern 51 % statt 21 %.
- **Kleineres:** Prüfung genau um 00:00 ohne Spielraum (jetzt 00:30 und „sobald vollständig“); seltene, linksschiefe Strategien (jetzt
  Mindestzahl 30 Trades); Streuung zu niedrig angegeben; Ausfalltage als Tage ohne Trade; „rund 13 % weniger“ war das Höchste, nicht
  das Übliche; eine Welt ohne Monate beider Arten kennt kein „gescheitert“.

## 14. Nebenbefund (nicht Teil der Engine, Entscheidung offen)

Die Familie Orderfluss verliert seit dem 27.09. stark und gleichmäßig (Ø −0,564 % je Trade nach Kosten, t −19,1 über 584 Blöcke). Ist
das kein Artefakt der Ausführung, wäre eine Gegenregel ein ernsthafter Kandidat. Sie ist aber kein Spiegelbild: Stop (1,5 σ) und
Ziel (2 σ) sind ungleich, die Gegenregel zahlt dieselben Kosten. Das zeigt nur ein eigener, vorab festgelegter Vorwärtstest im Labor
(neue Kennung, eigenes Urteil). Vorschlag: als eigener Plan-Punkt, wenn du willst.

## 15. Bau (Paket 23.93, vor dem ersten Lauf festgelegt)

Gebaut am 03./04.11.2026 nach der Entscheidung „Wie vorgeschlagen“ (Abschnitt 12): Modul `hl_engine.py`, Skript des Reiters
`hl_engine_js.py`, eigene Datei `engine.db` neben der Hauptdatenbank. Die Regeln aus Abschnitt 4 und 5 gelten unverändert; beim Bau
waren Einzelheiten festzulegen, die das Konzept offenließ. Sie stehen hier, bevor die Engine ein einziges Mal auf echten Daten lief:

1. **Abspielen statt Fortschreiben:** Bei jeder Rechnung (alle 10 min) spielt die Engine die Regeln Tag für Tag auf den Labor-Trades
   ab, je Prüfung nur mit den bis dahin geschlossenen. Jede Entscheidung seit dem Start steht zusätzlich im Protokoll (`engine.db`);
   fehlt eine gespeicherte Entscheidung in der Neuberechnung, melden Reiter und Bericht „Protokoll weicht ab“ (nichts wird still
   überschrieben). Entscheidungen vor dem Start heißen „Vorgeschichte“ (beschreibend; so steht die Engine am ersten Tag nicht leer da,
   wenn eine Strategie die Regeln schon erfüllt).
2. **Start:** 00:00 UTC am Tag nach dem ersten Schritt des Fadens „engine“ (120 s nach dem Start des Dashboards). Erste volle Woche einer
   Strategie: der erste Montag ab dem ersten vollen Tag nach dem Start ihrer Regelversion (bei den Strategien vom 27.09. der 28.09.).
3. **Tage und Wochen:** Ein Tag zählt an der ersten Prüfung um 00:30 UTC, zu der alle seine Trades geschlossen sind; die Tage zählen in
   der Reihe (ein offener Trade hält die folgenden Tage auf). Eine Woche wird am Dienstag 00:30 UTC nach ihrem Sonntag geprüft, wenn
   alle ihre Tage zählen, sonst am ersten Tag danach. Werden zwei Wochen zugleich fertig, prüft die Engine einmal mit der jüngeren.
4. **(B):** die letzten 17 Kalenderwochen bis zur geprüften Woche, darin mindestens 15 gültige; möglich ab der 17. Woche seit der ersten
   vollen Woche. (A) und (B) je mindestens 30 Trades in den gültigen Wochen.
5. **Ausfälle:** bekannt erst ab dem Einspielen. Der Faden schreibt alle 5 min einen Puls, solange der Takt des Labors fortschreitet;
   jede Lücke über 1 h macht jeden Tag, den sie berührt, zum Ausfalltag (er fehlt in der Überwachung und in der Summe seit einer Pause,
   seine Woche fällt aus den Tests). Ein Ausfall gilt erst ab dem Zeitpunkt, zu dem er bekannt war: 1 h nach dem Beginn der Lücke, auch
   während sie noch läuft. Eine Prüfung davor zählt den Tag noch -- im Echtzeit-Lauf wie beim späteren Abspielen (sonst wiche die
   Neuberechnung vom Protokoll ab). Vor dem Einspielen zählen alle Tage.
6. **Monatsart:** aus den BTC-Tageskerzen der Hauptdatenbank (`daily_bars`): Schluss des letzten Monatstags gegen den des letzten
   Tags des Vormonats. Fehlt einer der beiden Tage, ist der Monat unbekannt, ebenso bei gleichem Schluss (beides zählt weder als
   steigend noch als fallend). Bekannt ab 00:00 UTC am zweiten Tag nach dem Monatsende: Die Tageskerzen kommen alle 6 h, erst dann ist
   die letzte sicher endgültig. Für „gescheitert“ zählen die Tage der gültigen Wochen im Fenster. Ein Lesefehler bei den Kerzen bricht
   die Rechnung ab (sonst stünden Entscheidungen ohne Monatsart im Protokoll).
7. **Konto:** Trades in der Reihenfolge ihrer Eröffnung (bei Limit-Orders der Füllung), nur wenn die Strategie in diesem Moment aktiv
   ist (Zustand nach der letzten Prüfung um 00:30 UTC); realisiert beim Schließen im Labor. Die Grenzen zählen die offenen Positionen zum
   Eröffnungszeitpunkt; Ausgelassenes wird je Grund gezählt (Kapazität, Coin, Richtung). Füllt das Labor nach einem Ausfall eine
   Limit-Order nachträglich über die Kerzen, zählt sie, wenn die Strategie zum Füllzeitpunkt aktiv war (eine liegende Limit-Order
   wäre an der Börse ebenso gefüllt worden).
8. **Bremse:** geprüft täglich um 00:30 UTC auf dem realisierten Konto (Unrealisiertes kennt die Engine nicht), vor den Wochenprüfungen
   derselben Prüfung. Ausgelöst: alle aktiven Strategien pausieren (je ein Eintrag), keine Aufnahme, kein neuer Trade. Lösen nur von
   Hand (seit 23.94 der Button „Bremse lösen“ im Reiter, Punkt 17; in 23.93 war es Debug 142, ein Schalter mit Nachfrage), wirksam ab
   der nächsten Prüfung um 00:30 UTC: Der Kontostand gilt als neuer Höchststand (sonst griffe die Bremse sofort wieder); von der Bremse
   pausierte Strategien gelten als beobachtet und werden sofort nach (A)/(B) geprüft -- ohne Abkühlung, denn die Bremse ist kein Befund
   über die einzelne Strategie (das gilt auch, wenn eine von ihnen während der Bremse „gescheitert“ heißt; zurück dann nur über (B)).
   Wer vorher von der eigenen Überwachung pausiert wurde, behält seine Abkühlung. Beim Lösen prüft die Engine alle nicht aktiven
   Strategien einmal mit der zuletzt ausgewerteten Woche: Was die Bremse an Aufnahmen aufgehalten hat, kommt sofort statt erst am
   nächsten Dienstag (bis zu 6 Tage früher; Auslegung, von der Durchsicht gefragt, so belassen).
9. **Vergleich im selben Zeitraum:** realisiertes Netto der Trades, die seit dem Start eröffnet wurden, je Tag der Schließung: Labor
   gesamt (alle Strategien, je Strategie und Coin ein eigenes Konto), die Kandidaten ungefiltert, Halten Long.
10. **Rückkehr nach „gescheitert“:** Bei der Aufnahme über (B) fällt die Bezeichnung weg („zurückgekehrt am …“), das Fenster für
    „gescheitert“ beginnt mit der Woche danach.
11. **Rückblick (Debug 139):** dieselben Regeln mit dem Konto ab dem ersten vollen Tag des Labors, ohne gelöste Bremse; beschreibend.
12. **Proben (Abschnitt 9) umgesetzt:** Die Nullprobe rechnet 30 Welten (im schnellen Selbsttest für die Mutationen 12). „Phase … nicht
    gescheitert“ heißt im Test: höchstens 2 % der Welten (Abwärtsphase an den Tagen 200–319). Die Browser-Probe zeigt vier Stände statt
    drei (dazu die gesetzte Bremse).
13. **Regelversionen:** Ändert das Labor die Regeln einer Strategie, bekommt sie dort eine neue Kennung, die alte gilt nicht mehr als
    aktiv. Die Engine liest alle Versionen: Die alte endet mit dem Start der neuen und heißt an der ersten Prüfung danach „beendet“ (ein
    Eintrag im Protokoll; kein Trade und keine Prüfung mehr). Ihre übernommenen Trades bleiben im Konto, auch die noch offenen bis zu
    ihrem Schluss. Die neue Kennung beginnt beobachtet, mit eigener erster voller Woche. Im Betrieb zählen alte Versionen nur, wenn sie
    nach dem Start der Engine endeten. Der Reiter zeigt sie grau unter den aktuellen Zeilen, mit „(alte Regeln)“ am Namen.
14. **Hänger:** Ist ein Trade einer aktiven Strategie 72 h nach dem Ende seines Tages noch offen (etwa ohne Kurs für einen Coin), steht
    ihre Überwachung (nach Punkt 3 zählt kein weiterer Tag). Dann pausiert sie, ohne Abkühlung und ohne Aufnahme, bis der Tag zählt;
    danach heißt sie wieder beobachtet („Überwachung läuft wieder“) und wird bei der nächsten Wochenprüfung normal geprüft. Das Konzept
    hatte dafür keine Zeitgrenze (Lücke, von der Durchsicht gefunden).
15. **Grenze der Überwachung:** Pause, sobald die Summe die Grenze erreicht (S ≥ h, wie in Abschnitt 4). Die Grenze aus Siegmunds
    Näherung ist nie kleiner als 2; das greift erst bei k ≳ 1, also praktisch nie.
16. **Ohne Daten:** Liegt der Prüfzeitpunkt vor dem ersten Tag einer Strategie, rechnet die Engine nichts (statt abzustürzen).
17. **Button „Bremse lösen“ (seit 23.94, Wunsch des Nutzers 04.11. 02:57 statt Debug 142):** Er steht im Hinweis der Bremse oben im
    Reiter und erscheint nur, solange die Bremse gesetzt und noch kein Lösen vorgemerkt ist. Ein Klick öffnet eine Nachfrage auf der
    Seite (mit dem Zeitpunkt, ab dem es wirkt, und den Folgen); erst „Ja, Bremse lösen“ sendet, „Abbrechen“ sendet nichts. Der Server
    nimmt das Lösen nur per POST mit der Kopfzeile des Dashboards und der Kennung der Nachfrage an (GET 405), nur bei gesetzter Bremse
    und nur einmal (die Prüfung wiederholt sich in der Schreibsperre; ein zweiter Klick ergibt keinen zweiten Eintrag). Danach zeigt der
    Hinweis „Lösen vorgemerkt am …, wirkt mit der Prüfung am … (00:30 UTC)“ statt des Buttons, auch nach dem Neuladen und im Bericht:
    Die Vormerkung bestimmt die Engine beim Lesen aus den Einträgen in `engine.db` (der gespeicherte Stand wird dafür nicht mehr
    gelöscht). Rückgängig machen lässt sich ein Lösen nicht; deshalb die Nachfrage. Die Wirkung ist dieselbe wie bisher (Punkt 8).
    Debug 142 ist weggefallen, die Nummer bleibt reserviert; wer sie im Debug-Feld eingibt, bekommt den Hinweis auf den Button.

**Ergebnisse beim Bau (Sandbox, 04.11.2026; nach der Durchsicht vollständig wiederholt):**
- Selbsttest 38 von 38 (14 s; schnell 5 s): Rechnung von Hand (Tagessumme, vollständige Tage, Wochen dienstags, Ausfallwoche, t,
  Siegmund mit Untergrenze, Überwachung in Handelszeit mit Kappung, Bezug, Umfang 34, Monatsart auch mit fehlendem Monatstag, Ausfall
  aus dem Puls und kausal), Regeln an gebauten Fällen ((A) am Tag 64, Mindestzahl 30 Trades, (B) nach schlechten Wochen, Abkühlung
  30 Tage und Summe nur für (A), „gescheitert“ nur mit beiden Monatsarten und Hälften, nach „gescheitert“ kein (A), Rückkehr zählt neu),
  Konto (Kapazität, Coin, Richtung, Bremse, Bremse vor der Aufnahme, Hänger, Limit-Order nach der Füllung), Ende zu Ende über
  `abspielen` und über Dateien (Start, Puls mit Lücke, Protokoll, Abgleich, Bericht, Rückblick, Wechsel der Regelversion),
  Kausalität an drei Zeitpunkten.
- Nullprobe (30 Welten mit 34 Strategien ohne Vorsprung, echte Handelshäufigkeit, ein Markt je Welt): 0,27 grundlose Aufnahmen je Welt
  (7 von 30 Welten mit mindestens einer; Simulation 0,27 und 22,5 %), Ergebnis im Mittel 0,0 Punkte. Positivkontrolle (+0,30 %):
  288 von 300 aufgenommen, Median Tag 64; nach dem Ende des Vorsprungs pausiert im Median nach 20 Tagen. Rückkehr 99,7 % bzw. 99,0 %;
  Ruhe 4 von 297 pausiert; Phase 0,7 % „gescheitert“.
- Mutationen 28 von 28 rot (146 s), darunter alle 19 aus Abschnitt 9 und fünf zu den Befunden der Durchsicht (nur die aktuelle
  Regelversion gelesen, Bremse nach der Aufnahme, Ausfall vorausgesehen, Hänger übergangen, Monatsart ohne Vormonatstag).
- Dashboard-Selbsttest `hl_viz.py --selbsttest-engine` bestanden (Endpunkte, Kopf, fehlende und kaputte Datei, Skript, Seite, doppelte
  Namen, Dienst, Sicherung, Debug 138–142, Berichtsplan). Browser-Probe: vier Stände (leer, aktiv, Pause mit „gescheitert“ und einer
  beendeten Regelversion, Bremse) bei 1280 und 390 px ohne Befund (nach der Durchsicht wiederholt, 01:01–01:06); 9 Seiten-Mutationen
  rot.

**Nachtrag 23.94 (Button „Bremse lösen“, Sandbox 04.11.2026):**
- Selbsttest 39 von 39 (14 s): neu „Bremse lösen über Dateien“ -- nur bei gesetzter Bremse, nur einmal, bis zur Prüfung um 00:30 UTC
  vorgemerkt (die Bremse bleibt bis dahin gesetzt, der Bericht nennt die Vormerkung), dort gelöst mit dem Kontostand als neuem
  Höchststand. Mutationen 30 von 30 rot (167 s), neu „Lösen ohne Vormerkung“ und „Lösen ohne gesetzte Bremse“.
- Dashboard-Selbsttest `--selbsttest-engine` bestanden, neu: ohne Bremse abgelehnt; GET 405; POST ohne Kopfzeile oder ohne Nachfrage
  abgelehnt (kein Eintrag); mit beidem vorgemerkt und sofort im Stand; zweiter Klick ohne zweiten Eintrag; Debug 142 nicht mehr im
  Menü, Nummer reserviert, Hinweis auf der Debug-Seite. Vier Mutationen dieses Selbsttests rot (Server ohne Prüfung der Nachfrage, GET
  löst aus, Zwischenspeicher nicht verworfen, Debug 142 wieder im Menü).
- Browser-Probe (Playwright, 03:18:27–03:18:48 nach der letzten Änderung): vier Stände bei 1280 und 390 px ohne Befund; im Stand mit
  Bremse am PC Nachfrage geöffnet und abgebrochen (nichts gesendet), am Handy bestätigt (ein Eintrag, „Lösen vorgemerkt“ mit dem
  Zeitpunkt, Button weg, nach dem Neuladen ebenso); ohne Bremse kein Button. 14 Seiten-Mutationen rot (03:11:30–03:18:11), neu: Button
  auch ohne Bremse, Button ohne Nachfrage, Abbrechen sendet, ohne ja=1 gesendet, Button trotz Vormerkung.

**Eigene Fehler beim Bau** (alle vor dem ersten Lauf gefunden):
- Erster Entwurf: Bezugstag der Selbsttests als Montag kommentiert, war aber ein Donnerstag (01.01.2026); beim Nachrechnen gefunden.
- Erster Entwurf: acht Prüfungen hätten ihre Mutation nicht erkannt (ohne Abkühlung, Summe auch für (B), nach „gescheitert“ (A), ohne
  Mindestzahl, pausierte übernommen, Zukunft, Rückkehr mit alten Daten, ohne Hälften) -- die Fälle waren so gebaut, dass das Ergebnis
  mit und ohne Fehler gleich blieb. Vor dem ersten Mutationslauf durch gezielte Fälle ersetzt.
- Erster Entwurf: Schleifen je Strategie und Woche über die ganze Geschichte -- für die Proben zu langsam; vektoriell neu geschrieben.
- Bericht: Ein Tausenderpunkt über die ganze Zeile verwandelte die Kommas des Textes in Punkte („Trades. offen“; auch im Grund der
  Bremse); beim ersten Lesen des Berichts gefunden.
- Kontoverlauf: Rundung je Tag ließ die Summe um 1 USD vom Netto des Kontos abweichen (von der Browser-Probe gefunden); jetzt über die
  laufende Summe gerundet.

**Unabhängige Durchsicht des Codes** (04.11., fertig 00:46 nach der Dateizeit): Ein eigener Prüfer las `hl_engine.py` gegen die
Abschnitte 4, 5, 9 und 15 und rechnete jeden Befund mit kleinen Skripten nach, ohne am Projekt etwas zu ändern. Ergebnis: Die Regeln
aus Abschnitt 4 sind richtig umgesetzt (Kausalität der Trades, Kalender, (A) und (B), Abkühlung, Überwachung, „gescheitert“, Konto).
Mit dem Kalender aus echten Daten kam er auf dieselben frühesten Termine wie Abschnitt 7 (erste volle Woche 28.09., (A) frühestens
Di 01.12., „gescheitert“ frühestens Di 29.12., (B) ab 26.01.2027). Seine Befunde sind eigene Fehler beim Bau; alle vor dem ersten Lauf
behoben oder festgelegt, jeweils mit Probe und, wo möglich, Mutation:
- **Mittel -- Wechsel der Regelversion:** Die Engine las nur die aktuelle Version des Labors. Nach einer Regeländerung wären alle unter
  der alten Kennung übernommenen Trades aus Konto, Höchststand und Bremse verschwunden (nachgerechnet: Konto 121.147 USD → 100.000 USD),
  und der Abgleich hätte dauerhaft „Protokoll weicht ab“ gemeldet. Jetzt Punkt 13.
- **Klein -- Bremse erst nach der Aufnahme:** In derselben Prüfung wurde erst aufgenommen, dann von der Bremse pausiert (ohne Wirkung
  auf das Konto, aber drei Einträge zur selben Zeit). Jetzt vor den Wochen (Punkt 8).
- **Klein -- „gescheitert“ während der Bremse** löschte die Markierung „von der Bremse pausiert“; nach dem Lösen wäre die Strategie mit
  Abkühlung pausiert geblieben. Behoben (Punkt 8).
- **Klein, Auslegung -- Lösen prüft alle nicht aktiven Strategien:** so belassen und in Punkt 8 beschrieben.
- **Klein -- Monatsart bei fehlender Kerze:** Verglichen wurde mit dem letzten vorhandenen Tag des Vormonats; bei gleichem Schluss galt
  der Monat als fallend. Jetzt Punkt 6.
- **Klein -- Absturz ohne Daten** (Prüfzeit vor dem ersten Tag; im Betrieb nicht erreichbar): Punkt 16.
- **Verdacht -- Ausfall bis zu 1 h vorausgesehen:** Beim späteren Abspielen kannte die Engine die ganze Lücke schon; das hätte vom
  Echtzeit-Lauf abweichen können. Jetzt kausal (Punkt 5).
- **Verdacht -- Monatsart vor der endgültigen Kerze** (um 00:30 am Monatsersten ein vorläufiger Schlusskurs): jetzt erst ab dem zweiten
  Tag (Punkt 6).
- **Verdacht -- Lesefehler der BTC-Kerzen still übergangen:** In diesem Lauf hätte keine Strategie „gescheitert“ heißen können, und das
  Protokoll hätte es behalten. Jetzt bricht die Rechnung ab (Punkt 6).
- **Verdacht -- ein nie geschlossener Trade hält die Überwachung an,** die Strategie bliebe ohne Überwachung aktiv: Lücke der
  Spezifikation, jetzt Punkt 14.
- **Nebensächlich:** Pause bei „größer“ statt „erreicht“ (jetzt S ≥ h) und Untergrenze 2 der Grenze (beides Punkt 15); „90 Tage“ ist
  bei 13 gültigen Wochen immer erfüllt (Spanne mindestens 91 Tage) -- so belassen, die Bedingung schadet nicht.

## Quellen

- McLean, R. D., & Pontiff, J. (2016). Does Academic Research Destroy Stock Return Predictability? Journal of Finance 71(1).
  Zusammenfassung: https://rpc.cfainstitute.org/research/cfa-digest/2016/06/does-academic-research-destroy-stock-return-predictability-digest-summary
- Harvey, C. R., Liu, Y., & Zhu, H. (2016). … and the Cross-Section of Expected Returns. Review of Financial Studies 29(1), 5–68.
  https://www.nber.org/papers/w20592
- Bailey, D. H., & López de Prado, M. (2014). The Deflated Sharpe Ratio. Journal of Portfolio Management 40(5), 94–107.
  https://papers.ssrn.com/abstract=2460551
- Ehsani, S., & Linnainmaa, J. T. (2022). Factor Momentum and the Momentum Factor. Journal of Finance 77(3), 1877–1919.
  https://www.nber.org/papers/w25551
- Page, E. S. (1954). Continuous Inspection Schemes. Biometrika 41. Übersicht: https://en.wikipedia.org/wiki/CUSUM
- Howard, S. R., Ramdas, A., McAuliffe, J., & Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences.
  Annals of Statistics 49(2) – der allgemeine Weg zu Grenzen, die beliebig oft geprüft werden dürfen; hier stattdessen Schwellen, die für
  wöchentliche Prüfung über zwei Jahre simuliert sind. https://arxiv.org/abs/1810.08240
- Simulation: `sim.py` (Fassung 1), `sim2.py` (Fassung 2) und `sim3.py` (Fassung 3, Regeln der zweiten Durchsicht) im Arbeitsordner
  der Sitzung; Durchsichten mit eigenen Proben (`review.md`, `review2.md` und ihre Skripte).
