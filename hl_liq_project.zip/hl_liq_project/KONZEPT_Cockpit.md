# KONZEPT Cockpit (U245) — das Dashboard als Cockpit: Instrumente nur aus belastbaren Daten

Stand 11.11.2026, abends (Fable 5.2). Anlass: Wunsch des Nutzers vom 11.11. 20:58 — „Backup soll unter System verschoben
werden … Das Dashboard soll als Cockpit umgestaltet werden, weiterhin mit Zahlen, aber auch visuellen Indikatoren. Prüfe, welche
Daten aus dem ganzen Projekt zusätzlich belastbar sind.“ **Status: gebaut sind Stufe C0 (Paket 23.96: die Kacheln „Letztes Backup“ und „Datenbank“ im Abschnitt System) und die Stufen C0b und C1 (Paket 23.98, 12.11.2026: Cockpit oben auf der Hauptseite, Gruppen „Werkstatt“ und „Betrieb“; Abschnitt 9). Stufe C2 ist gebaut: die Karte „Kurs-Rechner“ (Paket 23.105, 16.11.2026; Abschnitt 13) und der Rest -- Funding (Hyperliquid) und Taker-Varianz in den Markt-Messwerten, Karte „Liquidationsdichte“, Betriebslampe (Paket 23.108, 17.11.2026; Abschnitt 14; dort auch die Berichtigung der Schwelle des API-Gewichts auf 93 %). Offen: C3. Berichtigung nach der ersten Prüfung auf echten Daten: Paket 23.99, Abschnitt 10 -- die 7-Tage-Spanne ist nicht „belegt“ im strengen Sinn. Seit Paket 23.100 (U254): Instrument „Unstaking“ bei ETH, Abschnitt 11. Seit Paket 23.104 (U260): Karte „Unstaking · Verlauf“ bei ETH, Abschnitt 12. Seit Paket 23.106 (U259) zeigt sie ab der eigenen Messung die angemeldeten Abzüge und markiert neue Wellen der zweiten Prüfung (Abschnitt 12).**
Grundlage: Paket 23.95, Sammeldatei und Debug 73 vom 11.11., `AUDIT_Gesamt_11-11-2026.md`, die Urteile in der Übergabe.
Entwurf (zwei Handy-Ansichten, Cockpit und System mit Backup; Werte vom 11.11., eckige Klammern = Wert in keinem Bericht):
https://claude.ai/artifact/TGq3YnxU1TQDzMAZ1FdWHR

---

## 0. Kurzfassung

- **Regel:** Ein Instrument im Cockpit bekommt nur, was belegt oder sauber gemessen ist. Jedes Instrument zeigt seinen Beleg.
- **Drei Klassen:** A belegt (vorab festgelegter Test bestanden) · B gemessen (verlässlicher Messwert, keine Vorhersage) ·
  C nicht belegt (bleibt in der Werkstatt, nie im Cockpit).
- **Ergebnis der Prüfung:** 9 Größen der Klasse A, 11 der Klasse B. *Berichtigt am 12.11. (Abschnitt 10): 8 Größen der Klasse A; die 7-Tage-Spanne (A2) hat einen belegten Vorsprung, ihre Gesamtprüfung S1 besteht aber nicht.* Drei belastbare Größen zeigt das Dashboard heute gar nicht als
  Anzeige: die Erreich-Wahrscheinlichkeit über 1 h und 4 h, die erwartete 4-h-Bewegung und die Kostenschwelle.
- **Kein Richtungspfeil im Cockpit.** Richtung ist über kein Fenster belegt (Audit, Debug 73).
- **Backup:** Die Kacheln „Letztes Backup“ und „Datenbank“ stehen heute in der Kennzahlenleiste zwischen Marktwerten. Sie
  wandern in den Abschnitt System, wo der Backup-Block (`#speicher`) seit 23.95 schon steht.

## 1. Heutiger Aufbau (23.95)

Eine Seite mit 23 einklappbaren Abschnitten: Live-Chart, Chartbild, Ausblick, Konfluenz, AI-Prognose, Treiberfamilien,
TradeLabor, Notbremse, Makro, Prognosemärkte, Volatilität, Orders, Heatmap, Momentaufnahme, Wale, Leaderboard (3), Aktive Profis,
Netzwerkstatus, Aktualisierung, Debug, System. Darüber eine Kennzahlenleiste, unter anderem mit 60-Minuten-Trend, MA 50 Wochen,
MA 200 Tage, Letztes Backup, Datenbank, Wal-Position, Wal-Flow, Leaderboard-Trend, Coinbase-Spot, Konfluenz.

Befund: Belegtes (Ausblick, Volatilität) und Unbelegtes (AI-Prognose, Konfluenz, Wal-Flow) stehen gleichrangig nebeneinander.
Die Kennzahlenleiste zeigt überwiegend Größen der Klasse C.

## 2. Prüfung: was belastbar ist

### Klasse A — belegt

| Nr. | Größe | Beleg | Im Dashboard heute |
|---|---|---|---|
| A1 | Niveau der Schwankung, 1–4 Wochen | V1 belegt 30.10. (p Holm 0,0292) | Abschnitt Volatilität |
| A2 | Spanne 7 Tage | S1: CRPS +1,5 % (p 0,002); 80-%-Band trifft BTC 84,0, ETH 80,4, HYPE 80,7, XMR 82,9, ZEC 79,0 %. **Berichtigung 12.11.: Die Gesamtprüfung S1 lautet „besteht nicht“ -- das Band von BTC liegt mit 84,0 % ± 1,7 außerhalb von 80 % ± 2 Standardfehler (zu weit). Belegt ist nur der Vorsprung gegen das Vergleichsmodell; siehe Abschnitt 10** | Abschnitt Ausblick |
| A3 | Erreich-Wahrscheinlichkeit von Kursen, 7 / 14 / 28 Tage | S3 besteht: Brier-Skill +6,2 / +3,7 / +1,5 %, Steigung 0,96 / 0,92 / 0,89 | Abschnitt Ausblick |
| A4 | Erreich-Wahrscheinlichkeit über 1 h und 4 h | Nullmodell von U110 an Zufallsniveaus, BTC 1 h: 1 σ 22,2 → 21,4 %, 2 σ 6,0 → 5,9 %, 3 σ 2,0 → 2,1 % | **nein** (nur im Testbericht) |
| A5 | Erwartete 4-h-Bewegung E\|r\| | Kriterium 5 (vorab 13.10.): Verhältnis 1,02 ± 0,05, n 1.390 in 232 Zeitblöcken | **nein** (nur im Fusion-Bericht und in einem Tooltip) |
| A6 | Hebel-Warnung H1 | Konten ≥ 3: Rücksetzer in 7 Tagen 20,3 % statt 7,3 %, p Holm 0,012; in 4 von 5 Fällen folgte keiner | Satz im Chartbild |
| A7 | Datentage | U154: Varianz in den 2 h nach CPI × 2,45, nach Arbeitsmarktbericht × 1,9 | Hinweis an Datentagen |
| A8 | Wochenende | Varianz Sa/So = 0,68 × Werktag (2.494 Tage) | in der Spanne eingerechnet |
| A9 | Kopplung an den S&P 500 | S4: Abhängigkeit belegt (p 0,003) | Szenarien im Ausblick |

Einschränkungen, die am Instrument stehen müssen:
- A2: Bei 14 Tagen ist der Vorsprung nicht belegt (+0,4 %, p 0,18), bei 28 Tagen keiner (−0,7 %). PAXG trifft nur 58–67 %.
- A3: Die Zahl folgt allein aus dem Abstand; die Niveau-Art prüft U244.
- A3, A4: seit Paket 23.105 für jeden eingetippten Kurs im Kurs-Rechner des Cockpits (Abschnitt 13) -- A4 war bis dahin nur im
  Testbericht zu sehen.
- A9: Unter Aktienstress ist die bedingte Verteilung nicht kalibriert (PIT p 0,014). Gezeigt wird die Kopplung, nicht das Szenario.

Aus A5 folgt rechnerisch die **Kostenschwelle** (nötige Trefferquote; BTC 11.11.: 4 h 58,9 % Taker / 52,9 % Maker, 24 h 53,5 /
51,1 %). Auch sie steht heute nur im Bericht und im Tooltip der Fusion-Kachel, auf dem Handy also gar nicht.

Die Perzentile der Klasse B rechnet das Chartbild schon (Mittelrang unter den letzten 90 Tagesständen, wie U142); das Cockpit
übernimmt diese Rechnung.

### Klasse B — gemessen

| Nr. | Größe | Anzeige | Vorbehalt |
|---|---|---|---|
| B1 | Kurs, Mark, Oracle, Prämie | Zahl | — |
| B2 | Funding Hyperliquid | Perzentil 90 Tage | Fremdbörsen erst nach U23 |
| B3 | Open Interest | Perzentil 90 Tage | — |
| B4 | Realisierte Schwankung 7 / 30 Tage, DVOL | Zahl neben A1 | DVOL als Zusatz nicht belegt (V4) |
| B5 | Kontenquote Binance | Skala mit Marke bei 3 | Schwelle = A6 |
| B6 | Liquidationsdichte nahe am Kurs | Balken ± 3 % | Abdeckung BTC 27 % des OI; 85 % der bekannten Positionen zu alt |
| B7 | Wartende Orders, Stops, Wände | Liste | Momentaufnahme, Konten ab 250k USD |
| B8 | Spread | Zahl | Buchtiefe erst nach N1 (heute nur 10 Stufen) |
| B9 | Varianz des Taker-Flusses | Skala, unterstes Dezil markiert | Vorläufer nur im Mittel, kein Einzelalarm |
| B10 | Termine: CPI, Arbeitsmarkt, Fed, Optionsverfall | Countdown | — |
| B11 | Betrieb: Dienste, API-Gewicht, Rückstand, Speicher, Backup | Lampe + Abschnitt System | — |
| B12 | Unstaking: angemeldete Abzüge aus dem Ethereum-Staking mit ihrem Zeitpunkt (seit 23.100, nur ETH) | Karte mit Kalender, Termin der nächsten großen Freigabe | Kurswirkung: vorab festgelegte Prüfung (U255, Debug 147, seit 23.101); ihr Urteil steht als Text in der Karte -- am 15.11.2026: nicht belegt, Wellen bis 25.10.2026 |
| B13 | Unstaking, Verlauf: Schlange der Abzüge und ETH-Kurs je UTC-Tag seit Mai 2023 (seit 23.104, nur ETH) | Karte mit zwei Feldern (Kurs, Schlange) und den Wellen der Prüfung als Marken | — (der Verlauf belegt nichts; darunter steht der Satz der Prüfung U255) |

### Klasse C — nicht belegt, nicht im Cockpit

AI-Prognose (P(aufwärts), Bias, „Konfidenz“, 7-Tage-Pfad, Kauf- und Verkaufspreis) · Konfluenz (49 % richtig bei 45 % Zufall,
n 35) · Smart Money, Elite, Wale, Leaderboard, Pool als Richtungsanzeiger (das Timing-Urteil der Darwin-Liste steht am 18.11. an)
· Heatmap als Magnet oder Anker · ETF-Flüsse und Makro-Zonen als Signal (3 von 322 Tests belegt, erwartet wären 16 aus Zufall) ·
Wahrscheinlichkeit einer „volatilen Woche“ (nicht besser als die Grundrate) · Szenarien unter Aktienstress · Kalendereffekte bei
XMR (kippen an der Holm-Grenze) · alles aus Labor und Engine, solange N1 offen ist.

Diese Abschnitte bleiben erhalten, unter „Werkstatt“, mit dem Vermerk „nicht belegt“.

## 3. Aufbau des Cockpits (Handy zuerst)

Von oben nach unten, ein Bildschirm je Block:

1. **Kopf:** Coin, Kurs, Datenalter, eine Betriebslampe (führt zu System).
2. **Risikoleiste, fünf Lampen:** Hebel (A6) · Termin (A7, B10) · Wochenende (A8) · Aktien (A9) · Schwankung (A1 als Perzentil).
   Jede Lampe: aus, gelb oder — nur wo ein Test es trägt — rot; beim Antippen der Beleg.
3. **Schwankung:** Bogen-Instrument mit der erwarteten Schwankung für 7 Tage und ihrem Perzentil gegen 365 Tage; daneben A5
   („in 4 h typisch ± x %“), realisierte 7 und 30 Tage, DVOL.
4. **Spanne:** waagrechter Balken 50 / 80 / 90 % für 7 Tage mit Kursmarke, darunter 14 Tage schmaler, 28 Tage als Rahmen.
   Beschriftung mit gemessener Trefferquote.
5. **Levels:** die nächsten Niveaus oben und unten, je mit Balken für 1 und 2 Wochen und dem Abstand in %; nach U244 die
   Bilanz der Art.
6. **Erreich-Rechner (neu, aus A4 und A3):** Kurs eintippen → Wahrscheinlichkeit, ihn in 1 h, 4 h, 7 und 14 Tagen zu erreichen.
   Gedacht für Stopps, Limits und den eigenen Liquidationspreis.
7. **Markt-Messwerte:** kleine Perzentil-Skalen für B2, B3, B5, B9; Liquidationsdichte B6 mit der Abdeckung daneben.
8. **Kosten:** nötige Trefferquote für 4 h und 24 h, Taker und Maker.
9. **Werkstatt** (alle heutigen Abschnitte der Klasse C, eingeklappt) und **System** (Backup, Datenbank, Speicher, Netzwerk,
   Aktualisierung, Debug).

## 4. Regeln für jedes Instrument

- **Beleg sichtbar:** eine Zeile unter dem Instrument, etwa „geprüft: 80-%-Band traf 84 % (Rückblick 08.11.)“.
- **Farbe nur für Klasse A.** Klasse B ist neutral (grau, blau) und zeigt das Perzentil; kein Grün/Rot im Sinn von gut/schlecht.
- **Keine Pfeile, keine Empfehlungswörter.** Die Liste der verbotenen Wörter aus Chartbild und Ausblick gilt.
- **Frische:** Ist die Quelle älter als ihre Grenze, wird das Instrument grau und nennt den Stand.
- **Nicht nur Farbe:** Jede Lampe trägt ein Wort; Zustände unterscheiden sich auch in der Form.
- **Zahlen bleiben.** Jedes Instrument zeigt seinen Zahlenwert; die Grafik ersetzt ihn nicht.
- **Schwellen fest und vorab:** H1 ab Kontenquote 3; Termin 24 h vor bis 2 h nach der Veröffentlichung; Schwankung gelb ab dem
  80., rot ab dem 95. Perzentil; Betrieb gelb bei API-Gewicht über 85 % oder Backup älter als 36 h, rot bei Dienst aus.
  **Berichtigt mit 23.108 (Abschnitt 14):** API-Gewicht ab 93 % des harten Limits -- der Recorder nutzt planmäßig 90 %; 85 % war
  mein Fehler im Entwurf.

## 5. Stufen

| Stufe | Inhalt | Paket |
|---|---|---|
| C0 | Kacheln „Letztes Backup“ und „Datenbank“ aus der Kennzahlenleiste in System, über den Speicherorten; ein Problem zeigt die Kopfzeile des Abschnitts auch zugeklappt („⚠ Backup“, „⚠ Datenbank“) | **gebaut mit 23.96** (Selbsttest Speicherorte S15, S16; Browserprobe bei 390 px) |
| C0b | Netzwerk, Aktualisierung, Debug und System als Gruppe „Betrieb“ | **gebaut mit 23.98** (mit C1; Abschnitt 9) |
| C1 | Cockpit als Startabschnitt aus vorhandenen Endpunkten (Ausblick, Volatilität, Chartbild, Termine, Fusion, System); nur lesend, keine neue Rechnung; alte Abschnitte darunter als Werkstatt | **gebaut mit 23.98** (Abschnitt 9; dazu aus C2 schon der Kostenblock und drei Messwerte) |
| C2 | Erreich-Rechner (A4, A3), Perzentil-Skalen für Funding und Taker-Varianz, Liquidationsdichte, Betriebslampe mit API-Gewicht und Diensten | **Kurs-Rechner gebaut mit 23.105** (Abschnitt 13); **der Rest gebaut mit 23.108** (Abschnitt 14) |
| C3 | nach N1, U23 und U244: Buchtiefe und Impact, Funding-Spread, Bilanz der Niveau-Art | später |

## 6. Proben

1. Abgleich: Jede Zahl im Cockpit ist gleich der Zahl im Quellbericht desselben Zeitpunkts (Ausblick, Volatilität, Fusion).
2. Frische: Quelle künstlich gealtert → Instrument grau mit Stand.
3. Browserprobe bei 360 bis 430 px Breite und am Desktop; kein waagrechtes Scrollen.
4. Wortprobe: keine Empfehlungswörter, kein Pfeil.
5. Mutation je Lampe: Schwelle verschoben → Probe schlägt an.
6. Der Erreich-Rechner trifft an Zufallsniveaus die Quoten von U110 (Positivkontrolle) und liefert für den aktuellen Kurs 100 %.
   *Seit 23.105 gebaut:* Vertragsprobe „Stunden“ auf einem Probe-Markt; der jetzige Kurs steht als „erreicht“ da (Abschnitt 13).

## 7. Entscheidungen beim Nutzer

**Entschieden am 12.11.2026 gegen 01:00 (Auswahl zum Anklicken, nach der Frage des Nutzers von 00:55 „aber das cockpit ist noch nicht umgesetzt?“):** Punkt 1 „Oben auf der Hauptseite“, Punkt 2 „Ein Coin groß + Streifen“, Punkt 3 „In die Werkstatt“, Punkt 4 „Ja, auf meinem Gerät merken“ -- jeweils der Vorschlag. Punkt 5 hat die Frage des Nutzers beantwortet: das Cockpit zuerst, vor U244.

Stand 11.11. 21:36 (überholt): Der Nutzer antwortete auf dieses Konzept mit „Ok“ und fragte nach dem Paket. Das „Ok“ war keine Einzelantwort auf die fünf Punkte.

1. **Ort:** Cockpit als Startabschnitt derselben Seite, alte Abschnitte eingeklappt darunter? Vorschlag: ja.
2. **Coins:** ein Coin groß, dazu ein Streifen mit allen sechs (Spanne 7 Tage und Lampen)? Vorschlag: ja.
3. **Unbelegtes:** AI-Prognose, Kauf- und Verkaufspreis, Konfluenz und die Kacheln zu Walen aus der Hauptansicht nehmen und nur
   in der Werkstatt zeigen? Vorschlag: ja.
4. **Erreich-Rechner** mit eigenem Liquidationspreis als festem Eintrag? Vorschlag: ja, lokal im Browser gespeichert.
5. **Reihenfolge:** C0 mit 23.96, C1 und C2 als eigenes Paket danach, vor oder nach U244? Vorschlag: C1 und C2 vor U244 — das
   Cockpit braucht keine neue Studie.

## 8. Abgrenzung

- Das Cockpit rechnet nichts Neues außer dem Erreich-Rechner und den Perzentilen. Es ändert keine Prognose, kein Urteil, kein
  Labor.
- Was heute Klasse C ist, kann aufsteigen: Ein bestandener, vorab festgelegter Test macht aus einer Werkstatt-Größe ein Instrument
  (zum Beispiel eine Niveau-Art nach U244 oder der Rücklauf nach Liquidationswellen nach U204).

## 9. Bau der Stufen C0b und C1 (Paket 23.98, 12.11.2026)

**Was gebaut ist**
- Neues Modul `hl_cockpit.py` (liest nur, Endpunkt `/cockpit?coin=…`) und `hl_cockpit_js.py` (Skript `/cockpit.js`). Abschnitt
  „CK Cockpit“ als erster Abschnitt der Hauptseite: Kopf mit Kurs und Betriebs-Pille, Streifen mit sechs Coins, Kernsatz, fünf
  Lampen, Schwankung, Spannen, Levels, Messwerte, Kosten, Sprünge zu Werkstatt und Betrieb.
- Ordnung der Seite in `hl_cockpit.seite_ordnen`: Hauptansicht (Live-Chart, Chartbild, Ausblick, Volatilität, Notbremse, Makro,
  Prognosemärkte, Orders, Heatmap, Momentaufnahme), Gruppe „Werkstatt · nicht belegt“ (Kennzahlenleiste, Konfluenz, AI-Prognose,
  Treiberfamilien, TradeLabor, Wale, Leaderboard dreifach, Aktive Profis), Gruppe „Betrieb“ (Netzwerk, Aktualisierung, Debug,
  System). Beim ersten Laden je Browser werden die bisherigen Abschnitte einmal eingeklappt.
- Debug 143 (★ Cockpit: Stand je Coin als Text) und 144 (Selbsttest).

**Festlegungen beim Bau (neu, fest und vorab)**
- **Lampe „Aktien“:** Abschnitt 4 nannte für sie keine Schwelle. Festgelegt: Sie zeigt die Ausnahmelage (c) des Ausblicks
  (`hl_ausblick.schock_pruefen`: S&P-500-Perp in 6 h über 3 typische Bewegungen; gilt 24 h) -- eine Regel, die es schon gab. Für
  PAXG gilt sie nicht. Die Ausnahmelagen (a) und (b) des Coins selbst stehen als Zeile unter dem Kernsatz.
  - „Aus“ zeigt die Lampe nur, solange die Regel nachweislich geprüft wird -- dieselben Bedingungen wie in `schock_pruefen`: Basis
    `FS1` vorhanden, mindestens 12 Kerzen der Reihe `xyz:SP500:30m` in den letzten 8 h, die letzte jünger als 2 h; dazu: letzte
    Rechnung des Ausblicks jünger als 3 h (die Prüfung läuft in seinem Takt). Sonst ist sie grau und nennt den Grund. Anlass: Die
    Notbremse lief knapp drei Wochen ohne XMR, weil ein fremd betriebener Markt verschwunden war und nichts es meldete (23.97); fiele
    der S&P-500-Perp aus, stünde die Lampe sonst für immer auf „aus“.
  - Grau ist sie auch, solange für den Coin eine Ausnahmelage (a) oder (b) gilt (`schock_pruefen` setzt (c) dann nicht), und für
    einen Coin, der in der Basis der Regel fehlt (keine Rechnung des Ausblicks für ihn).
- **Ohne Quelle kein „aus“** (gilt für alle Lampen): ohne Kontenquote, ohne bekannten kommenden Termin, ohne geprüfte Aktien-Regel,
  mit Tageswerten der Schwankung, die älter als 3 Tage sind, ist die Lampe grau. Nur „Wochenende“ kommt ohne Quelle aus (Uhr).
- **Lampe „Termin“:** 24 h davor Hinweis; von der Veröffentlichung bis 2 h danach Warnung, aber nur, wenn die Datentage-Studie für
  diese Reihe „belegt“ meldet -- sonst bleibt es beim Hinweis. Erzeugerpreise und Erstanträge lösen nichts aus (die Studie führt
  sie nur beschreibend, ohne Urteil).
- **Lampe „Schwankung“:** Perzentil der erwarteten Schwankung (erste Woche des Modells, das auch der Abschnitt „Volatilität“
  zeigt) gegen die realisierte 7-Tage-Schwankung der letzten 365 Tage. Farbe nur mit Urteil V1 „belegt“ und nur für die Prognose; gibt es keine frische Prognose, zeigt die Lampe
  das Perzentil der realisierten Schwankung neutral.
- **Levels:** Die Wahrscheinlichkeiten gelten ab dem Anker der Rechnung. Ein Niveau, das der Kurs seither durchlaufen hat, wird
  nicht mehr gezeigt, nur gezählt; die Abstände zählen zum jetzigen Kurs.
- **Vermerk an der Spanne** (*berichtigt mit 23.99, Abschnitt 10*): immer die gemessene Trefferquote des Coins („traf x %“), mit
  „(zu eng)“ oder „(zu weit)“ außerhalb von 80 % ± 2 Standardfehler, wie im Ausblick. Vorsprung je Horizont und das Urteil der
  Gesamtprüfung S1 stehen in der Zeile darunter. Bis 23.98 stand „traf x %“ nur, wenn die Gesamtprüfung bestand -- auf dem Pi
  also nie.

- **Stand an jedem Instrument:** Kurs und Messwerte mit Uhrzeit („live“) oder UTC-Tag (Tagesstand, Funding-Druck); Schwankung mit
  dem Tag der Tageswerte und dem der Prognose; Spanne und Levels mit der Zeit der Rechnung (älter als 2 Tage: blass); Kosten mit
  Zeit und Fenster; im Detail der Lampen „Stand der Quelle“.

**Abweichungen vom Entwurf**
- Aus Stufe C2 vorgezogen: der Kostenblock und drei Messwerte (Open Interest, Kontenquote mit Perzentil, Funding-Druck als z-Wert).
  Taker-Varianz, Liquidationsdichte und das Perzentil des Hyperliquid-Fundings fehlen noch.
- Die Betriebs-Pille zeigt dieselben Meldungen wie die Kopfzeile des Abschnitts System (Backup fehlgeschlagen oder Ziel
  ungeeignet, Backup älter als 50 Stunden, Platz am Backup-Ziel, Datenbank beschädigt) und nur die Stufe „Hinweis“. Die
  Betriebslampe nach Abschnitt 4 (Backup älter als 36 h, API-Gewicht über 85 %, Dienst aus = rot) kommt mit C2.
- Der Kopf zeigt den Kurs aus der jüngsten Minutenkerze des Recorders (Mark, Oracle und Prämie stehen weiter im Live-Chart).
- Die Lampe „Wochenende“ ist als Messwert geführt (blau), nicht als Klasse A wie in der Tabelle von Abschnitt 2 (A8): Der Faktor
  0,68 stammt aus einer Datenprobe der Volatilität (Prüfung vor dem Urteil), nicht aus einem Test mit Urteil.
- Die Regeln des Cockpits gelten für den Abschnitt Cockpit. Die Abschnitte der Hauptansicht darunter sind unverändert; der
  Live-Chart zeigt weiter seine Marken und Zonen (darunter FVG mit den Wörtern „bullisch“ und „bärisch“). Darüber ist nichts
  entschieden.

**Proben (Abschnitt 6):** 1 Abgleich und 2 Frische in `hl_cockpit.py --selbsttest` (dazu der Vertrag mit den Modulen auf deren
Demo-Datenbanken); 3 Browserprobe bei 360, 390 und 430 px und am Desktop beim Bau (kein waagrechtes Scrollen, keine Fehler);
4 Wortprobe im Selbsttest von Modul und Skript; 5 Mutationen beim Bau (jede Lampe an ihrer Schwelle); 6 entfällt bis C2.

## 10. Erste Prüfung auf echten Daten und Berichtigung (Debug 143 vom 12.11.2026 16:18 UTC; Paket 23.99)

Der Nutzer hat 23.98 eingespielt und Debug 143 geschickt (Laufzeit 4,2 s für sechs Coins).

**Stimmt mit den Quellen überein:** Kosten BTC 4 h 58,9 / 52,9 % und 24 h 53,5 / 51,1 % (gleich dem Fusion-Bericht vom 11.11.);
die Aktien-Regel wird geprüft (letzte Kerze des S&P-500-Perp 15:00 UTC, letzte Rechnung des Ausblicks 16:06 UTC); nächster Termin
Arbeitsmarktbericht (laut Kalender der BLS am 04.12.2026, die Verbraucherpreise am 10.12.2026:
https://www.bls.gov/schedule/2026/12_sched.htm); PAXG mit drei grauen Lampen, wie beschrieben. Hebel-Lampe an bei BTC
(Kontenquote 3,20) und ETH (3,59).

**Zwei Fehler des Cockpits, mit 23.99 behoben**
1. **Vermerk an der 7-Tage-Spanne: „Vorsprung offen“ bei allen Coins.** Der Vermerk hing an der Gesamtprüfung S1 des Ausblicks. Die
   verlangt den Vorsprung (p < 0,05) *und* die Deckung von BTC und ETH in 80 % ± 2 Standardfehler. Auf dem Pi (Debug 73 vom 11.11.):
   7 Tage Gewinn +1,5 %, p 0,002, aber BTC 84,0 % ± 1,7 -- „besteht nicht“. Am Balken stand deshalb „Vorsprung offen“, in der Zeile
   darunter „schlägt das einfache Vergleichsmodell (p 0,002)“. Jetzt: Der Balken trägt immer die gemessene Trefferquote des Coins
   („traf 84 % (zu weit)“), der Kernsatz nennt sie, die Zeile darunter nennt Vorsprung je Horizont, das Urteil der Gesamtprüfung und
   seinen Grund.
2. **Perzentil gerundet:** ZEC zeigte „80. Perzentil“ und die Lampe „aus“ (0,796). Jetzt wird abgeschnitten; Zahl und Lampe können
   sich nicht mehr widersprechen (geprüft über alle Mittelränge für 60 bis 365 Werte).

Dazu: Der Debug-Text nennt den Zeitpunkt des nächsten Termins und den Beleg der Spanne.

**Berichtigung dieses Konzepts (mein Fehler vom 11.11.):** Die Tabelle der Klasse A führte die 7-Tage-Spanne (A2) als „belegt“. Das
stimmt so nicht. Belegt ist der *Vorsprung* des Fächers gegen das Vergleichsmodell bei 7 Tagen (CRPS +1,5 %, p 0,002). Die vorab
festgelegte *Gesamtprüfung* S1 besteht bei keinem Horizont -- bei 7 Tagen, weil das Band von BTC etwas zu weit ist. Das stand in
Debug 73 („-> besteht nicht“) und seit Oktober im README („Breite S1 besteht bei keinem Horizont“); ich habe die Zahlen übernommen
und das Urteil nicht. Folgen:
- Klasse A im strengen Sinn (vorab festgelegter Test bestanden) hat 8 Größen, nicht 9. Die Spanne bleibt das zentrale Instrument,
  aber mit dem Etikett, das stimmt: Trefferquote je Coin gemessen, Vorsprung bei 7 Tagen belegt, Gesamtprüfung nicht bestanden.
- Für BTC ist das 80-%-Band eher zu weit (traf 84 %), für PAXG deutlich zu eng (traf 67 %; bei 28 Tagen 58 %) -- bei PAXG ist das
  Risiko größer, als das Band zeigt. Für ETH, HYPE, XMR und ZEC liegt die Trefferquote in der Toleranz (79 bis 83 %).
- Die Erreich-Wahrscheinlichkeiten der Levels (A3, Prüfung S3) bestehen bei allen drei Horizonten; daran ändert sich nichts.

**Warum die Probe es nicht fand:** Die Probe-Welt des Selbsttests trug für 7 Tage ein erfundenes „besteht: True“. Der Vertragstest
lief auf der Demo-Datenbank ohne Rückblick. Jetzt trägt die Probe-Welt die Zahlen und Urteile des Pi aus Debug 73, und der
Vertragstest erzeugt S1 mit `hl_ausblick.urteil_s1` selbst -- einmal so, dass das Modul „besteht nicht“ urteilt.

**Beobachtungen, nichts geändert**
- Die Wahrscheinlichkeit eines Levels gilt ab dem Anker der Rechnung (bis zu 30 Minuten alt), der Abstand zum jetzigen Kurs. Nach
  einer schnellen Bewegung passen beide nicht mehr zusammen (XMR 12.11.: Level +1,0 % über dem Kurs mit 99 % -- vom Anker aus
  waren es +0,2 %). Der Kurs-Rechner (Stufe C2) rechnet vom jetzigen Kurs.
- Die Kerzen des S&P-500-Perp kommen alle 30 Minuten und nur abgeschlossen; die jüngste ist 50 bis 80 Minuten alt. Bis zur Grenze
  von 2 Stunden bleibt Luft für einen ausgefallenen Abruf, nicht für zwei.

## 11. Instrument „Unstaking“ bei ETH (Paket 23.100, U254; Wunsch des Nutzers vom 14.11.2026)

Der Nutzer hat beobachtet, dass auf große Abzüge aus dem Ethereum-Staking häufig Kursrückgänge folgen, und einen Indikator mit Termin
verlangt. Einzelheiten, Quellen und die vorab festgelegte Studie: `KONZEPT_Unstaking.md`.

- **Klasse B (gemessen), Nummer B12.** Die Zeitpunkte der Abzüge stehen in der Kette; das Cockpit rechnet nichts hinzu außer Summe je
  Tag, Anteil am Tagesdurchsatz, Anteil des größten Abziehers und dem Wert in USD zum frischen Kurs.
- **Anzeige, nur bei ETH:** Karte „Unstaking“ zwischen Messwerten und Kosten; dazu eine Zeile mit dem Termin der nächsten großen
  Freigabe unter dem Kernsatz. Für die anderen Coins gibt es das Instrument nicht.
- **Schwellen, fest und vorab:** großer Tag ab 28.800 ETH „frei ab“ (die Hälfte des Höchstdurchsatzes von 57.600 ETH am Tag);
  Abzieher genannt ab 10.000 ETH; Stand des Knotens höchstens 3 Stunden alt, Tagesdatei als Ersatz höchstens 2 Tage.
- **Farbe:** blau wie alle Messwerte. Keine Lampe, keine Warnfarbe. Große Tage unterscheiden sich in der Form (fett, höherer
  Balken, Punkt).
- **Prüfung der Kursfolge (seit 23.101, U255):** Unter dem Termin steht die Zeile „Folgt darauf ein Kursrückgang?“ mit dem
  gespeicherten Urteil der vorab festgelegten Prüfung -- „Noch nicht geprüft“ mit der Debug-Nummer 147, oder Datum und Wortlaut
  („nicht belegt“, „belegt …“, „zu wenige Fälle“). Der Beleg der Karte nennt Fallzahlen und Nachweisgrenze. Das Cockpit rechnet hier
  nichts; auch „belegt“ bleibt Text ohne Farbe, bis die Lampe eigens festgelegt ist. Seit 23.102 nennen Zeile und Beleg den letzten
  bewerteten Tag („Geprüft am 15.11.2026 (Wellen bis 25.10.2026): nicht belegt.“) -- damit niemand eine Welle für geprüft hält, die
  nicht in den Daten war.
- **Stehengebliebene Tagesdatei (seit 23.102):** Fehlt die Gegenseite, weil die Tagesdatei der Quelle älter als 2 Tage ist, steht in
  der Karte „Gegenseite …: zurzeit kein Wert, weil die Tagesdatei der Quelle am … endet.“ statt nichts. Die Dauer des
  Auszahlungslaufs nennt dann den Tag, von dem die Zahl der Validatoren stammt. Der alte Wert der Gegenseite wird nicht gezeigt.
- **Ohne Quelle kein Wert:** Fehlt der Stand, ist die Karte blass und nennt den Grund; ein Ersatz aus der Tagesdatei trägt den
  Vermerk „geschätzt“.
- **Aufstieg zu Klasse A** nur über die Studie U255 (`KONZEPT_Unstaking.md` 6, 6a und 6b). Erster Lauf am 15.11.2026: nicht belegt
  -- das Instrument bleibt Klasse B. Bei „belegt“ in einer späteren Prüfung: eigene Lampe und ein Platz in der Prognose, eigens
  festzulegen.
- **Proben:** Abgleich und Schwellen in `hl_cockpit.py --selbsttest`, Vertrag mit `hl_staking` auf einer vom Modul gefüllten
  Datenbank; Zeichnung in `hl_viz.py --selbsttest-cockpit`; Browser-Probe bei 360 bis 1280 px; Mutationen beim Bau.
- **Abruf vom Pi aus:** gelingt (Debug 145 vom 15.11.2026: Knoten 4,9 MB in 1,5 s). Die Tagesdatei kommt an, endet aber am
  25.10.2026 (`KONZEPT_Unstaking.md` 3a).

## 12. Karte „Unstaking · Verlauf“ bei ETH (Paket 23.104, U260; Frage des Nutzers vom 15.11.2026)

Der Nutzer fragte nach dem Einspielen von 23.103: „Wo sehe ich den Chart mit dem Unstaking?“ Die Karte „Unstaking“ zeigt den Stand
und die nächsten Tage; einen Verlauf über die Zeit gab es nicht. Auf die Frage, ob er dazukommen soll, wählte er „Ja, bauen“.
Einzelheiten: `KONZEPT_Unstaking.md` 4a.

- **Klasse B (gemessen), Nummer B13.** Schlange der Abzüge und ETH-Kurs je UTC-Tag seit Mai 2023. Das Cockpit rechnet nichts hinzu
  außer der Lage je Tag, Rundung und den Zeiträumen ohne Daten.
- **Anzeige, nur bei ETH:** eigene Karte zwischen „Unstaking“ und „Kosten“ -- zwei Felder mit gemeinsamer Zeitachse (Kurs oben,
  Schlange unten, ab null), **keine zweite Skala in einem Feld**; Ausschnitt 3 Monate, 1 Jahr (beim Öffnen) oder alles; graue Fläche,
  wo die Schlange drei Tage oder länger fehlt.
- **Wellen der Prüfung als Marken:** die Fälle des gespeicherten Urteils (U255), nicht neu bestimmt. Antippen zeigt den Tag mit
  Schlange und Kurs; nahe einer Marke den Satz der Welle. Dazu die Wellen des Ausschnitts als aufklappbare Liste mit den Zahlen aus
  Debug 147.
- **Seit 23.106 (U259):** Ab dem Beginn der eigenen Messung zeigt das untere Feld die **angemeldeten Abzüge, die noch nicht frei
  sind** (Schlange + Sperrfrist + Teilabzüge) -- Feldname, Quellenzeile und Ablesezeile („Angemeldet“) sagen es. Grund und Regel:
  `KONZEPT_Unstaking.md` 6c. **Neue Wellen** der zweiten Prüfung tragen einen offenen Kreis und eine eigene Nummer (N1 …); ihr
  Text und ihre Zeile in der Liste nennen Tag und Zuwachs, **keine Kursfolge**. Die Legende zählt beide Arten getrennt; der
  Satz unter dem Bild nennt den Zähler („bisher x“) und den frühesten Tag einer neuen Welle. Form statt Farbe: voller Kreis =
  Welle der Prüfung, offener Kreis = neue Welle.
- **Kein Urteil in der Karte außer dem gespeicherten:** Unter dem Bild steht der Satz der Prüfung (Mittel nach den Wellen, Mittel
  aller Tage, „nicht belegt“ mit p nach Holm) und „Der Verlauf allein belegt keinen Zusammenhang.“ Keine Lampe, keine Warnfarbe, kein
  Pfeil -- auch nicht bei „belegt“.
- **Farben der Linien:** Schlange `#388bfd`, Kurs `#bb8009` -- die nächsten dunkleren Stufen des Blau und des Gelb des Cockpits, weil
  diese für zwei Linien auf der Kartenfläche zu hell sind (geprüft: Helligkeit, Unterscheidbarkeit bei Farbsehschwäche, Kontrast).
  Text trägt nie die Farbe einer Linie; Marken und Kreuz sind neutral grau.
- **Daten:** `/cockpit/unstaking` (`hl_cockpit.verlauf_nutzlast` aus `hl_staking_studie.verlauf`), 10 min im Zwischenspeicher; das
  Skript holt sie nur bei ETH, nach dem Cockpit, und frühestens nach 30 min wieder. Debug 143 nennt den Umfang unter ETH.
- **Ohne Quelle kein Bild:** Fehlt `staking.db` oder hat sie noch keinen Tag, ist die Karte blass und nennt den Grund; fehlt nur der
  Kurs, bleibt die Schlange und der Grund steht darunter.
- **Proben:** Antwort und Texte in `hl_cockpit.py --selbsttest`, Vertrag mit `hl_staking_studie`; Endpunkt und Zeichnung in einem
  nachgebauten Dokument in `hl_viz.py --selbsttest-cockpit`; Browser-Probe bei 360 bis 1280 px; Mutationen beim Bau.

## 13. Karte „Kurs-Rechner“ (Paket 23.105, U245 Stufe C2 -- erster Teil; Wahl des Nutzers vom 16.11.2026)

Am 16.11.2026 lag die Sammeldatei des Pi vor (dort lief noch 23.103). Auf die Frage zum Anklicken, woran inzwischen gearbeitet werden
soll, wählte der Nutzer „Kurs-Rechner bauen“ (der Vorschlag). Den festen Eintrag für den eigenen Liquidationspreis, nur im Browser
gemerkt, hatte er am 12.11. entschieden (Abschnitt 7 Punkt 4).

**Was die Karte zeigt** (bei jedem Coin, zwischen „Levels“ und „Markt-Messwerte“; Klasse A: A3 und A4)
- **Ein Kurs wird eingetippt** („61.500“, „65,39“; Eingabetaste oder „Rechnen“). Die Karte zeigt für ihn vier Zahlen: die
  Wahrscheinlichkeit, dass er **vom jetzigen Kurs aus** in 1 Stunde, in 4 Stunden, in 7 Tagen und in 14 Tagen **mindestens einmal
  berührt** wird -- je Frist Balken und ganze Prozent. Unter 0,5 % steht „unter 1 %“, ab 99,5 % „über 99 %“; 0 % und 100 % stehen nie
  da. Der jetzige Kurs selbst heißt „erreicht“.
- **Merken:** bis zu 6 Kurse je Coin unter einem von vier Namen -- Liquidation, Stopp, Limit, Marke. Sie liegen nur in diesem Browser
  (`localStorage`, Schlüssel `ck_rechner_v1`). Zum Rechnen gehen sie an das eigene Dashboard und werden dort nicht gespeichert (kein
  Zwischenspeicher, kein Protokoll). Die Namen sind Namen des Nutzers: Das Cockpit kennt keine Position.
- **Darunter** die Kurzfassung des Belegs; aufklappbar „Beleg und Grenzen“ mit den Einzelheiten und dem Stand der Rechnung.
- **Keine Wertung:** keine Warnfarbe, kein Pfeil, keine Empfehlung. Die Zahl folgt allein aus Abstand und Schwankung -- nicht aus der
  Art des Niveaus (das prüft U244) und nicht aus einer Richtung (die ist für kein Zeitfenster belegt).

**Rechnung** (beim Bau vorab festgelegt; gerechnet wird auf dem Server unter `/cockpit/rechner`, `hl_cockpit.rechner_nutzlast`)
1. **1 und 4 Stunden (A4):** das Nullmodell des Magnet-Tests U110, `hl_kaskade.p_ueber(|ln(Kurs ÷ jetzt)|, c, σ, τ)`. c und τ je Coin
   und Frist kommen aus der letzten Rechnung des Magnet-Tests (Prognosespeicher, nur gelesen; höchstens 3 Tage alt, nur aus der
   geltenden Modellversion). σ ist die Schwankung über 4 Stunden aus den 15-Minuten-Renditen der letzten 7 Tage (`hl_anker.Markt`,
   wie im Magnet-Test), mal √(h ÷ 4) -- über 1 Stunde also die Hälfte.
2. **7 und 14 Tage (A3):** die Verteilung des laufenden Hochs (Kurs über dem jetzigen) oder Tiefs (Kurs darunter) aus der jüngsten
   Rechnung des Ausblicks, **angelegt am jetzigen Kurs**. Der Ausblick legt sie seit 23.105 je Coin ab (`au_meta` „lauf“: 199
   Quantile von 0,5 % bis 99,5 % je Horizont und Seite, dazu Anker, Kurs und Zahl der Fenster N der Rechnung; rund 76 kB für sechs
   Coins). Sie steht bewusst nicht in `au_prognose`: Die Zeilen der 6-Stunden-Anker bleiben dort für immer. Aus den Quantilen ergibt
   sich dieselbe Zahl wie aus der vollen Rechnung `erreichen()` auf höchstens 0,5 Prozentpunkte + 1/N; jenseits des Rasters ist nur
   die Schranke bekannt („unter 1 %“, „über 99 %“). Die Rechnung darf höchstens 2 Tage alt sein.
3. **Eine längere Frist ist nie unwahrscheinlicher als eine kürzere.** Stunden und Tage rechnen mit getrennten Modellen; wo die
   längere Frist weniger ergäbe, gilt der Wert der kürzeren. Ändert das die gezeigte Zahl, steht ein Vermerk beim Kurs.
4. **Der jetzige Kurs** ist die jüngste Minutenkerze des Recorders und gilt 5 Minuten als frisch. Ohne frischen Kurs rechnet der
   Rechner nicht.
5. **Bereich:** ein Fünftel bis das Fünffache des jetzigen Kurses; höchstens 8 Kurse je Anfrage.
6. **Vermerk „nicht geprüft“:** bei den Stunden jenseits von 3 üblichen Schwankungen der Frist (die Zufallsniveaus des Magnet-Tests
   reichen bis 3 σ), bei den Tagen jenseits von 30 % Abstand (die Prüfung S3 des Ausblicks umfasst Prüfniveaus bis zum Zweifachen der
   Schwankung der Frist und Swing-Niveaus bis 30 %). Die Zahl steht trotzdem da.
7. **Hinweis „ungenauer“:** wenn bei der Probe des Nullmodells an Zufallsniveaus mehr als einer von acht Abständen außerhalb von 2
   Standardfehlern lag (am 11.11.2026 bei HYPE über 1 Stunde: 5 von 8 innerhalb).
8. **Hinweis zur Trefferquote des Bands:** Die Prüfung S3 der Erreich-Wahrscheinlichkeiten läuft über alle Coins zusammen. Je Coin
   gemessen ist die Trefferquote des 80-%-Bands (Rückblick S1, wie an der Karte „Spanne“). Liegt sie für den Coin außerhalb von 80 %
   ± 2 Standardfehler, steht bei den Tagen ein Hinweis mit der Folge: zu eng -- der Kurs verließ das Band öfter als erwartet, die
   Wahrscheinlichkeiten können zu niedrig sein (am 11.11.2026 bei PAXG: 67 % über 7 Tage, 66 % über 14 Tage); zu weit -- sie können
   zu hoch sein (BTC: 84 % und 85 %). Die Zahlen selbst werden nicht verändert.
9. **Ohne Quelle kein Wert:** Fehlt das Nullmodell einer Frist, die Schwankung oder die Verteilung, bleibt genau diese Frist leer
   („—“) und der Grund steht da. Nichts wird geschätzt.

**Belege, wie die Karte sie nennt**
- Stunden: die Probe des Nullmodells an Zufallsniveaus je Frist („1 h 8 von 8, 4 h 8 von 8 innerhalb von 2 Standardfehlern“), die
  Schwankung über 4 Stunden, das Alter der Rechnung. Am 11.11.2026 (Debug 51): BTC über 1 Stunde 1 σ 22,2 % vorhergesagt, 21,4 %
  eingetreten.
- Tage: der Anker der Rechnung des Ausblicks und das Urteil S3 aus dem Rückblick (am 11.11.2026: 7 Tage Brier-Skill +6,3 %, Steigung
  0,96; 14 Tage +3,7 %, 0,92 -- beide „besteht“). Ohne Rückblick steht „noch nicht geprüft“ da.

**Verhältnis zur Karte „Levels“.** „Levels“ zeigt die Wahrscheinlichkeit ab dem Anker der Rechnung, vom damaligen Kurs aus
(Abschnitt 10, Beobachtungen). Der Kurs-Rechner rechnet vom jetzigen Kurs. Nach einer schnellen Bewegung seit der Rechnung weichen
beide voneinander ab -- für „jetzt“ gilt der Rechner. Bei gleichem Abstand und gleicher Rechnung stimmen sie auf einen Prozentpunkt
überein.

**Bedienung.** Solange im Eingabefeld getippt wird, zeichnet das Cockpit nicht neu (das Feld verlöre sonst Text und Tastatur) --
höchstens 15 Sekunden nach dem letzten Tastendruck; wer das Feld verlässt, sieht das Zurückgestellte nach 0,4 Sekunden. Gemerkte
Kurse rechnet das Skript nach jedem Laden des Cockpits nach, dieselbe Abfrage frühestens nach 50 Sekunden wieder. Erlaubt der
Browser kein Speichern, gilt ein gemerkter Kurs bis zum Neuladen der Seite, und die Karte sagt das.

**Debug 143** nennt je Coin acht Beispielkurse (±1, ±2, ±5 und ±10 % vom jetzigen Kurs) mit ihren vier Zahlen, die Gründe für
fehlende Fristen, Hinweise und Belege; am Ende einmal den allgemeinen Satz.

**Proben** (Abschnitt 6 Punkt 6 und mehr)
- `hl_cockpit.py --selbsttest`: Stunden gleich `hl_kaskade.p_ueber` (und von Hand: mit c = 1, τ = 0 das Spiegelungsprinzip, 1 σ
  31,7 %), Tage gleich `hl_ausblick.erreichen_aus_lauf` und auf 0,5 Punkte + 1/N gleich `erreichen()`; jetziger Kurs „erreicht“;
  längere Frist nie unwahrscheinlicher (mit und ohne Vermerk, auch an der Schranke); Vermerke an ihren Grenzen; Hinweis zur
  Trefferquote des Bands; Schreibweise; Grenzen der Eingabe; ohne Quelle kein Wert; Belege; Text für Debug 143; über 112 Kurse fällt
  die Wahrscheinlichkeit mit dem Abstand und steigt mit der Frist.
- **Vertrag, Tage:** `hl_ausblick.prognose` auf der Demo-Welt legt die Verteilung ab, der Rechner gibt für jedes Niveau der Rechnung
  im selben Abstand dieselbe Wahrscheinlichkeit. Ein Rückblick in der Datenbank mit dem S1 aus `hl_ausblick.urteil_s1` (Band von BTC
  zu weit) erreicht den Rechner: Hinweis bei BTC, keiner bei ETH.
- **Vertrag, Stunden, mit Positivkontrolle:** Auf einem Probe-Markt rechnet `hl_magnet.kalibrieren` das Nullmodell selbst. An den
  acht Zufallsabständen trifft der Rechner die dort eingetretene Berührquote auf höchstens 2,5 Standardfehler und die Vorhersage des
  Tests auf höchstens 2 Punkte (über 1 und 4 Stunden); der Prognosespeicher bleibt dabei unverändert.
- `hl_ausblick.py --selbsttest`: Erreichen aus den Quantilen gegen `erreichen()` für beide Seiten und alle Horizonte, die Ränder des
  Rasters mit ihrer Lage; Ablage je Coin (älterer Anker überschreibt nicht, derselbe und ein neuerer schon), nicht in `au_prognose`.
- `hl_viz.py --selbsttest-cockpit`: der Endpunkt (leere Datenbank, fremder Coin, Kürzen der Anfrage, kein Zwischenspeicher) und die
  Karte in einem nachgebauten Dokument: Eingabe lesen (deutsche Schreibweise zuerst), Rechnen, Merken und Entfernen mit
  nachgebautem Speicher (auch kaputt oder gesperrt), Abfragen und ihre Drossel, Wechsel des Coins während einer laufenden Abfrage,
  Zurückstellen des Zeichnens beim Tippen, Maskierung.
- Browser-Probe bei 360, 390, 430 und 1280 px; Mutationen beim Bau (Zahlen in der Übergabe, Abschnitt zu Paket 23.105).

**Grenzen**
- „Berührt“ heißt: Der Kurs erreicht die Marke mindestens einmal. Ob er darüber hinaus schließt, sagt die Zahl nicht.
- Der Name „Liquidation“ ist nur ein Name. Für eine Liquidation zählt bei Hyperliquid der Mark-Preis (aus Kursen anderer Börsen und
  dem eigenen Orderbuch), nicht der Schluss der Minutenkerze, von dem der Rechner ausgeht
  (https://hyperliquid.gitbook.io/hyperliquid-docs/trading/liquidations, gelesen 16.11.2026). Die Karte sagt das unter „Beleg und
  Grenzen“.
- Die Tage rechnen mit der Verteilung der letzten Rechnung des Ausblicks (stündlich; bei offenem Abschnitt alle 30 Minuten). Zwischen
  Anker und jetzt vergangene Zeit ist nicht abgezogen.
- Die Stunden rechnen ohne Wochenende, Termin und Tageszeit: σ ist der Mittelwert der letzten 7 Tage.
- Geprüft ist das Nullmodell an Zufallsniveaus bis 3 σ, die Tage im Rückblick des Ausblicks -- nicht dieser Rechner mit Kursen des
  Nutzers auf dem Pi. Die eigene Bilanz des Rechners wäre eine neue Prüfung.
- Die Tage sind je Coin nicht eigens geprüft (S3 läuft über alle Coins zusammen). Der Hinweis zur Trefferquote des Bands ist ein
  Schluss aus S1, keine eigene Messung: Ist das Band zu eng, kann das an einer zu kleinen Schwankung liegen oder an einem Trend,
  den die Rechnung nicht kennt -- dann wäre nur eine Seite zu niedrig.
- 28 Tage zeigt die Karte nicht: Vier Fristen passen in eine Zeile am Handy; die Verteilung für 28 Tage liegt mit ab.

**Rest von Stufe C2:** Perzentil-Skalen für Funding und Taker-Varianz, Liquidationsdichte, Betriebslampe mit API-Gewicht und
Diensten -- gebaut mit Paket 23.108, Abschnitt 14.

## 14. Rest von Stufe C2: Funding, Taker-Varianz, Liquidationsdichte, Betrieb (Paket 23.108, 17.11.2026)

Auftrag: Punkt 3 der Wahl des Nutzers vom 16.11.2026 („1, 2 und 3 ausführen“). Damit ist Stufe C2 gebaut. Alle vier Teile sind
**Klasse B** (gemessen): neutral, mit Zahl, Stand und Vergleichsbasis; nichts davon ist eine Vorhersage.

**Was gebaut ist**

| Teil | Wo | Quelle | Anzeige |
|---|---|---|---|
| Funding (Hyperliquid), B2 | Karte „Markt-Messwerte“, vierte Zeile | `ctx_bars.funding` des Recorders (laufender Satz je Stunde, jede Minute) | Satz in %/h mit vier Stellen und als Jahreswert (× 24 × 365); Perzentil gegen die Werte zur vollen Stunde der letzten 90 Tage; die Zeile nennt, wie viele Werte aus wie vielen Tagen es sind |
| Varianz des Taker-Flusses, B9 | Karte „Markt-Messwerte“, fünfte Zeile | `hl_indikatoren.varianz_kompression` -- dieselbe Zahl, mit der die Prognose ihr Band weitet: Streuung der 10-s-Salden der letzten vollen Stunde gegen die Stunden der letzten 30 Tage | Skala mit Perzentil, das unterste Zehntel ist markiert; Text „im untersten Zehntel“ oder „nicht im untersten Zehntel“ |
| Liquidationsdichte, B6 | eigene Karte nach den Messwerten | jüngster Schnappschuss der Heatmap (`heatmap`, alle 10 Minuten), `coverage`, `snapshot_meta` | zwölf Balken je 0,5 % von −3 % bis +3 % um den Kurs, Summe je Seite, Abdeckung des Open Interest, Anteil der zu alten Positionen, Stand; alle Stufen als Liste |
| Betrieb, B11 | Pille im Kopf des Cockpits und Karte „Betrieb“ am Ende | `systemctl` (wie der Wächter), `meta` des Recorders, `backup.json` | Lampe mit Wort und Form; drei Zeilen mit Zahl und Schwelle |

**Regeln (fest)**

- **Funding:** Der jüngste Wert darf höchstens 15 Minuten alt sein (wie der Wächter: „Markpreis-Feed still“), sonst „kein Wert“ mit
  dem Stand. Ein Perzentil gibt es ab 14 Tagen Verlauf und 240 Stundenwerten; gleiche Werte zählen halb (Mittelrang, wie überall
  im Cockpit); sind alle Vergleichswerte gleich, gibt es keines. Solange der Recorder noch keine 90 Tage aufgezeichnet hat, sagt
  die Zeile, wie viele Tage es sind („… aus 64 Tagen (Ziel 90)“).
- **Taker-Varianz:** „unterstes Zehntel“ heißt Perzentil unter 0,10 -- dieselbe Grenze, an der die Prognose „komprimiert“ meldet.
  Der Stand ist das Ende der letzten vollen Stunde. Ohne 7 Tage 10-s-Daten gibt es keinen Wert.
- **Liquidationsdichte:** Abstand = Zelle der Heatmap ÷ jetziger Kurs − 1; nur mit frischem Kurs (höchstens 5 Minuten alt). Unter
  dem Kurs zählen nur Long-, darüber nur Short-Positionen. Die kursferne Grenze einer Stufe gehört zu ihr (−0,50 % zur Stufe am
  Kurs, −0,51 % zur nächsten; oben spiegelbildlich). Maßgeblich ist der jüngste vollständige Schnappschuss überhaupt: Hat ein
  Coin darin keine Zelle, ist seine Dichte null -- nicht der alte Stand. Ein Schnappschuss älter als 30 Minuten macht die Karte
  grau (wie im Chartbild).
- **Betrieb:** *Warnung*, wenn ein eingerichteter Dienst nicht „active“ ist (gefragt wie der Wächter: nur Dienste, die
  `systemctl is-enabled` als eingerichtet meldet; die sechs Dienste aus `install.py`). *Hinweis* bei API-Gewicht ab 93 % des
  harten Limits der Börse, bei einer Sicherung älter als 36 Stunden oder einer fehlgeschlagenen Sicherung, und solange ein Dienst
  startet. Ein Stand des API-Gewichts älter als 30 Minuten wird nicht gewertet. Ist nichts prüfbar, steht „nicht prüfbar“ -- nie
  „ohne Hinweis“. Die Pille verbindet die Lampe mit den Hinweisen des Abschnitts System (Backup fehlgeschlagen oder Ziel
  ungeeignet, Platz am Ziel, Datenbank beschädigt) und nennt jeden Grund einmal.

**Abweichungen vom Entwurf -- und warum**

1. **API-Gewicht: Hinweis ab 93 % des harten Limits, nicht ab 85 % (Abschnitt 4).** Die Zahl 85 im Entwurf war mein Fehler: Der
   Recorder nutzt planmäßig 90 % des Limits (Deckel 1.080 von 1.200 je Minute); eine Lampe ab 85 % stünde im Normalbetrieb oft auf
   „Hinweis“. Acht Messungen aus den Berichten vom 23.09. bis 11.11.2026: 44, 66, 72, 77, 85, 87, 91 und 95 % des Limits; sieben
   davon nennen die Abweisungen der Börse: jeweils 0. Mit 85 % wären drei der acht ein Hinweis gewesen, mit 93 % einer (1.143 von
   1.200 -- der Begrenzer hatte seinen Deckel um 6 % überschritten; dort warnt auch der Wächter). 93 % ist die Warnschwelle des
   Wächters (`hl_watchdog.run_checks`); ein Selbsttest hält beide Stellen gleich.
2. **Dienst nicht aktiv: erst Hinweis, nach 60 Sekunden Warnung.** Beim Neustart nach einem Update ist jeder Dienst kurz inaktiv;
   ohne Wartezeit zeigte die Pille nach jedem „Update“ rot. Debug 143 kennt keine Wartezeit (ein Lauf sieht jeden Dienst nur einmal).
3. **Funding gegen Stundenwerte, nicht gegen 90 Tagesstände.** Hyperliquid zahlt stündlich; ein Tagesstand wäre ein beliebiger
   Zeitpunkt. Der Satz liegt oft stundenlang auf demselben Grundwert -- dann steht der Wert um das 50. Perzentil.
4. **Taker-Varianz gegen 30 Tage, nicht 90,** damit das Cockpit dieselbe Zahl zeigt wie die Prognose. **Der Beleg ist Literatur**
   (`AUDIT_Gesamt_11-11-2026.md`, Abschnitt 5: sinkende Varianz des Taker-Flusses als einziger durchgehender Vorläufer von
   Kaskaden, im Mittel); **im Projekt ist das nicht geprüft** -- die Zeile sagt das. Das Instrument bleibt deshalb ein Messwert
   ohne Lampe und ohne Farbe.
5. **Liquidationsdichte: „überholt“.** Liegt eine Zelle auf der falschen Seite des Kurses (der Kurs ist seit der Abfrage über sie
   hinweggegangen, die Position ist vermutlich schon liquidiert oder verändert), steht ihr Betrag als eigene Zahl da und nicht in
   den Balken.
6. **Die Karte nennt den Stand des Magnet-Tests** (U110, Debug 51) aus dessen gespeicherter Rechnung -- ob Cluster den Kurs
   anziehen, ist eine Frage an diesen Test, nicht an die Karte.

**Grenzen**

- Die Liquidationsdichte ist eine **Untergrenze**: Erfasst sind nur bekannte Konten (die Karte nennt die Abdeckung des Open
  Interest), und Positionen, die länger als 60 Minuten nicht abgefragt wurden, fehlen (die Karte nennt ihren Anteil über alle
  Coins; seit 23.113 ihre Größe beim gewählten Coin, Abschnitt 17). Das Raster der Heatmap ist 0,25 %: Eine Zelle kann bis zu
  0,125 % neben ihrer Stufe liegen.
- Die Betriebslampe wird nur gerechnet, während jemand das Cockpit offen hat oder Debug 143 läuft. Sie benachrichtigt nicht -- das
  tut der Wächter. Ohne systemd (oder wenn kein Dienst eingerichtet ist) sind die Dienste „nicht prüfbar“.
- Der Zusammenhang der Taker-Varianz mit Kaskaden ist im Projekt nicht geprüft (siehe oben).
- Debug 143 rechnet die Taker-Varianz für alle sechs Coins neu (je Coin die 10-s-Daten von 30 Tagen) und dauert dadurch auf dem
  Pi einige Sekunden länger; im Dashboard teilt sich das Cockpit die Rechnung mit der Prognose.

**Proben (Paket 23.108):** `hl_cockpit.py --selbsttest` 116 von 116 Proben (22 neue: Funding von Hand, Mindestmenge, Frische; Taker an der
Grenze und gleich der Prognose; Liquidationsdichte von Hand, an den Stufengrenzen, nicht frisch, ohne Kurs, Leser auf einer
temporären Datenbank; Betrieb an jeder Schwelle, Wartezeit, nicht prüfbar, Leser, Zwischenspeicher; Verträge mit Wächter,
Recorder, Installation und Chartbild), `hl_viz.py --selbsttest-cockpit` mit sieben neuen Proben (die Karten im nachgebauten
Dokument). Mutationen: 784 von 784 rot, am fertigen Code, ohne Unterbrechung (zwei Hälften nebeneinander: 387 Mutationen 03:44:18–05:00:12 und 387 Mutationen 03:44:18–04:58:35; danach allein die zehn am Selbsttest des Backups 05:00:12–05:09:20): die 673 Mutationen aus 23.107 (M136 und M354 an die neue Reihenfolge der Karten angepasst) und 111 neue (M674–M784: 75 in `hl_cockpit.py` -- Funding: Fenster, Mindestmenge, Frische, Jahreswert, Leser; Taker-Varianz: Grenze, Tage, Hinweis; Liquidationsdichte: Breite, Stufen, Seiten, Stufengrenzen, Frische, Kurs, Leser, Text, Satz zum Magnet-Test; Betrieb: jede Schwelle, Wartezeit, Zustände der Dienste, Zwischenspeicher, Leser, Text; 33 in `hl_cockpit_js.py` -- Pille aus Server und Seite, Balken, Marke, Auswahl, Liste, Maskierung, Vergleichsbasis, Stilregeln; je eine in `hl_watchdog.py`, `hl_recorder.py` und `install.py` -- die Verträge). Vorab liefen die ersten 107 neuen allein (107 von 107 rot, 03:11:38–03:19:14, auf einem früheren Stand); zwei davon fielen dort nur über eine Ausnahme in der Probe auf -- die Proben sind seitdem so gebaut, dass die richtige Probe rot wird; M781 bis M784 kamen danach dazu, jede vorab einzeln rot. A7: 99 Schritte, alle [ok], rc 0 (03:29:09–03:44:18), am fertigen Code, allein gelaufen, vor den Mutationen. Update-Probe: drei Ausgänge am gelieferten Zip, je 19 von 19: von 23.107 · 8f12eb8648, von 23.106 · 763e8d40c2 und von 23.104 · 5078947908 aus (so lief der Pi laut Debug 143 vom 16.11., 18:37 UTC). Je mit dem update.py des Ausgangs, mit Dateien des Nutzers, ohne Datenbank-Sicherung und ohne systemd; die Hauptdatenbank der Probe hat der Code des AUSGANGS mit dem Schema seines Recorders angelegt und gefüllt (Kurs, Funding, Heatmap, Abdeckung, API-Gewicht, Backup): Das Cockpit von 23.108 liest sie -- Funding +0,0024 %/h im 90. Perzentil von 480 Stundenwerten aus 19 Tagen, Liquidationsdichte 4,2 und 2,5 Mio. USD mit Abdeckung 27 %, API-Gewicht 87 % des Limits, Backup vor 14 Stunden; Debug 143 trägt die neuen Zeilen. Von 23.107 aus sind genau die neun Dateien dieses Pakets geändert und keine kommt neu dazu; von 23.104 und 23.106 aus kommt `hl_niveaus.py` als „weitere Datei“ an; alles byte-gleich mit dem Zip; Dateien des Nutzers unverändert; alle Debug-Läufe von vorher behalten ihre Nummer; in der eingespielten Kopie laufen die Selbsttests des Cockpits (116 von 116) und des Dashboards. Dieselbe Probe lief vorab am Kandidaten (je 19 von 19). Browser: Cockpit in Chrome auf einer Demo-Welt (Demo-Datenbanken der Module; dazu von Hand: Funding über 64 Tage, 10-s-Daten über 31 Tage, Heatmap mit Abdeckung, API-Gewicht, Backup), am fertigen Code, für BTC, ETH und XMR bei 390, 360 und 1280 px: kein Überlauf, kein „undefined“. „Markt-Messwerte“ mit fünf Zeilen (BTC: Funding +0,0031 %/h im 90. Perzentil von 1.537 Stundenwerten aus 64 Tagen; Taker-Varianz im untersten Zehntel, Marke auf der Skala). „Liquidationsdichte“ mit zwölf Balken und der Marke am Kurs; Antippen wählt eine Stufe, die Liste bleibt nach dem Antippen und nach dem Nachladen offen; XMR ohne erfasste Position mit dem Satz dazu. Betriebslampe über einen Ersatz für `systemctl` im Pfad (der echte Aufruf des Dashboards lief): alle Dienste aktiv -- „ohne Hinweis“; ein Dienst „failed“, API-Gewicht 1.143 von 1.200, Backup 41 Stunden alt -- zuerst „Hinweis“ („eben nicht aktiv“), nach einer Minute „Warnung“ mit drei Gründen, Quadrat in der Pille und in der Karte. Farben der Balken und der Kursmarke gegen die Kartenfläche geprüft: Kontrast über 3 : 1, bei Farbsehschwäche unterscheidbar. Einzige Fehlermeldung der Seite: die Daten-Abfrage des Live-Charts (`/data`: „no such table: addresses“) -- die Demo-Welt hat nicht alle Tabellen des Recorders; bei 23.107 ebenso.

**Beim Bau gefunden (meine Fehler):** (1) die Schwelle 85 % im Entwurf (oben, Punkt 1); (2) eine neue Stilregel hieß wie die der
Spannen-Balken (`.ckbz`) und verschob die Karte „Spanne“ um 12 px -- im Bildschirmfoto gesehen, umbenannt, jetzt eine Probe „jede
neue Regel genau einmal“; (3) „Long“ und „Short“ standen im Skript der Seite, das die Wortprobe davon freihält -- die Beschriftung
kommt jetzt vom Server; (4) zwei Erwartungen in den Proben waren von Hand falsch gerechnet (−1,0 % gehört zur Stufe −1,0 bis
−0,5 %; „2 von 4“ statt „4 von 6“ eingerichteten Diensten) -- der Code war richtig, die Proben sind berichtigt.

## 15. Karte „Durchschnittslinien“ -- 50- und 200-Tage-Linie (Paket 23.110, U269; Nachricht des Nutzers vom 17.11.2026)

*Ergänzt mit 23.111 (Abschnitt 16): Die Karte zeigt seitdem zwei Werte je Linie. Was hier über „den Wert“ und den Abstand steht,
beschreibt den Wert nach Tagesschluss -- seit 23.111 den kleinen; der Abstand gilt dem großen.*

Auftrag: „Im Cockpit sollte auch zu sehen sein, wie der aktuelle 200 Moving Average und der 50er Moving Average derzeit steht. Denn
das sind wichtige Kennzahlen.“ Die Karte ist **Klasse B** (gemessen): neutral, mit Zahl, Stand und Beleg; keine Lampe.

**Warum keine Lampe und keine Farbe.** Beide vorab festgelegten Prüfungen des Projekts haben für die Linien keine Wirkung belegt:
U141 B2 (über der 200-Tage-Linie war nicht sicherer als Halten; Prüfstand im Chartbild) und das Urteil der Niveau-Arten U244/1 vom
17.11.2026 (weder Anziehung noch Halten für `ma50` und `ma200`; `KONZEPT_Niveaus.md` 13). „Nicht belegt“ heißt nicht „widerlegt“ --
die Nachweisgrenze der Niveau-Prüfung liegt für die beiden Linien bei rund 8 und 10 Punkten (Anziehung) und rund 19 und 27 Punkten
(Halten); kleinere Wirkungen wären unentdeckt geblieben. Die Karte zeigt deshalb, wo die Linien stehen, und nennt im Beleg, was
geprüft ist. Auf dem Pi (Urteil vom 17.11.2026): 50-Tage-Linie erreicht 37,7 % bei 36,6 % erwartet (n 896), 200-Tage-Linie 30,2 %
bei 30,7 % (n 546).

**Was die Karte zeigt**

| Zeile | Quelle | Regel |
|---|---|---|
| Wert der Linie | `hl_chartbild.trendlage` über `tagesteil` (Tagesschlüsse aus `daily_bars`, vor 00:00 UTC heute) | einfacher Durchschnitt der letzten 50 bzw. 200 Tagesschlüsse, ohne den laufenden Tag; weniger Tage -> „fehlen noch Tage (n von 200)“ |
| Abstand | Kurs der jüngsten Minutenkerze | Kurs ÷ Linie − 1; nur mit frischem Kurs (≤ 5 min); unter 0,05 % „Kurs auf der Linie“ |
| Richtung | Reihe der Linie | Vorzeichen der jüngsten Tagesänderung und seit wie vielen Tagen es gilt (wie `trendlage` für die 50-Tage-Linie) |
| Erreich-Wahrscheinlichkeit 1 und 2 Wochen | jüngste Rechnung des Ausblicks, Niveau mit Art-Kennung `ma50_` / `ma200` | nur aus einer frischen Rechnung (≤ 2 Tage), nicht erreicht, nicht durchlaufen; sonst der Grund; weicht der Stand der Linie im Ausblick ab, steht er dabei |
| Lage der Linien | `lage50_200`, `kreuz_tag` | „Die 50-Tage-Linie liegt über/unter der 200-Tage-Linie, seit dem …“ |
| Stand | letzter voller Tag, Quelle der Tageskerzen | Rückstand und Tage ohne Kerze unter den letzten 200 als Hinweis |

**Zwei Lesarten desselben Abstands:** Die Karte bezieht den Abstand auf die Linie (Kurs ÷ Linie − 1, wie das Chartbild und wie man
es üblicherweise sagt: „Kurs x % über der 200-Tage-Linie“). Die Karte „Levels“ bezieht ihn auf den Kurs (Niveau ÷ Kurs − 1, der Weg
dorthin). Für dieselbe Linie stehen deshalb zwei Zahlen untereinander -- in der Probewelt Linie 58.028, Kurs 62.004: hier „Kurs 6,9 %
darüber“, in „Levels“ „−6,4 %“. Das Chartbild nennt eine dritte: den Abstand des letzten Tagesschlusses (dort 8,3 %).

**Nicht geschätzt:** Tageskerzen älter als 3 Tage -> das Chartbild blendet den Trend aus, die Karte nennt dessen Grund und wird
grau. Ohne frischen Kurs kein Abstand. Ohne Rechnung des Ausblicks keine Wahrscheinlichkeit.

**Allein entschieden:** ohne den laufenden Tag und als einfacher Durchschnitt -- dieselbe Zahl wie im Chartbild, im Ausblick und in
den Prüfungen; ein Chart mit laufender Kerze zeigt einen leicht anderen Wert (die Karte sagt das). Keine Zeichnung: Eine erste
Fassung mit den Balken der „Levels“ drängte die Werte an den Rand; jetzt steht der Wert groß rechts.

**Dazu:** Der Beleg der Karte „Levels“ liest das Urteil der Niveau-Arten (bisher fest „die Art des Niveaus ist nicht geprüft“).

**Proben (Paket 23.110):** `hl_cockpit.py --selbsttest` 135 von 135 Proben (18 neue), `hl_viz.py --selbsttest-cockpit` mit zwei neuen
Proben (die Karte im nachgebauten Dokument). Mutationen: 1024 von 1024 rot, darunter 88 neue (M937–M1024).

## 16. Durchschnittslinien: beide Rechnungen (Paket 23.111, U270; Entscheidung des Nutzers vom 18.11.2026)

Im Dashboard gibt es zwei Rechnungen der 50- und der 200-Tage-Linie:

| Rechnung | Wer sie benutzt | Regel |
|---|---|---|
| **mit dem heutigen Tag** (`hl_viz.load_mas`) | Kachel „MA 200 Tage“ (Kennzahlenleiste, Werkstatt), Linien „MA 50 T“ und „MA 200 T“ im Live-Chart, Konfluenz | (Summe der letzten 49 bzw. 199 Tagesschlüsse + jetziger Kurs) ÷ 50 bzw. 200 -- wie übliche Charts |
| **nach Tagesschluss** (`hl_chartbild.trendlage`) | Chartbild, Niveaus des Ausblicks, „Levels“, die Prüfungen U141 und U244 | Mittel der letzten 50 bzw. 200 Tagesschlüsse, ohne den laufenden Tag |

Paket 23.110 zeigte in der Karte nur die zweite. Die Zahlen weichen um (Kurs − Schluss vor n Tagen) ÷ n voneinander ab. Auf die Frage
zum Anklicken wählte der Nutzer „Beide Werte zeigen“:

- **Groß** steht der Wert mit dem heutigen Tag; auf ihn bezieht sich der **Abstand** (derselbe wie in der Kachel).
- **Klein, rechtsbündig darunter** „nach Tagesschluss …“; auf ihn beziehen sich **Richtung**, **Lage der Linien** („Nach dem letzten
  Tagesschluss liegt …“) und die **Erreich-Wahrscheinlichkeit** des Ausblicks („gilt für den Stand nach Tagesschluss“).
- Steht es mit dem heutigen Kurs umgekehrt (die 50-Tage-Linie nach Tagesschluss über der 200-Tage-Linie, mit heute darunter), sagt
  die Karte beides -- ein Wechsel, der sich erst mit dem Tagesschluss entscheidet.
- **Ohne frischen Kurs** kein Wert mit dem heutigen Tag: Dann steht der Wert nach Tagesschluss groß, mit dem Grund darunter.
- Das Cockpit rechnet den großen Wert aus der Reihe des Tagesteils (`ma50_rest`, `ma200_rest` in `linien_lesen`); eine Vertragsprobe im
  Dashboard-Selbsttest hält fest, dass er gleich `load_mas` ist.

**Grenzen (gesehen, nicht geändert):**

- **Tage ohne Kerze.** Fehlt in den letzten 200 Tagen eine Tageskerze, rechnen die beiden Stellen nicht mehr gleich: `load_mas` nimmt
  die letzten 49 bzw. 199 Zeilen der Tabelle, das Cockpit (wie das Chartbild) die letzten 49 bzw. 199 Kalendertage und setzt für den
  Tag ohne Kerze den Schluss des Vortags. Die Karte zeigt dann ihren Hinweis „… ohne Tageskerze -- dort gilt der Schluss des Vortags“.
- **Vorläufiger Tagesschluss.** hl-binance lädt die Tageskerzen beim Start und danach alle 6 Stunden, nicht zum Tageswechsel. Nach
  00:00 UTC gilt die Zeile des Vortags mit dem Stand des letzten Nachladens als Schluss, bis das nächste Nachladen sie ersetzt (bis zu
  6 Stunden). Das trifft beide Rechnungen gleich (aus dem Code gelesen, auf dem Pi nicht gemessen; offen als U271).
- **Zeitpunkt des Kurses.** Das Cockpit liest den Kurs aus der jüngsten Minutenkerze, der Live-Chart aus der letzten Kerze seines
  Fensters -- die letzte Stelle des großen Werts kann abweichen.

**Proben (Paket 23.111):** `hl_cockpit.py --selbsttest` 136 von 136 Proben; `hl_viz.py --selbsttest-cockpit` mit dem Vertrag gegen
`load_mas`. Mutationen: 1049 von 1049 rot, darunter 25 neue (M1025–M1049) und vier angepasste.

## 17. Liquidationsdichte: nicht enthaltene Positionen nach Größe, Vermerk im Anlauf (Paket 23.113, U272 Teil 2; Messung vom 20.11.2026)

**Anlass.** Die Karte nannte „69 % der bekannten Positionen … nicht abgefragt und nicht enthalten“. Der Zähler zählt Köpfe über alle
Coins, beginnt nach jedem Neustart des Recorders bei 0 und wächst über Tage. Die Messung vom 20.11.2026 (Debug 85, Recorder 23,4 h)
zeigte: Nach Größe fehlen je Coin nur 1,8 bis 3,7 Prozentpunkte Abdeckung (BTC 2.361,8 BTC = 3,0 Punkte bei 29 % erfasst).

**Regel der Zeile.**

- Quelle ist der Meta-Wert `ausgelassen` des Recorders (seit 23.112): je Coin Anzahl, Größe und USD der Positionen, deren Konto seit
  über 60 Minuten nicht abgefragt wurde. Die Karte nimmt ihn nur, wenn seine Zeit die des gezeigten Schnappschusses ist.
- „mit ihnen wären es x Prozentpunkte mehr“ = Größe ÷ (2 × Open Interest), dieselbe Rechnung wie „käme dazu“ in Debug 85.
- Text (Debug 143): „nicht enthalten, weil seit über 60 Minuten nicht abgefragt: 7.112 BTC-Positionen mit zusammen 2.362 BTC (146,6
  Mio. USD, letzter bekannter Wert) -- mit ihnen wären es 3,0 Prozentpunkte mehr · über alle Coins 49.905 von 72.085 bekannten
  Positionen“. Die Karte der Seite lässt den USD-Wert und die Köpfe weg.
- Fehlt der Wert, sein Eintrag für den Coin oder das Open Interest, bleibt die bisherige Zeile nach Köpfen.
- Die Größe ist der letzte bekannte Stand dieser Positionen -- so alt wie ihre letzte Abfrage.
- **Bei 0 und bei 1 Position** steht derselbe Satz: „0 BTC-Positionen mit zusammen 0,000 BTC … -- mit ihnen wären es 0,0
  Prozentpunkte mehr“, bei einer Position „mit ihnen“ statt „mit ihr“. 0 ist der Stand der ersten Stunde nach jedem Neustart
  (der Zähler beginnt bei 0). Richtig, aber holprig -- offen als U282.

**Vermerk im Anlauf.** Läuft der Recorder seit weniger als 45 Minuten (`LIQ_ANLAUF_S`, gleich `hl_watchdog.ANLAUF_S`; Laufzeit aus
`snapshot_meta.uptime`), steht „Der Recorder läuft erst seit n Minuten: Der Stand ist noch im Aufbau, die Summen sind kleiner als
sonst.“ Am 19.11.2026 standen kurz nach einem Update 6.285 statt rund 22.000 Positionen im Stand.

**Nicht geändert:** die Regel des Recorders (60 Minuten), die Heatmap, die Balken. Die Karte bleibt eine Untergrenze.

**Proben (Paket 23.113):** `hl_cockpit.py --selbsttest` 141 von 141 (Zeile mit den Zahlen der Messung, Grenzen, Vermerk an der
45-Minuten-Grenze, Lesen aus der Datenbank, Vertrag mit Recorder und Wächter); `hl_viz.py --selbsttest-cockpit` mit der Karte in
node; Browser bei 390, 360 und 1280 px (dort der Anlauf mit den vollen Zahlen der Messung; den echten Zustand kurz nach einem
Neustart -- 0 ausgelassen -- nach den Prüfläufen eigens angesehen, Karte und Debug 143). Mutationen: 1195 von 1195 rot, darunter 19 zu diesem Abschnitt (M1113–M1131) und die neu gefasste
M705.

**Nachtrag 23.114 (U282, 20.11.2026): Wortlaut bei null und bei einer Position.** In der ersten Stunde nach jedem Neustart des
Recorders ist nichts wegen Alters ausgelassen; die Zeile hieß dann „0 BTC-Positionen mit zusammen 0,000 BTC (0 USD, letzter bekannter
Wert) -- mit ihnen wären es 0,0 Prozentpunkte mehr“ (so im Bericht vom 20.11. 12:52). Neu: „nicht enthalten, weil seit über 60 Minuten
nicht abgefragt: zurzeit keine BTC-Position“, ohne Größe und Punkte; bei genau einer Position „1 BTC-Position mit 0,500 BTC -- mit ihr
wären es …“. Null Köpfe mit einer Größe über null (kann der Recorder nicht liefern) bleiben als Zahl stehen. Gleich in Text (Debug
143) und Karte der Seite; an der Rechnung ändert sich nichts.
