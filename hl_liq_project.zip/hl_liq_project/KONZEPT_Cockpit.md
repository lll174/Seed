# KONZEPT Cockpit (U245) — das Dashboard als Cockpit: Instrumente nur aus belastbaren Daten

Stand 11.11.2026, abends (Fable 5.2). Anlass: Wunsch des Nutzers vom 11.11. 20:58 — „Backup soll unter System verschoben
werden … Das Dashboard soll als Cockpit umgestaltet werden, weiterhin mit Zahlen, aber auch visuellen Indikatoren. Prüfe, welche
Daten aus dem ganzen Projekt zusätzlich belastbar sind.“ **Status: gebaut sind Stufe C0 (Paket 23.96: die Kacheln „Letztes Backup“ und „Datenbank“ im Abschnitt System) und die Stufen C0b und C1 (Paket 23.98, 12.11.2026: Cockpit oben auf der Hauptseite, Gruppen „Werkstatt“ und „Betrieb“; Abschnitt 9). Aus Stufe C2 gebaut: die Karte „Kurs-Rechner“ (Paket 23.105, 16.11.2026; Abschnitt 13). Offen: der Rest von C2 (Perzentil-Skalen für Funding und Taker-Varianz, Liquidationsdichte, Betriebslampe), C3. Berichtigung nach der ersten Prüfung auf echten Daten: Paket 23.99, Abschnitt 10 -- die 7-Tage-Spanne ist nicht „belegt“ im strengen Sinn. Seit Paket 23.100 (U254): Instrument „Unstaking“ bei ETH, Abschnitt 11. Seit Paket 23.104 (U260): Karte „Unstaking · Verlauf“ bei ETH, Abschnitt 12.**
Grundlage: Paket 23.95, Sammeldatei und Debug 73 vom 11.11., `AUDIT_Gesamt_11-11-2026.md`, die Urteile in der Übergabe.
Entwurf (zwei Handy-Ansichten, Cockpit und System mit Backup; Werte vom 11.11., eckige Klammern = Wert in keinem Bericht):
https://claude.ai/artifact/TGq3YnxU1TQDzMAZ1FdWHR

---

## 0. Kurzfassung

- **Regel:** Ein Instrument im Cockpit bekommt nur, was belegt oder sauber gemessen ist. Jedes Instrument zeigt seinen Beleg.
- **Drei Klassen:** A belegt (vorab festgelegter Test bestanden) · B gemessen (verlässlicher Messwert, keine Vorhersage) ·
  C nicht belegt (bleibt in der Werkstatt, nie im Cockpit).
- **Ergebnis der Prüfung:** 9 Größen der Klasse A, 11 der Klasse B. *Berichtigt am 12.11. (Abschnitt 10): 8 Größen der Klasse A; die 7-Tage-Spanne (A2) hat einen belegten Vorsprung, ihre Gesamtprüfung S1 besteht aber nicht.* Drei belastbare Größen zeigt das Dashboard heute gar nicht als
  Anzeige: die Erreich-Wahrscheinlichkeit über 1 h und 4 h, die erwartete 4-h-Bewegung und die Kostenschwelle.
- **Kein Richtungspfeil im Cockpit.** Richtung ist über kein Fenster belegt (Audit, Debug 73).
- **Backup:** Die Kacheln „Letztes Backup“ und „Datenbank“ stehen heute in der Kennzahlenleiste zwischen Marktwerten. Sie
  wandern in den Abschnitt System, wo der Backup-Block (`#speicher`) seit 23.95 schon steht.

## 1. Heutiger Aufbau (23.95)

Eine Seite mit 23 einklappbaren Abschnitten: Live-Chart, Chartbild, Ausblick, Konfluenz, AI-Prognose, Treiberfamilien,
TradeLabor, Notbremse, Makro, Prognosemärkte, Volatilität, Orders, Heatmap, Momentaufnahme, Wale, Leaderboard (3), Aktive Profis,
Netzwerkstatus, Aktualisierung, Debug, System. Darüber eine Kennzahlenleiste, unter anderem mit 60-Minuten-Trend, MA 50 Wochen,
MA 200 Tage, Letztes Backup, Datenbank, Wal-Position, Wal-Flow, Leaderboard-Trend, Coinbase-Spot, Konfluenz.

Befund: Belegtes (Ausblick, Volatilität) und Unbelegtes (AI-Prognose, Konfluenz, Wal-Flow) stehen gleichrangig nebeneinander.
Die Kennzahlenleiste zeigt überwiegend Größen der Klasse C.

## 2. Prüfung: was belastbar ist

### Klasse A — belegt

| Nr. | Größe | Beleg | Im Dashboard heute |
|---|---|---|---|
| A1 | Niveau der Schwankung, 1–4 Wochen | V1 belegt 30.10. (p Holm 0,0292) | Abschnitt Volatilität |
| A2 | Spanne 7 Tage | S1: CRPS +1,5 % (p 0,002); 80-%-Band trifft BTC 84,0, ETH 80,4, HYPE 80,7, XMR 82,9, ZEC 79,0 %. **Berichtigung 12.11.: Die Gesamtprüfung S1 lautet „besteht nicht“ -- das Band von BTC liegt mit 84,0 % ± 1,7 außerhalb von 80 % ± 2 Standardfehler (zu weit). Belegt ist nur der Vorsprung gegen das Vergleichsmodell; siehe Abschnitt 10** | Abschnitt Ausblick |
| A3 | Erreich-Wahrscheinlichkeit von Kursen, 7 / 14 / 28 Tage | S3 besteht: Brier-Skill +6,2 / +3,7 / +1,5 %, Steigung 0,96 / 0,92 / 0,89 | Abschnitt Ausblick |
| A4 | Erreich-Wahrscheinlichkeit über 1 h und 4 h | Nullmodell von U110 an Zufallsniveaus, BTC 1 h: 1 σ 22,2 → 21,4 %, 2 σ 6,0 → 5,9 %, 3 σ 2,0 → 2,1 % | **nein** (nur im Testbericht) |
| A5 | Erwartete 4-h-Bewegung E\|r\| | Kriterium 5 (vorab 13.10.): Verhältnis 1,02 ± 0,05, n 1.390 in 232 Zeitblöcken | **nein** (nur im Fusion-Bericht und in einem Tooltip) |
| A6 | Hebel-Warnung H1 | Konten ≥ 3: Rücksetzer in 7 Tagen 20,3 % statt 7,3 %, p Holm 0,012; in 4 von 5 Fällen folgte keiner | Satz im Chartbild |
| A7 | Datentage | U154: Varianz in den 2 h nach CPI × 2,45, nach Arbeitsmarktbericht × 1,9 | Hinweis an Datentagen |
| A8 | Wochenende | Varianz Sa/So = 0,68 × Werktag (2.494 Tage) | in der Spanne eingerechnet |
| A9 | Kopplung an den S&P 500 | S4: Abhängigkeit belegt (p 0,003) | Szenarien im Ausblick |

Einschränkungen, die am Instrument stehen müssen:
- A2: Bei 14 Tagen ist der Vorsprung nicht belegt (+0,4 %, p 0,18), bei 28 Tagen keiner (−0,7 %). PAXG trifft nur 58–67 %.
- A3: Die Zahl folgt allein aus dem Abstand; die Niveau-Art prüft U244.
- A3, A4: seit Paket 23.105 für jeden eingetippten Kurs im Kurs-Rechner des Cockpits (Abschnitt 13) -- A4 war bis dahin nur im
  Testbericht zu sehen.
- A9: Unter Aktienstress ist die bedingte Verteilung nicht kalibriert (PIT p 0,014). Gezeigt wird die Kopplung, nicht das Szenario.

Aus A5 folgt rechnerisch die **Kostenschwelle** (nötige Trefferquote; BTC 11.11.: 4 h 58,9 % Taker / 52,9 % Maker, 24 h 53,5 /
51,1 %). Auch sie steht heute nur im Bericht und im Tooltip der Fusion-Kachel, auf dem Handy also gar nicht.

Die Perzentile der Klasse B rechnet das Chartbild schon (Mittelrang unter den letzten 90 Tagesständen, wie U142); das Cockpit
übernimmt diese Rechnung.

### Klasse B — gemessen

| Nr. | Größe | Anzeige | Vorbehalt |
|---|---|---|---|
| B1 | Kurs, Mark, Oracle, Prämie | Zahl | — |
| B2 | Funding Hyperliquid | Perzentil 90 Tage | Fremdbörsen erst nach U23 |
| B3 | Open Interest | Perzentil 90 Tage | — |
| B4 | Realisierte Schwankung 7 / 30 Tage, DVOL | Zahl neben A1 | DVOL als Zusatz nicht belegt (V4) |
| B5 | Kontenquote Binance | Skala mit Marke bei 3 | Schwelle = A6 |
| B6 | Liquidationsdichte nahe am Kurs | Balken ± 3 % | Abdeckung BTC 27 % des OI; 85 % der bekannten Positionen zu alt |
| B7 | Wartende Orders, Stops, Wände | Liste | Momentaufnahme, Konten ab 250k USD |
| B8 | Spread | Zahl | Buchtiefe erst nach N1 (heute nur 10 Stufen) |
| B9 | Varianz des Taker-Flusses | Skala, unterstes Dezil markiert | Vorläufer nur im Mittel, kein Einzelalarm |
| B10 | Termine: CPI, Arbeitsmarkt, Fed, Optionsverfall | Countdown | — |
| B11 | Betrieb: Dienste, API-Gewicht, Rückstand, Speicher, Backup | Lampe + Abschnitt System | — |
| B12 | Unstaking: angemeldete Abzüge aus dem Ethereum-Staking mit ihrem Zeitpunkt (seit 23.100, nur ETH) | Karte mit Kalender, Termin der nächsten großen Freigabe | Kurswirkung: vorab festgelegte Prüfung (U255, Debug 147, seit 23.101); ihr Urteil steht als Text in der Karte -- am 15.11.2026: nicht belegt, Wellen bis 25.10.2026 |
| B13 | Unstaking, Verlauf: Schlange der Abzüge und ETH-Kurs je UTC-Tag seit Mai 2023 (seit 23.104, nur ETH) | Karte mit zwei Feldern (Kurs, Schlange) und den Wellen der Prüfung als Marken | — (der Verlauf belegt nichts; darunter steht der Satz der Prüfung U255) |

### Klasse C — nicht belegt, nicht im Cockpit

AI-Prognose (P(aufwärts), Bias, „Konfidenz“, 7-Tage-Pfad, Kauf- und Verkaufspreis) · Konfluenz (49 % richtig bei 45 % Zufall,
n 35) · Smart Money, Elite, Wale, Leaderboard, Pool als Richtungsanzeiger (das Timing-Urteil der Darwin-Liste steht am 18.11. an)
· Heatmap als Magnet oder Anker · ETF-Flüsse und Makro-Zonen als Signal (3 von 322 Tests belegt, erwartet wären 16 aus Zufall) ·
Wahrscheinlichkeit einer „volatilen Woche“ (nicht besser als die Grundrate) · Szenarien unter Aktienstress · Kalendereffekte bei
XMR (kippen an der Holm-Grenze) · alles aus Labor und Engine, solange N1 offen ist.

Diese Abschnitte bleiben erhalten, unter „Werkstatt“, mit dem Vermerk „nicht belegt“.

## 3. Aufbau des Cockpits (Handy zuerst)

Von oben nach unten, ein Bildschirm je Block:

1. **Kopf:** Coin, Kurs, Datenalter, eine Betriebslampe (führt zu System).
2. **Risikoleiste, fünf Lampen:** Hebel (A6) · Termin (A7, B10) · Wochenende (A8) · Aktien (A9) · Schwankung (A1 als Perzentil).
   Jede Lampe: aus, gelb oder — nur wo ein Test es trägt — rot; beim Antippen der Beleg.
3. **Schwankung:** Bogen-Instrument mit der erwarteten Schwankung für 7 Tage und ihrem Perzentil gegen 365 Tage; daneben A5
   („in 4 h typisch ± x %“), realisierte 7 und 30 Tage, DVOL.
4. **Spanne:** waagrechter Balken 50 / 80 / 90 % für 7 Tage mit Kursmarke, darunter 14 Tage schmaler, 28 Tage als Rahmen.
   Beschriftung mit gemessener Trefferquote.
5. **Levels:** die nächsten Niveaus oben und unten, je mit Balken für 1 und 2 Wochen und dem Abstand in %; nach U244 die
   Bilanz der Art.
6. **Erreich-Rechner (neu, aus A4 und A3):** Kurs eintippen → Wahrscheinlichkeit, ihn in 1 h, 4 h, 7 und 14 Tagen zu erreichen.
   Gedacht für Stopps, Limits und den eigenen Liquidationspreis.
7. **Markt-Messwerte:** kleine Perzentil-Skalen für B2, B3, B5, B9; Liquidationsdichte B6 mit der Abdeckung daneben.
8. **Kosten:** nötige Trefferquote für 4 h und 24 h, Taker und Maker.
9. **Werkstatt** (alle heutigen Abschnitte der Klasse C, eingeklappt) und **System** (Backup, Datenbank, Speicher, Netzwerk,
   Aktualisierung, Debug).

## 4. Regeln für jedes Instrument

- **Beleg sichtbar:** eine Zeile unter dem Instrument, etwa „geprüft: 80-%-Band traf 84 % (Rückblick 08.11.)“.
- **Farbe nur für Klasse A.** Klasse B ist neutral (grau, blau) und zeigt das Perzentil; kein Grün/Rot im Sinn von gut/schlecht.
- **Keine Pfeile, keine Empfehlungswörter.** Die Liste der verbotenen Wörter aus Chartbild und Ausblick gilt.
- **Frische:** Ist die Quelle älter als ihre Grenze, wird das Instrument grau und nennt den Stand.
- **Nicht nur Farbe:** Jede Lampe trägt ein Wort; Zustände unterscheiden sich auch in der Form.
- **Zahlen bleiben.** Jedes Instrument zeigt seinen Zahlenwert; die Grafik ersetzt ihn nicht.
- **Schwellen fest und vorab:** H1 ab Kontenquote 3; Termin 24 h vor bis 2 h nach der Veröffentlichung; Schwankung gelb ab dem
  80., rot ab dem 95. Perzentil; Betrieb gelb bei API-Gewicht über 85 % oder Backup älter als 36 h, rot bei Dienst aus.

## 5. Stufen

| Stufe | Inhalt | Paket |
|---|---|---|
| C0 | Kacheln „Letztes Backup“ und „Datenbank“ aus der Kennzahlenleiste in System, über den Speicherorten; ein Problem zeigt die Kopfzeile des Abschnitts auch zugeklappt („⚠ Backup“, „⚠ Datenbank“) | **gebaut mit 23.96** (Selbsttest Speicherorte S15, S16; Browserprobe bei 390 px) |
| C0b | Netzwerk, Aktualisierung, Debug und System als Gruppe „Betrieb“ | **gebaut mit 23.98** (mit C1; Abschnitt 9) |
| C1 | Cockpit als Startabschnitt aus vorhandenen Endpunkten (Ausblick, Volatilität, Chartbild, Termine, Fusion, System); nur lesend, keine neue Rechnung; alte Abschnitte darunter als Werkstatt | **gebaut mit 23.98** (Abschnitt 9; dazu aus C2 schon der Kostenblock und drei Messwerte) |
| C2 | Erreich-Rechner (A4, A3), Perzentil-Skalen für Funding und Taker-Varianz, Liquidationsdichte, Betriebslampe mit API-Gewicht und Diensten | **Kurs-Rechner gebaut mit 23.105** (Abschnitt 13); der Rest offen |
| C3 | nach N1, U23 und U244: Buchtiefe und Impact, Funding-Spread, Bilanz der Niveau-Art | später |

## 6. Proben

1. Abgleich: Jede Zahl im Cockpit ist gleich der Zahl im Quellbericht desselben Zeitpunkts (Ausblick, Volatilität, Fusion).
2. Frische: Quelle künstlich gealtert → Instrument grau mit Stand.
3. Browserprobe bei 360 bis 430 px Breite und am Desktop; kein waagrechtes Scrollen.
4. Wortprobe: keine Empfehlungswörter, kein Pfeil.
5. Mutation je Lampe: Schwelle verschoben → Probe schlägt an.
6. Der Erreich-Rechner trifft an Zufallsniveaus die Quoten von U110 (Positivkontrolle) und liefert für den aktuellen Kurs 100 %.
   *Seit 23.105 gebaut:* Vertragsprobe „Stunden“ auf einem Probe-Markt; der jetzige Kurs steht als „erreicht“ da (Abschnitt 13).

## 7. Entscheidungen beim Nutzer

**Entschieden am 12.11.2026 gegen 01:00 (Auswahl zum Anklicken, nach der Frage des Nutzers von 00:55 „aber das cockpit ist noch nicht umgesetzt?“):** Punkt 1 „Oben auf der Hauptseite“, Punkt 2 „Ein Coin groß + Streifen“, Punkt 3 „In die Werkstatt“, Punkt 4 „Ja, auf meinem Gerät merken“ -- jeweils der Vorschlag. Punkt 5 hat die Frage des Nutzers beantwortet: das Cockpit zuerst, vor U244.

Stand 11.11. 21:36 (überholt): Der Nutzer antwortete auf dieses Konzept mit „Ok“ und fragte nach dem Paket. Das „Ok“ war keine Einzelantwort auf die fünf Punkte.

1. **Ort:** Cockpit als Startabschnitt derselben Seite, alte Abschnitte eingeklappt darunter? Vorschlag: ja.
2. **Coins:** ein Coin groß, dazu ein Streifen mit allen sechs (Spanne 7 Tage und Lampen)? Vorschlag: ja.
3. **Unbelegtes:** AI-Prognose, Kauf- und Verkaufspreis, Konfluenz und die Kacheln zu Walen aus der Hauptansicht nehmen und nur
   in der Werkstatt zeigen? Vorschlag: ja.
4. **Erreich-Rechner** mit eigenem Liquidationspreis als festem Eintrag? Vorschlag: ja, lokal im Browser gespeichert.
5. **Reihenfolge:** C0 mit 23.96, C1 und C2 als eigenes Paket danach, vor oder nach U244? Vorschlag: C1 und C2 vor U244 — das
   Cockpit braucht keine neue Studie.

## 8. Abgrenzung

- Das Cockpit rechnet nichts Neues außer dem Erreich-Rechner und den Perzentilen. Es ändert keine Prognose, kein Urteil, kein
  Labor.
- Was heute Klasse C ist, kann aufsteigen: Ein bestandener, vorab festgelegter Test macht aus einer Werkstatt-Größe ein Instrument
  (zum Beispiel eine Niveau-Art nach U244 oder der Rücklauf nach Liquidationswellen nach U204).

## 9. Bau der Stufen C0b und C1 (Paket 23.98, 12.11.2026)

**Was gebaut ist**
- Neues Modul `hl_cockpit.py` (liest nur, Endpunkt `/cockpit?coin=…`) und `hl_cockpit_js.py` (Skript `/cockpit.js`). Abschnitt
  „CK Cockpit“ als erster Abschnitt der Hauptseite: Kopf mit Kurs und Betriebs-Pille, Streifen mit sechs Coins, Kernsatz, fünf
  Lampen, Schwankung, Spannen, Levels, Messwerte, Kosten, Sprünge zu Werkstatt und Betrieb.
- Ordnung der Seite in `hl_cockpit.seite_ordnen`: Hauptansicht (Live-Chart, Chartbild, Ausblick, Volatilität, Notbremse, Makro,
  Prognosemärkte, Orders, Heatmap, Momentaufnahme), Gruppe „Werkstatt · nicht belegt“ (Kennzahlenleiste, Konfluenz, AI-Prognose,
  Treiberfamilien, TradeLabor, Wale, Leaderboard dreifach, Aktive Profis), Gruppe „Betrieb“ (Netzwerk, Aktualisierung, Debug,
  System). Beim ersten Laden je Browser werden die bisherigen Abschnitte einmal eingeklappt.
- Debug 143 (★ Cockpit: Stand je Coin als Text) und 144 (Selbsttest).

**Festlegungen beim Bau (neu, fest und vorab)**
- **Lampe „Aktien“:** Abschnitt 4 nannte für sie keine Schwelle. Festgelegt: Sie zeigt die Ausnahmelage (c) des Ausblicks
  (`hl_ausblick.schock_pruefen`: S&P-500-Perp in 6 h über 3 typische Bewegungen; gilt 24 h) -- eine Regel, die es schon gab. Für
  PAXG gilt sie nicht. Die Ausnahmelagen (a) und (b) des Coins selbst stehen als Zeile unter dem Kernsatz.
  - „Aus“ zeigt die Lampe nur, solange die Regel nachweislich geprüft wird -- dieselben Bedingungen wie in `schock_pruefen`: Basis
    `FS1` vorhanden, mindestens 12 Kerzen der Reihe `xyz:SP500:30m` in den letzten 8 h, die letzte jünger als 2 h; dazu: letzte
    Rechnung des Ausblicks jünger als 3 h (die Prüfung läuft in seinem Takt). Sonst ist sie grau und nennt den Grund. Anlass: Die
    Notbremse lief knapp drei Wochen ohne XMR, weil ein fremd betriebener Markt verschwunden war und nichts es meldete (23.97); fiele
    der S&P-500-Perp aus, stünde die Lampe sonst für immer auf „aus“.
  - Grau ist sie auch, solange für den Coin eine Ausnahmelage (a) oder (b) gilt (`schock_pruefen` setzt (c) dann nicht), und für
    einen Coin, der in der Basis der Regel fehlt (keine Rechnung des Ausblicks für ihn).
- **Ohne Quelle kein „aus“** (gilt für alle Lampen): ohne Kontenquote, ohne bekannten kommenden Termin, ohne geprüfte Aktien-Regel,
  mit Tageswerten der Schwankung, die älter als 3 Tage sind, ist die Lampe grau. Nur „Wochenende“ kommt ohne Quelle aus (Uhr).
- **Lampe „Termin“:** 24 h davor Hinweis; von der Veröffentlichung bis 2 h danach Warnung, aber nur, wenn die Datentage-Studie für
  diese Reihe „belegt“ meldet -- sonst bleibt es beim Hinweis. Erzeugerpreise und Erstanträge lösen nichts aus (die Studie führt
  sie nur beschreibend, ohne Urteil).
- **Lampe „Schwankung“:** Perzentil der erwarteten Schwankung (erste Woche des Modells, das auch der Abschnitt „Volatilität“
  zeigt) gegen die realisierte 7-Tage-Schwankung der letzten 365 Tage. Farbe nur mit Urteil V1 „belegt“ und nur für die Prognose; gibt es keine frische Prognose, zeigt die Lampe
  das Perzentil der realisierten Schwankung neutral.
- **Levels:** Die Wahrscheinlichkeiten gelten ab dem Anker der Rechnung. Ein Niveau, das der Kurs seither durchlaufen hat, wird
  nicht mehr gezeigt, nur gezählt; die Abstände zählen zum jetzigen Kurs.
- **Vermerk an der Spanne** (*berichtigt mit 23.99, Abschnitt 10*): immer die gemessene Trefferquote des Coins („traf x %“), mit
  „(zu eng)“ oder „(zu weit)“ außerhalb von 80 % ± 2 Standardfehler, wie im Ausblick. Vorsprung je Horizont und das Urteil der
  Gesamtprüfung S1 stehen in der Zeile darunter. Bis 23.98 stand „traf x %“ nur, wenn die Gesamtprüfung bestand -- auf dem Pi
  also nie.

- **Stand an jedem Instrument:** Kurs und Messwerte mit Uhrzeit („live“) oder UTC-Tag (Tagesstand, Funding-Druck); Schwankung mit
  dem Tag der Tageswerte und dem der Prognose; Spanne und Levels mit der Zeit der Rechnung (älter als 2 Tage: blass); Kosten mit
  Zeit und Fenster; im Detail der Lampen „Stand der Quelle“.

**Abweichungen vom Entwurf**
- Aus Stufe C2 vorgezogen: der Kostenblock und drei Messwerte (Open Interest, Kontenquote mit Perzentil, Funding-Druck als z-Wert).
  Taker-Varianz, Liquidationsdichte und das Perzentil des Hyperliquid-Fundings fehlen noch.
- Die Betriebs-Pille zeigt dieselben Meldungen wie die Kopfzeile des Abschnitts System (Backup fehlgeschlagen oder Ziel
  ungeeignet, Backup älter als 50 Stunden, Platz am Backup-Ziel, Datenbank beschädigt) und nur die Stufe „Hinweis“. Die
  Betriebslampe nach Abschnitt 4 (Backup älter als 36 h, API-Gewicht über 85 %, Dienst aus = rot) kommt mit C2.
- Der Kopf zeigt den Kurs aus der jüngsten Minutenkerze des Recorders (Mark, Oracle und Prämie stehen weiter im Live-Chart).
- Die Lampe „Wochenende“ ist als Messwert geführt (blau), nicht als Klasse A wie in der Tabelle von Abschnitt 2 (A8): Der Faktor
  0,68 stammt aus einer Datenprobe der Volatilität (Prüfung vor dem Urteil), nicht aus einem Test mit Urteil.
- Die Regeln des Cockpits gelten für den Abschnitt Cockpit. Die Abschnitte der Hauptansicht darunter sind unverändert; der
  Live-Chart zeigt weiter seine Marken und Zonen (darunter FVG mit den Wörtern „bullisch“ und „bärisch“). Darüber ist nichts
  entschieden.

**Proben (Abschnitt 6):** 1 Abgleich und 2 Frische in `hl_cockpit.py --selbsttest` (dazu der Vertrag mit den Modulen auf deren
Demo-Datenbanken); 3 Browserprobe bei 360, 390 und 430 px und am Desktop beim Bau (kein waagrechtes Scrollen, keine Fehler);
4 Wortprobe im Selbsttest von Modul und Skript; 5 Mutationen beim Bau (jede Lampe an ihrer Schwelle); 6 entfällt bis C2.

## 10. Erste Prüfung auf echten Daten und Berichtigung (Debug 143 vom 12.11.2026 16:18 UTC; Paket 23.99)

Der Nutzer hat 23.98 eingespielt und Debug 143 geschickt (Laufzeit 4,2 s für sechs Coins).

**Stimmt mit den Quellen überein:** Kosten BTC 4 h 58,9 / 52,9 % und 24 h 53,5 / 51,1 % (gleich dem Fusion-Bericht vom 11.11.);
die Aktien-Regel wird geprüft (letzte Kerze des S&P-500-Perp 15:00 UTC, letzte Rechnung des Ausblicks 16:06 UTC); nächster Termin
Arbeitsmarktbericht (laut Kalender der BLS am 04.12.2026, die Verbraucherpreise am 10.12.2026:
https://www.bls.gov/schedule/2026/12_sched.htm); PAXG mit drei grauen Lampen, wie beschrieben. Hebel-Lampe an bei BTC
(Kontenquote 3,20) und ETH (3,59).

**Zwei Fehler des Cockpits, mit 23.99 behoben**
1. **Vermerk an der 7-Tage-Spanne: „Vorsprung offen“ bei allen Coins.** Der Vermerk hing an der Gesamtprüfung S1 des Ausblicks. Die
   verlangt den Vorsprung (p < 0,05) *und* die Deckung von BTC und ETH in 80 % ± 2 Standardfehler. Auf dem Pi (Debug 73 vom 11.11.):
   7 Tage Gewinn +1,5 %, p 0,002, aber BTC 84,0 % ± 1,7 -- „besteht nicht“. Am Balken stand deshalb „Vorsprung offen“, in der Zeile
   darunter „schlägt das einfache Vergleichsmodell (p 0,002)“. Jetzt: Der Balken trägt immer die gemessene Trefferquote des Coins
   („traf 84 % (zu weit)“), der Kernsatz nennt sie, die Zeile darunter nennt Vorsprung je Horizont, das Urteil der Gesamtprüfung und
   seinen Grund.
2. **Perzentil gerundet:** ZEC zeigte „80. Perzentil“ und die Lampe „aus“ (0,796). Jetzt wird abgeschnitten; Zahl und Lampe können
   sich nicht mehr widersprechen (geprüft über alle Mittelränge für 60 bis 365 Werte).

Dazu: Der Debug-Text nennt den Zeitpunkt des nächsten Termins und den Beleg der Spanne.

**Berichtigung dieses Konzepts (mein Fehler vom 11.11.):** Die Tabelle der Klasse A führte die 7-Tage-Spanne (A2) als „belegt“. Das
stimmt so nicht. Belegt ist der *Vorsprung* des Fächers gegen das Vergleichsmodell bei 7 Tagen (CRPS +1,5 %, p 0,002). Die vorab
festgelegte *Gesamtprüfung* S1 besteht bei keinem Horizont -- bei 7 Tagen, weil das Band von BTC etwas zu weit ist. Das stand in
Debug 73 („-> besteht nicht“) und seit Oktober im README („Breite S1 besteht bei keinem Horizont“); ich habe die Zahlen übernommen
und das Urteil nicht. Folgen:
- Klasse A im strengen Sinn (vorab festgelegter Test bestanden) hat 8 Größen, nicht 9. Die Spanne bleibt das zentrale Instrument,
  aber mit dem Etikett, das stimmt: Trefferquote je Coin gemessen, Vorsprung bei 7 Tagen belegt, Gesamtprüfung nicht bestanden.
- Für BTC ist das 80-%-Band eher zu weit (traf 84 %), für PAXG deutlich zu eng (traf 67 %; bei 28 Tagen 58 %) -- bei PAXG ist das
  Risiko größer, als das Band zeigt. Für ETH, HYPE, XMR und ZEC liegt die Trefferquote in der Toleranz (79 bis 83 %).
- Die Erreich-Wahrscheinlichkeiten der Levels (A3, Prüfung S3) bestehen bei allen drei Horizonten; daran ändert sich nichts.

**Warum die Probe es nicht fand:** Die Probe-Welt des Selbsttests trug für 7 Tage ein erfundenes „besteht: True“. Der Vertragstest
lief auf der Demo-Datenbank ohne Rückblick. Jetzt trägt die Probe-Welt die Zahlen und Urteile des Pi aus Debug 73, und der
Vertragstest erzeugt S1 mit `hl_ausblick.urteil_s1` selbst -- einmal so, dass das Modul „besteht nicht“ urteilt.

**Beobachtungen, nichts geändert**
- Die Wahrscheinlichkeit eines Levels gilt ab dem Anker der Rechnung (bis zu 30 Minuten alt), der Abstand zum jetzigen Kurs. Nach
  einer schnellen Bewegung passen beide nicht mehr zusammen (XMR 12.11.: Level +1,0 % über dem Kurs mit 99 % -- vom Anker aus
  waren es +0,2 %). Der Kurs-Rechner (Stufe C2) rechnet vom jetzigen Kurs.
- Die Kerzen des S&P-500-Perp kommen alle 30 Minuten und nur abgeschlossen; die jüngste ist 50 bis 80 Minuten alt. Bis zur Grenze
  von 2 Stunden bleibt Luft für einen ausgefallenen Abruf, nicht für zwei.

## 11. Instrument „Unstaking“ bei ETH (Paket 23.100, U254; Wunsch des Nutzers vom 14.11.2026)

Der Nutzer hat beobachtet, dass auf große Abzüge aus dem Ethereum-Staking häufig Kursrückgänge folgen, und einen Indikator mit Termin
verlangt. Einzelheiten, Quellen und die vorab festgelegte Studie: `KONZEPT_Unstaking.md`.

- **Klasse B (gemessen), Nummer B12.** Die Zeitpunkte der Abzüge stehen in der Kette; das Cockpit rechnet nichts hinzu außer Summe je
  Tag, Anteil am Tagesdurchsatz, Anteil des größten Abziehers und dem Wert in USD zum frischen Kurs.
- **Anzeige, nur bei ETH:** Karte „Unstaking“ zwischen Messwerten und Kosten; dazu eine Zeile mit dem Termin der nächsten großen
  Freigabe unter dem Kernsatz. Für die anderen Coins gibt es das Instrument nicht.
- **Schwellen, fest und vorab:** großer Tag ab 28.800 ETH „frei ab“ (die Hälfte des Höchstdurchsatzes von 57.600 ETH am Tag);
  Abzieher genannt ab 10.000 ETH; Stand des Knotens höchstens 3 Stunden alt, Tagesdatei als Ersatz höchstens 2 Tage.
- **Farbe:** blau wie alle Messwerte. Keine Lampe, keine Warnfarbe. Große Tage unterscheiden sich in der Form (fett, höherer
  Balken, Punkt).
- **Prüfung der Kursfolge (seit 23.101, U255):** Unter dem Termin steht die Zeile „Folgt darauf ein Kursrückgang?“ mit dem
  gespeicherten Urteil der vorab festgelegten Prüfung -- „Noch nicht geprüft“ mit der Debug-Nummer 147, oder Datum und Wortlaut
  („nicht belegt“, „belegt …“, „zu wenige Fälle“). Der Beleg der Karte nennt Fallzahlen und Nachweisgrenze. Das Cockpit rechnet hier
  nichts; auch „belegt“ bleibt Text ohne Farbe, bis die Lampe eigens festgelegt ist. Seit 23.102 nennen Zeile und Beleg den letzten
  bewerteten Tag („Geprüft am 15.11.2026 (Wellen bis 25.10.2026): nicht belegt.“) -- damit niemand eine Welle für geprüft hält, die
  nicht in den Daten war.
- **Stehengebliebene Tagesdatei (seit 23.102):** Fehlt die Gegenseite, weil die Tagesdatei der Quelle älter als 2 Tage ist, steht in
  der Karte „Gegenseite …: zurzeit kein Wert, weil die Tagesdatei der Quelle am … endet.“ statt nichts. Die Dauer des
  Auszahlungslaufs nennt dann den Tag, von dem die Zahl der Validatoren stammt. Der alte Wert der Gegenseite wird nicht gezeigt.
- **Ohne Quelle kein Wert:** Fehlt der Stand, ist die Karte blass und nennt den Grund; ein Ersatz aus der Tagesdatei trägt den
  Vermerk „geschätzt“.
- **Aufstieg zu Klasse A** nur über die Studie U255 (`KONZEPT_Unstaking.md` 6, 6a und 6b). Erster Lauf am 15.11.2026: nicht belegt
  -- das Instrument bleibt Klasse B. Bei „belegt“ in einer späteren Prüfung: eigene Lampe und ein Platz in der Prognose, eigens
  festzulegen.
- **Proben:** Abgleich und Schwellen in `hl_cockpit.py --selbsttest`, Vertrag mit `hl_staking` auf einer vom Modul gefüllten
  Datenbank; Zeichnung in `hl_viz.py --selbsttest-cockpit`; Browser-Probe bei 360 bis 1280 px; Mutationen beim Bau.
- **Abruf vom Pi aus:** gelingt (Debug 145 vom 15.11.2026: Knoten 4,9 MB in 1,5 s). Die Tagesdatei kommt an, endet aber am
  25.10.2026 (`KONZEPT_Unstaking.md` 3a).

## 12. Karte „Unstaking · Verlauf“ bei ETH (Paket 23.104, U260; Frage des Nutzers vom 15.11.2026)

Der Nutzer fragte nach dem Einspielen von 23.103: „Wo sehe ich den Chart mit dem Unstaking?“ Die Karte „Unstaking“ zeigt den Stand
und die nächsten Tage; einen Verlauf über die Zeit gab es nicht. Auf die Frage, ob er dazukommen soll, wählte er „Ja, bauen“.
Einzelheiten: `KONZEPT_Unstaking.md` 4a.

- **Klasse B (gemessen), Nummer B13.** Schlange der Abzüge und ETH-Kurs je UTC-Tag seit Mai 2023. Das Cockpit rechnet nichts hinzu
  außer der Lage je Tag, Rundung und den Zeiträumen ohne Daten.
- **Anzeige, nur bei ETH:** eigene Karte zwischen „Unstaking“ und „Kosten“ -- zwei Felder mit gemeinsamer Zeitachse (Kurs oben,
  Schlange unten, ab null), **keine zweite Skala in einem Feld**; Ausschnitt 3 Monate, 1 Jahr (beim Öffnen) oder alles; graue Fläche,
  wo die Schlange drei Tage oder länger fehlt.
- **Wellen der Prüfung als Marken:** die Fälle des gespeicherten Urteils (U255), nicht neu bestimmt. Antippen zeigt den Tag mit
  Schlange und Kurs; nahe einer Marke den Satz der Welle. Dazu die Wellen des Ausschnitts als aufklappbare Liste mit den Zahlen aus
  Debug 147.
- **Kein Urteil in der Karte außer dem gespeicherten:** Unter dem Bild steht der Satz der Prüfung (Mittel nach den Wellen, Mittel
  aller Tage, „nicht belegt“ mit p nach Holm) und „Der Verlauf allein belegt keinen Zusammenhang.“ Keine Lampe, keine Warnfarbe, kein
  Pfeil -- auch nicht bei „belegt“.
- **Farben der Linien:** Schlange `#388bfd`, Kurs `#bb8009` -- die nächsten dunkleren Stufen des Blau und des Gelb des Cockpits, weil
  diese für zwei Linien auf der Kartenfläche zu hell sind (geprüft: Helligkeit, Unterscheidbarkeit bei Farbsehschwäche, Kontrast).
  Text trägt nie die Farbe einer Linie; Marken und Kreuz sind neutral grau.
- **Daten:** `/cockpit/unstaking` (`hl_cockpit.verlauf_nutzlast` aus `hl_staking_studie.verlauf`), 10 min im Zwischenspeicher; das
  Skript holt sie nur bei ETH, nach dem Cockpit, und frühestens nach 30 min wieder. Debug 143 nennt den Umfang unter ETH.
- **Ohne Quelle kein Bild:** Fehlt `staking.db` oder hat sie noch keinen Tag, ist die Karte blass und nennt den Grund; fehlt nur der
  Kurs, bleibt die Schlange und der Grund steht darunter.
- **Proben:** Antwort und Texte in `hl_cockpit.py --selbsttest`, Vertrag mit `hl_staking_studie`; Endpunkt und Zeichnung in einem
  nachgebauten Dokument in `hl_viz.py --selbsttest-cockpit`; Browser-Probe bei 360 bis 1280 px; Mutationen beim Bau.

## 13. Karte „Kurs-Rechner“ (Paket 23.105, U245 Stufe C2 -- erster Teil; Wahl des Nutzers vom 16.11.2026)

Am 16.11.2026 lag die Sammeldatei des Pi vor (dort lief noch 23.103). Auf die Frage zum Anklicken, woran inzwischen gearbeitet werden
soll, wählte der Nutzer „Kurs-Rechner bauen“ (der Vorschlag). Den festen Eintrag für den eigenen Liquidationspreis, nur im Browser
gemerkt, hatte er am 12.11. entschieden (Abschnitt 7 Punkt 4).

**Was die Karte zeigt** (bei jedem Coin, zwischen „Levels“ und „Markt-Messwerte“; Klasse A: A3 und A4)
- **Ein Kurs wird eingetippt** („61.500“, „65,39“; Eingabetaste oder „Rechnen“). Die Karte zeigt für ihn vier Zahlen: die
  Wahrscheinlichkeit, dass er **vom jetzigen Kurs aus** in 1 Stunde, in 4 Stunden, in 7 Tagen und in 14 Tagen **mindestens einmal
  berührt** wird -- je Frist Balken und ganze Prozent. Unter 0,5 % steht „unter 1 %“, ab 99,5 % „über 99 %“; 0 % und 100 % stehen nie
  da. Der jetzige Kurs selbst heißt „erreicht“.
- **Merken:** bis zu 6 Kurse je Coin unter einem von vier Namen -- Liquidation, Stopp, Limit, Marke. Sie liegen nur in diesem Browser
  (`localStorage`, Schlüssel `ck_rechner_v1`). Zum Rechnen gehen sie an das eigene Dashboard und werden dort nicht gespeichert (kein
  Zwischenspeicher, kein Protokoll). Die Namen sind Namen des Nutzers: Das Cockpit kennt keine Position.
- **Darunter** die Kurzfassung des Belegs; aufklappbar „Beleg und Grenzen“ mit den Einzelheiten und dem Stand der Rechnung.
- **Keine Wertung:** keine Warnfarbe, kein Pfeil, keine Empfehlung. Die Zahl folgt allein aus Abstand und Schwankung -- nicht aus der
  Art des Niveaus (das prüft U244) und nicht aus einer Richtung (die ist für kein Zeitfenster belegt).

**Rechnung** (beim Bau vorab festgelegt; gerechnet wird auf dem Server unter `/cockpit/rechner`, `hl_cockpit.rechner_nutzlast`)
1. **1 und 4 Stunden (A4):** das Nullmodell des Magnet-Tests U110, `hl_kaskade.p_ueber(|ln(Kurs ÷ jetzt)|, c, σ, τ)`. c und τ je Coin
   und Frist kommen aus der letzten Rechnung des Magnet-Tests (Prognosespeicher, nur gelesen; höchstens 3 Tage alt, nur aus der
   geltenden Modellversion). σ ist die Schwankung über 4 Stunden aus den 15-Minuten-Renditen der letzten 7 Tage (`hl_anker.Markt`,
   wie im Magnet-Test), mal √(h ÷ 4) -- über 1 Stunde also die Hälfte.
2. **7 und 14 Tage (A3):** die Verteilung des laufenden Hochs (Kurs über dem jetzigen) oder Tiefs (Kurs darunter) aus der jüngsten
   Rechnung des Ausblicks, **angelegt am jetzigen Kurs**. Der Ausblick legt sie seit 23.105 je Coin ab (`au_meta` „lauf“: 199
   Quantile von 0,5 % bis 99,5 % je Horizont und Seite, dazu Anker, Kurs und Zahl der Fenster N der Rechnung; rund 76 kB für sechs
   Coins). Sie steht bewusst nicht in `au_prognose`: Die Zeilen der 6-Stunden-Anker bleiben dort für immer. Aus den Quantilen ergibt
   sich dieselbe Zahl wie aus der vollen Rechnung `erreichen()` auf höchstens 0,5 Prozentpunkte + 1/N; jenseits des Rasters ist nur
   die Schranke bekannt („unter 1 %“, „über 99 %“). Die Rechnung darf höchstens 2 Tage alt sein.
3. **Eine längere Frist ist nie unwahrscheinlicher als eine kürzere.** Stunden und Tage rechnen mit getrennten Modellen; wo die
   längere Frist weniger ergäbe, gilt der Wert der kürzeren. Ändert das die gezeigte Zahl, steht ein Vermerk beim Kurs.
4. **Der jetzige Kurs** ist die jüngste Minutenkerze des Recorders und gilt 5 Minuten als frisch. Ohne frischen Kurs rechnet der
   Rechner nicht.
5. **Bereich:** ein Fünftel bis das Fünffache des jetzigen Kurses; höchstens 8 Kurse je Anfrage.
6. **Vermerk „nicht geprüft“:** bei den Stunden jenseits von 3 üblichen Schwankungen der Frist (die Zufallsniveaus des Magnet-Tests
   reichen bis 3 σ), bei den Tagen jenseits von 30 % Abstand (die Prüfung S3 des Ausblicks umfasst Prüfniveaus bis zum Zweifachen der
   Schwankung der Frist und Swing-Niveaus bis 30 %). Die Zahl steht trotzdem da.
7. **Hinweis „ungenauer“:** wenn bei der Probe des Nullmodells an Zufallsniveaus mehr als einer von acht Abständen außerhalb von 2
   Standardfehlern lag (am 11.11.2026 bei HYPE über 1 Stunde: 5 von 8 innerhalb).
8. **Hinweis zur Trefferquote des Bands:** Die Prüfung S3 der Erreich-Wahrscheinlichkeiten läuft über alle Coins zusammen. Je Coin
   gemessen ist die Trefferquote des 80-%-Bands (Rückblick S1, wie an der Karte „Spanne“). Liegt sie für den Coin außerhalb von 80 %
   ± 2 Standardfehler, steht bei den Tagen ein Hinweis mit der Folge: zu eng -- der Kurs verließ das Band öfter als erwartet, die
   Wahrscheinlichkeiten können zu niedrig sein (am 11.11.2026 bei PAXG: 67 % über 7 Tage, 66 % über 14 Tage); zu weit -- sie können
   zu hoch sein (BTC: 84 % und 85 %). Die Zahlen selbst werden nicht verändert.
9. **Ohne Quelle kein Wert:** Fehlt das Nullmodell einer Frist, die Schwankung oder die Verteilung, bleibt genau diese Frist leer
   („—“) und der Grund steht da. Nichts wird geschätzt.

**Belege, wie die Karte sie nennt**
- Stunden: die Probe des Nullmodells an Zufallsniveaus je Frist („1 h 8 von 8, 4 h 8 von 8 innerhalb von 2 Standardfehlern“), die
  Schwankung über 4 Stunden, das Alter der Rechnung. Am 11.11.2026 (Debug 51): BTC über 1 Stunde 1 σ 22,2 % vorhergesagt, 21,4 %
  eingetreten.
- Tage: der Anker der Rechnung des Ausblicks und das Urteil S3 aus dem Rückblick (am 11.11.2026: 7 Tage Brier-Skill +6,3 %, Steigung
  0,96; 14 Tage +3,7 %, 0,92 -- beide „besteht“). Ohne Rückblick steht „noch nicht geprüft“ da.

**Verhältnis zur Karte „Levels“.** „Levels“ zeigt die Wahrscheinlichkeit ab dem Anker der Rechnung, vom damaligen Kurs aus
(Abschnitt 10, Beobachtungen). Der Kurs-Rechner rechnet vom jetzigen Kurs. Nach einer schnellen Bewegung seit der Rechnung weichen
beide voneinander ab -- für „jetzt“ gilt der Rechner. Bei gleichem Abstand und gleicher Rechnung stimmen sie auf einen Prozentpunkt
überein.

**Bedienung.** Solange im Eingabefeld getippt wird, zeichnet das Cockpit nicht neu (das Feld verlöre sonst Text und Tastatur) --
höchstens 15 Sekunden nach dem letzten Tastendruck; wer das Feld verlässt, sieht das Zurückgestellte nach 0,4 Sekunden. Gemerkte
Kurse rechnet das Skript nach jedem Laden des Cockpits nach, dieselbe Abfrage frühestens nach 50 Sekunden wieder. Erlaubt der
Browser kein Speichern, gilt ein gemerkter Kurs bis zum Neuladen der Seite, und die Karte sagt das.

**Debug 143** nennt je Coin acht Beispielkurse (±1, ±2, ±5 und ±10 % vom jetzigen Kurs) mit ihren vier Zahlen, die Gründe für
fehlende Fristen, Hinweise und Belege; am Ende einmal den allgemeinen Satz.

**Proben** (Abschnitt 6 Punkt 6 und mehr)
- `hl_cockpit.py --selbsttest`: Stunden gleich `hl_kaskade.p_ueber` (und von Hand: mit c = 1, τ = 0 das Spiegelungsprinzip, 1 σ
  31,7 %), Tage gleich `hl_ausblick.erreichen_aus_lauf` und auf 0,5 Punkte + 1/N gleich `erreichen()`; jetziger Kurs „erreicht“;
  längere Frist nie unwahrscheinlicher (mit und ohne Vermerk, auch an der Schranke); Vermerke an ihren Grenzen; Hinweis zur
  Trefferquote des Bands; Schreibweise; Grenzen der Eingabe; ohne Quelle kein Wert; Belege; Text für Debug 143; über 112 Kurse fällt
  die Wahrscheinlichkeit mit dem Abstand und steigt mit der Frist.
- **Vertrag, Tage:** `hl_ausblick.prognose` auf der Demo-Welt legt die Verteilung ab, der Rechner gibt für jedes Niveau der Rechnung
  im selben Abstand dieselbe Wahrscheinlichkeit. Ein Rückblick in der Datenbank mit dem S1 aus `hl_ausblick.urteil_s1` (Band von BTC
  zu weit) erreicht den Rechner: Hinweis bei BTC, keiner bei ETH.
- **Vertrag, Stunden, mit Positivkontrolle:** Auf einem Probe-Markt rechnet `hl_magnet.kalibrieren` das Nullmodell selbst. An den
  acht Zufallsabständen trifft der Rechner die dort eingetretene Berührquote auf höchstens 2,5 Standardfehler und die Vorhersage des
  Tests auf höchstens 2 Punkte (über 1 und 4 Stunden); der Prognosespeicher bleibt dabei unverändert.
- `hl_ausblick.py --selbsttest`: Erreichen aus den Quantilen gegen `erreichen()` für beide Seiten und alle Horizonte, die Ränder des
  Rasters mit ihrer Lage; Ablage je Coin (älterer Anker überschreibt nicht, derselbe und ein neuerer schon), nicht in `au_prognose`.
- `hl_viz.py --selbsttest-cockpit`: der Endpunkt (leere Datenbank, fremder Coin, Kürzen der Anfrage, kein Zwischenspeicher) und die
  Karte in einem nachgebauten Dokument: Eingabe lesen (deutsche Schreibweise zuerst), Rechnen, Merken und Entfernen mit
  nachgebautem Speicher (auch kaputt oder gesperrt), Abfragen und ihre Drossel, Wechsel des Coins während einer laufenden Abfrage,
  Zurückstellen des Zeichnens beim Tippen, Maskierung.
- Browser-Probe bei 360, 390, 430 und 1280 px; Mutationen beim Bau (Zahlen in der Übergabe, Abschnitt zu Paket 23.105).

**Grenzen**
- „Berührt“ heißt: Der Kurs erreicht die Marke mindestens einmal. Ob er darüber hinaus schließt, sagt die Zahl nicht.
- Der Name „Liquidation“ ist nur ein Name. Für eine Liquidation zählt bei Hyperliquid der Mark-Preis (aus Kursen anderer Börsen und
  dem eigenen Orderbuch), nicht der Schluss der Minutenkerze, von dem der Rechner ausgeht
  (https://hyperliquid.gitbook.io/hyperliquid-docs/trading/liquidations, gelesen 16.11.2026). Die Karte sagt das unter „Beleg und
  Grenzen“.
- Die Tage rechnen mit der Verteilung der letzten Rechnung des Ausblicks (stündlich; bei offenem Abschnitt alle 30 Minuten). Zwischen
  Anker und jetzt vergangene Zeit ist nicht abgezogen.
- Die Stunden rechnen ohne Wochenende, Termin und Tageszeit: σ ist der Mittelwert der letzten 7 Tage.
- Geprüft ist das Nullmodell an Zufallsniveaus bis 3 σ, die Tage im Rückblick des Ausblicks -- nicht dieser Rechner mit Kursen des
  Nutzers auf dem Pi. Die eigene Bilanz des Rechners wäre eine neue Prüfung.
- Die Tage sind je Coin nicht eigens geprüft (S3 läuft über alle Coins zusammen). Der Hinweis zur Trefferquote des Bands ist ein
  Schluss aus S1, keine eigene Messung: Ist das Band zu eng, kann das an einer zu kleinen Schwankung liegen oder an einem Trend,
  den die Rechnung nicht kennt -- dann wäre nur eine Seite zu niedrig.
- 28 Tage zeigt die Karte nicht: Vier Fristen passen in eine Zeile am Handy; die Verteilung für 28 Tage liegt mit ab.

**Offen aus Stufe C2:** Perzentil-Skalen für Funding und Taker-Varianz, Liquidationsdichte, Betriebslampe mit API-Gewicht und
Diensten.
