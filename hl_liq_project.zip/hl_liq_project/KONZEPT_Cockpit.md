# KONZEPT Cockpit (U245) — das Dashboard als Cockpit: Instrumente nur aus belastbaren Daten

Stand 11.11.2026, abends (Fable 5.2). Anlass: Wunsch des Nutzers vom 11.11. 20:58 — „Backup soll unter System verschoben
werden … Das Dashboard soll als Cockpit umgestaltet werden, weiterhin mit Zahlen, aber auch visuellen Indikatoren. Prüfe, welche
Daten aus dem ganzen Projekt zusätzlich belastbar sind.“ **Status: Konzept und Entwurf; gebaut ist Stufe C0, erster Teil (Paket 23.96): die Kacheln „Letztes Backup“ und „Datenbank“ stehen im Abschnitt System.**
Grundlage: Paket 23.95, Sammeldatei und Debug 73 vom 11.11., `AUDIT_Gesamt_11-11-2026.md`, die Urteile in der Übergabe.
Entwurf (zwei Handy-Ansichten, Cockpit und System mit Backup; Werte vom 11.11., eckige Klammern = Wert in keinem Bericht):
https://claude.ai/artifact/TGq3YnxU1TQDzMAZ1FdWHR

---

## 0. Kurzfassung

- **Regel:** Ein Instrument im Cockpit bekommt nur, was belegt oder sauber gemessen ist. Jedes Instrument zeigt seinen Beleg.
- **Drei Klassen:** A belegt (vorab festgelegter Test bestanden) · B gemessen (verlässlicher Messwert, keine Vorhersage) ·
  C nicht belegt (bleibt in der Werkstatt, nie im Cockpit).
- **Ergebnis der Prüfung:** 9 Größen der Klasse A, 11 der Klasse B. Drei belastbare Größen zeigt das Dashboard heute gar nicht als
  Anzeige: die Erreich-Wahrscheinlichkeit über 1 h und 4 h, die erwartete 4-h-Bewegung und die Kostenschwelle.
- **Kein Richtungspfeil im Cockpit.** Richtung ist über kein Fenster belegt (Audit, Debug 73).
- **Backup:** Die Kacheln „Letztes Backup“ und „Datenbank“ stehen heute in der Kennzahlenleiste zwischen Marktwerten. Sie
  wandern in den Abschnitt System, wo der Backup-Block (`#speicher`) seit 23.95 schon steht.

## 1. Heutiger Aufbau (23.95)

Eine Seite mit 23 einklappbaren Abschnitten: Live-Chart, Chartbild, Ausblick, Konfluenz, AI-Prognose, Treiberfamilien,
TradeLabor, Notbremse, Makro, Prognosemärkte, Volatilität, Orders, Heatmap, Momentaufnahme, Wale, Leaderboard (3), Aktive Profis,
Netzwerkstatus, Aktualisierung, Debug, System. Darüber eine Kennzahlenleiste, unter anderem mit 60-Minuten-Trend, MA 50 Wochen,
MA 200 Tage, Letztes Backup, Datenbank, Wal-Position, Wal-Flow, Leaderboard-Trend, Coinbase-Spot, Konfluenz.

Befund: Belegtes (Ausblick, Volatilität) und Unbelegtes (AI-Prognose, Konfluenz, Wal-Flow) stehen gleichrangig nebeneinander.
Die Kennzahlenleiste zeigt überwiegend Größen der Klasse C.

## 2. Prüfung: was belastbar ist

### Klasse A — belegt

| Nr. | Größe | Beleg | Im Dashboard heute |
|---|---|---|---|
| A1 | Niveau der Schwankung, 1–4 Wochen | V1 belegt 30.10. (p Holm 0,0292) | Abschnitt Volatilität |
| A2 | Spanne 7 Tage | S1: CRPS +1,5 % (p 0,002); 80-%-Band trifft BTC 84,0, ETH 80,4, HYPE 80,7, XMR 82,9, ZEC 79,0 % | Abschnitt Ausblick |
| A3 | Erreich-Wahrscheinlichkeit von Kursen, 7 / 14 / 28 Tage | S3 besteht: Brier-Skill +6,2 / +3,7 / +1,5 %, Steigung 0,96 / 0,92 / 0,89 | Abschnitt Ausblick |
| A4 | Erreich-Wahrscheinlichkeit über 1 h und 4 h | Nullmodell von U110 an Zufallsniveaus, BTC 1 h: 1 σ 22,2 → 21,4 %, 2 σ 6,0 → 5,9 %, 3 σ 2,0 → 2,1 % | **nein** (nur im Testbericht) |
| A5 | Erwartete 4-h-Bewegung E\|r\| | Kriterium 5 (vorab 13.10.): Verhältnis 1,02 ± 0,05, n 1.390 in 232 Zeitblöcken | **nein** (nur im Fusion-Bericht und in einem Tooltip) |
| A6 | Hebel-Warnung H1 | Konten ≥ 3: Rücksetzer in 7 Tagen 20,3 % statt 7,3 %, p Holm 0,012; in 4 von 5 Fällen folgte keiner | Satz im Chartbild |
| A7 | Datentage | U154: Varianz in den 2 h nach CPI × 2,45, nach Arbeitsmarktbericht × 1,9 | Hinweis an Datentagen |
| A8 | Wochenende | Varianz Sa/So = 0,68 × Werktag (2.494 Tage) | in der Spanne eingerechnet |
| A9 | Kopplung an den S&P 500 | S4: Abhängigkeit belegt (p 0,003) | Szenarien im Ausblick |

Einschränkungen, die am Instrument stehen müssen:
- A2: Bei 14 Tagen ist der Vorsprung nicht belegt (+0,4 %, p 0,18), bei 28 Tagen keiner (−0,7 %). PAXG trifft nur 58–67 %.
- A3: Die Zahl folgt allein aus dem Abstand; die Niveau-Art prüft U244.
- A9: Unter Aktienstress ist die bedingte Verteilung nicht kalibriert (PIT p 0,014). Gezeigt wird die Kopplung, nicht das Szenario.

Aus A5 folgt rechnerisch die **Kostenschwelle** (nötige Trefferquote; BTC 11.11.: 4 h 58,9 % Taker / 52,9 % Maker, 24 h 53,5 /
51,1 %). Auch sie steht heute nur im Bericht und im Tooltip der Fusion-Kachel, auf dem Handy also gar nicht.

Die Perzentile der Klasse B rechnet das Chartbild schon (Mittelrang unter den letzten 90 Tagesständen, wie U142); das Cockpit
übernimmt diese Rechnung.

### Klasse B — gemessen

| Nr. | Größe | Anzeige | Vorbehalt |
|---|---|---|---|
| B1 | Kurs, Mark, Oracle, Prämie | Zahl | — |
| B2 | Funding Hyperliquid | Perzentil 90 Tage | Fremdbörsen erst nach U23 |
| B3 | Open Interest | Perzentil 90 Tage | — |
| B4 | Realisierte Schwankung 7 / 30 Tage, DVOL | Zahl neben A1 | DVOL als Zusatz nicht belegt (V4) |
| B5 | Kontenquote Binance | Skala mit Marke bei 3 | Schwelle = A6 |
| B6 | Liquidationsdichte nahe am Kurs | Balken ± 3 % | Abdeckung BTC 27 % des OI; 85 % der bekannten Positionen zu alt |
| B7 | Wartende Orders, Stops, Wände | Liste | Momentaufnahme, Konten ab 250k USD |
| B8 | Spread | Zahl | Buchtiefe erst nach N1 (heute nur 10 Stufen) |
| B9 | Varianz des Taker-Flusses | Skala, unterstes Dezil markiert | Vorläufer nur im Mittel, kein Einzelalarm |
| B10 | Termine: CPI, Arbeitsmarkt, Fed, Optionsverfall | Countdown | — |
| B11 | Betrieb: Dienste, API-Gewicht, Rückstand, Speicher, Backup | Lampe + Abschnitt System | — |

### Klasse C — nicht belegt, nicht im Cockpit

AI-Prognose (P(aufwärts), Bias, „Konfidenz“, 7-Tage-Pfad, Kauf- und Verkaufspreis) · Konfluenz (49 % richtig bei 45 % Zufall,
n 35) · Smart Money, Elite, Wale, Leaderboard, Pool als Richtungsanzeiger (das Timing-Urteil der Darwin-Liste steht am 18.11. an)
· Heatmap als Magnet oder Anker · ETF-Flüsse und Makro-Zonen als Signal (3 von 322 Tests belegt, erwartet wären 16 aus Zufall) ·
Wahrscheinlichkeit einer „volatilen Woche“ (nicht besser als die Grundrate) · Szenarien unter Aktienstress · Kalendereffekte bei
XMR (kippen an der Holm-Grenze) · alles aus Labor und Engine, solange N1 offen ist.

Diese Abschnitte bleiben erhalten, unter „Werkstatt“, mit dem Vermerk „nicht belegt“.

## 3. Aufbau des Cockpits (Handy zuerst)

Von oben nach unten, ein Bildschirm je Block:

1. **Kopf:** Coin, Kurs, Datenalter, eine Betriebslampe (führt zu System).
2. **Risikoleiste, fünf Lampen:** Hebel (A6) · Termin (A7, B10) · Wochenende (A8) · Aktien (A9) · Schwankung (A1 als Perzentil).
   Jede Lampe: aus, gelb oder — nur wo ein Test es trägt — rot; beim Antippen der Beleg.
3. **Schwankung:** Bogen-Instrument mit der erwarteten Schwankung für 7 Tage und ihrem Perzentil gegen 365 Tage; daneben A5
   („in 4 h typisch ± x %“), realisierte 7 und 30 Tage, DVOL.
4. **Spanne:** waagrechter Balken 50 / 80 / 90 % für 7 Tage mit Kursmarke, darunter 14 Tage schmaler, 28 Tage als Rahmen.
   Beschriftung mit gemessener Trefferquote.
5. **Levels:** die nächsten Niveaus oben und unten, je mit Balken für 1 und 2 Wochen und dem Abstand in %; nach U244 die
   Bilanz der Art.
6. **Erreich-Rechner (neu, aus A4 und A3):** Kurs eintippen → Wahrscheinlichkeit, ihn in 1 h, 4 h, 7 und 14 Tagen zu erreichen.
   Gedacht für Stopps, Limits und den eigenen Liquidationspreis.
7. **Markt-Messwerte:** kleine Perzentil-Skalen für B2, B3, B5, B9; Liquidationsdichte B6 mit der Abdeckung daneben.
8. **Kosten:** nötige Trefferquote für 4 h und 24 h, Taker und Maker.
9. **Werkstatt** (alle heutigen Abschnitte der Klasse C, eingeklappt) und **System** (Backup, Datenbank, Speicher, Netzwerk,
   Aktualisierung, Debug).

## 4. Regeln für jedes Instrument

- **Beleg sichtbar:** eine Zeile unter dem Instrument, etwa „geprüft: 80-%-Band traf 84 % (Rückblick 08.11.)“.
- **Farbe nur für Klasse A.** Klasse B ist neutral (grau, blau) und zeigt das Perzentil; kein Grün/Rot im Sinn von gut/schlecht.
- **Keine Pfeile, keine Empfehlungswörter.** Die Liste der verbotenen Wörter aus Chartbild und Ausblick gilt.
- **Frische:** Ist die Quelle älter als ihre Grenze, wird das Instrument grau und nennt den Stand.
- **Nicht nur Farbe:** Jede Lampe trägt ein Wort; Zustände unterscheiden sich auch in der Form.
- **Zahlen bleiben.** Jedes Instrument zeigt seinen Zahlenwert; die Grafik ersetzt ihn nicht.
- **Schwellen fest und vorab:** H1 ab Kontenquote 3; Termin 24 h vor bis 2 h nach der Veröffentlichung; Schwankung gelb ab dem
  80., rot ab dem 95. Perzentil; Betrieb gelb bei API-Gewicht über 85 % oder Backup älter als 36 h, rot bei Dienst aus.

## 5. Stufen

| Stufe | Inhalt | Paket |
|---|---|---|
| C0 | Kacheln „Letztes Backup“ und „Datenbank“ aus der Kennzahlenleiste in System, über den Speicherorten; ein Problem zeigt die Kopfzeile des Abschnitts auch zugeklappt („⚠ Backup“, „⚠ Datenbank“) | **gebaut mit 23.96** (Selbsttest Speicherorte S15, S16; Browserprobe bei 390 px) |
| C0b | Netzwerk, Aktualisierung, Debug und System als Gruppe „Betrieb“ | mit C1 — ändert Reihenfolge und Navigation der Abschnitte, gehört deshalb zum Umbau der Seite |
| C1 | Cockpit als Startabschnitt aus vorhandenen Endpunkten (Ausblick, Volatilität, Chartbild, Termine, Fusion, System); nur lesend, keine neue Rechnung; alte Abschnitte darunter als Werkstatt | eigenes Paket nach 23.96 |
| C2 | Erreich-Rechner (A4, A3), Perzentil-Skalen, Betriebslampe, Kostenblock | dasselbe oder das nächste |
| C3 | nach N1, U23 und U244: Buchtiefe und Impact, Funding-Spread, Bilanz der Niveau-Art | später |

## 6. Proben

1. Abgleich: Jede Zahl im Cockpit ist gleich der Zahl im Quellbericht desselben Zeitpunkts (Ausblick, Volatilität, Fusion).
2. Frische: Quelle künstlich gealtert → Instrument grau mit Stand.
3. Browserprobe bei 360 bis 430 px Breite und am Desktop; kein waagrechtes Scrollen.
4. Wortprobe: keine Empfehlungswörter, kein Pfeil.
5. Mutation je Lampe: Schwelle verschoben → Probe schlägt an.
6. Der Erreich-Rechner trifft an Zufallsniveaus die Quoten von U110 (Positivkontrolle) und liefert für den aktuellen Kurs 100 %.

## 7. Entscheidungen beim Nutzer

Stand 11.11. 21:36: Der Nutzer antwortete auf dieses Konzept mit „Ok“ und fragte nach dem Paket. Das „Ok“ ist keine Einzelantwort auf die fünf Punkte; die Vorschläge gelten deshalb nur vorläufig. Vor dem Bau von C1 und C2 werden sie einzeln und in Klartext zum Anklicken vorgelegt.

1. **Ort:** Cockpit als Startabschnitt derselben Seite, alte Abschnitte eingeklappt darunter? Vorschlag: ja.
2. **Coins:** ein Coin groß, dazu ein Streifen mit allen sechs (Spanne 7 Tage und Lampen)? Vorschlag: ja.
3. **Unbelegtes:** AI-Prognose, Kauf- und Verkaufspreis, Konfluenz und die Kacheln zu Walen aus der Hauptansicht nehmen und nur
   in der Werkstatt zeigen? Vorschlag: ja.
4. **Erreich-Rechner** mit eigenem Liquidationspreis als festem Eintrag? Vorschlag: ja, lokal im Browser gespeichert.
5. **Reihenfolge:** C0 mit 23.96, C1 und C2 als eigenes Paket danach, vor oder nach U244? Vorschlag: C1 und C2 vor U244 — das
   Cockpit braucht keine neue Studie.

## 8. Abgrenzung

- Das Cockpit rechnet nichts Neues außer dem Erreich-Rechner und den Perzentilen. Es ändert keine Prognose, kein Urteil, kein
  Labor.
- Was heute Klasse C ist, kann aufsteigen: Ein bestandener, vorab festgelegter Test macht aus einer Werkstatt-Größe ein Instrument
  (zum Beispiel eine Niveau-Art nach U244 oder der Rücklauf nach Liquidationswellen nach U204).
