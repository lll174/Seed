# KONZEPT Cockpit (U245) — das Dashboard als Cockpit: Instrumente nur aus belastbaren Daten

Stand 11.11.2026, abends (Fable 5.2). Anlass: Wunsch des Nutzers vom 11.11. 20:58 — „Backup soll unter System verschoben
werden … Das Dashboard soll als Cockpit umgestaltet werden, weiterhin mit Zahlen, aber auch visuellen Indikatoren. Prüfe, welche
Daten aus dem ganzen Projekt zusätzlich belastbar sind.“ **Status: gebaut sind Stufe C0 (Paket 23.96: die Kacheln „Letztes Backup“ und „Datenbank“ im Abschnitt System) und die Stufen C0b und C1 (Paket 23.98, 12.11.2026: Cockpit oben auf der Hauptseite, Gruppen „Werkstatt“ und „Betrieb“; Abschnitt 9). Offen: C2 (Kurs-Rechner und der Rest), C3. Berichtigung nach der ersten Prüfung auf echten Daten: Paket 23.99, Abschnitt 10 -- die 7-Tage-Spanne ist nicht „belegt“ im strengen Sinn. Seit Paket 23.100 (U254): Instrument „Unstaking“ bei ETH, Abschnitt 11.**
Grundlage: Paket 23.95, Sammeldatei und Debug 73 vom 11.11., `AUDIT_Gesamt_11-11-2026.md`, die Urteile in der Übergabe.
Entwurf (zwei Handy-Ansichten, Cockpit und System mit Backup; Werte vom 11.11., eckige Klammern = Wert in keinem Bericht):
https://claude.ai/artifact/TGq3YnxU1TQDzMAZ1FdWHR

---

## 0. Kurzfassung

- **Regel:** Ein Instrument im Cockpit bekommt nur, was belegt oder sauber gemessen ist. Jedes Instrument zeigt seinen Beleg.
- **Drei Klassen:** A belegt (vorab festgelegter Test bestanden) · B gemessen (verlässlicher Messwert, keine Vorhersage) ·
  C nicht belegt (bleibt in der Werkstatt, nie im Cockpit).
- **Ergebnis der Prüfung:** 9 Größen der Klasse A, 11 der Klasse B. *Berichtigt am 12.11. (Abschnitt 10): 8 Größen der Klasse A; die 7-Tage-Spanne (A2) hat einen belegten Vorsprung, ihre Gesamtprüfung S1 besteht aber nicht.* Drei belastbare Größen zeigt das Dashboard heute gar nicht als
  Anzeige: die Erreich-Wahrscheinlichkeit über 1 h und 4 h, die erwartete 4-h-Bewegung und die Kostenschwelle.
- **Kein Richtungspfeil im Cockpit.** Richtung ist über kein Fenster belegt (Audit, Debug 73).
- **Backup:** Die Kacheln „Letztes Backup“ und „Datenbank“ stehen heute in der Kennzahlenleiste zwischen Marktwerten. Sie
  wandern in den Abschnitt System, wo der Backup-Block (`#speicher`) seit 23.95 schon steht.

## 1. Heutiger Aufbau (23.95)

Eine Seite mit 23 einklappbaren Abschnitten: Live-Chart, Chartbild, Ausblick, Konfluenz, AI-Prognose, Treiberfamilien,
TradeLabor, Notbremse, Makro, Prognosemärkte, Volatilität, Orders, Heatmap, Momentaufnahme, Wale, Leaderboard (3), Aktive Profis,
Netzwerkstatus, Aktualisierung, Debug, System. Darüber eine Kennzahlenleiste, unter anderem mit 60-Minuten-Trend, MA 50 Wochen,
MA 200 Tage, Letztes Backup, Datenbank, Wal-Position, Wal-Flow, Leaderboard-Trend, Coinbase-Spot, Konfluenz.

Befund: Belegtes (Ausblick, Volatilität) und Unbelegtes (AI-Prognose, Konfluenz, Wal-Flow) stehen gleichrangig nebeneinander.
Die Kennzahlenleiste zeigt überwiegend Größen der Klasse C.

## 2. Prüfung: was belastbar ist

### Klasse A — belegt

| Nr. | Größe | Beleg | Im Dashboard heute |
|---|---|---|---|
| A1 | Niveau der Schwankung, 1–4 Wochen | V1 belegt 30.10. (p Holm 0,0292) | Abschnitt Volatilität |
| A2 | Spanne 7 Tage | S1: CRPS +1,5 % (p 0,002); 80-%-Band trifft BTC 84,0, ETH 80,4, HYPE 80,7, XMR 82,9, ZEC 79,0 %. **Berichtigung 12.11.: Die Gesamtprüfung S1 lautet „besteht nicht“ -- das Band von BTC liegt mit 84,0 % ± 1,7 außerhalb von 80 % ± 2 Standardfehler (zu weit). Belegt ist nur der Vorsprung gegen das Vergleichsmodell; siehe Abschnitt 10** | Abschnitt Ausblick |
| A3 | Erreich-Wahrscheinlichkeit von Kursen, 7 / 14 / 28 Tage | S3 besteht: Brier-Skill +6,2 / +3,7 / +1,5 %, Steigung 0,96 / 0,92 / 0,89 | Abschnitt Ausblick |
| A4 | Erreich-Wahrscheinlichkeit über 1 h und 4 h | Nullmodell von U110 an Zufallsniveaus, BTC 1 h: 1 σ 22,2 → 21,4 %, 2 σ 6,0 → 5,9 %, 3 σ 2,0 → 2,1 % | **nein** (nur im Testbericht) |
| A5 | Erwartete 4-h-Bewegung E\|r\| | Kriterium 5 (vorab 13.10.): Verhältnis 1,02 ± 0,05, n 1.390 in 232 Zeitblöcken | **nein** (nur im Fusion-Bericht und in einem Tooltip) |
| A6 | Hebel-Warnung H1 | Konten ≥ 3: Rücksetzer in 7 Tagen 20,3 % statt 7,3 %, p Holm 0,012; in 4 von 5 Fällen folgte keiner | Satz im Chartbild |
| A7 | Datentage | U154: Varianz in den 2 h nach CPI × 2,45, nach Arbeitsmarktbericht × 1,9 | Hinweis an Datentagen |
| A8 | Wochenende | Varianz Sa/So = 0,68 × Werktag (2.494 Tage) | in der Spanne eingerechnet |
| A9 | Kopplung an den S&P 500 | S4: Abhängigkeit belegt (p 0,003) | Szenarien im Ausblick |

Einschränkungen, die am Instrument stehen müssen:
- A2: Bei 14 Tagen ist der Vorsprung nicht belegt (+0,4 %, p 0,18), bei 28 Tagen keiner (−0,7 %). PAXG trifft nur 58–67 %.
- A3: Die Zahl folgt allein aus dem Abstand; die Niveau-Art prüft U244.
- A9: Unter Aktienstress ist die bedingte Verteilung nicht kalibriert (PIT p 0,014). Gezeigt wird die Kopplung, nicht das Szenario.

Aus A5 folgt rechnerisch die **Kostenschwelle** (nötige Trefferquote; BTC 11.11.: 4 h 58,9 % Taker / 52,9 % Maker, 24 h 53,5 /
51,1 %). Auch sie steht heute nur im Bericht und im Tooltip der Fusion-Kachel, auf dem Handy also gar nicht.

Die Perzentile der Klasse B rechnet das Chartbild schon (Mittelrang unter den letzten 90 Tagesständen, wie U142); das Cockpit
übernimmt diese Rechnung.

### Klasse B — gemessen

| Nr. | Größe | Anzeige | Vorbehalt |
|---|---|---|---|
| B1 | Kurs, Mark, Oracle, Prämie | Zahl | — |
| B2 | Funding Hyperliquid | Perzentil 90 Tage | Fremdbörsen erst nach U23 |
| B3 | Open Interest | Perzentil 90 Tage | — |
| B4 | Realisierte Schwankung 7 / 30 Tage, DVOL | Zahl neben A1 | DVOL als Zusatz nicht belegt (V4) |
| B5 | Kontenquote Binance | Skala mit Marke bei 3 | Schwelle = A6 |
| B6 | Liquidationsdichte nahe am Kurs | Balken ± 3 % | Abdeckung BTC 27 % des OI; 85 % der bekannten Positionen zu alt |
| B7 | Wartende Orders, Stops, Wände | Liste | Momentaufnahme, Konten ab 250k USD |
| B8 | Spread | Zahl | Buchtiefe erst nach N1 (heute nur 10 Stufen) |
| B9 | Varianz des Taker-Flusses | Skala, unterstes Dezil markiert | Vorläufer nur im Mittel, kein Einzelalarm |
| B10 | Termine: CPI, Arbeitsmarkt, Fed, Optionsverfall | Countdown | — |
| B11 | Betrieb: Dienste, API-Gewicht, Rückstand, Speicher, Backup | Lampe + Abschnitt System | — |
| B12 | Unstaking: angemeldete Abzüge aus dem Ethereum-Staking mit ihrem Zeitpunkt (seit 23.100, nur ETH) | Karte mit Kalender, Termin der nächsten großen Freigabe | Kurswirkung: vorab festgelegte Prüfung (U255, Debug 147, seit 23.101); ihr Urteil steht als Text in der Karte |

### Klasse C — nicht belegt, nicht im Cockpit

AI-Prognose (P(aufwärts), Bias, „Konfidenz“, 7-Tage-Pfad, Kauf- und Verkaufspreis) · Konfluenz (49 % richtig bei 45 % Zufall,
n 35) · Smart Money, Elite, Wale, Leaderboard, Pool als Richtungsanzeiger (das Timing-Urteil der Darwin-Liste steht am 18.11. an)
· Heatmap als Magnet oder Anker · ETF-Flüsse und Makro-Zonen als Signal (3 von 322 Tests belegt, erwartet wären 16 aus Zufall) ·
Wahrscheinlichkeit einer „volatilen Woche“ (nicht besser als die Grundrate) · Szenarien unter Aktienstress · Kalendereffekte bei
XMR (kippen an der Holm-Grenze) · alles aus Labor und Engine, solange N1 offen ist.

Diese Abschnitte bleiben erhalten, unter „Werkstatt“, mit dem Vermerk „nicht belegt“.

## 3. Aufbau des Cockpits (Handy zuerst)

Von oben nach unten, ein Bildschirm je Block:

1. **Kopf:** Coin, Kurs, Datenalter, eine Betriebslampe (führt zu System).
2. **Risikoleiste, fünf Lampen:** Hebel (A6) · Termin (A7, B10) · Wochenende (A8) · Aktien (A9) · Schwankung (A1 als Perzentil).
   Jede Lampe: aus, gelb oder — nur wo ein Test es trägt — rot; beim Antippen der Beleg.
3. **Schwankung:** Bogen-Instrument mit der erwarteten Schwankung für 7 Tage und ihrem Perzentil gegen 365 Tage; daneben A5
   („in 4 h typisch ± x %“), realisierte 7 und 30 Tage, DVOL.
4. **Spanne:** waagrechter Balken 50 / 80 / 90 % für 7 Tage mit Kursmarke, darunter 14 Tage schmaler, 28 Tage als Rahmen.
   Beschriftung mit gemessener Trefferquote.
5. **Levels:** die nächsten Niveaus oben und unten, je mit Balken für 1 und 2 Wochen und dem Abstand in %; nach U244 die
   Bilanz der Art.
6. **Erreich-Rechner (neu, aus A4 und A3):** Kurs eintippen → Wahrscheinlichkeit, ihn in 1 h, 4 h, 7 und 14 Tagen zu erreichen.
   Gedacht für Stopps, Limits und den eigenen Liquidationspreis.
7. **Markt-Messwerte:** kleine Perzentil-Skalen für B2, B3, B5, B9; Liquidationsdichte B6 mit der Abdeckung daneben.
8. **Kosten:** nötige Trefferquote für 4 h und 24 h, Taker und Maker.
9. **Werkstatt** (alle heutigen Abschnitte der Klasse C, eingeklappt) und **System** (Backup, Datenbank, Speicher, Netzwerk,
   Aktualisierung, Debug).

## 4. Regeln für jedes Instrument

- **Beleg sichtbar:** eine Zeile unter dem Instrument, etwa „geprüft: 80-%-Band traf 84 % (Rückblick 08.11.)“.
- **Farbe nur für Klasse A.** Klasse B ist neutral (grau, blau) und zeigt das Perzentil; kein Grün/Rot im Sinn von gut/schlecht.
- **Keine Pfeile, keine Empfehlungswörter.** Die Liste der verbotenen Wörter aus Chartbild und Ausblick gilt.
- **Frische:** Ist die Quelle älter als ihre Grenze, wird das Instrument grau und nennt den Stand.
- **Nicht nur Farbe:** Jede Lampe trägt ein Wort; Zustände unterscheiden sich auch in der Form.
- **Zahlen bleiben.** Jedes Instrument zeigt seinen Zahlenwert; die Grafik ersetzt ihn nicht.
- **Schwellen fest und vorab:** H1 ab Kontenquote 3; Termin 24 h vor bis 2 h nach der Veröffentlichung; Schwankung gelb ab dem
  80., rot ab dem 95. Perzentil; Betrieb gelb bei API-Gewicht über 85 % oder Backup älter als 36 h, rot bei Dienst aus.

## 5. Stufen

| Stufe | Inhalt | Paket |
|---|---|---|
| C0 | Kacheln „Letztes Backup“ und „Datenbank“ aus der Kennzahlenleiste in System, über den Speicherorten; ein Problem zeigt die Kopfzeile des Abschnitts auch zugeklappt („⚠ Backup“, „⚠ Datenbank“) | **gebaut mit 23.96** (Selbsttest Speicherorte S15, S16; Browserprobe bei 390 px) |
| C0b | Netzwerk, Aktualisierung, Debug und System als Gruppe „Betrieb“ | **gebaut mit 23.98** (mit C1; Abschnitt 9) |
| C1 | Cockpit als Startabschnitt aus vorhandenen Endpunkten (Ausblick, Volatilität, Chartbild, Termine, Fusion, System); nur lesend, keine neue Rechnung; alte Abschnitte darunter als Werkstatt | **gebaut mit 23.98** (Abschnitt 9; dazu aus C2 schon der Kostenblock und drei Messwerte) |
| C2 | Erreich-Rechner (A4, A3), Perzentil-Skalen für Funding und Taker-Varianz, Liquidationsdichte, Betriebslampe mit API-Gewicht und Diensten | nächstes Paket zum Cockpit |
| C3 | nach N1, U23 und U244: Buchtiefe und Impact, Funding-Spread, Bilanz der Niveau-Art | später |

## 6. Proben

1. Abgleich: Jede Zahl im Cockpit ist gleich der Zahl im Quellbericht desselben Zeitpunkts (Ausblick, Volatilität, Fusion).
2. Frische: Quelle künstlich gealtert → Instrument grau mit Stand.
3. Browserprobe bei 360 bis 430 px Breite und am Desktop; kein waagrechtes Scrollen.
4. Wortprobe: keine Empfehlungswörter, kein Pfeil.
5. Mutation je Lampe: Schwelle verschoben → Probe schlägt an.
6. Der Erreich-Rechner trifft an Zufallsniveaus die Quoten von U110 (Positivkontrolle) und liefert für den aktuellen Kurs 100 %.

## 7. Entscheidungen beim Nutzer

**Entschieden am 12.11.2026 gegen 01:00 (Auswahl zum Anklicken, nach der Frage des Nutzers von 00:55 „aber das cockpit ist noch nicht umgesetzt?“):** Punkt 1 „Oben auf der Hauptseite“, Punkt 2 „Ein Coin groß + Streifen“, Punkt 3 „In die Werkstatt“, Punkt 4 „Ja, auf meinem Gerät merken“ -- jeweils der Vorschlag. Punkt 5 hat die Frage des Nutzers beantwortet: das Cockpit zuerst, vor U244.

Stand 11.11. 21:36 (überholt): Der Nutzer antwortete auf dieses Konzept mit „Ok“ und fragte nach dem Paket. Das „Ok“ war keine Einzelantwort auf die fünf Punkte.

1. **Ort:** Cockpit als Startabschnitt derselben Seite, alte Abschnitte eingeklappt darunter? Vorschlag: ja.
2. **Coins:** ein Coin groß, dazu ein Streifen mit allen sechs (Spanne 7 Tage und Lampen)? Vorschlag: ja.
3. **Unbelegtes:** AI-Prognose, Kauf- und Verkaufspreis, Konfluenz und die Kacheln zu Walen aus der Hauptansicht nehmen und nur
   in der Werkstatt zeigen? Vorschlag: ja.
4. **Erreich-Rechner** mit eigenem Liquidationspreis als festem Eintrag? Vorschlag: ja, lokal im Browser gespeichert.
5. **Reihenfolge:** C0 mit 23.96, C1 und C2 als eigenes Paket danach, vor oder nach U244? Vorschlag: C1 und C2 vor U244 — das
   Cockpit braucht keine neue Studie.

## 8. Abgrenzung

- Das Cockpit rechnet nichts Neues außer dem Erreich-Rechner und den Perzentilen. Es ändert keine Prognose, kein Urteil, kein
  Labor.
- Was heute Klasse C ist, kann aufsteigen: Ein bestandener, vorab festgelegter Test macht aus einer Werkstatt-Größe ein Instrument
  (zum Beispiel eine Niveau-Art nach U244 oder der Rücklauf nach Liquidationswellen nach U204).

## 9. Bau der Stufen C0b und C1 (Paket 23.98, 12.11.2026)

**Was gebaut ist**
- Neues Modul `hl_cockpit.py` (liest nur, Endpunkt `/cockpit?coin=…`) und `hl_cockpit_js.py` (Skript `/cockpit.js`). Abschnitt
  „CK Cockpit“ als erster Abschnitt der Hauptseite: Kopf mit Kurs und Betriebs-Pille, Streifen mit sechs Coins, Kernsatz, fünf
  Lampen, Schwankung, Spannen, Levels, Messwerte, Kosten, Sprünge zu Werkstatt und Betrieb.
- Ordnung der Seite in `hl_cockpit.seite_ordnen`: Hauptansicht (Live-Chart, Chartbild, Ausblick, Volatilität, Notbremse, Makro,
  Prognosemärkte, Orders, Heatmap, Momentaufnahme), Gruppe „Werkstatt · nicht belegt“ (Kennzahlenleiste, Konfluenz, AI-Prognose,
  Treiberfamilien, TradeLabor, Wale, Leaderboard dreifach, Aktive Profis), Gruppe „Betrieb“ (Netzwerk, Aktualisierung, Debug,
  System). Beim ersten Laden je Browser werden die bisherigen Abschnitte einmal eingeklappt.
- Debug 143 (★ Cockpit: Stand je Coin als Text) und 144 (Selbsttest).

**Festlegungen beim Bau (neu, fest und vorab)**
- **Lampe „Aktien“:** Abschnitt 4 nannte für sie keine Schwelle. Festgelegt: Sie zeigt die Ausnahmelage (c) des Ausblicks
  (`hl_ausblick.schock_pruefen`: S&P-500-Perp in 6 h über 3 typische Bewegungen; gilt 24 h) -- eine Regel, die es schon gab. Für
  PAXG gilt sie nicht. Die Ausnahmelagen (a) und (b) des Coins selbst stehen als Zeile unter dem Kernsatz.
  - „Aus“ zeigt die Lampe nur, solange die Regel nachweislich geprüft wird -- dieselben Bedingungen wie in `schock_pruefen`: Basis
    `FS1` vorhanden, mindestens 12 Kerzen der Reihe `xyz:SP500:30m` in den letzten 8 h, die letzte jünger als 2 h; dazu: letzte
    Rechnung des Ausblicks jünger als 3 h (die Prüfung läuft in seinem Takt). Sonst ist sie grau und nennt den Grund. Anlass: Die
    Notbremse lief knapp drei Wochen ohne XMR, weil ein fremd betriebener Markt verschwunden war und nichts es meldete (23.97); fiele
    der S&P-500-Perp aus, stünde die Lampe sonst für immer auf „aus“.
  - Grau ist sie auch, solange für den Coin eine Ausnahmelage (a) oder (b) gilt (`schock_pruefen` setzt (c) dann nicht), und für
    einen Coin, der in der Basis der Regel fehlt (keine Rechnung des Ausblicks für ihn).
- **Ohne Quelle kein „aus“** (gilt für alle Lampen): ohne Kontenquote, ohne bekannten kommenden Termin, ohne geprüfte Aktien-Regel,
  mit Tageswerten der Schwankung, die älter als 3 Tage sind, ist die Lampe grau. Nur „Wochenende“ kommt ohne Quelle aus (Uhr).
- **Lampe „Termin“:** 24 h davor Hinweis; von der Veröffentlichung bis 2 h danach Warnung, aber nur, wenn die Datentage-Studie für
  diese Reihe „belegt“ meldet -- sonst bleibt es beim Hinweis. Erzeugerpreise und Erstanträge lösen nichts aus (die Studie führt
  sie nur beschreibend, ohne Urteil).
- **Lampe „Schwankung“:** Perzentil der erwarteten Schwankung (erste Woche des Modells, das auch der Abschnitt „Volatilität“
  zeigt) gegen die realisierte 7-Tage-Schwankung der letzten 365 Tage. Farbe nur mit Urteil V1 „belegt“ und nur für die Prognose; gibt es keine frische Prognose, zeigt die Lampe
  das Perzentil der realisierten Schwankung neutral.
- **Levels:** Die Wahrscheinlichkeiten gelten ab dem Anker der Rechnung. Ein Niveau, das der Kurs seither durchlaufen hat, wird
  nicht mehr gezeigt, nur gezählt; die Abstände zählen zum jetzigen Kurs.
- **Vermerk an der Spanne** (*berichtigt mit 23.99, Abschnitt 10*): immer die gemessene Trefferquote des Coins („traf x %“), mit
  „(zu eng)“ oder „(zu weit)“ außerhalb von 80 % ± 2 Standardfehler, wie im Ausblick. Vorsprung je Horizont und das Urteil der
  Gesamtprüfung S1 stehen in der Zeile darunter. Bis 23.98 stand „traf x %“ nur, wenn die Gesamtprüfung bestand -- auf dem Pi
  also nie.

- **Stand an jedem Instrument:** Kurs und Messwerte mit Uhrzeit („live“) oder UTC-Tag (Tagesstand, Funding-Druck); Schwankung mit
  dem Tag der Tageswerte und dem der Prognose; Spanne und Levels mit der Zeit der Rechnung (älter als 2 Tage: blass); Kosten mit
  Zeit und Fenster; im Detail der Lampen „Stand der Quelle“.

**Abweichungen vom Entwurf**
- Aus Stufe C2 vorgezogen: der Kostenblock und drei Messwerte (Open Interest, Kontenquote mit Perzentil, Funding-Druck als z-Wert).
  Taker-Varianz, Liquidationsdichte und das Perzentil des Hyperliquid-Fundings fehlen noch.
- Die Betriebs-Pille zeigt dieselben Meldungen wie die Kopfzeile des Abschnitts System (Backup fehlgeschlagen oder Ziel
  ungeeignet, Backup älter als 50 Stunden, Platz am Backup-Ziel, Datenbank beschädigt) und nur die Stufe „Hinweis“. Die
  Betriebslampe nach Abschnitt 4 (Backup älter als 36 h, API-Gewicht über 85 %, Dienst aus = rot) kommt mit C2.
- Der Kopf zeigt den Kurs aus der jüngsten Minutenkerze des Recorders (Mark, Oracle und Prämie stehen weiter im Live-Chart).
- Die Lampe „Wochenende“ ist als Messwert geführt (blau), nicht als Klasse A wie in der Tabelle von Abschnitt 2 (A8): Der Faktor
  0,68 stammt aus einer Datenprobe der Volatilität (Prüfung vor dem Urteil), nicht aus einem Test mit Urteil.
- Die Regeln des Cockpits gelten für den Abschnitt Cockpit. Die Abschnitte der Hauptansicht darunter sind unverändert; der
  Live-Chart zeigt weiter seine Marken und Zonen (darunter FVG mit den Wörtern „bullisch“ und „bärisch“). Darüber ist nichts
  entschieden.

**Proben (Abschnitt 6):** 1 Abgleich und 2 Frische in `hl_cockpit.py --selbsttest` (dazu der Vertrag mit den Modulen auf deren
Demo-Datenbanken); 3 Browserprobe bei 360, 390 und 430 px und am Desktop beim Bau (kein waagrechtes Scrollen, keine Fehler);
4 Wortprobe im Selbsttest von Modul und Skript; 5 Mutationen beim Bau (jede Lampe an ihrer Schwelle); 6 entfällt bis C2.

## 10. Erste Prüfung auf echten Daten und Berichtigung (Debug 143 vom 12.11.2026 16:18 UTC; Paket 23.99)

Der Nutzer hat 23.98 eingespielt und Debug 143 geschickt (Laufzeit 4,2 s für sechs Coins).

**Stimmt mit den Quellen überein:** Kosten BTC 4 h 58,9 / 52,9 % und 24 h 53,5 / 51,1 % (gleich dem Fusion-Bericht vom 11.11.);
die Aktien-Regel wird geprüft (letzte Kerze des S&P-500-Perp 15:00 UTC, letzte Rechnung des Ausblicks 16:06 UTC); nächster Termin
Arbeitsmarktbericht (laut Kalender der BLS am 04.12.2026, die Verbraucherpreise am 10.12.2026:
https://www.bls.gov/schedule/2026/12_sched.htm); PAXG mit drei grauen Lampen, wie beschrieben. Hebel-Lampe an bei BTC
(Kontenquote 3,20) und ETH (3,59).

**Zwei Fehler des Cockpits, mit 23.99 behoben**
1. **Vermerk an der 7-Tage-Spanne: „Vorsprung offen“ bei allen Coins.** Der Vermerk hing an der Gesamtprüfung S1 des Ausblicks. Die
   verlangt den Vorsprung (p < 0,05) *und* die Deckung von BTC und ETH in 80 % ± 2 Standardfehler. Auf dem Pi (Debug 73 vom 11.11.):
   7 Tage Gewinn +1,5 %, p 0,002, aber BTC 84,0 % ± 1,7 -- „besteht nicht“. Am Balken stand deshalb „Vorsprung offen“, in der Zeile
   darunter „schlägt das einfache Vergleichsmodell (p 0,002)“. Jetzt: Der Balken trägt immer die gemessene Trefferquote des Coins
   („traf 84 % (zu weit)“), der Kernsatz nennt sie, die Zeile darunter nennt Vorsprung je Horizont, das Urteil der Gesamtprüfung und
   seinen Grund.
2. **Perzentil gerundet:** ZEC zeigte „80. Perzentil“ und die Lampe „aus“ (0,796). Jetzt wird abgeschnitten; Zahl und Lampe können
   sich nicht mehr widersprechen (geprüft über alle Mittelränge für 60 bis 365 Werte).

Dazu: Der Debug-Text nennt den Zeitpunkt des nächsten Termins und den Beleg der Spanne.

**Berichtigung dieses Konzepts (mein Fehler vom 11.11.):** Die Tabelle der Klasse A führte die 7-Tage-Spanne (A2) als „belegt“. Das
stimmt so nicht. Belegt ist der *Vorsprung* des Fächers gegen das Vergleichsmodell bei 7 Tagen (CRPS +1,5 %, p 0,002). Die vorab
festgelegte *Gesamtprüfung* S1 besteht bei keinem Horizont -- bei 7 Tagen, weil das Band von BTC etwas zu weit ist. Das stand in
Debug 73 („-> besteht nicht“) und seit Oktober im README („Breite S1 besteht bei keinem Horizont“); ich habe die Zahlen übernommen
und das Urteil nicht. Folgen:
- Klasse A im strengen Sinn (vorab festgelegter Test bestanden) hat 8 Größen, nicht 9. Die Spanne bleibt das zentrale Instrument,
  aber mit dem Etikett, das stimmt: Trefferquote je Coin gemessen, Vorsprung bei 7 Tagen belegt, Gesamtprüfung nicht bestanden.
- Für BTC ist das 80-%-Band eher zu weit (traf 84 %), für PAXG deutlich zu eng (traf 67 %; bei 28 Tagen 58 %) -- bei PAXG ist das
  Risiko größer, als das Band zeigt. Für ETH, HYPE, XMR und ZEC liegt die Trefferquote in der Toleranz (79 bis 83 %).
- Die Erreich-Wahrscheinlichkeiten der Levels (A3, Prüfung S3) bestehen bei allen drei Horizonten; daran ändert sich nichts.

**Warum die Probe es nicht fand:** Die Probe-Welt des Selbsttests trug für 7 Tage ein erfundenes „besteht: True“. Der Vertragstest
lief auf der Demo-Datenbank ohne Rückblick. Jetzt trägt die Probe-Welt die Zahlen und Urteile des Pi aus Debug 73, und der
Vertragstest erzeugt S1 mit `hl_ausblick.urteil_s1` selbst -- einmal so, dass das Modul „besteht nicht“ urteilt.

**Beobachtungen, nichts geändert**
- Die Wahrscheinlichkeit eines Levels gilt ab dem Anker der Rechnung (bis zu 30 Minuten alt), der Abstand zum jetzigen Kurs. Nach
  einer schnellen Bewegung passen beide nicht mehr zusammen (XMR 12.11.: Level +1,0 % über dem Kurs mit 99 % -- vom Anker aus
  waren es +0,2 %). Der Kurs-Rechner (Stufe C2) rechnet vom jetzigen Kurs.
- Die Kerzen des S&P-500-Perp kommen alle 30 Minuten und nur abgeschlossen; die jüngste ist 50 bis 80 Minuten alt. Bis zur Grenze
  von 2 Stunden bleibt Luft für einen ausgefallenen Abruf, nicht für zwei.

## 11. Instrument „Unstaking“ bei ETH (Paket 23.100, U254; Wunsch des Nutzers vom 14.11.2026)

Der Nutzer hat beobachtet, dass auf große Abzüge aus dem Ethereum-Staking häufig Kursrückgänge folgen, und einen Indikator mit Termin
verlangt. Einzelheiten, Quellen und die vorab festgelegte Studie: `KONZEPT_Unstaking.md`.

- **Klasse B (gemessen), Nummer B12.** Die Zeitpunkte der Abzüge stehen in der Kette; das Cockpit rechnet nichts hinzu außer Summe je
  Tag, Anteil am Tagesdurchsatz, Anteil des größten Abziehers und dem Wert in USD zum frischen Kurs.
- **Anzeige, nur bei ETH:** Karte „Unstaking“ zwischen Messwerten und Kosten; dazu eine Zeile mit dem Termin der nächsten großen
  Freigabe unter dem Kernsatz. Für die anderen Coins gibt es das Instrument nicht.
- **Schwellen, fest und vorab:** großer Tag ab 28.800 ETH „frei ab“ (die Hälfte des Höchstdurchsatzes von 57.600 ETH am Tag);
  Abzieher genannt ab 10.000 ETH; Stand des Knotens höchstens 3 Stunden alt, Tagesdatei als Ersatz höchstens 2 Tage.
- **Farbe:** blau wie alle Messwerte. Keine Lampe, keine Warnfarbe. Große Tage unterscheiden sich in der Form (fett, höherer
  Balken, Punkt).
- **Prüfung der Kursfolge (seit 23.101, U255):** Unter dem Termin steht die Zeile „Folgt darauf ein Kursrückgang?“ mit dem
  gespeicherten Urteil der vorab festgelegten Prüfung -- „Noch nicht geprüft“ mit der Debug-Nummer 147, oder Datum und Wortlaut
  („nicht belegt“, „belegt …“, „zu wenige Fälle“). Der Beleg der Karte nennt Fallzahlen und Nachweisgrenze. Das Cockpit rechnet hier
  nichts; auch „belegt“ bleibt Text ohne Farbe, bis die Lampe eigens festgelegt ist.
- **Ohne Quelle kein Wert:** Fehlt der Stand, ist die Karte blass und nennt den Grund; ein Ersatz aus der Tagesdatei trägt den
  Vermerk „geschätzt“.
- **Aufstieg zu Klasse A** nur über die Studie U255 (`KONZEPT_Unstaking.md` 6 und 6a; gebaut mit 23.101, Urteil nach dem ersten
  Lauf von Debug 147). Bei „belegt“: eigene Lampe und ein Platz in der Prognose, eigens festzulegen.
- **Proben:** Abgleich und Schwellen in `hl_cockpit.py --selbsttest`, Vertrag mit `hl_staking` auf einer vom Modul gefüllten
  Datenbank; Zeichnung in `hl_viz.py --selbsttest-cockpit`; Browser-Probe bei 360 bis 1280 px; Mutationen beim Bau.
- **Nicht geprüft:** der Abruf vom Pi aus -- **Debug 145** zeigt ihn.
