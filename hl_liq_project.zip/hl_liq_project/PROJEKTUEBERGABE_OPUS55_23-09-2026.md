# PROJEKTÜBERGABE — Hyperliquid-Analysesystem („hl_liq_project")
**Für den Import in eine neue Sitzung (Claude Opus 5.5) · Stand 23.09.2026, Version 2026-09-23.10**
Erstellt bis hierher mit Claude Fable 5.1 (Sitzungen 1–5, 13.–23.09.2026); Auditberichte v9/v10 kamen von Opus 5.5.

> **So beginnst du:** (1) Diese Datei ganz lesen. (2) `UPDATE_PLAN.md` lesen — Abschnitt A abarbeiten (Prüfungen),
> Abschnitt B ist die Reihenfolge der offenen Arbeiten. (3) Das Paket `hl_liq_project.zip` ist die einzige Wahrheit;
> Chats und alte Transkripte sind nicht verfügbar. Alles Wissen steht in den Dateien des Pakets.

---

## 1. Was das System ist

Ein Analysesystem für Hyperliquid-Perpetuals (BTC, ETH, HYPE, ZEC, PAXG, XMR) auf einem **Raspberry Pi 5**
(Python 3.13, SQLite, systemd), mit vier Diensten:

| Dienst | Datei | Aufgabe |
|---|---|---|
| Recorder | `hl_recorder.py` | Hyperliquid-API und WebSocket: Positionen aller großen Konten (Poller in Stufen), Leaderboard-Top-75 (alle 2 min), Fills (Stream + REST-Nachtrag), Orders, Liquidationen (beobachtet + abgeleitet), Kerzen, Heatmap-Snapshots, Pool „Aktive Profis", Masterregel Sperre, Backup; seit 23.33 der Adress-Strom (`hl_adressfluss.py` → `adressfluss.db`) |
| Dashboard | `hl_viz.py` | Web-UI (http://<pi>:8765), alle Charts/Abschnitte, Prognose-Berechnung (Lernzyklus, Kalibrierung v1/v2, Scores, Profis, Konstellationen), Debug-Konsole (seit 23.84 jeder Lauf mit fester Nummer, U227), Update/Restore; seit 23.33 der TradeLabor-Takt (`hl_labor.py`, 15 s); seit 23.93 der Faden der Trading Engine (`hl_engine.py`, Puls jede Minute, Stand alle 10 min) |
| Fremdbörsen | `hl_binance.py` (+ `hl_ext.py`) | Binance, Bybit, OKX, Crypto.com: Liquidationen, Funding, Kennzahlen, ETF-Flüsse (Farside) |
| Coinbase | `hl_coinbase.py` | Spot-Matches (Taker-Flow), Orderbuch, Kerzen |

Kernfunktion: **Liquidations-Heatmap** (wo liegen Liquidationspreise großer Konten) und eine **Prognose**
(30 Treiber → Wahrscheinlichkeit/Pfad), dazu Konten-Analysen (Wale, Leaderboard, Elite, Aktive Profis).

## 2. Dateien im Paket (122 Dateien in 140 Zip-Einträgen, Stand 23.93)

- **Kern:** `hl_recorder.py`, `hl_viz.py`, `hl_forecast.py` (Treiber, Pfad, Kalibrierung v1, Bewertung),
  `hl_indikatoren.py` (neue Treiber 14.09.), `hl_score.py` (Konto-Score, Elite), `hl_profis.py` (Aktive Profis; seit 23.57 Schatten der Darwin-Liste, U136),
  `hl_kalib.py` (Kalibrierung v2, Schatten), `hl_konstellation.py` (Paar-Statistik, Vorbedingungen; Ereignisse seit 23.53 aus jeder gespeicherten Prognose, U131; Begründung im Kursdaten-Abgleich seit 23.56 über die ganze Bewegung, U135),
  `hl_ext.py`, `hl_binance.py`, `hl_coinbase.py`, `hl_dbcoord.py` (Schreibsperre), `hl_watchdog.py`,
  `hl_timestats.py`, `hl_backtest.py`, `macro_corr.py`, `run_all.py`, `install.py` (Installation + `--selftest`),
  `hl_familien.py` (Treiberfamilien; Hygiene seit 23.55 an den aktiven Zeiten, „kein Urteil“ statt „tot“, U133), `hl_anker.py` (Heatmap-Anker), `hl_labor.py` (TradeLabor, simulierter Handel),
  `hl_adressfluss.py` (Adress-Strom), `hl_fusion.py` (Fusionsprognose, Kalibrierung v3, Kostenschwelle; Schatten, seit 23.42),
  `hl_kaskade.py` (Kaskaden-Gleichung: Wurzelgesetz auf die Heatmap-Cluster, Kipppunkt, Kalibrierung Y; Schatten, seit 23.43),
  `hl_magnet.py` (Magnet-Test U110: Berührungen der Cluster gegen das Nullmodell, Spiegel, Placebo; nur Messung, seit 23.45),
  `hl_makro.py` (Makro-Chart U121: Abruf freier Quellen nach `makro.db`, Treiber, Miner-Kostenbasis, Nutzlast; seit 23.47),
  `hl_makro_js.py` (Skript des Makro-Abschnitts, `/makro.js`; seit 23.47; Kursleiste unter jedem Kennzahl-Chart seit 23.54, U132),
  `hl_makro_signal.py` (Makro-Signale U126: Abweichung zur Referenzlinie, Rückblick, Live-Signal, Bilanz gegen Zufall, Prognose,
  Live gegen Nachrechnung; reine Rechnung, seit 23.49), `hl_makro_korr.py` (Makro × Kurs U130: Makro-Merkmale gegen die
  BTC-Rendite der folgenden Tage, Phasen-Null, Benjamini-Hochberg, Hälften; Debug-Bericht, seit 23.52; Teil B seit 23.85:
  Makro-Regime × 4-h-Prognosen, Placebo verschobener Kalender, Urteil 15.01.2027; U229 SSR-Diagnose), `hl_regime.py`
  (Regime-Modul U138, Phase 0: Vorprüfung P0.1–P0.9 auf bis zu drei Jahren 30-min-Kerzen je Coin, eigene `regime.db`; Debug-Bericht,
  seit 23.59; K3 seit 23.60 je Stunde verglichen, U139), `hl_swing.py` (Swing-Trades U140: eigene `swing.db` mit 30-min-Kerzen und
  Funding von Binance-Futures ab 2020, Swing-Takt im Dashboard, Strategien S1–S4 und zwei Kontrollen als gemeinsame Funktionen für
  Historie und TradeLabor, Vorprüfung mit Placebo und Urteil; seit 23.61; seit 23.62 auch die Dip-Regeln Z1/Z2 und RSI),
  `hl_zyklus.py` (Zyklus-Studie U141: Rallyes und Rücksetzer auf den langen Tagesschlüssen von Coin Metrics gegen 1000
  Zufallswege, „Dip halten“ gegen HODL, Trendfilter und Schwankungssteuerung, Warnsignale vor Rücksetzern, Gegenprobe mit
  Ausführung; nur lesend; Debug-Bericht, seit 23.62), `hl_hebel.py` (Hebel-Studie U142: Binance-Positionierung und Perp-Anteil vor
  Rücksetzern und Liquidationswellen; eigene `hebel.db` mit dem Binance-Archiv ab 2020, Hebel-Takt im Dashboard, Sicherung der
  Liquidationen und Buchtiefe; Debug-Bericht, seit 23.63; 23.64 Kerzenschlüssel mit Markt und beschreibende H1-Ergänzungen),
  `hl_chartbild.py` (Chartbild U143 Stufe 1: die Lage je Coin in Worten -- Trend, Bein wie U141, Swings, Niveaus der Großkonten und
  Liquidationscluster, 80-%-Band wie P0.2 mit Trefferquote, RSI, Positionierung, Prüfstand je Zeile; nur lesend, kein Signal; seit
  23.65), `hl_chartbild_js.py` (Skript des Abschnitts „CB Chartbild“, `/chartbild.js`; seit 23.65),
  `hl_ausblick.py` (Ausblick 4 Wochen U146: Breite HAR-X, Form aus echten Pfaden ohne Trend, Richtung nur nach bestandenem Tor,
  Ziellevels mit Wahrscheinlichkeit, bedingte Szenarien mit dem S&P 500, Stressfächer, Takt; eigene `ausblick.db`; seit 23.66),
  `hl_ausblick_js.py` (Skript des Abschnitts „AU Ausblick“, `/ausblick.js`; seit 23.66), `hl_aktien.py` (Aktien-Archiv U148:
  FRED, `xyz`, DVOL, CFTC, FINRA, Farside, Cboe, SEC mit Abrufzeit in `aktien.db`, Studie U147, Kurzstudie K1/K2; seit 23.66),
  `hl_datentage.py` (Studie Datentage U154: Schwankung von BTC und ETH im Fenster 8:30–10:30 New York an US-Terminen gegen Werktage
  desselben Monats, Verschiebungs-Null, Holm, Hälften; liest `swing.db` und `makro.db`, schreibt nichts; seit 23.67),
  `hl_volumen.py` (Volumen-Studie U221: Einstiege der Strategien nach relativem Volumen und Taker-Saldo vor dem Einstieg -- Teil A die
  Trades des TradeLabors mit Urteil am 08.11., Teil B die vier Swing-Strategien seit 2020; Zeitverschiebung der fertigen Reihen, Holm,
  Hälften; liest nur, schreibt nichts; seit 23.81; seit 23.82 fragliche Minuten keine Lücke mehr und `--datenlage` für U222),
  `hl_wende.py` (Extrem-Wende U226: die Strategie aus dem Video „Range Deviation plus Ribbon Flip“ auf BTC 8 h -- 8-h-Kerzen aus
  `swing.db`, Signale beider Lesarten, Nachrechnen der Video-Trades, Urteil H1/H2/Hälften gegen gemeinsam verschobene Trades mit
  α_H1 0,038 und Stichtag 27.10., Bericht, Labor-Daten für `sig_wende`, Kalibrierung; liest nur; seit 23.83),
  `hl_prognosemarkt.py` (Prognosemärkte U235, seit 23.88: Kalshi, Polymarket und Hyperliquid HIP-4 nur lesend in eigener
  `prognosemarkt.db` -- Dienst-Faden im Dashboard mit Erstlauf und Stichtag, Takt, Rückblick auf abgelaufene Märkte, vorab
  festgelegte Auswertung H1–H3 mit einem gemeinsamen Urteil, vor dem Urteil nur Zählungen; Spot-Echo zur Anzeige; Berichte),
  `hl_prognosemarkt_js.py` (Skript des Abschnitts „PM Prognosemärkte“, `/prognosemarkt.js`; seit 23.88),
  `hl_volatil.py` (Volatilität U237, seit 23.90: Index VI30/VI7 aus den 30-min-Kerzen in `swing.db` und DVOL aus `aktien.db`,
  Prognose der Schwankung je Woche für vier Wochen (log-HAR direkt, M+ mit DVOL, HYPE geliehen) mit Bändern und der
  Wahrscheinlichkeit einer volatilen Woche neben der Grundrate, eigene `volatil.db`; Erstlauf mit Stichtag, Rückblick ab
  28.10.2021, vorab festgelegtes Urteil V1–V4 mit gewichtetem Holm, vor dem Urteil nur Zählungen; Rechnung als eigener Prozess
  mit nice 10, gestartet vom Faden „volatil“ im Dashboard; liest als einziges Projektmodul `hl_swing`),
  `hl_volatil_js.py` (Skript des Abschnitts „VL Volatilität“, `/volatil.js`: zwei Achsen, Zeiträume 2 W bis 5 J; seit 23.90),
  `hl_engine.py` (Trading Engine U241, seit 23.93: wählt aus 34 Labor-Strategien die belegten aus -- Aufnahme (A)/(B), Pause per
  CUSUM in Handelszeit, „gescheitert“ mit Monatsbedingung -- und übernimmt nur deren Trades auf ein Papierkonto mit Bremse; spielt die
  Regeln bei jeder Rechnung neu ab, Protokoll und Abgleich, Puls für Ausfalltage in eigener `engine.db`; Faden „engine“ im Dashboard;
  liest das Labor nur, alle Regelversionen -- eine abgelöste heißt „beendet“), `hl_engine_js.py` (Skript des Reiters „Engine“ im TradeLabor, `/engine.js`; seit 23.93;
  seit 23.94 mit dem Button „Bremse lösen“, `POST /labor/engine/bremse_loesen`),
  `hl_notbremse.py` (Notbremse U206, seit 23.76: eigener Dienst `hl-notbremse` mit `notbremse.db` -- Ebene A jede Minute (Krypto- und
  Aktien-Korb, X, Y, Λ, Stufen 1/2, Kalibrierung nach Alarmbudget), Termine, Handbremse; das Tor `darf()` und Welt A (`labor_a.db`)
  für das TradeLabor; Banner- und Abschnittsdaten), `check_notbremse.py` (Debug-Werkzeug: Zustand, `--zerlegung`, `--rueckblick` mit
  Empfindlichkeit, Labor-Rückwärtstest über Sichten mit Zeitgrenze und Positivkontrollen von data.binance.vision),
  `update.py` (Update/Restore), `migrate_db.py`, `version.py` (Version + Prüfsumme).
- **Werkzeuge (Debug-Konsole):** `check_*.py` — sources, fills, leaderboard, forecast, writes, report, m9, magnet,
  elite, treiber (Harness, 83 Prüfungen), pool, sperre, profis, daily, orders, abdeckung (seit 23.68, U159), notbremse (seit 23.76, U206; seit 23.77 Rückblick im Hintergrund), system (seit 23.77, Systemdiagnose ohne SSH, U212; seit 23.78 Hänger-Abzüge, Lücken und Lebenszeichen, Systemprotokoll dauerhaft als Klick, U215–U217); `db_size.py`;
  `make_treiber_pdf.py`/`_en.py` (Treiber-Dokumentation als PDF).
- **Dokumente:** `README.md` (Betrieb), `UEBERGABE_13-09-2026.md` (chronologisches Änderungsprotokoll, Abschnitte
  3a–3ω, 3αα, 3ββ, 3γγ, 3δδ, 3εε, 3ζζ, 3ηη, 3θθ, 3ιι, 3κκ, 3λλ, 3μμ, 3νν, 3ξξ, 3οο, 3ππ, 3ρρ, 3σσ, 3ττ, 3υυ, 3φφ, 3χχ, 3ψψ, 3ωω, 3ααα, 3βββ, 3γγγ, 3δδδ, 3εεε, 3ζζζ, 3ηηη, 3θθθ, 3ιιι, 3κκκ, 3λλλ, 3μμμ, 3ννν, 3ξξξ, 3οοο, 3πππ, 3ρρρ, 3σσσ, 3τττ, 3υυυ, 3φφφ, 3χχχ, 3ψψψ, 3ωωω, 3αααα, 3ββββ, 3γγγγ, 3δδδδ, 3εεεε, 3ζζζζ, 3ηηηη, 3θθθθ, 3ιιιι, 3κκκκ, 3λλλλ, 3μμμμ, 3νννν, 3ξξξξ, 3οοοο, 3ππππ, 3ρρρρ, 3σσσσ, 3ττττ, 3υυυυ, 3φφφφ, 3χχχχ, 3ψψψψ, 3ωωωω, 3ααααα, 3βββββ, 3γγγγγ, 3δδδδδ, 3εεεεε), `UPDATE_PLAN.md` (lebendes Arbeitsdokument), `REVIEW_Audit_v10_22-09-2026.md`, `KONZEPT_Aktive_Profis.md`, `KONZEPT_Fusion.md` (fusionierter Treiber, Stufen 1–3; Abschnitt 4b Strukturgleichung und Kaskaden-Gleichung),
  `KONZEPT_Makro.md` (Makro-Chart: Regeln, Quellen, Rechnung je Treiber, Proben, Grenzen; 12 Börsenflüsse U174 vorab festgelegt), `RECHERCHE_Makro_Chart_05-10-2026.md`
  (Recherche zu Zyklus-Indikatoren und freien Datenquellen, Grundlage von U121), `KONZEPT_Regime.md` (Regime-Modul U138:
  die jüngsten 4–8 Wochen lesen; Prüfplan 9.1a, Phase 0 gebaut in 23.59, Ergebnis auf echten Daten 9.4), `RECHERCHE_Regime_07-10-2026.md` (Recherche zu Kalender- und
  Schwankungsmustern, Stufen, Regime-Erkennung und Prognosebewertung, Grundlage von U138), `KONZEPT_Swing.md` (Swing-Trades U140:
  Regeln S1–S4, Größe nach Risiko, Urteil vorab, Kalibrierung des Placebos 6a, Labor; 7a Zyklus-Strategien),
  `KONZEPT_Zyklen.md` (Zyklus-Studie U141: Fragen des Nutzers messbar gemacht, Zufallsgeometrie, Teile A–D vorab, Änderungen vor
  dem ersten Lauf 12, Vorschlag zum weiteren Vorgehen 13), `KONZEPT_Hebel.md` (Hebel-Studie U142: Fragen messbar gemacht, Daten,
  H1–H4 vorab mit zwei Nullmodellen, Folgen vorab, Kalibrierung 12), `RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` (Bewertung
  Fear & Greed, Binance-Top-Trader, Market Maker, Hebel gegen Spot, Chart-Trader; Vorkonzept U142/U143), `KONZEPT_Chartbild.md`
  (Chartbild U143 Stufe 1: Bausteine und Frische, Lesart, Anzeige, Proben, beim Bau geändert 9.1),
  `KONZEPT_Ausblick.md` (Ausblick 4 Wochen U146 und Studie U147: vorab festgelegt 11.10., Ergänzung 13 zu Takt, Aktienmarkt und
  gemeinsamen Szenarien), `RECHERCHE_Aktienmarkt_11-10-2026.md` (Recherche zu Aktiendaten, Zusammenhang BTC–S&P 500, Methoden
  gemeinsamer Szenarien; Grundlage von 13), `RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md` (U152: gängige Kennzahlen für
  „95 % Hebel gegen 5 % Spot“ mit Quelle, Historie, Kosten und Höchstwerten; seit 23.67),
  `RECHERCHE_Boersenfluesse_17-10-2026.md` (U174: freie Quellen für BTC-Börsenzu- und -abflüsse, Eigenbau, Vergleichbarkeit,
  Revisionen, Belege und Nachweisgrenze; Nachtrag 18.10.: Coin Metrics frei bestätigt; im Paket seit 23.69),
  `KONZEPT_Akkumulation.md` (U180, gebaut mit 23.69, auf dem Pi ab 23.70: Akkumulation im TradeLabor -- nur Kauf, Regeln A0/A1/A2/A3,
  Sperre, Warteregel, 5.000 USD Spot, Startkauf und Rückrechnung ab dem Start des Coins im Labor (U184, 7a), Bilanz und Reiter, Vergleich
  beschreibend, Rückblick mit Q gegen Vorzeichen-Surrogate, vor jedem echten Kurs geändert 7, Stand nach dem Bau 3/6; Anzeige berichtigt
  mit 23.71: „Alle Käufe“, „Stand je Tag“, Grund des Startkaufs (U185, 7b); Korrekturkauf A4 mit 23.72 (U186, 7c); auf dem Pi erst mit
  dem Paket nach 23.70, siehe `update.py`),
  `KONZEPT_Notbremse.md` (U206–U209, Fassung 1 vom 23.10., vorab festgelegt: marktweite Long-Sperre bei Schocks -- Ebene A Marktsignal,
  Ebene B Nachrichten und KI (U207), Handbremse, Tor, Welt A und B, Prüfungen 10, Urteile 11; gebaut mit 23.76 ohne Ebene B),
  `KONZEPT_Volumen.md` (U221, vorab festgelegt und freigegeben am 24.10.: RV und TS, Drittel je Schicht, Nullmodell, Pool, Urteil Teil A
  am 08.11., Teil B Swing-Historie; unabhängige Durchsicht 13; Änderungen beim Bau 12; gebaut mit 23.81; auf dem Pi erst mit dem Paket
  nach 23.81, siehe `update.py`),
  `KONZEPT_Wende.md` (U226, vorab festgelegt am 25.10. 10:41: Regeln laut Video und Festlegungen, Nachrechnen, Urteil, Beschreibendes,
  Labor; unabhängige Durchsicht und Kalibrierung in 3.9 und 8; gebaut mit 23.83; auf dem Pi erst mit dem Paket nach 23.83, siehe
  `update.py`),
  `KONZEPT_Prognosemaerkte.md` (U235, vorab festgelegt am 27.10.: Quellen, Takt, Rückblick, H1–H3, Anzeige, Proben; unabhängige
  Durchsicht mit Nachtrag 13.1 (feste Regeln R1–R15), Nachtrag 13.2 beim Einbau; gebaut mit 23.88),
  `RECHERCHE_Prognosemaerkte_27-10-2026.md` (Kalshi, Polymarket und HIP-4 als Datenquellen: Märkte, Schnittstellen, Historie,
  Grenzen, Zugang aus Deutschland, belegte Güte, Bausteine; Grundlage von U235; Berichtigung zum Hyperliquid-Gewicht vom 27.10.),
  `KONZEPT_Volatilitaet.md` (U237, vorab festgelegt am 28.10.: Index, Prognose, Rückblick, V1–V4, Anzeige, Proben; unabhängige
  Durchsicht mit Nachtrag 13 -- geht den Abschnitten 0–12 vor --, 13.21 beim Bau gemessen; gebaut mit 23.90),
  `RECHERCHE_Volatilitaet_28-10-2026.md` (Volatilitätsprognose: HAR und Verwandte, DVOL, Termine, Wochentage, Prüfverfahren;
  Grundlage von U237),
  `KONZEPT_TradingEngine.md` (U241, vorab festgelegt am 03.11. nach zwei unabhängigen Durchsichten, Fassung 3; Entscheidung des
  Nutzers 03.11. 23:23; Abschnitt 15 beim Bau festgelegt und gemessen; gebaut mit 23.93),
  `notbremse_termine.json` (Termine der Notbremse in UTC, pflegt der Nutzer; `update.py` überschreibt sie nicht),
  `PROPOSAL_Kalibrierung_Stufe2_3.md` (historisch, durch den K2-Neubau ersetzt), `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
  (historisch), `labels.json` (eigene Kontonamen, Sperren/Schutz), `accesstokens.json`, `android/` (WebView-App).

## 3. Eiserne Regeln (nie brechen)

1. **Zeitstempel in Sekunden** (Ausnahme: `addresses.last_trade/first_seen` in ms; Grenze 1e11).
2. **Seiten** normalisiert `long`/`short`; Klassen `dir`/`mixed`/`hedge`/`mm`; `liquidations.side` ist roh `A`/`B` (A = Long liquidiert).
   `cb_bars.buy_usd/sell_usd` sind vor `cb_meta` 'seite_umstellung' VERTAUSCHT gespeichert (U41) — nur mit `hl_forecast.cb_seite_ab` lesen.
3. **API-Gewicht:** Deckel 90 % von 1.200/min (1.080), Begrenzer mit Rang (0 Leaderboard, 1 Poller/Orders, 3 Fills) und
   arbeitserhaltender 20-%-Reserve für den Hintergrund. **userEvents-Abos: höchstens 10 Nutzer je IP** (Hyperliquid-Limit).
4. **n_eff = getrennte Horizont-Blöcke**, nie Fensterzahl. Jeder Treiber braucht einen **Nulltest**; die Kalibrierung
   zusätzlich die **Positivkontrolle** (Kante 0,65 → p 0,60–0,70) — sie ist Selbsttest-Schritt 22 und ein Tor.
5. **Masterregel Sperre:** > 300 gebündelte Trades (je Coin, Minute, Richtung) in 24 h an ZWEI Tagen binnen 7 Tagen = dauerhaft
   gesperrt; nach dem ersten Tag vorläufig ausgeschlossen, ohne zweiten Tag nach 7 Tagen frei (seit 23.29; 23.13–23.28 ein Tag;
   vorher > 2.000 Fills, alte Sperren einmalig neu bewertet) (kein Signal, keine Orders, keine Fill-Speicherung,
   Positionen nur alle 6 h für die Heatmap). Manuell: `labels.json` `"sperre": true/false`.
6. **Elite:** n ≥ 10 Schritte im Coin, Vorlauf > 0, t ≥ 1 (auf nicht überlappenden Blöcken), Gewinn-Schranke
   (PnL 30 T > 0, Position ≤ 3 % unter Wasser), Aktivitätsschranke ≤ 300 Trades/Tag.
7. **Aktive Profis:** Pool = Kontowert ≥ 1 Mio und Tagesumsatz ≥ 500k (Leaderboard-Datei); Qualifikation 7 T:
   2–150 gebündelte Trades/Tag **in den verfolgten Coins** (seit 23.31; vorher 5–150); Gewinn 7 T > 0; seit 23.32 Timing über ALLE
   Ein- und Ausstiege (mindestens 4, Glückswahrscheinlichkeit ≤ 5 % gegen die Zufallsquote je Coin und Richtung; Einstiege ab 5 nur
   als Veto: Entry-Lift nicht signifikant negativ) statt Exit-Lift ab 5 Ausstiegen. Ein-/Ausstiege aus whale_positions, lb_events
   und -- seit 23.34 -- pool_positions (dieselbe Entscheidung binnen 15 min einmal). Rang: eigene ROI 12 h, sonst HL roi_1d.
   Die Fills der Darwin-Liste sammelt der Recorder seit 23.34 ohne Mindestbetrag (gedeckelt); pool_fills_hourly zählt weiter ab 2.500 USD.
8. **Version und Prüfsumme sind gepaart:** Jede Codeänderung → `version.py` hochzählen (Format `JJJJ-MM-TT.n`). Die
   Systemkachel „Version" zeigt beides; der Nutzer gleicht ab.
9. **Paketname immer `hl_liq_project.zip`** (Update-System des Pi). Inhalt: alle Projektdateien in einem Ordner
   `hl_liq_project/` plus `android/`.
10. **TradeLabor-Regeln sind eingefroren** (seit 23.33): eine Strategie nie „nachbessern“ -- jede Regeländerung ergibt eine
    neue Kennung (name@Prüfsumme) mit eigener Bilanz, die alte bleibt stehen. Bewertet wird nur mit „Glück“ (Student-t ×
    Zahl der Strategien) und den Stufen; die Kontrollen Zufall und Halten laufen immer mit. Seit 23.34 zählen t, Glück,
    Hälften und Stufen **Blöcke** (Trades einer Strategie im selben Horizont-Block = eine Beobachtung, Regel 4); ein neuer
    Coin (XMR) zählt ab seinem eigenen Start (Kontotage).
11. **Dokumente in derselben Antwort aktualisieren:** `UEBERGABE` (neuer Abschnitt 3xxx oben nach „## 0."), `UPDATE_PLAN`
    (Status, Stand, neue Punkte). Was dort nicht steht, existiert nicht.
12. **Notbremse** (seit 23.76, U206, `KONZEPT_Notbremse.md` 2.3): Jeder Weg zu einer neuen oder größeren Long-Position geht durch
    `notbremse.darf()`; sie blockiert nie ein Schließen. (Im Konzept als „Regel 11“ vorgeschlagen; 11 ist hier schon vergeben.)
13. **Selbstheilung des Dashboards** (seit 23.78, U215): `WATCHDOG=1` an systemd nur aus dem Faden „lebenszeichen“ und nur nach einer
    Antwort der eigenen Seite `/lebt`; `/lebt` braucht weder Datenbank noch Sperre. Jede Änderung an der Unit des Dashboards muss auch
    rückwärts passen: Die Wiederherstellung erzeugt die Units mit dem `install.py` des zurückgespielten Stands neu.

## 4. Arbeitsweise in der Sitzung (Sandbox)

- Arbeitsverzeichnis `/home/claude`; Paket dorthin entpacken (`unzip -o hl_liq_project.zip && cp -r hl_liq_project/* .`).
- **Keine Netzverbindung** in der Sandbox (kein pip, keine API); numpy, node, playwright sind vorhanden.
- **Tests:** `python3 install.py --selftest` (37 Schritte seit 23.63, ~6–8 min; im Hintergrund starten und Log greppen),
  `python3 hl_hebel.py --selbsttest` (seit 23.63; seit 23.64 63 Prüfungen, ~26 s, ohne Netz),
  `python3 hl_chartbild.py --selbsttest` (seit 23.65; 42 Prüfungen, ~5 s, ohne Netz; Demo-Datenbanken für Bildschirmfotos mit
  `--demo <ordner>`),
  `python3 hl_zyklus.py --selbsttest` (seit 23.62, 17 Prüfungen, ~35 s, ohne Netz),
  `python3 hl_swing.py --selbsttest` (seit 23.61; seit 23.62 21 Prüfungen, ~25 s, ohne Netz),
  `python3 hl_regime.py --selbsttest` (seit 23.59; seit 23.60 28 Prüfungen, ~35 s, ohne Netz),
  `python3 hl_makro.py --selbsttest` (seit 23.47; seit 23.56 56 Prüfungen, ~10 s, ohne Netz, unabhängig von einem echten FRED-Schlüssel),
  `python3 check_treiber.py` (Harness), `python3 hl_forecast.py --nulltest`, `python3 hl_kalib.py --nulltest`,
  `python3 hl_profis.py --nulltest` (seit 23.57 ~12 s mit dem Schatten-Teil), `python3 hl_konstellation.py --nulltest`, `python3 hl_score.py`,
  `python3 hl_labor.py --selbsttest` (seit 23.40 mit Grid, seit 23.61 mit Swing, ~90–105 s), `python3 hl_fusion.py --nulltest` (seit 23.42, ~30 s), `python3 hl_kaskade.py --nulltest` (seit 23.43, seit 23.44 ~40 s), `python3 hl_magnet.py --nulltest` (seit 23.45, ~21 s), `python3 hl_anker.py --nulltest`, `python3 hl_adressfluss.py --selbsttest`, `python3 hl_recorder.py --selbsttest-fills`,
  `python3 hl_viz.py --selbsttest-last`, `python3 hl_recorder.py --selbsttest-start`, `python3 hl_recorder.py --selbsttest-sperre`,
  `python3 hl_recorder.py --selbsttest-gewicht` (Begrenzer in virtueller Zeit: Ereignisschleife mit springender Uhr --
  so lassen sich Stunden Last in Sekunden prüfen; Muster für weitere asyncio-Tests),
  vollständig `python3 install.py --selftest-isoliert`,
  JS-Syntax: alle `<script>`-Blöcke aus `hl_viz.PAGE` extrahieren und mit `node --check` prüfen; seit 23.47 zusätzlich
  `hl_makro_js.MAKRO_JS` (eigene Datei `/makro.js`), seit 23.65 `hl_chartbild_js.CHARTBILD_JS` (`/chartbild.js`). Browserprobe des
  Chartbilds (seit 23.65): Dashboard auf Demo-Datenbanken (`hl_chartbild.py --demo`, Hintergrund-Takte mit HL_BERICHTE=0,
  HL_LABOR=0, HL_MAKRO=0, HL_SWING=0, HL_HEBEL=0 aus), das SVG mit playwright auslesen und gegen die Nutzlast an der beschrifteten
  Achse messen -- vorher Demo frisch bauen und den Server neu starten (der Kurs ist sonst älter als 15 min und das Bild zeigt den
  Ersatz „letzter Tagesschluss“).
  Recorder-Simulation: `python3 hl_recorder.py --db s.db --simulate` (erzeugt Testdaten, ~2 min).
  Dashboard lokal: `setsid nohup python3 hl_viz.py --db s.db --serve --port 91xx &`, dann curl/playwright.
- **Patches:** Text-Ersetzungen mit `assert s.count(o) == 1` je Anker (Unikat!). Anker vorher mit grep prüfen;
  bei Python-Heredocs keine deutschen Anführungszeichen/Gedankenstriche in doppelt-quotierten Strings (Syntaxfehler) —
  Patch-Skripte als Datei (`create_file`) schreiben, nicht als Heredoc. Lange Befehle werden abgebrochen: Schritte klein halten.
- **Packen:** Ordner `hl_liq_project/` aufbauen (Dateiliste in Abschnitt 2), `python3 version.py` im Ordner drucken,
  `zip -rq /mnt/user-data/outputs/hl_liq_project.zip hl_liq_project`, danach `present_files`.
- **Vor dem Packen:** `rm -f s.db* forecasts.db* labels_cache.json sys_history.json` (Testdateien nicht mitliefern).

## 5. Der Nutzer und seine Vorlieben

Deutschsprachig, technisch versiert, betreibt das System selbst (Update-Knopf im Dashboard, Debug-Einträge, Screenshots).
Erwartet: erst Daten prüfen, dann entscheiden; Fehler klar benennen (auch eigene); keine Behauptungen ohne Beleg; jede
Änderung mit Probe; Zahlen mit Intervallen; keine neuen Fehlerquellen. Er liefert Debug-Ausgaben und Screenshots auf
Anfrage — konkret sagen, welcher Debug-Eintrag gebraucht wird. Lange Erklärungen nur, wenn er fragt („Für mein Verständnis…").
Antworten enden mit Version · Prüfsumme des Pakets. **Nummern und Abkürzungen (U142, H1, 13.11 …) kann er sich nicht merken
(11.10.):** offene Entscheidungen in Klartext erklären und als Auswahl zum Anklicken vorlegen, mit Vorschlag und Folgen je
Möglichkeit.

## 6. Aktueller Stand (23.09.2026)

- Pi läuft Version 23.6 (laut Nutzer 11:20); 23.7–23.10 bereit. Alle Quellen grün, Leaderboard 82 s/17,5 s, Fills 593 s,
  15 Gesperrte, Fills-Stream 668 Konten, keine 429.
- **Kalibrierung:** v1 (alt, trägt die Prognose) ist strukturell lernunfähig (Audit v10 K2, selbst nachgestellt);
  v2 (`hl_kalib.py`) läuft im Schatten, Tor bestanden; Umschalten = U7b nach 1–2 Wochen, wenn die direkte Bilanz v2 ≥ v1.
  **Beim Umschalten auch den Pfad (Bias) auf v2 umstellen** (offen, Teil von U7b).
- **Aktive Profis:** Phase 0–3 + U5 live; erster echter Lauf: 692 Pool → 73 aktiv mit Gewinn → 6 qualifiziert.
- **Konstellationen/Vorbedingungen:** Stufe 1 live (Anzeige + Tageshistorie); Stufe 2 (Interaktionsterme in v2) wartet auf stabile Paare.
- **Audit v10:** Stand 23.16 siehe Plan; U8 gebaut, offen U7b, U9–U13, U16–U24, U27, U29, U35, U36, U38. Proben P2 (K1) und P1 (Coinbase-Seite) bestanden (U1, U2).
- **Geklärt heute:** Leaderboard-Flow „0 Konten in 60 min" = ruhige Stunde, nur 6 der Top-75 halten BTC (U26 geschlossen);
  Vorschlag U27: Flow-Treiber auf Basis der qualifizierten Profis.

**Nachtrag 27.09. (23.33):** TradeLabor (U71) und Adress-Strom (U72) sind neu; Einzelheiten in UEBERGABE 3β. Als
Nächstes: informierter Fluss je Adresse aus dem Adress-Strom (U75, braucht ≥ 3 Tage Daten), dann weitere Labor-Strategien
(U76). Eine Demo-Datenbank für Ansicht und Probe entsteht mit einem kleinen Generator (Bars/Buch/ctx/Heatmap für BTC, ETH,
ZEC, HYPE, Prognosespeicher mit Treibern) und `Labor.zyklus(t)` über vergangene Zeitpunkte.

**Nachtrag 29.09. (23.34):** Alle Korrekturen nach dem ersten Labor-Tag (UEBERGABE 3γ, U77–U81): Profi-Bewertung liest
pool_positions (die Darwin-Liste war ausgetrocknet), Recorder sammelt die Fills der Liste ohne Mindestbetrag, Darwin v2 im
Labor (15-min-Summe, halbe Schließung als Ausstieg, neue Kennung), Blockstatistik, XMR als fünfter Labor-Coin (HIP-3-Gebühr
×2 angenommen), Bericht mit Darwin- und Gebühren-Prüfung und allen offenen Positionen. Tests: `python3 hl_recorder.py
--selbsttest-fills` (neu), Labor-Selbsttest 24 Prüfungen, Profis-Nulltest mit Quellen-Probe. Umstellungsprobe 23.33 → 23.34
auf einer Demo-Datenbank (alte Kennungen bleiben, XMR ab dem Update, Kontotage je Coin). Nächstes: U75 (informierter Fluss),
TWAP gegen ausgelöste Orders trennen (U82), weitere Labor-Strategien (U76).

**Nachtrag 30.09. (23.35):** Dauerlast des Dashboards (UEBERGABE 3δ, U83): Abfragen über die ganze, unbegrenzt wachsende
Tabelle whale_positions plus Zwischenspeicher ohne Einzelflug stauten sich (hl_viz 366 %). Regel ab jetzt: **jüngste Stände nie
über die ganze Historie** (Fenster; offene Wal-Positionen haben alle 10 min einen Snapshot), **teure Berechnungen im Dashboard
immer mit Einzelflug** (eine Berechnung, die übrigen bekommen die vorige Antwort). Werkzeuge: Debug „Dashboard-Threads“ (jetzt mit
CPU je Thread), `python3 hl_viz.py --selbsttest-last`. Lastproben mit Millionen Zeilen gehören zu jeder Abfrage auf wachsenden
Tabellen.

**Nachtrag 30.09. (23.36):** Thread-Abzug auf 23.35 ruhig (13 Threads, dauerhafte 0 %). Dieselbe Regel galt noch nicht beim
Recorder-Start: `restore_whales` las die ganze Wal-Tabelle per korrelierter Unterabfrage (2 Mio Zeilen 40 s, quadratisch
wachsend, vor dem Start der Aufzeichnung). Jetzt `wal_zustand_laden`: 24 h vor dem LETZTEN EINTRAG, close gewinnt bei
gleichem Zeitstempel, Gesperrte nicht übernehmen (U85). Gesperrte Wale ließen geschlossene Positionen für immer im Zustand
(`del` in der H3-Bedingung), die Exposure-Zeitreihe zählte Gesperrte mit (U86). Debug „Dashboard-Threads“ zeigt jetzt auch
die Gesamt-CPU des Prozesses: Kurze Anfragen fehlten in der Liste je Thread (U87). Einzelheiten: UEBERGABE 3ε.

**Nachtrag 30.09. (23.37):** Aktive Profis (UEBERGABE 3ζ, U88–U90). Zwei Dinge zugleich:
(1) Eigener Fehler aus 23.34: Die Masterregel zählte die kleinen Fills, die seit U79 nur für Darwin-Konten gespeichert
werden -- die besten Mitglieder wurden vorläufig gesperrt und fielen von der Liste. Regel ab jetzt: **Wenn eine Messung
für eine Teilmenge erweitert wird, prüfen, welche Regeln diese Messung lesen** (hier: Masterregel, Vorhalt).
(2) Darwin-Regeln v2: streng hinein (Glück ≤ 1 %, 14 T), großzügig bleiben (Glück ≤ 50 %), Abstieg nach 3 Tagen.
Die Tagesentscheidung ist die reine Funktion `hl_profis.darwin_tag` (im Nulltest geprüft). Regeländerungen an der Liste
vorher simulieren (Population mit und ohne Vorsprung, Anteil der Könner auf der Liste, Zufallsaufnahmen je Woche).

**Nachtrag 30.09. (23.38):** Bericht vom ersten Tag mit 23.37 (UEBERGABE 3η, U91–U96).
(1) Darwin-Regeln v3: Die Schonung (Verbleib großzügig, 3 Fehltage) gilt nur für Konten mit strenger Aufnahme (Merker
`streng`); der Umstieg auf v2 hatte sie auch Altbestand und einer Rückkehr über die Verbleib-Regel gegeben. Lehre: **Bei
einem Regelwechsel mit Hysterese festlegen, wer beim Umstieg in welchem Zustand startet** -- sonst umgeht der Übergang die
strenge Seite. (2) Die Neubewertung der Masterregel gab ein Konto frei, bei dem kein kleines Bündel mitgezählt war
(Nachzählung zu niedrig, vermutlich gelöschte Rohfills); jetzt muss die Nachzählung die Sperre nachvollziehen, die Freigabe
ist zurückgenommen. Lehre: **Eine Neubewertung vergleicht mit Daten, die inzwischen der Vorhalt gekürzt haben kann.**
(3) API-Gewicht hart gedeckelt (gleitendes Fenster, Klemme, leerer Start); der Begrenzer wird jetzt in virtueller Zeit
geprüft. (4) Eine eigene Aussage war falsch: SilkBtc flog nicht wegen des Zählfehlers, sondern nach den alten Regeln.

**Nachtrag 30.09. (23.39):** Zwei Kopier-Vorlagen im Labor (UEBERGABE 3θ, U97–U99): „Darwin-Liste live folgen“ und neu
„Elite live folgen“, nach derselben Regel und je mit Gegenprobe; die Kopier-Logik ist eine Funktion mit Zustand je Vorlage.
Lehre: **Ein Prüfwerkzeug rechnet mit denselben Funktionen wie das System** (check_elite hatte eine eigene Einstufung und
keinen Sperrfilter und zeigte deshalb eine andere Elite als die, die das System nutzt). Das Labor läuft jetzt bis zur
Auswertung U99 (ab 11.10.) unverändert weiter; Regeländerungen an Strategien nur mit neuer Kennung.

**Nachtrag 01.10. (23.40):** Grid-Bots im Labor (UEBERGABE 3ι, U100–U102): „Grid Long“ und das Spiegelbild „Grid Short“
mit eigener Mechanik in `hl_labor.py` (`_grid*`; die übrigen Strategien überspringen sie). Bewertet nach Bestandswert
(Tagesergebnis = realisiert + Änderung des unrealisierten Bestands, `labor_grid_tag`), nicht nur realisiert. Lehren:
(1) **Eine neue Strategie vor dem Einfrieren auf einem synthetischen Markt mit den Szenarien laufen lassen, die der Nutzer
beschreibt** -- hier hätte ein 15-min-Auslöser den Wunsch „nicht zu früh verkaufen“ in einer schnellen Rallye verfehlt, und
ein Trendmaß ohne Richtung baute dreimal in einen Abwärtstrend hinein. (2) **Bei Strategien mit Bestand (Grid, DCA) nie nur
realisierte Gewinne zählen.** (3) **Regeln mit Mutationen prüfen**: Drei Regeln (Kapitaldeckel mit alten Losen, Stop in der
Auslöserkerze, Notlinie) trafen die Szenarien nicht zuverlässig -- dafür Mikro-Proben auf festen Kerzen. Ungefragt mit
geliefert: die Antwort auf „verzögern lange Läufe die Signale?“ (nein; U95-Kriterium präzisiert).

**Nachtrag 02.10. (23.41):** „database is locked“ im Labor (UEBERGABE 3κ, U103) -- eigener Fehler aus 23.40: ein von Hand
ausgeführtes `BEGIN` öffnete eine Lese-Transaktion, ein fremder Commit machte ihren Stand veraltet, der nächste Schreibzugriff
scheiterte sofort. Lehre: **Eine Transaktion, die liest und danach schreibt, beginnt im WAL-Modus immer mit `BEGIN IMMEDIATE`**
(seit dem 14.09. im Recorder so, `hl_dbcoord` warnt davor) -- vor jedem neuen `BEGIN`/`SAVEPOINT` im Code nach dieser Stelle suchen.
Dazu der Praxis-Hinweis zu den Grids: Hyperliquid verrechnet Long und Short je Konto und Coin; live bräuchte jede Strategie einen
eigenen Sub-Account.

**Nachtrag 04.10. (23.42):** Fusionsprognose, Kalibrierung v3 und Kostenschwelle -- Stufe 1 von `KONZEPT_Fusion.md`, alles im
Schatten (UEBERGABE 3λ, U104–U112). Neu `hl_fusion.py`: Kostenschwelle p* = ½ + K/(2·E|r|) je Coin und Horizont; v3 = v2 über alle
Coins geteilt auf den Familienwerten; Fusion = Expertenmischung (Basisrate, v1, v2, v3, Analog) mit Garantie gegenüber dem besten
Experten, prequential in `fusion_fall`; zwei Labor-Strategien. Auswertung U108 ab 25.10.; umgeschaltet wird nur mit Beleg. Lehren:
(1) **Standardfehler über Coins zählen Zeitblöcke als Klumpen** -- Blöcke verschiedener Coins zur selben Zeit hängen zusammen (in der
Probe war der naive Standardfehler 1,75-mal zu klein). (2) **Die 1-SE-Regel braucht einen GEPAARTEN Standardfehler**; die Streuung der
Fold-Mittel enthält die gemeinsamen Unterschiede der Folds und macht die Regel übervorsichtig. (3) **Erwartungen einer Probe aus der
Mathematik ableiten, nicht aus dem Gefühl:** Fixed Share hält Gewichte gemischt, schlafende Experten behalten ihr Gewicht -- zwei
Prüfungen waren zuerst falsch formuliert, nicht der Code. (4) **Anzeige gehört nicht in den gespeicherten Payload** (sonst +4,2 kB je
Prognosezeile). Rechenhilfe für Erwartungen: 14 Tage Halbwertszeit über 90 Tage = rund 237 effektive 4-h-Blöcke je Coin
(Standardfehler der Trefferquote 3,3 Punkte).

**Nachtrag 04.10. (23.43):** Kaskaden-Gleichung, Stufe 2b von `KONZEPT_Fusion.md` (Abschnitt 4b), alles im Schatten (UEBERGABE 3μ,
U113–U117). Anlass war die Frage nach einer „komplexen Funktionsgleichung“ für den Kurs. Antwort: Für den Kurs gibt es keine, für
seine Verteilung schon.

Neu `hl_kaskade.py`:
- Wurzelgesetz I = Y · σ_Tag · √(Q / V_Tag) auf die Liquidationscluster der Heatmap.
- Kaskade als Fixpunkt mit geschlossener Form für P(Ausschlag ≥ m).
- Kipppunkt und Ende je Seite.
- Schatten-Treiber „Kaskaden-Asymmetrie“ und Familie „Kaskaden“.
- Kalibrierung Y je Coin und Horizont mit Placebo und Seitenspiegel.
- Labor-Strategie „Kaskaden-Kipppunkt“.

Urteil ab 25.10. (U115). Lehren:
1. **Ein Zeit-Placebo allein reicht nicht.** Nahe Cluster gehen oft mit höherer Schwankung auf BEIDEN Seiten einher. Erst der
   Seitenspiegel (dieselben Cluster, Seiten vertauscht) trennt Mechanik vom Mitlaufen; in der Probe ließ das Placebo allein 1 von 4
   Störfaktor-Läufen durch.
2. **Lastproben müssen die Breite eines Datensatzes abbilden, nicht nur die Länge.** Mit 100 Eimern je Heatmap-Stand war alles
   schnell. Mit 800 Eimern kostete das Lesen ganzer Stände 354 MB je 30 Tage, rund 1 GB bei 90 Tagen im Dashboard-Prozess. Jetzt
   laufen je Block gezielte Abfragen: der erste Stand per `MIN(ts)` über `ix_heat_coin_ts`, die Eimer per Bereich im Primärschlüssel.
3. **Wer einen Weg schneller macht, braucht ein Orakel.** Der alte Weg bleibt als Vergleich im Selbsttest. Zwei Mutationen (zu
   schmales Fenster, letzter statt erster Stand) fängt NUR diese Prüfung.
4. **Ein Schatten-Treiber außerhalb von PRIORS** bleibt aus dem v1-Lernen und aus v2 heraus. Er steht aber in `forecast_drivers`,
   also in Familien, Ereignis-Profilen und Hygiene. Seine Trefferzelle in der Treibertabelle braucht einen eigenen Text, sonst steht
   dort „nie |Score| > 0,05“.

**Nachtrag 04.10. (23.44):** Die erste echte Kalibrierung der Kaskaden-Gleichung vom Pi (UEBERGABE 3ν, U118, `KONZEPT_Fusion.md`
4b.1a). Nichts belegt; BTC 1 h am nächsten. Große Ausschläge wurden in allen Coins rund halb so oft vorhergesagt wie eingetreten.
Behoben mit gemischter Schwankung (τ), dazu Spiegel beim gleichen Y, Richtungsprobe ab 20 Blöcken und ein isolierter Selbsttest.
Treiber und Kipppunkt bleiben unverändert. Lehren:
1. **Synthetische Proben brauchen die Eigenschaften echter Kurse,** nicht nur die geprüfte Mechanik: Schwankung mit Gedächtnis und
   dicke Ränder. Die Proben von 23.43 bestand das Modell, der echte Markt widerlegte es am ersten Abend. Der Testmarkt hat jetzt
   `sv_tau`.
2. **Erst die echten Daten ansehen, dann die nächste Stufe bauen.** U110 hätte auf dem falschen Nullmodell gestanden.
3. **Eine Schutzbedingung kann still in eine andere zusammenfallen.** Der Spiegel mit eigenem Y war bei Y = 0 dieselbe Rechnung wie
   „Y = 0 gegen gewählt“. Vergleiche gehören auf gleiche Komplexität.
4. **Selbsttests dürfen den echten Speicher nicht berühren.** Python bindet Standardwerte beim Definieren
   (`learned_save(..., path=STORE)`). Wer `F.STORE` umlenkt, muss den Pfad ausdrücklich übergeben. Die Mutationsprobe legt dafür
   einen Köder-Speicher an.
5. **Kleine n:** Ohne Mindestzahl keine z-Werte, und z nimmt den Standardfehler der Nullhypothese.

**Nachtrag 04.10. (23.45):** Die zweite Kalibrierung vom Pi bestätigt 23.44 (22 von 22 „vorhergesagt ≈ eingetreten“ ✓,
`KONZEPT_Fusion.md` 4b.1b). Gebaut: U110 Magnet-Test (`hl_magnet.py`, UEBERGABE 3ξ), nur Messung. Er prüft, ob der Kurs Cluster
öfter berührt, als die geprüfte Rechnung ohne Cluster erwarten lässt, mit Spiegel und Placebo; Urteil ab 25.10. Mutationen
16 von 16 rot. Lehren:
1. **Eine Eigenschaft gilt nur mit ihrer Bedingung.** Das seitengleiche Mittel heißt „trendfest“, ist es aber nur, wenn beide
   Seiten Fälle haben. Die Trendfalle (Abwärtstrend, nur Long-Cluster) zeigte es; jetzt zählen wirksame Fälle (eine Seite = 0).
2. **Jede Schutzbedingung braucht einen Testmarkt, in dem nur sie hält.** Sonst prüft der Selbsttest sie nicht wirklich: Der
   Störfaktor wie im Kaskaden-Test brachte den Überschuss nur einmal über 2 SE; erst „nur große Cluster koppeln“ zeigt den Spiegel.
3. **Nicht jede Falle ist eine Lücke.** Die Niveau-Welt (der Kurs läuft zu festen Niveaus, dort liegen Cluster) wird belegt. Das
   ist die Grenze des Tests (Vorhersage, nicht Ursache), offen benannt. Ein Placebo mit alten Preisen würde echte, tagelang offene
   Positionen mitnehmen.
4. **Testmärkte nur mit Parametern erweitern, die ohne Wert nichts ändern** (keine zusätzlichen Zufallszahlen). Der Kaskaden-Selbsttest
   liefert danach Zahl für Zahl dasselbe.
5. **Kleine Probe, falscher Alarm:** Mit 12 Seeds lag die Streuung der Spiegel-Differenz (klein) beim 1,38-Fachen des berechneten
   Standardfehlers; mit 40 Seeds liegt sie bei 0,82–1,08 über alle Größen und Kontrollen. Erst genug Wiederholungen, dann eine
   Korrektur.

**Nachtrag 04.10. (23.46):** Nutzerfund vor dem Einspielen von 23.45: In den Treiberfamilien (BTC, „Kaskaden“) stand z = 1,2 · 10¹⁶ bei
n = 3 (UEBERGABE 3ο, U119). z = Mittel / Stichproben-Streuung; drei gleiche Treffer haben Streuung 0, im Fließkomma 6,8 · 10⁻¹⁷.
Jetzt rechnen Treiberfamilien und Heatmap-Anker das z einer Trefferquote exakt (`hl_forecast.z_treffer`: Summe von Binomialen je
Erwartung, mittlerer p-Wert, |z| ≤ 7); die Ereignis-Profile geben ohne Streuung kein z. 23.46 enthält 23.45. Lehren:
1. **Bei Trefferquoten nie die Stichproben-Streuung in den Nenner,** sondern die des Zufalls (oder exakt). Bei wenigen gleichen Werten
   ist sie 0 bzw. 10⁻¹⁷, `> 0` schützt nicht.
2. **Einen Fehler auch in den Kopien suchen:** Dieselbe `_stat`-Funktion stand im Heatmap-Anker, wo „belegt“ die Hauptprognose
   ändert, und dieselbe Rechnung in den Ereignis-Profilen.
3. **Auch eine kleine Probe braucht ihre Mutationen:** Die erste Fassung der Anker-Prüfung hätte die alte Formel nur durch einen
   Absturz verraten (z war None). Jetzt prüft sie den exakten Wert.

**Nachtrag 05.10. (23.47):** Makro-Chart (UEBERGABE 3π, U121, `KONZEPT_Makro.md`). Auf Wunsch des Nutzers alles Kostenlose aus der
Recherche `RECHERCHE_Makro_Chart_05-10-2026.md` (Stufen 1 und 2), je Treiber ein Chart, dazu die Miner-Kostenbasis (Antminer S21 XP,
13,5 J/TH, 7,5 ct/kWh; Annahme US-Cent, Euro-Cent umschaltbar).
- Eigene Datenbank `makro.db` neben `hl_liq.db`, geschrieben nur vom Makro-Takt im Dashboard-Prozess (`BEGIN IMMEDIATE`), gesichert
  mit dem täglichen Backup.
- Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor, kein Hyperliquid-API-Gewicht. Fusion, v3 und Kaskaden
  unberührt (Zusage bis 25.10.).
- Im Paket außerdem U120 (v2-Kachel misst den Brier-Skill gegen denselben Kalibrierschritt mit c = 0) und U122 (Selbsttest
  „Recorder: Masterregel ohne Kleinfills“ lief mit der echten Uhr und ist seit 05.10. rot -- auch mit 23.46; das System rechnet
  richtig).

Lehren:
1. **Tests mit festen Daten brauchen eine feste Uhr.** Eine vorläufige Sperre „vor dem 29.09.“ war am Tag des Schreibens 2 Tage
   alt, am 05.10. 7 Tage: Die Sieben-Tage-Regel gab sie frei, der Test wurde rot. Das Muster (U34/U36) war bekannt.
2. **Freie Quellen fallen still aus.** Verschwindet eine Metrik oder ändert eine Seite ihr Format, antwortet der Abruf oft
   weiter fehlerfrei. Deshalb prüft der Makro-Stand das Alter jeder Reihe und meldet Reihen, die nach einem erfolgreichen Abruf
   fehlen. Das war mein eigenes Abnahmekriterium; ich habe es erst beim Schreiben der Doku als fehlend bemerkt und nachgebaut.
3. **Anlauf verwerfen, bevor man Extremwerte vergleicht:** Das MVRV beginnt 2010 mit 146 (Anlauf der realisierten
   Kapitalisierung). Erst mit 180 verworfenen Tagen stimmen die Epochen-Hochs mit der Literatur.
4. **Ein Modul, das ein anderes im Speicher hält, liefert nach dem Kopieren noch die alte Fassung:** Der lokale Testserver
   lieferte `/makro.js` nach einer Änderung weiter aus dem schon importierten Modul. Nach Änderungen an `hl_makro_js.py` den
   Dienst neu starten (auf dem Pi tut das das Update).

**Nachtrag 05.10. (23.48):** Erster Pi-Lauf des Makro-Charts (Bild des Tabs „Daten“, 12:14; UEBERGABE 3ρ, U123–U125).
- Die meisten Quellen laufen, ihre Formate sind belegt.
- FRED hängt ohne Schlüssel (`fredgraph.csv` antwortet seit Mitte August 2026 vielerorts nicht). Jetzt läuft FRED über die
  offizielle API mit kostenlosem Schlüssel. Der Nutzer trägt ihn im Makro-Tab „Daten“ ein, er landet in `accesstokens.json` →
  `"fred"`.
- Antwortet ein Host nicht, überspringt der Takt die übrigen Ziele dieser Quelle in der Runde. Vorher hielten 12 × 45 s den Takt
  9 Minuten an.
- BGeometrics liefert frei mit 7 Tagen Verzug: Frische-Grenze 9 Tage, Hinweise in Kohorten und Zonenkarte.

Lehren:
1. **Erreichbarkeit ist nicht Format.** Das Abrufwerkzeug der Sandbox liest Seiten, die ein Skript auf dem Pi nicht bekommt.
   Neue Quellen erst nach dem ersten echten Abruf auf dem Pi als belegt führen.
2. **Kein Ziel darf den Takt anhalten:** kurze Wartezeit, Abbruch je Quelle, Pause mit Verdopplung.
3. **Freie Stufen genau lesen:** Verzug, Fenster und Kontingent sind drei verschiedene Grenzen.

**Nachtrag 05.10. (23.49):** Makro-Signale (UEBERGABE 3σ, U126, `KONZEPT_Makro.md` Abschnitt 9). Auf Wunsch des Nutzers je Chart mit
Referenzlinie (14 Paare) und Zeitraum (1/2/4/8 J, alles): Abweichung in %, Median, ideale Wendepunkte im Rückblick, Live-Signal
(unterstes/oberstes Zehntel des Zeitraums, nur Daten bis zum Tag), Bilanz gegen Zufallstage, Prognose „Rückkehr zum Median“ mit
80-%-Band; täglich, Tagesstand in `mk_signal`.
- Neues Modul `hl_makro_signal.py` (reine Rechnung); `hl_makro.py` rechnet es einmal je Datentag, archiviert und vergleicht das
  Archiv mit der Nachrechnung („Live gegen Nachrechnung“).
- Auf echten Daten (bis 23.05.2026): 3 von 322 Bilanz-Tests belegt, der Zufall allein ließe etwa 16 erwarten. Die Zonen beschreiben
  eine Lage, sie sagen keine Rendite voraus; Verkaufssignale kamen zu früh (Momentum). Die Prognose schlägt „die Abweichung
  bleibt“ in 78–83 % der Fälle, ihr Band traf 81–85 %.
- Fusion, v3 und Kaskaden unberührt (Zusage bis 25.10.).

Lehren:
1. **Signifikanz erst auf Zufallswegen kalibrieren.** Ein Block-Bootstrap über alle Signaltage erklärte 26–41 % der Zufallstests für
   belegt: Läufe, in denen der Kurs weiter fällt, sind länger und zählen mit mehr Tagen. Episoden mit lokalem Placebo: 3,2 %.
2. **Ein Band aus Fehlern, die man am Ursprung nicht kannte, bestätigt sich selbst.** Der Test dafür braucht wachsende Schwankung;
   bei gleichbleibender trifft auch das falsche Band 80 %.
3. **Texte sind Behauptungen.** „So wie es damals sichtbar war“ stimmt nur ohne Datenrevision. Jetzt prüft das Archiv es täglich.

**Nachtrag 05.10. (23.50):** OI-Chart baute sich nicht auf (Bild 16:04; UEBERGABE 3τ, U128). Binance-REST liefert nur 30 Tage, das
Archiv lief ab 2020 vorwärts; im Zeitraum 4 J war deshalb nur ein Strich am rechten Rand zu sehen. Jetzt lädt das Archiv
rückwärts (jüngste Tage zuerst), unter dem Chart steht der Ladestand, und die Zonenkarte zeigt kein OI-Perzentil, bis die
Historie vollständig ist.

Lehre: **Den halb geladenen Zustand ansehen.** Ich hatte die Charts leer und voll geprüft, nicht im Zustand nach den ersten
Stunden auf dem Pi.

**Nachtrag 05.10. (23.51):** Im Makro-Überblick steht unter der Zonenkarte „Verlauf je Indikator“: je Zeile ein kleiner Chart der Reihe
hinter der Zahl (UEBERGABE 3υ, U129). Die Probe vergleicht jeden Punkt mit der Ableitung, nicht nur den letzten -- mit konstanten
Testdaten (Funding) wäre eine vertauschte Reihe sonst unentdeckt geblieben.

**Nachtrag 05.10. (Plan, nur Dokumente):** U130 „Makro × Kurs“ -- Wunsch des Nutzers, am 25.10. auszuwerten. Die Tests stehen vorab
festgelegt in `KONZEPT_Makro.md` Abschnitt 10 (Teil A: Makro gegen BTC-Rendite vorwärts über die ganze Historie; Teil B: Makro-Regime
gegen die 4-h-Prognosen). Wer die Auswertung baut: zuerst Abschnitt 10 lesen und nichts daran ändern, was das Ergebnis begünstigt.

**Nachtrag 05.10. (23.52):** U130 Teil A gebaut (`hl_makro_korr.py`, UEBERGABE 3χ, `KONZEPT_Makro.md` 10.4): Makro-Merkmale gegen die
BTC-Rendite der folgenden 1, 7 und 30 Tage, Debug-Bericht, Berichte 06.10. und 25.10.

Lehre: **Ein Nullverfahren erst zählen, dann glauben.** Die im Plan genannte zirkuläre Verschiebung „erhält die Autokorrelation“ und
war trotzdem zu großzügig (6,5 % statt 5 %, bei Perzentilen 8,7 %), der Blockbootstrap noch mehr. Erst 4.050 Tests auf Zufallswegen
zeigten es; ein erster Lauf mit 720 Tests schwankte zu stark für ein Urteil. Phasen-Surrogate halten 5,4 %.

**Nachtrag 05.10. (23.53):** Nutzerfund 20:42: Unter „Vorbedingungen“ stand „vor Rückgängen noch zu wenige Ereignisse“, obwohl der
Chart mehrere Rückgänge über 3 % zeigte (UEBERGABE 3ψ, U131). Ursache: Bezugskurs war nur die erste Prognose je 4-h-Block, und
Ereignisblöcke bis 24 h auseinander wurden verkettet. Jetzt zählt jede gespeicherte Prognose (15 min), ein Ereignis ist eine
Bewegung; die Anzeige listet die erfassten Ereignisse, der Debug-Eintrag „★ Vorbedingungen: Ereignisliste“ gleicht sie mit den
Kursdaten ab. Basis und Konstellationen sind bitgleich geblieben.

Lehre: **Einen Ereigniszähler gegen das prüfen, was der Chart zeigt.** Der Nulltest sagte seit 23.7 „bestanden“ -- er prüft nur,
dass Rauschen keinen Lift erzeugt, nicht, ob die Ereignisse vollständig sind. Ein grobes Raster (4 h) verkleinert Bewegungen
systematisch, weil sein Beginn fast nie am Hoch liegt.

**Nachtrag 05.10. (23.54):** Wunsch 22:21: Makro-Charts mit dem BTC-Kurs (orange) überlagern, um Korrelationen zu erkennen
(UEBERGABE 3ω, U132). Gebaut als **Kursleiste**: unter jedem Kennzahl-Chart ein eigenes Feld mit dem Kurs (eigene log. Skala,
dieselbe Zeitachse, gemeinsames Fadenkreuz, Tooltip und Tabelle mit Kurs), Schalter „BTC-Kurs“. Keine zweite y-Achse im selben
Feld: Deren freie Skalierung macht fast jede Reihe im Bild gleichläufig. Gleichlauf im Bild ist bei Kennzahlen aus dem Kurs ohnehin
mechanisch; ob eine Kennzahl vorhersagt, misst U130.

Lehre: **Eine Anzeige gegen Quellen außerhalb ihres Codes prüfen.** Die Browserprobe vergleicht den Tooltip mit dem Rohkurs in
`makro.db` und die Pfadhöhe mit der beschrifteten Skala; Sollwerte aus denselben JS-Funktionen hätten einen Zeitversatz der Leiste
bestätigt. Und eine Reihenprüfung prüft Anfang UND Ende -- die Server-Prüfung sah zuerst nur den Anfang.

**Nachtrag 05.10. (23.55):** Nutzerfund 23:18 mit zwei Fotos: Die Treiber-Hygiene nannte acht BTC-Treiber „tot“, die nur selten
aktiv sind oder erst seit Kurzem rechnen (UEBERGABE 3αα, U133). „tot“ hieß bis 23.54 jeder Treiber mit Werten in weniger als 20 % der
Zeit -- inaktive Treiber werden nicht gespeichert, also traf das genau die Ereignis-Treiber (Kapitulation, OI-Überhitzung …), dazu
Crowding-Trend 7 T und Kaskaden-Asymmetrie (jung) und Funding (immer da, fast 0). Jetzt zählen ihre aktiven Zeiten als Fälle; reicht
das nicht, steht „kein Urteil“ mit Grund. Neu sind die Spalten Fälle, aktiv und zuletzt sowie ein Intervall zu jedem r.

Lehre: **Bei Ereignis-Treibern heißt „kein Wert“ „kein Ereignis“.** Eine Prüfung, die Anteile oder feste Raster zählt, muss das
wissen. Und ein Befundwort wird benutzt: „tot“ ging am 30.09. in die Entscheidung U97 ein (Elite). Deshalb nur Wörter, die die
Messung trägt.

**Nachtrag 06.10. (nur Dokumente, U134):** Warum v1 nur 3 von 33 Gewichten „lernt“ -- bewertet mit der exakten v1-Rechnung
(UEBERGABE 3ββ). v1 teilt die Treibersumme durch die Prior-Summe 18,6, klemmt Gewichte auf 2 × Prior und verankert β; damit nutzt
es nur rund 6 % eines starken Einzelvorsprungs. Schwellen senken oder Fenster verlängern ändert daran nichts, erzeugt aber mehr
scheinbar gelernte Rauschgewichte. Empfehlung: am 25.10. die geplante Modellwahl, danach Ereignis-Experten und langes
Gedächtnis in der Fusion (`KONZEPT_Fusion.md` 5); die ehrliche Lernanzeige kommt mit dieser Erweiterung (Nutzer 06.10. 01:21).

Lehre: **Erst messen, ob ein Modell einen Vorsprung überhaupt ausdrücken kann, dann an seinem Lernen drehen.**

**Nachtrag 06.10. abends (nur Dokumente, Berichtsbündel 21:10):** Erste Pi-Läufe mit allen Quellen (UEBERGABE 3γγ). Makro × Kurs
(U130 Teil A): 0 von 45 Tests belegt, wie die Vorschau; bei 30 Tagen ist die Null so breit, dass nur sehr starke Zusammenhänge
belegbar wären. Die Nachrechnung meldet DVOL und ETF-Fluss „abweichend“, weil die Zonenkarte am offenen Tag festgeschrieben wird
-- kein Rechenfehler, ohne Folge fürs Urteil. Vorbedingungen (U131): 181 von 205 Kursdaten-Bewegungen erfasst, der Rest liegt im
Nachbarereignis oder knapp unter 3 % vom 15-min-Prognosekurs. Eigener Fehler: Die Begründungszeile des Abgleichs misst nur die
24 h vor dem Extrem und lässt lange Bewegungen größer wirken als den Schwellenrand, der sie verfehlte. Makro-Signale (U126):
4 von 336 Tests belegt, weniger als der Zufall liefert. Vier Berichtskorrekturen als U135 vorgemerkt (reine Anzeige).

Lehre: **Eine Begründung muss dieselbe Spanne messen wie die Regel, die sie erklärt; und eine Nachrechnung muss Gleiches mit
Gleichem vergleichen -- ein am offenen Tag festgeschriebener Wert ist kein Widerspruch.**

**Nachtrag 06.10. (23.56):** U135 gebaut (UEBERGABE 3δδ), reine Anzeige. Die Begründung „nicht erfasst“ im Kursdaten-Abgleich
misst jetzt alle Prognosepunkte vom Beginn bis zum Extrem mit ihrer eigenen 24-h-Bewegung und nennt den Docht; auf der Probe
wie BTC 11.09. stand vorher „-0,7 %“, jetzt „-2,7 %, 15-min-Hoch 0,6 % über dem höchsten Prognosekurs“. Die U130-Nachrechnung
führt DVOL und ETF-Fluss, wenn sie am offenen Tag festgeschrieben wurden, als vorläufig statt als Widerspruch. Der Makro-Stand
hat eine Summenzeile der Signale (belegt N von M, Zufallserwartung, Live-Signale mit Beleg der eigenen Seite). Mutationen 19
von 19 rot. Dazu die Nutzerfrage „Darwin-Aufnahme bei Glück < 3 %?“ bewertet (U136): Im heutigen Pool erwartet der Zufall bei
3 % 1,2 Aufnahmen, beobachtet sind 2; in der Simulation der Regeln v3 steigen die Zufallsmitglieder von 1,9 auf 4,9, Könner
werden nur besser abgedeckt, wenn sie selten sind. Empfehlung: 1 % lassen, Beinahe-Aufnahmen im Schatten vorwärts verfolgen.

Lehre: **Eine Schwelle über viele Konten ist ein Mehrfachtest. Lockern macht eine Liste größer, nicht besser, solange der
Pool kein belegbares Können enthält.**

**Nachtrag 07.10. (23.57):** U136 gebaut (UEBERGABE 3εε, `KONZEPT_Aktive_Profis.md` 11), auf Wunsch des Nutzers („ja“ zur
Beobachtung). Die Darwin-Aufnahme bleibt bei Glück ≤ 1 %; ein Schatten verfolgt vorwärts, wie die Beinahe-Aufnahmen (Glück
1–3 % und 3–5 %), die Aufnahmen selbst und eine Kontrollgruppe aus demselben Pool (Glück über 5 %) danach treffen. Das Urteil ist
vorab festgelegt: am 18.11.2026 (sonst 16.12.) „Timing belegt“ nur, wenn das Band 1–3 % mindestens 5 Punkte öfter trifft als die
Kontrolle (p < 0,05, ≥ 60 Entscheidungen aus ≥ 3 Konten, auch ohne jedes einzelne Konto). Die Kontrolle ist nötig, weil Konten
eher in bewegten Phasen handeln: Gegen die Zufallsquote allein sähe man dann in der Simulation in einem Viertel bis einem Drittel
der Fälle „Timing“, das keines ist. Liste, Labor und Familien sind unberührt. Dabei berichtigt: Eine Aufnahme nach v4 bekäme die
Labor-Kennung `liste=4`, nicht `liste=3` (eigener Fehler in 23.56).

Lehre: **Vorwärts zählen, die Gruppe beim Eintritt festhalten und gegen eine Kontrolle aus demselben Pool vergleichen -- sonst
misst man die eigene Auswahl oder den Zeitpunkt des Handels.**

**Nachtrag 07.10. abends (23.58):** Wochenbündel 19:44 ausgewertet (UEBERGABE 3ζζ). Dabei ein eigener Fehler aus 23.56 gefunden
und berichtigt (U137): Die Begründung „nicht erfasst“ im Kursdaten-Abgleich der Vorbedingungen maß nur noch die Prognosepunkte
zwischen Beginn und Extrem. Punkte davor, die die Bewegung schon gesehen hatten, fielen heraus. Im Bericht standen deshalb neun
ZEC-Bewegungen als „höchstens −2,1 … −2,9 %“ statt „im benachbarten Ereignis enthalten“, ein 1-min-Anstieg bei XMR als „keine
Prognose gespeichert“ (las sich wie eine Lücke der Ablage) und eine Zahl zu klein (+2,1 statt +2,8 %). Gefunden durch den Vergleich
mit dem Bericht vom Vortag, Zeile für Zeile. Jetzt zählen beide Mengen; die Proben (a2) und (i)–(n) prüfen genau diese Fälle, zwei
davon über die ganze Kette; Mutationen 19 von 19 rot. Die Zählung war nie betroffen. Dazu reine Anzeige: Die Schatten-Tabelle zeigt
„Konten (mit Entsch.)“ in einer Spalte. Befunde: BTC 11.09. ist ein Schwellenrand (−2,99 %, Docht 0,8 %); der Pool-Flow 4 h liegt
vor Rutschen wie vor Anstiegen leicht über normal (je 12 Fälle, noch nicht testbar); die Makro-Summenzeile stimmt nachgezählt;
der Schatten trägt ein, erste Zahlen ab 09.10.

Lehre: **Wer eine Begründung umbaut, prüft die Fälle der alten mit. Eine Probe deckt nur ab, woran man gedacht hat; der Vergleich
alter und neuer Bericht Zeile für Zeile zeigt, was verloren ging.**

**Nachtrag 07.10. spät abends (nur Dokumente, 23.58 unverändert):** Konzept Regime-Modul (U138, UEBERGABE 3ηη,
`KONZEPT_Regime.md`, Recherche `RECHERCHE_Regime_07-10-2026.md`), auf Wunsch des Nutzers: die jüngsten 4–8 Wochen „rückwärts“
lesen und daraus nächste Schritte ableiten (mehrtägige Stufen mit Rücksetzern zu höheren Tiefs, Uhrzeit- und Wochentagsmuster).
Recherche und Zufallsweg-Simulation zeigen: Vorhersagbar sind Größe und Zeitpunkt der Bewegungen, kaum ihre Richtung. Beine von
2–3 Tagen und höhere Hochs nach höheren Tiefs in zwei von drei Fällen liefert schon der Zufall. Uhrzeit- und Wochentagsmuster der
Richtung sind in 4–8 Wochen nicht von Zufall zu trennen (Nachweisgrenze einer Stunde in 8 Wochen 17–21 bp, dokumentiert sind
rund 4–5 bp). Das Konzept: Die Historie schätzt, das Fenster filtert; acht Bausteine R1–R8 (Schwankungsprofil mit zwei Uhren,
Bewegungsgröße 1–7 Tage, Regime-Zustand, Stufen gegen die Zufallsgeometrie, vorab festgelegte Kalenderhypothesen, Wochenmomentum,
Teilnehmer an den Wendepunkten, Regime-Analog und Pfadfächer), zwölf Anzeigen RG1–RG12, Prüfplan vorab, Phasen 0–3. Nichts ist
gebaut; die Entscheidungen 1–7 liegen beim Nutzer (Empfehlung: Phase 0 zuerst, ein Debug-Bericht auf der Historie). Die Zusage
bis 25.10. bleibt unberührt.

Lehre: **Was man in kurzen Fenstern „sieht“, erzeugt der Zufall oft schon. Jede Fensterstatistik braucht ihre Zufallsweg-Null in
derselben Auflösung, und jede Suche über Fenster ihre Bereinigung.**

**Nachtrag 08.10. nachts (23.59):** Regime-Modul Phase 0 gebaut (U138, UEBERGABE 3θθ), auf Wunsch des Nutzers („Lass uns mit Phase
0 beginnen“). `hl_regime.py` rechnet die vorab festgelegten Prüfungen P0.1–P0.9 auf bis zu drei Jahren 30-min-Kerzen je Coin und
gibt einen Debug-Bericht aus („★ Regime: Vorprüfung auf der Historie (U138)“, geplant 08.10. 21:00). Die Kerzen liegen in einer
eigenen Datei `regime.db` (Binance-Futures oder Bybit, je Coin festgehalten); `klines30` bleibt unberührt, weil die Analog-Suche
der Prognose sie liest. Vor dem ersten echten Lauf wurden die Bedingungen in `KONZEPT_Regime.md` 9.1a präzisiert und an sieben
Stellen begründet geändert, wo Nullen oder Positivkontrollen eine Schwäche zeigten (z. B. muss das Regime-Analog auch den Zufallsweg
mit σ̂ schlagen; PBO ist bei fast gleichen Varianten keine brauchbare Bedingung). Selbsttest 27 Prüfungen, Mutationen 29 von 31
rot (zwei ohne Wirkung auf die Urteile). Das Ergebnis auf echten Daten steht aus.

Lehre: **Eine Vergleichsprobe muss zählen, wie viele echte Werte sie verglichen hat. Die erste Kausalitätsprobe für Fixed Share
verglich nur fehlende Werte und hätte jeden Blick in die Zukunft durchgelassen; erst eine Mutation zeigte es.**

**Nachtrag 08.10. nachts (23.60):** Erster echter Lauf der Regime-Vorprüfung ausgewertet (Bericht 02:06 mit 23.59; UEBERGABE 3ιι,
`KONZEPT_Regime.md` 9.4).
- **Belegt:** nur Kalendereffekte bei XMR (K1 +12,3 ± 4,9 bp, also steigend statt „fällt“; K3 −82,6 ± 15,9 bp; drei
  UTC-Stunden; Persistenz des Stundenmusters) und bei PAXG (K3 −13,5 ± 4,0 bp), dazu die Fensterkombination bei ZEC und XMR.
- **Nicht belegt, also nicht vorhersagbar:** die Richtung über Stunden bis Tage. Beine sind Zufallsgeometrie, D/θ ist kalibriert,
  es gibt kein Momentum, Analoge sind nicht besser als der Zufallsweg mit σ̂, und der Bruchmelder meldet eine Verdopplung erst nach
  51–366 h.
- **Tragfähig ist die Größe:** HAR schlägt EWMA bei 1 Tag in allen sechs Coins; ein glattes Tagesprofil schlägt das heutige
  Zellenprofil in 5 von 6.
- **Eigener Fehler 23.59 (U139):** K3 verglich die 6,5-h-Sitzung mit dem ganzen Rest (im Mittel 27,1 h) und maß so die Drift mit.
  Seit 23.60 vergleicht K3 je Stunde; jede feste Drift hebt sich genau auf. Das Urteil zu K3 liefert der Lauf 08.10. 21:00.
- **Vorschlag:** Vorhaltetest auf 10/2020–10/2023 für das, was getragen hat; danach Phase 1 schlank. Entscheidungen beim Nutzer.

Lehre: **Wer Zeitfenster ungleicher Länge vergleicht, misst die Drift mit. Jeder Fenstervergleich braucht einen Nulltest mit Drift,
und eine Gleichheitsprobe einen Testmarkt, in dem sich Fehler nicht paarweise aufheben (drei Frühjahrs- gegen drei
Herbstumstellungen verdeckten eine übergangene Zeitumstellung).**

**Nachtrag 08.10. vormittags (23.61):** Swing-Trades (U140, UEBERGABE 3κκ, `KONZEPT_Swing.md`), auf Wunsch des Nutzers („Swing-Trades
in das System inkludieren … mehrere bestmögliche Strategien in das TradeLabor“).
- **Regeln vorab, nichts optimiert:** Entscheidung einmal je Tag nach 00:00 UTC, Größe nach Risiko (100 USD bis zum Stop). S1
  Trend-Ausbruch, S2 Rücksetzer im Trend, S3 Ausbruch nach Ruhe, S4 Gegenbewegung nach Übertreibung mit Funding-Druck; Kontrollen
  Zufall und Zufall im Trend.
- **Gebaut:** `hl_swing.py` mit eigener `swing.db` (Binance-Futures ab 2020, Swing-Takt im Dashboard); dieselben Funktionen für die
  Vorprüfung auf der Historie und das TradeLabor (sechs neue Kennungen, die 38 alten unverändert); Debug-Bericht „★ Swing: Vorprüfung
  auf der Historie (U140)“, geplant 08.10. 21:30 und 09.10. 07:30.
- **Urteil vorab:** ≥ 60 Trades, Tagesergebnis p < 0,05 und positiv, Mehrertrag gegen ein Zeitpunkt-Placebo nach Holm < 0,05, beide
  Hälften, DSR ≥ 0,95. Vor dem ersten echten Lauf geändert: Der Placebo-Vergleich ist studentisiert (Standardfehler aus der
  Tagesreihe). Der Rang unter den Placebo-Läufen war auf Nullmärkten nicht kalibriert (S4: 25 % statt 5 % unter 0,05).
- **Proben:** Selbsttest 20 Prüfungen, Labor-Proben (gleiche Tage wie die Historie, Signal-Ausstieg ohne Pause), Mutationen 33 von
  34 rot (eine gleichwertig), Nullreplikationen 0 von 160 belegt, Kalibrierung auf Märkten mit echtem Pfad in der Kerze.

Lehre: **Ein Rang gegen Placebo-Läufe gilt nur, wenn die Trades der Strategie unter der Null so streuen wie die des Placebos. Wer
nach starken Bewegungen einsteigt, wählt eine andere Schwankung; dann den Mehrertrag mit dem eigenen Standardfehler prüfen. Und:
Synthetische Kerzen ohne echten Pfad in der Kerze verzerren jede Simulation mit Stops und Zielen.**

**Nachtrag 08.10. spät abends (nur Dokumente, 23.61 unverändert):** Berichtsbündel 22:44 ausgewertet (UEBERGABE 3λλ).
- **Erste Swing-Vorprüfung (`KONZEPT_Swing.md` 6b): nichts belegt.** Die beiden Ausbruchsregeln sind positiv: S3 Ø +0,34 R je
  Trade (Sharpe 0,72, p 0,10, in allen Coins und Jahren positiv), S1 +0,17 R (Sharpe 0,49). Beides ist auf sechs Jahren nicht von
  Glück zu trennen. S2 liegt nahe null (Rücksetzer kaufen ≈ irgendwann im Trend kaufen), S4 verliert. Alle sechs Strategien laufen
  im Labor weiter. Neu zur Entscheidung: ein Vorhaltetest in der Breite (S1 und S3 auf weiteren Binance-Perpetuals).
- **Zweiter Regime-Lauf (`KONZEPT_Regime.md` 9.5):** Die K3-Abschätzung traf (XMR −45 bp belegt, BTC −10, ETH −23, PAXG −5
  nicht mehr belegt). P0.3-Urteile an der Holm-Grenze kippen mit einem Tag mehr Daten. Die Analog-Suche der Prognose ist bei
  72 h und 7 Tagen schlechter als der Zufallsweg (ETH, ZEC, HYPE); vorgemerkt für nach dem 25.10.
- **U126:** Live gegen Nachrechnung 192 von 192 gleich.

Lehre: **Urteile an der Holm-Grenze kippen schon mit einem Tag mehr Daten; sie zählen erst nach einem Vorhaltetest. Und eine vorab
notierte Abschätzung, die eintrifft, zeigt am besten, dass eine Korrektur das Richtige misst.**

**Nachtrag 09.10. nachts (23.62):** Zyklus-Studie und „Dip halten“ (U141, UEBERGABE 3μμ, `KONZEPT_Zyklen.md`), auf die Frage des
Nutzers (08.10. 23:45: „Dump bestätigt → kaufen, laufen lassen, vor dem nächsten Rücksetzer raus; wie lange, nach wie vielen
Prozent, welche Signale, was ist am sichersten?“).
- **Studie** `hl_zyklus.py` (nur lesend, Debug „★ Zyklen …“, Berichtsplan 09.10. 12:00): Teil A Rallyes und Rücksetzer bei
  10/20/30 % gegen 1000 Zufallswege mit derselben Drift und Schwankung; Teil B HODL, T200, VOL, Z1 Dip halten, Z2 Überhitzung,
  Z3 typisches Ziel, Z0 Zufall mit den Urteilen Timing und sicherer als HODL; Teil C Warnsignale (OI, Funding, RSI, Gier); Teil D
  Gegenprobe mit Ausführung; oben der aktuelle Stand je Coin.
- **Labor:** drei neue Strategien in der Gruppe „Swing“ (`zyklus_dip`, `zyklus_dip_heiss`, `zyklus_dip_zufall`), 44 alte Kennungen
  unverändert; dieselben Regeln wie die Studie (`hl_swing`, Art „dip“), Tag für Tag gleich geprüft.
- **Vor dem ersten echten Lauf geändert:** Teil A urteilt gepoolt je Schwelle (Mittelwert) statt je Coin und Schwelle (Median) —
  die Beingröße eines Zufallswegs hängt nicht an der Schwankung, und der alte Test erkannte selbst starke Struktur kaum.
- **Labor „überall Minus“:** kein Rechenfehler, Kosten (Stand 07.10.: 3.580 Trades, netto −72.792 USD, Gebühren 26.081).

Lehre: **Ein Test der Beingröße ist blind für Schwung von Tag zu Tag; Struktur muss man auf der Skala prüfen, auf der man fragt.
Mit Surrogaten und Holm muss die Zahl der Surrogate zur Zahl der Tests passen. Und wer eine Regel zweimal rechnet (schnell über
viele Pfade und Tag für Tag im Labor), prüft beide gegeneinander.**

**Nachtrag 09.10. nachts (nur Dokumente, 23.62 unverändert):** Bewertung der Nutzerfragen (02:05) zu Fear & Greed, Binance-Top-Tradern
und Market Makern, Hebel gegen Spot und einem Chart-Analyse-Trader (UEBERGABE 3νν; ausführlich mit Quellen im Projekt-Dokument
`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md`, nicht im Paket).
- **Zugang ist kein Problem:** Fear & Greed seit 2018, die vier Binance-Verhältnisse (darunter Top-Trader = die 20 % größten Konten
  nach Margin, nicht die besten) alle 5 min, Binance-Buch, Liquidationen von Binance, Bybit und OKX. Das Binance-Archiv „metrics“
  mit denselben Verhältnissen ab 2020 lädt `hl_makro` schon für BTC, behält aber nur das OI.
- **Offen ist der Nachweis:** Bisher beschreiben die Daten Größe und Risiko, kaum die Richtung (U130 0/45, Magnet, Anker, Labor).
  Drei Konfluenz-Regeln mit Binance-Verhältnissen wurden nie einzeln geprüft.
- **Vorgemerkt:** U142 Positionierung und Hebel (Studie, H1–H4, darunter die 95-%-Regel des Nutzers als Deleveraging-Test), U143
  Chart-Trader in drei Stufen (Chartbild, Niveau-Test an echten Orderniveaus, Labor-Familie). Bau nach der U141-Auswertung, nur mit
  Zustimmung.

Lehre: **Gesammelte Daten sind noch kein Signal, und „fast immer“ braucht eine Basisrate. Mehr Filter machen einen Backtest schöner
und den Nachweis schwerer.**

**Nachtrag 09.10. nachts (23.63):** Hebel-Studie gebaut (U142, UEBERGABE 3ξξ, `KONZEPT_Hebel.md`), auf die Frage des Nutzers
„Warum machst du heute Nacht nichts?“ (02:48) — mein Grund (erst das U141-Ergebnis abwarten) war schwach: U142 hängt nicht daran,
und Regeln davor festzuschreiben ist sauberer; der Archiv-Download auf dem Pi ist der Engpass.
- **Daten:** eigene `hebel.db`; Binance-Archiv „metrics“ (OI, Top-Trader, Konten, Taker; eine Zeile je Stunde) ab 01.09.2020 für
  fünf Coins, Tageskerzen von 21 Symbolen (Spot, USDⓈ-M, COIN-M) ab 2020; Hebel-Takt lädt im Hintergrund; Sicherung der Bybit/OKX-
  Liquidationen und der Binance-Buchtiefe vor ihrer Vorhaltefrist.
- **Prüfungen vorab:** H1 Konten ≥ 3 → Rücksetzer (Vorzeichen-Surrogate), H2 Top-Trader-Regel der Konfluenz → Richtung (zweiseitig),
  H3 Perp-Anteil ≥ 95 % und H4 oberstes Zehntel → Liquidationswelle (OI in Coins + Ausschlag; Zeitverschiebung 30–365 T). Urteil nur
  mit vollständiger Historie. Nachweisgrenze RR um 2.
- **Prüfung des Programms:** 51 Selbsttest-Prüfungen, Nullreplikationen, Trend-Null, Trennschärfe, Mutationen 26 von 26 rot.
- Konfluenz, Labor, Prognose, Fusion, v3, Kaskaden, v1 und `hl_zyklus` unverändert. Bericht 10.10. 08:15 (sonst 11.10. 08:15).

Lehre: **Eine Risikofrage braucht ein anderes Nullmodell als eine Richtungsfrage — Vorzeichen-Surrogate behalten die Schwankung und
hätten ein reines Risikosignal unsichtbar gemacht. Ein zweiseitiger Test braucht Positivkontrollen in beiden Richtungen.**

**Nachtrag 09.10. mittags (nur Dokumente, 23.63 unverändert):** Erster Lauf der Zyklus-Studie (U141, 12:00) ausgewertet
(UEBERGABE 3οο, `KONZEPT_Zyklen.md` 14): **nichts belegt.** Rallyes und Rücksetzer wie ein Zufallsweg mit derselben Drift und
Schwankung; „Dip halten“ schlechter als HODL und bei BTC/ETH sogar unter zufälligen Einstiegen mit denselben Ausstiegen; T200 am
nächsten an einem Beleg (Sharpe 1,47 gegen 1,27 im Kern, p Holm 0,53); kein Warnsignal (OI-Überhitzung RR 1,6 nur Hinweis; nach Gier
≥ 80 und Funding-Druck weniger Rücksetzer). Folge vorab: HODL im Kern bleibt der Maßstab, kein Timing-Werkzeug. 23.63 freigegeben.

Lehre: **Eine plausible Handelsidee kann schlechter sein als Zufall — die Kontrolle mit denselben Ausstiegen gehört in jeden
Vergleich.**

**Nachtrag 10.10. mittags (23.64):** Erster Lauf der Hebel-Studie (U142, 08:16) ausgewertet (UEBERGABE 3ππ, `KONZEPT_Hebel.md`
13): H1 „Konten ≥ 3 → Rücksetzer in 7 Tagen“ erfüllt die Bedingung (RR 2,77, 90 %: 2,10–3,73; 20,3 % gegen 7,4 %; p Holm 0,006,
beide Hälften, jeder Coin und jedes Jahr), H2 „Top-Trader-Regel → Richtung“ nicht (p 0,148; die Regel steht fast immer auf „Kauf“),
H3/H4 ohne Daten — **mein Ladefehler**: `hb_dateien` merkte Kerzendateien ohne Markt, sechs Spotpaare mit dem Namen eines Perps
(BTC/ETH gegen USDT, USDC, BUSD) galten als geladen, der Ladestand meldete fälschlich „vollständig“; deshalb alle Urteile vorläufig.
23.64: Schlüssel „markt:symbol“ mit einmaliger Umstellung beim ersten Öffnen, Ladestand gegen die Zeilen („Widerspruch“),
Ende-zu-Ende-Probe über den Lader; H1 beschreibend ergänzt (Stand 1 h und 24 h früher, Schichtung nach der Rendite der 7 Tage
davor mit Lesart vorab — die Vorzeichen-Surrogate sind blind für Momentum: auf Momentum-Märkten roh 30 von 30 „signifikant“,
geschichtet 0 von 30). H1–H4 rechnen unverändert (identisch zu 23.63 auf fünf synthetischen Märkten). `hl_swing.py` nur Text.
Selbsttest 63 Prüfungen, Mutationen 37 von 37 rot. Endgültig mit dem Lauf 11.10. 08:15.

Lehre: **Eine Probe, die am Lader vorbei in die Datenbank schreibt, prüft den Lader nicht; „vollständig“ prüft man an den Zeilen,
die die Auswertung liest. Und ein Nullmodell, das Vorzeichen auslost, prüft Richtung gegen Schwankung, nicht gegen Momentum.**

**Nachtrag 10.10. spät abends (23.65):** U143 Stufe 1 „Chartbild“ gebaut (UEBERGABE 3ρρ, `KONZEPT_Chartbild.md`; Nutzer 22:16 „Wo
finde ich die Chart Analysen“, 22:20 „Ja“ zum Bau). Neuer Abschnitt „CB Chartbild“ nach dem Live-Chart: Lesart in fünf bis sechs
Sätzen, Tageschart (log. Skala; 50/200-Tage-Linie; Bein wie U141 mit Bestätigungsschwelle der Gegenrichtung; Swings; rechts von
„heute“ die Niveaus als Momentaufnahme mit Nummer und das 80-%-Band für heute und +7 Tage; RSI im eigenen Feld), Tabellen mit
Prüfstand je Zeile. Dieselben Rechnungen wie die Studien (`hl_zyklus`, `hl_regime.har_prognosen`, `hl_swing`, Tagesstände wie
`hl_hebel`, `load_stops`/`load_depth` wie der Live-Chart), nur lesend, kein Signal, wirkt auf nichts. Beim Bau geändert (9.1):
runde Zahlen 1/2/5, Swings ±30 %, PAXG „bewusst nicht gezeigt“, Kerzen hohl/gefüllt statt Rot/Grün (Prüfskript), Live-Teil je Teil
für sich (Kurs, Heatmap, Orders getrennt gelesen). Selbsttest 42 Prüfungen, Mutationen 51 von 51 rot, Browserprobe 13 von 13 Skript-Mutationen rot; nebenbei die Seitenbreite am Desktop behoben
(Debug-Auswahl 1.881 px). `install.py`: 38 Schritte, 11 Dashboard-Abrufe. Einspielen ab 11.10. 08:20 (nach dem U142-Lauf).

Lehre: **Eine Browserprobe prüft ihre Vorbedingung und misst gegen den Bildrand -- ohne frischen Kurs prüfte sie den Ersatzwert,
und relative Lagen sehen eine verschobene Zeitachse nicht. Farben einer Chartfläche wählt das Prüfskript, nicht das Auge.**

**Nachtrag 11.10. vormittags (nur Dokumente, 23.65 unverändert):** U142 endgültig (Lauf `u142-hebel-2` 08:16, Historie vollständig;
UEBERGABE 3σσ, `KONZEPT_Hebel.md` 13.5): **H1 belegt** -- Konten ≥ 3 → Rücksetzer in 7 Tagen 20,3 % gegen 7,3 % (RR 2,77, p Holm
0,012), auch geschichtet nach der Vorwoche (RR 2,52 gegen Null 1,56, p 0,012); in 4 von 5 Fällen folgte kein Rücksetzer. **H2 nicht
belegt** (p Holm 0,376). **H3 nicht prüfbar:** Der Perp-Anteil am Binance-Volumen lag bei BTC/ETH seit 2020 an keinem Tag bei 95 %.
**H4 nicht belegt**, Wellen nach hohem Perp-Anteil eher seltener (RR 0,53). Folgen vorab (Abschnitt 8) beim Nutzer: Hinweis mit Quoten,
Top-Trader-Punkt entfernen, U144, Abgrenzung der 95 %. Die Sammeldatei 08:25 meldete „2026-09-23.64 · a897c8e3c5“ -- 23.65 lag nicht
auf dem Pi, obwohl der Nutzer um 03:10 „läuft bereits“ schrieb.

Lehre: **Den Kopf jeder Sammeldatei (Version und Prüfsumme) vor der Auswertung lesen -- er zeigt, was wirklich lief.**

**Nachtrag 11.10. mittags (nur Dokumente, 23.65 unverändert):** Das Dashboard-Update auf 23.65 hing ab 12:35 in Schritt 2
(Datenbank-Sicherung, ~14 GB auf die SD-Karte); nichts verändert, der Pi läuft auf 23.64 (UEBERGABE 3ττ). Ursache ein eigener
Konstruktionsfehler: update.py sichert unter derselben Bedingung selbst, unter der auch der Recorder fällig ist (letzte gute älter als
24 h oder fehlgeschlagen, dann alle 30 min), beide ohne Sperre in dieselbe Zwischendatei -- eine scheitert, oder die neueste Sicherung
ist unvollständig unter „ok“. Dazu: Log gepuffert, zweiter Update-Klick lädt neu und leert das Log, „nächste in“ nach Fehlschlag
falsch, Debug-Logdatei veraltet. → U145 (23.66). Weg ohne Terminal: abwarten; Update nur bei Uhrzeit auf der Kachel
„Letztes Backup“, sonst erst „Jetzt sichern“. README „Aktualisieren“ berichtigt. 13:42: Fehlertext der Recorder-Sicherung
„disk I/O error“ (12:35:40–12:44) -- in der Sandbox nachgestellt: In 10 von 10 überlappenden Läufen scheitert die als zweite fertige
Kopie mit genau diesem Text (die andere hat die Journaldatei gleichen Namens gelöscht), die erste danach ebenfalls; kein Hinweis auf
Hardware. Dazu zwei weitere Fehler für U145: `backup.json` nicht atomar, fremdes „heißes Journal“ in der eigenen Kopie.
Die Recorder-Sicherung 13:26 lief allein durch; das alte Update endete mit „Abbruch“ beim Umbenennen. Zweiter Versuch bei grüner
Kachel: **14:10 läuft 23.65 auf dem Pi** (A1 ✓).

**Nachtrag 11.10. nachmittags (nur Dokumente, 23.65 unverändert):** Chartbild erster Lauf auf echten Daten (14:58; UEBERGABE 3υυ,
`KONZEPT_Chartbild.md` 9.2) stimmig, von Hand nachgerechnet. Fünf Nacharbeiten für 23.66: PAXG-Band fehlt (`regime.db` ohne
Nachlade-Takt), Satz „keiner dieser Werte hat ein Timing belegt“ seit U142 H1 falsch (auch im Dashboard-Hinweis und Modulkopf;
README und Konzept schon berichtigt), Mindestgröße der Cluster, „höchster Schluss“ im Bein-Satz, „-0,0 σ“.

Lehre: **Wird ein Urteil endgültig, alle „kein … belegt“-Sätze durchsuchen, nicht nur die Prüfstand-Tabelle. Jede Datenquelle
einer Anzeige braucht einen eigenen Nachlade-Takt.**

**Nachtrag 11.10. 17:00 (nur Dokumente, 23.65 unverändert):** U146 „Ausblick 4 Wochen“ vorab festgelegt (`KONZEPT_Ausblick.md`,
UEBERGABE 3φφ): Breite aus HAR je Horizont, Form aus echten normierten Pfaden ohne Trend (Szenarien genau), Richtung aus 31
Kandidaten mit Ridge im Walk-forward und Tor, Gewichte gegen zirkuläre Null mit Holm geprüft, Ziellevels mit Erreich- und
Schluss-Wahrscheinlichkeit. Bau mit 23.66 zusammen mit U145 und den Chartbild-Nacharbeiten (Wahl des Nutzers). Erwartung vorab:
driftfreier Fächer mit geprüfter Breite.

**Nachtrag 11.10. abends (nur Dokumente, 23.65 unverändert):** Auf Wunsch des Nutzers (17:49) wurde der Aktienmarkt recherchiert
(`RECHERCHE_Aktienmarkt_11-10-2026.md`) und ins Ausblick-Konzept eingebaut (`KONZEPT_Ausblick.md` 13, UEBERGABE 3χχ).
- **Befund:** „Fällt der S&P 500, fällt BTC immer“ ist falsch. Im jüngsten Jahr waren es 66 % der Verlusttage, 88 % unter −1 %,
  Ausnahmen in beide Richtungen.
- **Richtung:** Keine Aktiengröße sagt die BTC-Richtung über 1–4 Wochen außerhalb der Stichprobe voraus. Der Aktienmarkt trägt
  Breite und gemeinsame Szenarien.
- **Ergänzt sind:**
  - Takt alle 30 Minuten bei offenem Dashboard, stündlich im Hintergrund, sofort bei Schock;
  - HAR-X mit DVOL, S&P-Schwankung, Stress und VIX als geprüfte Zusätze;
  - S&P-Pfade als zweite Koordinate derselben Fenster, bedingte Szenarien mit Episoden-ESS und Kopula-Rückfall, Stressfächer;
  - vier Aktien-Kandidaten der Richtung;
  - Reiter „Aktienmarkt“, Archiv `aktien.db` (Hochzinsspread zuerst — FRED zeigt nur noch drei Jahre);
  - Studie U147 und Kurzstudie zu ETF-Flüssen.
- **Entschieden 18:55:** Aktienkurse rund um die Uhr über Hyperliquid HIP-3 `xyz` (Hinweis des Nutzers), Historie aus FRED;
  SEC-User-Agent `admin@localhost.com`; kein SoSoValue.

Lehre: **Eine starke Überzeugung des Nutzers wird nicht kodiert, sondern als eigene, vorab festgelegte Studie gemessen und
täglich als Tafel gezeigt. Gleichlauf ist keine Vorhersage: Aus ρ = 0,4 und einer schwer vorhersagbaren Aktienrichtung wird
für BTC fast nichts.**

Lehre: **Zwei Wege zum selben Ziel brauchen eine Sperre -- und ein Prüfkriterium, das beide gleichzeitig auslöst, macht die
Kollision zur Regel, nicht zur Ausnahme. Ein Log, das erst am Ende erscheint, sieht von außen wie ein Hänger aus.**

**Nachtrag 11.10. spät abends (23.66):** „Alles in 23.66“ gebaut (UEBERGABE 3ψψ).
- **Neue Dateien:**
  - `hl_ausblick.py` und `hl_ausblick_js.py`: Ausblick 4 Wochen (U146), eigene `ausblick.db`, Nachtrag `KONZEPT_Ausblick.md` 12.1.
  - `hl_aktien.py`: Aktien-Archiv (U148), eigene `aktien.db`, Studie U147 und K1/K2.
- **Geändert:**
  - `hl_recorder.py`: U145 Backup-Sperre, U149 `first_seen` in ms, U150 Audit-Einordnung.
  - `update.py`: wartet auf eine laufende Sicherung und übernimmt sie, Log zeilenweise.
  - `hl_viz.py`: Abschnitt „AU Ausblick“, Routen `/ausblick`, `/ausblick.js`, `/aktienmarkt`, Takte für Aktien, Ausblick und Regime,
    Update-Knopf prüft zuerst, Berichtsplan 12./13.10.
  - `hl_chartbild.py` und `hl_chartbild_js.py`: Nacharbeiten, `KONZEPT_Chartbild.md` 9.3.
  - `hl_regime.py`: Takt für PAXG.
  - `install.py`, `version.py`.
- **Ausblick in einem Satz:** geprüfte Breite (HAR-X), Form aus echten Pfaden ohne Trend, Richtung nur nach bestandenem Tor,
  Ziellevels mit Erreich- und Schluss-Wahrscheinlichkeit, bedingte Szenarien mit dem S&P 500 -- er wirkt auf nichts sonst.
- **Nullverfahren:** zirkuläre Verschiebung mit α 0,05 (Kalibrierung auf 100 Null-Universen: 5,4 % gegen Phasen 4,2 %;
  Schwanzprüfung auf 30 neuen bestanden).
- **Nachweisgrenze:** Bei R² 2,8 % (Wochenmomentum der Literatur) öffnet das Tor in 3 von 10 Märkten, P1 „trägt“ in 9 von 10;
  ab R² 5,9 % Tor 9 von 10; Rausch-Kandidaten nie.
- **Eigener Fehler beim Bau:** Die λ-Kreuzvalidierung sah in die Zukunft. Gefunden hat das die vorab festgelegte Embargo-Probe, vor
  jedem Lauf auf echten Daten.
- **Proben:**
  - Selbsttests: Ausblick 49 Prüfungen, Aktien 22, Audit 8, Backup 18.
  - Mutationen 61 + 14 + 17 rot.
  - Browserprobe 82 Prüfungen, Skript-Mutationen 16 von 16 rot.
  - `install.py --selftest-isoliert`: 42 Schritte und 14 Abrufe grün.

Lehre: **Eine Kreuzvalidierung mit Purging braucht dieselbe Embargo-Probe wie die Schätzung selbst -- das Purging darf nur abziehen,
was vorher addiert war. Eine Positivkontrolle, die ihre Stärke nicht erreicht, wird zur gemessenen Nachweisgrenze, nicht zu einer
stillen Anpassung der Stärke.**

Lehre: **Eine Probe, deren Testdaten den geprüften Fall nicht enthalten (Demo ohne Tafeln, Bein nur mit einem Startextrem), prüft
nichts -- die Mutationen finden solche Lücken, bevor es ein echter Fehler tut.**

Lehre: **Eine Kalibrierung bei p < 0,05 sagt nichts über die kleinen p, die Holm braucht -- den Schwanz eigens prüfen, mit einer
vor dem Lauf festgelegten Regel. Und eine Schranke im Selbsttest bekommt ihre Fehlalarmrate ausgerechnet.**

**Nachtrag 11.10. 23:30 (nur Dokumente, 23.66 läuft auf dem Pi):** Entscheidungen des Nutzers per Auswahl (UEBERGABE 3ωω):
- Hinweis „Kaskadenrisiko nach unten“ mit Quoten, Top-Trader-Punkt raus aus der Konfluenz, Chartbild-Text sonntags im Berichtsplan
  (alles U151, mit 23.67 nach den Berichten vom 12.10.);
- Breitentest der Kontenregel ja (U144); Niveau-Test nach dem 25.10.;
- die 95 % waren eine andere Kennzahl unbekannter Quelle (U152: Liste, Nutzer wählt, dann Test);
- Ausblick 11: 1 ja, 2 nein (beides wie gebaut), 3 nein.

**Nachtrag 11.10. gegen 23:50 (nur Dokumente, 23.66 läuft auf dem Pi):** Frage des Nutzers nach Arbeitsmarkt-, Verbraucher-
und Erzeugerpreisdaten der USA (UEBERGABE 3ααα). Ergebnis: nicht im System, bei FRED vorhanden. Per Auswahl entschieden:
- sammeln und zeigen (U153, mit 23.67). Fassungen mit Abrufzeit, weil `makro.db` Korrekturen überschreibt; dazu Termine. Die Lücke
  Oktober 2025 (Stillstand der US-Regierung) bleibt Lücke.
- Datentage-Studie (U154, nur Schwankung). Zuerst „nach dem 25.10.“, auf Nachfrage des Nutzers (12.10. 00:01) vorgezogen
  auf 23.67.

**Nachtrag 12.10. 02:30 (nur Dokumente, 23.66 läuft auf dem Pi):** Neuer Name des Dashboards „HyperBit — Analyzer“
(Nutzerwunsch, U155, UEBERGABE 3βββ). Mit 23.67 ändern sich Browser-Tab, Kopfzeile, Export-Zeile, Web-App-Manifest und
README-Titel. Die technischen Namen (Ordner, Dienste, Datenbanken, Dateien) bleiben.

**Nachtrag 13.10. nachts (23.67):** Berichte vom 12.10. ausgewertet und 23.67 gebaut (UEBERGABE 3γγγ).
- **Erster Rückblick des Ausblicks** (`KONZEPT_Ausblick.md` 12.2):
  - Breite S1 besteht bei keinem Horizont; B0 bleibt, weil B1 nicht besser ist. Das PAXG-Band ist zu eng (Deckung 57 %).
  - Tor zu, S3 besteht, S4 belegt; unter Aktienstress ist die bedingte Verteilung nicht kalibriert.
  - U147 „immer“ nicht bestätigt (unter −1 % 77 %, unter −2 % 84 %); K1/K2 nicht belegt.
  - Eigene Fehleinschätzungen genannt (S1, X1, U147).
- **Gebaut:**
  - U151: Konfluenz ohne Top-Trader-Punkt, Konten-Hinweis mit Quoten, Bilanz ab Regelwechsel (`konfluenz_regel`).
  - U153: Arbeitsmarkt und Preise der USA im Tab Makro, mit Fassungen, ALFRED und Terminen; Lücke Oktober 2025 nicht gefüllt.
  - U154: `hl_datentage.py`; Lauf 15.10. 21:45.
  - U155: Name „HyperBit — Analyzer“.
  - Acht Befunde aus den Berichten (SEC-Fehlerzeile, Aktienzahl, eingestellter VIX, Ortszeit, fehlende Textabschnitte, Deckung mit
    Wertung, S4 unter Stress, Stressfächer-Beschriftung).
- U152-Liste: `RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md`.
- Offen beim Nutzer: U152 (welche Kennzahl), U156 (Stressfächer mit Größe der Stressphase); U157 (PAXG-Band) nach dem 25.10.
- Proben: Python-Mutationen 53 von 53 rot, Browserprobe Makro USA 9 von 9.

**Nachtrag 13.10. nach 03:00 (nur Dokumente, 23.67 unverändert):** Entscheidungen des Nutzers per Auswahl (UEBERGABE 3δδδ):
- U152: Die 95 % meinen CryptoQuants Bitcoin-Messung über alle Börsen. Kostenlos ab jetzt sammeln; Test U158 vorab festgelegt
  (`KONZEPT_Hebel.md` 14).
- U156: Stressfächer zusätzlich in der Größe der Stressphase, als Szenario (`KONZEPT_Ausblick.md` 13.14).
- Beides mit 23.68, Vorschlag nach den Berichten vom 15./16.10.; der Nutzer legt dafür ein kostenloses CryptoQuant-Konto mit
  Schlüssel an.

**Nachtrag 13.10. 04:20 (nur Dokumente, 23.67 unverändert):** Kaskaden-Gleichung und Magnet-Test nach gut einer Woche (Berichte vom
11.10. abends, UEBERGABE 3εεε): nichts belegt, beide Nullmodelle treffen. Neu U159: Die Heatmap sieht nur noch 7–19 % des OI (04.10.
22–24 %); Ursache offen, Bericht mit 23.68. Fusion und TradeLabor vom 11.10. 19:30 fehlen noch.

**Nachtrag 13.10. 05:35 (nur Dokumente, 23.67 unverändert):** Fusion nach einer Woche live und TradeLabor nach 14 Tagen (Berichte
vom 11.10. 19:30/19:31, UEBERGABE 3ζζζ, `KONZEPT_Fusion.md` 6.1):
- Fusion 4 h nicht belegt besser als die Basisrate (−0,0032 ± 0,0029 je Block), kein ✗ gegen einen Experten, v1 knapp davor.
  Alle Vorhersagen liegen beim Münzwurf. Erwartung für das Urteil am 25.10., vorab festgehalten: Die Fusion bleibt im Schatten.
- TradeLabor: 5.204 Trades, netto −104.833 USD, 0 bewährt, 7 negativ; die Kosten überwiegen.
- XMR-Gebühr: Der Nutzer wählte die normalen Sätze ab 23.68 (U160; Messung ×0,5 statt der angenommenen ×2). Die Kostenschwelle der
  Fusion bleibt bis zum 25.10. unverändert, die Swing-Vorprüfung auf der Historie behält ihre Annahme (`KONZEPT_Swing.md` 7).
- Neu U161 (Labor je Strategie und Coin) und U162 (Kriterium 5 im Bericht; fehlte seit 23.42, eigener Fehler).
- 23.68 = U156, U158, U159, U160, U161, U162. Es fehlt nur noch der Fusion-Selbsttest vom 11.10. (optional).

**Nachtrag 13.10. 14:10 (nur Dokumente, 23.67 unverändert):** Der Fusion-Selbsttest vom 11.10. kam nach: bestanden (27 von 27,
38 s), Zeile für Zeile wie in der Sandbox mit 23.67 und wie beim Bau. Es fehlt kein Bericht mehr (UEBERGABE 3ζζζ, Nachtrag).

**Nachtrag 13.10. 20:35 (nur Dokumente, 23.67 unverändert):** Größe der Labor-Trades geprüft (Nutzerfrage mit Bild, UEBERGABE 3ηηη):
- Grid-Lose sind 833–2.500 USD groß (10.000 USD je Coin auf 4–12 Stufen verteilt); Swing und Zyklus richten sich nach dem Risiko
  (100 USD bis zum Stop); alle anderen handeln 10.000 USD. Die Kachel „10.000 USD je Trade“ war irreführend (eigener Fehler).
- Per Auswahl: U163 (Grid-Anzeige je Coin und Tag, Spalte „Größe“, Ø/Tag in USD, Kachel berichtigt; nur Anzeige) und U164 (Swing
  und Zyklus im Labor mit fester Größe 10.000 USD, neue Kennungen; Historie bitgleich, R bleibt vergleichbar).
- 23.68 = U156, U158, U159, U160, U161, U162, U163, U164. `KONZEPT_Swing.md` und `KONZEPT_Zyklen.md` vermerkt (im Projekt).

**Nachtrag 13.10. 22:15 (nur Dokumente, 23.67 unverändert):** Sammeldatei 13.10. 22:07 (UEBERGABE 3θθθ): Die Zweitläufe von Ausblick,
Aktienmarkt, U147 und K1/K2 bestätigen den 12.10. Der Pi läuft noch mit 23.66; 23.67 muss vor dem 15.10. 20:15 eingespielt sein (U153,
U154). Neu U165: Der jüngste Farside-Tag kann unvollständig sein (12.10. ohne IBIT); Nachprüfung 18.10. 08:30. 23.68 = U156, U158–U165.

**Nachtrag 14.10. 08:25 (nur Dokumente, 23.67 unverändert):** Skriptfehler im Hinweisfenster des Kurs-Charts mit der Quelle „Binance
Daten“ (UEBERGABE 3ιιι): Eingetretene Binance-Marken haben kein `x_vol`. Es ist ein alter Fehler und betrifft nur die Anzeige; er ist
nachgestellt. Die Zeilennummer zeigt, dass 23.67 läuft. Korrektur mit 23.68 (U166, Wahl des Nutzers); 23.68 = U156, U158–U166.

**Nachtrag 14.10. 12:15 (nur Dokumente, 23.67 unverändert):** Bilanzverlauf im TradeLabor mit allen Strategien, Häkchen je Strategie
und Standard „Top 10 nach Trefferquote“ (Wahl des Nutzers), vorab festgelegt als U167 (UEBERGABE 3κκκ); 23.68 = U156, U158–U167.
Am Nachmittag im Arbeitsstand gebaut und geprüft (node 13/13, Browser 40/40, Mutationen 5/5 rot); Auslieferung mit 23.68.

**Nachtrag 14.10. 22:30 (nur Dokumente, 23.67 unverändert):** Sammeldatei der Woche, neu der Wochenlauf 14.10. 19:00 (UEBERGABE 3λλλ):
- 23.67 läuft seit 13.10. 22:44 (A1 ✓).
- Der Vollbericht brach nach 15 min ab: Er zählt jede Tabelle dreimal vollständig und druckt erst am Ende; die Laufzeit wuchs mit
  der Datenbank (596 s, 779 s, über 900 s), ich habe sie nicht verfolgt (eigener Fehler). Korrektur mit 23.68 (U168, Wahl des Nutzers): einmal
  zählen, sofort ausgeben, Zeitbudget, Vorwarnung im Berichtsplan. Bis dahin liefert ihn der Handlauf.
- Abdeckung der Heatmap wieder 24–27 % (20 h nach dem Neustart); U159 vorab präzisiert (Poller-Kennzahlen, Neustarts).
- v3 hat erstmals Gewichte (Tor nach fester Regel geöffnet, nichts geändert). Fusion, Kaskaden, Magnet: nichts belegt; Hochrechnung
  für den 25.10. wie erwartet. Labor −120.835 USD, 0 bewährt; beide Grids im Minus; erste fünf Swing-/Zyklus-Trades alle am Stop.
- Neu U169 (Makro-Textzeilen). 23.68 = U156, U158–U169.

**Nachtrag 14.10. 23:15 (nur Dokumente, 23.67 unverändert):** Zweites Bild des Nutzers zum Skriptfehler (UEBERGABE 3μμμ): wieder
U166 im Binance-Modus, dazu „NaN %“ beim nächsten FVG. Ein Feldvergleich der Chart-Nutzlast aller drei Quellen fand im Binance-Modus
genau drei fehlende Felder (`x_vol` der Marken, `dist` der FVGs und der Orderbuch-Stufen; deshalb fehlten dort still die
Schlüsselniveaus) → U166 erweitert. Die Konfluenz-Bilanz speichert die Quelle nicht und mischt damit Regelwerke (eigener
Konstruktionsfehler) → U170. 23.68 = U156, U158–U170.

**Nachtrag 15.10. 22:30 (nur Dokumente, 23.67 unverändert):** Berichte vom 15.10. (UEBERGABE 3ννν, `KONZEPT_Makro.md` 11.9): Die
Verbraucherpreise für September sind da (U153 ✓). Die Datentage-Studie (U154) belegt H1 und H2: In den zwei Stunden nach den
Verbraucherpreisen schwanken BTC und ETH typisch 2,45-mal so stark (Varianz), nach dem Arbeitsmarktbericht 1,9-mal; über den ganzen
Tag kaum, Erzeugerpreise und Erstanträge ohne Effekt. Die Erwartung „seit 2024 kleiner“ war falsch; die Gegenprobe weicht ab
(→ U171). Per Auswahl: Hinweis an Datentagen mit 23.68 (U172), Rechnung für die Schwankung der nächsten Stunden nach dem 25.10.
(U173). 23.68 = U156, U158–U172. Der zweite Lauf am 16.10. 21:46 bestätigt das Ergebnis Zahl für Zahl.

**Nachtrag 17.10. (Version 2026-09-23.68 · e195e119f2): 23.68 gebaut und geprüft** (UEBERGABE 3ξξξ).
- **Gebaut:** alle Punkte U156 und U158–U172.
  - Vollbericht in einem Durchgang.
  - Binance-Modus ohne Fehler und ohne „NaN“.
  - Konfluenz je Quelle.
  - Hinweis an Datentagen.
  - Labor: XMR normal, feste Größe, Tabellen, Bilanzverlauf.
  - Kriterium 5, Farside, Abdeckung.
  - Ausblick: Fächer in der Größe der Stressphase.
  - CryptoQuant mit S5.
- **Eigener Fehler:** Die Stressklammer bei +4 W war seit 23.66 abgeschnitten.
- **Nachweisgrenze S5:** Mit kurzer Reihe ist ein „nicht belegt“ schwach.
- **Der Nutzer trägt den CryptoQuant-Schlüssel selbst ein**, im Tab „Daten“, nie im Chat. Erster Bericht 19.10. 20:15.

**Nachtrag 19.10. abends (Version 2026-09-23.69 · 547c938d6a): 23.69 gebaut und geprüft** (UEBERGABE 3φφφ).
- **Gebaut:** U180 Akkumulation im TradeLabor (`KONZEPT_Akkumulation.md`, neu im Paket), U177 Strategy-Bestand, U178 Zeitraum der
  Stressfächer, U179 Ausnahmelage mit Text, Probe und Zählung (`KONZEPT_Ausblick.md` 13.19). Nicht im Paket: U174, U175 (Wahl des
  Nutzers).
- **Vor jedem echten Kurs geändert:** Bei der Akkumulation zählt Q gegen Vorzeichen-Surrogate (auf Zufallswegen kalibriert, 6 von 144
  unter 0,05), nicht der Vorteil gegen Zufallszeiten (der ist auf Zufallswegen schief).
- **Präzisierung vor dem Bau:** U177 prüft die Plausibilität nur nach unten.
- **Beim Packen gefunden und behoben (eigene Fehler):** `update.py` kannte die beiden neuen Dokumente und `check_abdeckung.py` (seit
  23.68) nicht → aufgenommen, Prüfsumme 547c938d6a statt 4f52736ff4; Uhrzeiten in den Dokumenten waren geschätzt (bis zu 2 h zu spät)
  → nach Dateizeiten berichtigt; in `KONZEPT_Akkumulation.md` 7 zwei Zahlenreihen ohne Protokoll ersetzt bzw. nachgerechnet.
- **Termine:** 20.10. 08:45 Akkumulation-Rückblick, 20.10. 21:15 Zählung der Regel (c). Neu offen U181 (Rechenweg der
  Akkumulation-Tageszeilen, nur Rechenzeit), U182 (Probe der Dateiliste von update.py) und U183 (Dauer im Debug-Eintrag
  „Selbsttest“: dort „3–5 min“, gemessen 1.297 s in der Sandbox, auf dem Pi eher eine Stunde); nächste neue Nummer U184.
- **A7:** `install.py --selftest-isoliert` 61 von 61 grün.

**Nachtrag 20.10. (Version 2026-09-23.70 · a2b59f0fc5): 23.70 statt 23.69** (UEBERGABE 3χχχ). 23.69 wurde nicht eingespielt; der Nutzer
änderte vorher die Akkumulation (U184): 5.000 USD je Kauf, Spot (war es schon; das Ereignis heißt jetzt „spot“), Startkauf A0 je Coin,
Käufe rückwirkend ab dem Start des Coins im Labor nachgerechnet („direkt vergleichbar mit den anderen laufenden Strategien“). Meine
Entscheidungen: Start des Coins im Labor als Beginn, Sperre auch beim Startkauf, Kontrolle ebenso, Rückblick und Vergleich ohne Startkauf
(`KONZEPT_Akkumulation.md` 7a). Termine wie 23.69 (20.10. 08:45 und 21:15, zweite Termine am 21.10.). Nächste neue Nummer U185.

**Nachtrag 20.10. (Version 2026-09-23.71 · f3113c906a): Anzeige der Akkumulation berichtigt** (U185, UEBERGABE 3ψψψ). 23.70 ist auf dem Pi;
der Nutzer las die Tabelle je Tag (23 Zeilen für 23 Tage, Stand am Tagesende) als Liste von Käufen und fragte, warum oben nur 5.000 je
Kauf stehe. Die Rechnung stimmte (3 Startkäufe, 15.000 USD). Neu: Liste „Alle Käufe“ unter der Übersicht, Tagestabelle als „Stand je
Tag — keine Kaufliste“ mit „Käufe“ bis dahin und „neu“, Grund des Startkaufs richtig (eigener Fehler aus 23.70: „zum Start des Coins“
auch bei späterem Kauf; gespeicherte Texte nur in der Anzeige umgeschrieben), Handy ohne Seitwärtsscrollen. Regeln, Kennungen und
gespeicherte Käufe unverändert. Mit 23.71 kommen `KONZEPT_Akkumulation.md` und `RECHERCHE_Boersenfluesse_17-10-2026.md` auf den Pi (das
`update.py` von 23.70 kennt sie). Nächste neue Nummer U186.

**Nachtrag 20.10. (Version 2026-09-23.72 · 1a8c1b577d): Korrekturkauf A4** (U186, UEBERGABE 3ωωω). Noch vor dem Einspielen von 23.71
wünschte der Nutzer eine Zusatzregel für scharfe Korrekturen: 7 % unter dem Hoch der letzten 48 h kaufen, binnen 14 Tagen je weitere 7 %
nachkaufen, für alle Coins, rückwirkend und dann live; auf meine Rückfrage ohne Sperre. Gebaut als eigene Spur neben A0–A3 (die
bisherigen Käufe bleiben gleich, Probe), neue Kennungen; die Bilanz von 23.70 steht unter „frühere Regeln“. 23.72 enthält 23.71.
Nächste neue Nummer U187.

**Nachtrag 20.10. 07:37 (nur Dokumente, 23.72 läuft auf dem Pi):** Der CryptoQuant-Bericht vom 19.10. (U158) ist geprüft: Der kostenlose
Schlüssel bekommt die Tageswerte, Einheit und Antwortform passen, D lag in 32 Tagen bei 83,2–91,4 % (kein Tag ≥ 95 %), S5 ist noch nicht
prüfbar (UEBERGABE 3αααα, `KONZEPT_Hebel.md` 14). Neu U187: Der Labor-Bericht kennzeichnet frühere Regelstände der Akkumulation nicht.
Nächste neue Nummer U188.

**Nachtrag 20.10. (Version 2026-09-23.73 · 5563865ed5): Tagestabelle der Akkumulation nochmals berichtigt** (U188, U187, UEBERGABE 3ββββ).
Der Nutzer las die Spalte „Käufe“ der Tabelle „Stand je Tag“ (bei BTC in jeder Zeile 1) als einen Kauf an jedem Tag und zweifelte an der
7-%-Regel. Die Rechnung stimmte: BTC hat nur den Startkauf, und 7 % binnen 48 h gab es nicht (größter Zwei-Tage-Rückgang 4,5 %). Neu: Spalte
„Kauf an diesem Tag“ („—“ oder ⊕ mit dem Kauf), „eingesetzt gesamt“; dazu der Labor-Bericht mit „(alte Regeln)“ (U187). Rechnung,
Kennungen und gespeicherte Käufe unverändert. Nächste neue Nummer U189.

**Nachtrag 20.10. (Version 2026-09-23.74 · bc6ebee746): Faktor gegenüber BTC** (U189, UEBERGABE 3γγγγ). Der Nutzer sah bei ZEC über 70.000 USD
Käufe gegenüber 5.000 bei BTC: die festen 7 % des Korrekturkaufs sind bei ZEC Alltag. Gebaut auf seine Wahl: je Coin ein Faktor
(σ_Tag ÷ σ_Tag von BTC in den 365 Tagen vor dem Start im Labor, mindestens 1, einmal bestimmt und gespeichert), Korrektur-Schwelle 0,93
hoch Faktor, Betrag 5.000 USD ÷ Faktor; neue Kennungen, alles ab dem Start neu nachgerechnet; Tabelle „Schwellen je Coin“. A1–A3 und
die Sperre bleiben. Nächste neue Nummer U190.

**Nachtrag 20.10. 15:33 (nur Dokumente, 23.74 läuft auf dem Pi):** Der Rückblick der Akkumulation seit 2020 (vorab festgelegt) ist da:
Zeitpunkt bei ZEC belegt (p 0,020), bei XMR knapp nicht, bei BTC und ETH nicht -- beschreibend, vier Coins geprüft. Der Labor-Bericht von
08:46 lief noch mit 23.72 und bestätigt den Befund des Nutzers (fest 7 %: ZEC 16 Korrekturkäufe, 80.000 USD). UEBERGABE 3δδδδ,
`KONZEPT_Akkumulation.md` 5.

**Nachtrag 20.10. 16:21 (nur Dokumente):** Die rote Leiste „/speicher: keine Verbindung (Failed to fetch)“ auf dem Handy kommt von
Abfragen, die auch bei verborgener Seite laufen; harmlos, räumt sich selbst weg. Der Nutzer will daran nichts ändern (UEBERGABE 3εεεε).

**Nachtrag 21.10. 22:17 (nur Dokumente, 23.74 läuft auf dem Pi):** Die Berichte vom 21.10. sind geprüft (UEBERGABE 3ζζζζ). Der erste
Labor-Bericht mit dem Faktor gegenüber BTC bestätigt U189 und die Erwartung vorab: Faktoren ETH 1,39, ZEC 3,45, HYPE 2,25, XMR 2,08; 4 Käufe
und 14.416 USD statt 27 Käufe und 135.000 USD mit fest 7 % (ZEC 16 Korrekturkäufe → 0). Die Zählung der Regel (c) (U179): Am Wochenende
bewegt sich der S&P-500-Perp mit rund einem Achtel der angenommenen Varianz (Q 0,12); in der Handelszeit stimmt die Varianz (Q 1,13), aber
2,2 % der Prüfzeitpunkte liegen über der 3-σ-Schwelle (dicke Ränder). Der Nutzer hat entschieden: Schwelle je Fensterart mit Q, direkt
live, gebaut nach dem 25.10. (festgelegt in `KONZEPT_Ausblick.md` 13.20) Der Vollbericht läuft in 354 s (U168 erledigt). Kriterium 5 der Fusion steht bei 1,03 ± 0,08 (U162); die Anzeige bekommt
im Grenzfall (PAXG 0,81 ± 0,09) den Abstand in Standardfehlern (U190). Das Tor von v3 ist wieder zu. Nächste neue Nummer U191.

**Nachtrag 22.10. 17:45 (nur Dokumente):** Der Nutzer lud den Auditbericht v3 vom 14.09. erneut hoch. Alle seine Korrekturen sind im Stand
23.74 noch da; offen ist nur der Lint (62 kosmetische Meldungen, W6). UEBERGABE 3ηηηη.

**Nachtrag 22.10. 18:20 (Version 2026-09-23.75 · 28541d9ce0): Auditbericht v10 vom 22.10.** (UEBERGABE 3θθθθ, U191–U205). Der
Nutzer lud ihn 17:46 hoch („Lob bleibt“); geprüft am Code von 23.74; Wahl des Nutzers: 23.75 jetzt, der Rest nach dem 25.10. In 23.75:
Die Abo-Grenze 10 gilt auch ohne Befehlszeile (H-1, eigener Fehler aus K1: der Standard 600 der Befehlszeile überschrieb sie; auf dem Pi
bisher ohne Wirkung, die Darwin-Liste hat 2 Mitglieder); die vier schreibenden Aktionen des Dashboards gehen nur per POST mit Kopfzeile
(M-5); der Chart-Zeitraum hat eine Grenze je Kerzengröße, unter 4 h 90 Tage, ab 4 h 5 Jahre -- „1 Woche · 5 Jahre“ zeigte bisher 3 Jahre
(M-6); ein Listener für das Sichtbarwerden (N-5); der Vollbericht zeigt die Dauer der Fill-Nacharbeit (M-3, erst messen). Korrektur
meiner Prüfung: Die Vielhandler-Abfrage liest ohne Planer-Statistik die ganze Tabelle `lb_fills`, nicht über den Zeitindex -- erster
Kandidat für den Umbau. Nach dem 25.10.: H-2 (Kalibrierung aus `forecast_slim` und `forecast_drivers`, vor dem 10.11.), M-1, M-2,
Statistik v1/v2, OOS-Wächter, kleine Robustheitsstellen, zwei vorab festgelegte Studien. Nach dem Einspielen offene Dashboard-Seiten
anderer Geräte einmal neu laden. Nächste neue Nummer U206.

**Nachtrag 23.10. 03:11 (Version 2026-09-23.76 · ca72ef99cc): Notbremse U206** (UEBERGABE 3ιιιι, `KONZEPT_Notbremse.md` Fassung 1). Anlass
war der 22.10. (Krypto und Tech-Aktien fielen gemeinsam, das Labor schloss rund 17.000 USD im Minus, keine Regel stoppte das Nachkaufen).
Gebaut: ein eigener Dienst `hl-notbremse` prüft jede Minute, ob ein Krypto- und ein Aktien-Korb auf `xyz` gemeinsam ungewöhnlich fallen
(X, Fenster 15/60/240 min) oder Krypto allein mit einer Liquidationswelle einbricht (Y mit Λ); Stufe 1 sperrt neue und größere Longs,
Stufe 2 heißt Schock (Bestandsvarianten V1–V3 nur im Schatten). Die Schwellen folgen aus dem Alarmbudget 4/1/1 je 30 Tage; die erste
Kalibrierung nutzt nur Daten bis 20.10. 23:59 UTC, der 22.10. bleibt ungesehen. Dazu Termine (US-Wahlnacht vorgegeben) und die
Handbremse im Kopf jeder Seite. **Die Bremse wirkt nur in Welt A**, einer Kopie des TradeLabors in `labor_a.db`; Welt B, das bisherige
Labor, bleibt unverändert (Zusage bis 25.10.), der Unterschied A − B ist der Nutzen der Bremse in USD. Neue eiserne Regel 12. Nach dem
Einspielen zuerst die Zerlegung des 22.10. und abends der Rückblick (U210). Ebene B (Polymarket, KI) folgt als U207. Nächste neue Nummer
U211.

**Nachtrag 23.10. 15:56 (Version 2026-09-23.77 · b446905d86): Ausfall, Zerlegung, Rückblick aus der Debug-Konsole** (UEBERGABE 3κκκκ,
U210–U214). Um 14:13 war die Weboberfläche nicht erreichbar (Ping ja, Port 8765 nein); der Neustart über den Taster half, **SSH ist auf
dem Pi aus**, ein Bildschirm hängt nicht dran. Die Ursache ist offen; dafür gibt es jetzt „★ System: letzter Neustart und Ausfälle“
(`check_system.py`), und der Systemverlauf hält den Speicher. Die Zerlegung des 22.10. zeigt: Mit den vorab kalibrierten Schwellen
(Budget 4) hätte die Bremse am 22.10. nicht ausgelöst, erst bei Budget 8 ab 02:30 UTC; Welt B −34.760 USD im 48-h-Fenster, davon
−19.837 Bestand vor t0 und −12.722 neue Longs danach. θ1 liegt bei Budget 2 und 4 an der Klammer −3,50 (beide gleich); für θ2Y hielt
kein Wert bis −8,00 das Budget. Der Rückblick läuft jetzt aus der Debug-Konsole als eigene systemd-Einheit („★ Notbremse: Rückblick
vollständig im Hintergrund STARTEN“, „… Stand und Ergebnis“). Nächste neue Nummer U215.

**Nachtrag 23.10. 18:46 (Version 2026-09-23.78 · de01471ead): Ausfall ausgewertet, Selbstheilung** (UEBERGABE 3λλλλ, U215–U218). Der
Systembericht von 17:35 zeigt: Der Pi lief durch (Wächter pünktlich, Platte, Recorder in Ordnung), **der Dashboard-Prozess hing knapp 5
Stunden** (letzter Messwert 09:31:19, 14–19 min nach dem ersten Start von 23.76, bis zum Neustart 14:27) und blieb für systemd „aktiv“.
Die Ursache ist offen (Journal nicht dauerhaft). Seit 23.78 meldet das Dashboard systemd nur dann ein Lebenszeichen, wenn seine eigene
Seite `/lebt` antwortet (`WatchdogSec=900`); bleibt es aus, startet systemd es neu, und `logs/dashboard_haenger.log` hält fest, wo jeder
Faden stand. Der Systembericht grenzt Ausfälle nachträglich ein (Lücken aus den Prognosen, Wächter-Abstände, Lebenszeichen der Teile in
den Datenbanken). Das Systemprotokoll dauerhaft gibt es als Klick (U217). Neue eiserne Regel 13. Nächste neue Nummer U219.

**Nachtrag 23.10. 19:36 (Version 2026-09-23.79 · b5e713371a): Lücke des 23.10. eingegrenzt, eigener Fehler im Bericht** (UEBERGABE 3μμμμ,
U216, U219). Der Bericht von 23.78 (18:58) zeigt: Der Pi war nicht überlastet, Recorder und Notbremse-Dienst liefen, alle Dashboard-Teile mit
Schreibzeit standen ab etwa 09:36 (letztes Lebenszeichen 09:36:09) -- vermutlich stand das ganze Dashboard. Sein Urteil „nur Teile standen“
beruhte auf TradeLabor-Einträgen mit Kerzenzeit, die nach dem Neustart nachgeholt wurden; seit 23.79 zählen dort nur Takt-Arten. Regel für
Lebenszeichen: Eine Zeitspalte zählt nur, wenn sie am Code geprüft die Zeit des Schreibens trägt. Nächste neue Nummer U220.

**Nachtrag 23.10. 20:33 (Version 2026-09-23.79 · b5e713371a, kein neues Paket): Ausfall des 23.10. eingegrenzt** (UEBERGABE 3νννν, U216). Mit 23.79 auf dem Pi bestätigt: Das ganze Dashboard stand ab etwa 09:36 (auch die Takt-Einträge des TradeLabors),
seine Marktzeit-Einträge in der Lücke wurden nach dem Neustart nachgeholt. Die Ursache bleibt offen; den nächsten Hänger hält
`logs/dashboard_haenger.log` fest (U215).

**Nachtrag 23.10. 21:45 (Version 2026-09-23.80 · 6c64536b8f): Wächter gegen den Normalwert, Poller-Kapazität** (UEBERGABE 3ξξξξ, U218,
U220). Der Wächter stand wegen des bekannt zu knappen Abfragebudgets dauernd auf KRITISCH (Poller: 90-%-Quantil über alle Adressen mit
Position, auch die kleinen im 2-h-Takt; Abdeckung unter 25 %) und hätte einen echten Ausfall nicht mehr gezeigt. Seit 23.80 misst er Poller
und Abdeckung gegen ihren eigenen Normalwert der letzten 7 Tage; KRITISCH heißt: Poller steht oder Snapshot leer. Wo das Budget hingeht,
zeigt Debug „★ Recorder: Poller-Kapazität“ -- ein Modell der Auswahl des Recorders (`due_addresses`), gegen die echte Auswahl simuliert und
mit Probe C17 an den Quelltext gebunden: Wer im Recorder Takte, Stufen oder die Reihenfolge ändert, muss das Modell mitziehen. Am Poller
selbst ändert sich bis zum 25.10. nichts (U220). Nächste neue Nummer U221.

**Nachtrag 24.10. 02:40 (Version 2026-09-23.80 · 6c64536b8f, kein neues Paket): Volumen-Analyse (U221)** (UEBERGABE 3οοοο). Der
Nutzer will für alle Trading-Strategien eine Volumen-Analyse; Entscheidung „Erst messen, dann filtern“. Volumendaten liegen größtenteils schon
vor: Hyperliquid je Minute und je 10 s mit Taker-Seiten (eigene Aufzeichnung, kein API-Gewicht), Binance-Kerzen ab 2020 (intraday ohne
Seiten; das Taker-Kaufvolumen liefert Binance mit, die Lader verwerfen es bisher), Coinbase-Spot je Minute. Nicht über Hyperliquids
`candleSnapshot` nachladen (Budget am Deckel). Entwurf `KONZEPT_Volumen.md` (24.10. 03:11, wartet auf Freigabe). Befund U222: späte Trades
können fertige Minuten-Bars überschreiben (`INSERT OR REPLACE` mit Bruchstück, keine Entdoppelung nach `tid`) -- erst messen, beheben nach
dem 25.10. Nächste neue Nummer U223.

**Nachtrag 24.10. 05:21 (Version 2026-09-23.81 · 52636840b9): Volumen-Studie gebaut (U221)** (UEBERGABE 3ππππ, `KONZEPT_Volumen.md` 12).
`hl_volumen.py` liest nur und fließt nirgends ein. Teil A urteilt erst am 08.11. (Lauf 09:15 im Berichtsplan); jeder Lauf davor heißt
„vorläufig“ -- keine Entscheidung auf einem Zwischenstand. Teil B (Swing-Historie bis 23.10.) urteilt beim ersten Lauf mit vollständiger
Historie. Beim Bau korrigiert: Vergleichsfenster nach der Tagesart in ihrer Mitte (ein 24-h-Fenster am Samstag früh enthält den Freitag).
Wer an Fenstern, Schichten, Pool oder Nullmodell etwas ändert, trägt es vorher mit Datum in Abschnitt 12 des Konzepts ein und zieht die
Mutationen nach (Liste in UEBERGABE 3ππππ). Neu U223: der 4-h-Chart kann wegen `klines30` (nur per Hand geladen) eine Lücke zeigen.
Nächste neue Nummer U224.

**Nachtrag 25.10. 02:48 (Version 2026-09-23.82 · 7bb469f6d6): Recorder-Fix U222 und neue Regel der Volumen-Studie** (UEBERGABE 3ρρρρ,
`KONZEPT_Volumen.md` 12.19–12.24). Der Recorder schreibt Minuten-Bars und 10-s-Stücke gut 3 s nach ihrem Ende (Takt 10 s auf :03, :13, …),
hält sie, bis die Börsenzeit 15 min über ihre Minute hinaus ist, und schreibt sie bei einem späten Trade vollständig neu; danach zählt
nichts mehr; Trades nach (Zeit, tid) entdoppelt; beim Neustart zählen Trades bis zur Marke `u222_hw_ms` nicht, die letzte Minute wird
zusammengeführt. **Wer an `on_trade` (Bars), `_bar_entscheid`, `_stueck`, `flush_bars`, `flush_bars10` oder am Schreibtakt etwas
ändert, lässt `hl_recorder.py --selbsttest-bars` und die Mutationen R01–R18 ohne R07 (UEBERGABE 3ρρρρ) laufen.** Die Volumen-Studie rechnet seit 23.82 mit dem größeren Umsatz aus `bars` und den
10-s-Stücken; fragliche Minuten sind keine Lücke mehr (Entscheidung des Nutzers vor dem Urteil, 25.10. 00:57). Neu U224 (Coinbase), U225
(Labor, Limit-Orders). Nächste neue Nummer U226.

**Nachtrag 25.10. 13:24 (Version 2026-09-23.83 · e512a7ab09): Extrem-Wende nach Video (U226)** (UEBERGABE 3σσσσ, `KONZEPT_Wende.md`).
Die Strategie aus dem Video (BTC 8 h: Extrem-Kerze im Fenster der 765 Kerzen, dann Flip EMA 8/89; Stop 0,1 % hinter dem Extrem) ist eine
Studie (`hl_wende.py`, liest nur; Bericht 27.10. 09:40 urteilt mit Datenende Stichtag) und zwei Strategien im TradeLabor (`wende_rang`,
`wende_spanne`, Gruppe Swing, nur BTC). Das Urteil (H1 mit α_H1 0,038 aus der Kalibrierung auf Nullmärkten, H2, Hälften, Mindestzahlen)
ist vorab festgelegt; **wer an Signalen, Einstieg, Ausgang, Verschiebung, Skalierung oder Urteil etwas ändert, trägt es vorher mit Datum in
KONZEPT 8 ein, kalibriert neu (`hl_wende.py --kalibrieren`, KONZEPT 3.8) und lässt den Selbsttest und die Mutationen W01–W62, L01–L19 ohne
L09 und L10 (UEBERGABE 3σσσσ) laufen; wer die Einstiegslogik in `sig_wende` ändert, erhöht `wende_v`.** Ändert ein Umbau die Signale, schlägt die Goldprobe an: dann `wende_v` erhöhen (neue Kennung im Labor,
die alte Bilanz bleibt). 23.83 enthält 23.82 und wird statt 23.82 frühestens am 26.10. eingespielt. Nächste neue Nummer U227.

**Nachtrag 25.10. 15:23 (Version 2026-09-23.84 · 736a851017): Debug-Nummern (U227)** (UEBERGABE 3ττττ). Jeder Debug-Lauf hat eine
feste Nummer = Stelle in `_DEBUG_REIHE` (`hl_viz.py`): 1–124 die Menüfolge vom 25.10.2026, 125 Debug-Liste, 126 ihr Selbsttest. **Regeln:
`_DEBUG_REIHE` nur hinten verlängern -- nie löschen, umstellen oder einfügen; Schlüssel in `debug_commands` nie umbenennen (der Lauf
bekäme eine neue Nummer); nach neuen Läufen einen Prüfpunkt hinten an `_DEBUG_REIHE_PRUEFPUNKTE` anfügen, alte nie ändern; ein Lauf,
der etwas umschaltet, schreibt das Schaltwort groß und steht in `DEBUG_SCHALTER` (die Seite fragt nach, der Server nimmt ihn nur mit
`&ja=1` an).** Gegenüber dem Nutzer Läufe mit Nummer und Namen nennen („Debug Nr. 26 · ★ Wende …“); nächste freie Nummer 127.
`hl_viz.py --selbsttest-debugnr` (A7-Schritt, Lauf 126), die Browserprobe `b103/browser_debug84.py` mit 17 Mutationen und die
Mutationen D01–D38 (UEBERGABE 3ττττ) prüfen das. 23.84 enthält 23.83. Nächste neue Plan-Nummer U229.

**Nachtrag 25.10. 22:17 (Version 2026-09-23.84 · 736a851017, nur Dokumente): Abendurteile** (UEBERGABE 3υυυυ). Auf dem Pi
läuft 23.83. Nach den vorab festgelegten Regeln: **die Fusion bleibt im Schatten** (U108; Kriterium 1 gegen die Basisrate −1,4 SE),
**Kaskaden-Y nicht belegt** (U115; BTC und ETH 1 h scheitern am Seitenspiegel), **Magnet-Test nichts belegt** (U110; kein Treiber
„Zug“), **Makro × Kurs Teil A 0 von 45** (U130). Alle 4-h-Vorhersagen liegen beim Münzwurf. **Teil B von U130 fehlt** -- das Werkzeug
war bis 25.10. zugesagt (eigenes Versäumnis) und kommt mit dem nächsten Paket. Die Zusage bis 25.10. (Fusion, v3, Kaskaden, v1-Lernen
unverändert) ist eingehalten und endet; wer eine dieser Rechnungen jetzt ändert, braucht für ein neues Urteil eine neue, vorab
festgelegte Runde. Nächste neue Plan-Nummer U230.

**Nachtrag 26.10. 00:28 (Version 2026-09-23.85 · 30a5e44391): Nacharbeiten nach den Urteilen** (UEBERGABE 3φφφφ). U130 Teil B gebaut:
- `hl_makro_korr.py --teil-b` (Debug Nr. 127) und die Prüfung auf echten Kalendern `--kalibrieren-b-echt` (Nr. 128).
- **Regeln:**
  - Teil B ist mit 23.85 eingefroren (Fingerabdruck im Berichtskopf). Wer an Kalender, Maß, Placebo, Mindestzahlen, Familie oder Urteil
    etwas ändert, braucht eine neue, vorab festgelegte Runde (`KONZEPT_Makro.md` 10.7, 10.7a, 10.7b).
  - Das Urteil fällt genau einmal, am 15.01.2027 (Prognosen bis 14.01. 23:59 UTC).
  - Besteht die Prüfung auf den echten Kalendern (01.11.) nicht, vor dem 15.01. mit einem Paket `B_P_FUER_BH = "bonferroni"` setzen.
- U229: Teil A zählt eine SSR-Abweichung nur dann als vorläufig, wenn die Stablecoin-Summe des Datentags nachweislich noch offen war (10.8).
- Fusion: Münzwurf-Vergleich (kein Experte), Kostenschwelle mit `hl_labor.gebuehr` (XMR normal), Kriterium 5 mit Abstand in SE
  (`KONZEPT_Fusion.md` 6.4).
- Proben: Selbsttest `hl_makro_korr.py` 21 Prüfungen, Mutationen K01–K26, U01–U05, F01–F06, L01, V01–V03 (`b105/mutationen85.py`).
- Nächste neue Plan-Nummer U230; nächste freie Debug-Nummer 129.

**Nachtrag 26.10. 01:37 (Version 2026-09-23.85 · 30a5e44391, nur Dokumente): U7b nachgeholt** (UEBERGABE 3χχχχ). Die am 25.10. fällige Modellwahl habe ich nur für U108 getroffen und U7b vergessen. Nach der Regel kein Umschalten: v1 bleibt angezeigt, v2 im Schatten (auf denselben Blöcken rund 0,01 Nats je Block schlechter als v1). **Debug Nr. 93 („Kalibrierung v2 AKTIVIEREN“) nicht ausführen**, solange keine neue, vorab festgelegte Runde etwas anderes ergibt. Neu U230 (direkte Bilanz v1/v2 im Bericht). Nächste neue Plan-Nummer U231.

**Nachtrag 26.10. 11:00 (Version 2026-09-23.85 · 30a5e44391, nur Dokumente): Poller-Kapazität vom 26.10. ausgewertet** (UEBERGABE 3ψψψψ, U220, U231). Überlast unverändert (Bedarf 96.385 gegen 11.053 Konten-Abfragen je Stunde, Faktor 8,7; 24.10. 7,8). Das Modell stimmt mit dem gemessenen Alter, rund ein Achtel zu vorsichtig. Die 107 gesperrten Konten (3,5 Mrd USD, 36 % des bekannten Positionswerts) wurden seit Wochen nicht abgefragt und fehlen in der Heatmap; in Rang 0 alle 30 min hoben sie im Modell den frischen Wert von 54 auf 90 % (1,9 % des Budgets), änderten aber die Heatmap für Prognose, Labor, Kaskaden und Teil B. Eigener Fehler aus 23.80: Die Gegenprobe Pool vergleicht Ungleiches, und der Anteil zu alter Positionen hängt an der Laufzeit (U231). **Entscheidung des Nutzers (12:04):** Gesperrte bleiben gesperrt und werden nicht mehr abgefragt (Hedge-Positionen von Market-Makern sagen wenig); die Kapazität geht an die größten Konten -- kleine Konten nur nach eigenem Handel, „groß“ erst ab 500.000 USD. Paket 23.86 im Bau (mit U231 und U230). Nächste neue Plan-Nummer U232.

**Nachtrag 26.10. 14:48 (Version 2026-09-23.86 · c1d9c975ae): Paket 23.86** (UEBERGABE 3ωωωω, U220, U231, U230). Der Poller wie entschieden: gesperrte Konten werden nicht mehr abgefragt, „groß“ beginnt bei 500.000 USD, kleine Konten (unter 25.000 USD) kommen nur nach eigenem Handel dran (sonst höchstens täglich, in derselben Gruppe wie leere Adressen). Nach unabhängiger Durchsicht dazu: Vorrang für leere und kleine Adressen mit mindestens 25.000 USD Handel seit ihrer letzten Abfrage (sonst hätten die kleinen Konten neue große Positionen verdrängt), Pause nach Fehlschlägen, der Recorder misst die Abstände je Stufe, das Alter im Snapshot zählt seit dem letzten Erfolg. Rückweg über die Unit: `--hot-notional 250000`, `--klein-regelmaessig`, `--vorrang-ab 0`. Eigener Fehler: Die Rückrechnung der Abstände aus dem Alter (Auswertung 11:00) war zu kurz verzerrt -- „Modell ein Achtel zu vorsichtig“ war teils ein Messfehler. Messung nachher am 28.10. und 30.10. 08:50. U230: direkte Bilanz v1/v2 im Bericht „Kalibrierung v2: Stand“. Nächste neue Plan-Nummer U232. Vor der Lieferung Texte nachgezogen (Berichtsplan 28.10., Debug Nr. 21, README: gemessene Abstände als Hauptmaß, Vorrang, Pause nach Fehlschlägen); die Fassung von 14:12 (61a5df2d04) wurde nie geliefert.

**Nachtrag 26.10. 15:57 (Version 2026-09-23.87 · 4ce6da0c6e): Paket 23.87** (UEBERGABE 3ααααα, U232). Volumenbalken im Live-Chart auf Wunsch des Nutzers: Volumen je Kerze im unteren Fünftel, Farbe wie die Kerze, in allen Rastern und Quellen. Der Server gibt je Kerze die Börse mit (`q`: hl eigene Bars, bnc Binance); jede zusammenhängende Strecke gleicher Börse hat ihre eigene Skala (4-h-Chart: Binance, dann die eigenen Bars). Die Preisskala reicht nach unten weiter, Linien und Marken enden am Band. Schalter „Volumen an/aus“ (im Browser gemerkt), Tooltip im Band. Kriterien vorab, Browser-Probe 78 von 78, Mutationen der Seite 12 von 12 und gegen den neuen Selbsttest `--selbsttest-volumen` 11 von 11 rot. Nur Anzeige; fließt nirgends ein. Nächste neue Plan-Nummer U233.
**Nachtrag 27.10. 20:23 (Version 2026-09-23.88 · 95b9909a33): Paket 23.88** (UEBERGABE 3βββββ, U235). Prognosemärkte auf Wunsch des Nutzers (27.10. 17:49): neuer Abschnitt „PM Prognosemärkte“ und Modul `hl_prognosemarkt.py` mit eigener `prognosemarkt.db` -- Kalshi, Polymarket und Hyperliquid HIP-4 nur lesend, ohne Konto; Dienst-Faden im Dashboard (Erstlauf setzt den Stichtag, Takt, Rückblick auf abgelaufene Märkte); vorab festgelegt (`KONZEPT_Prognosemaerkte.md`, unabhängig durchgesehen, Nachtrag 13.1 und 13.2): H1 Kalshi BTC 15 min vor dem Fensterbeginn, H2 Tagesleiter gegen das beste kausale Modell, H3 Inflationsüberraschung gegen BTC 08:30–09:00 ET, ein gemeinsames Urteil mit gewichtetem Holm, bis dahin nur Zählungen. Debug 129–133, Berichtsplan 30.10.–03.11. Hyperliquid mit eigenem Deckel von 20 Gewicht je Minute (Berichtigung der Recherche). Borri-Zitat in `KONZEPT_Ausblick.md` berichtigt. Wirkt auf nichts. Einspielen nach dem Poller-Bericht am 30.10. 08:50. Nächste neue Plan-Nummer U236, nächste freie Debug-Nummer 134.
**Nachtrag 28.10. 14:23 (Version 2026-09-23.88 · 95b9909a33, nur Dokumente): Poller-Kapazität vom 28.10. vorläufig** (UEBERGABE 3γγγγγ, U220). 23.88 läuft seit dem 27.10. gegen 22:26 (vor dem 30.10. auf Wunsch des Nutzers eingespielt); der Poller-Bericht vom 28.10. kam 10,4 h nach dem Neustart und zählt nicht als Messpunkt (Ersatz: Debug Nr. 21 von Hand ab 28.10. 22:35). Vorläufig Takte wie im Modell (Rang 1 1,01–1,03, Rang 0 1,14), OI-Abdeckung kaum verändert; Gruppe C voll -- vorab festgelegte Frage an den Nutzer. Das vorab festgelegte Maß der OI-Abdeckung liefert der Poller-Bericht nicht (eigenes Versäumnis); es kommt annähernd aus dem Bericht „Abdeckung“ der Wochenprüfung.
**Nachtrag 28.10. 14:44 (Version 2026-09-23.88 · 95b9909a33, nur Dokumente): Prognosemärkte im ersten Betrieb** (UEBERGABE 3δδδδδ, U235, U236). Alle Quellen vom Pi lesbar, Rückblick für das Urteil nach 16 h fertig; H1 nicht prüfbar (Kalshi eröffnet die 15-min-Märkte erst zum Fensterbeginn; R7 ohne Ausweichen), Holm auf H2 und H3 normiert; Urteil voraussichtlich mit der Wochenprüfung am 28.10.; `KONZEPT_Prognosemaerkte.md` Nachtrag 13.3 vor dem Urteil. Mängel nur in beschreibenden Teilen (Polymarket-404, HIP-4-Format und -Deckel mit eigenem Fehler aus 23.88, IP-Adresse in der Ausgabe) → U236. Gruppe C bleibt (Entscheidung des Nutzers).
**Nachtrag 28.10. 17:53 (Version 2026-09-23.89 · 254abc5669): Paket 23.89** (UEBERGABE 3εεεεε, U236). Prognosemärkte nach dem ersten Betrieb nachgebessert, nur beschreibende Teile: HIP-4 nur Krypto-Preisbinäre der Projekt-Coins nach Gewichtsplan (eigener Fehler aus 23.88: die Abrechnung bekam nie Gewicht), nicht mehr geführte Ausgänge geschlossen; Polymarket-Kennungen ohne Orderbuch ruhen 6 h; keine IP-Adresse im Erstlauf; Texte. Auswertung unverändert (U235-2). `KONZEPT_Prognosemaerkte.md` Nachtrag 13.4. Neu im Plan: U237 Volatilität (Wunsch des Nutzers 28.10.).
**Nachtrag 28.10. 20:16 (Version 2026-09-23.90 · 51fb804519): Paket 23.90** (UEBERGABE 3ζζζζζ, U237). Volatilität auf Wunsch des Nutzers (28.10. 17:03): neuer Abschnitt „VL Volatilität“ und Modul `hl_volatil.py` mit eigener `volatil.db` -- Index VI30/VI7 (Binance-Perps aus `swing.db`) und DVOL (BTC, ETH) mit dem Kurs auf zweiter Achse (Entscheidung des Nutzers, abweichend von U132), Zeitraum 2 W bis 5 J, Prognose der Schwankung je Woche für vier Wochen mit der Wahrscheinlichkeit einer volatilen Woche neben der Grundrate; vorab festgelegt (`KONZEPT_Volatilitaet.md`, Nachtrag 13 nach unabhängiger Durchsicht, 13.21 beim Bau gemessen): Rückblick ab 28.10.2021, ein gemeinsames Urteil V1–V4 kurz nach dem Einspielen, vorher nur Zählungen; Nachweisgrenze synthetisch: nur große Vorteile werden sicher erkannt. Beim Bau gefunden: globaler Name `VL` doppelt (der Abschnitt wäre leer geblieben); jetzt prüft `hl_viz --selbsttest-volatil` alle Skripte der Seite auf doppelte Namen. Debug 134–137, Berichtsplan 30.10. 13:00 und 31.10. 09:00. Wirkt auf nichts. Einspielen nach dem Poller-Bericht am 30.10. 08:50; Entscheidungen 13.20 vorher (Standards gelten). Nächste neue Plan-Nummer U238, nächste freie Debug-Nummer 138.
**Nachtrag 28.10. 20:59 (Version 2026-09-23.90 · 51fb804519, nur Dokumente): Wochenprüfung vom 28.10.** (UEBERGABE 3ηηηηη, U235, U220). Prognosemärkte ohne Urteil: drei der sechs Prüfungen vor dem Urteil nicht bestanden (H2 Kalibrierungssteigung 1,31; H3 MAE 0,101 bei n 4; H3 Faktor 1,38), H1 und H3 ohnehin unter der Mindestzahl; zwei eigene Entwurfsfehler; Wahl A/B/C beim Nutzer (`KONZEPT_Prognosemaerkte.md` 13.5). OI-Abdeckung nach 23.86 kaum verändert; Debug Nr. 21 ab 22:35 steht aus.
**Nachtrag 28.10. 22:51 (Version 2026-09-23.90 · 51fb804519, nur Dokumente): Poller-Kapazität, Ersatz-Messpunkt** (UEBERGABE 3θθθθθ, U220). Debug Nr. 21 um 22:49 nach 24,4 h Laufzeit: gemessene Abstände 10–13 % über dem Modell, groß, Pool und mittel gegen den 26.10. etwa halbiert, OI-Abdeckung kaum verändert -- wie erwartet, keine Änderung. Zweiter Messpunkt 30.10. 08:50.
**Nachtrag 28.10. 23:49 (Version 2026-09-23.91 · cb6d059ba2): Paket 23.91** (UEBERGABE 3ιιιιι, U235). Enthält 23.90. Prognosemärkte nach Wahl A des Nutzers (28.10. 22:56): Ohne bestandene Prüfungen vor dem Urteil schließt die Auswertung den Rückblick einmal ohne Urteil ab und rechnet danach nichts mehr neu; Bericht, Bilanz und Makro zeigen dann Beschreibendes mit der Aufschrift „ohne Urteil“, ohne p-Werte (`KONZEPT_Prognosemaerkte.md` 13.6). Einspielen statt 23.90 nach dem 30.10. 08:50.
**Nachtrag 30.10. 12:08 (nur Dokumente):** Poller-Kapazität, zweiter Messpunkt 30.10. 08:50 (UEBERGABE 3κκκκκ, U220): Hauptmaß im Band, OI-Abdeckung kaum verändert; die Messung vorher/nachher aus 23.86 ist vollständig, keine Änderung. Prognosemärkte mit 23.89 (Debug Nr. 129) wie erwartet. Auf dem Pi läuft 23.89; 23.91 kann jetzt eingespielt werden.
**Nachtrag 30.10. 21:12 (nur Dokumente):** Auf dem Pi läuft 23.91 · cb6d059ba2 (UEBERGABE 3λλλλλ). Volatilität: Urteil 30.10. 17:58 UTC -- V1 Niveau belegt, V2–V4 nicht belegt (`KONZEPT_Volatilitaet.md` 13.22). Prognosemärkte: Rückblick ohne Urteil abgeschlossen 30.10. 18:57 UTC (`KONZEPT_Prognosemaerkte.md` 13.7).
**Nachtrag 31.10. 14:03 (nur Dokumente):** Berichte vom 31.10. wie erwartet (UEBERGABE 3μμμμμ). Neu U238 (Vorschlag): Der Speicher der Prognosemärkte wächst ein Vielfaches schneller als geschätzt (`KONZEPT_Prognosemaerkte.md` 13.8); erst messen, dann Entscheidung 4 neu.
**Nachtrag 02.11. 00:36 (nur Dokumente):** Berichte vom 01.11. ausgewertet (UEBERGABE 3ννννν): Makro-Regime 10.7b bestanden, Volumen Teil B wie am 24.10., Datentage wie im Oktober. Neu U239 (Chartbild-Text zu U110) und U240 (Farside-Zählung erreicht, Vorschlag).
**Nachtrag 02.11. 01:34 (Version 2026-09-23.92 · 5446542fc7): Paket 23.92** (UEBERGABE 3ξξξξξ; U238, U239, U240), früher gebaut auf Wunsch des Nutzers (02.11. 00:48). Debug Nr. 129 zeigt den Speicher der Prognosemärkte mit gemessenem Zuwachs je Tag (ab 20 h nach dem Start; danach Entscheidung 4 neu, `KONZEPT_Prognosemaerkte.md` 13.9); die Farside-Zählung steht auch je Abrufzeit (danach Entscheidung zu den Abrufzeiten, `KONZEPT_Ausblick.md` 13.21); der Chartbild-Prüfstand U110 nennt das Urteil vom 25.10. Nur Messung oder Text. Die Zahl der Mutationen bei Debug 133 war seit 23.91 veraltet (eigener Fehler, jetzt geprüft).
**Nachtrag 03.11. 23:13 (nur Dokumente):** Trading Engine (U241) vorab festgelegt (UEBERGABE 3οοοοο, `KONZEPT_TradingEngine.md` Fassung 3 nach zwei unabhängigen Durchsichten): Reiter „Engine“ im TradeLabor, Papierkonto mit gemeinsamem Kapital, Aufnahme nur mit Beleg (ganze Geschichte oder letzte 17 Wochen), Pause per CUSUM in Handelszeit, „gescheitert“ als Bezeichnung mit Monatsbedingung. Fassung 1 hatte einen verzerrten Zufallsvergleich (eigener Fehler). Entscheidungen beim Nutzer; nichts gebaut.
**Nachtrag 04.11. 01:30 (Version 2026-09-23.93 · 9c13b41248): Paket 23.93 -- Trading Engine gebaut** (UEBERGABE 3πππππ, U241, `KONZEPT_TradingEngine.md` 15). Entscheidung des Nutzers 03.11. 23:23 „Wie vorgeschlagen“: Reiter „Engine“ im TradeLabor mit `hl_engine.py`, `hl_engine_js.py` und eigener `engine.db` (in der Sicherung); Papierkonto 100.000 USD, nur Trades der belegten Strategien, Bremse −10 % mit Lösen nur von Hand (Debug 142). Das Labor bleibt unverändert. Eine unabhängige Durchsicht des Codes fand vor dem ersten Lauf einen mittleren eigenen Fehler (beim Wechsel der Regelversion wären die übernommenen Trades aus dem Konto verschwunden) und kleine; behoben, alle Prüfungen wiederholt (Selbsttest 38/38, Mutationen 28/28). Erwartung: kein Trade vor dem 01.12. Enthält 23.92. Nächste neue Plan-Nummer U242, nächste freie Debug-Nummer 143.

**Nachtrag 04.11. 03:36 (Version 2026-09-23.94 · fea6e13689): Paket 23.94 -- Button „Bremse lösen“ statt Debug 142** (UEBERGABE 3ρρρρρ, U241, `KONZEPT_TradingEngine.md` 15 Punkt 17). Wunsch des Nutzers 04.11. 02:57. Im Hinweis der gesetzten Bremse im Reiter „Engine“ ein Button mit Nachfrage auf der Seite; der Server nimmt das Lösen nur per POST mit Kopfzeile und `ja=1` an, nur bei gesetzter Bremse und nur einmal; bis zur Prüfung um 00:30 UTC zeigt der Reiter „Lösen vorgemerkt“. Debug 142 weggefallen (Nummer reserviert). Regeln unverändert. Enthält 23.93 und 23.92. Nächste neue Plan-Nummer U242, nächste freie Debug-Nummer 143.

**Nachtrag 05.11. 02:15 (Version 2026-09-23.95 · b63b650a9b): Paket 23.95 -- zwei statt drei Generationen der Sicherung, Änderung des Backup-Pfads durchgeprüft** (UEBERGABE 3τττττ, U243). Wunsch des Nutzers 04.11. 23:48. Die Hauptdatenbank liegt im Backup-Ordner in zwei Ständen (neu, .1); die alte .2 fällt beim ersten Lauf vor der Platzprüfung weg (auf der SD-Karte rund 23 GB, gerechnet bis etwa Ende November). Elf Befunde der Pfad-Änderung und neun weitere aus einer unabhängigen Durchsicht behoben, vor allem: ein nicht eingehängtes Laufwerk führt nicht mehr zu einer Kopie auf der SD-Karte oder zum Absturz der Aufgabe „Backup“, sondern zu Meldung und neuem Versuch; das Dashboard prüft, bevor es anlegt, und rechnet den Platz für zwei Stände plus neue Kopie; Ordnernamen mit Apostroph; Wechsel während einer Sicherung gilt direkt danach; „Jetzt sichern“ nicht doppelt. Zweites Medium bis Ende November beim Nutzer (Vorschlag).

**Nachtrag 11.11. 22:30 (Version 2026-09-23.96 · 0069a56cd1): Paket 23.96 -- Gesamtaudit vom 11.11. und seine Sofort-Punkte, Backup-Kacheln unter System** (UEBERGABE 3υυυυυ; U196, U197, U198, U244–U249; Fable 5.2). Auftrag des Nutzers 11.11. 19:14: Code-, Logik- und Inhaltsaudit des ganzen Projekts (`AUDIT_Gesamt_11-11-2026.md`, im Paket). Kern: Für die Richtung über 4 und 24 h gibt es keinen belegten Vorteil; der Verlust des Labors ist fast ganz Kosten, gut die Hälfte davon XMR, und der Abstand zur Buchmitte ist modelliert, nie gemessen; belegt sind Schwankung, 7-Tage-Spannen, Erreich-Wahrscheinlichkeiten nach Abstand und H1 -- der Weg heißt „Glaskugel als Verteilung“. Gebaut: U196 (v2 liest die schlanken Tabellen, 90 statt 60 Tage), U197 (v1-Labels nur aus frischer Bar), U198 (Vorlauf-Paare), U247 (Notbremse meldet Instrumente ohne Live-Kurs, keine Regeländerung), U246 (Recorder speichert die Impact-Preise der Börse je Minute in `impact_bars`; der Labor-Bericht vergleicht sie mit dem Abstand-Modell), U249 (Labor-Bilanz je Coin mit „ohne XMR“), U245 Stufe C0 (Kacheln „Letztes Backup“ und „Datenbank“ im Abschnitt System, Warnung in dessen Kopfzeile), U248 („Kaufpreis/Verkaufspreis nach Modell“ statt „optimal“). Nur Konzept: `KONZEPT_Niveaus.md` (U244), `KONZEPT_Cockpit.md` (U245; C1 und C2 als nächstes Paket). **Regel für die nächste Sitzung:** Offene Entscheidungen dem Nutzer in Klartext und zum Anklicken vorlegen, mit Vorschlag und Folgen -- er merkt sich keine Nummern (U…, N…, H1). Offen beim Nutzer: Ersatzkurs der Notbremse für XMR; Kauf- und Verkaufspreis abschalten; die fünf Punkte des Cockpits. Nächste neue Plan-Nummer U250, nächste freie Debug-Nummer 143.

**Nachtrag 12.11. 00:30 (Version 2026-09-23.97 · 1ae18181ae): Paket 23.97 -- Notbremse findet den XMR-Markt; erste Messung „Modell gegen Börse“** (UEBERGABE 3φφφφφ; U250, U251, U252; Fable 5.2). Läufe des Nutzers vom 11.11. 23:35: Debug 13 (★ TradeLabor) und Debug 14 (★ Notbremse). **Regel des Nutzers (11.11. 22:48): immer die Debugnummer nennen.** Debug 14: Die Notbremse lief seit dem 23.10. ohne XMR -- im Korb stand der feste Dex-Name „felix“, den es an der Börse nicht gibt (Felix heißt dort „flx“, der Markt ist delistet; aktiv ist „hyna:XMR“); jede Minute eine gescheiterte Abfrage. Gebaut (U250): Der Recorder legt seine Zuordnung Coin -> Symbol und Dex in `meta['symbole']` ab; die Notbremse folgt ihr (sonst eigene Suche ohne delistete Märkte, nie ein fester Name), trägt 15-min-Schlüsse und Minutenkurse aus den Minutenkerzen nach und bestimmt einen vorläufigen Korb alle 10 Minuten neu. Regeln, Schwellen und Fassung unverändert. Debug 13: Die Börse liefert die Impact-Preise; der Abstand zur Buchmitte ist im Modell des Labors bei XMR rund zwölfmal so hoch wie die Messung der Börse (Median 49,3 gegen 4,0 bps je Seite, 92 % der Proben mit der 150-bps-Pauschale; eine Stunde, 53 Proben). Überschlag, kein Ergebnis: Labor rund −158.000 statt −307.951 USD; vor Kosten −16.615 USD -- einen Vorteil hat weiterhin keine Strategie. Am Kostenmodell ist nichts geändert; der Nutzer führt am Mi 18.11. noch einmal Debug 13 aus, danach die Entscheidung über eine zweite Bilanz mit gemessenen Kosten (U252). Nach dem Einspielen: Debug 14 (Zeile „Dex … Quelle: Recorder“, kein Hinweis „ohne Live-Kurs: XMR“). Offen beim Nutzer weiter: Kauf- und Verkaufspreis abschalten; die fünf Punkte des Cockpits. Nächste neue Plan-Nummer U253, nächste freie Debug-Nummer 143.

**Nachtrag 12.11. 02:55 (Version 2026-09-23.98 · 85ace1dea1): Paket 23.98 -- Cockpit, Schritt 1** (UEBERGABE 3χχχχχ; U245 Stufen C1 und C0b, U253; Fable 5.2). Frage des Nutzers vom 12.11. 00:55 nach dem Einspielen von 23.97: „aber das cockpit ist noch nicht umgesetzt?“ -- bis dahin war nur Stufe C0 gebaut. Vier Entscheidungen zum Anklicken (jeweils der Vorschlag): Cockpit oben auf der Hauptseite; ein Coin groß und ein Streifen mit allen sechs; Unbelegtes in die „Werkstatt“; der Kurs-Rechner darf einen Kurs im Browser merken (Schritt 2). Gebaut: `hl_cockpit.py` (Endpunkt `/cockpit`, liest nur die Ergebnisse von Ausblick, Volatilität, Chartbild, Makro, Fusion und Aktien) und `hl_cockpit_js.py`; Abschnitt „CK Cockpit“ als erster der Seite mit Kernsatz, fünf Lampen (Hebel ab Kontenquote 3; Termin 24 h vor bis 2 h nach Verbraucherpreisen oder Arbeitsmarktbericht; Wochenende; Aktien = Ausnahmelage (c) des Ausblicks; Schwankung ab dem 80. und 95. Perzentil), Schwankung, Spannen, Levels, Messwerten, Kosten und einem Streifen mit sechs Coins; die bisherigen Abschnitte darunter, Unbelegtes samt Kennzahlenleiste in der Gruppe „Werkstatt · nicht belegt“, Netzwerk bis System in der Gruppe „Betrieb“. **Regel: ohne Quelle kein „aus“** -- eine Lampe ohne frische Quelle oder ohne nachweislich laufende Prüfung ist grau und nennt den Grund; jedes Instrument nennt seinen Stand. Fund beim Bau: Dem Abschnitt „Aktualisierung“ fehlte ein `</div>`, Debug und System lagen in ihm (behoben). Debug 143 (★ Cockpit als Text) und 144. Geprüft: Selbsttests 42 von 42 und 16 von 16, Vertrag mit den Modulen auf deren Demo-Datenbanken, Browser-Probe bei 360 bis 1280 px, Mutationen 72 von 72 rot, A7 95 von 95, Update-Probe 21 von 21. Nicht geprüft: echte Daten des Pi, echtes Handy. Nach dem Einspielen: Debug 143 schicken lassen; weiter offen Debug 14 (nach 23.97) und Debug 13 am Mi 18.11. (U252). Als Nächstes Cockpit Stufe C2 (Kurs-Rechner). Nächste neue Plan-Nummer U254, nächste freie Debug-Nummer 145.

**Nachtrag 12.11. 18:20 (Version 2026-09-23.99 · d24ec96f4d): Paket 23.99 -- Cockpit berichtigt nach der ersten Prüfung auf echten Daten** (UEBERGABE 3ψψψψψ; U245; Fable 5.2). Der Nutzer schickte am 12.11. 17:19 Debug 143 (★ Cockpit als Text, auf 23.98) und noch einmal den alten Debug 14 vom 11.11. 23:34 -- **ein frischer Debug 14 steht weiter aus.** Debug 143 stimmt mit den Quellen überein (Kosten, Aktien-Regel wird auf dem Pi geprüft, nächster Termin Arbeitsmarktbericht; Lampe Hebel an bei BTC 3,20 und ETH 3,59) und zeigte zwei Fehler des Cockpits: (1) „Vorsprung offen“ an der 7-Tage-Spanne aller Coins, weil der Vermerk an der Gesamtprüfung S1 des Ausblicks hing, die auf dem Pi „besteht nicht“ lautet (Vorsprung belegt, p 0,002; Band von BTC mit 84,0 % ± 1,7 zu weit); (2) „80. Perzentil“ bei Lampe „aus“ (Anzeige gerundet, Schwelle ungerundet). Behoben: Jeder Balken trägt die gemessene Trefferquote des Coins („traf 84 % (zu weit)“, Maßstab wie `hl_ausblick.deckung_wertung`), Kernsatz und Zeile darunter nennen Trefferquote, Vorsprung je Horizont und das Urteil S1 mit Grund; Perzentile werden abgeschnitten (`pz_zahl`). **Berichtigung meines Fehlers vom 11.11.:** Konzept und Audit führten die 7-Tage-Spanne als „belegt“; belegt ist nur ihr Vorsprung, die Gesamtprüfung S1 besteht bei keinem Horizont (stand in Debug 73 und im README). **Wer künftig Zahlen aus einem Bericht in ein Konzept oder eine Probe-Welt übernimmt, übernimmt auch das Urteil, das daneben steht.** Neu sichtbar: Das Band von PAXG ist zu eng (traf 67 %, bei 28 Tagen 58 %). Geprüft: Selbsttests 47 von 47 und 18 von 18 (Probe-Welt mit Zahlen und Urteilen des Pi; Vertrag über `hl_ausblick.urteil_s1`), Browser-Probe bei 360 bis 1280 px, Mutationen 90 von 90 rot, A7 95 von 95, Update-Probe 22 von 22. Nicht geprüft: die Anzeige auf dem Pi, echtes Handy. Nach dem Einspielen: Debug 143 erneut, Debug 14 frisch, Debug 13 am Mi 18.11. (U252). Als Nächstes unverändert Cockpit Stufe C2. Nächste neue Plan-Nummer U254, nächste freie Debug-Nummer 145.

**Nachtrag 14.11. 22:05 (Version 2026-09-23.100 · 0423fd048b): Paket 23.100 -- Unstaking bei Ethereum: Daten und Anzeige (U254), Studie vorab festgelegt (U255)** (UEBERGABE 3ωωωωω; `KONZEPT_Unstaking.md`; Fable 5.2). Der Nutzer hat am 14.11. 19:57 beobachtet, dass auf große Abzüge aus dem Ethereum-Staking häufig Kursrückgänge folgen, und einen Indikator im Cockpit verlangt, der einen Termin nennt. Das Projekt erfasste dazu nichts. **Der Termin ist keine Prognose:** Die Kette teilt jedem angemeldeten Abzug einen Zeitpunkt zu (höchstens 256 ETH je Epoche = 57.600 ETH am Tag, dann 27,3 h Sperrfrist). Neu: `hl_staking.py` (importiert kein Projektmodul) liest stündlich einen öffentlichen Beacon-Knoten -- Vollabzüge, Teilabzüge, **Zusammenlegungen abgezogen** (ihre Quelle sieht aus wie ein Abzug, das ETH bleibt gestakt; am 14.11. 194.432 ETH neben 251.274 ETH Abzügen) -- und alle 6 h die Tagesdatei von validatorqueue.com; `staking.db` neben der Hauptdatenbank, nicht im Backup. Im Cockpit bei ETH: Karte „Unstaking“ (Summe, „alles frei bis“, Termin der nächsten großen Freigabe = Tage ab 28.800 ETH, Kalender, größter Abzieher, Gegenseite) und eine Zeile unter dem Kernsatz; Klasse B, blau, ohne Warnfarbe. **Debug 145** ★ Unstaking: Stand als Text (fragt beide Quellen selbst ab und zeigt je Frage Status, Größe, Dauer), **146** Selbsttest. **Bewusst nicht gebaut:** Warnsignal und Eingang in die Prognose -- die Kurswirkung ist eine Beobachtung, kein Befund; die Studie (Fälle, Zielgröße ETH minus BTC über 7 Tage, Verschiebe-Test, Urteil) ist in `KONZEPT_Unstaking.md` 6 festgelegt, bevor Schlange und Kurse zusammengeführt wurden. Geprüft: Modul 43 von 43 (auch der echte Abruf gegen einen Webserver auf demselben Rechner), Cockpit 54 von 54, Dashboard 21 von 21, Mutationen 148 von 148 rot, A7 96 von 96, Update-Probe 26 von 26 von 23.99 und 26 von 26 von 23.98 aus, Browser-Probe 360 bis 1280 px. **Nicht geprüft: der Abruf über das Netz -- die Sandbox hat keines. Erst Debug 145 auf dem Pi zeigt, ob der öffentliche Knoten antwortet; wenn nicht, zeigt das Cockpit die Schätzung aus der Tagesdatei oder den Grund.** Beim Nutzer offen: Debug 145 nach dem Einspielen, Debug 14 frisch, Debug 143, Debug 13 am Mi 18.11., Entscheidung über U255. **Beim Bau gefunden:** Eine Probe im Selbsttest des Makro-Moduls hing an der echten Uhr und fällt seit dem 13.11.2026 durch (auch in 23.99 auf dem Pi; das Modul rechnet richtig) -- behoben; **wer A7 künftig rot sieht, prüft zuerst, ob eine Probe mit festen Daten an der echten Uhr hängt** (U256). Nächste neue Plan-Nummer U257, nächste freie Debug-Nummer 147 (für U244 vorgesehen).

**Nachtrag 15.11. 00:20 (Version 2026-09-23.101 · 41525375bd): Paket 23.101 -- Unstaking: die vorab festgelegte Prüfung „Folgt auf große Abzüge ein Kursrückgang?“ ist gebaut; ihr Urteil entsteht beim ersten Lauf von Debug 147 auf dem Pi (U255)** (UEBERGABE 3αααααα; `KONZEPT_Unstaking.md` 6 und 6a; Fable 5.2). Der Nutzer hat nach 23.100 gewählt, die Prüfung als Nächstes zu bauen. Neu: `hl_staking_studie.py` -- Fälle A (Tag, zu dessen Beginn die Schlange um mindestens 57.600 ETH gewachsen ist; neue Welle erst nach 14 Tagen Ruhe) und B (erster Tag nach dem Freiwerden des ersten ETH), Zielgröße ETH minus BTC über 7 Tage, Verschiebe-Test im Kreis (30 bis N − 30 Tage), Holm über beide Fragen, „belegt“ nur mit p < 0,05, mindestens 8 Fällen und negativem Unterschied in beiden Hälften; Nullprobe (2.000 Lagen, bestanden bis 6,5 %), Fundquote und Nachweisgrenze; Gegenprobe ohne die Anlass-Welle vom November 2026. Daten: Tagesdatei in `staking.db` (erste Messung je UTC-Tag; Werte vor dem 07.05.2025 sind Validatoren × 32; 07.05.–21.05.2025 ausgeschlossen) und 30-min-Kerzen aus `swing.db`. **Die Prüfung rechnet einmal und speichert das Urteil** (`st_meta`, `studie_u255`); danach zeigt **Debug 147** es nur und zählt die Wellen seither. Neu gerechnet wird nur mit einer neuen Fassung der Regeln (Kennung `REGEL` im Modul) -- **wer am Verfahren etwas ändert, erhöht die Fassung und begründet es im Konzept; wer nur den Bericht ändert, lässt sie stehen.** Im Cockpit steht das Urteil als Text in der Karte „Unstaking“; auch „belegt“ färbt nichts, Lampe und Platz im Ausblick werden dann eigens festgelegt. **Debug 148** Selbsttest. Geprüft: Prüfung 33 von 33 (Kreistest gegen eine Gegenrechnung ohne numpy, Positivkontrolle in die Kurse eingebaut), Staking 43 von 43, Cockpit 56 von 56, Dashboard 23 von 23, Mutationen 215 von 215 rot, A7 97 von 97, Update-Probe 29 von 29 von 23.100, 23.99 und 23.98 aus, Browser-Probe 360 bis 1280 px. **Nicht geprüft: der Lauf auf echten Daten -- die Sandbox hat weder Netz noch die Daten des Pi.** Erkenntnis beim Bau: Das Verfahren liegt unter Zufall knapp unter 5 % (4,4 bis 4,9 % auf erfundenen Reihen), deshalb die Toleranz der Nullprobe; Wellen in festem Abstand machen den Kreistest vorsichtig. Beim Nutzer offen: nach dem Einspielen Debug 145, dann Debug 147; Debug 14 frisch, Debug 143, Debug 13 am Mi 18.11. Nächste neue Plan-Nummer U258, nächste freie Debug-Nummer 149 (für U244 vorgesehen).

**Nachtrag 15.11. 05:38 (Version 2026-09-23.102 · 5dc152fa44): Paket 23.102 -- Unstaking: das Urteil der Prüfung liegt vor (nicht belegt, Wellen bis 25.10.2026); die Tagesdatei der Quelle steht; eigene Tagesreihe aus dem Knoten** (UEBERGABE 3ββββββ; `KONZEPT_Unstaking.md` 3a und 6b; Fable 5.2). Der Nutzer hat am 15.11. Debug 145 und Debug 147 vom Pi geschickt (auf dem Pi 23.101). **Urteil U255, gespeichert am 15.11.2026 03:24 UTC: nicht belegt** -- 18 Wellen seit Mai 2023; nach der Anmeldung ETH gegen BTC über 7 Tage −1,00 Prozentpunkte gegen alle Tage (14 von 18 negativ, p 0,211, nach Holm 0,422, Hälften +0,67 / −2,67), nach der Freigabe +0,21; Nullprobe bestanden, Nachweisgrenze 3,5 %. **Mein Fehler in 23.101:** Der Bericht schrieb für den 01. bis 14.11.2026 „keine Welle“ -- die Tagesdatei von validatorqueue.com endet aber am 25.10.2026, die Welle vom November (der Anlass der Frage) ist nicht in den Daten. Berichtigt: Der Bericht unterscheidet „keine Welle“ von „nicht in den Daten“ und sagt beim Urteil, bis wohin es reicht; die Karte nennt „Wellen bis 25.10.2026“. Regeln und gespeichertes Urteil bleiben (`U255/1`; nur der Bericht ist geändert). **Neu in `hl_staking.py`:** eigene Tagesreihe `st_tag_knoten` (erster Stand des Knotens je UTC-Tag: Schlange, Wartezeit, Sperrfrist, Teilabzüge, Zusammenlegungen getrennt), Abruf zwei Minuten nach Mitternacht UTC außer der Reihe; Debug 145 meldet das Alter der Tagesdatei, gleicht nur mit einer frischen ab und zählt Tage, an denen ihre Schlange um mehr als 60.480 ETH fiel; die Zahl der Validatoren gilt 120 statt 30 Tage als brauchbar (bis 21.02.2027, mit Datum). **Wer hier weiterarbeitet, muss wissen:** (1) Die Tagesdatei ist keine laufende Quelle mehr; Gegenseite und Ersatzkalender fehlen, bis U258 gebaut ist. (2) Die eigene Reihe beginnt mit dem Einspielen von 23.102; die Tage vom 26.10.2026 bis dahin fehlen und lassen sich aus dem Knoten nicht nachholen. (3) **`staking.db` ist nicht im Backup (U257, jetzt P1)** -- Reihe und Urteil wären bei Verlust weg. (4) Die Tagesdatei zählt womöglich Zusammenlegungen mit (an fünf ihrer letzten sieben Tage fiel die Schlange um 76.389 bis 121.960 ETH; Abzüge allein erlauben 57.600): nicht geprüft; einzelne der acht Wellen seit Mai 2025 wären dann keine Abzüge. (5) Eine zweite Prüfung braucht vorab festgelegte Regeln zu Datenquelle, Anschluss und Lücke (U259) -- nicht nachträglich an den neuen Wellen ausrichten. Geprüft: Staking 48 von 48, Prüfung 34 von 34, Cockpit 59 von 59, Dashboard Cockpit bestanden, Kreuzprobe (Urteil mit 23.101 gespeichert, mit 23.102 gelesen: unverändert), Mutationen 260 von 260 rot, A7 97 von 97, Update-Probe 29 von 29 von 23.101 aus (mit und ohne das Konzept zum Unstaking), auch auf einer Datenbank von 23.101, Browser-Probe 360 bis 1280 px. **Nicht geprüft: der Lauf auf dem Pi** (Tabelle in der vorhandenen Datenbank, Abruf nach Mitternacht) -- Debug 145 zeigt es. Lehre: Ein Satz „es gab kein X“ braucht die Prüfung, ob die Daten die Zeit decken; eine fremde Quelle hat ein Ende, bis das Gegenteil gezeigt ist. Beim Nutzer offen: nach dem Einspielen Debug 145 und Debug 147, einen Tag später noch einmal Debug 145; Debug 14 frisch, Debug 143, Debug 13 am Mi 18.11. Nächste neue Plan-Nummer U260, nächste freie Debug-Nummer 149 (für U244 vorgesehen).

**Nachtrag 15.11. 10:55 (Version 2026-09-23.103 · 64bbad89b1): Paket 23.103 -- `staking.db` im täglichen Backup (U257)** (UEBERGABE 3γγγγγγ; `KONZEPT_Unstaking.md` 3b; Fable 5.2). Der Nutzer hat nach 23.102 gewählt, als Nächstes das Backup zu bauen. Während des Baus kamen Debug 145 und Debug 147 vom Pi mit 23.102 (15.11. 09:34 UTC): kein neuer Fehler -- der berichtigte Bericht steht, das gespeicherte Urteil ist unverändert, die eigene Tagesreihe hat ihre erste Zeile (die Tabelle entstand in der vorhandenen Datenbank); neu: an 19 von 510 Tagen seit 22.05.2025 fiel die Schlange der Tagesdatei um mehr als 60.480 ETH (am stärksten 128.494 ETH am 27.06.2026), was die Vermutung stützt, dass sie Zusammenlegungen mitzählt (nicht bewiesen); offen bleibt der Abruf kurz nach Mitternacht UTC (Zeile vom 16.11.). In `staking.db` liegen die eigene Tagesreihe aus dem Knoten (seit 23.102) und das gespeicherte Urteil der Prüfung U255 -- beides nicht neu ladbar; die Datei war in keiner Sicherung. Jetzt steht `staking` in `hl_recorder.BACKUP_NEBEN`: Das tägliche Backup kopiert die Datei wie die anderen Nebendatenbanken über die SQLite-Backup-API (`staking_backup.db`, voriger Stand `.1`). **Wer eine weitere Nebendatenbank sichern will, trägt ihren Namen nur noch in `BACKUP_NEBEN` ein** -- die beiden Dateimuster (Anzeige und Umzug; Aufräumen) entstehen daraus; bis 23.102 waren es drei Stellen von Hand. Der Selbsttest des Backups (B7) prüft jetzt den Inhalt jeder Kopie, den vorigen Stand und eine beschädigte Quelle in zwei Arten (unlesbar: Ausnahme; in sich widersprüchlich: Meldung der Prüfung) -- in beiden bleibt die gute Kopie liegen, der Fehler steht als `<name>_db_error` in `backup.json`. Der Selbsttest des Cockpits sichert eine von `hl_staking` und `hl_staking_studie` gefüllte Datei mit `do_backup`, stellt sie an einem neuen Ort wieder her und vergleicht Tagesreihe, Tagesdatei, Stand, Urteil und den Text von Debug 147. **Debug 145 nennt die Sicherung** (`hl_staking.sicherung_stand`: Ordner aus `meta.backup_dir` der Hauptdatenbank, sonst wie `hl_recorder.resolve_backup_dir` die Vorgabe „dbbackup“; Zeit und Gelingen aus `backup.json`) -- nur lesen, das Modul importiert weiter kein Projektmodul. Die erste Kopie entsteht beim nächsten täglichen Backup (der Recorder sichert erst, wenn das letzte gelungene 24 Stunden alt ist, nicht bei jedem Neustart) oder mit „Jetzt sichern“. **Wiederherstellen von Hand:** Dashboard-Dienst stoppen, `staking.db-wal` und `-shm` löschen, `staking_backup.db` als `staking.db` neben die Hauptdatenbank kopieren, Dienst starten. Nicht geändert: Prüfung, Cockpit, Seite; keine neue Datei, keine neue Debug-Nummer. Geprüft: Backup-Selbsttest und Cockpit-Selbsttest bestanden, Staking 50 von 50, Prüfung 34 von 34, Cockpit 59 von 59, Mutationen 286 von 286 rot, A7 97 von 97, Update-Probe 27 von 27 von 23.102 aus (und von 23.101 aus, mit und ohne das Konzept), auch auf Daten des Ausgangs. **Nicht geprüft: der Lauf auf dem Pi** -- Debug 145 zeigt nach dem nächsten Backup, ob die Kopie da ist. Bekannte Grenze: Die Kachel „Letztes Backup“ zeigt nur die Hauptdatenbank; für die anderen neun Nebendatenbanken gibt es keine solche Zeile. Beim Nutzer offen: Debug 145 am 16.11. oder später (Tagesreihe kurz nach Mitternacht UTC, Zeile „Sicherung“ mit Kopie); Debug 14 frisch, Debug 143, Debug 13 am Mi 18.11. Nächste neue Plan-Nummer U260, nächste freie Debug-Nummer 149 (für U244 vorgesehen).

**Nachtrag 15.11. 14:56 (Version 2026-09-23.104 · 5078947908): Paket 23.104 -- Unstaking: Verlauf im Cockpit (U260)** (UEBERGABE 3δδδδδδ; `KONZEPT_Unstaking.md` 4a; `KONZEPT_Cockpit.md` 12; Fable 5.2). Der Nutzer fragte nach dem Einspielen von 23.103: „Wo sehe ich den Chart mit dem Unstaking?“ Einen Verlauf über die Zeit gab es nicht (die Karte „Unstaking“ zeigt Stand und die nächsten Tage, nur bei ETH); auf die Frage zum Anklicken wählte er „Ja, bauen“. Gebaut ist eine eigene Karte **„Unstaking · Verlauf“** im Cockpit, nur bei ETH: zwei Felder mit gemeinsamer Zeitachse -- oben der ETH-Kurs zu Beginn jedes UTC-Tags, unten die Schlange der Abzüge ab null (bis 25.10.2026 die Tagesdatei, so wie die Prüfung sie liest; ab 15.11.2026 die eigene Tagesreihe vom Knoten), Marken an den 18 Wellen des gespeicherten Urteils, graue Fläche, wo drei Tage oder mehr fehlen, Ausschnitt 3 Monate / 1 Jahr / alles, Ablesen per Antippen (rastet auf die Welle; ihr Satz erscheint unter dem Bild), Wellen als aufklappbare Liste mit den Zahlen aus Debug 147. **Bewusst keine zweite Skala in einem Feld** und **keine eigene Bestimmung von Wellen**: Das Bild zeigt Gemessenes und das gespeicherte Urteil, sonst nichts; darunter steht „Der Verlauf allein belegt keinen Zusammenhang“. Wer hier weiterbaut: Die Reihen kommen aus `hl_staking_studie.verlauf` (nur lesen; `kurs_tagesbeginn` liest zwei Kerzen je Tag und gibt denselben Kurs wie `kurse_lesen` -- der Selbsttest hält das fest), die Antwort formt `hl_cockpit.verlauf_bauen`, Endpunkt `/cockpit/unstaking` (10 min Zwischenspeicher), das Skript holt sie nur bei ETH und frühestens nach 30 min wieder. Die Linienfarben `#388bfd` und `#bb8009` sind die nächsten dunkleren Stufen des Blau und des Gelb des Cockpits -- diese selbst sind für zwei Linien auf der Kartenfläche zu hell (geprüft mit einem Prüfer für Diagrammfarben). **Debug 143** nennt unter ETH vier Zeilen „Unstaking Verlauf …“. Nicht geändert: Regeln, Urteil und Bericht der Prüfung, `hl_staking.py`, Backup; keine neue Datei, keine neue Debug-Nummer. Geprüft: Prüfung 39 von 39, Cockpit 68 von 68, Cockpit-Selbsttest des Dashboards bestanden, Staking 50 von 50, Mutationen 359 von 359 rot, A7 97 von 97, Update-Probe 26 von 26 von 23.103 aus und 27 von 27 von 23.102 aus, auch auf Daten des Ausgangs, Browser-Probe bei 360 bis 1280 px. **Nicht geprüft: der Lauf auf dem Pi mit echten Daten** -- die Demo-Welt der Browser-Probe ist erfunden (Kurse frei gewählt; die Schlange springt an den 18 Tagen des Pi-Berichts, dazwischen gerade Strecken). Grenzen: Die Tage 26.10.–14.11.2026 fehlen; an der Nahtstelle wechselt die Quelle (offene Zählweise der Tagesdatei, U259); Wellen nach dem Urteil sind nicht markiert; der Kurs im Bild ist der zu Tagesbeginn. Beim Nutzer offen: Blick auf die Karte bei ETH und Debug 143; Debug 145 am 16.11. oder später (Tagesreihe kurz nach Mitternacht UTC, Zeile „Sicherung“); Debug 14 frisch; Debug 13 am Mi 18.11. Nächste neue Plan-Nummer U261, nächste freie Debug-Nummer 149 (für U244 vorgesehen).

**Nachtrag 16.11. 14:42 (Version 2026-09-23.105 · 2dfd017812): Paket 23.105 -- Cockpit: Karte „Kurs-Rechner“ (U245 Stufe C2, erster Teil)** (UEBERGABE 3εεεεεε; `KONZEPT_Cockpit.md` 13; Fable 5.2). Am 16.11. lag die Sammeldatei des Pi vor (dort lief 23.103 · 64bbad89b1; 23.104 war noch nicht eingespielt). Auf die Frage zum Anklicken wählte der Nutzer „Kurs-Rechner bauen“. Gebaut ist eine Karte **„Kurs-Rechner“** im Cockpit, bei jedem Coin unter „Levels“: Für einen eingetippten Kurs zeigt sie die Wahrscheinlichkeit, dass er **vom jetzigen Kurs aus** in 1 Stunde, 4 Stunden, 7 und 14 Tagen **mindestens einmal berührt** wird; bis zu 6 Kurse je Coin lassen sich unter den Namen Liquidation, Stopp, Limit, Marke merken -- nur im Browser (`localStorage` `ck_rechner_v1`), auf dem Pi wird nichts davon gespeichert. **Wer hier weiterbaut:** Gerechnet wird auf dem Server (`hl_cockpit.rechner_bauen`, Endpunkt `/cockpit/rechner`, kein Zwischenspeicher), das Skript liest nur die Eingabe und zeichnet. Die Stunden sind das Nullmodell des Magnet-Tests (`hl_kaskade.p_ueber` mit c und τ aus learned „magnet“ im Prognosespeicher, nur gelesen, höchstens 3 Tage alt; σ über 4 Stunden aus `hl_anker.Markt`, mal √(h ÷ 4)). Die Tage kommen aus der Verteilung des laufenden Hochs und Tiefs der jüngsten Rechnung des Ausblicks, die `hl_ausblick.prognose` seit diesem Paket je Coin in `au_meta` „lauf“ ablegt (199 Quantile; `erreichen_aus_lauf` bildet `erreichen()` auf höchstens 0,5 Punkte + 1/N nach) -- **nicht** in `au_prognose`, weil die Zeilen der 6-Stunden-Anker für immer bleiben. Die Verteilung wird am jetzigen Kurs angelegt; die Karte „Levels“ zeigt dagegen Wahrscheinlichkeiten ab dem Anker der Rechnung, nach einer schnellen Bewegung weichen beide ab. Regeln, die fest sind: eine längere Frist ist nie unwahrscheinlicher als eine kürzere (sonst gilt der Wert der kürzeren, mit Vermerk, sobald sich die gezeigte Zahl ändert); ohne frischen Kurs (5 Minuten) keine Rechnung; fehlt eine Quelle, bleibt genau diese Frist leer und nennt den Grund; Vermerk „nicht geprüft“ jenseits von 3 Schwankungen der Frist (Stunden) und 30 % (Tage); nie 0 % oder 100 %. S3 prüft die Erreich-Wahrscheinlichkeiten nur über alle Coins zusammen; je Coin steht bei den Tagen ein Hinweis, wenn sein 80-%-Band im Rückblick zu eng oder zu weit ist (Wertung wie an der Spanne; PAXG zu eng: die Zahlen können zu niedrig sein). Beim Tippen zeichnet das Cockpit nicht neu (höchstens 15 s nach dem letzten Tastendruck). **Debug 143** nennt je Coin acht Beispielkurse (±1, ±2, ±5, ±10 %) mit ihren vier Zahlen, Gründen und Belegen. **Lehre aus dem Bau:** Ein Teil-Lauf eines Selbsttests (`--nur e2e`) kann bestehen, während der volle Lauf scheitert -- die Demo-Welt hängt vom Lauf davor ab; vor der Lieferung zählt der volle Lauf. Und: Proben, die den Rechner direkt aufrufen, melden eine Ausnahme jetzt als fehlgeschlagene Probe statt abzubrechen (sonst zählt eine Mutation, die nur einen Abbruch auslöst, nicht als gefunden). Nicht geändert: Modell, Rückblick und Urteile des Ausblicks, Magnet-Test, Lampen, übrige Karten; keine neue Datei, keine neue Debug-Nummer. Geprüft: Cockpit 90 von 90, Cockpit-Selbsttest des Dashboards bestanden (42 Proben), Ausblick bestanden (67 Proben), Positivkontrolle der Stunden auf einem Probe-Markt (höchstens 2,5 Standardfehler an acht Zufallsabständen), Mutationen 496 von 496 rot, A7 98 von 98, Update-Probe 28 von 28 von 23.103 aus und 27 von 27 von 23.104 aus, auch auf Daten des Ausgangs, Browser-Probe bei 360 bis 1280 px. **Nicht geprüft: der Lauf auf dem Pi mit echten Daten** (echte Nullmodelle, Rechenzeit), ein echtes Handy, eine eigene Bilanz des Rechners für Kurse des Nutzers. Grenzen: „berührt“ heißt mindestens einmal erreicht; für eine Liquidation zählt bei Hyperliquid der Mark-Preis, nicht der Schluss der Minutenkerze; nach dem Einspielen erscheinen 7 und 14 Tage erst nach der nächsten Rechnung des Ausblicks. Beim Nutzer offen: 23.105 einspielen (enthält 23.104), Debug 143; Debug 145; Debug 14 frisch; Debug 13 am Mi 18.11.; Entscheidung zu U240. Nächste neue Plan-Nummer U261, nächste freie Debug-Nummer 149 (für U244 vorgesehen).

**Nachtrag 16.11. 22:15 (Version 2026-09-23.106 · 763e8d40c2): Paket 23.106 -- Unstaking: zweite Prüfung der Kursfolge vorab festgelegt (U259)** (UEBERGABE 3ζζζζζζ; `KONZEPT_Unstaking.md` 6c; Fable 5.2). Nach 23.105 wählte der Nutzer „1, 2 und 3 ausführen“ (U259, dann U244, dann der Rest von Stufe C2). **Was feststeht (Fassung `U255/2`, 16.11.2026, vor jeder neuen Welle; gerechnet ist nichts):** Die zweite Prüfung ist eine Bestätigung an neuen Daten -- sie zählt nur Wellen aus der eigenen Messung am Knoten und wird genau einmal gerechnet, sobald acht davon bewertet sind (Stichtag = der späteste von Falltag A der achten Welle, den Falltagen B der ersten acht und 364 Tagen nach dem ersten Tag mit bekanntem Zuwachs). Messgröße ist der Zuwachs der **angemeldeten Abzüge** (Schlange + Sperrfrist + Teilabzüge, ohne Zusammenlegungen) gegen den Vortag, Schwelle fest 57.600 ETH; ein Tag zählt nur, wenn seine erste Messung vor 03:00 UTC liegt. Beginnt die Reihe mit einer Summe ab 57.600 ETH oder ist die Summe über eine Lücke hinweg um mindestens 57.600 ETH gewachsen, gilt der Tag als Tag mit Zuwachs ohne Fall („Wiederbeginn“): Die Reihe begann am 16.11.2026 mit 248.223 ETH, die Welle vom November zählt nicht, eine neue Welle kann frühestens am 01.12.2026 beginnen. Alles Übrige wie in der ersten Prüfung (Zielgröße, Kreistest, Holm, die drei Bedingungen, Nullprobe, Positivkontrolle; Niveau 5 %). **Bis zum Urteil zeigt das Projekt keine Kursfolgen neuer Wellen** -- wer weiterbaut, lässt das so. **Wer hier weiterbaut:** Gebaut sind nur die Teile, die heute etwas zeigen (`hl_staking_studie.reihe_lesen`, `faelle_eigen`, `stichtag_2`, `neue_wellen`; in `hl_staking` `tageswert_gueltig`, `angemeldet_eth`, `nachholen_faellig`). **Die Rechnung der zweiten Prüfung fehlt noch (U261)**: dieselben Schritte wie `rechnen()` auf den Fällen aus `faelle_eigen`, Urteil einmal unter `studie_u255_2`; die Regeln aus 6c dürfen dabei nicht mehr geändert werden (bis zur ersten bewerteten neuen Welle, frühestens 08.12.2026, wären sie mit Offenlegung noch änderbar). Debug 147 meldet „fällig“, sobald der Stichtag erreicht ist. `faelle_bestimmen` (erste Prüfung) ist unberührt; ohne Wiederbeginn gibt `faelle_eigen` dieselben Fälle (Probe auf Zufallsreihen). **Warum die Summe und nicht die Schlange:** EIP-8061 steht in der Übersicht des Upgrades Glamsterdam (EIP-7773) unter „Scheduled for Inclusion“ -- das Kontingent der Austritte stiege von 256 ETH je Epoche auf den gestakten Bestand ÷ 32.768 (rund 247.000 statt 57.600 ETH am Tag); für die Testnetze sind dort der 06.10. und der 26.10.2026 genannt, für das Hauptnetz am 16.11.2026 kein Termin. Die Schlange wäre danach meist binnen Stunden leer; die Summe hält jeden Antrag fest, bis er frei ist. Am 16.11. galt noch 256 ETH (aus Debug 145: 114.190 ETH Vollabzüge und 42.024 ETH Teilabzüge über 607,7 Epochen = 257 ETH je Epoche; Teilabzüge nutzen dasselbe Kontingent). **Daraus U262:** Im Modul stehen 57.600 ETH am Tag als feste Zahl in Texten, in der Schwelle der großen Freigabe (die Hälfte), im Ersatzkalender und in der Grenze der Tage mit zu schnellem Abbau -- vor der Aktivierung auf dem Hauptnetz anpassen; der Kalender „frei ab“ kommt aus den Zeitpunkten der Kette und bleibt richtig. **Sonst gebaut:** Der Dienst holt eine misslungene Messung zu Tagesbeginn alle 5 Minuten nach (00:02 bis 03:00 UTC); Debug 145 zeigt je Zeile der Tagesreihe die Summe und ihren Zuwachs; die Karte „Unstaking · Verlauf“ zeigt ab der eigenen Messung die Summe (Feldname, Quellenzeile, Ablesezeile „Angemeldet“) und neue Wellen als offenen Kreis; Debug 147 listet die Tage, an denen die Schlange der Tagesdatei um mehr als 60.480 ETH fiel, mit den Mustern Zacke und Delle und sagt, ob ein Falltag A der ersten Prüfung daran hängt (Ergebnis erst vom Pi). Dazu passt: Zusammenlegungen haben ein eigenes Kontingent (gestakter Bestand ÷ 65.536 abzüglich 256 ETH je Epoche; bei 36 bis 38 Mio. ETH mit den Austritten rund 124.000 bis 130.000 ETH am Tag) -- der größte Abbau der Tagesdatei (128.494 ETH) liegt darin; bewiesen ist die Zählweise damit nicht. **Vom Pi (Debug 143 und 145 vom 16.11., 18:37 und 18:39 UTC):** Dort lief 23.104, nicht 23.105 -- dem Nutzer gesagt; der Update-Knopf lädt von `raw.githubusercontent.com`, das eine ersetzte Datei bis zu rund 5 Minuten in der alten Fassung ausliefert (Vorschlag U263: das Update nennt die Version des Archivs). Die Tageszeile kam am 16.11. um 00:02 UTC, die Sicherung von `staking.db` um 02:34 UTC. **Lehre aus dem Bau:** Wiederholt eine neue Funktion Zeilen einer alten wörtlich, verlieren bestehende Mutationen ihren eindeutigen Anker -- `werk/anker.py` nach jedem Patch laufen lassen. Eine neue Mechanik kann alte Mutationen verdecken (das Nachholen ersetzte den Abruf zu Tagesbeginn, zwei Mutationen blieben grün, bis eine Probe den Fall „letzter Versuch kurz vor Mitternacht“ prüfte); und der Selbsttest des Cockpits druckt erst am Ende -- eine Ausnahme in einer neuen Probe verschluckt alle Fehlschläge davor, neue Proben dort deshalb immer absturzsicher schreiben. Nicht geändert: das gespeicherte Urteil, die Regeln der ersten Prüfung, Kalender und Karte „Unstaking“; keine neue Datei, keine neue Debug-Nummer. Geprüft: `hl_staking.py` 54 von 54, `hl_staking_studie.py` 49 von 49, Cockpit 92 von 92, Cockpit-Selbsttest des Dashboards bestanden, Mutationen 568 von 568 rot, A7 98 von 98, Update-Probe 26 von 26 von 23.104 aus und 26 von 26 von 23.105 aus, auch auf Daten des Ausgangs, Browser-Probe der Karte mit neuen Wellen. **Nicht geprüft: der Lauf auf dem Pi** (Tabelle der Tage mit schnellem Abbau, Nachholen bei einem echten Ausfall, Karte auf dem Handy); ob und wann EIP-8061 das Hauptnetz erreicht. Beim Nutzer offen: 23.106 einspielen (enthält 23.105; Zip hochladen, 5 Minuten warten, „Update“, Kachel „Version“ vergleichen), dann Debug 147, 145 und 143; Debug 14 frisch; Debug 13 am Mi 18.11.; Entscheidung zu U240. Nächste neue Plan-Nummer U264, nächste freie Debug-Nummer 149 (für U244 vorgesehen).

**Nachtrag 17.11. 02:35 (Version 2026-09-23.107 · 8f12eb8648): Paket 23.107 -- Niveaus: Bilanz je Art (U244)** (UEBERGABE 3ηηηηηη; `KONZEPT_Niveaus.md` 11 und 12). Neues Modul `hl_niveaus.py`: Tragen Niveau-Arten (Swing, runde Zahl, 50- und 200-Tage-Linie, Bein-Schwelle) mehr als ihren Abstand -- werden sie öfter erreicht (Anziehung), schließt der Kurs danach seltener jenseits (Halten)? Vergleich gegen die Prüfniveaus des Ausblicks; Urteil nur für 7 Tage, **einmal** gerechnet im Rückblick des Ausblicks (Haken am Ende von `rueckblick()`, eigene Tabelle `au_niveaus`), gesperrt bei Abweichung von S3. Wer hier weiterbaut, muss wissen: (1) Die Regel ist vorab festgelegt; geändert wurde vor dem ersten Lauf nur die Spiegelprobe, vom Nutzer entschieden und im Konzept offengelegt -- eine weitere Änderung ist eine neue Fassung (`REGEL` im Modul), das alte Urteil bleibt abgelegt. (2) Der Abgleich mit S3 zählt wie S3 heute, samt dessen Eigenheit bei B1 (U264); wer S3 ändert, muss den Abgleich mitziehen. (3) Der Vorwärtsteil ist bis 52 Wochen Zählung; für sein Urteil fehlt das Erreichen der Prüfniveaus (U265). (4) Die Nachweisgrenze (4 bis 11 Punkte) stammt von synthetischen Märkten; `hl_niveaus.py --nachweisgrenze` wiederholt die Messung (je Markt rund eine Minute). Debug 149 (★ Bilanz), 150 (Selbsttest), 75 (Rückblick sofort).

**Nachtrag 17.11. 05:25 (Version 2026-09-23.108 · c1b9a1a1b3): Paket 23.108 -- Cockpit, Rest von Stufe C2 (U245)** (UEBERGABE 3θθθθθθ; `KONZEPT_Cockpit.md` 14). Vier gemessene Teile in `hl_cockpit.py`: Funding von Hyperliquid und Varianz des Taker-Flusses als Zeilen der Markt-Messwerte, Karte „Liquidationsdichte“, Betriebslampe (Pille im Kopf, Karte „Betrieb“). Wer hier weiterbaut, muss wissen: (1) Die Schwelle des API-Gewichts (93 % des harten Limits) ist die Warnschwelle des Wächters; ein Selbsttest liest sie aus `hl_watchdog.run_checks` -- wer dort ändert, ändert `API_HINWEIS` mit. Ebenso gebunden: die sechs Dienste an `install.py`, die Altersgrenze der Positionen und der Takt der Schnappschüsse an `hl_recorder.Settings`. (2) „Dienst läuft nicht“ wird erst nach 60 Sekunden zur Warnung (`_BETRIEB["aus_seit"]` im Prozess des Dashboards); Debug 143 wartet nicht. (3) Die Taker-Varianz kommt aus `hl_indikatoren.varianz_kompression` und teilt sich im Dashboard deren Zwischenspeicher mit der Prognose; die Funktion rechnet mit der Uhr des Rechners, nicht mit einem übergebenen Zeitpunkt. Ihr Zusammenhang mit Kaskaden ist im Projekt nicht geprüft -- deshalb ohne Lampe. (4) Das Skript der Seite trägt keine Positionswörter (Wortprobe); Beschriftungen wie „Long-Liquidationen darunter“ kommen vom Server. (5) Die Liquidationsdichte ist eine Untergrenze (Abdeckung des Open Interest, Positionen bis 60 Minuten alt). Debug 143 (★ Cockpit als Text), 144 (Selbsttest).

**Nachtrag 17.11. 15:05 (Version 2026-09-23.109 · 66fc7404a8): Paket 23.109 -- Berichtsplan mit Läufen nach dem Einspielen (U267) und Benachrichtigung (U268); Notbremse ergänzt fehlende Schlüsse (U266)** (UEBERGABE 3ιιιιιι). Wer hier weiterbaut, muss wissen: (1) **Jedes Paket bringt im `BERICHTSPLAN` (hl_viz.py) einen Eintrag `{"nach_update": "<Version>", "minuten": X, "laeufe": […]}` mit den Läufen, die es prüfen** -- so wünscht es der Nutzer seit dem 17.11.; er startet dann keine Debug-Nummern mehr von Hand. Der Selbsttest der Debug-Nummern weist einen Eintrag ab, dessen Paket neuer ist als `version.VERSION`; Läufe über 15 Minuten brauchen `"grenze_s"` (Debug 75 lief am 17.11. auf dem Pi 795 s). (2) Das Einspielen erkennt der Faden des Berichtsplans am Versionswechsel gegen `berichte/.stand.json` -- also erst, wenn das Dashboard mit dem neuen Code läuft. (3) Die Benachrichtigung sendet nur Zahl, Anlass und Debug-Nummern an ein ntfy-Thema; das Thema ist ein Geheimnis (`accesstokens.json` → `ntfy` → `thema`) und darf in keiner Antwort außer `POST /berichte/melden?aktion=einrichten|zeigen`, in keinem Bericht und in keinem Fehlertext stehen -- dafür gibt es Proben und Mutationen. Die Zustellung selbst ist in der Sandbox nicht prüfbar. (4) Notbremse: `kurse_nachtragen` (U250) gilt nur für einen neuen HIP-3-Handelsplatz, `schluesse_ergaenzen` (U266) für jeden eigenen Coin im Korb; XMR läuft auf dem Pi am Hauptmarkt. Die monatliche Eichung rechnet X aus `nb_kerze15`, nur Y aus den Minutenkerzen des Recorders. (5) Das Urteil der Niveau-Arten (U244/1) ist seit dem 17.11. festgehalten: nicht belegt. Debug 151 (★ Berichtsplan: Stand), 152 (Selbsttest).

**Nachtrag 17.11. 21:21 (Version 2026-09-23.110 · 4f6f20b81f): Paket 23.110 -- Cockpit: Karte „Durchschnittslinien“ (U269)** (UEBERGABE 3κκκκκκ). Wer hier weiterbaut, muss wissen: (1) Das Cockpit rechnet die 50- und die 200-Tage-Linie nicht selbst -- `linien_lesen` nimmt sie aus `hl_chartbild.tagesteil` (einfacher Durchschnitt der Tagesschlüsse vor 00:00 UTC heute, ohne den laufenden Tag; Zwischenspeicher 10 Minuten). Wer die Rechnung ändert, ändert sie im Chartbild -- dann ändern sich auch die Niveaus des Ausblicks und die Grundlage der Prüfungen U141 und U244. (2) Die Erreich-Wahrscheinlichkeit der Karte ist die des Ausblicks für das Niveau mit der Art-Kennung `ma50_` bzw. `ma200` (`hl_ausblick.niveaus_aus_chartbild`); der Ausblick rechnet alle 6 Stunden, sein Stand der Linie kann einen Tagesschritt alt sein -- die Karte nennt ihn dann. (3) Alle Texte der Karte entstehen in `linien_bauen` (Python); `ckLinien` im Skript setzt sie nur. (4) Das Urteil der Niveau-Arten liest das Cockpit einmal je Anfrage (`niveaus_urteil_lesen` in `gemeinsam_lesen`); es steht im Beleg der „Levels“ und der neuen Karte -- kein fester Satz mehr. (5) Die Linien sind Messwerte ohne Lampe: U141 B2 und U244/1 belegen keine Wirkung. Eintrag im Berichtsplan `p110-nach-update` (Debug 143, 71, 73, 149). Keine neue Debug-Nummer; nächste freie 153, nächste Plan-Nummer U270.

**Nachtrag 18.11. 22:40 (Version 2026-09-23.111 · dc74aa5a40): Paket 23.111 -- Cockpit: Durchschnittslinien mit beiden Rechnungen (U270)** (UEBERGABE 3λλλλλλ). Wer hier weiterbaut, muss wissen: **Im Dashboard gibt es zwei Rechnungen der 50- und der 200-Tage-Linie.** (1) `hl_viz.load_mas` -- der heutige Tag zählt mit dem jetzigen Kurs mit; Kachel „MA 200 Tage“, Linien im Live-Chart, Konfluenz. (2) `hl_chartbild.trendlage` -- nur volle Tage; Chartbild, Niveaus des Ausblicks, „Levels“, Prüfungen U141 und U244. Die Karte „Durchschnittslinien“ zeigt seit 23.111 beide: groß (1), klein (2). Sie rechnet (1) selbst aus der Reihe des Tagesteils (`ma50_rest`, `ma200_rest` + frischer Kurs), weil hl_cockpit hl_viz nicht laden kann; die Vertragsprobe „Vertrag mit dem Live-Chart“ in `hl_viz.py --selbsttest-cockpit` hält die Gleichheit mit `load_mas` fest -- wer `load_mas` ändert, sieht sie rot. Vor einer neuen Anzeige im Cockpit im ganzen Projekt suchen, ob es die Größe schon gibt (bei 23.110 versäumt). Eintrag im Berichtsplan `p111-nach-update` (Debug 143, 105, 71; 105 lädt die Tageskerzen nach und fragt die Quellen im Netz ab -- der erste Lauf im Plan, der nicht nur liest). Offen notiert: U271 (jüngster Tagesschluss nach 00:00 UTC bis zu 6 Stunden vorläufig). Nächste Debug-Nummer 153, nächste Plan-Nummer U272.

**Nachtrag 19.11. 03:55 (Version 2026-09-23.112 · 57abd71bd4): Paket 23.112 -- zweite Bilanz des Labors mit den Abständen der Börse (U252); Größe der ausgelassenen Positionen gemessen (U272)** (UEBERGABE 3μμμμμμ). Wer hier weiterbaut, muss wissen: (1) **Das Labor hat seit 23.112 zwei Bilanzen im Bericht (Debug 13), aber nur eine, mit der gerechnet wird.** Kopfzeile, Stufen, „Glück“, Engine und Dashboard nutzen weiter die gebuchte Bilanz mit dem Abstand-Modell (`taker_preis`). `zweite_bilanz` rechnet nur nach: Trades ganz im Messzeitraum, je Markt-Seite der Impact-Preis der Börse (`impact_bars`), „niedrig“ und „hoch“ über die Größe der gemeinsamen Order. Wer die Arten der Ausführung ändert: Markt-Seiten erkennt die Rechnung an „(Taker)“ im Namen der Art. (2) **`n_stale_dropped` und die Cockpit-Zeile „… % der bekannten Positionen … nicht abgefragt“ zählen Positionen im Speicher des Recorders -- der Zähler beginnt nach jedem Neustart bei 0 und wächst mit der Laufzeit** (seit 23.86 gewollt). Über die Größe sagt er nichts; die steht seit 23.112 im Meta-Wert `ausgelassen` und in Debug 85. In Debug 85 zeigen „Alter Med.“ und „Alter 90 %“ seit 23.86 nicht mehr die Frische des Standes. (3) **Der Berichtsplan darf je Paket mehrere Einträge der Art „nach dem Einspielen“ tragen** (hier 10 Minuten und 1.440 Minuten; mehr als 1.440 lässt die Planprüfung nicht zu). (4) **Die Sicherung braucht während eines Laufs Platz für drei Kopien der Hauptdatenbank**; eine Vorwarnung fehlt (U273). Der Nutzer schließt ein größeres Laufwerk an (Stand 18.11.: auf der SD-Karte reicht es bis um den 1.12.). (5) Vor einer neuen Plan-Nummer im UPDATE_PLAN suchen, ob es den Punkt schon gibt -- die zweite Bilanz stand seit dem 12.11. als U252 im Plan, ich hatte sie zuerst U272 genannt. (6) **Gesamt-Selbsttest und Mutationsläufe nie zwischen 00:00 und 00:30 UTC (01:00–01:30 MEZ)**: Der Cockpit-Selbsttest schlägt dort fehl, weil `hl_ausblick.chartbild_daten` das Chartbild mit der echten Uhr rechnet und die Probe mit `jetzt` vom Vortag (U275, offen) -- jede Mutation mit dem Cockpit-Selbsttest als Prüfung wäre in dem Fenster fälschlich „rot“. Nächste Debug-Nummer 153, nächste Plan-Nummer U276.

**Nachtrag 20.11. 11:38 (Version 2026-09-23.113 · 2215dad4ba): Paket 23.113 -- Hinweis erst nach allen Läufen (U276), Cockpit-Selbsttest um Mitternacht UTC (U275), Cockpit-Zeile nach Größe (U272 Teil 2), Erstlauf der Optionen (U278)** (UEBERGABE 3νννννν). Wer hier weiterbaut, muss wissen: (1) **Der Berichtsplan arbeitet in Runden.** Alle zugleich fälligen Einträge sind eine Runde; ein Lauf in mehreren Einträgen startet einmal; die Meldung kommt einmal am Ende. `_BER["runde"]` trägt den Fortschritt, `_BER["rest"]` die fertigen Einträge einer unterbrochenen Runde. Der Hinweis im Kopf der Seite hängt an `hinweis` aus `/berichte` (`hl_berichte.hinweis_stand`), nicht mehr allein an der Zahl der Berichte. (2) **`hl_ausblick.chartbild_daten` nimmt `jetzt`.** Wer eine Rechnung für einen vergangenen Zeitpunkt nachstellt, muss `jetzt` durchreichen; `hl_extreme_seit` tut das noch nicht (U281). Die Sperrzeit 00:00–00:30 UTC für Selbsttest und Mutationen entfällt. (3) **Die Karte „Liquidationsdichte“ liest zwei Dinge neu:** den Meta-Wert `ausgelassen` (nur wenn seine Zeit die des Schnappschusses ist) und `snapshot_meta.uptime`. `LIQ_ANLAUF_S` muss gleich `hl_watchdog.ANLAUF_S` bleiben (Vertrag im Selbsttest). In der ersten Stunde nach einem Neustart ist `ausgelassen` je Coin 0 -- die Zeile nennt dann „0 BTC-Positionen …“ (richtig, holprig; U282). (4) **Debugnummern können reserviert sein** (`DEBUG_RESERVIERT`): 153 gehört der Vorprüfung des 24-Monats-Charts (U277). Wer den Lauf baut, nimmt den Schlüssel `langfrist_pruefung` und streicht den Eintrag in `DEBUG_RESERVIERT` -- der Selbsttest verlangt beides. (5) **`update.py` übernimmt aus dem Zip nur neue `.py`- und `.json`-Dateien.** Ein neues Dokument kommt erst mit dem übernächsten Update auf den Pi; eine Probe, die ein neues Dokument liest, muss sein Fehlen dulden (so K2 in `hl_optionen.py`). (6) **Der 24-Monats-Chart ist vorab festgelegt** (`KONZEPT_Langfrist.md`): An den Regeln der Abschnitte 3 bis 8 und an der Zählweise Z1 bis Z6 wird nach dem Blick auf Zahlen nichts geändert; Nachträge kommen mit Datum in Abschnitt 15. Der Prototyp der Vorprüfung liegt im Arbeitsordner (`prog24/lf_proto.py`), nicht im Paket. (7) **`hl_optionen.py` speichert nichts und ist ein Erstlauf**, kein Dienst; der Aufbau der Cboe-Antwort ist nicht dokumentiert -- erst den Bericht von Debug 154 lesen, dann den täglichen Abruf bauen. Nächste Debug-Nummer 155 (153 reserviert), nächste Plan-Nummer U283.

**Nachtrag 20.11. 18:15 (Version 2026-09-23.114 · 7282342906): Paket 23.114 -- Stabilität: Kindstart ohne `preexec_fn` (U283), Selbstheilung nach 3 Minuten (U286), Probe der Selbstheilung (U289, Debug 155)** (UEBERGABE 3ξξξξξξ). Wer hier weiterbaut, muss wissen: (1) **Kein `preexec_fn`, kein `os.fork` im Paket** (Vertrag L16 im Selbsttest der Selbstheilung). Das Dashboard hat viele Fäden und lädt numpy mit OpenBLAS; ein `fork()` kann es einfrieren (19.11.2026). Wer einem Kind etwas mitgeben will, tut es über die Umgebung -- so `HL_NICE` (`kind_umgebung`, `nice_aus_umgebung` in `hl_ausblick.py` und `hl_volatil.py`). (2) **Die Wächterzeit steht an zwei Stellen und muss gleich sein:** `WatchdogSec=180` in `install.DASH_UNIT` und `WAECHTER_S` in `hl_viz.py` (L11 prüft es). Takt, Antwortzeit und Abzugszeit leitet das Dashboard aus `WATCHDOG_USEC` ab (`_lebt_zeiten`, `abzug_zeit`). (3) **Lebenszeichen sendet nach dem Start nur der Faden „lebenszeichen“, und nur nach einer Antwort der eigenen Seite.** Der Faden „anlauf“ überbrückt den Start (bis zur ersten Antwort, längstens 10 Minuten). Wer `serve()` umbaut und vor dem Binden des Servers länger als 3 Minuten braucht, ohne dass „anlauf“ läuft, baut eine Neustart-Schleife. (4) **`haenger_vorher` liest die Hänger-Datei vor dem eigenen Start-Eintrag**; Meldung (`_neustart_melden`) und Bericht (`_neustart_bericht`, Debug 20) laufen im Faden des Berichtsplans. (5) **Die Marke „PROBE-HÄNGER“** schreibt `hl_viz.py`, `check_system.py` liest sie (Vertrag in L19). (6) **Debug 155 hält das Dashboard wirklich an.** Der Server nimmt die Anfrage nur vom Pi selbst; in keinem Plan aufrufen. (7) **Die Seite lädt neu, wenn sich die Prozessnummer des Dashboards ändert** (`lebtPruefen`); während `updTimer` läuft, tut sie nichts. (8) **Der Mutationsläufer erkennt jetzt auch „ROT“** (Selbsttest der Volatilität). Nächste Debug-Nummer 156 (153 reserviert), nächste Plan-Nummer U292.

**Nachtrag 21.11. 02:35 (Version 2026-09-23.115 · 5e7ac9113f): Paket 23.115 -- Vorprüfung zum 24-Monats-Chart (U277, Debug 153) und Messung der Recorder-Runden (Vorarbeit zu U287, Debug 157)** (UEBERGABE 3οοοοοο). Wer hier weiterbaut, muss wissen: (1) **Die Regeln der Vorprüfung sind vorab festgelegt (`KONZEPT_Langfrist.md` 3 bis 8, Regelversion 1) und werden nicht nach dem Blick auf Zahlen geändert.** Jede Änderung ist eine neue Regelversion mit Datum und Grund in Abschnitt 15; `REGELVERSION` in `hl_langfrist.py` anheben -- das alte Urteil wandert dann ins Archiv (`langfrist:archiv`). (2) **Das Urteil liegt in `makro.db`** (`mk_meta`, `langfrist:urteil`) und wird vom ersten Lauf mit vollständigen Daten abgelegt; `speichern` überschreibt ein Urteil derselben Regelversion nie. Der abgelegte Hauptfächer gilt für alles Weitere (`auswerten(L, haupt_fest)`). (3) **Der Chart (U279) muss `Lauf.fan(o)` rufen** -- dieselbe Funktion, deren Ränder die Rückrechnung wertet (Probe P9). Kein eigener Rechenweg im Chart. (4) **Die Ränder der Mischung liegen bei 10,2 und 89,8 %** (Mittelpunktregel von `hl_ausblick.gew_quantile` auf 199 Quantilen). Das ist Teil der Regelversion 1; wer `gew_quantile` ändert, ändert die Vorprüfung. (5) **`hl_langfrist.py` importiert `hl_makro`, `hl_makro_signal` und `hl_ausblick`** und nutzt deren Bausteine unverändert (`powerlaw_monatlich`, `Referenz`, `ar1`, `y_prognose`, `_fenster_daten`, `gew_quantile`); die Probe P2 hält die Gleichheit mit U126 fest. (6) **Der Messfaden der Recorder-Runden läuft im Wächter-Dienst** (`hl_watchdog.messfaden_starten` -> `hl_rtakt.starten`), liest nur (`mode=ro`), gibt nichts aus und schreibt `recorder_takt.json` neben die Hauptdatenbank. Er hängt an drei Schlüsseln von `meta`, die `hl_recorder.py` schreibt: `recorder_alive` (am Ende jeder Schreibrunde), `started`, `jobs`. Wer diese im Recorder ändert, ändert die Messung. (7) **Proben mit echten Fäden warten auf Bedingungen, nicht auf die Uhr** (`warte` im Selbsttest von `hl_rtakt.py`) -- eine Probe mit festen Wartezeiten fiel im Vorlauf unter Last. (8) **`VERSION_MODUL` = das Paket, das die Datei zuletzt geändert hat.** Nächste Debug-Nummer 158 (156 reserviert), nächste Plan-Nummer U293.

**Nachtrag 21.11. 15:12 (Version 2026-09-23.116 · 16d7b73740): Paket 23.116 -- Chart „24 Monate“ (U279, Debug 156) mit Monatsfassungen und Vorwärtsbilanz; Debug 157 berichtigt (U294)** (UEBERGABE 3ππππππ). Wer hier weiterbaut, muss wissen: (1) **Das Urteil der Vorprüfung ist gefallen (21.11.2026, Pi): Hauptfächer H.** Es liegt in `makro.db` und bleibt (Regel 7.5). (2) **Der Chart rechnet nichts Eigenes:** `hl_langfrist.chart_stand` ruft `Lauf.fan` am letzten Kurstag und liefert Seite (`/makro?tab=langfrist`) und Debug 156 dieselbe Antwort mit fertigen Zahlen und Sätzen; `mkLangfrist` in `hl_makro_js.py` zeichnet nur. Die Probe K2b prüft, dass das Skript nur Felder liest, die die Antwort trägt -- wer ein Feld umbenennt, sieht es dort. (3) **Ohne abgelegtes Urteil „bauen“ der geltenden Regelversion gibt es keinen Chart und keine Fassung.** Wer `REGELVERSION` anhebt, braucht zuerst einen Lauf von Debug 153. (4) **Monatsfassungen sind unveränderlich** (`makro.db`, Tabelle `lf_fassung`, `INSERT OR IGNORE`); Starttag unter `mk_meta` `langfrist:fassung_start`. Nichts wird rückwirkend erzeugt. Die Regeln V1 bis V7 stehen in `KONZEPT_Langfrist.md` 10a und wurden vor der ersten Fassung festgelegt; die Regel, wann die Bilanz den Fächer infrage stellt, fehlt noch (U295, vor dem 01.03.2027). (5) **Der Makro-Takt ruft `hl_langfrist.takt_schritt`** nach jeder neuen Rechnung (in `try`/`except`); die Rückrechnung läuft dabei nur, wenn eine Fassung fällig ist. `hl_langfrist` importiert `hl_makro` -- der Aufruf in `hl_makro._schleife` importiert deshalb erst dort. (6) **Die Rückrechnung für die Seite läuft je Datenstand einmal** (`lauf_aus`, Schlüssel aus den Reihen des Datensatzes); Urteil, Fassungen, Ausblick und Termine werden je Anfrage gelesen, `/makro` hält das Dashboard 60 s vor. (7) **Der generische Makro-Chart hat neue Felder** (`xFest`, `kurz`, `lo`, `links`, `dy`, `halo`, `xmarken`, `xTicks`, `endenMax`); ohne sie zeichnet er wie zuvor. (8) **Farben eines Charts mit sich kreuzenden Linien mit allen Paaren prüfen** (`validate_palette.js … --pairs all`): Aus der Reihe des Makro-Charts tragen sich so höchstens drei Töne; Blau neben Violett und Orange neben Gelbbraun fallen durch. (9) **Debug 157:** Ein Abstand zweier Schnappschüsse unter der Pause ist keine Runde (der Recorder schreibt beim Beenden einen letzten Stand). Nächste Debug-Nummer 158 (für U293 vorgesehen, nicht vergeben), nächste Plan-Nummer U296.

**Nachtrag 22.11. 01:14 (Version 2026-09-23.117 · 63b5fec9eb): Paket 23.117 -- Legende im Reiter „24 Monate“ schaltbar (U297); Debug 157 zählt einen Lauf mit Zwischenständen einmal (U296)** (UEBERGABE 3ρρρρρρ). Wer hier weiterbaut, muss wissen: (1) **Eine Reihe des Makro-Charts wird schaltbar, indem sie `schalt` trägt** (Kennung aus a–z und 0–9): `mkFigur` macht aus ihrem Eintrag einen Knopf, `mkZeichne` lässt sie aus Achse, Bild und Fadenkreuz, wenn `MK.aus` sie nennt; die Tabellen zeigen sie weiter. (2) **Verhalten im Browser prüft die Klickprobe des Baus (`vis/klick117.py`)** -- auch als Befehl der Mutationsläufe (Kürzel KL): Mutationen am Skript der Seite müssen dort rot werden, nicht nur an einem Vertrag über den Wortlaut. Sie braucht die frisch gebaute Demo-Welt. (3) **Der Recorder meldet bei manchen Aufgaben Zwischenstände** (`note_job` mit wachsender `dauer`): Wer Meldungen zählt, muss am Beginn (`last − dauer`) erkennen, was zusammengehört (`hl_rtakt._jobs`). (4) **Eine Legende auf dem Handy verträgt keine breiteren Einträge:** Der erste Entwurf mit Rahmen brach sie in eine dritte Zeile. (5) **Projekt-Dokumente über rund 40 kB lassen sich nicht in einem Stück lesen und deshalb nicht aus einer Datei schreiben** -- teilen. Nächste Debug-Nummer 158, nächste Plan-Nummer U298.

**Nachtrag 22.11. 07:10 (Version 2026-09-23.118 · 693338e9bb): Paket 23.118 -- Optionen von Deribit im 24-Monats-Chart (Markt-Schicht, Teil 1: U280, U292)** (UEBERGABE 3σσσσσσ). Wer hier weiterbaut, muss wissen: (1) **Die Schicht ist ein eigenes Modul (`hl_marktschicht.py`)**; `hl_optionen.py` bleibt der Erstlauf, der nichts speichert (seine Probe K3). (2) **Der Makro-Takt ruft `takt_schritt` in jeder Runde** -- der Abruf geschieht nur, wenn er fällig ist (ein Lesen der Datenbank sonst). Der Tag eines Abrufs ist der in New York, nicht der in UTC. (3) **Die Ränder kommen aus Differenzen benachbarter Preise** -- das verstärkt Rauschen. Zusammengelegte Paare gelten als ein Paar über die ganze Strecke; die Zahl der Zusammenlegungen steht im Bericht und ist das Warnzeichen. Was der Rechenweg auf echten Ketten leistet, zeigt erst der Pi. (4) **Die Schicht geht nicht in den Fächer ein** (Probe C11) und nicht in die Monatsfassungen. (5) **Eine Reihe des Makro-Charts kann „Spannen“ tragen** (`spannen:[{tag, lo, hi, q1, q3, m, zeilen}]`): Zeichen je Tag, mit Legende, Schalter und Fadenkreuz. (6) **Eine vierte Farbe trägt der Chart nicht** (Paarprüfung) -- Neues unterscheidet die Form. (7) **Die Antwort an die Seite muss JSON-stabil sein:** keine Zahlen als Schlüssel. Nächste Debug-Nummer 158, nächste Plan-Nummer U300.

**Nachtrag 22.11. 19:23 (Version 2026-09-23.119 · 73549014ea): Paket 23.119 -- Fächer bis 90 Tage mit Wurzel-Verlauf (U303); Diagnose der Optionen und Debug 158 (U302); Debug 73 vollständig (U300, U301)** (UEBERGABE 3ττττττ). Wer hier weiterbaut, muss wissen: (1) **Die Reihen des Fächers für die Seite laufen über `hl_langfrist.faecher_raster`** -- bis zur ersten Stützstelle Wurzel-Verlauf um die gerade Mitte, danach gerade. Die Stützstellen (Tabelle, Monatsfassungen, Vorwärtsbilanz) kennen das nicht; wer die Verbindung ändert, ändert nur das Bild. (2) **`lf_option` hat eine Spalte mehr (`diag`, JSON)**; der Schritt des Takts legt sie in einer Tabelle aus 23.118 einmal an; Zeilen von vorher tragen keine Diagnose. Der Code von 23.118 liest die Tabelle weiter (er nennt seine Spalten beim Namen). (3) **Die Diagnose ändert keinen Rand und keine Zeichen** -- sie steht nur im Bericht; ein Fehler in ihr wird vermerkt statt geworfen (der Abruf und die Zeichen hängen nicht an ihr, Probe M22). Eine Regel, die Zeichen wegen einer Markierung weglässt, gibt es nicht; sie wäre vorab im Konzept festzulegen (frühestens nach 14 gespeicherten Tagen). (4) **Es gibt genau eine Stelle, die bei Deribit abruft (`hl_marktschicht.holen`)** -- Tagesabruf und Debug 158 nutzen sie; Debug 158 öffnet keine Datenbank (Probe K2). (5) **Die zweite Gegenprobe hängt am Terminkurs aus der Parität** (die Seite der Schwankung wechselt dort). (6) **Der Text von Debug 73 rechnet den nächsten Rückblick mit `rueckblick_naechster`** -- dieselbe Regel wie `rueckblick_faellig`; wer die eine ändert, ändert die andere. Nächste Debug-Nummer 159, nächste Plan-Nummer U304.

**Nachtrag 27.11. 21:56 (Version 2026-09-23.128 · 9937ae33ec): Paket 23.128 -- Märkte-Modell (U322), dazu U317, U319, U320 und U321** (UEBERGABE 3δδδδδδδ). Wer hier weiterbaut, muss wissen: (1) **Das Modell rechnet `hl_marktschicht.pm_modell`** im Chart-Teil und im Bericht aus denselben Zeilen wie die Punkte (PM21); `hl_langfrist.pm_modell_stand` macht daraus nur Reihen und Zeilen -- eine zweite Rechnung gibt es nicht. Die Stützstellen stehen doppelt (`MS.PM_MOD_H` und `HORIZONTE`; Probe C13). (2) **Die Linie hat zwei Stücke** (durchgezogen, gestrichelt) mit `ohneLeg`/`ohneTab` und eine Reihe `nurTip` für die Ansicht „Tabelle“; das Fadenkreuz kommt aus `tipExtra`. Wer eine Reihe in zwei Stücken zeichnet, macht es genauso. (3) **Endbeschriftungen** fallen nur weg, wenn sie sich auch waagrecht überdecken; der Chart „24 Monate“ erlaubt sechs. (4) **Buch-Tiefe:** `tiefe_naechste(jetzt, zuletzt)` -- nach Überlauf sofort, zur laufenden Minute. (5) **Radar:** Zahlen, die gegen eine Spanne geprüft werden, über `_de_grenze`. Nächste Debug-Nummer 170, nächste Plan-Nummer U323.

**Nachtrag 27.11. 02:00 (Version 2026-09-23.127 · 43bcee649d): Paket 23.127 -- Abruf nach Bekanntgabe (U316), dazu U314 und U315** (UEBERGABE 3γγγγγγγ). Wer hier weiterbaut, muss wissen: (1) **Uhrzeiten je FRED-Reihe stehen in `hl_makro.TERMIN_UHRZEIT`** (New York); eine neue FRED-Reihe gehört entweder dorthin (mit Beleg der Uhrzeit), nach `TERMIN_OHNE` oder ist die Zielspanne (`TERMIN_NACH_FED`) -- der Selbsttest T2 verlangt, dass jede Reihe aus `FRED` in genau einer der drei steht. (2) **„Zahl da“ heißt: die jüngste Beobachtung wurde nach der Uhrzeit geschrieben** (`mk_reihe.abgerufen`); deshalb schreibt der FRED-Abruf mit der Uhr des Takts (`schreiben(..., int(self.uhr()))`). (3) **Termine der Fed-Entscheide** = Vereinigung aus `hl_volatil.FOMC` und Kalshi (`fed_tage_alle`); die Liste bleibt Gegenprobe und muss nachgetragen werden, wenn die Fed Termine nennt (U306). (4) **Erklärung der Fed**: Titel endet auf „FOMC statement“, Satz „decided to … the target range for the federal funds rate … A to B percent“; ändert die Fed das Format, steht in Debug 168 „NICHT GELESEN“, der Chart wartet dann auf FRED. (5) **Buch-Tiefe**: jede Runde 20 s nach einer vollen Minute, Zeile zur Minute der Runde (`tiefe_minute`, `tiefe_naechste`). (6) **Die Schicht nach Termin darf den Takt nie anhalten:** In `Makro.runde` läuft sie über `Makro._sicher` -- eine Ausnahme wird vermerkt (`mk_meta` „fehler:termin“, Debug 168, Makro-Stand), die Runde läuft weiter wie ohne sie; neuer Code dort gehört ebenso abgesichert (Probe T18). Nächste Debug-Nummer 170, nächste Plan-Nummer U318.

**Nachtrag 26.11. 02:23 (Version 2026-09-23.126 · 9d9f32f110): Paket 23.126 -- Hänger-Schutz des Recorders (U287)** (UEBERGABE 3βββββββ). Wer hier weiterbaut, muss wissen: (1) **Der Recorder hat jetzt einen Wächter von systemd** (Unit: `WatchdogSec=300`, `NotifyAccess=main`). Jede Änderung, die die Schreibrunde (`run_flush`) länger als 5 Minuten aufhält -- eine große Migration beim Start ausgenommen, dafür meldet der Faden „anlauf“ bis zu 10 Minuten --, führt zum Abbruch. Lange Arbeiten gehören in einen Faden (`asyncio.to_thread`), nie in die Ereignisschleife. (2) **`lebenszeichen_runde()` steht direkt nach dem Commit in `run_flush`**; davor wäre das Lebenszeichen nicht geschrieben. (3) **Aktiv nur im Dienst** (`rec_wd_sekunden`: `WATCHDOG_USEC`, `NOTIFY_SOCKET`, `WATCHDOG_PID` = eigene PID); Kinder des Dashboards erben dessen Umgebung und melden nichts. (4) **Hänger-Datei** `logs/recorder_haenger.log` (Ordner wie beim Dashboard: `HL_LOGDIR`); Kopfzeile „== Zeit Recorder-Start, PID …“ -- `check_system.haenger_lesen` und `hl_recorder.rec_neustarts` erkennen Starts daran. Keine weiteren Zeilen „== …“ hineinschreiben: Debug 20 zählt sie sonst als Abzug. (5) **Meldung nach einem Neustart** schickt das Dashboard (`hl_viz._rec_neustart` im Faden des Berichtsplans), gemerkt in `berichte/recorder_neustart.json`. Nächste Debug-Nummer 168, nächste Plan-Nummer U314.

**Nachtrag 25.11. 17:56 (Version 2026-09-23.125 · 7a7c40be21): Paket 23.125 -- Tiefe des Buchs bis −1 % (U311), dazu U312, U313 und der Rest von U310** (UEBERGABE 3ααααααα). Wer hier weiterbaut, muss wissen: (1) **Die Tiefe misst die Aufgabe „Buch-Tiefe“ des Recorders** (`run_tiefe`, `tiefe_abfragen`, `tiefe_rechnen`; Konstanten `TIEFE_*`): je Minute und Coin eine REST-Abfrage `l2Book` mit `nSigFigs` (Gewicht 2, Quelle „Tiefe“ mit Rang 1), die Zeile geht über `flush_round` in `book_tiefe`; `voll` hat zwei Bits (1 Gebote, 2 Forderungen vollständig bis ±1 %). Die Abos des Buchs bleiben, wie sie sind (`book_summary` mit `bid_100` wird weiter geschrieben, Debug 165 vergleicht damit). (2) **Das Radar liest nur vollständige Zeilen** (`tiefe_lesen`, `tiefen_stunden`: `(voll & 1) = 1 AND bid_1 > 0`). Der eigene Verlauf von A5 zählt erst ab `rd_meta` „tiefe_ab“, gesetzt beim ersten Ablegen zur vollen Stunde und danach nie wieder -- ändert sich der Nenner noch einmal, braucht es eine neue Marke. (3) **Debug 165 öffnet `hl_liq.db` nur lesend** (`tiefe_text_datei`, `mode=ro`); nicht über `db_connect`, das Schema und Spalten anlegt. (4) **U312:** `rd_meta` „takt_voll“ hält den Schritt zur vollen Stunde fest (alle Coins), `takt_voll_satz` nennt ihn in Debug 160, wenn er nicht selbst der letzte ist. (5) **U313:** `hl_berichte.update_erkennen` setzt nur Einträge des neuen Pakets neu an; offene Einträge früherer Pakete behalten ihren Termin, frühestens `NACH_UPDATE_MINUTEN` nach dem Einspielen. (6) **U310:** `_umbrochen` und `_satz` halten „6 %“ mit dem Zeichen U+E000 zusammen; in Abschnitt 5 von Debug 159 stehen die Ausgänge in einer eigenen Zeile; `pm_weit_mitte` liefert die Mitte eines weiten Kurses nur zum Zeigen. Nächste Debug-Nummer 167, nächste Plan-Nummer U314.

**Nachtrag 25.11. 06:20 (Version 2026-09-23.124 · 985a33966d): Paket 23.124 -- Risikoradar: Aufschlag für belegte Zeichen (Regel A), die 48-Stunden-Zahl groß (U309 Teil 1, U310)** (UEBERGABE 3ωωωωωω). Wer hier weiterbaut, muss wissen: (1) **Die große Zahl der Karte ist `LEIT` in `hl_radar.py`** (seit 23.124 „e2“); `REIHE` legt die Reihenfolge in Karte und Berichten fest, `alle_stufen` zeigt die große Zahl. (2) **Regel A ist eine dritte Prüfung der 48-Stunden-Zahl auf denselben Daten** (Konzept 14.4, A1–A8). Sie hängt an der Nachkalibrierung: `auf_auswerten` rechnet nur, wenn `anzeige` „kal“ ist, und setzt „auf“, wenn G2a besteht, die Zahl besser trifft (`auf_besser_ok`) und für den laufenden Monat ein Faktor vorliegt. `kal_fuer` gibt die Nachkalibrierung bei „kal“ und „auf“ heraus; `auf_fuer` den Aufschlag nur bei „auf“. Kein weiterer Versuch auf diesen Daten. (3) **Zustände und Faktoren rechnet `hl_radar_regeln.py`** (`auf_zustand`, `auf_faktoren`, `auf_daten`, `auf_stand`) aus denselben Tagesreihen wie das Urteil; der Faktor eines Monatsersten M nimmt nur Tage d mit d + 2 < M (auch die Zehntel der Schwankung nur aus ihnen). Der Ursprung um 00:00 UTC des Tages T nimmt den Zustand von T − 1. (4) **Der Takt holt den Stand der Zeichen einmal am Tag** (`zeichen_pflegen`, `rd_meta` „zeichen“; nach einem Fehler frühestens nach einer Stunde); älter als zwei Tage gilt „unbekannt“, dann bleibt die Zahl ohne Aufschlag. Der Rückblick rechnet neu, wenn ein neueres Urteil der Regeln abgelegt ist. (5) **Die Messung 14.6 ist schwach:** Selbst Zeichen der Stärke, die Debug 163 zeigte, bestehen G2a mit „trifft besser“ in den erfundenen Reihen nur in 18,5 % bis 30,7 % der Fälle; `auf_nachweis` rechnet sie nach (rund 11 Minuten auf zwei Kernen), die Zahlen stehen als `AUF_NACHWEIS` im Modul und in 14.6. „Nicht bestätigt“ heißt dort „nicht nachweisbar“. (6) **Plan:** Ein Eintrag „einen Tag später“ mit demselben Lauf wie ein offener Eintrag eines früheren Pakets käme zur selben Minute -- darum hat 23.124 keinen eigenen. Nächste Debug-Nummer 165, nächste Plan-Nummer U313.

**Nachtrag 24.11. 17:32 (Version 2026-09-23.123 · 1e451361cd): Paket 23.123 -- Risikoradar: Prüfung der Regeln R1 bis R7 (Debug 163, 164), Nachkalibrierung beider Zahlen (Regel K), Berichtigung von Markttiefe und Liquidations-Nähe (U308)** (UEBERGABE 3ψψψψψψ). Wer hier weiterbaut, muss wissen: (1) **`bid_100` ist nicht die Tiefe bis −1 %.** `hl_recorder.on_l2book` kürzt das Buch auf 10 Preisstufen je Seite; alle Tiefen-Spalten (`bid_10` bis `bid_100`) sind Summen dieser Stufen, soweit sie in die Spanne fallen. Wer eine Tiefe braucht, muss erst die Aufzeichnung ändern (U311). Gefunden habe ich es an den Zahlen des Pi, nicht beim Bau -- eine Probe, die nur die Spalte prüft, prüft nicht, was in ihr steht. (2) **Regel K ist eine zweite Prüfung auf denselben Daten** (`KONZEPT_Risikoradar.md` 13.2, K6). Kein dritter Versuch: Fällt G7k durch, bleibt die 7-Tage-Zahl matt. Die Anpassung ist kausal (je Monatserstem aus Ursprüngen mit abgelaufener Frist); `kal_fuer` gibt sie nur heraus, wenn `anzeige` = „kal“ ist, das Urteil besteht und a und b des laufenden Monats vorliegen. Der Rückblick hängt an `VERSION_MODUL` und am Monat -- eine neue Version des Moduls lässt ihn neu rechnen. **Der Kurs-Rechner zeigt weiter die Rohzahl** (`hl_ausblick.erreichen_aus_lauf`); wer das ändert, ändert eine zweite Anzeige. (3) **Das Urteil der Regeln wird einmal gefällt und abgelegt** (`rd_meta` „regeln“, `FASSUNG` in `hl_radar_regeln.py` = `REGELN_FASSUNG` in `hl_radar.py`). Wer eine Regel ändert, erhöht beide Fassungen -- und legt die Änderung vorher im Konzept fest; ein zweites Urteil auf denselben Daten ist kein neuer Beleg. (4) **R7 ist nicht unabhängig von R1 und R5** (der Druck-Index enthält Kontenquote und Open Interest; auf erfundenen Märkten gemessen). (5) **„Nicht belegt“ heißt bei seltenen Zeichen oft „nicht nachweisbar“** -- die Tabelle der Nachweisgrenze steht in Debug 163 und im Konzept 13.5; sie ist auf erfundenen Märkten gemessen (`nachweis()` in der Probe, rund 23 Minuten auf zwei Kernen), die Zahlen stehen als `NACHWEIS_MESSUNG` im Modul. (6) **Eine Probe auf erfundenen Märkten darf nicht „nichts belegt“ verlangen** -- bei 5 % je Familie ist unter zwölf Familien oft eine. (7) **Hintergrundläufe sterben in dieser Arbeitsumgebung, während eine Auswahl zum Anklicken offen ist** -- lange Läufe erst nach der Antwort starten oder danach prüfen und neu starten. (8) **Plan:** Offene Einträge früherer Pakete setzt jedes Einspielen neu an; zwei Einträge mit demselben Lauf und derselben Frist kämen dann zur selben Minute (darum `p123-stand-1d` mit einem Tag statt zwölf Stunden). (9) Der Stand trägt seine Rechenzeit je Abschnitt (`zeit`), der Takt die Dauer seines Schritts -- vor einem Umbau zur Beschleunigung erst Debug 160 vom Pi lesen (U312). Nächste Debug-Nummer 165, nächste Plan-Nummer U313.

**Nachtrag 24.11. 03:31 (Version 2026-09-23.122 · 6a9fd807f8): Paket 23.122 -- Risikoradar, Stufe 1: Risiko eines Rücksetzers in Prozent, acht Achsen, Alarm mit Push, Ton und Ansage; Debug 160 bis 162 (U307)** (UEBERGABE 3χχχχχχ). Wer hier weiterbaut, muss wissen: (1) **Die Prozentzahl kommt allein aus dem Ausblick** (`hl_ausblick.erreichen_aus_lauf` auf der abgelegten Verteilung, seit 23.122 mit Tag 2: `LAUF_H`). Achsen, Druck-Index und Warnzeichen ändern sie nicht -- das darf erst Paket 2, und nur für Regeln, die U308 belegt. (2) **Ohne bestandenen Rückblick keine Stufe und kein Alarm** (`besteht is True` UND Schwellen des Coins). Der Rückblick rechnet ohne Trend und begrenzt die Zahl wie die Anzeige (0,5 bis 99,5 %); enthält die jüngste Rechnung des Ausblicks einen Trend, sagt die Karte es. Das vierte Kriterium „Niveau“ fängt, was die Steigung nicht fängt (eine überall zu hohe Zahl). (3) **Felder des Cockpits:** `pz_n` der Messwerte ist die abgeschnittene Perzentilzahl, keine Anzahl; der Grund für einen fehlenden Wert steht in `fehlt`, nicht in `text` (mein Lesefehler beim Bau). (4) **Orderbuch:** Die letzten 14 Tage stehen nur in `book_summary` (5-s-Raster), ältere nur in `book_summary_1m` -- wer 30 Tage braucht, liest beide (`tiefen_stunden`); Mittel statt Median, weil der Median rund 1,5 Millionen Zeilen in den Speicher holte. (5) **Zustand je Coin** läuft auch für nicht gewählte Coins mit; nur `gemeldet` entscheidet über Sperrzeit und Entwarnung. (6) **Neue .md-Dateien kommen mit dem `update.py` der Vorversion nicht mit** (nur `.py` und `.json`): Kein Test, der auf dem Pi läuft, darf eine neue .md-Datei verlangen, und die Update-Probe muss auf eine Kopie ohne sie einspielen (in 23.122 stand das falsch im Selbsttest der Debug-Nummern -- vor der Lieferung gefunden). (7) **Der Faden** (`hl_radar.starte`) übersteht Fehler und öffnet nach einem Fehler der Datenbank eine neue Verbindung; `HL_RADAR=0` wird nur dort geprüft; für Selbsttest-Datenbanken startet er nicht. Schritt und Takt lassen sich für Proben einsetzen (`schritt`, `takt_s`). (8) **Push:** Das Thema steht in keinem Text und keinem Fehlertext; Proben senden nur an eine nachgebaute Funktion oder an einen Webserver auf demselben Rechner. (9) **Debug 163 ist reserviert** (`DEBUG_RESERVIERT`) -- mit U308 als Lauf eintragen und den Prüfpunkt der Reihe anpassen. (10) Meldungen nennen die Ortszeit des Pi mit Zone, Berichte UTC. (11) Ein Selbsttest, dessen Probe bei einem fehlenden Wert mit einer Ausnahme abbricht, zählt im Mutationslauf als „nicht gefunden“ -- Proben auf Texte laufen über `_drin`. Nächste Debug-Nummer 164, nächste Plan-Nummer U311.

**Nachtrag 23.11. 14:07 (Version 2026-09-23.121 · 967df1fdf8): Paket 23.121 -- Prognosemärkte im 24-Monats-Chart, Schritt 2b: Punkte ab 90 Tagen Frist, Fed-Marken, Debug 159 mit Abschnitt 7, Debug 156 mit Abschnitt 9 (U280)** (UEBERGABE 3φφφφφφ). Wer hier weiterbaut, muss wissen: (1) **Es zählt nur ein frischer enger Kurs** (`zaehlt` = frisch UND eng; `hl_marktschicht.pm_eng`: Geld und Brief gespeichert, höchstens 4 Punkte auseinander, Geld 0 zählt als 0). Der letzte Handel steht in der Zeile, geht aber in keine Rechnung ein -- wer ihn wieder einrechnet, bekommt bei den späten Sitzungen der Fed Unsinn (Bericht vom 23.11.). (2) **Ein Weg, zwei Leser:** `_pm_lesen` öffnet `prognosemarkt.db` an EINER Stelle, nur lesend; `pm_bestand` (Debug 159) und `pm_chart` (Chart, Debug 156) lesen dieselbe Auswahl. `pm_chart` wirft nie -- ein Fehler dieser Schicht kostet weder den Chart noch Debug 156 (Proben P24, C12). (3) **Ein Punkt ist nicht der Fächer:** Die Raute nennt, wie wahrscheinlich das Niveau BIS zur Frist erreicht wird; der Fächer den Kurs AM Tag. Der Vergleich ist nur der Überschlag in `hl_langfrist.ueberschlag` (Anteil des Fächers jenseits des Niveaus bis zum Doppelten) -- Text, keine Rechnung, kein Pfadmodell. Nur ein Zeichen aus Spannen (Kurs am Tag) ist dieselbe Größe wie der Fächer. (4) **Stichtag:** Der Chart nimmt seinen letzten Kurstag, Debug 159 den Vortag (UTC); Fristen zählen in Kalendertagen bis zum letzten Tag in New York (`pm_tag`). (5) **Fed-Marken kommen aus `KXFEDDECISION`**, nicht aus der Zins-Leiter; der Ausgang wird aus dem Titel gelesen, sonst aus dem Ende der Kennung -- **die Titel kenne ich aus keiner echten Antwort**; bei Widerspruch ist die Sitzung nicht eng, und Debug 159 zeigt in Abschnitt 5, was gelesen wurde. (6) **Der Fangbereich des Fadenkreuzes ist in Pixeln** (`tpp` = Tage je Pixel in `mkZeichne`); eine Schwelle nur in Tagen ist auf dem Handy nicht zu treffen. Der Zeiger wird an der Trefferfläche gemessen, nicht am Außenrand des Bilds (1 px Rahmen; Klickprobe K17 prüft beide Seiten). (7) **Die Antwort für die Seite darf sich zwischen zwei Abrufen nicht ändern** (Probe C10) -- keine Uhrzeit und kein Dateipfad im Teil `prognosemarkt`. (8) Die Schwellen 90 Tage, 3 %, 60 %, 6 je Tag sind Setzungen für die Lesbarkeit. Nächste Debug-Nummer 160, nächste Plan-Nummer U306.

**Nachtrag 23.11. 04:20 (Version 2026-09-23.120 · 8a39a2dcfa): Paket 23.120 -- Prognosemärkte für den 24-Monats-Chart, Schritt 2a: zwei neue Marktreihen und Debug 159 (U280); Wächter-Zeile in Debug 20 (U304)** (UEBERGABE 3υυυυυυ). Wer hier weiterbaut, muss wissen: (1) **`hl_marktschicht.py` hat zwei Teile, die nichts teilen:** die Optionen (schreibt in `makro.db`, ruft Deribit) und seit 23.120 Teil 2a, den Bericht der Prognosemärkte (`pm_bestand`, `pm_text`) -- er öffnet `prognosemarkt.db` an EINER Stelle und nur lesend (`hl_prognosemarkt.lesen`), ruft nichts ab und fasst `makro.db` nicht an (Proben K3, P11). (2) **Fristen-Leitern sind eine eigene Form:** Bei Polymarket trägt der Gruppentitel eines Markts die Frist, keine Schwelle -- das Niveau kommt aus der Vorgabe `PM_FRISTEN`, die Frist aus `pm_frist` (Ende des Tages in New York); `endDate` bleibt als Ablauf. Bei Kalshi `KXBTCPRICE` kommt das Niveau notfalls aus dem Ereignis und die Frist aus dem Titel, wenn der Handelsschluss mehr als zwei Tage dahinter liegt -- beides nur für Reihen mit den Schaltern `niveau_aus_ereignis` und `frist_aus_titel`. (3) **Beide Reihen sind in keiner echten Antwort geprüft**; der erste Debug 159 vom Pi zeigt je Ereignis ein Beispiel. Vor jeder Regel für den Chart diesen Bericht lesen. (4) **Rekalibriert wird je Markt mit SEINER Frist** (Bericht und Reiter „Krypto“); die Übertragung der Regel 1.6 auf Spannen (PM6) ist meine und nicht entschieden. (5) **Im Chart steht von den Prognosemärkten nichts**; die Regeln für Punkte und Kontextstreifen (PM9) sind vorab im Konzept festzulegen, nach dem ersten Bericht. Ein Berührungs-Markt nennt das Erreichen BIS zur Frist, der Fächer den Kurs AM Stichtag -- das ist nicht dieselbe Größe. (6) **Die Stempel des Takts der Prognosemärkte liegen nur im Speicher** -- nach jedem Neustart der Dienste läuft jede Aufgabe im ersten Schritt. (7) **`check_system.wache_stand`** liefert die jüngste Prüfung des Wächters; „still“ ab 15 Minuten. Nächste Debug-Nummer 160, nächste Plan-Nummer U305.

## 7. Bekannte Schwächen, die man kennen muss

- Trades/Aktivität sind nur für die verfolgten Coins messbar (Stream); Leaderboard-Konten haben zusätzlich REST-Fills aller Coins → leicht ungleiche Aktivitätszählung (U5-Feinheit).
- Placebo im Exit-Lift über Coins gemittelt (Verfeinerung offen).
- v1-Trefferbilanz je Treiber ist in-sample; Lift/z gegen Randverteilungen vorhanden; OOS ab 25 Blöcken.
- Konstellationen: Auswahl-Effekt (Top-12 von ~400 Prüfungen) ist ausgewiesen, aber die Tabelle wirkt immer beeindruckend — nur die Stabilitätsliste (z ≥ 2 an ≥ 14 Tagen) zählt.
- Vorbedingungen (U131): Steigt der Kurs in einen Rückgang hinein und folgt binnen Stunden nach einer Erholung ein tieferer, zählen beide als ein Ereignis (Zufallswege: 1 von 660 Bewegungen). Bewegungen, die nur am Kerzenhoch 3 % erreichen, vom 15-min-Prognosekurs aus aber nicht, fehlen (der Debug-Abgleich nennt sie).
- Sicherheit: Dashboard ohne Anmeldung im Heimnetz (Host-Allowlist für POST), Update ohne Signatur (S2), sudo-Passwort im Klartext (S3) — Betriebsentscheidungen des Nutzers.
- Ausblick (seit dem ersten Rückblick 12.10.): Die Breite schlägt den naiven Vergleich nur bei 7 Tagen knapp; das PAXG-Band ist zu eng
  (57 % statt 80 %, U157); die Szenarien mit dem S&P 500 sind unter Aktienstress nicht kalibriert. Beides steht am Fächer.
- Heatmap-Abdeckung (schwankt, U159): Am 11.10. sah die Karte nur 7–19 % des OI, am 14.10. (20 h nach einem Neustart) wieder
  24–27 %. Kaskaden-Gleichung, Magnet-Test und Heatmap-Anker rechnen mit dem jeweiligen Ausschnitt; die Ursache ist noch offen
  (Vermutung: Neustart-Muster des Pollers).
- Vollbericht (seit 23.68 ein Durchgang mit Zeitbudget, U168): Die Laufzeit auf dem Pi ist noch nicht gemessen (Wochenlauf 21.10.);
  fehlt am Ende etwas, steht es als „nicht gezählt (Zeitbudget)“ da.
- Konfluenz-Bilanz (seit 23.68 je Quelle, U170): Die Einträge vor 23.68 bleiben als „Quelle unbekannt“ gemischt; nur die Zeilen je
  Quelle seit dem Einspielen gelten für ein Regelwerk.
- Fusion (erster Blick 13.10.): nicht belegt besser als die Basisrate; alle Vorhersagen, auch die Basisrate, liegen beim Münzwurf.
  Kriterium 5 rechnet der Bericht seit 23.68 (U162); erster echter Wert im Wochenlauf 21.10.
- TradeLabor: Bis 23.68 lief XMR mit doppelter Gebühr (gemessen etwa die Hälfte der normalen). XMR-Ergebnisse vor dem Wechsel sind
  um diesen Teil zu schlecht; die Tabelle je Strategie und Coin trennt vor/nach (U160, U161). Die Kostenschwelle der Fusion rechnet
  XMR bis 25.10. weiter doppelt.
- TradeLabor, Größen: Grid-Lose sind Teile des 10.000-USD-Kontos je Coin (seit 23.68 mit „Los“ und Tagestabelle, U163). Swing und
  Zyklus handeln seit 23.68 mit 10.000 USD unter neuen Kennungen (U164); ihre wenigen Trades davor stehen unter den alten.
- Ausblick, Ausnahmelage (U179, `KONZEPT_Ausblick.md` 13.18/13.19): Die S&P-Regel (c) ist ein Hinweis; sie ändert keine Spanne.
  Seit 23.69 nennt der Text Beginn, Ende und den Börsenstand bei Auslösung. Die Schwelle ist nicht auf den Tagesverlauf des S&P
  geeicht; die Zählung (`--sp-zaehlung`, 20.10. 21:15) misst es, eine neue Schwelle erst nach Entscheidung des Nutzers.
- TradeLabor, Akkumulation (U180, seit 23.69): Der Vergleich „Zeitpunkt gegen Zufall“ ist auch ohne Vorhersagekraft meist positiv
  (Zufallswege: Median +2 %); belastbar sind nur Q gegen Vorzeichen-Surrogate im Rückblick und der Abstand zur Kontrolle ohne
  Heatmap. Die Kalibrierung von Q (6 von 144 Zufallswegen unter 0,05) schließt einen Fehlalarmanteil bis knapp 9 % nicht aus.
  Die Heatmap-Regel A2 ist die Idee des Nutzers, kein Beleg (U110 offen bis 25.10.). Kapital ohne Obergrenze: Der Einsatz wächst mit
  jedem Rücksetzer.
  Seit 23.70 (U184) rechnet sie beim ersten Takt rückwirkend ab dem Start des Coins im Labor: ohne Heatmap-Regel und Warteregel (die
  wirken erst live, bis dahin sind Hauptstrategie und Kontrolle gleich) und zum Schwellenpreis ohne Abstand zur Buchmitte (etwas
  günstiger als live). Der Kurs kommt aus dem Perp-Buch, gerechnet wird ein Spot-Kauf mit Spot-Gebühr. Die Startkauf-Gründe aus 23.70
  stehen in der Datenbank im alten Wortlaut; die Anzeige schreibt sie um (U185), die Ursache eines späten Startkaufs fehlt bei ihnen.
  Seit 23.72 (U186) kauft sie zusätzlich jede Korrektur von 7 % in 48 h und je 7 % tiefer binnen 14 Tagen, ohne Sperre: auch in teuren
  Phasen und ohne Obergrenze; für diese Käufe gibt es noch keinen Vergleich gegen Zufall (der zählt weiter nur A1–A3).
  Der Labor-Bericht nennt frühere Regelstände (andere Kennung) bis zur Behebung (U187) mit demselben Titel wie die laufenden.
- Strategy-Bestand (U177, seit 23.69): Plausibilität nur nach unten und nur mit einem Nachbarn binnen 9 Tagen; ein einzelnes 8-K
  nach einer Lücke wird ungeprüft übernommen.
- Update (U182): `update.py` spielt nur Dateien aus `PROJECT_FILES` ein (weitere `.py`/`.json` ohne Sicherung, andere Dokumente gar
  nicht). Jede neue Datei gehört in die Liste; eine Probe im Selbsttest fehlt noch. Ein Paket wird immer vom update.py des
  installierten Stands eingespielt — eine berichtigte Liste wirkt erst beim nächsten Update.
- Börsenflüsse (U174, `KONZEPT_Makro.md` 12.6): Ein Fenster je Tag; das eigene Archiv weist nach 730 Tagen erst ρ ≈ 0,13–0,15
  nach (R² rund 2 %), mehr als die Studien fanden. Die Vorstudie auf der bereinigten Historie zählt nur in einer Richtung (ohne
  Beleg endet U174).
- Hebel S5 (U158): Mit den ersten ein bis zwei Jahren Reihe belegt die Prüfung selbst ein dreifaches Risiko nur in einem Teil der
  Fälle (450 Tage: 8 von 30); „nicht belegt“ heißt dann wenig. Ob der kostenlose CryptoQuant-Schlüssel den Endpunkt erreicht, zeigt
  erst der erste Abruf (Doku widersprüchlich).
- Ausblick, Größe der Stressphase (U156): ein Szenario aus wenigen unabhängigen Wegen (ein Jahr ≈ 13 Vier-Wochen-Wege); die
  Spannen sind grob, die Zahl „x-mal so breit“ ist die belastbarere.
- Backup bis 23.66 (U145): update.py und Recorder können gleichzeitig sichern (keine Sperre, dieselbe Zwischendatei). Update nur drücken, wenn die Kachel „Letztes Backup“ eine Uhrzeit zeigt; sonst erst „Jetzt sichern“ (System → Speicherorte).
- Notbremse (U206, seit 23.76): Ob Ebene A allein den 22.10. erfasst hätte, ist offen (`KONZEPT_Notbremse.md` 11.5); die erste
  Kalibrierung sieht für den Gleichlauf nur rund 50 Tage (`candleSnapshot` liefert die jüngsten 5.000 Kerzen, bei 15 min rund 52 Tage; jeder Tag bis zum
  ersten Start kostet einen Tag).
  **Rückblicke auf Labor-Code sind nur über Sichten mit Zeitgrenze kausal:** `hl_anker.jetzt`, `liq_schwellen` und
  `hl_adressfluss.lesen` lesen ohne Obergrenze der Zeit (live richtig); `check_notbremse.py` liest deshalb über temporäre Sichten, und
  sein Rückwärtstest bildet Darwin, Elite und den TWAP-Druck nicht nach. In Welt A sind gesperrte Einstiege verworfen, nicht
  nachgeholt; die Rückrechnung der Akkumulation ab dem Start filtert dort nach dem Tor (Näherung).
- Betrieb ohne SSH (seit 23.10.): Auf dem Pi ist SSH aus, ein Bildschirm hängt nicht dran. Diagnose nur über die Debug-Konsole
  („★ System: letzter Neustart und Ausfälle“); was Stunden läuft, startet die Debug-Konsole als eigene systemd-Einheit (Muster:
  Update, Rückblick der Notbremse). Das Systemprotokoll vor einem Neustart gibt es nur bei dauerhaftem journald (U214; seit 23.78 als
  Klick einschaltbar, U217). Seit 23.78 startet systemd ein hängendes Dashboard nach 15 min ohne Lebenszeichen neu (U215); hängen nur
  Datenseiten, während `/lebt` antwortet, startet nichts neu. Der Wächter ist wegen Abdeckung und Poller dauernd rot (U218).

## 8. Kompatibilität dieser Übergabe

- Modellunabhängig: keine Sitzungs-, Transkript- oder Speicherfunktion wird vorausgesetzt. Alle Fakten stehen in den Dateien.
- Historische Dateinamen mit „FABLE" bleiben (Änderungsprotokoll); Autorenvermerke in README/UEBERGABE/REVIEW sind auf
  „Fable 5.1 bis 23.09., fortgeführt mit Opus 5.5" angepasst.
- Die Werkzeuge der Sandbox (numpy, node, playwright, kein Netz) sind Annahmen dieser Umgebung; in einer anderen
  Umgebung Abschnitt 4 entsprechend prüfen.

## 9. Erste Schritte in der neuen Sitzung (Vorschlag)

1. Abschnitt A des Plans mit dem Nutzer (Version 23.10 einspielen lassen, Rundum-Funktionstest, Netzwerkstatus).
2. Ausstehende Proben abfragen: P2 (K1: Liquidationen nach Methode, ≤ 10 beobachtete Konten) und P1 (Coinbase-Seite).
3. U8 (H10 Bilanz der Empfehlungen) ist seit 23.16 gebaut — jetzt LESEN: Debug „★ Bilanz der Kauf-/Verkaufsempfehlungen (U8)“,
   wöchentlich; aussagekräftig erst nach einigen Wochen.
   Seit 23.20 laufen die Prüf-Einträge von selbst (Berichtsplan `hl_viz.BERICHTSPLAN`, Dateien in `berichte/`). Der Nutzer lädt
   die Sammeldatei aus dem Debug-Bereich hoch. Neue Termine trägt Claude dort mit dem nächsten Paket ein.
4. Ab 6.10. U3b entscheiden. U7b (v2 aktivieren, inkl. Pfad): seit 05.10. auf den 25.10. gelegt, zusammen mit U108 (Plan U7b: Schalter allein unvollständig, Labor-Strategie „Prognose“ liest `p_up`).
