# PROJEKTÜBERGABE — Hyperliquid-Analysesystem („hl_liq_project")
**Für den Import in eine neue Sitzung (Claude Opus 5.5) · Stand 23.09.2026, Version 2026-09-23.10**
Erstellt bis hierher mit Claude Fable 5.1 (Sitzungen 1–5, 13.–23.09.2026); Auditberichte v9/v10 kamen von Opus 5.5.

> **So beginnst du:** (1) Diese Datei ganz lesen. (2) `UPDATE_PLAN.md` lesen — Abschnitt A abarbeiten (Prüfungen),
> Abschnitt B ist die Reihenfolge der offenen Arbeiten. (3) Das Paket `hl_liq_project.zip` ist die einzige Wahrheit;
> Chats und alte Transkripte sind nicht verfügbar. Alles Wissen steht in den Dateien des Pakets.

---

## 1. Was das System ist

Ein Analysesystem für Hyperliquid-Perpetuals (BTC, ETH, HYPE, ZEC, PAXG, XMR) auf einem **Raspberry Pi 5**
(Python 3.13, SQLite, systemd), mit vier Diensten:

| Dienst | Datei | Aufgabe |
|---|---|---|
| Recorder | `hl_recorder.py` | Hyperliquid-API und WebSocket: Positionen aller großen Konten (Poller in Stufen), Leaderboard-Top-75 (alle 2 min), Fills (Stream + REST-Nachtrag), Orders, Liquidationen (beobachtet + abgeleitet), Kerzen, Heatmap-Snapshots, Pool „Aktive Profis", Masterregel Sperre, Backup; seit 23.33 der Adress-Strom (`hl_adressfluss.py` → `adressfluss.db`) |
| Dashboard | `hl_viz.py` | Web-UI (http://<pi>:8765), alle Charts/Abschnitte, Prognose-Berechnung (Lernzyklus, Kalibrierung v1/v2, Scores, Profis, Konstellationen), Debug-Konsole, Update/Restore; seit 23.33 der TradeLabor-Takt (`hl_labor.py`, 15 s) |
| Fremdbörsen | `hl_binance.py` (+ `hl_ext.py`) | Binance, Bybit, OKX, Crypto.com: Liquidationen, Funding, Kennzahlen, ETF-Flüsse (Farside) |
| Coinbase | `hl_coinbase.py` | Spot-Matches (Taker-Flow), Orderbuch, Kerzen |

Kernfunktion: **Liquidations-Heatmap** (wo liegen Liquidationspreise großer Konten) und eine **Prognose**
(30 Treiber → Wahrscheinlichkeit/Pfad), dazu Konten-Analysen (Wale, Leaderboard, Elite, Aktive Profis).

## 2. Dateien im Paket (102 Dateien in 120 Zip-Einträgen, Stand 23.72)

- **Kern:** `hl_recorder.py`, `hl_viz.py`, `hl_forecast.py` (Treiber, Pfad, Kalibrierung v1, Bewertung),
  `hl_indikatoren.py` (neue Treiber 14.09.), `hl_score.py` (Konto-Score, Elite), `hl_profis.py` (Aktive Profis; seit 23.57 Schatten der Darwin-Liste, U136),
  `hl_kalib.py` (Kalibrierung v2, Schatten), `hl_konstellation.py` (Paar-Statistik, Vorbedingungen; Ereignisse seit 23.53 aus jeder gespeicherten Prognose, U131; Begründung im Kursdaten-Abgleich seit 23.56 über die ganze Bewegung, U135),
  `hl_ext.py`, `hl_binance.py`, `hl_coinbase.py`, `hl_dbcoord.py` (Schreibsperre), `hl_watchdog.py`,
  `hl_timestats.py`, `hl_backtest.py`, `macro_corr.py`, `run_all.py`, `install.py` (Installation + `--selftest`),
  `hl_familien.py` (Treiberfamilien; Hygiene seit 23.55 an den aktiven Zeiten, „kein Urteil“ statt „tot“, U133), `hl_anker.py` (Heatmap-Anker), `hl_labor.py` (TradeLabor, simulierter Handel),
  `hl_adressfluss.py` (Adress-Strom), `hl_fusion.py` (Fusionsprognose, Kalibrierung v3, Kostenschwelle; Schatten, seit 23.42),
  `hl_kaskade.py` (Kaskaden-Gleichung: Wurzelgesetz auf die Heatmap-Cluster, Kipppunkt, Kalibrierung Y; Schatten, seit 23.43),
  `hl_magnet.py` (Magnet-Test U110: Berührungen der Cluster gegen das Nullmodell, Spiegel, Placebo; nur Messung, seit 23.45),
  `hl_makro.py` (Makro-Chart U121: Abruf freier Quellen nach `makro.db`, Treiber, Miner-Kostenbasis, Nutzlast; seit 23.47),
  `hl_makro_js.py` (Skript des Makro-Abschnitts, `/makro.js`; seit 23.47; Kursleiste unter jedem Kennzahl-Chart seit 23.54, U132),
  `hl_makro_signal.py` (Makro-Signale U126: Abweichung zur Referenzlinie, Rückblick, Live-Signal, Bilanz gegen Zufall, Prognose,
  Live gegen Nachrechnung; reine Rechnung, seit 23.49), `hl_makro_korr.py` (Makro × Kurs U130: Makro-Merkmale gegen die
  BTC-Rendite der folgenden Tage, Phasen-Null, Benjamini-Hochberg, Hälften; Debug-Bericht, seit 23.52), `hl_regime.py`
  (Regime-Modul U138, Phase 0: Vorprüfung P0.1–P0.9 auf bis zu drei Jahren 30-min-Kerzen je Coin, eigene `regime.db`; Debug-Bericht,
  seit 23.59; K3 seit 23.60 je Stunde verglichen, U139), `hl_swing.py` (Swing-Trades U140: eigene `swing.db` mit 30-min-Kerzen und
  Funding von Binance-Futures ab 2020, Swing-Takt im Dashboard, Strategien S1–S4 und zwei Kontrollen als gemeinsame Funktionen für
  Historie und TradeLabor, Vorprüfung mit Placebo und Urteil; seit 23.61; seit 23.62 auch die Dip-Regeln Z1/Z2 und RSI),
  `hl_zyklus.py` (Zyklus-Studie U141: Rallyes und Rücksetzer auf den langen Tagesschlüssen von Coin Metrics gegen 1000
  Zufallswege, „Dip halten“ gegen HODL, Trendfilter und Schwankungssteuerung, Warnsignale vor Rücksetzern, Gegenprobe mit
  Ausführung; nur lesend; Debug-Bericht, seit 23.62), `hl_hebel.py` (Hebel-Studie U142: Binance-Positionierung und Perp-Anteil vor
  Rücksetzern und Liquidationswellen; eigene `hebel.db` mit dem Binance-Archiv ab 2020, Hebel-Takt im Dashboard, Sicherung der
  Liquidationen und Buchtiefe; Debug-Bericht, seit 23.63; 23.64 Kerzenschlüssel mit Markt und beschreibende H1-Ergänzungen),
  `hl_chartbild.py` (Chartbild U143 Stufe 1: die Lage je Coin in Worten -- Trend, Bein wie U141, Swings, Niveaus der Großkonten und
  Liquidationscluster, 80-%-Band wie P0.2 mit Trefferquote, RSI, Positionierung, Prüfstand je Zeile; nur lesend, kein Signal; seit
  23.65), `hl_chartbild_js.py` (Skript des Abschnitts „CB Chartbild“, `/chartbild.js`; seit 23.65),
  `hl_ausblick.py` (Ausblick 4 Wochen U146: Breite HAR-X, Form aus echten Pfaden ohne Trend, Richtung nur nach bestandenem Tor,
  Ziellevels mit Wahrscheinlichkeit, bedingte Szenarien mit dem S&P 500, Stressfächer, Takt; eigene `ausblick.db`; seit 23.66),
  `hl_ausblick_js.py` (Skript des Abschnitts „AU Ausblick“, `/ausblick.js`; seit 23.66), `hl_aktien.py` (Aktien-Archiv U148:
  FRED, `xyz`, DVOL, CFTC, FINRA, Farside, Cboe, SEC mit Abrufzeit in `aktien.db`, Studie U147, Kurzstudie K1/K2; seit 23.66),
  `hl_datentage.py` (Studie Datentage U154: Schwankung von BTC und ETH im Fenster 8:30–10:30 New York an US-Terminen gegen Werktage
  desselben Monats, Verschiebungs-Null, Holm, Hälften; liest `swing.db` und `makro.db`, schreibt nichts; seit 23.67),
  `update.py` (Update/Restore), `migrate_db.py`, `version.py` (Version + Prüfsumme).
- **Werkzeuge (Debug-Konsole):** `check_*.py` — sources, fills, leaderboard, forecast, writes, report, m9, magnet,
  elite, treiber (Harness, 83 Prüfungen), pool, sperre, profis, daily, orders, abdeckung (seit 23.68, U159); `db_size.py`;
  `make_treiber_pdf.py`/`_en.py` (Treiber-Dokumentation als PDF).
- **Dokumente:** `README.md` (Betrieb), `UEBERGABE_13-09-2026.md` (chronologisches Änderungsprotokoll, Abschnitte
  3a–3ω, 3αα, 3ββ, 3γγ, 3δδ, 3εε, 3ζζ, 3ηη, 3θθ, 3ιι, 3κκ, 3λλ, 3μμ, 3νν, 3ξξ, 3οο, 3ππ, 3ρρ, 3σσ, 3ττ, 3υυ, 3φφ, 3χχ, 3ψψ, 3ωω, 3ααα, 3βββ, 3γγγ, 3δδδ, 3εεε, 3ζζζ, 3ηηη, 3θθθ, 3ιιι, 3κκκ, 3λλλ, 3μμμ, 3ννν, 3ξξξ, 3οοο, 3πππ, 3ρρρ, 3σσσ, 3τττ, 3υυυ, 3φφφ, 3χχχ, 3ψψψ, 3ωωω, 3αααα, 3ββββ, 3γγγγ), `UPDATE_PLAN.md` (lebendes Arbeitsdokument), `REVIEW_Audit_v10_22-09-2026.md`, `KONZEPT_Aktive_Profis.md`, `KONZEPT_Fusion.md` (fusionierter Treiber, Stufen 1–3; Abschnitt 4b Strukturgleichung und Kaskaden-Gleichung),
  `KONZEPT_Makro.md` (Makro-Chart: Regeln, Quellen, Rechnung je Treiber, Proben, Grenzen; 12 Börsenflüsse U174 vorab festgelegt), `RECHERCHE_Makro_Chart_05-10-2026.md`
  (Recherche zu Zyklus-Indikatoren und freien Datenquellen, Grundlage von U121), `KONZEPT_Regime.md` (Regime-Modul U138:
  die jüngsten 4–8 Wochen lesen; Prüfplan 9.1a, Phase 0 gebaut in 23.59, Ergebnis auf echten Daten 9.4), `RECHERCHE_Regime_07-10-2026.md` (Recherche zu Kalender- und
  Schwankungsmustern, Stufen, Regime-Erkennung und Prognosebewertung, Grundlage von U138), `KONZEPT_Swing.md` (Swing-Trades U140:
  Regeln S1–S4, Größe nach Risiko, Urteil vorab, Kalibrierung des Placebos 6a, Labor; 7a Zyklus-Strategien),
  `KONZEPT_Zyklen.md` (Zyklus-Studie U141: Fragen des Nutzers messbar gemacht, Zufallsgeometrie, Teile A–D vorab, Änderungen vor
  dem ersten Lauf 12, Vorschlag zum weiteren Vorgehen 13), `KONZEPT_Hebel.md` (Hebel-Studie U142: Fragen messbar gemacht, Daten,
  H1–H4 vorab mit zwei Nullmodellen, Folgen vorab, Kalibrierung 12), `RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` (Bewertung
  Fear & Greed, Binance-Top-Trader, Market Maker, Hebel gegen Spot, Chart-Trader; Vorkonzept U142/U143), `KONZEPT_Chartbild.md`
  (Chartbild U143 Stufe 1: Bausteine und Frische, Lesart, Anzeige, Proben, beim Bau geändert 9.1),
  `KONZEPT_Ausblick.md` (Ausblick 4 Wochen U146 und Studie U147: vorab festgelegt 11.10., Ergänzung 13 zu Takt, Aktienmarkt und
  gemeinsamen Szenarien), `RECHERCHE_Aktienmarkt_11-10-2026.md` (Recherche zu Aktiendaten, Zusammenhang BTC–S&P 500, Methoden
  gemeinsamer Szenarien; Grundlage von 13), `RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md` (U152: gängige Kennzahlen für
  „95 % Hebel gegen 5 % Spot“ mit Quelle, Historie, Kosten und Höchstwerten; seit 23.67),
  `RECHERCHE_Boersenfluesse_17-10-2026.md` (U174: freie Quellen für BTC-Börsenzu- und -abflüsse, Eigenbau, Vergleichbarkeit,
  Revisionen, Belege und Nachweisgrenze; Nachtrag 18.10.: Coin Metrics frei bestätigt; im Paket seit 23.69),
  `KONZEPT_Akkumulation.md` (U180, gebaut mit 23.69, auf dem Pi ab 23.70: Akkumulation im TradeLabor -- nur Kauf, Regeln A0/A1/A2/A3,
  Sperre, Warteregel, 5.000 USD Spot, Startkauf und Rückrechnung ab dem Start des Coins im Labor (U184, 7a), Bilanz und Reiter, Vergleich
  beschreibend, Rückblick mit Q gegen Vorzeichen-Surrogate, vor jedem echten Kurs geändert 7, Stand nach dem Bau 3/6; Anzeige berichtigt
  mit 23.71: „Alle Käufe“, „Stand je Tag“, Grund des Startkaufs (U185, 7b); Korrekturkauf A4 mit 23.72 (U186, 7c); auf dem Pi erst mit
  dem Paket nach 23.70, siehe `update.py`),
  `PROPOSAL_Kalibrierung_Stufe2_3.md` (historisch, durch den K2-Neubau ersetzt), `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
  (historisch), `labels.json` (eigene Kontonamen, Sperren/Schutz), `accesstokens.json`, `android/` (WebView-App).

## 3. Eiserne Regeln (nie brechen)

1. **Zeitstempel in Sekunden** (Ausnahme: `addresses.last_trade/first_seen` in ms; Grenze 1e11).
2. **Seiten** normalisiert `long`/`short`; Klassen `dir`/`mixed`/`hedge`/`mm`; `liquidations.side` ist roh `A`/`B` (A = Long liquidiert).
   `cb_bars.buy_usd/sell_usd` sind vor `cb_meta` 'seite_umstellung' VERTAUSCHT gespeichert (U41) — nur mit `hl_forecast.cb_seite_ab` lesen.
3. **API-Gewicht:** Deckel 90 % von 1.200/min (1.080), Begrenzer mit Rang (0 Leaderboard, 1 Poller/Orders, 3 Fills) und
   arbeitserhaltender 20-%-Reserve für den Hintergrund. **userEvents-Abos: höchstens 10 Nutzer je IP** (Hyperliquid-Limit).
4. **n_eff = getrennte Horizont-Blöcke**, nie Fensterzahl. Jeder Treiber braucht einen **Nulltest**; die Kalibrierung
   zusätzlich die **Positivkontrolle** (Kante 0,65 → p 0,60–0,70) — sie ist Selbsttest-Schritt 22 und ein Tor.
5. **Masterregel Sperre:** > 300 gebündelte Trades (je Coin, Minute, Richtung) in 24 h an ZWEI Tagen binnen 7 Tagen = dauerhaft
   gesperrt; nach dem ersten Tag vorläufig ausgeschlossen, ohne zweiten Tag nach 7 Tagen frei (seit 23.29; 23.13–23.28 ein Tag;
   vorher > 2.000 Fills, alte Sperren einmalig neu bewertet) (kein Signal, keine Orders, keine Fill-Speicherung,
   Positionen nur alle 6 h für die Heatmap). Manuell: `labels.json` `"sperre": true/false`.
6. **Elite:** n ≥ 10 Schritte im Coin, Vorlauf > 0, t ≥ 1 (auf nicht überlappenden Blöcken), Gewinn-Schranke
   (PnL 30 T > 0, Position ≤ 3 % unter Wasser), Aktivitätsschranke ≤ 300 Trades/Tag.
7. **Aktive Profis:** Pool = Kontowert ≥ 1 Mio und Tagesumsatz ≥ 500k (Leaderboard-Datei); Qualifikation 7 T:
   2–150 gebündelte Trades/Tag **in den verfolgten Coins** (seit 23.31; vorher 5–150); Gewinn 7 T > 0; seit 23.32 Timing über ALLE
   Ein- und Ausstiege (mindestens 4, Glückswahrscheinlichkeit ≤ 5 % gegen die Zufallsquote je Coin und Richtung; Einstiege ab 5 nur
   als Veto: Entry-Lift nicht signifikant negativ) statt Exit-Lift ab 5 Ausstiegen. Ein-/Ausstiege aus whale_positions, lb_events
   und -- seit 23.34 -- pool_positions (dieselbe Entscheidung binnen 15 min einmal). Rang: eigene ROI 12 h, sonst HL roi_1d.
   Die Fills der Darwin-Liste sammelt der Recorder seit 23.34 ohne Mindestbetrag (gedeckelt); pool_fills_hourly zählt weiter ab 2.500 USD.
8. **Version und Prüfsumme sind gepaart:** Jede Codeänderung → `version.py` hochzählen (Format `JJJJ-MM-TT.n`). Die
   Systemkachel „Version" zeigt beides; der Nutzer gleicht ab.
9. **Paketname immer `hl_liq_project.zip`** (Update-System des Pi). Inhalt: alle Projektdateien in einem Ordner
   `hl_liq_project/` plus `android/`.
10. **TradeLabor-Regeln sind eingefroren** (seit 23.33): eine Strategie nie „nachbessern“ -- jede Regeländerung ergibt eine
    neue Kennung (name@Prüfsumme) mit eigener Bilanz, die alte bleibt stehen. Bewertet wird nur mit „Glück“ (Student-t ×
    Zahl der Strategien) und den Stufen; die Kontrollen Zufall und Halten laufen immer mit. Seit 23.34 zählen t, Glück,
    Hälften und Stufen **Blöcke** (Trades einer Strategie im selben Horizont-Block = eine Beobachtung, Regel 4); ein neuer
    Coin (XMR) zählt ab seinem eigenen Start (Kontotage).
11. **Dokumente in derselben Antwort aktualisieren:** `UEBERGABE` (neuer Abschnitt 3xxx oben nach „## 0."), `UPDATE_PLAN`
    (Status, Stand, neue Punkte). Was dort nicht steht, existiert nicht.

## 4. Arbeitsweise in der Sitzung (Sandbox)

- Arbeitsverzeichnis `/home/claude`; Paket dorthin entpacken (`unzip -o hl_liq_project.zip && cp -r hl_liq_project/* .`).
- **Keine Netzverbindung** in der Sandbox (kein pip, keine API); numpy, node, playwright sind vorhanden.
- **Tests:** `python3 install.py --selftest` (37 Schritte seit 23.63, ~6–8 min; im Hintergrund starten und Log greppen),
  `python3 hl_hebel.py --selbsttest` (seit 23.63; seit 23.64 63 Prüfungen, ~26 s, ohne Netz),
  `python3 hl_chartbild.py --selbsttest` (seit 23.65; 42 Prüfungen, ~5 s, ohne Netz; Demo-Datenbanken für Bildschirmfotos mit
  `--demo <ordner>`),
  `python3 hl_zyklus.py --selbsttest` (seit 23.62, 17 Prüfungen, ~35 s, ohne Netz),
  `python3 hl_swing.py --selbsttest` (seit 23.61; seit 23.62 21 Prüfungen, ~25 s, ohne Netz),
  `python3 hl_regime.py --selbsttest` (seit 23.59; seit 23.60 28 Prüfungen, ~35 s, ohne Netz),
  `python3 hl_makro.py --selbsttest` (seit 23.47; seit 23.56 56 Prüfungen, ~10 s, ohne Netz, unabhängig von einem echten FRED-Schlüssel),
  `python3 check_treiber.py` (Harness), `python3 hl_forecast.py --nulltest`, `python3 hl_kalib.py --nulltest`,
  `python3 hl_profis.py --nulltest` (seit 23.57 ~12 s mit dem Schatten-Teil), `python3 hl_konstellation.py --nulltest`, `python3 hl_score.py`,
  `python3 hl_labor.py --selbsttest` (seit 23.40 mit Grid, seit 23.61 mit Swing, ~90–105 s), `python3 hl_fusion.py --nulltest` (seit 23.42, ~30 s), `python3 hl_kaskade.py --nulltest` (seit 23.43, seit 23.44 ~40 s), `python3 hl_magnet.py --nulltest` (seit 23.45, ~21 s), `python3 hl_anker.py --nulltest`, `python3 hl_adressfluss.py --selbsttest`, `python3 hl_recorder.py --selbsttest-fills`,
  `python3 hl_viz.py --selbsttest-last`, `python3 hl_recorder.py --selbsttest-start`, `python3 hl_recorder.py --selbsttest-sperre`,
  `python3 hl_recorder.py --selbsttest-gewicht` (Begrenzer in virtueller Zeit: Ereignisschleife mit springender Uhr --
  so lassen sich Stunden Last in Sekunden prüfen; Muster für weitere asyncio-Tests),
  vollständig `python3 install.py --selftest-isoliert`,
  JS-Syntax: alle `<script>`-Blöcke aus `hl_viz.PAGE` extrahieren und mit `node --check` prüfen; seit 23.47 zusätzlich
  `hl_makro_js.MAKRO_JS` (eigene Datei `/makro.js`), seit 23.65 `hl_chartbild_js.CHARTBILD_JS` (`/chartbild.js`). Browserprobe des
  Chartbilds (seit 23.65): Dashboard auf Demo-Datenbanken (`hl_chartbild.py --demo`, Hintergrund-Takte mit HL_BERICHTE=0,
  HL_LABOR=0, HL_MAKRO=0, HL_SWING=0, HL_HEBEL=0 aus), das SVG mit playwright auslesen und gegen die Nutzlast an der beschrifteten
  Achse messen -- vorher Demo frisch bauen und den Server neu starten (der Kurs ist sonst älter als 15 min und das Bild zeigt den
  Ersatz „letzter Tagesschluss“).
  Recorder-Simulation: `python3 hl_recorder.py --db s.db --simulate` (erzeugt Testdaten, ~2 min).
  Dashboard lokal: `setsid nohup python3 hl_viz.py --db s.db --serve --port 91xx &`, dann curl/playwright.
- **Patches:** Text-Ersetzungen mit `assert s.count(o) == 1` je Anker (Unikat!). Anker vorher mit grep prüfen;
  bei Python-Heredocs keine deutschen Anführungszeichen/Gedankenstriche in doppelt-quotierten Strings (Syntaxfehler) —
  Patch-Skripte als Datei (`create_file`) schreiben, nicht als Heredoc. Lange Befehle werden abgebrochen: Schritte klein halten.
- **Packen:** Ordner `hl_liq_project/` aufbauen (Dateiliste in Abschnitt 2), `python3 version.py` im Ordner drucken,
  `zip -rq /mnt/user-data/outputs/hl_liq_project.zip hl_liq_project`, danach `present_files`.
- **Vor dem Packen:** `rm -f s.db* forecasts.db* labels_cache.json sys_history.json` (Testdateien nicht mitliefern).

## 5. Der Nutzer und seine Vorlieben

Deutschsprachig, technisch versiert, betreibt das System selbst (Update-Knopf im Dashboard, Debug-Einträge, Screenshots).
Erwartet: erst Daten prüfen, dann entscheiden; Fehler klar benennen (auch eigene); keine Behauptungen ohne Beleg; jede
Änderung mit Probe; Zahlen mit Intervallen; keine neuen Fehlerquellen. Er liefert Debug-Ausgaben und Screenshots auf
Anfrage — konkret sagen, welcher Debug-Eintrag gebraucht wird. Lange Erklärungen nur, wenn er fragt („Für mein Verständnis…").
Antworten enden mit Version · Prüfsumme des Pakets. **Nummern und Abkürzungen (U142, H1, 13.11 …) kann er sich nicht merken
(11.10.):** offene Entscheidungen in Klartext erklären und als Auswahl zum Anklicken vorlegen, mit Vorschlag und Folgen je
Möglichkeit.

## 6. Aktueller Stand (23.09.2026)

- Pi läuft Version 23.6 (laut Nutzer 11:20); 23.7–23.10 bereit. Alle Quellen grün, Leaderboard 82 s/17,5 s, Fills 593 s,
  15 Gesperrte, Fills-Stream 668 Konten, keine 429.
- **Kalibrierung:** v1 (alt, trägt die Prognose) ist strukturell lernunfähig (Audit v10 K2, selbst nachgestellt);
  v2 (`hl_kalib.py`) läuft im Schatten, Tor bestanden; Umschalten = U7b nach 1–2 Wochen, wenn die direkte Bilanz v2 ≥ v1.
  **Beim Umschalten auch den Pfad (Bias) auf v2 umstellen** (offen, Teil von U7b).
- **Aktive Profis:** Phase 0–3 + U5 live; erster echter Lauf: 692 Pool → 73 aktiv mit Gewinn → 6 qualifiziert.
- **Konstellationen/Vorbedingungen:** Stufe 1 live (Anzeige + Tageshistorie); Stufe 2 (Interaktionsterme in v2) wartet auf stabile Paare.
- **Audit v10:** Stand 23.16 siehe Plan; U8 gebaut, offen U7b, U9–U13, U16–U24, U27, U29, U35, U36, U38. Proben P2 (K1) und P1 (Coinbase-Seite) bestanden (U1, U2).
- **Geklärt heute:** Leaderboard-Flow „0 Konten in 60 min" = ruhige Stunde, nur 6 der Top-75 halten BTC (U26 geschlossen);
  Vorschlag U27: Flow-Treiber auf Basis der qualifizierten Profis.

**Nachtrag 27.09. (23.33):** TradeLabor (U71) und Adress-Strom (U72) sind neu; Einzelheiten in UEBERGABE 3β. Als
Nächstes: informierter Fluss je Adresse aus dem Adress-Strom (U75, braucht ≥ 3 Tage Daten), dann weitere Labor-Strategien
(U76). Eine Demo-Datenbank für Ansicht und Probe entsteht mit einem kleinen Generator (Bars/Buch/ctx/Heatmap für BTC, ETH,
ZEC, HYPE, Prognosespeicher mit Treibern) und `Labor.zyklus(t)` über vergangene Zeitpunkte.

**Nachtrag 29.09. (23.34):** Alle Korrekturen nach dem ersten Labor-Tag (UEBERGABE 3γ, U77–U81): Profi-Bewertung liest
pool_positions (die Darwin-Liste war ausgetrocknet), Recorder sammelt die Fills der Liste ohne Mindestbetrag, Darwin v2 im
Labor (15-min-Summe, halbe Schließung als Ausstieg, neue Kennung), Blockstatistik, XMR als fünfter Labor-Coin (HIP-3-Gebühr
×2 angenommen), Bericht mit Darwin- und Gebühren-Prüfung und allen offenen Positionen. Tests: `python3 hl_recorder.py
--selbsttest-fills` (neu), Labor-Selbsttest 24 Prüfungen, Profis-Nulltest mit Quellen-Probe. Umstellungsprobe 23.33 → 23.34
auf einer Demo-Datenbank (alte Kennungen bleiben, XMR ab dem Update, Kontotage je Coin). Nächstes: U75 (informierter Fluss),
TWAP gegen ausgelöste Orders trennen (U82), weitere Labor-Strategien (U76).

**Nachtrag 30.09. (23.35):** Dauerlast des Dashboards (UEBERGABE 3δ, U83): Abfragen über die ganze, unbegrenzt wachsende
Tabelle whale_positions plus Zwischenspeicher ohne Einzelflug stauten sich (hl_viz 366 %). Regel ab jetzt: **jüngste Stände nie
über die ganze Historie** (Fenster; offene Wal-Positionen haben alle 10 min einen Snapshot), **teure Berechnungen im Dashboard
immer mit Einzelflug** (eine Berechnung, die übrigen bekommen die vorige Antwort). Werkzeuge: Debug „Dashboard-Threads“ (jetzt mit
CPU je Thread), `python3 hl_viz.py --selbsttest-last`. Lastproben mit Millionen Zeilen gehören zu jeder Abfrage auf wachsenden
Tabellen.

**Nachtrag 30.09. (23.36):** Thread-Abzug auf 23.35 ruhig (13 Threads, dauerhafte 0 %). Dieselbe Regel galt noch nicht beim
Recorder-Start: `restore_whales` las die ganze Wal-Tabelle per korrelierter Unterabfrage (2 Mio Zeilen 40 s, quadratisch
wachsend, vor dem Start der Aufzeichnung). Jetzt `wal_zustand_laden`: 24 h vor dem LETZTEN EINTRAG, close gewinnt bei
gleichem Zeitstempel, Gesperrte nicht übernehmen (U85). Gesperrte Wale ließen geschlossene Positionen für immer im Zustand
(`del` in der H3-Bedingung), die Exposure-Zeitreihe zählte Gesperrte mit (U86). Debug „Dashboard-Threads“ zeigt jetzt auch
die Gesamt-CPU des Prozesses: Kurze Anfragen fehlten in der Liste je Thread (U87). Einzelheiten: UEBERGABE 3ε.

**Nachtrag 30.09. (23.37):** Aktive Profis (UEBERGABE 3ζ, U88–U90). Zwei Dinge zugleich:
(1) Eigener Fehler aus 23.34: Die Masterregel zählte die kleinen Fills, die seit U79 nur für Darwin-Konten gespeichert
werden -- die besten Mitglieder wurden vorläufig gesperrt und fielen von der Liste. Regel ab jetzt: **Wenn eine Messung
für eine Teilmenge erweitert wird, prüfen, welche Regeln diese Messung lesen** (hier: Masterregel, Vorhalt).
(2) Darwin-Regeln v2: streng hinein (Glück ≤ 1 %, 14 T), großzügig bleiben (Glück ≤ 50 %), Abstieg nach 3 Tagen.
Die Tagesentscheidung ist die reine Funktion `hl_profis.darwin_tag` (im Nulltest geprüft). Regeländerungen an der Liste
vorher simulieren (Population mit und ohne Vorsprung, Anteil der Könner auf der Liste, Zufallsaufnahmen je Woche).

**Nachtrag 30.09. (23.38):** Bericht vom ersten Tag mit 23.37 (UEBERGABE 3η, U91–U96).
(1) Darwin-Regeln v3: Die Schonung (Verbleib großzügig, 3 Fehltage) gilt nur für Konten mit strenger Aufnahme (Merker
`streng`); der Umstieg auf v2 hatte sie auch Altbestand und einer Rückkehr über die Verbleib-Regel gegeben. Lehre: **Bei
einem Regelwechsel mit Hysterese festlegen, wer beim Umstieg in welchem Zustand startet** -- sonst umgeht der Übergang die
strenge Seite. (2) Die Neubewertung der Masterregel gab ein Konto frei, bei dem kein kleines Bündel mitgezählt war
(Nachzählung zu niedrig, vermutlich gelöschte Rohfills); jetzt muss die Nachzählung die Sperre nachvollziehen, die Freigabe
ist zurückgenommen. Lehre: **Eine Neubewertung vergleicht mit Daten, die inzwischen der Vorhalt gekürzt haben kann.**
(3) API-Gewicht hart gedeckelt (gleitendes Fenster, Klemme, leerer Start); der Begrenzer wird jetzt in virtueller Zeit
geprüft. (4) Eine eigene Aussage war falsch: SilkBtc flog nicht wegen des Zählfehlers, sondern nach den alten Regeln.

**Nachtrag 30.09. (23.39):** Zwei Kopier-Vorlagen im Labor (UEBERGABE 3θ, U97–U99): „Darwin-Liste live folgen“ und neu
„Elite live folgen“, nach derselben Regel und je mit Gegenprobe; die Kopier-Logik ist eine Funktion mit Zustand je Vorlage.
Lehre: **Ein Prüfwerkzeug rechnet mit denselben Funktionen wie das System** (check_elite hatte eine eigene Einstufung und
keinen Sperrfilter und zeigte deshalb eine andere Elite als die, die das System nutzt). Das Labor läuft jetzt bis zur
Auswertung U99 (ab 11.10.) unverändert weiter; Regeländerungen an Strategien nur mit neuer Kennung.

**Nachtrag 01.10. (23.40):** Grid-Bots im Labor (UEBERGABE 3ι, U100–U102): „Grid Long“ und das Spiegelbild „Grid Short“
mit eigener Mechanik in `hl_labor.py` (`_grid*`; die übrigen Strategien überspringen sie). Bewertet nach Bestandswert
(Tagesergebnis = realisiert + Änderung des unrealisierten Bestands, `labor_grid_tag`), nicht nur realisiert. Lehren:
(1) **Eine neue Strategie vor dem Einfrieren auf einem synthetischen Markt mit den Szenarien laufen lassen, die der Nutzer
beschreibt** -- hier hätte ein 15-min-Auslöser den Wunsch „nicht zu früh verkaufen“ in einer schnellen Rallye verfehlt, und
ein Trendmaß ohne Richtung baute dreimal in einen Abwärtstrend hinein. (2) **Bei Strategien mit Bestand (Grid, DCA) nie nur
realisierte Gewinne zählen.** (3) **Regeln mit Mutationen prüfen**: Drei Regeln (Kapitaldeckel mit alten Losen, Stop in der
Auslöserkerze, Notlinie) trafen die Szenarien nicht zuverlässig -- dafür Mikro-Proben auf festen Kerzen. Ungefragt mit
geliefert: die Antwort auf „verzögern lange Läufe die Signale?“ (nein; U95-Kriterium präzisiert).

**Nachtrag 02.10. (23.41):** „database is locked“ im Labor (UEBERGABE 3κ, U103) -- eigener Fehler aus 23.40: ein von Hand
ausgeführtes `BEGIN` öffnete eine Lese-Transaktion, ein fremder Commit machte ihren Stand veraltet, der nächste Schreibzugriff
scheiterte sofort. Lehre: **Eine Transaktion, die liest und danach schreibt, beginnt im WAL-Modus immer mit `BEGIN IMMEDIATE`**
(seit dem 14.09. im Recorder so, `hl_dbcoord` warnt davor) -- vor jedem neuen `BEGIN`/`SAVEPOINT` im Code nach dieser Stelle suchen.
Dazu der Praxis-Hinweis zu den Grids: Hyperliquid verrechnet Long und Short je Konto und Coin; live bräuchte jede Strategie einen
eigenen Sub-Account.

**Nachtrag 04.10. (23.42):** Fusionsprognose, Kalibrierung v3 und Kostenschwelle -- Stufe 1 von `KONZEPT_Fusion.md`, alles im
Schatten (UEBERGABE 3λ, U104–U112). Neu `hl_fusion.py`: Kostenschwelle p* = ½ + K/(2·E|r|) je Coin und Horizont; v3 = v2 über alle
Coins geteilt auf den Familienwerten; Fusion = Expertenmischung (Basisrate, v1, v2, v3, Analog) mit Garantie gegenüber dem besten
Experten, prequential in `fusion_fall`; zwei Labor-Strategien. Auswertung U108 ab 25.10.; umgeschaltet wird nur mit Beleg. Lehren:
(1) **Standardfehler über Coins zählen Zeitblöcke als Klumpen** -- Blöcke verschiedener Coins zur selben Zeit hängen zusammen (in der
Probe war der naive Standardfehler 1,75-mal zu klein). (2) **Die 1-SE-Regel braucht einen GEPAARTEN Standardfehler**; die Streuung der
Fold-Mittel enthält die gemeinsamen Unterschiede der Folds und macht die Regel übervorsichtig. (3) **Erwartungen einer Probe aus der
Mathematik ableiten, nicht aus dem Gefühl:** Fixed Share hält Gewichte gemischt, schlafende Experten behalten ihr Gewicht -- zwei
Prüfungen waren zuerst falsch formuliert, nicht der Code. (4) **Anzeige gehört nicht in den gespeicherten Payload** (sonst +4,2 kB je
Prognosezeile). Rechenhilfe für Erwartungen: 14 Tage Halbwertszeit über 90 Tage = rund 237 effektive 4-h-Blöcke je Coin
(Standardfehler der Trefferquote 3,3 Punkte).

**Nachtrag 04.10. (23.43):** Kaskaden-Gleichung, Stufe 2b von `KONZEPT_Fusion.md` (Abschnitt 4b), alles im Schatten (UEBERGABE 3μ,
U113–U117). Anlass war die Frage nach einer „komplexen Funktionsgleichung“ für den Kurs. Antwort: Für den Kurs gibt es keine, für
seine Verteilung schon.

Neu `hl_kaskade.py`:
- Wurzelgesetz I = Y · σ_Tag · √(Q / V_Tag) auf die Liquidationscluster der Heatmap.
- Kaskade als Fixpunkt mit geschlossener Form für P(Ausschlag ≥ m).
- Kipppunkt und Ende je Seite.
- Schatten-Treiber „Kaskaden-Asymmetrie“ und Familie „Kaskaden“.
- Kalibrierung Y je Coin und Horizont mit Placebo und Seitenspiegel.
- Labor-Strategie „Kaskaden-Kipppunkt“.

Urteil ab 25.10. (U115). Lehren:
1. **Ein Zeit-Placebo allein reicht nicht.** Nahe Cluster gehen oft mit höherer Schwankung auf BEIDEN Seiten einher. Erst der
   Seitenspiegel (dieselben Cluster, Seiten vertauscht) trennt Mechanik vom Mitlaufen; in der Probe ließ das Placebo allein 1 von 4
   Störfaktor-Läufen durch.
2. **Lastproben müssen die Breite eines Datensatzes abbilden, nicht nur die Länge.** Mit 100 Eimern je Heatmap-Stand war alles
   schnell. Mit 800 Eimern kostete das Lesen ganzer Stände 354 MB je 30 Tage, rund 1 GB bei 90 Tagen im Dashboard-Prozess. Jetzt
   laufen je Block gezielte Abfragen: der erste Stand per `MIN(ts)` über `ix_heat_coin_ts`, die Eimer per Bereich im Primärschlüssel.
3. **Wer einen Weg schneller macht, braucht ein Orakel.** Der alte Weg bleibt als Vergleich im Selbsttest. Zwei Mutationen (zu
   schmales Fenster, letzter statt erster Stand) fängt NUR diese Prüfung.
4. **Ein Schatten-Treiber außerhalb von PRIORS** bleibt aus dem v1-Lernen und aus v2 heraus. Er steht aber in `forecast_drivers`,
   also in Familien, Ereignis-Profilen und Hygiene. Seine Trefferzelle in der Treibertabelle braucht einen eigenen Text, sonst steht
   dort „nie |Score| > 0,05“.

**Nachtrag 04.10. (23.44):** Die erste echte Kalibrierung der Kaskaden-Gleichung vom Pi (UEBERGABE 3ν, U118, `KONZEPT_Fusion.md`
4b.1a). Nichts belegt; BTC 1 h am nächsten. Große Ausschläge wurden in allen Coins rund halb so oft vorhergesagt wie eingetreten.
Behoben mit gemischter Schwankung (τ), dazu Spiegel beim gleichen Y, Richtungsprobe ab 20 Blöcken und ein isolierter Selbsttest.
Treiber und Kipppunkt bleiben unverändert. Lehren:
1. **Synthetische Proben brauchen die Eigenschaften echter Kurse,** nicht nur die geprüfte Mechanik: Schwankung mit Gedächtnis und
   dicke Ränder. Die Proben von 23.43 bestand das Modell, der echte Markt widerlegte es am ersten Abend. Der Testmarkt hat jetzt
   `sv_tau`.
2. **Erst die echten Daten ansehen, dann die nächste Stufe bauen.** U110 hätte auf dem falschen Nullmodell gestanden.
3. **Eine Schutzbedingung kann still in eine andere zusammenfallen.** Der Spiegel mit eigenem Y war bei Y = 0 dieselbe Rechnung wie
   „Y = 0 gegen gewählt“. Vergleiche gehören auf gleiche Komplexität.
4. **Selbsttests dürfen den echten Speicher nicht berühren.** Python bindet Standardwerte beim Definieren
   (`learned_save(..., path=STORE)`). Wer `F.STORE` umlenkt, muss den Pfad ausdrücklich übergeben. Die Mutationsprobe legt dafür
   einen Köder-Speicher an.
5. **Kleine n:** Ohne Mindestzahl keine z-Werte, und z nimmt den Standardfehler der Nullhypothese.

**Nachtrag 04.10. (23.45):** Die zweite Kalibrierung vom Pi bestätigt 23.44 (22 von 22 „vorhergesagt ≈ eingetreten“ ✓,
`KONZEPT_Fusion.md` 4b.1b). Gebaut: U110 Magnet-Test (`hl_magnet.py`, UEBERGABE 3ξ), nur Messung. Er prüft, ob der Kurs Cluster
öfter berührt, als die geprüfte Rechnung ohne Cluster erwarten lässt, mit Spiegel und Placebo; Urteil ab 25.10. Mutationen
16 von 16 rot. Lehren:
1. **Eine Eigenschaft gilt nur mit ihrer Bedingung.** Das seitengleiche Mittel heißt „trendfest“, ist es aber nur, wenn beide
   Seiten Fälle haben. Die Trendfalle (Abwärtstrend, nur Long-Cluster) zeigte es; jetzt zählen wirksame Fälle (eine Seite = 0).
2. **Jede Schutzbedingung braucht einen Testmarkt, in dem nur sie hält.** Sonst prüft der Selbsttest sie nicht wirklich: Der
   Störfaktor wie im Kaskaden-Test brachte den Überschuss nur einmal über 2 SE; erst „nur große Cluster koppeln“ zeigt den Spiegel.
3. **Nicht jede Falle ist eine Lücke.** Die Niveau-Welt (der Kurs läuft zu festen Niveaus, dort liegen Cluster) wird belegt. Das
   ist die Grenze des Tests (Vorhersage, nicht Ursache), offen benannt. Ein Placebo mit alten Preisen würde echte, tagelang offene
   Positionen mitnehmen.
4. **Testmärkte nur mit Parametern erweitern, die ohne Wert nichts ändern** (keine zusätzlichen Zufallszahlen). Der Kaskaden-Selbsttest
   liefert danach Zahl für Zahl dasselbe.
5. **Kleine Probe, falscher Alarm:** Mit 12 Seeds lag die Streuung der Spiegel-Differenz (klein) beim 1,38-Fachen des berechneten
   Standardfehlers; mit 40 Seeds liegt sie bei 0,82–1,08 über alle Größen und Kontrollen. Erst genug Wiederholungen, dann eine
   Korrektur.

**Nachtrag 04.10. (23.46):** Nutzerfund vor dem Einspielen von 23.45: In den Treiberfamilien (BTC, „Kaskaden“) stand z = 1,2 · 10¹⁶ bei
n = 3 (UEBERGABE 3ο, U119). z = Mittel / Stichproben-Streuung; drei gleiche Treffer haben Streuung 0, im Fließkomma 6,8 · 10⁻¹⁷.
Jetzt rechnen Treiberfamilien und Heatmap-Anker das z einer Trefferquote exakt (`hl_forecast.z_treffer`: Summe von Binomialen je
Erwartung, mittlerer p-Wert, |z| ≤ 7); die Ereignis-Profile geben ohne Streuung kein z. 23.46 enthält 23.45. Lehren:
1. **Bei Trefferquoten nie die Stichproben-Streuung in den Nenner,** sondern die des Zufalls (oder exakt). Bei wenigen gleichen Werten
   ist sie 0 bzw. 10⁻¹⁷, `> 0` schützt nicht.
2. **Einen Fehler auch in den Kopien suchen:** Dieselbe `_stat`-Funktion stand im Heatmap-Anker, wo „belegt“ die Hauptprognose
   ändert, und dieselbe Rechnung in den Ereignis-Profilen.
3. **Auch eine kleine Probe braucht ihre Mutationen:** Die erste Fassung der Anker-Prüfung hätte die alte Formel nur durch einen
   Absturz verraten (z war None). Jetzt prüft sie den exakten Wert.

**Nachtrag 05.10. (23.47):** Makro-Chart (UEBERGABE 3π, U121, `KONZEPT_Makro.md`). Auf Wunsch des Nutzers alles Kostenlose aus der
Recherche `RECHERCHE_Makro_Chart_05-10-2026.md` (Stufen 1 und 2), je Treiber ein Chart, dazu die Miner-Kostenbasis (Antminer S21 XP,
13,5 J/TH, 7,5 ct/kWh; Annahme US-Cent, Euro-Cent umschaltbar).
- Eigene Datenbank `makro.db` neben `hl_liq.db`, geschrieben nur vom Makro-Takt im Dashboard-Prozess (`BEGIN IMMEDIATE`), gesichert
  mit dem täglichen Backup.
- Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor, kein Hyperliquid-API-Gewicht. Fusion, v3 und Kaskaden
  unberührt (Zusage bis 25.10.).
- Im Paket außerdem U120 (v2-Kachel misst den Brier-Skill gegen denselben Kalibrierschritt mit c = 0) und U122 (Selbsttest
  „Recorder: Masterregel ohne Kleinfills“ lief mit der echten Uhr und ist seit 05.10. rot -- auch mit 23.46; das System rechnet
  richtig).

Lehren:
1. **Tests mit festen Daten brauchen eine feste Uhr.** Eine vorläufige Sperre „vor dem 29.09.“ war am Tag des Schreibens 2 Tage
   alt, am 05.10. 7 Tage: Die Sieben-Tage-Regel gab sie frei, der Test wurde rot. Das Muster (U34/U36) war bekannt.
2. **Freie Quellen fallen still aus.** Verschwindet eine Metrik oder ändert eine Seite ihr Format, antwortet der Abruf oft
   weiter fehlerfrei. Deshalb prüft der Makro-Stand das Alter jeder Reihe und meldet Reihen, die nach einem erfolgreichen Abruf
   fehlen. Das war mein eigenes Abnahmekriterium; ich habe es erst beim Schreiben der Doku als fehlend bemerkt und nachgebaut.
3. **Anlauf verwerfen, bevor man Extremwerte vergleicht:** Das MVRV beginnt 2010 mit 146 (Anlauf der realisierten
   Kapitalisierung). Erst mit 180 verworfenen Tagen stimmen die Epochen-Hochs mit der Literatur.
4. **Ein Modul, das ein anderes im Speicher hält, liefert nach dem Kopieren noch die alte Fassung:** Der lokale Testserver
   lieferte `/makro.js` nach einer Änderung weiter aus dem schon importierten Modul. Nach Änderungen an `hl_makro_js.py` den
   Dienst neu starten (auf dem Pi tut das das Update).

**Nachtrag 05.10. (23.48):** Erster Pi-Lauf des Makro-Charts (Bild des Tabs „Daten“, 12:14; UEBERGABE 3ρ, U123–U125).
- Die meisten Quellen laufen, ihre Formate sind belegt.
- FRED hängt ohne Schlüssel (`fredgraph.csv` antwortet seit Mitte August 2026 vielerorts nicht). Jetzt läuft FRED über die
  offizielle API mit kostenlosem Schlüssel. Der Nutzer trägt ihn im Makro-Tab „Daten“ ein, er landet in `accesstokens.json` →
  `"fred"`.
- Antwortet ein Host nicht, überspringt der Takt die übrigen Ziele dieser Quelle in der Runde. Vorher hielten 12 × 45 s den Takt
  9 Minuten an.
- BGeometrics liefert frei mit 7 Tagen Verzug: Frische-Grenze 9 Tage, Hinweise in Kohorten und Zonenkarte.

Lehren:
1. **Erreichbarkeit ist nicht Format.** Das Abrufwerkzeug der Sandbox liest Seiten, die ein Skript auf dem Pi nicht bekommt.
   Neue Quellen erst nach dem ersten echten Abruf auf dem Pi als belegt führen.
2. **Kein Ziel darf den Takt anhalten:** kurze Wartezeit, Abbruch je Quelle, Pause mit Verdopplung.
3. **Freie Stufen genau lesen:** Verzug, Fenster und Kontingent sind drei verschiedene Grenzen.

**Nachtrag 05.10. (23.49):** Makro-Signale (UEBERGABE 3σ, U126, `KONZEPT_Makro.md` Abschnitt 9). Auf Wunsch des Nutzers je Chart mit
Referenzlinie (14 Paare) und Zeitraum (1/2/4/8 J, alles): Abweichung in %, Median, ideale Wendepunkte im Rückblick, Live-Signal
(unterstes/oberstes Zehntel des Zeitraums, nur Daten bis zum Tag), Bilanz gegen Zufallstage, Prognose „Rückkehr zum Median“ mit
80-%-Band; täglich, Tagesstand in `mk_signal`.
- Neues Modul `hl_makro_signal.py` (reine Rechnung); `hl_makro.py` rechnet es einmal je Datentag, archiviert und vergleicht das
  Archiv mit der Nachrechnung („Live gegen Nachrechnung“).
- Auf echten Daten (bis 23.05.2026): 3 von 322 Bilanz-Tests belegt, der Zufall allein ließe etwa 16 erwarten. Die Zonen beschreiben
  eine Lage, sie sagen keine Rendite voraus; Verkaufssignale kamen zu früh (Momentum). Die Prognose schlägt „die Abweichung
  bleibt“ in 78–83 % der Fälle, ihr Band traf 81–85 %.
- Fusion, v3 und Kaskaden unberührt (Zusage bis 25.10.).

Lehren:
1. **Signifikanz erst auf Zufallswegen kalibrieren.** Ein Block-Bootstrap über alle Signaltage erklärte 26–41 % der Zufallstests für
   belegt: Läufe, in denen der Kurs weiter fällt, sind länger und zählen mit mehr Tagen. Episoden mit lokalem Placebo: 3,2 %.
2. **Ein Band aus Fehlern, die man am Ursprung nicht kannte, bestätigt sich selbst.** Der Test dafür braucht wachsende Schwankung;
   bei gleichbleibender trifft auch das falsche Band 80 %.
3. **Texte sind Behauptungen.** „So wie es damals sichtbar war“ stimmt nur ohne Datenrevision. Jetzt prüft das Archiv es täglich.

**Nachtrag 05.10. (23.50):** OI-Chart baute sich nicht auf (Bild 16:04; UEBERGABE 3τ, U128). Binance-REST liefert nur 30 Tage, das
Archiv lief ab 2020 vorwärts; im Zeitraum 4 J war deshalb nur ein Strich am rechten Rand zu sehen. Jetzt lädt das Archiv
rückwärts (jüngste Tage zuerst), unter dem Chart steht der Ladestand, und die Zonenkarte zeigt kein OI-Perzentil, bis die
Historie vollständig ist.

Lehre: **Den halb geladenen Zustand ansehen.** Ich hatte die Charts leer und voll geprüft, nicht im Zustand nach den ersten
Stunden auf dem Pi.

**Nachtrag 05.10. (23.51):** Im Makro-Überblick steht unter der Zonenkarte „Verlauf je Indikator“: je Zeile ein kleiner Chart der Reihe
hinter der Zahl (UEBERGABE 3υ, U129). Die Probe vergleicht jeden Punkt mit der Ableitung, nicht nur den letzten -- mit konstanten
Testdaten (Funding) wäre eine vertauschte Reihe sonst unentdeckt geblieben.

**Nachtrag 05.10. (Plan, nur Dokumente):** U130 „Makro × Kurs“ -- Wunsch des Nutzers, am 25.10. auszuwerten. Die Tests stehen vorab
festgelegt in `KONZEPT_Makro.md` Abschnitt 10 (Teil A: Makro gegen BTC-Rendite vorwärts über die ganze Historie; Teil B: Makro-Regime
gegen die 4-h-Prognosen). Wer die Auswertung baut: zuerst Abschnitt 10 lesen und nichts daran ändern, was das Ergebnis begünstigt.

**Nachtrag 05.10. (23.52):** U130 Teil A gebaut (`hl_makro_korr.py`, UEBERGABE 3χ, `KONZEPT_Makro.md` 10.4): Makro-Merkmale gegen die
BTC-Rendite der folgenden 1, 7 und 30 Tage, Debug-Bericht, Berichte 06.10. und 25.10.

Lehre: **Ein Nullverfahren erst zählen, dann glauben.** Die im Plan genannte zirkuläre Verschiebung „erhält die Autokorrelation“ und
war trotzdem zu großzügig (6,5 % statt 5 %, bei Perzentilen 8,7 %), der Blockbootstrap noch mehr. Erst 4.050 Tests auf Zufallswegen
zeigten es; ein erster Lauf mit 720 Tests schwankte zu stark für ein Urteil. Phasen-Surrogate halten 5,4 %.

**Nachtrag 05.10. (23.53):** Nutzerfund 20:42: Unter „Vorbedingungen“ stand „vor Rückgängen noch zu wenige Ereignisse“, obwohl der
Chart mehrere Rückgänge über 3 % zeigte (UEBERGABE 3ψ, U131). Ursache: Bezugskurs war nur die erste Prognose je 4-h-Block, und
Ereignisblöcke bis 24 h auseinander wurden verkettet. Jetzt zählt jede gespeicherte Prognose (15 min), ein Ereignis ist eine
Bewegung; die Anzeige listet die erfassten Ereignisse, der Debug-Eintrag „★ Vorbedingungen: Ereignisliste“ gleicht sie mit den
Kursdaten ab. Basis und Konstellationen sind bitgleich geblieben.

Lehre: **Einen Ereigniszähler gegen das prüfen, was der Chart zeigt.** Der Nulltest sagte seit 23.7 „bestanden“ -- er prüft nur,
dass Rauschen keinen Lift erzeugt, nicht, ob die Ereignisse vollständig sind. Ein grobes Raster (4 h) verkleinert Bewegungen
systematisch, weil sein Beginn fast nie am Hoch liegt.

**Nachtrag 05.10. (23.54):** Wunsch 22:21: Makro-Charts mit dem BTC-Kurs (orange) überlagern, um Korrelationen zu erkennen
(UEBERGABE 3ω, U132). Gebaut als **Kursleiste**: unter jedem Kennzahl-Chart ein eigenes Feld mit dem Kurs (eigene log. Skala,
dieselbe Zeitachse, gemeinsames Fadenkreuz, Tooltip und Tabelle mit Kurs), Schalter „BTC-Kurs“. Keine zweite y-Achse im selben
Feld: Deren freie Skalierung macht fast jede Reihe im Bild gleichläufig. Gleichlauf im Bild ist bei Kennzahlen aus dem Kurs ohnehin
mechanisch; ob eine Kennzahl vorhersagt, misst U130.

Lehre: **Eine Anzeige gegen Quellen außerhalb ihres Codes prüfen.** Die Browserprobe vergleicht den Tooltip mit dem Rohkurs in
`makro.db` und die Pfadhöhe mit der beschrifteten Skala; Sollwerte aus denselben JS-Funktionen hätten einen Zeitversatz der Leiste
bestätigt. Und eine Reihenprüfung prüft Anfang UND Ende -- die Server-Prüfung sah zuerst nur den Anfang.

**Nachtrag 05.10. (23.55):** Nutzerfund 23:18 mit zwei Fotos: Die Treiber-Hygiene nannte acht BTC-Treiber „tot“, die nur selten
aktiv sind oder erst seit Kurzem rechnen (UEBERGABE 3αα, U133). „tot“ hieß bis 23.54 jeder Treiber mit Werten in weniger als 20 % der
Zeit -- inaktive Treiber werden nicht gespeichert, also traf das genau die Ereignis-Treiber (Kapitulation, OI-Überhitzung …), dazu
Crowding-Trend 7 T und Kaskaden-Asymmetrie (jung) und Funding (immer da, fast 0). Jetzt zählen ihre aktiven Zeiten als Fälle; reicht
das nicht, steht „kein Urteil“ mit Grund. Neu sind die Spalten Fälle, aktiv und zuletzt sowie ein Intervall zu jedem r.

Lehre: **Bei Ereignis-Treibern heißt „kein Wert“ „kein Ereignis“.** Eine Prüfung, die Anteile oder feste Raster zählt, muss das
wissen. Und ein Befundwort wird benutzt: „tot“ ging am 30.09. in die Entscheidung U97 ein (Elite). Deshalb nur Wörter, die die
Messung trägt.

**Nachtrag 06.10. (nur Dokumente, U134):** Warum v1 nur 3 von 33 Gewichten „lernt“ -- bewertet mit der exakten v1-Rechnung
(UEBERGABE 3ββ). v1 teilt die Treibersumme durch die Prior-Summe 18,6, klemmt Gewichte auf 2 × Prior und verankert β; damit nutzt
es nur rund 6 % eines starken Einzelvorsprungs. Schwellen senken oder Fenster verlängern ändert daran nichts, erzeugt aber mehr
scheinbar gelernte Rauschgewichte. Empfehlung: am 25.10. die geplante Modellwahl, danach Ereignis-Experten und langes
Gedächtnis in der Fusion (`KONZEPT_Fusion.md` 5); die ehrliche Lernanzeige kommt mit dieser Erweiterung (Nutzer 06.10. 01:21).

Lehre: **Erst messen, ob ein Modell einen Vorsprung überhaupt ausdrücken kann, dann an seinem Lernen drehen.**

**Nachtrag 06.10. abends (nur Dokumente, Berichtsbündel 21:10):** Erste Pi-Läufe mit allen Quellen (UEBERGABE 3γγ). Makro × Kurs
(U130 Teil A): 0 von 45 Tests belegt, wie die Vorschau; bei 30 Tagen ist die Null so breit, dass nur sehr starke Zusammenhänge
belegbar wären. Die Nachrechnung meldet DVOL und ETF-Fluss „abweichend“, weil die Zonenkarte am offenen Tag festgeschrieben wird
-- kein Rechenfehler, ohne Folge fürs Urteil. Vorbedingungen (U131): 181 von 205 Kursdaten-Bewegungen erfasst, der Rest liegt im
Nachbarereignis oder knapp unter 3 % vom 15-min-Prognosekurs. Eigener Fehler: Die Begründungszeile des Abgleichs misst nur die
24 h vor dem Extrem und lässt lange Bewegungen größer wirken als den Schwellenrand, der sie verfehlte. Makro-Signale (U126):
4 von 336 Tests belegt, weniger als der Zufall liefert. Vier Berichtskorrekturen als U135 vorgemerkt (reine Anzeige).

Lehre: **Eine Begründung muss dieselbe Spanne messen wie die Regel, die sie erklärt; und eine Nachrechnung muss Gleiches mit
Gleichem vergleichen -- ein am offenen Tag festgeschriebener Wert ist kein Widerspruch.**

**Nachtrag 06.10. (23.56):** U135 gebaut (UEBERGABE 3δδ), reine Anzeige. Die Begründung „nicht erfasst“ im Kursdaten-Abgleich
misst jetzt alle Prognosepunkte vom Beginn bis zum Extrem mit ihrer eigenen 24-h-Bewegung und nennt den Docht; auf der Probe
wie BTC 11.09. stand vorher „-0,7 %“, jetzt „-2,7 %, 15-min-Hoch 0,6 % über dem höchsten Prognosekurs“. Die U130-Nachrechnung
führt DVOL und ETF-Fluss, wenn sie am offenen Tag festgeschrieben wurden, als vorläufig statt als Widerspruch. Der Makro-Stand
hat eine Summenzeile der Signale (belegt N von M, Zufallserwartung, Live-Signale mit Beleg der eigenen Seite). Mutationen 19
von 19 rot. Dazu die Nutzerfrage „Darwin-Aufnahme bei Glück < 3 %?“ bewertet (U136): Im heutigen Pool erwartet der Zufall bei
3 % 1,2 Aufnahmen, beobachtet sind 2; in der Simulation der Regeln v3 steigen die Zufallsmitglieder von 1,9 auf 4,9, Könner
werden nur besser abgedeckt, wenn sie selten sind. Empfehlung: 1 % lassen, Beinahe-Aufnahmen im Schatten vorwärts verfolgen.

Lehre: **Eine Schwelle über viele Konten ist ein Mehrfachtest. Lockern macht eine Liste größer, nicht besser, solange der
Pool kein belegbares Können enthält.**

**Nachtrag 07.10. (23.57):** U136 gebaut (UEBERGABE 3εε, `KONZEPT_Aktive_Profis.md` 11), auf Wunsch des Nutzers („ja“ zur
Beobachtung). Die Darwin-Aufnahme bleibt bei Glück ≤ 1 %; ein Schatten verfolgt vorwärts, wie die Beinahe-Aufnahmen (Glück
1–3 % und 3–5 %), die Aufnahmen selbst und eine Kontrollgruppe aus demselben Pool (Glück über 5 %) danach treffen. Das Urteil ist
vorab festgelegt: am 18.11.2026 (sonst 16.12.) „Timing belegt“ nur, wenn das Band 1–3 % mindestens 5 Punkte öfter trifft als die
Kontrolle (p < 0,05, ≥ 60 Entscheidungen aus ≥ 3 Konten, auch ohne jedes einzelne Konto). Die Kontrolle ist nötig, weil Konten
eher in bewegten Phasen handeln: Gegen die Zufallsquote allein sähe man dann in der Simulation in einem Viertel bis einem Drittel
der Fälle „Timing“, das keines ist. Liste, Labor und Familien sind unberührt. Dabei berichtigt: Eine Aufnahme nach v4 bekäme die
Labor-Kennung `liste=4`, nicht `liste=3` (eigener Fehler in 23.56).

Lehre: **Vorwärts zählen, die Gruppe beim Eintritt festhalten und gegen eine Kontrolle aus demselben Pool vergleichen -- sonst
misst man die eigene Auswahl oder den Zeitpunkt des Handels.**

**Nachtrag 07.10. abends (23.58):** Wochenbündel 19:44 ausgewertet (UEBERGABE 3ζζ). Dabei ein eigener Fehler aus 23.56 gefunden
und berichtigt (U137): Die Begründung „nicht erfasst“ im Kursdaten-Abgleich der Vorbedingungen maß nur noch die Prognosepunkte
zwischen Beginn und Extrem. Punkte davor, die die Bewegung schon gesehen hatten, fielen heraus. Im Bericht standen deshalb neun
ZEC-Bewegungen als „höchstens −2,1 … −2,9 %“ statt „im benachbarten Ereignis enthalten“, ein 1-min-Anstieg bei XMR als „keine
Prognose gespeichert“ (las sich wie eine Lücke der Ablage) und eine Zahl zu klein (+2,1 statt +2,8 %). Gefunden durch den Vergleich
mit dem Bericht vom Vortag, Zeile für Zeile. Jetzt zählen beide Mengen; die Proben (a2) und (i)–(n) prüfen genau diese Fälle, zwei
davon über die ganze Kette; Mutationen 19 von 19 rot. Die Zählung war nie betroffen. Dazu reine Anzeige: Die Schatten-Tabelle zeigt
„Konten (mit Entsch.)“ in einer Spalte. Befunde: BTC 11.09. ist ein Schwellenrand (−2,99 %, Docht 0,8 %); der Pool-Flow 4 h liegt
vor Rutschen wie vor Anstiegen leicht über normal (je 12 Fälle, noch nicht testbar); die Makro-Summenzeile stimmt nachgezählt;
der Schatten trägt ein, erste Zahlen ab 09.10.

Lehre: **Wer eine Begründung umbaut, prüft die Fälle der alten mit. Eine Probe deckt nur ab, woran man gedacht hat; der Vergleich
alter und neuer Bericht Zeile für Zeile zeigt, was verloren ging.**

**Nachtrag 07.10. spät abends (nur Dokumente, 23.58 unverändert):** Konzept Regime-Modul (U138, UEBERGABE 3ηη,
`KONZEPT_Regime.md`, Recherche `RECHERCHE_Regime_07-10-2026.md`), auf Wunsch des Nutzers: die jüngsten 4–8 Wochen „rückwärts“
lesen und daraus nächste Schritte ableiten (mehrtägige Stufen mit Rücksetzern zu höheren Tiefs, Uhrzeit- und Wochentagsmuster).
Recherche und Zufallsweg-Simulation zeigen: Vorhersagbar sind Größe und Zeitpunkt der Bewegungen, kaum ihre Richtung. Beine von
2–3 Tagen und höhere Hochs nach höheren Tiefs in zwei von drei Fällen liefert schon der Zufall. Uhrzeit- und Wochentagsmuster der
Richtung sind in 4–8 Wochen nicht von Zufall zu trennen (Nachweisgrenze einer Stunde in 8 Wochen 17–21 bp, dokumentiert sind
rund 4–5 bp). Das Konzept: Die Historie schätzt, das Fenster filtert; acht Bausteine R1–R8 (Schwankungsprofil mit zwei Uhren,
Bewegungsgröße 1–7 Tage, Regime-Zustand, Stufen gegen die Zufallsgeometrie, vorab festgelegte Kalenderhypothesen, Wochenmomentum,
Teilnehmer an den Wendepunkten, Regime-Analog und Pfadfächer), zwölf Anzeigen RG1–RG12, Prüfplan vorab, Phasen 0–3. Nichts ist
gebaut; die Entscheidungen 1–7 liegen beim Nutzer (Empfehlung: Phase 0 zuerst, ein Debug-Bericht auf der Historie). Die Zusage
bis 25.10. bleibt unberührt.

Lehre: **Was man in kurzen Fenstern „sieht“, erzeugt der Zufall oft schon. Jede Fensterstatistik braucht ihre Zufallsweg-Null in
derselben Auflösung, und jede Suche über Fenster ihre Bereinigung.**

**Nachtrag 08.10. nachts (23.59):** Regime-Modul Phase 0 gebaut (U138, UEBERGABE 3θθ), auf Wunsch des Nutzers („Lass uns mit Phase
0 beginnen“). `hl_regime.py` rechnet die vorab festgelegten Prüfungen P0.1–P0.9 auf bis zu drei Jahren 30-min-Kerzen je Coin und
gibt einen Debug-Bericht aus („★ Regime: Vorprüfung auf der Historie (U138)“, geplant 08.10. 21:00). Die Kerzen liegen in einer
eigenen Datei `regime.db` (Binance-Futures oder Bybit, je Coin festgehalten); `klines30` bleibt unberührt, weil die Analog-Suche
der Prognose sie liest. Vor dem ersten echten Lauf wurden die Bedingungen in `KONZEPT_Regime.md` 9.1a präzisiert und an sieben
Stellen begründet geändert, wo Nullen oder Positivkontrollen eine Schwäche zeigten (z. B. muss das Regime-Analog auch den Zufallsweg
mit σ̂ schlagen; PBO ist bei fast gleichen Varianten keine brauchbare Bedingung). Selbsttest 27 Prüfungen, Mutationen 29 von 31
rot (zwei ohne Wirkung auf die Urteile). Das Ergebnis auf echten Daten steht aus.

Lehre: **Eine Vergleichsprobe muss zählen, wie viele echte Werte sie verglichen hat. Die erste Kausalitätsprobe für Fixed Share
verglich nur fehlende Werte und hätte jeden Blick in die Zukunft durchgelassen; erst eine Mutation zeigte es.**

**Nachtrag 08.10. nachts (23.60):** Erster echter Lauf der Regime-Vorprüfung ausgewertet (Bericht 02:06 mit 23.59; UEBERGABE 3ιι,
`KONZEPT_Regime.md` 9.4).
- **Belegt:** nur Kalendereffekte bei XMR (K1 +12,3 ± 4,9 bp, also steigend statt „fällt“; K3 −82,6 ± 15,9 bp; drei
  UTC-Stunden; Persistenz des Stundenmusters) und bei PAXG (K3 −13,5 ± 4,0 bp), dazu die Fensterkombination bei ZEC und XMR.
- **Nicht belegt, also nicht vorhersagbar:** die Richtung über Stunden bis Tage. Beine sind Zufallsgeometrie, D/θ ist kalibriert,
  es gibt kein Momentum, Analoge sind nicht besser als der Zufallsweg mit σ̂, und der Bruchmelder meldet eine Verdopplung erst nach
  51–366 h.
- **Tragfähig ist die Größe:** HAR schlägt EWMA bei 1 Tag in allen sechs Coins; ein glattes Tagesprofil schlägt das heutige
  Zellenprofil in 5 von 6.
- **Eigener Fehler 23.59 (U139):** K3 verglich die 6,5-h-Sitzung mit dem ganzen Rest (im Mittel 27,1 h) und maß so die Drift mit.
  Seit 23.60 vergleicht K3 je Stunde; jede feste Drift hebt sich genau auf. Das Urteil zu K3 liefert der Lauf 08.10. 21:00.
- **Vorschlag:** Vorhaltetest auf 10/2020–10/2023 für das, was getragen hat; danach Phase 1 schlank. Entscheidungen beim Nutzer.

Lehre: **Wer Zeitfenster ungleicher Länge vergleicht, misst die Drift mit. Jeder Fenstervergleich braucht einen Nulltest mit Drift,
und eine Gleichheitsprobe einen Testmarkt, in dem sich Fehler nicht paarweise aufheben (drei Frühjahrs- gegen drei
Herbstumstellungen verdeckten eine übergangene Zeitumstellung).**

**Nachtrag 08.10. vormittags (23.61):** Swing-Trades (U140, UEBERGABE 3κκ, `KONZEPT_Swing.md`), auf Wunsch des Nutzers („Swing-Trades
in das System inkludieren … mehrere bestmögliche Strategien in das TradeLabor“).
- **Regeln vorab, nichts optimiert:** Entscheidung einmal je Tag nach 00:00 UTC, Größe nach Risiko (100 USD bis zum Stop). S1
  Trend-Ausbruch, S2 Rücksetzer im Trend, S3 Ausbruch nach Ruhe, S4 Gegenbewegung nach Übertreibung mit Funding-Druck; Kontrollen
  Zufall und Zufall im Trend.
- **Gebaut:** `hl_swing.py` mit eigener `swing.db` (Binance-Futures ab 2020, Swing-Takt im Dashboard); dieselben Funktionen für die
  Vorprüfung auf der Historie und das TradeLabor (sechs neue Kennungen, die 38 alten unverändert); Debug-Bericht „★ Swing: Vorprüfung
  auf der Historie (U140)“, geplant 08.10. 21:30 und 09.10. 07:30.
- **Urteil vorab:** ≥ 60 Trades, Tagesergebnis p < 0,05 und positiv, Mehrertrag gegen ein Zeitpunkt-Placebo nach Holm < 0,05, beide
  Hälften, DSR ≥ 0,95. Vor dem ersten echten Lauf geändert: Der Placebo-Vergleich ist studentisiert (Standardfehler aus der
  Tagesreihe). Der Rang unter den Placebo-Läufen war auf Nullmärkten nicht kalibriert (S4: 25 % statt 5 % unter 0,05).
- **Proben:** Selbsttest 20 Prüfungen, Labor-Proben (gleiche Tage wie die Historie, Signal-Ausstieg ohne Pause), Mutationen 33 von
  34 rot (eine gleichwertig), Nullreplikationen 0 von 160 belegt, Kalibrierung auf Märkten mit echtem Pfad in der Kerze.

Lehre: **Ein Rang gegen Placebo-Läufe gilt nur, wenn die Trades der Strategie unter der Null so streuen wie die des Placebos. Wer
nach starken Bewegungen einsteigt, wählt eine andere Schwankung; dann den Mehrertrag mit dem eigenen Standardfehler prüfen. Und:
Synthetische Kerzen ohne echten Pfad in der Kerze verzerren jede Simulation mit Stops und Zielen.**

**Nachtrag 08.10. spät abends (nur Dokumente, 23.61 unverändert):** Berichtsbündel 22:44 ausgewertet (UEBERGABE 3λλ).
- **Erste Swing-Vorprüfung (`KONZEPT_Swing.md` 6b): nichts belegt.** Die beiden Ausbruchsregeln sind positiv: S3 Ø +0,34 R je
  Trade (Sharpe 0,72, p 0,10, in allen Coins und Jahren positiv), S1 +0,17 R (Sharpe 0,49). Beides ist auf sechs Jahren nicht von
  Glück zu trennen. S2 liegt nahe null (Rücksetzer kaufen ≈ irgendwann im Trend kaufen), S4 verliert. Alle sechs Strategien laufen
  im Labor weiter. Neu zur Entscheidung: ein Vorhaltetest in der Breite (S1 und S3 auf weiteren Binance-Perpetuals).
- **Zweiter Regime-Lauf (`KONZEPT_Regime.md` 9.5):** Die K3-Abschätzung traf (XMR −45 bp belegt, BTC −10, ETH −23, PAXG −5
  nicht mehr belegt). P0.3-Urteile an der Holm-Grenze kippen mit einem Tag mehr Daten. Die Analog-Suche der Prognose ist bei
  72 h und 7 Tagen schlechter als der Zufallsweg (ETH, ZEC, HYPE); vorgemerkt für nach dem 25.10.
- **U126:** Live gegen Nachrechnung 192 von 192 gleich.

Lehre: **Urteile an der Holm-Grenze kippen schon mit einem Tag mehr Daten; sie zählen erst nach einem Vorhaltetest. Und eine vorab
notierte Abschätzung, die eintrifft, zeigt am besten, dass eine Korrektur das Richtige misst.**

**Nachtrag 09.10. nachts (23.62):** Zyklus-Studie und „Dip halten“ (U141, UEBERGABE 3μμ, `KONZEPT_Zyklen.md`), auf die Frage des
Nutzers (08.10. 23:45: „Dump bestätigt → kaufen, laufen lassen, vor dem nächsten Rücksetzer raus; wie lange, nach wie vielen
Prozent, welche Signale, was ist am sichersten?“).
- **Studie** `hl_zyklus.py` (nur lesend, Debug „★ Zyklen …“, Berichtsplan 09.10. 12:00): Teil A Rallyes und Rücksetzer bei
  10/20/30 % gegen 1000 Zufallswege mit derselben Drift und Schwankung; Teil B HODL, T200, VOL, Z1 Dip halten, Z2 Überhitzung,
  Z3 typisches Ziel, Z0 Zufall mit den Urteilen Timing und sicherer als HODL; Teil C Warnsignale (OI, Funding, RSI, Gier); Teil D
  Gegenprobe mit Ausführung; oben der aktuelle Stand je Coin.
- **Labor:** drei neue Strategien in der Gruppe „Swing“ (`zyklus_dip`, `zyklus_dip_heiss`, `zyklus_dip_zufall`), 44 alte Kennungen
  unverändert; dieselben Regeln wie die Studie (`hl_swing`, Art „dip“), Tag für Tag gleich geprüft.
- **Vor dem ersten echten Lauf geändert:** Teil A urteilt gepoolt je Schwelle (Mittelwert) statt je Coin und Schwelle (Median) —
  die Beingröße eines Zufallswegs hängt nicht an der Schwankung, und der alte Test erkannte selbst starke Struktur kaum.
- **Labor „überall Minus“:** kein Rechenfehler, Kosten (Stand 07.10.: 3.580 Trades, netto −72.792 USD, Gebühren 26.081).

Lehre: **Ein Test der Beingröße ist blind für Schwung von Tag zu Tag; Struktur muss man auf der Skala prüfen, auf der man fragt.
Mit Surrogaten und Holm muss die Zahl der Surrogate zur Zahl der Tests passen. Und wer eine Regel zweimal rechnet (schnell über
viele Pfade und Tag für Tag im Labor), prüft beide gegeneinander.**

**Nachtrag 09.10. nachts (nur Dokumente, 23.62 unverändert):** Bewertung der Nutzerfragen (02:05) zu Fear & Greed, Binance-Top-Tradern
und Market Makern, Hebel gegen Spot und einem Chart-Analyse-Trader (UEBERGABE 3νν; ausführlich mit Quellen im Projekt-Dokument
`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md`, nicht im Paket).
- **Zugang ist kein Problem:** Fear & Greed seit 2018, die vier Binance-Verhältnisse (darunter Top-Trader = die 20 % größten Konten
  nach Margin, nicht die besten) alle 5 min, Binance-Buch, Liquidationen von Binance, Bybit und OKX. Das Binance-Archiv „metrics“
  mit denselben Verhältnissen ab 2020 lädt `hl_makro` schon für BTC, behält aber nur das OI.
- **Offen ist der Nachweis:** Bisher beschreiben die Daten Größe und Risiko, kaum die Richtung (U130 0/45, Magnet, Anker, Labor).
  Drei Konfluenz-Regeln mit Binance-Verhältnissen wurden nie einzeln geprüft.
- **Vorgemerkt:** U142 Positionierung und Hebel (Studie, H1–H4, darunter die 95-%-Regel des Nutzers als Deleveraging-Test), U143
  Chart-Trader in drei Stufen (Chartbild, Niveau-Test an echten Orderniveaus, Labor-Familie). Bau nach der U141-Auswertung, nur mit
  Zustimmung.

Lehre: **Gesammelte Daten sind noch kein Signal, und „fast immer“ braucht eine Basisrate. Mehr Filter machen einen Backtest schöner
und den Nachweis schwerer.**

**Nachtrag 09.10. nachts (23.63):** Hebel-Studie gebaut (U142, UEBERGABE 3ξξ, `KONZEPT_Hebel.md`), auf die Frage des Nutzers
„Warum machst du heute Nacht nichts?“ (02:48) — mein Grund (erst das U141-Ergebnis abwarten) war schwach: U142 hängt nicht daran,
und Regeln davor festzuschreiben ist sauberer; der Archiv-Download auf dem Pi ist der Engpass.
- **Daten:** eigene `hebel.db`; Binance-Archiv „metrics“ (OI, Top-Trader, Konten, Taker; eine Zeile je Stunde) ab 01.09.2020 für
  fünf Coins, Tageskerzen von 21 Symbolen (Spot, USDⓈ-M, COIN-M) ab 2020; Hebel-Takt lädt im Hintergrund; Sicherung der Bybit/OKX-
  Liquidationen und der Binance-Buchtiefe vor ihrer Vorhaltefrist.
- **Prüfungen vorab:** H1 Konten ≥ 3 → Rücksetzer (Vorzeichen-Surrogate), H2 Top-Trader-Regel der Konfluenz → Richtung (zweiseitig),
  H3 Perp-Anteil ≥ 95 % und H4 oberstes Zehntel → Liquidationswelle (OI in Coins + Ausschlag; Zeitverschiebung 30–365 T). Urteil nur
  mit vollständiger Historie. Nachweisgrenze RR um 2.
- **Prüfung des Programms:** 51 Selbsttest-Prüfungen, Nullreplikationen, Trend-Null, Trennschärfe, Mutationen 26 von 26 rot.
- Konfluenz, Labor, Prognose, Fusion, v3, Kaskaden, v1 und `hl_zyklus` unverändert. Bericht 10.10. 08:15 (sonst 11.10. 08:15).

Lehre: **Eine Risikofrage braucht ein anderes Nullmodell als eine Richtungsfrage — Vorzeichen-Surrogate behalten die Schwankung und
hätten ein reines Risikosignal unsichtbar gemacht. Ein zweiseitiger Test braucht Positivkontrollen in beiden Richtungen.**

**Nachtrag 09.10. mittags (nur Dokumente, 23.63 unverändert):** Erster Lauf der Zyklus-Studie (U141, 12:00) ausgewertet
(UEBERGABE 3οο, `KONZEPT_Zyklen.md` 14): **nichts belegt.** Rallyes und Rücksetzer wie ein Zufallsweg mit derselben Drift und
Schwankung; „Dip halten“ schlechter als HODL und bei BTC/ETH sogar unter zufälligen Einstiegen mit denselben Ausstiegen; T200 am
nächsten an einem Beleg (Sharpe 1,47 gegen 1,27 im Kern, p Holm 0,53); kein Warnsignal (OI-Überhitzung RR 1,6 nur Hinweis; nach Gier
≥ 80 und Funding-Druck weniger Rücksetzer). Folge vorab: HODL im Kern bleibt der Maßstab, kein Timing-Werkzeug. 23.63 freigegeben.

Lehre: **Eine plausible Handelsidee kann schlechter sein als Zufall — die Kontrolle mit denselben Ausstiegen gehört in jeden
Vergleich.**

**Nachtrag 10.10. mittags (23.64):** Erster Lauf der Hebel-Studie (U142, 08:16) ausgewertet (UEBERGABE 3ππ, `KONZEPT_Hebel.md`
13): H1 „Konten ≥ 3 → Rücksetzer in 7 Tagen“ erfüllt die Bedingung (RR 2,77, 90 %: 2,10–3,73; 20,3 % gegen 7,4 %; p Holm 0,006,
beide Hälften, jeder Coin und jedes Jahr), H2 „Top-Trader-Regel → Richtung“ nicht (p 0,148; die Regel steht fast immer auf „Kauf“),
H3/H4 ohne Daten — **mein Ladefehler**: `hb_dateien` merkte Kerzendateien ohne Markt, sechs Spotpaare mit dem Namen eines Perps
(BTC/ETH gegen USDT, USDC, BUSD) galten als geladen, der Ladestand meldete fälschlich „vollständig“; deshalb alle Urteile vorläufig.
23.64: Schlüssel „markt:symbol“ mit einmaliger Umstellung beim ersten Öffnen, Ladestand gegen die Zeilen („Widerspruch“),
Ende-zu-Ende-Probe über den Lader; H1 beschreibend ergänzt (Stand 1 h und 24 h früher, Schichtung nach der Rendite der 7 Tage
davor mit Lesart vorab — die Vorzeichen-Surrogate sind blind für Momentum: auf Momentum-Märkten roh 30 von 30 „signifikant“,
geschichtet 0 von 30). H1–H4 rechnen unverändert (identisch zu 23.63 auf fünf synthetischen Märkten). `hl_swing.py` nur Text.
Selbsttest 63 Prüfungen, Mutationen 37 von 37 rot. Endgültig mit dem Lauf 11.10. 08:15.

Lehre: **Eine Probe, die am Lader vorbei in die Datenbank schreibt, prüft den Lader nicht; „vollständig“ prüft man an den Zeilen,
die die Auswertung liest. Und ein Nullmodell, das Vorzeichen auslost, prüft Richtung gegen Schwankung, nicht gegen Momentum.**

**Nachtrag 10.10. spät abends (23.65):** U143 Stufe 1 „Chartbild“ gebaut (UEBERGABE 3ρρ, `KONZEPT_Chartbild.md`; Nutzer 22:16 „Wo
finde ich die Chart Analysen“, 22:20 „Ja“ zum Bau). Neuer Abschnitt „CB Chartbild“ nach dem Live-Chart: Lesart in fünf bis sechs
Sätzen, Tageschart (log. Skala; 50/200-Tage-Linie; Bein wie U141 mit Bestätigungsschwelle der Gegenrichtung; Swings; rechts von
„heute“ die Niveaus als Momentaufnahme mit Nummer und das 80-%-Band für heute und +7 Tage; RSI im eigenen Feld), Tabellen mit
Prüfstand je Zeile. Dieselben Rechnungen wie die Studien (`hl_zyklus`, `hl_regime.har_prognosen`, `hl_swing`, Tagesstände wie
`hl_hebel`, `load_stops`/`load_depth` wie der Live-Chart), nur lesend, kein Signal, wirkt auf nichts. Beim Bau geändert (9.1):
runde Zahlen 1/2/5, Swings ±30 %, PAXG „bewusst nicht gezeigt“, Kerzen hohl/gefüllt statt Rot/Grün (Prüfskript), Live-Teil je Teil
für sich (Kurs, Heatmap, Orders getrennt gelesen). Selbsttest 42 Prüfungen, Mutationen 51 von 51 rot, Browserprobe 13 von 13 Skript-Mutationen rot; nebenbei die Seitenbreite am Desktop behoben
(Debug-Auswahl 1.881 px). `install.py`: 38 Schritte, 11 Dashboard-Abrufe. Einspielen ab 11.10. 08:20 (nach dem U142-Lauf).

Lehre: **Eine Browserprobe prüft ihre Vorbedingung und misst gegen den Bildrand -- ohne frischen Kurs prüfte sie den Ersatzwert,
und relative Lagen sehen eine verschobene Zeitachse nicht. Farben einer Chartfläche wählt das Prüfskript, nicht das Auge.**

**Nachtrag 11.10. vormittags (nur Dokumente, 23.65 unverändert):** U142 endgültig (Lauf `u142-hebel-2` 08:16, Historie vollständig;
UEBERGABE 3σσ, `KONZEPT_Hebel.md` 13.5): **H1 belegt** -- Konten ≥ 3 → Rücksetzer in 7 Tagen 20,3 % gegen 7,3 % (RR 2,77, p Holm
0,012), auch geschichtet nach der Vorwoche (RR 2,52 gegen Null 1,56, p 0,012); in 4 von 5 Fällen folgte kein Rücksetzer. **H2 nicht
belegt** (p Holm 0,376). **H3 nicht prüfbar:** Der Perp-Anteil am Binance-Volumen lag bei BTC/ETH seit 2020 an keinem Tag bei 95 %.
**H4 nicht belegt**, Wellen nach hohem Perp-Anteil eher seltener (RR 0,53). Folgen vorab (Abschnitt 8) beim Nutzer: Hinweis mit Quoten,
Top-Trader-Punkt entfernen, U144, Abgrenzung der 95 %. Die Sammeldatei 08:25 meldete „2026-09-23.64 · a897c8e3c5“ -- 23.65 lag nicht
auf dem Pi, obwohl der Nutzer um 03:10 „läuft bereits“ schrieb.

Lehre: **Den Kopf jeder Sammeldatei (Version und Prüfsumme) vor der Auswertung lesen -- er zeigt, was wirklich lief.**

**Nachtrag 11.10. mittags (nur Dokumente, 23.65 unverändert):** Das Dashboard-Update auf 23.65 hing ab 12:35 in Schritt 2
(Datenbank-Sicherung, ~14 GB auf die SD-Karte); nichts verändert, der Pi läuft auf 23.64 (UEBERGABE 3ττ). Ursache ein eigener
Konstruktionsfehler: update.py sichert unter derselben Bedingung selbst, unter der auch der Recorder fällig ist (letzte gute älter als
24 h oder fehlgeschlagen, dann alle 30 min), beide ohne Sperre in dieselbe Zwischendatei -- eine scheitert, oder die neueste Sicherung
ist unvollständig unter „ok“. Dazu: Log gepuffert, zweiter Update-Klick lädt neu und leert das Log, „nächste in“ nach Fehlschlag
falsch, Debug-Logdatei veraltet. → U145 (23.66). Weg ohne Terminal: abwarten; Update nur bei Uhrzeit auf der Kachel
„Letztes Backup“, sonst erst „Jetzt sichern“. README „Aktualisieren“ berichtigt. 13:42: Fehlertext der Recorder-Sicherung
„disk I/O error“ (12:35:40–12:44) -- in der Sandbox nachgestellt: In 10 von 10 überlappenden Läufen scheitert die als zweite fertige
Kopie mit genau diesem Text (die andere hat die Journaldatei gleichen Namens gelöscht), die erste danach ebenfalls; kein Hinweis auf
Hardware. Dazu zwei weitere Fehler für U145: `backup.json` nicht atomar, fremdes „heißes Journal“ in der eigenen Kopie.
Die Recorder-Sicherung 13:26 lief allein durch; das alte Update endete mit „Abbruch“ beim Umbenennen. Zweiter Versuch bei grüner
Kachel: **14:10 läuft 23.65 auf dem Pi** (A1 ✓).

**Nachtrag 11.10. nachmittags (nur Dokumente, 23.65 unverändert):** Chartbild erster Lauf auf echten Daten (14:58; UEBERGABE 3υυ,
`KONZEPT_Chartbild.md` 9.2) stimmig, von Hand nachgerechnet. Fünf Nacharbeiten für 23.66: PAXG-Band fehlt (`regime.db` ohne
Nachlade-Takt), Satz „keiner dieser Werte hat ein Timing belegt“ seit U142 H1 falsch (auch im Dashboard-Hinweis und Modulkopf;
README und Konzept schon berichtigt), Mindestgröße der Cluster, „höchster Schluss“ im Bein-Satz, „-0,0 σ“.

Lehre: **Wird ein Urteil endgültig, alle „kein … belegt“-Sätze durchsuchen, nicht nur die Prüfstand-Tabelle. Jede Datenquelle
einer Anzeige braucht einen eigenen Nachlade-Takt.**

**Nachtrag 11.10. 17:00 (nur Dokumente, 23.65 unverändert):** U146 „Ausblick 4 Wochen“ vorab festgelegt (`KONZEPT_Ausblick.md`,
UEBERGABE 3φφ): Breite aus HAR je Horizont, Form aus echten normierten Pfaden ohne Trend (Szenarien genau), Richtung aus 31
Kandidaten mit Ridge im Walk-forward und Tor, Gewichte gegen zirkuläre Null mit Holm geprüft, Ziellevels mit Erreich- und
Schluss-Wahrscheinlichkeit. Bau mit 23.66 zusammen mit U145 und den Chartbild-Nacharbeiten (Wahl des Nutzers). Erwartung vorab:
driftfreier Fächer mit geprüfter Breite.

**Nachtrag 11.10. abends (nur Dokumente, 23.65 unverändert):** Auf Wunsch des Nutzers (17:49) wurde der Aktienmarkt recherchiert
(`RECHERCHE_Aktienmarkt_11-10-2026.md`) und ins Ausblick-Konzept eingebaut (`KONZEPT_Ausblick.md` 13, UEBERGABE 3χχ).
- **Befund:** „Fällt der S&P 500, fällt BTC immer“ ist falsch. Im jüngsten Jahr waren es 66 % der Verlusttage, 88 % unter −1 %,
  Ausnahmen in beide Richtungen.
- **Richtung:** Keine Aktiengröße sagt die BTC-Richtung über 1–4 Wochen außerhalb der Stichprobe voraus. Der Aktienmarkt trägt
  Breite und gemeinsame Szenarien.
- **Ergänzt sind:**
  - Takt alle 30 Minuten bei offenem Dashboard, stündlich im Hintergrund, sofort bei Schock;
  - HAR-X mit DVOL, S&P-Schwankung, Stress und VIX als geprüfte Zusätze;
  - S&P-Pfade als zweite Koordinate derselben Fenster, bedingte Szenarien mit Episoden-ESS und Kopula-Rückfall, Stressfächer;
  - vier Aktien-Kandidaten der Richtung;
  - Reiter „Aktienmarkt“, Archiv `aktien.db` (Hochzinsspread zuerst — FRED zeigt nur noch drei Jahre);
  - Studie U147 und Kurzstudie zu ETF-Flüssen.
- **Entschieden 18:55:** Aktienkurse rund um die Uhr über Hyperliquid HIP-3 `xyz` (Hinweis des Nutzers), Historie aus FRED;
  SEC-User-Agent `admin@localhost.com`; kein SoSoValue.

Lehre: **Eine starke Überzeugung des Nutzers wird nicht kodiert, sondern als eigene, vorab festgelegte Studie gemessen und
täglich als Tafel gezeigt. Gleichlauf ist keine Vorhersage: Aus ρ = 0,4 und einer schwer vorhersagbaren Aktienrichtung wird
für BTC fast nichts.**

Lehre: **Zwei Wege zum selben Ziel brauchen eine Sperre -- und ein Prüfkriterium, das beide gleichzeitig auslöst, macht die
Kollision zur Regel, nicht zur Ausnahme. Ein Log, das erst am Ende erscheint, sieht von außen wie ein Hänger aus.**

**Nachtrag 11.10. spät abends (23.66):** „Alles in 23.66“ gebaut (UEBERGABE 3ψψ).
- **Neue Dateien:**
  - `hl_ausblick.py` und `hl_ausblick_js.py`: Ausblick 4 Wochen (U146), eigene `ausblick.db`, Nachtrag `KONZEPT_Ausblick.md` 12.1.
  - `hl_aktien.py`: Aktien-Archiv (U148), eigene `aktien.db`, Studie U147 und K1/K2.
- **Geändert:**
  - `hl_recorder.py`: U145 Backup-Sperre, U149 `first_seen` in ms, U150 Audit-Einordnung.
  - `update.py`: wartet auf eine laufende Sicherung und übernimmt sie, Log zeilenweise.
  - `hl_viz.py`: Abschnitt „AU Ausblick“, Routen `/ausblick`, `/ausblick.js`, `/aktienmarkt`, Takte für Aktien, Ausblick und Regime,
    Update-Knopf prüft zuerst, Berichtsplan 12./13.10.
  - `hl_chartbild.py` und `hl_chartbild_js.py`: Nacharbeiten, `KONZEPT_Chartbild.md` 9.3.
  - `hl_regime.py`: Takt für PAXG.
  - `install.py`, `version.py`.
- **Ausblick in einem Satz:** geprüfte Breite (HAR-X), Form aus echten Pfaden ohne Trend, Richtung nur nach bestandenem Tor,
  Ziellevels mit Erreich- und Schluss-Wahrscheinlichkeit, bedingte Szenarien mit dem S&P 500 -- er wirkt auf nichts sonst.
- **Nullverfahren:** zirkuläre Verschiebung mit α 0,05 (Kalibrierung auf 100 Null-Universen: 5,4 % gegen Phasen 4,2 %;
  Schwanzprüfung auf 30 neuen bestanden).
- **Nachweisgrenze:** Bei R² 2,8 % (Wochenmomentum der Literatur) öffnet das Tor in 3 von 10 Märkten, P1 „trägt“ in 9 von 10;
  ab R² 5,9 % Tor 9 von 10; Rausch-Kandidaten nie.
- **Eigener Fehler beim Bau:** Die λ-Kreuzvalidierung sah in die Zukunft. Gefunden hat das die vorab festgelegte Embargo-Probe, vor
  jedem Lauf auf echten Daten.
- **Proben:**
  - Selbsttests: Ausblick 49 Prüfungen, Aktien 22, Audit 8, Backup 18.
  - Mutationen 61 + 14 + 17 rot.
  - Browserprobe 82 Prüfungen, Skript-Mutationen 16 von 16 rot.
  - `install.py --selftest-isoliert`: 42 Schritte und 14 Abrufe grün.

Lehre: **Eine Kreuzvalidierung mit Purging braucht dieselbe Embargo-Probe wie die Schätzung selbst -- das Purging darf nur abziehen,
was vorher addiert war. Eine Positivkontrolle, die ihre Stärke nicht erreicht, wird zur gemessenen Nachweisgrenze, nicht zu einer
stillen Anpassung der Stärke.**

Lehre: **Eine Probe, deren Testdaten den geprüften Fall nicht enthalten (Demo ohne Tafeln, Bein nur mit einem Startextrem), prüft
nichts -- die Mutationen finden solche Lücken, bevor es ein echter Fehler tut.**

Lehre: **Eine Kalibrierung bei p < 0,05 sagt nichts über die kleinen p, die Holm braucht -- den Schwanz eigens prüfen, mit einer
vor dem Lauf festgelegten Regel. Und eine Schranke im Selbsttest bekommt ihre Fehlalarmrate ausgerechnet.**

**Nachtrag 11.10. 23:30 (nur Dokumente, 23.66 läuft auf dem Pi):** Entscheidungen des Nutzers per Auswahl (UEBERGABE 3ωω):
- Hinweis „Kaskadenrisiko nach unten“ mit Quoten, Top-Trader-Punkt raus aus der Konfluenz, Chartbild-Text sonntags im Berichtsplan
  (alles U151, mit 23.67 nach den Berichten vom 12.10.);
- Breitentest der Kontenregel ja (U144); Niveau-Test nach dem 25.10.;
- die 95 % waren eine andere Kennzahl unbekannter Quelle (U152: Liste, Nutzer wählt, dann Test);
- Ausblick 11: 1 ja, 2 nein (beides wie gebaut), 3 nein.

**Nachtrag 11.10. gegen 23:50 (nur Dokumente, 23.66 läuft auf dem Pi):** Frage des Nutzers nach Arbeitsmarkt-, Verbraucher-
und Erzeugerpreisdaten der USA (UEBERGABE 3ααα). Ergebnis: nicht im System, bei FRED vorhanden. Per Auswahl entschieden:
- sammeln und zeigen (U153, mit 23.67). Fassungen mit Abrufzeit, weil `makro.db` Korrekturen überschreibt; dazu Termine. Die Lücke
  Oktober 2025 (Stillstand der US-Regierung) bleibt Lücke.
- Datentage-Studie (U154, nur Schwankung). Zuerst „nach dem 25.10.“, auf Nachfrage des Nutzers (12.10. 00:01) vorgezogen
  auf 23.67.

**Nachtrag 12.10. 02:30 (nur Dokumente, 23.66 läuft auf dem Pi):** Neuer Name des Dashboards „HyperBit — Analyzer“
(Nutzerwunsch, U155, UEBERGABE 3βββ). Mit 23.67 ändern sich Browser-Tab, Kopfzeile, Export-Zeile, Web-App-Manifest und
README-Titel. Die technischen Namen (Ordner, Dienste, Datenbanken, Dateien) bleiben.

**Nachtrag 13.10. nachts (23.67):** Berichte vom 12.10. ausgewertet und 23.67 gebaut (UEBERGABE 3γγγ).
- **Erster Rückblick des Ausblicks** (`KONZEPT_Ausblick.md` 12.2):
  - Breite S1 besteht bei keinem Horizont; B0 bleibt, weil B1 nicht besser ist. Das PAXG-Band ist zu eng (Deckung 57 %).
  - Tor zu, S3 besteht, S4 belegt; unter Aktienstress ist die bedingte Verteilung nicht kalibriert.
  - U147 „immer“ nicht bestätigt (unter −1 % 77 %, unter −2 % 84 %); K1/K2 nicht belegt.
  - Eigene Fehleinschätzungen genannt (S1, X1, U147).
- **Gebaut:**
  - U151: Konfluenz ohne Top-Trader-Punkt, Konten-Hinweis mit Quoten, Bilanz ab Regelwechsel (`konfluenz_regel`).
  - U153: Arbeitsmarkt und Preise der USA im Tab Makro, mit Fassungen, ALFRED und Terminen; Lücke Oktober 2025 nicht gefüllt.
  - U154: `hl_datentage.py`; Lauf 15.10. 21:45.
  - U155: Name „HyperBit — Analyzer“.
  - Acht Befunde aus den Berichten (SEC-Fehlerzeile, Aktienzahl, eingestellter VIX, Ortszeit, fehlende Textabschnitte, Deckung mit
    Wertung, S4 unter Stress, Stressfächer-Beschriftung).
- U152-Liste: `RECHERCHE_Kennzahlen_Hebel_Spot_13-10-2026.md`.
- Offen beim Nutzer: U152 (welche Kennzahl), U156 (Stressfächer mit Größe der Stressphase); U157 (PAXG-Band) nach dem 25.10.
- Proben: Python-Mutationen 53 von 53 rot, Browserprobe Makro USA 9 von 9.

**Nachtrag 13.10. nach 03:00 (nur Dokumente, 23.67 unverändert):** Entscheidungen des Nutzers per Auswahl (UEBERGABE 3δδδ):
- U152: Die 95 % meinen CryptoQuants Bitcoin-Messung über alle Börsen. Kostenlos ab jetzt sammeln; Test U158 vorab festgelegt
  (`KONZEPT_Hebel.md` 14).
- U156: Stressfächer zusätzlich in der Größe der Stressphase, als Szenario (`KONZEPT_Ausblick.md` 13.14).
- Beides mit 23.68, Vorschlag nach den Berichten vom 15./16.10.; der Nutzer legt dafür ein kostenloses CryptoQuant-Konto mit
  Schlüssel an.

**Nachtrag 13.10. 04:20 (nur Dokumente, 23.67 unverändert):** Kaskaden-Gleichung und Magnet-Test nach gut einer Woche (Berichte vom
11.10. abends, UEBERGABE 3εεε): nichts belegt, beide Nullmodelle treffen. Neu U159: Die Heatmap sieht nur noch 7–19 % des OI (04.10.
22–24 %); Ursache offen, Bericht mit 23.68. Fusion und TradeLabor vom 11.10. 19:30 fehlen noch.

**Nachtrag 13.10. 05:35 (nur Dokumente, 23.67 unverändert):** Fusion nach einer Woche live und TradeLabor nach 14 Tagen (Berichte
vom 11.10. 19:30/19:31, UEBERGABE 3ζζζ, `KONZEPT_Fusion.md` 6.1):
- Fusion 4 h nicht belegt besser als die Basisrate (−0,0032 ± 0,0029 je Block), kein ✗ gegen einen Experten, v1 knapp davor.
  Alle Vorhersagen liegen beim Münzwurf. Erwartung für das Urteil am 25.10., vorab festgehalten: Die Fusion bleibt im Schatten.
- TradeLabor: 5.204 Trades, netto −104.833 USD, 0 bewährt, 7 negativ; die Kosten überwiegen.
- XMR-Gebühr: Der Nutzer wählte die normalen Sätze ab 23.68 (U160; Messung ×0,5 statt der angenommenen ×2). Die Kostenschwelle der
  Fusion bleibt bis zum 25.10. unverändert, die Swing-Vorprüfung auf der Historie behält ihre Annahme (`KONZEPT_Swing.md` 7).
- Neu U161 (Labor je Strategie und Coin) und U162 (Kriterium 5 im Bericht; fehlte seit 23.42, eigener Fehler).
- 23.68 = U156, U158, U159, U160, U161, U162. Es fehlt nur noch der Fusion-Selbsttest vom 11.10. (optional).

**Nachtrag 13.10. 14:10 (nur Dokumente, 23.67 unverändert):** Der Fusion-Selbsttest vom 11.10. kam nach: bestanden (27 von 27,
38 s), Zeile für Zeile wie in der Sandbox mit 23.67 und wie beim Bau. Es fehlt kein Bericht mehr (UEBERGABE 3ζζζ, Nachtrag).

**Nachtrag 13.10. 20:35 (nur Dokumente, 23.67 unverändert):** Größe der Labor-Trades geprüft (Nutzerfrage mit Bild, UEBERGABE 3ηηη):
- Grid-Lose sind 833–2.500 USD groß (10.000 USD je Coin auf 4–12 Stufen verteilt); Swing und Zyklus richten sich nach dem Risiko
  (100 USD bis zum Stop); alle anderen handeln 10.000 USD. Die Kachel „10.000 USD je Trade“ war irreführend (eigener Fehler).
- Per Auswahl: U163 (Grid-Anzeige je Coin und Tag, Spalte „Größe“, Ø/Tag in USD, Kachel berichtigt; nur Anzeige) und U164 (Swing
  und Zyklus im Labor mit fester Größe 10.000 USD, neue Kennungen; Historie bitgleich, R bleibt vergleichbar).
- 23.68 = U156, U158, U159, U160, U161, U162, U163, U164. `KONZEPT_Swing.md` und `KONZEPT_Zyklen.md` vermerkt (im Projekt).

**Nachtrag 13.10. 22:15 (nur Dokumente, 23.67 unverändert):** Sammeldatei 13.10. 22:07 (UEBERGABE 3θθθ): Die Zweitläufe von Ausblick,
Aktienmarkt, U147 und K1/K2 bestätigen den 12.10. Der Pi läuft noch mit 23.66; 23.67 muss vor dem 15.10. 20:15 eingespielt sein (U153,
U154). Neu U165: Der jüngste Farside-Tag kann unvollständig sein (12.10. ohne IBIT); Nachprüfung 18.10. 08:30. 23.68 = U156, U158–U165.

**Nachtrag 14.10. 08:25 (nur Dokumente, 23.67 unverändert):** Skriptfehler im Hinweisfenster des Kurs-Charts mit der Quelle „Binance
Daten“ (UEBERGABE 3ιιι): Eingetretene Binance-Marken haben kein `x_vol`. Es ist ein alter Fehler und betrifft nur die Anzeige; er ist
nachgestellt. Die Zeilennummer zeigt, dass 23.67 läuft. Korrektur mit 23.68 (U166, Wahl des Nutzers); 23.68 = U156, U158–U166.

**Nachtrag 14.10. 12:15 (nur Dokumente, 23.67 unverändert):** Bilanzverlauf im TradeLabor mit allen Strategien, Häkchen je Strategie
und Standard „Top 10 nach Trefferquote“ (Wahl des Nutzers), vorab festgelegt als U167 (UEBERGABE 3κκκ); 23.68 = U156, U158–U167.
Am Nachmittag im Arbeitsstand gebaut und geprüft (node 13/13, Browser 40/40, Mutationen 5/5 rot); Auslieferung mit 23.68.

**Nachtrag 14.10. 22:30 (nur Dokumente, 23.67 unverändert):** Sammeldatei der Woche, neu der Wochenlauf 14.10. 19:00 (UEBERGABE 3λλλ):
- 23.67 läuft seit 13.10. 22:44 (A1 ✓).
- Der Vollbericht brach nach 15 min ab: Er zählt jede Tabelle dreimal vollständig und druckt erst am Ende; die Laufzeit wuchs mit
  der Datenbank (596 s, 779 s, über 900 s), ich habe sie nicht verfolgt (eigener Fehler). Korrektur mit 23.68 (U168, Wahl des Nutzers): einmal
  zählen, sofort ausgeben, Zeitbudget, Vorwarnung im Berichtsplan. Bis dahin liefert ihn der Handlauf.
- Abdeckung der Heatmap wieder 24–27 % (20 h nach dem Neustart); U159 vorab präzisiert (Poller-Kennzahlen, Neustarts).
- v3 hat erstmals Gewichte (Tor nach fester Regel geöffnet, nichts geändert). Fusion, Kaskaden, Magnet: nichts belegt; Hochrechnung
  für den 25.10. wie erwartet. Labor −120.835 USD, 0 bewährt; beide Grids im Minus; erste fünf Swing-/Zyklus-Trades alle am Stop.
- Neu U169 (Makro-Textzeilen). 23.68 = U156, U158–U169.

**Nachtrag 14.10. 23:15 (nur Dokumente, 23.67 unverändert):** Zweites Bild des Nutzers zum Skriptfehler (UEBERGABE 3μμμ): wieder
U166 im Binance-Modus, dazu „NaN %“ beim nächsten FVG. Ein Feldvergleich der Chart-Nutzlast aller drei Quellen fand im Binance-Modus
genau drei fehlende Felder (`x_vol` der Marken, `dist` der FVGs und der Orderbuch-Stufen; deshalb fehlten dort still die
Schlüsselniveaus) → U166 erweitert. Die Konfluenz-Bilanz speichert die Quelle nicht und mischt damit Regelwerke (eigener
Konstruktionsfehler) → U170. 23.68 = U156, U158–U170.

**Nachtrag 15.10. 22:30 (nur Dokumente, 23.67 unverändert):** Berichte vom 15.10. (UEBERGABE 3ννν, `KONZEPT_Makro.md` 11.9): Die
Verbraucherpreise für September sind da (U153 ✓). Die Datentage-Studie (U154) belegt H1 und H2: In den zwei Stunden nach den
Verbraucherpreisen schwanken BTC und ETH typisch 2,45-mal so stark (Varianz), nach dem Arbeitsmarktbericht 1,9-mal; über den ganzen
Tag kaum, Erzeugerpreise und Erstanträge ohne Effekt. Die Erwartung „seit 2024 kleiner“ war falsch; die Gegenprobe weicht ab
(→ U171). Per Auswahl: Hinweis an Datentagen mit 23.68 (U172), Rechnung für die Schwankung der nächsten Stunden nach dem 25.10.
(U173). 23.68 = U156, U158–U172. Der zweite Lauf am 16.10. 21:46 bestätigt das Ergebnis Zahl für Zahl.

**Nachtrag 17.10. (Version 2026-09-23.68 · e195e119f2): 23.68 gebaut und geprüft** (UEBERGABE 3ξξξ).
- **Gebaut:** alle Punkte U156 und U158–U172.
  - Vollbericht in einem Durchgang.
  - Binance-Modus ohne Fehler und ohne „NaN“.
  - Konfluenz je Quelle.
  - Hinweis an Datentagen.
  - Labor: XMR normal, feste Größe, Tabellen, Bilanzverlauf.
  - Kriterium 5, Farside, Abdeckung.
  - Ausblick: Fächer in der Größe der Stressphase.
  - CryptoQuant mit S5.
- **Eigener Fehler:** Die Stressklammer bei +4 W war seit 23.66 abgeschnitten.
- **Nachweisgrenze S5:** Mit kurzer Reihe ist ein „nicht belegt“ schwach.
- **Der Nutzer trägt den CryptoQuant-Schlüssel selbst ein**, im Tab „Daten“, nie im Chat. Erster Bericht 19.10. 20:15.

**Nachtrag 19.10. abends (Version 2026-09-23.69 · 547c938d6a): 23.69 gebaut und geprüft** (UEBERGABE 3φφφ).
- **Gebaut:** U180 Akkumulation im TradeLabor (`KONZEPT_Akkumulation.md`, neu im Paket), U177 Strategy-Bestand, U178 Zeitraum der
  Stressfächer, U179 Ausnahmelage mit Text, Probe und Zählung (`KONZEPT_Ausblick.md` 13.19). Nicht im Paket: U174, U175 (Wahl des
  Nutzers).
- **Vor jedem echten Kurs geändert:** Bei der Akkumulation zählt Q gegen Vorzeichen-Surrogate (auf Zufallswegen kalibriert, 6 von 144
  unter 0,05), nicht der Vorteil gegen Zufallszeiten (der ist auf Zufallswegen schief).
- **Präzisierung vor dem Bau:** U177 prüft die Plausibilität nur nach unten.
- **Beim Packen gefunden und behoben (eigene Fehler):** `update.py` kannte die beiden neuen Dokumente und `check_abdeckung.py` (seit
  23.68) nicht → aufgenommen, Prüfsumme 547c938d6a statt 4f52736ff4; Uhrzeiten in den Dokumenten waren geschätzt (bis zu 2 h zu spät)
  → nach Dateizeiten berichtigt; in `KONZEPT_Akkumulation.md` 7 zwei Zahlenreihen ohne Protokoll ersetzt bzw. nachgerechnet.
- **Termine:** 20.10. 08:45 Akkumulation-Rückblick, 20.10. 21:15 Zählung der Regel (c). Neu offen U181 (Rechenweg der
  Akkumulation-Tageszeilen, nur Rechenzeit), U182 (Probe der Dateiliste von update.py) und U183 (Dauer im Debug-Eintrag
  „Selbsttest“: dort „3–5 min“, gemessen 1.297 s in der Sandbox, auf dem Pi eher eine Stunde); nächste neue Nummer U184.
- **A7:** `install.py --selftest-isoliert` 61 von 61 grün.

**Nachtrag 20.10. (Version 2026-09-23.70 · a2b59f0fc5): 23.70 statt 23.69** (UEBERGABE 3χχχ). 23.69 wurde nicht eingespielt; der Nutzer
änderte vorher die Akkumulation (U184): 5.000 USD je Kauf, Spot (war es schon; das Ereignis heißt jetzt „spot“), Startkauf A0 je Coin,
Käufe rückwirkend ab dem Start des Coins im Labor nachgerechnet („direkt vergleichbar mit den anderen laufenden Strategien“). Meine
Entscheidungen: Start des Coins im Labor als Beginn, Sperre auch beim Startkauf, Kontrolle ebenso, Rückblick und Vergleich ohne Startkauf
(`KONZEPT_Akkumulation.md` 7a). Termine wie 23.69 (20.10. 08:45 und 21:15, zweite Termine am 21.10.). Nächste neue Nummer U185.

**Nachtrag 20.10. (Version 2026-09-23.71 · f3113c906a): Anzeige der Akkumulation berichtigt** (U185, UEBERGABE 3ψψψ). 23.70 ist auf dem Pi;
der Nutzer las die Tabelle je Tag (23 Zeilen für 23 Tage, Stand am Tagesende) als Liste von Käufen und fragte, warum oben nur 5.000 je
Kauf stehe. Die Rechnung stimmte (3 Startkäufe, 15.000 USD). Neu: Liste „Alle Käufe“ unter der Übersicht, Tagestabelle als „Stand je
Tag — keine Kaufliste“ mit „Käufe“ bis dahin und „neu“, Grund des Startkaufs richtig (eigener Fehler aus 23.70: „zum Start des Coins“
auch bei späterem Kauf; gespeicherte Texte nur in der Anzeige umgeschrieben), Handy ohne Seitwärtsscrollen. Regeln, Kennungen und
gespeicherte Käufe unverändert. Mit 23.71 kommen `KONZEPT_Akkumulation.md` und `RECHERCHE_Boersenfluesse_17-10-2026.md` auf den Pi (das
`update.py` von 23.70 kennt sie). Nächste neue Nummer U186.

**Nachtrag 20.10. (Version 2026-09-23.72 · 1a8c1b577d): Korrekturkauf A4** (U186, UEBERGABE 3ωωω). Noch vor dem Einspielen von 23.71
wünschte der Nutzer eine Zusatzregel für scharfe Korrekturen: 7 % unter dem Hoch der letzten 48 h kaufen, binnen 14 Tagen je weitere 7 %
nachkaufen, für alle Coins, rückwirkend und dann live; auf meine Rückfrage ohne Sperre. Gebaut als eigene Spur neben A0–A3 (die
bisherigen Käufe bleiben gleich, Probe), neue Kennungen; die Bilanz von 23.70 steht unter „frühere Regeln“. 23.72 enthält 23.71.
Nächste neue Nummer U187.

**Nachtrag 20.10. 07:37 (nur Dokumente, 23.72 läuft auf dem Pi):** Der CryptoQuant-Bericht vom 19.10. (U158) ist geprüft: Der kostenlose
Schlüssel bekommt die Tageswerte, Einheit und Antwortform passen, D lag in 32 Tagen bei 83,2–91,4 % (kein Tag ≥ 95 %), S5 ist noch nicht
prüfbar (UEBERGABE 3αααα, `KONZEPT_Hebel.md` 14). Neu U187: Der Labor-Bericht kennzeichnet frühere Regelstände der Akkumulation nicht.
Nächste neue Nummer U188.

**Nachtrag 20.10. (Version 2026-09-23.73 · 5563865ed5): Tagestabelle der Akkumulation nochmals berichtigt** (U188, U187, UEBERGABE 3ββββ).
Der Nutzer las die Spalte „Käufe“ der Tabelle „Stand je Tag“ (bei BTC in jeder Zeile 1) als einen Kauf an jedem Tag und zweifelte an der
7-%-Regel. Die Rechnung stimmte: BTC hat nur den Startkauf, und 7 % binnen 48 h gab es nicht (größter Zwei-Tage-Rückgang 4,5 %). Neu: Spalte
„Kauf an diesem Tag“ („—“ oder ⊕ mit dem Kauf), „eingesetzt gesamt“; dazu der Labor-Bericht mit „(alte Regeln)“ (U187). Rechnung,
Kennungen und gespeicherte Käufe unverändert. Nächste neue Nummer U189.

**Nachtrag 20.10. (Version 2026-09-23.74 · bc6ebee746): Faktor gegenüber BTC** (U189, UEBERGABE 3γγγγ). Der Nutzer sah bei ZEC über 70.000 USD
Käufe gegenüber 5.000 bei BTC: die festen 7 % des Korrekturkaufs sind bei ZEC Alltag. Gebaut auf seine Wahl: je Coin ein Faktor
(σ_Tag ÷ σ_Tag von BTC in den 365 Tagen vor dem Start im Labor, mindestens 1, einmal bestimmt und gespeichert), Korrektur-Schwelle 0,93
hoch Faktor, Betrag 5.000 USD ÷ Faktor; neue Kennungen, alles ab dem Start neu nachgerechnet; Tabelle „Schwellen je Coin“. A1–A3 und
die Sperre bleiben. Nächste neue Nummer U190.

## 7. Bekannte Schwächen, die man kennen muss

- Trades/Aktivität sind nur für die verfolgten Coins messbar (Stream); Leaderboard-Konten haben zusätzlich REST-Fills aller Coins → leicht ungleiche Aktivitätszählung (U5-Feinheit).
- Placebo im Exit-Lift über Coins gemittelt (Verfeinerung offen).
- v1-Trefferbilanz je Treiber ist in-sample; Lift/z gegen Randverteilungen vorhanden; OOS ab 25 Blöcken.
- Konstellationen: Auswahl-Effekt (Top-12 von ~400 Prüfungen) ist ausgewiesen, aber die Tabelle wirkt immer beeindruckend — nur die Stabilitätsliste (z ≥ 2 an ≥ 14 Tagen) zählt.
- Vorbedingungen (U131): Steigt der Kurs in einen Rückgang hinein und folgt binnen Stunden nach einer Erholung ein tieferer, zählen beide als ein Ereignis (Zufallswege: 1 von 660 Bewegungen). Bewegungen, die nur am Kerzenhoch 3 % erreichen, vom 15-min-Prognosekurs aus aber nicht, fehlen (der Debug-Abgleich nennt sie).
- Sicherheit: Dashboard ohne Anmeldung im Heimnetz (Host-Allowlist für POST), Update ohne Signatur (S2), sudo-Passwort im Klartext (S3) — Betriebsentscheidungen des Nutzers.
- Ausblick (seit dem ersten Rückblick 12.10.): Die Breite schlägt den naiven Vergleich nur bei 7 Tagen knapp; das PAXG-Band ist zu eng
  (57 % statt 80 %, U157); die Szenarien mit dem S&P 500 sind unter Aktienstress nicht kalibriert. Beides steht am Fächer.
- Heatmap-Abdeckung (schwankt, U159): Am 11.10. sah die Karte nur 7–19 % des OI, am 14.10. (20 h nach einem Neustart) wieder
  24–27 %. Kaskaden-Gleichung, Magnet-Test und Heatmap-Anker rechnen mit dem jeweiligen Ausschnitt; die Ursache ist noch offen
  (Vermutung: Neustart-Muster des Pollers).
- Vollbericht (seit 23.68 ein Durchgang mit Zeitbudget, U168): Die Laufzeit auf dem Pi ist noch nicht gemessen (Wochenlauf 21.10.);
  fehlt am Ende etwas, steht es als „nicht gezählt (Zeitbudget)“ da.
- Konfluenz-Bilanz (seit 23.68 je Quelle, U170): Die Einträge vor 23.68 bleiben als „Quelle unbekannt“ gemischt; nur die Zeilen je
  Quelle seit dem Einspielen gelten für ein Regelwerk.
- Fusion (erster Blick 13.10.): nicht belegt besser als die Basisrate; alle Vorhersagen, auch die Basisrate, liegen beim Münzwurf.
  Kriterium 5 rechnet der Bericht seit 23.68 (U162); erster echter Wert im Wochenlauf 21.10.
- TradeLabor: Bis 23.68 lief XMR mit doppelter Gebühr (gemessen etwa die Hälfte der normalen). XMR-Ergebnisse vor dem Wechsel sind
  um diesen Teil zu schlecht; die Tabelle je Strategie und Coin trennt vor/nach (U160, U161). Die Kostenschwelle der Fusion rechnet
  XMR bis 25.10. weiter doppelt.
- TradeLabor, Größen: Grid-Lose sind Teile des 10.000-USD-Kontos je Coin (seit 23.68 mit „Los“ und Tagestabelle, U163). Swing und
  Zyklus handeln seit 23.68 mit 10.000 USD unter neuen Kennungen (U164); ihre wenigen Trades davor stehen unter den alten.
- Ausblick, Ausnahmelage (U179, `KONZEPT_Ausblick.md` 13.18/13.19): Die S&P-Regel (c) ist ein Hinweis; sie ändert keine Spanne.
  Seit 23.69 nennt der Text Beginn, Ende und den Börsenstand bei Auslösung. Die Schwelle ist nicht auf den Tagesverlauf des S&P
  geeicht; die Zählung (`--sp-zaehlung`, 20.10. 21:15) misst es, eine neue Schwelle erst nach Entscheidung des Nutzers.
- TradeLabor, Akkumulation (U180, seit 23.69): Der Vergleich „Zeitpunkt gegen Zufall“ ist auch ohne Vorhersagekraft meist positiv
  (Zufallswege: Median +2 %); belastbar sind nur Q gegen Vorzeichen-Surrogate im Rückblick und der Abstand zur Kontrolle ohne
  Heatmap. Die Kalibrierung von Q (6 von 144 Zufallswegen unter 0,05) schließt einen Fehlalarmanteil bis knapp 9 % nicht aus.
  Die Heatmap-Regel A2 ist die Idee des Nutzers, kein Beleg (U110 offen bis 25.10.). Kapital ohne Obergrenze: Der Einsatz wächst mit
  jedem Rücksetzer.
  Seit 23.70 (U184) rechnet sie beim ersten Takt rückwirkend ab dem Start des Coins im Labor: ohne Heatmap-Regel und Warteregel (die
  wirken erst live, bis dahin sind Hauptstrategie und Kontrolle gleich) und zum Schwellenpreis ohne Abstand zur Buchmitte (etwas
  günstiger als live). Der Kurs kommt aus dem Perp-Buch, gerechnet wird ein Spot-Kauf mit Spot-Gebühr. Die Startkauf-Gründe aus 23.70
  stehen in der Datenbank im alten Wortlaut; die Anzeige schreibt sie um (U185), die Ursache eines späten Startkaufs fehlt bei ihnen.
  Seit 23.72 (U186) kauft sie zusätzlich jede Korrektur von 7 % in 48 h und je 7 % tiefer binnen 14 Tagen, ohne Sperre: auch in teuren
  Phasen und ohne Obergrenze; für diese Käufe gibt es noch keinen Vergleich gegen Zufall (der zählt weiter nur A1–A3).
  Der Labor-Bericht nennt frühere Regelstände (andere Kennung) bis zur Behebung (U187) mit demselben Titel wie die laufenden.
- Strategy-Bestand (U177, seit 23.69): Plausibilität nur nach unten und nur mit einem Nachbarn binnen 9 Tagen; ein einzelnes 8-K
  nach einer Lücke wird ungeprüft übernommen.
- Update (U182): `update.py` spielt nur Dateien aus `PROJECT_FILES` ein (weitere `.py`/`.json` ohne Sicherung, andere Dokumente gar
  nicht). Jede neue Datei gehört in die Liste; eine Probe im Selbsttest fehlt noch. Ein Paket wird immer vom update.py des
  installierten Stands eingespielt — eine berichtigte Liste wirkt erst beim nächsten Update.
- Börsenflüsse (U174, `KONZEPT_Makro.md` 12.6): Ein Fenster je Tag; das eigene Archiv weist nach 730 Tagen erst ρ ≈ 0,13–0,15
  nach (R² rund 2 %), mehr als die Studien fanden. Die Vorstudie auf der bereinigten Historie zählt nur in einer Richtung (ohne
  Beleg endet U174).
- Hebel S5 (U158): Mit den ersten ein bis zwei Jahren Reihe belegt die Prüfung selbst ein dreifaches Risiko nur in einem Teil der
  Fälle (450 Tage: 8 von 30); „nicht belegt“ heißt dann wenig. Ob der kostenlose CryptoQuant-Schlüssel den Endpunkt erreicht, zeigt
  erst der erste Abruf (Doku widersprüchlich).
- Ausblick, Größe der Stressphase (U156): ein Szenario aus wenigen unabhängigen Wegen (ein Jahr ≈ 13 Vier-Wochen-Wege); die
  Spannen sind grob, die Zahl „x-mal so breit“ ist die belastbarere.
- Backup bis 23.66 (U145): update.py und Recorder können gleichzeitig sichern (keine Sperre, dieselbe Zwischendatei). Update nur drücken, wenn die Kachel „Letztes Backup“ eine Uhrzeit zeigt; sonst erst „Jetzt sichern“ (System → Speicherorte).

## 8. Kompatibilität dieser Übergabe

- Modellunabhängig: keine Sitzungs-, Transkript- oder Speicherfunktion wird vorausgesetzt. Alle Fakten stehen in den Dateien.
- Historische Dateinamen mit „FABLE" bleiben (Änderungsprotokoll); Autorenvermerke in README/UEBERGABE/REVIEW sind auf
  „Fable 5.1 bis 23.09., fortgeführt mit Opus 5.5" angepasst.
- Die Werkzeuge der Sandbox (numpy, node, playwright, kein Netz) sind Annahmen dieser Umgebung; in einer anderen
  Umgebung Abschnitt 4 entsprechend prüfen.

## 9. Erste Schritte in der neuen Sitzung (Vorschlag)

1. Abschnitt A des Plans mit dem Nutzer (Version 23.10 einspielen lassen, Rundum-Funktionstest, Netzwerkstatus).
2. Ausstehende Proben abfragen: P2 (K1: Liquidationen nach Methode, ≤ 10 beobachtete Konten) und P1 (Coinbase-Seite).
3. U8 (H10 Bilanz der Empfehlungen) ist seit 23.16 gebaut — jetzt LESEN: Debug „★ Bilanz der Kauf-/Verkaufsempfehlungen (U8)“,
   wöchentlich; aussagekräftig erst nach einigen Wochen.
   Seit 23.20 laufen die Prüf-Einträge von selbst (Berichtsplan `hl_viz.BERICHTSPLAN`, Dateien in `berichte/`). Der Nutzer lädt
   die Sammeldatei aus dem Debug-Bereich hoch. Neue Termine trägt Claude dort mit dem nächsten Paket ein.
4. Ab 6.10. U3b entscheiden. U7b (v2 aktivieren, inkl. Pfad): seit 05.10. auf den 25.10. gelegt, zusammen mit U108 (Plan U7b: Schalter allein unvollständig, Labor-Strategie „Prognose“ liest `p_up`).
