# PROJEKTÜBERGABE — Hyperliquid-Analysesystem („hl_liq_project")
**Für den Import in eine neue Sitzung (Claude Opus 5.5) · Stand 23.09.2026, Version 2026-09-23.10**
Erstellt bis hierher mit Claude Fable 5.1 (Sitzungen 1–5, 13.–23.09.2026); Auditberichte v9/v10 kamen von Opus 5.5.

> **So beginnst du:** (1) Diese Datei ganz lesen. (2) `UPDATE_PLAN.md` lesen — Abschnitt A abarbeiten (Prüfungen),
> Abschnitt B ist die Reihenfolge der offenen Arbeiten. (3) Das Paket `hl_liq_project.zip` ist die einzige Wahrheit;
> Chats und alte Transkripte sind nicht verfügbar. Alles Wissen steht in den Dateien des Pakets.

---

## 1. Was das System ist

Ein Analysesystem für Hyperliquid-Perpetuals (BTC, ETH, HYPE, ZEC, PAXG, XMR) auf einem **Raspberry Pi 5**
(Python 3.13, SQLite, systemd), mit vier Diensten:

| Dienst | Datei | Aufgabe |
|---|---|---|
| Recorder | `hl_recorder.py` | Hyperliquid-API und WebSocket: Positionen aller großen Konten (Poller in Stufen), Leaderboard-Top-75 (alle 2 min), Fills (Stream + REST-Nachtrag), Orders, Liquidationen (beobachtet + abgeleitet), Kerzen, Heatmap-Snapshots, Pool „Aktive Profis", Masterregel Sperre, Backup; seit 23.33 der Adress-Strom (`hl_adressfluss.py` → `adressfluss.db`) |
| Dashboard | `hl_viz.py` | Web-UI (http://<pi>:8765), alle Charts/Abschnitte, Prognose-Berechnung (Lernzyklus, Kalibrierung v1/v2, Scores, Profis, Konstellationen), Debug-Konsole, Update/Restore; seit 23.33 der TradeLabor-Takt (`hl_labor.py`, 15 s) |
| Fremdbörsen | `hl_binance.py` (+ `hl_ext.py`) | Binance, Bybit, OKX, Crypto.com: Liquidationen, Funding, Kennzahlen, ETF-Flüsse (Farside) |
| Coinbase | `hl_coinbase.py` | Spot-Matches (Taker-Flow), Orderbuch, Kerzen |

Kernfunktion: **Liquidations-Heatmap** (wo liegen Liquidationspreise großer Konten) und eine **Prognose**
(30 Treiber → Wahrscheinlichkeit/Pfad), dazu Konten-Analysen (Wale, Leaderboard, Elite, Aktive Profis).

## 2. Dateien im Paket (77 Dateien in 95 Zip-Einträgen, Stand 23.47)

- **Kern:** `hl_recorder.py`, `hl_viz.py`, `hl_forecast.py` (Treiber, Pfad, Kalibrierung v1, Bewertung),
  `hl_indikatoren.py` (neue Treiber 14.09.), `hl_score.py` (Konto-Score, Elite), `hl_profis.py` (Aktive Profis),
  `hl_kalib.py` (Kalibrierung v2, Schatten), `hl_konstellation.py` (Paar-Statistik, Vorbedingungen),
  `hl_ext.py`, `hl_binance.py`, `hl_coinbase.py`, `hl_dbcoord.py` (Schreibsperre), `hl_watchdog.py`,
  `hl_timestats.py`, `hl_backtest.py`, `macro_corr.py`, `run_all.py`, `install.py` (Installation + `--selftest`),
  `hl_familien.py` (Treiberfamilien), `hl_anker.py` (Heatmap-Anker), `hl_labor.py` (TradeLabor, simulierter Handel),
  `hl_adressfluss.py` (Adress-Strom), `hl_fusion.py` (Fusionsprognose, Kalibrierung v3, Kostenschwelle; Schatten, seit 23.42),
  `hl_kaskade.py` (Kaskaden-Gleichung: Wurzelgesetz auf die Heatmap-Cluster, Kipppunkt, Kalibrierung Y; Schatten, seit 23.43),
  `hl_magnet.py` (Magnet-Test U110: Berührungen der Cluster gegen das Nullmodell, Spiegel, Placebo; nur Messung, seit 23.45),
  `hl_makro.py` (Makro-Chart U121: Abruf freier Quellen nach `makro.db`, Treiber, Miner-Kostenbasis, Nutzlast; seit 23.47),
  `hl_makro_js.py` (Skript des Makro-Abschnitts, `/makro.js`; seit 23.47),
  `update.py` (Update/Restore), `migrate_db.py`, `version.py` (Version + Prüfsumme).
- **Werkzeuge (Debug-Konsole):** `check_*.py` — sources, fills, leaderboard, forecast, writes, report, m9, magnet,
  elite, treiber (Harness, 83 Prüfungen), pool, sperre, profis, daily, orders; `db_size.py`;
  `make_treiber_pdf.py`/`_en.py` (Treiber-Dokumentation als PDF).
- **Dokumente:** `README.md` (Betrieb), `UEBERGABE_13-09-2026.md` (chronologisches Änderungsprotokoll, Abschnitte
  3a–3π), `UPDATE_PLAN.md` (lebendes Arbeitsdokument), `REVIEW_Audit_v10_22-09-2026.md`, `KONZEPT_Aktive_Profis.md`, `KONZEPT_Fusion.md` (fusionierter Treiber, Stufen 1–3; Abschnitt 4b Strukturgleichung und Kaskaden-Gleichung),
  `KONZEPT_Makro.md` (Makro-Chart: Regeln, Quellen, Rechnung je Treiber, Proben, Grenzen), `RECHERCHE_Makro_Chart_05-10-2026.md`
  (Recherche zu Zyklus-Indikatoren und freien Datenquellen, Grundlage von U121),
  `PROPOSAL_Kalibrierung_Stufe2_3.md` (historisch, durch den K2-Neubau ersetzt), `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
  (historisch), `labels.json` (eigene Kontonamen, Sperren/Schutz), `accesstokens.json`, `android/` (WebView-App).

## 3. Eiserne Regeln (nie brechen)

1. **Zeitstempel in Sekunden** (Ausnahme: `addresses.last_trade/first_seen` in ms; Grenze 1e11).
2. **Seiten** normalisiert `long`/`short`; Klassen `dir`/`mixed`/`hedge`/`mm`; `liquidations.side` ist roh `A`/`B` (A = Long liquidiert).
   `cb_bars.buy_usd/sell_usd` sind vor `cb_meta` 'seite_umstellung' VERTAUSCHT gespeichert (U41) — nur mit `hl_forecast.cb_seite_ab` lesen.
3. **API-Gewicht:** Deckel 90 % von 1.200/min (1.080), Begrenzer mit Rang (0 Leaderboard, 1 Poller/Orders, 3 Fills) und
   arbeitserhaltender 20-%-Reserve für den Hintergrund. **userEvents-Abos: höchstens 10 Nutzer je IP** (Hyperliquid-Limit).
4. **n_eff = getrennte Horizont-Blöcke**, nie Fensterzahl. Jeder Treiber braucht einen **Nulltest**; die Kalibrierung
   zusätzlich die **Positivkontrolle** (Kante 0,65 → p 0,60–0,70) — sie ist Selbsttest-Schritt 22 und ein Tor.
5. **Masterregel Sperre:** > 300 gebündelte Trades (je Coin, Minute, Richtung) in 24 h an ZWEI Tagen binnen 7 Tagen = dauerhaft
   gesperrt; nach dem ersten Tag vorläufig ausgeschlossen, ohne zweiten Tag nach 7 Tagen frei (seit 23.29; 23.13–23.28 ein Tag;
   vorher > 2.000 Fills, alte Sperren einmalig neu bewertet) (kein Signal, keine Orders, keine Fill-Speicherung,
   Positionen nur alle 6 h für die Heatmap). Manuell: `labels.json` `"sperre": true/false`.
6. **Elite:** n ≥ 10 Schritte im Coin, Vorlauf > 0, t ≥ 1 (auf nicht überlappenden Blöcken), Gewinn-Schranke
   (PnL 30 T > 0, Position ≤ 3 % unter Wasser), Aktivitätsschranke ≤ 300 Trades/Tag.
7. **Aktive Profis:** Pool = Kontowert ≥ 1 Mio und Tagesumsatz ≥ 500k (Leaderboard-Datei); Qualifikation 7 T:
   2–150 gebündelte Trades/Tag **in den verfolgten Coins** (seit 23.31; vorher 5–150); Gewinn 7 T > 0; seit 23.32 Timing über ALLE
   Ein- und Ausstiege (mindestens 4, Glückswahrscheinlichkeit ≤ 5 % gegen die Zufallsquote je Coin und Richtung; Einstiege ab 5 nur
   als Veto: Entry-Lift nicht signifikant negativ) statt Exit-Lift ab 5 Ausstiegen. Ein-/Ausstiege aus whale_positions, lb_events
   und -- seit 23.34 -- pool_positions (dieselbe Entscheidung binnen 15 min einmal). Rang: eigene ROI 12 h, sonst HL roi_1d.
   Die Fills der Darwin-Liste sammelt der Recorder seit 23.34 ohne Mindestbetrag (gedeckelt); pool_fills_hourly zählt weiter ab 2.500 USD.
8. **Version und Prüfsumme sind gepaart:** Jede Codeänderung → `version.py` hochzählen (Format `JJJJ-MM-TT.n`). Die
   Systemkachel „Version" zeigt beides; der Nutzer gleicht ab.
9. **Paketname immer `hl_liq_project.zip`** (Update-System des Pi). Inhalt: alle Projektdateien in einem Ordner
   `hl_liq_project/` plus `android/`.
10. **TradeLabor-Regeln sind eingefroren** (seit 23.33): eine Strategie nie „nachbessern“ -- jede Regeländerung ergibt eine
    neue Kennung (name@Prüfsumme) mit eigener Bilanz, die alte bleibt stehen. Bewertet wird nur mit „Glück“ (Student-t ×
    Zahl der Strategien) und den Stufen; die Kontrollen Zufall und Halten laufen immer mit. Seit 23.34 zählen t, Glück,
    Hälften und Stufen **Blöcke** (Trades einer Strategie im selben Horizont-Block = eine Beobachtung, Regel 4); ein neuer
    Coin (XMR) zählt ab seinem eigenen Start (Kontotage).
11. **Dokumente in derselben Antwort aktualisieren:** `UEBERGABE` (neuer Abschnitt 3xxx oben nach „## 0."), `UPDATE_PLAN`
    (Status, Stand, neue Punkte). Was dort nicht steht, existiert nicht.

## 4. Arbeitsweise in der Sitzung (Sandbox)

- Arbeitsverzeichnis `/home/claude`; Paket dorthin entpacken (`unzip -o hl_liq_project.zip && cp -r hl_liq_project/* .`).
- **Keine Netzverbindung** in der Sandbox (kein pip, keine API); numpy, node, playwright sind vorhanden.
- **Tests:** `python3 install.py --selftest` (31 Schritte seit 23.47, ~6 min; im Hintergrund starten und Log greppen),
  `python3 hl_makro.py --selbsttest` (seit 23.47, 42 Prüfungen, ~2 s, ohne Netz),
  `python3 check_treiber.py` (Harness), `python3 hl_forecast.py --nulltest`, `python3 hl_kalib.py --nulltest`,
  `python3 hl_profis.py --nulltest`, `python3 hl_konstellation.py --nulltest`, `python3 hl_score.py`,
  `python3 hl_labor.py --selbsttest` (seit 23.40 mit Grid, ~50 s), `python3 hl_fusion.py --nulltest` (seit 23.42, ~30 s), `python3 hl_kaskade.py --nulltest` (seit 23.43, seit 23.44 ~40 s), `python3 hl_magnet.py --nulltest` (seit 23.45, ~21 s), `python3 hl_anker.py --nulltest`, `python3 hl_adressfluss.py --selbsttest`, `python3 hl_recorder.py --selbsttest-fills`,
  `python3 hl_viz.py --selbsttest-last`, `python3 hl_recorder.py --selbsttest-start`, `python3 hl_recorder.py --selbsttest-sperre`,
  `python3 hl_recorder.py --selbsttest-gewicht` (Begrenzer in virtueller Zeit: Ereignisschleife mit springender Uhr --
  so lassen sich Stunden Last in Sekunden prüfen; Muster für weitere asyncio-Tests),
  vollständig `python3 install.py --selftest-isoliert`,
  JS-Syntax: alle `<script>`-Blöcke aus `hl_viz.PAGE` extrahieren und mit `node --check` prüfen; seit 23.47 zusätzlich
  `hl_makro_js.MAKRO_JS` (eigene Datei `/makro.js`).
  Recorder-Simulation: `python3 hl_recorder.py --db s.db --simulate` (erzeugt Testdaten, ~2 min).
  Dashboard lokal: `setsid nohup python3 hl_viz.py --db s.db --serve --port 91xx &`, dann curl/playwright.
- **Patches:** Text-Ersetzungen mit `assert s.count(o) == 1` je Anker (Unikat!). Anker vorher mit grep prüfen;
  bei Python-Heredocs keine deutschen Anführungszeichen/Gedankenstriche in doppelt-quotierten Strings (Syntaxfehler) —
  Patch-Skripte als Datei (`create_file`) schreiben, nicht als Heredoc. Lange Befehle werden abgebrochen: Schritte klein halten.
- **Packen:** Ordner `hl_liq_project/` aufbauen (Dateiliste in Abschnitt 2), `python3 version.py` im Ordner drucken,
  `zip -rq /mnt/user-data/outputs/hl_liq_project.zip hl_liq_project`, danach `present_files`.
- **Vor dem Packen:** `rm -f s.db* forecasts.db* labels_cache.json sys_history.json` (Testdateien nicht mitliefern).

## 5. Der Nutzer und seine Vorlieben

Deutschsprachig, technisch versiert, betreibt das System selbst (Update-Knopf im Dashboard, Debug-Einträge, Screenshots).
Erwartet: erst Daten prüfen, dann entscheiden; Fehler klar benennen (auch eigene); keine Behauptungen ohne Beleg; jede
Änderung mit Probe; Zahlen mit Intervallen; keine neuen Fehlerquellen. Er liefert Debug-Ausgaben und Screenshots auf
Anfrage — konkret sagen, welcher Debug-Eintrag gebraucht wird. Lange Erklärungen nur, wenn er fragt („Für mein Verständnis…").
Antworten enden mit Version · Prüfsumme des Pakets.

## 6. Aktueller Stand (23.09.2026)

- Pi läuft Version 23.6 (laut Nutzer 11:20); 23.7–23.10 bereit. Alle Quellen grün, Leaderboard 82 s/17,5 s, Fills 593 s,
  15 Gesperrte, Fills-Stream 668 Konten, keine 429.
- **Kalibrierung:** v1 (alt, trägt die Prognose) ist strukturell lernunfähig (Audit v10 K2, selbst nachgestellt);
  v2 (`hl_kalib.py`) läuft im Schatten, Tor bestanden; Umschalten = U7b nach 1–2 Wochen, wenn die direkte Bilanz v2 ≥ v1.
  **Beim Umschalten auch den Pfad (Bias) auf v2 umstellen** (offen, Teil von U7b).
- **Aktive Profis:** Phase 0–3 + U5 live; erster echter Lauf: 692 Pool → 73 aktiv mit Gewinn → 6 qualifiziert.
- **Konstellationen/Vorbedingungen:** Stufe 1 live (Anzeige + Tageshistorie); Stufe 2 (Interaktionsterme in v2) wartet auf stabile Paare.
- **Audit v10:** Stand 23.16 siehe Plan; U8 gebaut, offen U7b, U9–U13, U16–U24, U27, U29, U35, U36, U38. Proben P2 (K1) und P1 (Coinbase-Seite) bestanden (U1, U2).
- **Geklärt heute:** Leaderboard-Flow „0 Konten in 60 min" = ruhige Stunde, nur 6 der Top-75 halten BTC (U26 geschlossen);
  Vorschlag U27: Flow-Treiber auf Basis der qualifizierten Profis.

**Nachtrag 27.09. (23.33):** TradeLabor (U71) und Adress-Strom (U72) sind neu; Einzelheiten in UEBERGABE 3β. Als
Nächstes: informierter Fluss je Adresse aus dem Adress-Strom (U75, braucht ≥ 3 Tage Daten), dann weitere Labor-Strategien
(U76). Eine Demo-Datenbank für Ansicht und Probe entsteht mit einem kleinen Generator (Bars/Buch/ctx/Heatmap für BTC, ETH,
ZEC, HYPE, Prognosespeicher mit Treibern) und `Labor.zyklus(t)` über vergangene Zeitpunkte.

**Nachtrag 29.09. (23.34):** Alle Korrekturen nach dem ersten Labor-Tag (UEBERGABE 3γ, U77–U81): Profi-Bewertung liest
pool_positions (die Darwin-Liste war ausgetrocknet), Recorder sammelt die Fills der Liste ohne Mindestbetrag, Darwin v2 im
Labor (15-min-Summe, halbe Schließung als Ausstieg, neue Kennung), Blockstatistik, XMR als fünfter Labor-Coin (HIP-3-Gebühr
×2 angenommen), Bericht mit Darwin- und Gebühren-Prüfung und allen offenen Positionen. Tests: `python3 hl_recorder.py
--selbsttest-fills` (neu), Labor-Selbsttest 24 Prüfungen, Profis-Nulltest mit Quellen-Probe. Umstellungsprobe 23.33 → 23.34
auf einer Demo-Datenbank (alte Kennungen bleiben, XMR ab dem Update, Kontotage je Coin). Nächstes: U75 (informierter Fluss),
TWAP gegen ausgelöste Orders trennen (U82), weitere Labor-Strategien (U76).

**Nachtrag 30.09. (23.35):** Dauerlast des Dashboards (UEBERGABE 3δ, U83): Abfragen über die ganze, unbegrenzt wachsende
Tabelle whale_positions plus Zwischenspeicher ohne Einzelflug stauten sich (hl_viz 366 %). Regel ab jetzt: **jüngste Stände nie
über die ganze Historie** (Fenster; offene Wal-Positionen haben alle 10 min einen Snapshot), **teure Berechnungen im Dashboard
immer mit Einzelflug** (eine Berechnung, die übrigen bekommen die vorige Antwort). Werkzeuge: Debug „Dashboard-Threads“ (jetzt mit
CPU je Thread), `python3 hl_viz.py --selbsttest-last`. Lastproben mit Millionen Zeilen gehören zu jeder Abfrage auf wachsenden
Tabellen.

**Nachtrag 30.09. (23.36):** Thread-Abzug auf 23.35 ruhig (13 Threads, dauerhafte 0 %). Dieselbe Regel galt noch nicht beim
Recorder-Start: `restore_whales` las die ganze Wal-Tabelle per korrelierter Unterabfrage (2 Mio Zeilen 40 s, quadratisch
wachsend, vor dem Start der Aufzeichnung). Jetzt `wal_zustand_laden`: 24 h vor dem LETZTEN EINTRAG, close gewinnt bei
gleichem Zeitstempel, Gesperrte nicht übernehmen (U85). Gesperrte Wale ließen geschlossene Positionen für immer im Zustand
(`del` in der H3-Bedingung), die Exposure-Zeitreihe zählte Gesperrte mit (U86). Debug „Dashboard-Threads“ zeigt jetzt auch
die Gesamt-CPU des Prozesses: Kurze Anfragen fehlten in der Liste je Thread (U87). Einzelheiten: UEBERGABE 3ε.

**Nachtrag 30.09. (23.37):** Aktive Profis (UEBERGABE 3ζ, U88–U90). Zwei Dinge zugleich:
(1) Eigener Fehler aus 23.34: Die Masterregel zählte die kleinen Fills, die seit U79 nur für Darwin-Konten gespeichert
werden -- die besten Mitglieder wurden vorläufig gesperrt und fielen von der Liste. Regel ab jetzt: **Wenn eine Messung
für eine Teilmenge erweitert wird, prüfen, welche Regeln diese Messung lesen** (hier: Masterregel, Vorhalt).
(2) Darwin-Regeln v2: streng hinein (Glück ≤ 1 %, 14 T), großzügig bleiben (Glück ≤ 50 %), Abstieg nach 3 Tagen.
Die Tagesentscheidung ist die reine Funktion `hl_profis.darwin_tag` (im Nulltest geprüft). Regeländerungen an der Liste
vorher simulieren (Population mit und ohne Vorsprung, Anteil der Könner auf der Liste, Zufallsaufnahmen je Woche).

**Nachtrag 30.09. (23.38):** Bericht vom ersten Tag mit 23.37 (UEBERGABE 3η, U91–U96).
(1) Darwin-Regeln v3: Die Schonung (Verbleib großzügig, 3 Fehltage) gilt nur für Konten mit strenger Aufnahme (Merker
`streng`); der Umstieg auf v2 hatte sie auch Altbestand und einer Rückkehr über die Verbleib-Regel gegeben. Lehre: **Bei
einem Regelwechsel mit Hysterese festlegen, wer beim Umstieg in welchem Zustand startet** -- sonst umgeht der Übergang die
strenge Seite. (2) Die Neubewertung der Masterregel gab ein Konto frei, bei dem kein kleines Bündel mitgezählt war
(Nachzählung zu niedrig, vermutlich gelöschte Rohfills); jetzt muss die Nachzählung die Sperre nachvollziehen, die Freigabe
ist zurückgenommen. Lehre: **Eine Neubewertung vergleicht mit Daten, die inzwischen der Vorhalt gekürzt haben kann.**
(3) API-Gewicht hart gedeckelt (gleitendes Fenster, Klemme, leerer Start); der Begrenzer wird jetzt in virtueller Zeit
geprüft. (4) Eine eigene Aussage war falsch: SilkBtc flog nicht wegen des Zählfehlers, sondern nach den alten Regeln.

**Nachtrag 30.09. (23.39):** Zwei Kopier-Vorlagen im Labor (UEBERGABE 3θ, U97–U99): „Darwin-Liste live folgen“ und neu
„Elite live folgen“, nach derselben Regel und je mit Gegenprobe; die Kopier-Logik ist eine Funktion mit Zustand je Vorlage.
Lehre: **Ein Prüfwerkzeug rechnet mit denselben Funktionen wie das System** (check_elite hatte eine eigene Einstufung und
keinen Sperrfilter und zeigte deshalb eine andere Elite als die, die das System nutzt). Das Labor läuft jetzt bis zur
Auswertung U99 (ab 11.10.) unverändert weiter; Regeländerungen an Strategien nur mit neuer Kennung.

**Nachtrag 01.10. (23.40):** Grid-Bots im Labor (UEBERGABE 3ι, U100–U102): „Grid Long“ und das Spiegelbild „Grid Short“
mit eigener Mechanik in `hl_labor.py` (`_grid*`; die übrigen Strategien überspringen sie). Bewertet nach Bestandswert
(Tagesergebnis = realisiert + Änderung des unrealisierten Bestands, `labor_grid_tag`), nicht nur realisiert. Lehren:
(1) **Eine neue Strategie vor dem Einfrieren auf einem synthetischen Markt mit den Szenarien laufen lassen, die der Nutzer
beschreibt** -- hier hätte ein 15-min-Auslöser den Wunsch „nicht zu früh verkaufen“ in einer schnellen Rallye verfehlt, und
ein Trendmaß ohne Richtung baute dreimal in einen Abwärtstrend hinein. (2) **Bei Strategien mit Bestand (Grid, DCA) nie nur
realisierte Gewinne zählen.** (3) **Regeln mit Mutationen prüfen**: Drei Regeln (Kapitaldeckel mit alten Losen, Stop in der
Auslöserkerze, Notlinie) trafen die Szenarien nicht zuverlässig -- dafür Mikro-Proben auf festen Kerzen. Ungefragt mit
geliefert: die Antwort auf „verzögern lange Läufe die Signale?“ (nein; U95-Kriterium präzisiert).

**Nachtrag 02.10. (23.41):** „database is locked“ im Labor (UEBERGABE 3κ, U103) -- eigener Fehler aus 23.40: ein von Hand
ausgeführtes `BEGIN` öffnete eine Lese-Transaktion, ein fremder Commit machte ihren Stand veraltet, der nächste Schreibzugriff
scheiterte sofort. Lehre: **Eine Transaktion, die liest und danach schreibt, beginnt im WAL-Modus immer mit `BEGIN IMMEDIATE`**
(seit dem 14.09. im Recorder so, `hl_dbcoord` warnt davor) -- vor jedem neuen `BEGIN`/`SAVEPOINT` im Code nach dieser Stelle suchen.
Dazu der Praxis-Hinweis zu den Grids: Hyperliquid verrechnet Long und Short je Konto und Coin; live bräuchte jede Strategie einen
eigenen Sub-Account.

**Nachtrag 04.10. (23.42):** Fusionsprognose, Kalibrierung v3 und Kostenschwelle -- Stufe 1 von `KONZEPT_Fusion.md`, alles im
Schatten (UEBERGABE 3λ, U104–U112). Neu `hl_fusion.py`: Kostenschwelle p* = ½ + K/(2·E|r|) je Coin und Horizont; v3 = v2 über alle
Coins geteilt auf den Familienwerten; Fusion = Expertenmischung (Basisrate, v1, v2, v3, Analog) mit Garantie gegenüber dem besten
Experten, prequential in `fusion_fall`; zwei Labor-Strategien. Auswertung U108 ab 25.10.; umgeschaltet wird nur mit Beleg. Lehren:
(1) **Standardfehler über Coins zählen Zeitblöcke als Klumpen** -- Blöcke verschiedener Coins zur selben Zeit hängen zusammen (in der
Probe war der naive Standardfehler 1,75-mal zu klein). (2) **Die 1-SE-Regel braucht einen GEPAARTEN Standardfehler**; die Streuung der
Fold-Mittel enthält die gemeinsamen Unterschiede der Folds und macht die Regel übervorsichtig. (3) **Erwartungen einer Probe aus der
Mathematik ableiten, nicht aus dem Gefühl:** Fixed Share hält Gewichte gemischt, schlafende Experten behalten ihr Gewicht -- zwei
Prüfungen waren zuerst falsch formuliert, nicht der Code. (4) **Anzeige gehört nicht in den gespeicherten Payload** (sonst +4,2 kB je
Prognosezeile). Rechenhilfe für Erwartungen: 14 Tage Halbwertszeit über 90 Tage = rund 237 effektive 4-h-Blöcke je Coin
(Standardfehler der Trefferquote 3,3 Punkte).

**Nachtrag 04.10. (23.43):** Kaskaden-Gleichung, Stufe 2b von `KONZEPT_Fusion.md` (Abschnitt 4b), alles im Schatten (UEBERGABE 3μ,
U113–U117). Anlass war die Frage nach einer „komplexen Funktionsgleichung“ für den Kurs. Antwort: Für den Kurs gibt es keine, für
seine Verteilung schon.

Neu `hl_kaskade.py`:
- Wurzelgesetz I = Y · σ_Tag · √(Q / V_Tag) auf die Liquidationscluster der Heatmap.
- Kaskade als Fixpunkt mit geschlossener Form für P(Ausschlag ≥ m).
- Kipppunkt und Ende je Seite.
- Schatten-Treiber „Kaskaden-Asymmetrie“ und Familie „Kaskaden“.
- Kalibrierung Y je Coin und Horizont mit Placebo und Seitenspiegel.
- Labor-Strategie „Kaskaden-Kipppunkt“.

Urteil ab 25.10. (U115). Lehren:
1. **Ein Zeit-Placebo allein reicht nicht.** Nahe Cluster gehen oft mit höherer Schwankung auf BEIDEN Seiten einher. Erst der
   Seitenspiegel (dieselben Cluster, Seiten vertauscht) trennt Mechanik vom Mitlaufen; in der Probe ließ das Placebo allein 1 von 4
   Störfaktor-Läufen durch.
2. **Lastproben müssen die Breite eines Datensatzes abbilden, nicht nur die Länge.** Mit 100 Eimern je Heatmap-Stand war alles
   schnell. Mit 800 Eimern kostete das Lesen ganzer Stände 354 MB je 30 Tage, rund 1 GB bei 90 Tagen im Dashboard-Prozess. Jetzt
   laufen je Block gezielte Abfragen: der erste Stand per `MIN(ts)` über `ix_heat_coin_ts`, die Eimer per Bereich im Primärschlüssel.
3. **Wer einen Weg schneller macht, braucht ein Orakel.** Der alte Weg bleibt als Vergleich im Selbsttest. Zwei Mutationen (zu
   schmales Fenster, letzter statt erster Stand) fängt NUR diese Prüfung.
4. **Ein Schatten-Treiber außerhalb von PRIORS** bleibt aus dem v1-Lernen und aus v2 heraus. Er steht aber in `forecast_drivers`,
   also in Familien, Ereignis-Profilen und Hygiene. Seine Trefferzelle in der Treibertabelle braucht einen eigenen Text, sonst steht
   dort „nie |Score| > 0,05“.

**Nachtrag 04.10. (23.44):** Die erste echte Kalibrierung der Kaskaden-Gleichung vom Pi (UEBERGABE 3ν, U118, `KONZEPT_Fusion.md`
4b.1a). Nichts belegt; BTC 1 h am nächsten. Große Ausschläge wurden in allen Coins rund halb so oft vorhergesagt wie eingetreten.
Behoben mit gemischter Schwankung (τ), dazu Spiegel beim gleichen Y, Richtungsprobe ab 20 Blöcken und ein isolierter Selbsttest.
Treiber und Kipppunkt bleiben unverändert. Lehren:
1. **Synthetische Proben brauchen die Eigenschaften echter Kurse,** nicht nur die geprüfte Mechanik: Schwankung mit Gedächtnis und
   dicke Ränder. Die Proben von 23.43 bestand das Modell, der echte Markt widerlegte es am ersten Abend. Der Testmarkt hat jetzt
   `sv_tau`.
2. **Erst die echten Daten ansehen, dann die nächste Stufe bauen.** U110 hätte auf dem falschen Nullmodell gestanden.
3. **Eine Schutzbedingung kann still in eine andere zusammenfallen.** Der Spiegel mit eigenem Y war bei Y = 0 dieselbe Rechnung wie
   „Y = 0 gegen gewählt“. Vergleiche gehören auf gleiche Komplexität.
4. **Selbsttests dürfen den echten Speicher nicht berühren.** Python bindet Standardwerte beim Definieren
   (`learned_save(..., path=STORE)`). Wer `F.STORE` umlenkt, muss den Pfad ausdrücklich übergeben. Die Mutationsprobe legt dafür
   einen Köder-Speicher an.
5. **Kleine n:** Ohne Mindestzahl keine z-Werte, und z nimmt den Standardfehler der Nullhypothese.

**Nachtrag 04.10. (23.45):** Die zweite Kalibrierung vom Pi bestätigt 23.44 (22 von 22 „vorhergesagt ≈ eingetreten“ ✓,
`KONZEPT_Fusion.md` 4b.1b). Gebaut: U110 Magnet-Test (`hl_magnet.py`, UEBERGABE 3ξ), nur Messung. Er prüft, ob der Kurs Cluster
öfter berührt, als die geprüfte Rechnung ohne Cluster erwarten lässt, mit Spiegel und Placebo; Urteil ab 25.10. Mutationen
16 von 16 rot. Lehren:
1. **Eine Eigenschaft gilt nur mit ihrer Bedingung.** Das seitengleiche Mittel heißt „trendfest“, ist es aber nur, wenn beide
   Seiten Fälle haben. Die Trendfalle (Abwärtstrend, nur Long-Cluster) zeigte es; jetzt zählen wirksame Fälle (eine Seite = 0).
2. **Jede Schutzbedingung braucht einen Testmarkt, in dem nur sie hält.** Sonst prüft der Selbsttest sie nicht wirklich: Der
   Störfaktor wie im Kaskaden-Test brachte den Überschuss nur einmal über 2 SE; erst „nur große Cluster koppeln“ zeigt den Spiegel.
3. **Nicht jede Falle ist eine Lücke.** Die Niveau-Welt (der Kurs läuft zu festen Niveaus, dort liegen Cluster) wird belegt. Das
   ist die Grenze des Tests (Vorhersage, nicht Ursache), offen benannt. Ein Placebo mit alten Preisen würde echte, tagelang offene
   Positionen mitnehmen.
4. **Testmärkte nur mit Parametern erweitern, die ohne Wert nichts ändern** (keine zusätzlichen Zufallszahlen). Der Kaskaden-Selbsttest
   liefert danach Zahl für Zahl dasselbe.
5. **Kleine Probe, falscher Alarm:** Mit 12 Seeds lag die Streuung der Spiegel-Differenz (klein) beim 1,38-Fachen des berechneten
   Standardfehlers; mit 40 Seeds liegt sie bei 0,82–1,08 über alle Größen und Kontrollen. Erst genug Wiederholungen, dann eine
   Korrektur.

**Nachtrag 04.10. (23.46):** Nutzerfund vor dem Einspielen von 23.45: In den Treiberfamilien (BTC, „Kaskaden“) stand z = 1,2 · 10¹⁶ bei
n = 3 (UEBERGABE 3ο, U119). z = Mittel / Stichproben-Streuung; drei gleiche Treffer haben Streuung 0, im Fließkomma 6,8 · 10⁻¹⁷.
Jetzt rechnen Treiberfamilien und Heatmap-Anker das z einer Trefferquote exakt (`hl_forecast.z_treffer`: Summe von Binomialen je
Erwartung, mittlerer p-Wert, |z| ≤ 7); die Ereignis-Profile geben ohne Streuung kein z. 23.46 enthält 23.45. Lehren:
1. **Bei Trefferquoten nie die Stichproben-Streuung in den Nenner,** sondern die des Zufalls (oder exakt). Bei wenigen gleichen Werten
   ist sie 0 bzw. 10⁻¹⁷, `> 0` schützt nicht.
2. **Einen Fehler auch in den Kopien suchen:** Dieselbe `_stat`-Funktion stand im Heatmap-Anker, wo „belegt“ die Hauptprognose
   ändert, und dieselbe Rechnung in den Ereignis-Profilen.
3. **Auch eine kleine Probe braucht ihre Mutationen:** Die erste Fassung der Anker-Prüfung hätte die alte Formel nur durch einen
   Absturz verraten (z war None). Jetzt prüft sie den exakten Wert.

**Nachtrag 05.10. (23.47):** Makro-Chart (UEBERGABE 3π, U121, `KONZEPT_Makro.md`). Auf Wunsch des Nutzers alles Kostenlose aus der
Recherche `RECHERCHE_Makro_Chart_05-10-2026.md` (Stufen 1 und 2), je Treiber ein Chart, dazu die Miner-Kostenbasis (Antminer S21 XP,
13,5 J/TH, 7,5 ct/kWh; Annahme US-Cent, Euro-Cent umschaltbar).
- Eigene Datenbank `makro.db` neben `hl_liq.db`, geschrieben nur vom Makro-Takt im Dashboard-Prozess (`BEGIN IMMEDIATE`), gesichert
  mit dem täglichen Backup.
- Wirkt auf nichts anderes: keine Prognose, kein Treiber, kein Labor, kein Hyperliquid-API-Gewicht. Fusion, v3 und Kaskaden
  unberührt (Zusage bis 25.10.).
- Im Paket außerdem U120 (v2-Kachel misst den Brier-Skill gegen denselben Kalibrierschritt mit c = 0) und U122 (Selbsttest
  „Recorder: Masterregel ohne Kleinfills“ lief mit der echten Uhr und ist seit 05.10. rot -- auch mit 23.46; das System rechnet
  richtig).

Lehren:
1. **Tests mit festen Daten brauchen eine feste Uhr.** Eine vorläufige Sperre „vor dem 29.09.“ war am Tag des Schreibens 2 Tage
   alt, am 05.10. 7 Tage: Die Sieben-Tage-Regel gab sie frei, der Test wurde rot. Das Muster (U34/U36) war bekannt.
2. **Freie Quellen fallen still aus.** Verschwindet eine Metrik oder ändert eine Seite ihr Format, antwortet der Abruf oft
   weiter fehlerfrei. Deshalb prüft der Makro-Stand das Alter jeder Reihe und meldet Reihen, die nach einem erfolgreichen Abruf
   fehlen. Das war mein eigenes Abnahmekriterium; ich habe es erst beim Schreiben der Doku als fehlend bemerkt und nachgebaut.
3. **Anlauf verwerfen, bevor man Extremwerte vergleicht:** Das MVRV beginnt 2010 mit 146 (Anlauf der realisierten
   Kapitalisierung). Erst mit 180 verworfenen Tagen stimmen die Epochen-Hochs mit der Literatur.
4. **Ein Modul, das ein anderes im Speicher hält, liefert nach dem Kopieren noch die alte Fassung:** Der lokale Testserver
   lieferte `/makro.js` nach einer Änderung weiter aus dem schon importierten Modul. Nach Änderungen an `hl_makro_js.py` den
   Dienst neu starten (auf dem Pi tut das das Update).

## 7. Bekannte Schwächen, die man kennen muss

- Trades/Aktivität sind nur für die verfolgten Coins messbar (Stream); Leaderboard-Konten haben zusätzlich REST-Fills aller Coins → leicht ungleiche Aktivitätszählung (U5-Feinheit).
- Placebo im Exit-Lift über Coins gemittelt (Verfeinerung offen).
- v1-Trefferbilanz je Treiber ist in-sample; Lift/z gegen Randverteilungen vorhanden; OOS ab 25 Blöcken.
- Konstellationen: Auswahl-Effekt (Top-12 von ~400 Prüfungen) ist ausgewiesen, aber die Tabelle wirkt immer beeindruckend — nur die Stabilitätsliste (z ≥ 2 an ≥ 14 Tagen) zählt.
- Sicherheit: Dashboard ohne Anmeldung im Heimnetz (Host-Allowlist für POST), Update ohne Signatur (S2), sudo-Passwort im Klartext (S3) — Betriebsentscheidungen des Nutzers.

## 8. Kompatibilität dieser Übergabe

- Modellunabhängig: keine Sitzungs-, Transkript- oder Speicherfunktion wird vorausgesetzt. Alle Fakten stehen in den Dateien.
- Historische Dateinamen mit „FABLE" bleiben (Änderungsprotokoll); Autorenvermerke in README/UEBERGABE/REVIEW sind auf
  „Fable 5.1 bis 23.09., fortgeführt mit Opus 5.5" angepasst.
- Die Werkzeuge der Sandbox (numpy, node, playwright, kein Netz) sind Annahmen dieser Umgebung; in einer anderen
  Umgebung Abschnitt 4 entsprechend prüfen.

## 9. Erste Schritte in der neuen Sitzung (Vorschlag)

1. Abschnitt A des Plans mit dem Nutzer (Version 23.10 einspielen lassen, Rundum-Funktionstest, Netzwerkstatus).
2. Ausstehende Proben abfragen: P2 (K1: Liquidationen nach Methode, ≤ 10 beobachtete Konten) und P1 (Coinbase-Seite).
3. U8 (H10 Bilanz der Empfehlungen) ist seit 23.16 gebaut — jetzt LESEN: Debug „★ Bilanz der Kauf-/Verkaufsempfehlungen (U8)“,
   wöchentlich; aussagekräftig erst nach einigen Wochen.
   Seit 23.20 laufen die Prüf-Einträge von selbst (Berichtsplan `hl_viz.BERICHTSPLAN`, Dateien in `berichte/`). Der Nutzer lädt
   die Sammeldatei aus dem Debug-Bereich hoch. Neue Termine trägt Claude dort mit dem nächsten Paket ein.
4. Ab 6.10. U3b entscheiden. U7b (v2 aktivieren, inkl. Pfad): seit 05.10. auf den 25.10. gelegt, zusammen mit U108 (Plan U7b: Schalter allein unvollständig, Labor-Strategie „Prognose“ liest `p_up`).
