# PROJEKTÜBERGABE — Hyperliquid-Analysesystem („hl_liq_project")
**Für den Import in eine neue Sitzung (Claude Opus 5.5) · Stand 23.09.2026, Version 2026-09-23.10**
Erstellt bis hierher mit Claude Fable 5.1 (Sitzungen 1–5, 13.–23.09.2026); Auditberichte v9/v10 kamen von Opus 5.5.

> **So beginnst du:** (1) Diese Datei ganz lesen. (2) `UPDATE_PLAN.md` lesen — Abschnitt A abarbeiten (Prüfungen),
> Abschnitt B ist die Reihenfolge der offenen Arbeiten. (3) Das Paket `hl_liq_project.zip` ist die einzige Wahrheit;
> Chats und alte Transkripte sind nicht verfügbar. Alles Wissen steht in den Dateien des Pakets.

---

## 1. Was das System ist

Ein Analysesystem für Hyperliquid-Perpetuals (BTC, ETH, HYPE, ZEC, PAXG, XMR) auf einem **Raspberry Pi 5**
(Python 3.13, SQLite, systemd), mit vier Diensten:

| Dienst | Datei | Aufgabe |
|---|---|---|
| Recorder | `hl_recorder.py` | Hyperliquid-API und WebSocket: Positionen aller großen Konten (Poller in Stufen), Leaderboard-Top-75 (alle 2 min), Fills (Stream + REST-Nachtrag), Orders, Liquidationen (beobachtet + abgeleitet), Kerzen, Heatmap-Snapshots, Pool „Aktive Profis", Masterregel Sperre, Backup |
| Dashboard | `hl_viz.py` | Web-UI (http://<pi>:8765), alle Charts/Abschnitte, Prognose-Berechnung (Lernzyklus, Kalibrierung v1/v2, Scores, Profis, Konstellationen), Debug-Konsole, Update/Restore |
| Fremdbörsen | `hl_binance.py` (+ `hl_ext.py`) | Binance, Bybit, OKX, Crypto.com: Liquidationen, Funding, Kennzahlen, ETF-Flüsse (Farside) |
| Coinbase | `hl_coinbase.py` | Spot-Matches (Taker-Flow), Orderbuch, Kerzen |

Kernfunktion: **Liquidations-Heatmap** (wo liegen Liquidationspreise großer Konten) und eine **Prognose**
(30 Treiber → Wahrscheinlichkeit/Pfad), dazu Konten-Analysen (Wale, Leaderboard, Elite, Aktive Profis).

## 2. Dateien im Paket (82)

- **Kern:** `hl_recorder.py`, `hl_viz.py`, `hl_forecast.py` (Treiber, Pfad, Kalibrierung v1, Bewertung),
  `hl_indikatoren.py` (neue Treiber 14.09.), `hl_score.py` (Konto-Score, Elite), `hl_profis.py` (Aktive Profis),
  `hl_kalib.py` (Kalibrierung v2, Schatten), `hl_konstellation.py` (Paar-Statistik, Vorbedingungen),
  `hl_ext.py`, `hl_binance.py`, `hl_coinbase.py`, `hl_dbcoord.py` (Schreibsperre), `hl_watchdog.py`,
  `hl_timestats.py`, `hl_backtest.py`, `macro_corr.py`, `run_all.py`, `install.py` (Installation + `--selftest`),
  `update.py` (Update/Restore), `migrate_db.py`, `version.py` (Version + Prüfsumme).
- **Werkzeuge (Debug-Konsole):** `check_*.py` — sources, fills, leaderboard, forecast, writes, report, m9, magnet,
  elite, treiber (Harness, 77 Szenarien), pool, sperre, profis, daily, orders; `db_size.py`;
  `make_treiber_pdf.py`/`_en.py` (Treiber-Dokumentation als PDF).
- **Dokumente:** `README.md` (Betrieb), `UEBERGABE_13-09-2026.md` (chronologisches Änderungsprotokoll, Abschnitte
  3a–3fff), `UPDATE_PLAN.md` (lebendes Arbeitsdokument), `REVIEW_Audit_v10_22-09-2026.md`, `KONZEPT_Aktive_Profis.md`,
  `PROPOSAL_Kalibrierung_Stufe2_3.md` (historisch, durch den K2-Neubau ersetzt), `AENDERUNGSKONZEPT_v2_FABLE_13-09-2026.md`
  (historisch), `labels.json` (eigene Kontonamen, Sperren/Schutz), `accesstokens.json`, `android/` (WebView-App).

## 3. Eiserne Regeln (nie brechen)

1. **Zeitstempel in Sekunden** (Ausnahme: `addresses.last_trade/first_seen` in ms; Grenze 1e11).
2. **Seiten** normalisiert `long`/`short`; Klassen `dir`/`mixed`/`hedge`/`mm`; `liquidations.side` ist roh `A`/`B` (A = Long liquidiert).
   `cb_bars.buy_usd/sell_usd` sind vor `cb_meta` 'seite_umstellung' VERTAUSCHT gespeichert (U41) — nur mit `hl_forecast.cb_seite_ab` lesen.
3. **API-Gewicht:** Deckel 90 % von 1.200/min (1.080), Begrenzer mit Rang (0 Leaderboard, 1 Poller/Orders, 3 Fills) und
   arbeitserhaltender 20-%-Reserve für den Hintergrund. **userEvents-Abos: höchstens 10 Nutzer je IP** (Hyperliquid-Limit).
4. **n_eff = getrennte Horizont-Blöcke**, nie Fensterzahl. Jeder Treiber braucht einen **Nulltest**; die Kalibrierung
   zusätzlich die **Positivkontrolle** (Kante 0,65 → p 0,60–0,70) — sie ist Selbsttest-Schritt 22 und ein Tor.
5. **Masterregel Sperre:** > 300 gebündelte Trades (je Coin, Minute, Richtung) in 24 h an ZWEI Tagen binnen 7 Tagen = dauerhaft
   gesperrt; nach dem ersten Tag vorläufig ausgeschlossen, ohne zweiten Tag nach 7 Tagen frei (seit 23.29; 23.13–23.28 ein Tag;
   vorher > 2.000 Fills, alte Sperren einmalig neu bewertet) (kein Signal, keine Orders, keine Fill-Speicherung,
   Positionen nur alle 6 h für die Heatmap). Manuell: `labels.json` `"sperre": true/false`.
6. **Elite:** n ≥ 10 Schritte im Coin, Vorlauf > 0, t ≥ 1 (auf nicht überlappenden Blöcken), Gewinn-Schranke
   (PnL 30 T > 0, Position ≤ 3 % unter Wasser), Aktivitätsschranke ≤ 300 Trades/Tag.
7. **Aktive Profis:** Pool = Kontowert ≥ 1 Mio und Tagesumsatz ≥ 500k (Leaderboard-Datei); Qualifikation 7 T:
   2–150 gebündelte Trades/Tag **in den verfolgten Coins** (seit 23.31; vorher 5–150); seit 23.32 Timing über ALLE Ein- und Ausstiege
   (mindestens 4, Glückswahrscheinlichkeit ≤ 5 % gegen die Zufallsquote je Coin und Richtung, Einstiege ab 5 nur als Veto) statt Exit-Lift ab 5 Ausstiegen; Gewinn 7 T > 0, Exit-Lift > 0 mit t ≥ 1, Entry-Lift nicht
   signifikant negativ (Variante 2; strenge Variante = U3b). Rang: eigene ROI 12 h, sonst HL roi_1d.
8. **Version und Prüfsumme sind gepaart:** Jede Codeänderung → `version.py` hochzählen (Format `JJJJ-MM-TT.n`). Die
   Systemkachel „Version" zeigt beides; der Nutzer gleicht ab.
9. **Paketname immer `hl_liq_project.zip`** (Update-System des Pi). Inhalt: alle Projektdateien in einem Ordner
   `hl_liq_project/` plus `android/`.
10. **Dokumente in derselben Antwort aktualisieren:** `UEBERGABE` (neuer Abschnitt 3xxx oben nach „## 0."), `UPDATE_PLAN`
    (Status, Stand, neue Punkte). Was dort nicht steht, existiert nicht.

## 4. Arbeitsweise in der Sitzung (Sandbox)

- Arbeitsverzeichnis `/home/claude`; Paket dorthin entpacken (`unzip -o hl_liq_project.zip && cp -r hl_liq_project/* .`).
- **Keine Netzverbindung** in der Sandbox (kein pip, keine API); numpy, node, playwright sind vorhanden.
- **Tests:** `python3 install.py --selftest` (23 Schritte, ~5 min; im Hintergrund starten und Log greppen),
  `python3 check_treiber.py` (Harness), `python3 hl_forecast.py --nulltest`, `python3 hl_kalib.py --nulltest`,
  `python3 hl_profis.py --nulltest`, `python3 hl_konstellation.py --nulltest`, `python3 hl_score.py`,
  JS-Syntax: alle `<script>`-Blöcke aus `hl_viz.PAGE` extrahieren und mit `node --check` prüfen.
  Recorder-Simulation: `python3 hl_recorder.py --db s.db --simulate` (erzeugt Testdaten, ~2 min).
  Dashboard lokal: `setsid nohup python3 hl_viz.py --db s.db --serve --port 91xx &`, dann curl/playwright.
- **Patches:** Text-Ersetzungen mit `assert s.count(o) == 1` je Anker (Unikat!). Anker vorher mit grep prüfen;
  bei Python-Heredocs keine deutschen Anführungszeichen/Gedankenstriche in doppelt-quotierten Strings (Syntaxfehler) —
  Patch-Skripte als Datei (`create_file`) schreiben, nicht als Heredoc. Lange Befehle werden abgebrochen: Schritte klein halten.
- **Packen:** Ordner `hl_liq_project/` aufbauen (Dateiliste in Abschnitt 2), `python3 version.py` im Ordner drucken,
  `zip -rq /mnt/user-data/outputs/hl_liq_project.zip hl_liq_project`, danach `present_files`.
- **Vor dem Packen:** `rm -f s.db* forecasts.db* labels_cache.json sys_history.json` (Testdateien nicht mitliefern).

## 5. Der Nutzer und seine Vorlieben

Deutschsprachig, technisch versiert, betreibt das System selbst (Update-Knopf im Dashboard, Debug-Einträge, Screenshots).
Erwartet: erst Daten prüfen, dann entscheiden; Fehler klar benennen (auch eigene); keine Behauptungen ohne Beleg; jede
Änderung mit Probe; Zahlen mit Intervallen; keine neuen Fehlerquellen. Er liefert Debug-Ausgaben und Screenshots auf
Anfrage — konkret sagen, welcher Debug-Eintrag gebraucht wird. Lange Erklärungen nur, wenn er fragt („Für mein Verständnis…").
Antworten enden mit Version · Prüfsumme des Pakets.

## 6. Aktueller Stand (23.09.2026)

- Pi läuft Version 23.6 (laut Nutzer 11:20); 23.7–23.10 bereit. Alle Quellen grün, Leaderboard 82 s/17,5 s, Fills 593 s,
  15 Gesperrte, Fills-Stream 668 Konten, keine 429.
- **Kalibrierung:** v1 (alt, trägt die Prognose) ist strukturell lernunfähig (Audit v10 K2, selbst nachgestellt);
  v2 (`hl_kalib.py`) läuft im Schatten, Tor bestanden; Umschalten = U7b nach 1–2 Wochen, wenn die direkte Bilanz v2 ≥ v1.
  **Beim Umschalten auch den Pfad (Bias) auf v2 umstellen** (offen, Teil von U7b).
- **Aktive Profis:** Phase 0–3 + U5 live; erster echter Lauf: 692 Pool → 73 aktiv mit Gewinn → 6 qualifiziert.
- **Konstellationen/Vorbedingungen:** Stufe 1 live (Anzeige + Tageshistorie); Stufe 2 (Interaktionsterme in v2) wartet auf stabile Paare.
- **Audit v10:** Stand 23.16 siehe Plan; U8 gebaut, offen U7b, U9–U13, U16–U24, U27, U29, U35, U36, U38. Proben P2 (K1) und P1 (Coinbase-Seite) bestanden (U1, U2).
- **Geklärt heute:** Leaderboard-Flow „0 Konten in 60 min" = ruhige Stunde, nur 6 der Top-75 halten BTC (U26 geschlossen);
  Vorschlag U27: Flow-Treiber auf Basis der qualifizierten Profis.

## 7. Bekannte Schwächen, die man kennen muss

- Trades/Aktivität sind nur für die verfolgten Coins messbar (Stream); Leaderboard-Konten haben zusätzlich REST-Fills aller Coins → leicht ungleiche Aktivitätszählung (U5-Feinheit).
- Placebo im Exit-Lift über Coins gemittelt (Verfeinerung offen).
- v1-Trefferbilanz je Treiber ist in-sample; Lift/z gegen Randverteilungen vorhanden; OOS ab 25 Blöcken.
- Konstellationen: Auswahl-Effekt (Top-12 von ~400 Prüfungen) ist ausgewiesen, aber die Tabelle wirkt immer beeindruckend — nur die Stabilitätsliste (z ≥ 2 an ≥ 14 Tagen) zählt.
- Sicherheit: Dashboard ohne Anmeldung im Heimnetz (Host-Allowlist für POST), Update ohne Signatur (S2), sudo-Passwort im Klartext (S3) — Betriebsentscheidungen des Nutzers.

## 8. Kompatibilität dieser Übergabe

- Modellunabhängig: keine Sitzungs-, Transkript- oder Speicherfunktion wird vorausgesetzt. Alle Fakten stehen in den Dateien.
- Historische Dateinamen mit „FABLE" bleiben (Änderungsprotokoll); Autorenvermerke in README/UEBERGABE/REVIEW sind auf
  „Fable 5.1 bis 23.09., fortgeführt mit Opus 5.5" angepasst.
- Die Werkzeuge der Sandbox (numpy, node, playwright, kein Netz) sind Annahmen dieser Umgebung; in einer anderen
  Umgebung Abschnitt 4 entsprechend prüfen.

## 9. Erste Schritte in der neuen Sitzung (Vorschlag)

1. Abschnitt A des Plans mit dem Nutzer (Version 23.10 einspielen lassen, Rundum-Funktionstest, Netzwerkstatus).
2. Ausstehende Proben abfragen: P2 (K1: Liquidationen nach Methode, ≤ 10 beobachtete Konten) und P1 (Coinbase-Seite).
3. U8 (H10 Bilanz der Empfehlungen) ist seit 23.16 gebaut — jetzt LESEN: Debug „★ Bilanz der Kauf-/Verkaufsempfehlungen (U8)“,
   wöchentlich; aussagekräftig erst nach einigen Wochen.
   Seit 23.20 laufen die Prüf-Einträge von selbst (Berichtsplan `hl_viz.BERICHTSPLAN`, Dateien in `berichte/`). Der Nutzer lädt
   die Sammeldatei aus dem Debug-Bereich hoch. Neue Termine trägt Claude dort mit dem nächsten Paket ein.
4. Ab 6.10. U3b entscheiden; ab ~7.10. U7b (v2 aktivieren, inkl. Pfad) prüfen.
