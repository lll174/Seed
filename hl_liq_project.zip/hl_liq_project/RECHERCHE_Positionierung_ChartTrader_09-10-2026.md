# Bewertung: Fear & Greed, Binance-Top-Trader, Market Maker, Hebel gegen Spot, Chart-Analyse-Trader

**Projekt:** hl_liq_project · **Stand:** 09.10.2026, 02:30 · **Version des Systems:** 2026-09-23.62 (unverändert, nur Dokumente)
**Anlass:** Nutzerfrage 09.10. 02:05 · **Kurzfassung im Paket:** UEBERGABE 3νν · **Plan:** U142, U143 (UPDATE_PLAN)
**Nachtrag 09.10. nachts (03:50):** U142 ist gebaut (Version 23.63, `hl_hebel.py`, UEBERGABE 3ξξ). Maßgeblich sind die Regeln in `KONZEPT_Hebel.md` (dort u. a. H2 über einen Tag statt drei); Abschnitt 7 unten ist das Vorkonzept.
**Nachtrag 10.10. mittags:** Erster Lauf (08:16): H1 „Konten ≥ 3 → Rücksetzer“ erfüllt die Bedingung (RR 2,77; 20,3 % gegen 7,4 %), H2 „Top-Trader-Regel → Richtung“ nicht (die Regel steht fast immer auf „Kauf“), H3/H4 „95 % Hebel“ blieben wegen eines Ladefehlers ohne Daten (behoben in 23.64); alle Urteile vorläufig, endgültig 11.10. 08:15 (`KONZEPT_Hebel.md` 13, UEBERGABE 3ππ).

> Keine Anlageberatung. Dieses Dokument bewertet Daten und Prüfwege; es empfiehlt keine Trades.

## 0. Die Frage

Sinngemäß, in vier Teilen:

- (a) Den Fear & Greed Index als weiteren Indikator aufnehmen.
- (b) Gibt es Schnittstellen zu den Daten und Aktionen der Binance-Top-Trader? Dazu die Aktivität der Market Maker.
- (c) „Wenn es Leverage bei 95 % gegenüber 5 % Spot ist, dann wird fast immer erfahrungsgemäß eine Liquidierung durchgeführt.“
  Lässt sich das mit Binance-Daten prüfen?
- (d) Eine vollwertige Chartanalyse wie bei TradingView, gestützt durch alle gesammelten Daten als untere Schicht: Kann ein
  virtueller algorithmischer Trader auf dieser Grundlage arbeiten?

## 1. Kernaussage

Der Zugang ist nicht das Problem; fast alles wird schon gesammelt (Abschnitt 2). Offen ist der Nachweis, dass diese Daten die
**Richtung** vorhersagen. Die bisherigen Tests des Systems sagen:

| Test | Was er fragte | Ergebnis |
|---|---|---|
| U130 Makro × Kurs (Pi 06.10.) | 15 Merkmale, darunter Fear & Greed 30 T, gegen die BTC-Rendite über 1/7/30 Tage | 0 von 45 belegt (Endurteil 25.10.) |
| U110 Magnet (Woche 07.10.) | ziehen Liquidationscluster den Kurs an? | nichts belegt in 36 Tests |
| Heatmap-Anker | zeigt das Ungleichgewicht der Cluster die Richtung? | in keinem Coin belegt |
| TradeLabor (07.10.) | Wal-, Elite-, Darwin-, Orderfluss-Strategien u. a. gegen den Zufall | nichts schlägt den Zufall |
| U138 Regime (08.10.) | Beine, Analoge, Momentum | Richtung wie beim Zufallsweg; Größe (HAR) gut vorhersagbar |
| U140 Swing (08.10.) | klassische Chartregeln auf 2020–2026 | S3 und S1 positiv, nichts belegt |

Die Daten beschreiben also Größe und Risiko kommender Bewegungen, kaum ihre Richtung. Das deckt sich mit der Literatur
(`RECHERCHE_Regime_07-10-2026.md`: „Positionierung und Flüsse messen Risiko, nicht Richtung“). Daraus folgt der Vorschlag für den
Chart-Trader: **Der Chart gibt die Richtung, die Daten geben Größe, Stop und „heute nicht“.**

## 2. Was das System schon sammelt

| Bereich | Tabelle / Reihe | Takt, seit | Vorhaltefrist |
|---|---|---|---|
| Fear & Greed (alternative.me) | `makro.db` `fng:wert` | alle 6 h, Historie ab 02/2018 | keine |
| Binance-Verhältnisse: Top-Trader Positionen, Top-Trader Konten, alle Konten, Taker | `bnc_metrics` | 5 min seit 14.09. (`hl_ext`), davor 30 Tage Nachladen | keine |
| Binance Open Interest | `bnc_metrics`; Tagesstand ab 01.09.2020 in `makro.db` (`bnc:oi_btc_*`) | 5 min; Archiv vollständig (2.229 Tage) | keine |
| Binance-Orderbuch: Tiefe je Abstand, Wände je Preisstufe | `bnc_book` | 5 min seit 14.09. | 60 Tage |
| Binance-Liquidationen (Stream `!forceOrder@arr`, je Symbol höchstens eine Order je Sekunde, untertreibt) | `bnc_liquidations` | live | keine |
| Bybit (vollständig, WebSocket) und OKX Liquidationen | `ext_liquidations` | live seit 14.09. | 90 Tage |
| Bybit, OKX, Crypto.com: Kurs, OI, Funding, Taker, Long/Short, Volumen | `ext_metrics` | 5 min seit 14.09. | 90 Tage |
| Hyperliquid-Orderniveaus: größte Kauf-/Verkaufswand, Take-Profits, Stop-Cluster, Ordermix | `order_levels` | 10 min | keine |
| Hyperliquid-Konten: Wale, Leaderboard, Elite, Darwin, Pool, Fills, Positionen | diverse | laufend | je Tabelle |
| Binance-Futures-Kerzen 30 min, Funding | `swing.db` | ab 01.01.2020 | keine |

**Nicht gesammelt:** Spotvolumen (Binance-Tageskerzen holt `hl_binance` nur, wenn kein Futures-Kontrakt existiert) und die
Top-Trader-Spalten des Binance-Archivs (die Dateien werden geladen, behalten wird nur das OI).

## 3. Fear & Greed (a)

- **Bauart** laut Anbieter: Volatilität 25 %, Momentum/Volumen 25 %, Social Media 15 %, Umfragen 15 % (ausgesetzt), BTC-Dominanz 10 %,
  Google Trends 10 %. Der Index fasst also überwiegend den Kursverlauf zusammen.
- **Zyklus 2024–2026** (`RECHERCHE_Makro_Chart_05-10-2026.md`): am Hoch im Oktober 2025 nur 71; extreme Angst (5–9) im Februar
  2026, rund vier Monate vor dem Tief; 15 am 30. Juni.
- **Im System getestet:** U130 0 von 45 (Fear & Greed 30 T eines der 15 Merkmale). U141 C4 prüft „Gier ≥ 80 kündigt einen
  Rücksetzer ≥ 1,5 σ·√14 in 14 Tagen an“ gegen Zufallswege; Lauf 09.10. 12:00.
- **Stand 08.10.:** 30-Tage-Mittel 67,3, Perzentil 81,8 der eigenen Historie.
- **Bewertung:** kein neuer Baustein nötig. Wenn C4 nichts zeigt, bleibt der Index Anzeige.

## 4. Binance-Top-Trader und Market Maker (b)

### 4.1 Was Binance offiziell liefert

| Endpunkt | Inhalt | Grenzen |
|---|---|---|
| `/futures/data/topLongShortPositionRatio` | Long- zu Short-Positionswert der Top-Trader | Top-Trader = 20 % Konten mit dem höchsten Margin-Guthaben |
| `/futures/data/topLongShortAccountRatio` | Anteil der Top-Trader-Konten netto long zu netto short | dito |
| `/futures/data/globalLongShortAccountRatio` | alle Konten netto long zu netto short | — |
| `/futures/data/takerlongshortRatio` | aggressives Kauf- zu Verkaufsvolumen | — |

Raster 5 min bis 1 Tag, höchstens 500 Punkte je Abruf, per REST nur die letzten 30 Tage. Die Doku nennt inzwischen einen
API-Schlüssel (MARKET_DATA); vom Pi liefen alle vier am 04.10. ohne (check_sources). Erzwingt Binance den Schlüssel, genügt ein
kostenloser Lese-Schlüssel ohne Handelsrechte.

„Top-Trader“ heißt bei Binance: die größten Konten, nicht die besten. Ein großes Margin-Guthaben sagt nichts über Können.

### 4.2 Historie

Die Tagesdateien `data/futures/um/daily/metrics/<SYMBOL>/` auf data.binance.vision haben 5-min-Zeilen mit den Spalten
`create_time, symbol, sum_open_interest, sum_open_interest_value, count_toptrader_long_short_ratio,
sum_toptrader_long_short_ratio, count_long_short_ratio, sum_taker_long_short_vol_ratio`. Zuordnung: `count_toptrader…` =
Top-Trader nach Konten, `sum_toptrader…` = Top-Trader nach Positionswert, `count_long_short_ratio` = alle Konten,
`sum_taker…` = Taker. `hl_makro` lädt diese Dateien für BTC seit 01.09.2020 vollständig, behält aber nur das OI. Ab wann jede
Spalte gefüllt ist und welche weiteren Symbole Dateien haben, zeigt erst ein Lauf. Die öffentliche README des Archivs
(github.com/binance/binance-public-data) beschreibt nur Kerzen und Trades; „metrics“ ist undokumentiert, aber vom Pi belegt.

### 4.3 Aktionen einzelner Trader

Keine offizielle Schnittstelle. Die Copy-Trading-API betrifft das eigene Konto. Die Web-Rangliste der Futures hat undokumentierte
Endpunkte, die Drittprojekte nutzen; sie zeigt nur Trader, die ihre Positionen freiwillig teilen (Auswahlverzerrung), und kann sich
jederzeit ändern. Als Datengrundlage nicht geeignet.

Auf Hyperliquid hat das System das Bessere: jede Adresse mit Orders, Fills und Positionen, Wale, Leaderboard, Elite, die
Darwin-Liste mit Könnenstest, Kopier- und Gegenstrategien im TradeLabor. Ergebnis bis 07.10.: nichts schlägt den Zufall. Termine:
U99 Labor-Auswertung 11.10., Darwin v3 und Elite ab etwa 14.10., Urteil des Darwin-Schattens 18.11.

### 4.4 Market Maker

- Binance: anonym. Sichtbar sind Spuren: Orderbuchtiefe und Wände (`bnc_book`), Spread, Taker-Fluss.
- Hyperliquid: am Verhalten erkennbar und klassifiziert (`hl_score`; viele zweiseitige Orders, hohe Fill-Zahl, kaum Nettoposition).
  Hedges und Market Maker sind in der Konfluenz schon von den „direktionalen Walen“ ausgenommen.
- Über das vollständige Hyperliquid-Register (März 2025 bis Juni 2026, zehn größte Kontrakte) verdienen Market Maker rund
  208 Mio. USD, Front-End-Trader verlieren rund 1,11 Mrd. (Jia, Moallemi, Wang & Zeng 2026). Market Maker verdienen am Spread; ihr
  Gewinn ist kein Richtungssignal.
- Prüfbar: Dünnt sich die Buchtiefe vor großen Bewegungen aus? Das wäre ein Signal für die Größe, nicht für die Richtung (U142,
  beschreibend, solange `bnc_book` kurz ist).

### 4.5 Was heute schon in der Konfluenz zählt

Im Binance- und Fusions-Modus gibt die Konfluenz einen Kaufpunkt bei Top-Trader-Positionsverhältnis ≥ 1,5 und einen Verkaufspunkt
bei ≤ 0,67; „Konten ≥ 3“ erscheint als Hinweis „Kaskadenrisiko nach unten“ (ohne Punkt), ebenso der börsenübergreifende
Kontenschnitt ≥ 2,5 bzw. ≤ 0,6. Keine dieser Regeln wurde je einzeln geprüft. Sie bleiben, bis U142 urteilt.

## 5. Hebel gegen Spot (c)

### 5.1 Lesart und Messung

- **Lesart:** Anteil des Derivatevolumens am Gesamtvolumen (95 zu 5). Falls eine bestimmte Kennzahl gemeint ist (etwa ein Wert
  von Coinglass oder CryptoQuant), wird genau diese nachgebaut.
- **Messung:** Binance-Spot- und Futures-Kerzen enthalten Volumen, Quote-Volumen und Taker-Kaufvolumen, per REST mit voller Historie
  (Spot BTCUSDT seit 2017, USDT-Perpetual seit 09/2019) und im Archiv. Beide Endpunkte laufen vom Pi.
  - Perp-Anteil je Tag = Perp-Quote-Volumen ÷ (Perp + Summe Spot über alle BTC-Paare).
  - Daneben Spot-Taker gegen Perp-Taker (Rallye vom Hebel getragen, während Spot verkauft) und OI ÷ Spotvolumen.
  - OI ÷ Marktkapitalisierung steht schon im Makro-Chart (0,49 % am 07.10., Perzentil 73,1).
- **Falle:** BTC-Spot verteilt sich auf mehrere Paare (USDT, FDUSD, USDC, früher BUSD und TUSD). Null-Gebühren-Aktionen verschoben
  Volumen sprunghaft zwischen den Paaren; nach dem Ende der Aktion im März 2023 brach Binances Spotvolumen ein (Kaiko; Bloomberg).
  Darum alle Paare summieren, Bruchstellen markieren, die Schwelle relativ prüfen (Perzentil der eigenen 90 Tage) und die 95 % des
  Nutzers zusätzlich so, wie formuliert.

### 5.2 Was die Forschung sagt

- Hoher Carry, also teurer Hebel, kündigt künftige Crashs an (Schmeling, Schrimpf & Todorov 2023, BIS WP 1087).
- Für OI, Long/Short-Quoten und Liquidationsvolumen als Prädiktoren über 1–7 Tage fand die Recherche vom 07.10. keine begutachtete,
  außerhalb der Stichprobe getestete Studie; sie folgert eine Rolle als Crowding- und Tail-Größe (mehr Risiko großer Rückschläge,
  kein verschobener Median).
- Beispiel: Am Hoch im Oktober 2025 lag das annualisierte Funding bei fast 30 %; am 10. und 11. Oktober wurden über 19 Mrd. USD
  liquidiert (FTI Consulting). Ein Beispiel ist keine Quote.

### 5.3 „Fast immer“ braucht eine Basisrate

Liquidationswellen sind in Krypto häufig. Ein Signal zählt nur, wenn danach öfter etwas passiert als sonst. Kommt eine Welle ohnehin
an 6 von 10 Zeitpunkten, sind 8 von 10 nach dem Signal ein echter, aber kleiner Vorsprung (relatives Risiko 1,33); 6 von 10 wären
keiner. Darum misst U142 wie U141 Teil C: relatives Risiko „nach dem Signal“ gegen „sonst“, mit Intervall und Nullmodell.

### 5.4 Was „Liquidierung“ im Test heißt

- **Historie (ab 2020):** Kursausschlag ≥ 1,5 σ·√h binnen h Tagen mit gleichzeitigem OI-Abbau (OI aus dem Archiv, 5 min);
  Richtung getrennt: gegen die überfüllte Seite (Funding-Vorzeichen bzw. Long/Short-Quote).
- **Vorwärts:** echte Liquidationen — Hyperliquid vollständig, Bybit vollständig seit 14.09., Binance-Stream (untertreibt), OKX.
- **Vorhaltefristen beachten:** `ext_liquidations` 90 Tage, `bnc_book` 60 Tage. Ab Mitte November gehen die ersten Tage verloren;
  U142 sichert sie vorher in die eigene Datei.

## 6. Chart-Analyse-Trader (d)

### 6.1 Die erste Form gibt es schon

U140 S1–S4 sind klassische Chartregeln mit Stop, Nachzieh-Stop und Größe nach Risiko; U141 Z1–Z3 sind „Dip halten“. Historie
2020–2026 auf Binance-Perpetuals mit Kosten und Funding (Lauf 08.10. 21:30):

| Regel | Trades | Ø R je Trade | Sharpe/Jahr | Urteil |
|---|---|---|---|---|
| S1 Trend-Ausbruch (20-Tage-Kanal) | 343 | +0,17 ± 0,10 | 0,49 | nicht belegt |
| S2 Rücksetzer im Trend | 421 | +0,04 ± 0,05 | 0,27 | nicht belegt (≈ Zufall an Trendtagen) |
| S3 Ausbruch nach Ruhe | 206 | +0,34 ± 0,17 | 0,72 | nicht belegt (am nächsten) |
| S4 Gegenbewegung nach Übertreibung | 67 | −0,20 ± 0,13 | −0,45 | nicht belegt |

Alle laufen im TradeLabor vorwärts.

### 6.2 Der Engpass ist die Statistik

- Standardfehler der Sharpe-Ratio bei unabhängigen Renditen ≈ √((1 + SR²/2) / T), T in Jahren (Lo 2002). Für SR 0,5 mit zwei
  Standardfehlern braucht ein einzelner Markt rund 18 Jahre.
- Ein Filter, der die Hälfte der Trades aussortiert, vergrößert den Standardfehler um √2 ≈ 1,4. Jeder Filter ist ein weiterer Test.
  Ein Chart-Trader mit vielen Filtern sieht auf der Historie fast sicher gut aus, aus Zufall.
- Breite hilft mehr als Tiefe: dieselbe Regel auf vielen Märkten (Entscheidung 4 in `KONZEPT_Swing.md`, Vorhaltetest in der Breite).

### 6.3 Literatur (aus `RECHERCHE_Regime_07-10-2026.md`)

- Einzelne technische Regeln überleben bei BTC die Data-Snooping-Korrektur kaum; die beste In-Sample-Regel verlor 2018 auf BTC
  (Hudson & Urquhart 2021). Gewinne der Regeln ernten oft Risikoprämien (Anghel 2021).
- Vorab zu Portfolios oder Ensembles gebündelte Regeln schneiden außerhalb der Stichprobe besser ab (Deprez & Frömmel 2024).
- Chartmuster ändern Verteilungen, ein Gewinn ist nicht belegt (Lo, Mamaysky & Wang 2000).
- Unterstützung und Widerstand wirken, wo tatsächlich Orders liegen: Take-Profits auf runden Zahlen bremsen, Stop-Cluster
  beschleunigen nach dem Durchbruch (Osler 2000, 2001; Kavajecz 2004). Runde Zahlen bei BTC ohne Renditemuster (Urquhart 2017).

### 6.4 Der Vorteil des Systems: echte Orderniveaus

`order_levels` (Hyperliquid, alle 10 min, ohne Vorhaltefrist) speichert die größte Kaufwand unter und die größte Verkaufswand über
dem Kurs, die höchsten Take-Profits beider Seiten und die größten Stop-Cluster; `bnc_book` die Binance-Wände. Die Support- und
Resistance-Linien im Live-Chart sind genau diese Niveaus — keine gezeichneten Linien, sondern gemessene Orders. Geprüft sind bisher
nur Anziehung (Magnet U110) und Richtung (Anker) der Liquidationscluster. Ob der Kurs an echten Wänden öfter abprallt als an
Zufallsniveaus und nach dem Durchbruch von Stop-Clustern beschleunigt (Oslers zwei Vorhersagen), ist offen.

### 6.5 Vorschlag in drei Stufen (U143)

1. **Chartbild je Coin (Anzeige, kein Signal).** Trendlage (Schluss gegen 200-Tage-Linie, Steigung der 50-Tage-Linie), aktuelles
   Bein im Directional Change (Richtung, bisherige Größe gegen den Median aus U141 Teil A), nächste Niveaus aus Swing-Hochs und
   -Tiefs, Wänden, Take-Profits, Stop- und Liquidationsclustern, runde Zahlen, RSI 14, erwartete Schwankung (HAR, 1 Tag und
   1 Woche) als Band; daneben Funding-Druck, OI-Perzentil, Top-Trader-Perzentil, Fear & Greed. Eine Lesart in Worten, ohne Punkte.
2. **Niveau-Test (vorab festgelegt, nur Bericht).** Ereignis: Der Kurs kommt einem Niveau bis auf x·σ nahe. Ergebnis binnen
   h Stunden: Abprallen (Umkehr ≥ y·σ vor einem Durchbruch ≥ y·σ) oder Durchbruch, danach Beschleunigung. Kontrolle: Zufallsniveaus
   im gleichen Abstand auf derselben Seite (gepaart) und gespiegelte Niveaus; je Niveau-Art, über die Coins gepoolt, Holm, beide
   Hälften; Fallzahl zuerst zählen.
3. **Chart-Trader als Labor-Familie.** Höchstens 3–4 vorab festgelegte Regeln (etwa: Rücksetzer im Trend an einer echten Wand,
   Stop unter der Wand; Durchbruch eines Stop-Clusters in Trendrichtung; S3 mit einem einzigen Datenfilter „nicht gegen die
   überfüllte Seite“). Die Daten nur für Größe, Stop und „heute nicht“. Zufallskontrolle mit gleichen Ausstiegen, neue Kennungen,
   Historie, wo die Daten reichen (Kerzen, Funding und Archiv-Verhältnisse ab 2020; Orderniveaus nur vorwärts). Echtgeld wie
   bisher nur nach Beleg und mindestens 6 Monaten Labor, nie automatisch.

### 6.6 Nicht empfohlen

- Chartbilder von einer KI „lesen“ lassen: nicht reproduzierbar, nicht prüfbar.
- Elliott-Wellen, Fibonacci-Zonen oder frei gezogene Trendlinien ohne Mechanismus: zu viele Freiheitsgrade.
- Viele Indikatoren gleichzeitig als Bestätigung: jeder ist ein weiterer Test.
- Einzelne Binance-Ranglisten-Trader über inoffizielle Endpunkte kopieren (4.3).

## 7. Vorkonzept U142 „Positionierung und Hebel“ (festgeschrieben in `KONZEPT_Hebel.md`, gebaut in 23.63)

- **Form:** eigene Studie wie U141 (nur lesend, eigene Datei), berührt Fusion, v3, Kaskaden und v1 nicht.
- **Daten:** Archiv „metrics“ (OI und vier Verhältnisse, 5 min, ab 2020) für BTC und ETH, weitere Perpetuals nach fester Regel;
  Binance-Spot-Tageskerzen aller BTC- und ETH-Paare und Perp-Tageskerzen; Funding und Kurse aus `swing.db`. Kopie von
  `ext_liquidations` und `bnc_book` vor Ablauf der Vorhaltefrist.
- **Hauptprüfungen (Holm über 4, Rest beschreibend):**
  - H1 „Konten ≥ 3“ (Hinweis im Dashboard) kündigt einen Rücksetzer an (Ereignis wie U141 Teil C, h = 3 und 7 Tage).
  - H2 Top-Trader-Regel der Konfluenz (≥ 1,5 Kauf, ≤ 0,67 Verkauf): Richtung der Rendite über 3 Tage, zweiseitig (folgen oder
    dagegen).
  - H3 Perp-Anteil ≥ 95 % (Regel des Nutzers, wie formuliert) kündigt ein Deleveraging-Ereignis an (5.4).
  - H4 Perp-Anteil im obersten Zehntel der eigenen 90 Tage kündigt ein Deleveraging-Ereignis an.
- **Statistik:** relatives Risiko gegen „sonst“, Nullmodell aus Zufallswegen mit denselben externen Signalen (wie U141 Teil C) und
  Zeitverschiebungs-Placebo der Signalreihe; Kalender-Blockbootstrap für Intervalle; beide Hälften; Nullreplikationen und
  Positivkontrollen auf synthetischen Märkten vor dem ersten echten Lauf; Mutationen.
- **Folgen vorab:** Belegtes wird Kandidat für die Konfluenz (eigene Entscheidung des Nutzers); widerlegte Konfluenz-Regeln werden zur
  Entfernung vorgeschlagen; Nicht-Belegtes bleibt Anzeige.

## 8. Reihenfolge

1. 09.10. 12:00 U141 (Teil C prüft OI-Überhitzung, Funding-Druck, RSI ≥ 80, Gier ≥ 80) → Auswertung.
2. 11.10. U99 Labor-Auswertung und Aufräum-Entscheidung.
3. U142 bauen, wenn der Nutzer zustimmt (vor dem 25.10. möglich).
4. U143 Stufe 1 und 2 nach U142; Stufe 3 erst nach dem Niveau-Test.

## Quellen

- Binance, Top Trader Long/Short Ratio (Positions): https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Top-Trader-Long-Short-Ratio
- Binance, Top Trader Long/Short Ratio (Accounts): https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Top-Long-Short-Account-Ratio
- Binance Public Data (Archiv-README): https://github.com/binance/binance-public-data
- Binance Copy Trading API: https://developers.binance.com/docs/copy_trading/future-copy-trading
- Drittprojekt zur Futures-Rangliste (Beispiel): https://github.com/rtunazzz/bfldb
- alternative.me, Crypto Fear & Greed Index: https://alternative.me/crypto/fear-and-greed-index/
- Kaiko, Binance volume plummets after end of zero-fee trading: https://research.kaiko.com/insights/binance-volume-plummets-after-end-of-zero-fee-trading
- Bloomberg, 28.03.2023, Binance market share drops after zero-fee campaign ended: https://www.bloomberg.com/news/articles/2023-03-28/binance-bnb-market-share-drops-after-zero-fee-campaign-ended
- Schmeling, Schrimpf & Todorov 2023, BIS Working Paper 1087: https://www.bis.org/publ/work1087.pdf
- Jia, Moallemi, Wang & Zeng 2026, AFT 2026: https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.AFT.2026.36
- FTI Consulting, Crypto crash October 2025: https://www.fticonsulting.com/insights/articles/crypto-crash-october-2025-leverage-met-liquidity
- Osler 2000, FRBNY Economic Policy Review 6(2): https://www.newyorkfed.org/medialibrary/media/research/epr/00v06n2/0007osle.html
- Osler 2001, FRBNY Staff Report 125: https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr125.html
- Hudson & Urquhart 2021, Annals of Operations Research 297: https://hull-repository.worktribe.com/OutputFile/2639834
- Anghel 2021, Finance Research Letters 39: https://ideas.repec.org/a/eee/finlet/v39y2021ics1544612320304414.html
- Deprez & Frömmel 2024, International Review of Economics & Finance 93: https://ideas.repec.org/a/eee/reveco/v93y2024ipbp858-874.html
- Lo, Mamaysky & Wang 2000, Journal of Finance 55 (NBER WP 7613): https://www.nber.org/system/files/working_papers/w7613/w7613.pdf
- Lo 2002, The Statistics of Sharpe Ratios, Financial Analysts Journal 58(4) (ohne Link)
- Eigene Quellen: Berichtsbündel 08.10. 22:44 (Swing-Vorprüfung, Makro-Stand, Tabellenstände), UEBERGABE 3γγ, 3ζζ, 3λλ,
  `RECHERCHE_Regime_07-10-2026.md`, `RECHERCHE_Makro_Chart_05-10-2026.md`, Code `hl_binance.py`, `hl_ext.py`, `hl_makro.py`,
  `hl_recorder.py`, `hl_viz.py`.
