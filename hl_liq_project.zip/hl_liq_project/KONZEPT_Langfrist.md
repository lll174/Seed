# KONZEPT Langfrist (U277–U280) — Fächer über 24 Monate für BTC: zwei Sichten, Vorprüfung mit vorab festen Regeln

Stand 20.11.2026, 01:50 (gemessen; Fable 5.2). **Vorab festgelegt, bevor eine einzige Zahl der Vorprüfung auf echten Daten gerechnet
wurde.** Anlass: Wunsch des Nutzers vom 19.11.2026, 23:44 (Prognosechart über 24 Monate) und seine vier Entscheidungen vom 20.11.
nachts zur `BEWERTUNG_Prognosechart_24_Monate_19-11-2026.md`. **Status: Konzept. Gebaut ist nur ein Prototyp im Arbeitsordner, der
auf erzeugten Reihen lief (Abschnitt 8); im Paket ist nichts.** Auf dem Pi läuft 2026-09-23.112.

**Nachtrag 20.11.2026, 09:30 (Paket 23.113):** Der Erstlauf der Optionen (Abschnitt 9.1) ist gebaut: `hl_optionen.py`, Debug 154.
Wie er zählt, steht in Abschnitt 15 (Z1 bis Z6) — festgelegt vor dem ersten Abruf. Die Vorprüfung (Debug 153) kommt frühestens mit 23.115 (Abschnitt 13, Nachtrag);
die Nummer 153 ist im Dashboard bis dahin reserviert. An den Regeln der Abschnitte 3 bis 8 ist nichts geändert.

Offenlegung — was ich beim Festlegen kannte:

- Debug 52 vom 18.11.: die Fortschreibung von U126 über 365 Tage. Paar „Kurs gegen Power-Law-Fair-Value“, Zeitraum „alles“:
  119.750 USD, Band 60.545–165.393, Halbwertszeit 317 Tage, „Band traf im Rückblick 83 %“ (4 J: 86 %, 8 J: 75 %). Ebenso gesehen:
  Realized Price „alles“ 81.035 (34.502–191.825, 97 %) und 200-Wochen-MA „alles“ 111.474 (40.711–161.931, 84 %). Die Werte für 90
  und 180 Tage rechnet U126 mit; der Bericht zeigt sie nicht.
- Die Literatur aus der BEWERTUNG: Fehler außerhalb der Stichprobe 2014–2024, auf im Kern derselben Kurshistorie.
- Meinen Überschlag (BEWERTUNG, Abschnitt 3): gerechnet aus Berichtszahlen und Literaturwerten, ohne Kursdaten.
- **Nicht gesehen:** irgendeine Rückrechnung für 548 oder 730 Tage auf den Daten des Pi, irgendeinen CRPS-Wert auf echten Daten,
  irgendein Ergebnis der Sichten „Zyklus“ und „Bewertung“ über diese Horizonte. Im Arbeitsordner liegen keine Kursdaten; die
  echten Zahlen entstehen erst auf dem Pi.

---

## 0. Kurzfassung

- **Was entsteht:** ein Fächer für BTC über 24 Monate (Bänder 50 % und 80 %) aus zwei Sichten je zur Hälfte — „ohne Richtung“
  (der Kurs bleibt, Breite aus der Schwankung) und „Trend“ (Power Law mit Rückkehr zum Median, die Rechnung aus Debug 52). Daneben,
  nicht eingerechnet: Optionen, Prognosemärkte, Halving, Wirtschaftstermine.
- **Zuerst die Vorprüfung** (Debug 153): dieselben Regeln rückwirkend ab 2014, alle 30 Tage, für 3, 6, 12, 18 und 24 Monate — an
  jedem Stichtag nur mit Daten, die damals bekannt waren.
- **Drei Regeln stehen vorher fest:**
  1. *Ablösung.* Zyklus (4-Jahres-Theorie), Bewertung oder wandernde Gewichte kommen nur in den Fächer, wenn sie bei 12 Monaten
     nachweisbar besser waren, bei 24 Monaten nicht schlechter und in den letzten vier Jahren nicht schlechter (Abschnitt 7.1).
  2. *Alarm.* Hält das 80-%-Band deutlich seltener als 80 %, wird nicht gebaut, ohne zu fragen (7.2).
  3. *Nichts wird nach dem Blick auf die Zahlen angepasst* (7.6).
- **Auf erzeugten Reihen ausprobiert** (1.000 Welten, keine echten Daten; Abschnitt 8): Ohne Zusammenhang lösen Zyklus oder
  Bewertung den Fächer in 0 bis 1 % der Welten fälschlich ab, ein Fehlalarm kommt in 0 bis 3 %. Ein eingebauter Zyklus wird ab
  rund 2 σ in vier von fünf Welten erkannt; ein schrumpfender Zyklus, grob wie in der Geschichte, nur in einer von fünf.
- **Was die Vorprüfung nicht kann:** belegen, dass das Band bei 24 Monaten stimmt (6 Fenster ohne Überlappung). Sie kann zeigen,
  dass es grob falsch ist, sie prüft die Rechnung, und sie liefert die Breiten aus den Daten des Pi statt aus der Literatur.
- **Reihenfolge:** Paket 23.113 (offene Fehler; dazu Erstlauf Optionen, Debug 154) → Vorprüfung (Debug 153; frühestens 23.115) → Chart →
  Markt-Schicht.

## 1. Entscheidungen des Nutzers (20.11.2026, Auswahl)

| Frage | Entschieden | Folge |
|---|---|---|
| Form | Fächer mit zwei Sichten | Bänder 50 % und 80 %; beide Sichten bleiben sichtbar; keine einzelne Prognoselinie |
| Coins | nur BTC | Power Law und Halving gibt es nur dort |
| Optionen | Deribit und IBIT | neue Quelle; zuerst ein Erstlauf (Abschnitt 9) |
| Start | erst Vorprüfung | Abschnitte 3 bis 8; der Chart kommt danach |

## 2. Was in den Fächer fließt und was daneben steht

| Baustein | Platz | Grund |
|---|---|---|
| Kurs seit 2010: Schwankung | **im Fächer** (Sicht A) | trägt über Jahre |
| Power Law und Abweichung davon | **im Fächer** (Sicht B) | der am besten belegte Anker; Fehler bekannt |
| Halving-Zyklus (4-Jahres-Theorie) | Kandidat (Sicht C); sonst dünne Vergleichslinien | drei Zyklen; in den Fächer nur über 7.1 |
| Bewertung: Realized Price, 200-Wochen-MA | Kandidat (Sicht D); sonst Zonenstreifen | zweite Meinung zum Trend; in den Fächer nur über 7.1 |
| Optionen (Deribit, IBIT) | eigene Schicht, Punkte je Verfalltag | risikoneutral; keine Historie zum Prüfen |
| Prognosemärkte BTC | Punkte bis Ende 2027 | reichen nicht weiter; lange Fristen verzerrt |
| Halving-Termin, FOMC, Preis- und Arbeitsmarkttermine, US-Wahl | Zeitachse | Termine bewegen Tage, nicht den Pfad; das Halving ist ein Datum, keine Wahrscheinlichkeit |
| Makro (FRED), Fed-Pfad aus Kalshi | Kontextstreifen | im Projekt nichts belegt (0 von 45) |
| Aktienmarkt, Hyperliquid-Daten | nicht im Chart (nur der Startkurs) | reichen Stunden bis Wochen |

## 3. Daten, Raster, Horizonte

- **Kurs:** `cm:btc:PriceUSD` (Coin Metrics, Tageswerte) ab 18.07.2010 aus `makro.db`, so wie ihn `hl_makro.ableiten` liefert
  (`D["P"]`). Dieselbe Reihe wie im Makro-Chart.
- **Abgeleitet, je Tag nur aus Daten bis zu diesem Tag:** Fair Value des Power Law mit Monatsparametern (`powerlaw_monatlich`, ab
  Januar 2011), Realized Price, 200-Wochen-MA (ab Mai 2014), Halving-Daten (`HALVINGS`).
- **Ursprünge:** das Raster von U126 (`hl_makro_signal.pruefung`, Zeitraum „alles“): erster Ursprung 365 Tage nach dem ersten Fair
  Value, dann alle 30 Tage. **Gewertet** werden Ursprünge ab 01.01.2014; frühere füllen nur das Fehlergedächtnis.
- **Horizonte:** 90, 180, 365, 548 und 730 Tage (3, 6, 12, 18, 24 Monate). Die ersten drei sind die von U126.
- **Ziel:** ln(Kurs am Tag Ursprung + h). Fehlt der Kurs am Zieltag, entfällt der Fall; der Bericht zählt solche Fälle.
- **Zählung nach heutigem Stand** (nur das Raster gerechnet, ohne Kursdaten; `fenster.py` im Arbeitsordner):

  | Horizont in Tagen | 90 | 180 | 365 | 548 | 730 |
  |---|---:|---:|---:|---:|---:|
  | gewertete Ursprünge | 154 | 151 | 145 | 138 | 132 |
  | Fenster ohne Überlappung | 52 | 26 | 12 | 8 | 6 |

  „Ohne Überlappung“ heißt: jeder ⌈h ÷ 30⌉-te Ursprung ab dem ersten gewerteten (voraussichtlich 20.01.2014). Der Lauf nennt die
  echten Zahlen.

## 4. Die vier Sichten (feste Regeln)

An jedem Ursprung o zählt nur, was bis o bekannt war. P = Kurs, FV = Fair Value des Power Law. Jede Sicht hat einen **Rohwert**
(die Vorhersage der Regel), eine **Verteilung** und eine **Mitte** (den Median der Verteilung).

### 4.1 Sicht A „ohne Richtung“

- **Rohwert und Mitte:** der Kurs am Ursprung.
- **Breite:** s(h) = v · √(h ÷ 365). v = Standardabweichung der täglichen ln-Renditen der letzten 1.461 Tage bis zum Ursprung
  (mindestens 365 Tage), auf ein Jahr hochgerechnet (× √365).
- **Verteilung:** normal in ln um die Mitte.
- **Keine Berichtigung aus früheren Fehlern.** Die Fehler von „Kurs bleibt“ enthalten den Anstieg der Vergangenheit; damit käme
  eine Richtung in die Sicht ohne Richtung.

### 4.2 Sicht B „Trend“ — U126 unverändert, zwei Horizonte mehr

- y = ln(P ÷ FV). Median μ und AR(1) (φ, σ) über alle Tage bis zum Ursprung; Erwartung von y nach h Tagen:
  m(h) = μ + φ^h · (y − μ).
- **Rohwert:** ln(FV am Zieltag) + m(h); FV mit den Monatsparametern des Ursprungs.
- **Fehler** eines früheren Ursprungs: ln(P am Ziel) − Rohwert.
- **Verteilung:** Rohwert + die eigenen bekannten Fehler der letzten vier Jahre (Regel `_fehler_bekannt`: Ursprünge der letzten
  vier Jahre, deren Ziel am Ursprung schon bekannt war; mindestens 20). Darunter gilt das Modellband (normal, aus dem AR(1)).
- **Mitte** = Median der Verteilung. Debug 52 zeigt als Erwartung den Rohwert; die Ränder 10 % und 90 % sind dieselben.
- **B3 (neu, nur für den Fächer): Die Spanne zwischen 10-%- und 90-%-Rand (in ln) fällt nicht mit dem Horizont.** Ist sie bei
  einem Horizont kleiner als beim vorigen, werden die Abstände aller Quantile zur Mitte mit einem gemeinsamen Faktor gestreckt,
  bis sie gleich ist. Grund: Bei 548 und 730 Tagen stammen die bekannten Fehler aus zwei bis drei unabhängigen Zeiträumen; eine
  kleinere Spanne als bei 365 Tagen wäre Zufall.

### 4.3 Sicht C „Zyklus“ — die 4-Jahres-Theorie als Rechenregel

- τ = Tage seit dem letzten Halving am Ursprung. Für jedes frühere Halving H das Kursvielfache von damals, bereinigt um den Trend:
  q(H) = [P(H+τ+h) ÷ P(H+τ)] ÷ [FV(H+τ+h) ÷ FV(H+τ)], FV mit den Parametern des Ursprungs.
- **Rohwert:** P(o) · [FV(o+h) ÷ FV(o)] · geometrisches Mittel der q(H).
  In Worten: Der Kurs entwickelt sich gegenüber dem Trend so wie im Mittel der früheren Zyklen ab demselben Tag nach dem Halving.
  (Abweichung vom Trend statt Kursvielfache, weil die Vielfachen mit jedem Zyklus schrumpfen.)
- Es zählen die vier Halvings (28.11.2012, 09.07.2016, 11.05.2020, 20.04.2024). Die Sicht gibt es darum erst für Ursprünge ab
  09.07.2016 — mit einem, dann zwei, heute drei früheren Zyklen.
- **Verteilung:** Rohwert + eigene bekannte Fehler der letzten vier Jahre (mindestens 20). Darunter: Rohwert + Streuung von B
  (dessen Fehler abzüglich ihres Medians, oder dessen Modellband). B3 gilt.

### 4.4 Sicht D „Bewertung“

- Paare „Kurs gegen Realized Price“ und „Kurs gegen 200-Wochen-MA“ aus U126, Zeitraum „alles“: Rückkehr der Abweichung zum Median
  wie in B; die Referenzlinie wird mit ihrem Trend der letzten 365 Tage fortgeschrieben (wie in Debug 52).
- **Rohwert:** Mittel der ln-Prognosen der vorhandenen Paare (eines oder zwei).
- **Verteilung:** wie bei C.

## 5. Hauptfächer und Kandidaten

| Kennung | Fächer | Gewichte |
|---|---|---|
| **H** | **Hauptfächer** | ½ A + ½ B |
| G | wandernde Gewichte | Gewicht von B = MSE(A) ÷ [MSE(A) + MSE(B)], begrenzt auf ¼ bis ¾; A bekommt den Rest |
| Z | mit Zyklus | ½ A + ¼ B + ¼ C |
| W | mit Bewertung | ½ A + ¼ B + ¼ D |

- **MSE in G:** mittlerer quadrierter ln-Fehler der Mitte einer Sicht über ihre bekannten Fehler der letzten vier Jahre (je
  mindestens 20); sonst bleibt es bei ½.
- **Vergleichslinien** (berichtet; sie können den Fächer nicht ablösen): A, B, C und D je allein.
- **A bleibt in Z und W bei der Hälfte.** Sonst gewönne ein Kandidat schon dadurch, dass er mehr Gewicht auf Trend-Sichten legt —
  und der Trend lag in der Vergangenheit vorn. So misst der Vergleich nur, ob Zyklus oder Bewertung die Trend-Hälfte verbessern.
- **Warum je zur Hälfte:** Der Vorsprung des Power Law vor „Kurs bleibt“ ist in der Literatur nicht gesichert (p 0,196 bei 12 und
  0,079 bei 24 Monaten), die Trendform ist nicht bestimmbar. Gleiche Gewichte sind die Setzung bei Unwissen; G prüft die Alternative.
- **Mischen:** Jede Sicht wird durch 199 Quantile dargestellt (0,5 % bis 99,5 %); die Mischung ist ihre gewichtete Vereinigung.
  Quantile der Mischung: `hl_ausblick.gew_quantile`.
- Gibt es C oder D an einem Ursprung nicht, ist Z bzw. W dort gleich H.

## 6. Maße (je Horizont und Fächer)

- **CRPS** in ln, genau für die gewichtete Vereinigung (kleiner ist besser): Mittel über die gewerteten Ursprünge, dazu im
  Verhältnis zu H. Mit 199 Quantilen weicht der Wert vom genauen CRPS einer Normalverteilung um höchstens 0,7 % ab (gemessen an
  drei Punkten) — für alle Fächer gleich.
- **Deckung** des 50-%- und des 80-%-Bands; dazu der Anteil über dem 90-%-Rand und unter dem 10-%-Rand.
- **Fehler der Mitte:** RMSE in log10 (vergleichbar mit der Literatur) und als Faktor („typisch um den Faktor x daneben“).
- **Ohne Überlappung:** dieselben Zahlen als „x von y Fenstern“.
- **Standardfehler der Deckung:** √(p · (1 − p) ÷ n), n = Zahl der Fenster ohne Überlappung.

Der Blockbootstrap des Ausblicks (U146) trägt hier nicht: Bei 730 Tagen passen keine drei Blöcke in die Historie.

## 7. Regeln vorab

### 7.1 Ablösung des Hauptfächers

H bleibt Hauptfächer. Ein Kandidat (G, Z, W) löst ihn nur ab, wenn alle drei Bedingungen gelten:

1. **Nachweis bei 365 Tagen.** d = CRPS von H − CRPS des Kandidaten, je Fenster ohne Überlappung; Fenster, in denen der Kandidat
   mit H übereinstimmt, zählen nicht; mindestens 6 Fenster. Einseitiger **Vorzeichenwechsel-Test**: p = Anteil aller 2^n
   Vorzeichenmuster, deren Mittel mindestens so groß ist wie das beobachtete. Verlangt ist p ≤ 0,05 ÷ 3 = 0,0167.
2. **730 Tage, alle gewerteten Ursprünge:** Sein mittleres CRPS ist nicht größer als das von H.
3. **Letzte vier Jahre, 365 Tage:** Über die Ursprünge der letzten vier Jahre ist sein mittleres CRPS nicht größer als das von H.
   Grund: Die Ausschläge der Zyklen schrumpfen; was 2016 bis 2021 trug, muss heute nicht mehr tragen.

Bestehen mehrere, gilt der mit dem kleinsten mittleren CRPS bei 365 Tagen. Primär ist 365 Tage, weil dort 9 bis 12 Fenster
liegen (kleinstes mögliches p bei 9 Fenstern: 1 ÷ 512); bei 730 Tagen sind es 5 bis 6 — zu wenige für einen Test.

**Die Hürde ist hoch.** Was nicht besteht, erscheint im Chart nur als Vergleichslinie (frühere Zyklen) oder Streifen (Bewertung),
nicht im Fächer. Nicht bestanden heißt nicht „kein Zusammenhang“ (Nachweisgrenze: Abschnitt 8).

### 7.2 Alarm „Band zu schmal“

Geprüft wird der Fächer, der nach 7.1 Hauptfächer ist. Liegt die Deckung seines 80-%-Bands bei einem Horizont unter
0,80 − 2 · √(0,16 ÷ n) (n = Fenster ohne Überlappung), baue ich den Chart nicht ohne Rückfrage. Nach heutigem Stand sind das
68,9 / 64,3 / 56,9 / 51,7 / 47,3 % für 90 / 180 / 365 / 548 / 730 Tage. Der Nutzer bekommt den Befund und zwei Wege: das Band auf
die gemessene Breite strecken und so beschriften — oder den Horizont nicht zeigen.

### 7.3 Hinweis „Band zu breit“

Deckung über 0,80 + 2 · √(0,16 ÷ n): nur ein Hinweis am Chart. Ab 365 Tagen liegt diese Grenze über 100 %; dort ist „zu breit“
nicht feststellbar.

### 7.4 Aussagekraft

Liegt beim heutigen Hauptfächer der 90-%-Rand bei 730 Tagen über dem 20-Fachen des 10-%-Rands, frage ich nach, ob der Chart so
gebaut werden soll. (Überschlag: Faktor 11.)

### 7.5 Ein Urteil, ein Lauf

Das Urteil zu 7.1 bis 7.4 fällt der erste Lauf auf dem Pi. Spätere Läufe zeigen den Stand, ändern den Hauptfächer aber nicht.

### 7.6 Nichts wird nachträglich angepasst

Fest sind: Zeitraum „alles“, Fehlerfenster vier Jahre, Schwankungsfenster 1.461 Tage, Raster, Start 2014, Horizonte, Gewichte,
Test und Schwellen. Jede spätere Änderung ist eine neue Regelversion mit Datum und Grund in Abschnitt 15; der Chart zeigt die
Regelversion (Start: 1).

### 7.7 Nebenrechnung ohne Folgen

Sicht B mit den Zeiträumen 4 J und 8 J statt „alles“ — zeigt, wie empfindlich die Mitte ist.

## 8. Kalibrierung auf erzeugten Reihen (gemessen 20.11.2026, Arbeitsordner)

Prototyp `lf_proto.py` mit den unveränderten Bausteinen aus Paket 23.112 (`powerlaw_monatlich`, `ar1`, `y_prognose`, `Referenz`).
**Nur erzeugte Reihen, feste Startwerte, keine echten Kurse.** Jede Welt: 5.970 Tage ab 18.07.2010, 179 Ursprünge; eine Welt
rechnet in 0,6 s (Arbeitsrechner, nicht der Pi). σ = Streuung der Abweichung vom Trend in Welt 1 (0,301 in log10).

**Welten ohne Zusammenhang** — wie oft irren die Regeln?

| Welt | Welten | abgelöst durch G | durch Z | durch W | Alarm 7.2 (irgendein Horizont) | Deckung 80 % von H bei 90 / 180 / 365 / 548 / 730 Tagen |
|---|---:|---:|---:|---:|---:|---|
| 1: Power Law + AR(1)-Abweichung (Halbwertszeit 317 Tage) | 200 | 1,0 % | 0,5 % | 0,0 % | 0,0 % | 80 / 80 / 80 / 79 / 79 % |
| 1 mit fallender Schwankung (1,6- auf 0,6-fach) | 100 | 0,0 % | 1,0 % | 0,0 % | 0,0 % | 85 / 85 / 85 / 84 / 84 % |
| 1 mit dicken Rändern und Schwankungsballung (Wölbung rund 15) | 100 | 2,0 % | 0,0 % | 0,0 % | 2,0 % | 81 / 80 / 79 / 77 / 76 % |
| 3: reiner Zufallsweg ohne Trend | 100 | 2,0 % | 0,0 % | 0,0 % | 3,0 % | 78 / 77 / 76 / 74 / 73 % |

- Zyklus und Bewertung lösen ohne Zusammenhang in 0 bis 1 % der Welten ab (Soll: zusammen höchstens 5 %). **Die Schwelle 0,0167
  bleibt.**
- G hat keine „falsche“ Ablösung im selben Sinn: Im Zufallsweg ist mehr Gewicht auf A richtig.
- Alarm 7.2 (auf dem Fächer, der nach 7.1 Hauptfächer ist): 0 bis 3 %.
- In Welt 1 — dort ist B das wahre Modell — deckt B allein nur 73 / 69 / 60 / 56 / 54 %, A allein 79 / 79 / 76 / 73 / 70 %. Das
  Fehlergedächtnis von vier Jahren enthält bei langen Horizonten zu wenige unabhängige Fehler. Die Mischung H gleicht das aus und
  hat dort auch das kleinste CRPS (A allein +2 bis +34 %, B allein +6 bis +13 %, G +0,2 bis +1,3 %, Z +1,3 bis +1,6 %,
  W +0,5 bis +4,5 %).
- B3 hebt in Welt 1 die Deckung von B bei 730 Tagen von 49 auf 53 %, die von H von 76 auf 78 % (60 Welten).

**Welten mit eingebautem Zyklus** (Welt 1 plus Vier-Jahres-Sinus in der Abweichung, Hoch rund 525 Tage nach dem Halving; je
100 Welten) — wie stark muss er sein?

| Stärke des Zyklus | Z löst ab | Alarm 7.2 auf H | Alarm auf dem Hauptfächer nach 7.1 |
|---|---:|---:|---:|
| 1,0 σ | 6 % | 0 % | 0 % |
| 1,5 σ | 46 % | 2 % | 1 % |
| 2,0 σ | 79 % | 11 % | 2 % |
| 3,0 σ | 97 % | 65 % | 1 % |
| schrumpfend: 2,8 / 2,0 / 1,2 / 0,5 σ je Zyklus | 18 % | 0 % | 0 % |

- **Nachweisgrenze: rund 2 σ.** Das ist ein Sinus mit Ausschlag ±1,39 in ln (Faktor 4 über und unter dem Trend); er erklärt rund
  zwei Drittel der Abweichung vom Trend.
- Die schrumpfende Welt ist der Geschichte grob nachempfunden (Überschlag aus den Hochs und Tiefs der BEWERTUNG: 2013 rund 2,4 σ,
  2017 rund 1,9 σ, 2021 rund 1,2 σ, 2025 rund 0,5 σ). Dort besteht Z in 18 % der Welten — obwohl Z in den letzten vier Jahren in
  80 % dieser Welten besser gewesen wäre als H (CRPS im Median −9 % bei 365 Tagen). **Besteht Z auf echten Daten nicht, belegt das
  also nicht, dass der Zyklus nichts beiträgt.**

**Wahl des Tests** (je 60 Welten, 365 Tage, vor dem Ablegen dieses Konzepts): Der zuerst vorgesehene Vorzeichentest („besser in
fast jedem Fenster“) erkannte einen Zyklus von 2 σ nur in 28 % der Welten, der Vorzeichenwechsel-Test in 85 %, bei ähnlicher
Irrtumsquote ohne Zusammenhang (Z in Welt 1: je 0,5 % von 200 Welten). Eine Fassung mit Blöcken aus allen Ursprüngen erkannte
noch mehr (97 %), aber ihre Blöcke überlappen sich an den Rändern; ich habe die saubere Fassung gewählt.

**Proben am Prototyp:** kein Blick in die Zukunft (Vorhersage aus der vollen Reihe = Vorhersage aus der am Stichtag abgeschnittenen
Reihe, Abweichung 0,0; zwei Mutationen fallen auf) · 90, 180 und 365 Tage stimmen mit `pruefung` und `prognose` von U126 überein
(Zahl der Fälle und Ränder auf 12 Stellen) · CRPS gleich `hl_ausblick.crps_ens` · C gleich B ergibt Z gleich H.

Dateien im Arbeitsordner `/home/claude/audit/work/prog24/`: `lf_proto.py`, `lf_proben.py`, `lf_kalib2.py`, `lf_tests.py`,
`lf_b3.py`; Protokolle `k2_*.log`, `tests_*.log`, `kalib_w1.log`.

## 9. Optionen: Erstlauf (U278, Debug 154) und Regel danach

### 9.1 Was der Erstlauf misst

Je ein Abruf; gespeichert wird nur der Bericht.

- **Deribit** (öffentliche Schnittstelle, schon Quelle für DVOL): Liste der BTC-Optionen und ihre Kurszusammenfassung. Bericht:
  Zahl der Verfalltage, längster Verfall, Strikes je Verfall, Anteil mit Geld- und Briefkurs, Spanne am Geld für die drei
  längsten Verfalltage, Größe und Dauer der Antwort.
- **IBIT** (Cboe, verzögerte Kurse; dieselben zwei Hosts wie für VVIX und VIX9D): erreichbar ja oder nein, mit Statuscode; Größe
  und Dauer; Zahl der Kontrakte; Verfalltage und der längste; für Verfalltage ab 12 Monaten: Strikes mit Geld- und Briefkurs,
  Spanne am Geld, offene Kontrakte; Zeitstempel der Kurse; IBIT-Kurs.
- Der Erstlauf stürzt bei unerwartetem Format nicht ab; er meldet dann die Struktur der Antwort.

Bekannt vorab: Deribit führt bei BTC-Optionen (invers) bis zu vier Tages-, drei Wochen-, drei Monats- und vier Quartalsverfälle
([Deribit](https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy)). Der längste wäre heute
der 24.09.2027, gut zehn Monate entfernt (eigene Rechnung: letzter Freitag im vierten kommenden Quartalsmonat). Für das zweite
Jahr bleibt also nur IBIT. Cboe speist seine Kursseiten aus frei abrufbaren JSON-Daten mit verzögerten Kursen
([apis.io](https://apis.io/providers/cboe/)); ob der Pi die IBIT-Kette dort vollständig bekommt, ist ungeprüft.

### 9.2 Regel danach (vorab)

- Ein Verfalltag ist **brauchbar für Quantile**, wenn auf jeder Seite des Terminkurses mindestens fünf Strikes Geld- und Briefkurs
  haben und die Spanne am Geld höchstens 15 % des Mittelkurses beträgt. Sonst zählt nur die implizite Schwankung am Geld; fehlt
  auch sie, entfällt der Verfalltag.
- **IBIT kommt nur in den Chart, wenn mindestens ein brauchbarer Verfalltag 18 Monate oder länger läuft.** Sonst bleibt es bei
  Deribit, und der Nutzer bekommt den Befund.
- Rechenweg der Quantile und Abrufzeit lege ich nach dem Erstlauf in einem Nachtrag fest, bevor Stufe 2 gebaut wird. Fest steht
  schon: ein Abruf am Tag kurz vor US-Handelsschluss; gespeichert werden nur Kennzahlen je Verfalltag (Schwankung am Geld,
  Quantile, Terminkurs, Zahl der Strikes); IBIT wird über das Verhältnis Strike ÷ IBIT-Kurs auf BTC umgerechnet.
- **Lesart:** Optionspreise sind risikoneutral; ihre Mitte ist der Terminkurs. Die Schicht steht neben dem Fächer und geht nicht
  in die Mischung, solange es keine Bilanz gibt. Eine Rückrechnung ist nicht möglich: Auf dem Pi gibt es keine Options-Historie.

## 10. Chart und Vorwärtsbilanz (Stufe 1, Eckpunkte)

- **Ort:** Reiter „24 Monate“ im Makro-Chart; logarithmische Skala; von heute bis heute + 730 Tage.
- **Fächer:** Bänder 50 % und 80 % des Hauptfächers; Stützstellen bei 90, 180, 365, 548 und 730 Tagen, dazwischen gerade
  verbunden; bei 0 Tagen der Kurs.
- **Linien:** Mitte von A, Mitte von B, Fair Value. Dünn: die früheren Zyklen aus 4.3 (je Halving eine), ohne Wahrscheinlichkeit.
- **Die ersten vier Wochen:** das Band des Ausblicks (U146) als eigener, beschrifteter Anschluss.
- **Markt-Schicht (Stufe 2):** Punkte je Verfalltag aus Optionen; Schwellen der Prognosemärkte bis Ende 2027 mit Roh- und
  rekalibriertem Wert (`KONZEPT_Prognosemaerkte.md`, Regel 1.6).
- **Zeitachse:** Halving (Spanne der Schätzung 12. bis 21.04.2028), FOMC, Preis- und Arbeitsmarkttermine, US-Wahl 07.11.2028.
  **Kontextstreifen:** Zonenkarte, Fed-Pfad.
- **Beschriftung:** Kopfzeile „Szenarien, keine geprüfte Prognose“. Unter dem Chart die Rückblick-Zeile aus Debug 153 („80-%-Band
  hielt in x von y Fenstern“), Regelversion und Datenstand. Keine Kauf- oder Verkaufswörter.
- **Gleiche Rechnung:** Der Chart ruft dieselbe Funktion wie die Vorprüfung, mit heute als Ursprung.
- **Vorwärtsbilanz:** Am Ersten jedes Monats wird die Fassung unveränderlich gespeichert (Quantile je Horizont, Mitten,
  Regelversion, Datenstand). Zwischenbilanz nach 3, 6 und 12 Monaten, nur aus gespeicherten Fassungen.
- **Zurückgestellt:** die zweite Trendform mit Deckel (BEWERTUNG, Abschnitt 5). Eine weitere Linie ohne Rückrechnung widerspräche
  „erst Vorprüfung“; die Unsicherheit über die Trendform tragen schon Sicht A und die Fehlerbreite von B.

## 11. Proben und Mutationen (Selbsttest ohne Netz)

| Probe | prüft | Mutation, die sie fangen muss |
|---|---|---|
| P1 Kausalität | Vorhersage am Ursprung aus der vollen Reihe = Vorhersage aus der am Ursprung abgeschnittenen Reihe, für alle Sichten | Median über 30 Tage nach dem Ursprung; Fehlergedächtnis mit noch unbekannten Zielen |
| P2 Gleichheit mit U126 | 90, 180 und 365 Tage: Zahl der Fälle und Ränder wie `pruefung`; heutiges Band wie `prognose` | Raster 31 statt 30 Tage |
| P3 CRPS | gleiche Gewichte gegen `crps_ens`; ungleiche gegen die Doppelsumme; Normalverteilung gegen die geschlossene Formel (Toleranz 1 %) | Vorzeichen; falsches Gewicht |
| P4 Mischung | C gleich B ergibt Z gleich H (CRPS genau, Quantile auf 0,005 in ln); Gewicht 1 ergibt die Einzelsicht; Quantile steigen | A einfach statt doppelt gewichtet |
| P5 Vorzeichenwechsel-Test | neun gleiche Vorzeichen: 1 ÷ 512; ein kleiner Gegenwert: 2 ÷ 512; ein großer: kein Nachweis; Gleichstände zählen nicht | Gleichstand als Sieg; zweiseitig statt einseitig |
| P6 Regel B3 | gebaute Fehler mit schrumpfender Spanne werden gestreckt | Regel entfernt |
| P7 Deckung | bekannte Verteilung: 80 % innerhalb der Toleranz; Ränder 10 und 90, nicht 25 und 75 | falsches Quantil |
| P8 Welten (klein) | Abschnitt 8 mit je fünf Welten: Welt 1 löst nicht ab, Zyklus 3 σ löst ab | Gewichte von G vertauscht; Bedingung 3 entfernt |
| P9 Gleiche Rechnung | Chart-Funktion = Rückrechnung für denselben Tag | eigener Rechenweg im Chart |

P1 bis P3 liefen am Prototyp schon, P4 und P5 in Teilen (Abschnitt 8). Dazu wie üblich: Update-Probe, Eintrag im BERICHTSPLAN
(`nach_update`), Browserprobe für den Chart in Stufe 1.

## 12. Erwartung vorab (damit nichts überrascht)

- **A:** Das Band wird zu oft nach oben verlassen (der Anstieg der Vergangenheit); Deckung bei 730 Tagen unter 80 %.
- **B:** bei 365 Tagen nahe dem, was Debug 52 zeigt (83 %); bei 548 und 730 Tagen deutlich darunter — das war schon in der Welt
  so, in der B das wahre Modell ist (54 %), und ist kein Fehler der Rechnung. Die Mitte von B liegt heute vermutlich unter dem
  Überschlag — bei 12 Monaten eher um 100.000 als bei 118.000 USD —, weil die Fehler der letzten vier Jahre überwiegend nach unten
  zeigten (geometrische Mitte des Bands aus Debug 52: 100.069).
- **H:** Deckung im Soll oder darüber. Breiter als der Überschlag (Faktor 11) ist möglich.
- **CRPS:** A vorn bei 90 Tagen, B ab 365 Tagen — wie in der Literatur. Gesichert ist das nicht.
- **G** wandert zu B; ob es 7.1 besteht, ist offen. **W** besteht vermutlich nicht.
- **Z** ist offen. In der schrumpfenden Welt besteht Z in einem von fünf Fällen. Besteht Z, verschiebt sich der Fächer vermutlich
  nach oben: In früheren Zyklen stand der Kurs zwei Jahre nach diesem Zyklustag (944 Tage nach dem Halving) weit über dem Trend
  — aus dem Gedächtnis, nicht gerechnet.
- **Alarm 7.2:** nicht erwartet; wenn doch, dann bei 730 Tagen.

## 13. Stufen, Pakete, Nummern

| Stufe | Inhalt | Plan | Debug | Paket (geplant) |
|---|---|---|---|---|
| — | offene Fehler: U276, U275, U272 Teil 2, Wortlaut U246 | — | — | 23.113, nach der Messung vom 20.11. gegen 06:13 |
| Erstlauf | Optionen: Deribit und IBIT, je ein Abruf | U278 | 154 | 23.113 |
| 0 | Vorprüfung (Abschnitte 3 bis 8) | U277 | 153 | frühestens 23.115 |
| 1 | Chart „24 Monate“, Text-Lauf, Monatsfassungen, Vorwärtsbilanz | U279 | 156 ★ | danach |
| 2 | Markt-Schicht: Optionen täglich, Punkte der Prognosemärkte | U280 | in 156 | danach |

**Nachtrag 20.11.2026 (Paket 23.114):** 23.114 wurde das Paket zur Stabilität (Hänger des Dashboards vom 19.11., Auftrag des Nutzers vom 20.11.). Die Vorprüfung kommt frühestens mit 23.115. Debug 155 gehört jetzt der Probe der Selbstheilung; der Text-Lauf des Charts bekommt 156. An den Regeln der Abschnitte 3 bis 8 und an der Zählweise Z1 bis Z6 ändert das nichts.

Jedes Paket plant seine Debug-Läufe selbst (Regel seit 23.109): 23.113 den Lauf 154, das Paket der Vorprüfung die Läufe 153 und 52. Neues Modul:
`hl_langfrist.py` (reine Rechnung ohne Datenbank, wie `hl_makro_signal.py`), hervorgegangen aus dem Prototyp. Last auf dem Pi:
Tageswerte, rund 180 Ursprünge. Zum Vergleich: U126 rechnet alle Paare und Zeiträume in 4,4 s (Debug 52, 18.11.). Die Laufzeit
der Vorprüfung misst der Bericht.

## 14. Grenzen und nicht Geprüftes

**Grenzen** (zusätzlich zu Abschnitt 8 der BEWERTUNG):

- Die Vorprüfung ist keine unabhängige Prüfung: Sie rechnet auf der Historie, aus der Power Law und Zyklus-These stammen.
- Bei 730 Tagen gibt es 6 Fenster ohne Überlappung. Fünf Treffer von sechs sind mit einer wahren Deckung zwischen 42 und 99 %
  vereinbar (90-%-Bereich; eigene Rechnung).
- Die erzeugten Welten sind einfach: ein AR(1), ein Sinus, in einer Welt dicke Ränder. Echte Kurse können anders irren. Die
  Kalibrierung zeigt, dass die Regeln in diesen Welten halten — nicht, dass sie auf BTC halten.
- Sicht A wird im Rückblick mit der realisierten Schwankung gerechnet; Optionen haben keine Historie auf dem Pi.
- Sicht C stützt sich auf ein bis drei frühere Zyklen.
- Ein Strukturbruch (ETF-Zeit) kann die Historie vor 2024 entwerten.

**Nicht geprüft:**

- Ob der Pi die IBIT-Kette bei Cboe abrufen kann. Die Nutzungsbedingungen für verzögerte Kurse habe ich nicht im Wortlaut gelesen.
- Der längste Verfall bei Deribit heute (nach der Regel der Börse der vierte Quartalsverfall; ob Dezember 2027 schon gelistet
  ist, weiß ich nicht).
- Ob das Raster auf dem Pi am 20.01.2014 beginnt (hängt am ersten Tag mit Fair Value).
- Die Laufzeit der Vorprüfung auf dem Pi.
- Proben P6 bis P9 als eigene Proben (die Regeln selbst liefen in Abschnitt 8) und alle Mutationen außer den zwei zu P1 — sie
  kommen mit dem Bau.

## 15. Ergebnis und Nachträge

- **20.11.2026, vor dem Ablegen (nur erzeugte Reihen):** Der Test in 7.1 war zuerst ein Vorzeichentest; ersetzt durch den
  Vorzeichenwechsel-Test, weil der erste einen starken Zyklus kaum erkannte (Abschnitt 8). Bedingung 3 (letzte vier Jahre)
  ergänzt. Regelversion 1 ist die hier beschriebene Fassung.
- **20.11.2026, vor dem ersten Abruf (Paket 23.113, Erstlauf U278): Zählweise zu 9.1 und 9.2.** Die Regel in 9.2 nennt die
  Schwellen, aber nicht, wie gezählt wird. Festgelegt, bevor eine Antwort der beiden Quellen gesehen wurde; `hl_optionen.py`
  zählt so:
  - **Z1** Geld- und Briefkurs: beide vorhanden, größer 0, Brief nicht unter Geld.
  - **Z2** Terminkurs: Deribit = Feld `underlying_price` (Median je Verfalltag). IBIT = Put-Call-Parität am Strike mit dem
    kleinsten Abstand zwischen Call und Put (Mittelkurse): Terminkurs = Strike + Call − Put. Das ist eine Näherung (amerikanische
    Optionen, ohne Zins). Gibt es kein solches Paar, gilt der Kassakurs.
  - **Z3** Seiten: Unter dem Terminkurs zählen die Puts, darüber die Calls (aus dem Geld; aus ihnen kämen die Quantile). Ein
    Strike genau am Terminkurs zählt für keine Seite.
  - **Z4** Am Geld: der Strike nächst dem Terminkurs, an dem Call und Put gelistet sind (bei Gleichstand der niedrigere). Spanne
    am Geld = Spanne des Paars Call + Put: (Brief Call + Brief Put − Geld Call − Geld Put) ÷ Mitte des Paars. Fehlt ein Kurs, gibt
    es keine Spanne, und der Verfalltag ist nicht brauchbar.
  - **Z5** Tage bis zum Verfall: Deribit 08:00 UTC, IBIT 16:00 New York. 12 Monate = 365 Tage, 18 Monate = 548 Tage.
  - **Z6** Die Bedingung für IBIT wird nur in der US-Handelszeit gewertet: an Handelstagen 9:45 bis 16:15 New York (die Kurse
    sind 15 Minuten verzögert). Außerhalb heißt es „kein Urteil“. Es zählt der erste Lauf in der Handelszeit; spätere ändern das
    Urteil nicht. Frühe Handelsschlüsse kennt der Lauf nicht.

  Dazu: Cboe selbst dokumentiert das Format der Antwort nicht. Drei unabhängige Beschreibungen (Quellen, gelesen am 20.11.2026)
  nennen denselben Aufbau: eine Liste `data.options`, je Kontrakt `option` (OCC-Kennung), `bid`, `ask`, `iv`, `open_interest`,
  dazu `data.current_price`; eine nennt eine Weiterleitung (HTTP 307) vor der Antwort. Der Lauf verlässt sich nicht darauf: Er
  erkennt die Kontrakte an ihren OCC-Kennungen und meldet sonst den Aufbau der Antwort. Aus der Arbeitsumgebung war die Adresse
  nicht abrufbar. Angepasste Kontrakte (andere Wurzel als IBIT) werden gezählt, aber nicht gewertet. Der zweite Cboe-Host wird
  nur gefragt, wenn der erste nicht liefert; ob er diesen Pfad kennt, ist ungeprüft. Die Felder der Deribit-Antwort stehen in
  der Dokumentation der Börse (Quellen).
- *(Ergebnis des Erstlaufs der Optionen: folgt mit Debug 154. Ergebnis der Vorprüfung: folgt mit Debug 153.)*

## Quellen

- `BEWERTUNG_Prognosechart_24_Monate_19-11-2026.md` (Belegstand, Überschlag, alle Literaturquellen)
- [Baquero & Menezes, Bitcoin’s Power Law: Weak Structure, Strong Forecasts (arXiv 2605.21316)](https://arxiv.org/html/2605.21316v1)
- [Baquero, Deceleration without identification (arXiv 2611.13962)](https://arxiv.org/html/2611.13962v1)
- [Molnar, Bitcoin Runs on a Clock (arXiv 2607.26188)](https://arxiv.org/html/2607.26188)
- [Deribit, Contract Introduction Policy](https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy)
- [apis.io, Cboe Global Markets](https://apis.io/providers/cboe/)
- [Deribit, public/get_book_summary_by_currency](https://docs.deribit.com/api-reference/market-data/public-get_book_summary_by_currency)
- Aufbau der Cboe-Antwort, drei Beschreibungen: [OpenBB, Diskussion 2741](https://github.com/OpenBB-finance/OpenBBTerminal/discussions/2741),
  [RevenueChaser, Issue 418](https://github.com/alsanvolkan/RevenueChaser-public/issues/418),
  [David Arias, Gamma exposure step by step](https://davidariasfinance.com/scripts/gamma-exposure-gex/)
- Code: `hl_makro.py` (`powerlaw_monatlich`, `HALVINGS`, `ableiten`), `hl_makro_signal.py` (`pruefung`, `prognose`, `ar1`,
  `_fehler_bekannt`), `hl_ausblick.py` (`crps_ens`, `gew_quantile`), `hl_aktien.py` (Cboe, Deribit), `hl_optionen.py` (Erstlauf)
