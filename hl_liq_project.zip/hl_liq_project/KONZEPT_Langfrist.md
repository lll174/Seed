# KONZEPT Langfrist (U277–U280) — Fächer über 24 Monate für BTC: zwei Sichten, Vorprüfung mit vorab festen Regeln

Stand 20.11.2026, 01:50 (gemessen; Fable 5.2). **Vorab festgelegt, bevor eine einzige Zahl der Vorprüfung auf echten Daten gerechnet
wurde.** Anlass: Wunsch des Nutzers vom 19.11.2026, 23:44 (Prognosechart über 24 Monate) und seine vier Entscheidungen vom 20.11.
nachts zur `BEWERTUNG_Prognosechart_24_Monate_19-11-2026.md`. **Status: Konzept. Gebaut ist nur ein Prototyp im Arbeitsordner, der
auf erzeugten Reihen lief (Abschnitt 8); im Paket ist nichts.** Auf dem Pi läuft 2026-09-23.112.

**Nachtrag 20.11.2026, 09:30 (Paket 23.113):** Der Erstlauf der Optionen (Abschnitt 9.1) ist gebaut: `hl_optionen.py`, Debug 154.
Wie er zählt, steht in Abschnitt 15 (Z1 bis Z6) — festgelegt vor dem ersten Abruf. Die Vorprüfung (Debug 153) kommt frühestens mit 23.115 (Abschnitt 13, Nachtrag);
die Nummer 153 ist im Dashboard bis dahin reserviert. An den Regeln der Abschnitte 3 bis 8 ist nichts geändert.

**Nachtrag 20.11.2026, 22:10 (Paket 23.114 läuft auf dem Pi):** Der Erstlauf der Optionen ist ausgewertet (Abschnitt 15): Deribit
ist brauchbar, IBIT bei Cboe ist gesperrt — es bleibt vorerst bei Deribit; eine Recherche nach anderen Quellen liegt vor
(`RECHERCHE_Optionsquellen_20-11-2026.md`). Der Nutzer hat am 20.11. um 18:40 entschieden: Paket 23.115 bringt die Vorprüfung
(Debug 153) und eine Messung, wie lange eine Runde des Recorders dauert. An den Regeln der Abschnitte 3 bis 8 ist nichts geändert.
(Uhrzeit berichtigt: Dieser Nachtrag trug zuerst die geschätzte Zeit 22:30; geschrieben wurde er zwischen 22:00 und 22:13.)

**Nachtrag 20.11.2026, 23:00 (Paket 23.115, vor dem ersten Lauf der Vorprüfung):** Die Vorprüfung ist gebaut: `hl_langfrist.py`,
Debug 153. Der erste Lauf mit vollständigen Daten auf dem Pi fällt das Urteil und legt es ab (7.5). Was beim Bau zu klären war —
wann ein Lauf als erster zählt, wie bei fehlenden Kurstagen gezählt wird, wo das Urteil liegt —, steht in Abschnitt 15; festgelegt,
bevor der Lauf eine Zahl auf echten Daten gerechnet hat. An den Regeln der Abschnitte 3 bis 8 ist nichts geändert: Das Modul
ergibt auf vier erzeugten Welten dieselben Tabellen und Urteile wie der Prototyp (Abweichung 0,0).

**Nachtrag 21.11.2026, 09:05 (Paket 23.116 — nach dem Urteil, vor der ersten Monatsfassung):** Die Vorprüfung hat am 21.11.2026 um
07:15 auf dem Pi ihr Urteil gefällt und abgelegt: Der Hauptfächer H bleibt, kein Band ist zu schmal, der Chart kann gebaut werden
(Zahlen in Abschnitt 15). Paket 23.116 bringt den Chart: Reiter „24 Monate“ im Makro-Chart und Debug 156. Wie er gebaut ist und
wie die Vorwärtsbilanz zählt, steht im neuen Abschnitt 10a — festgelegt, bevor eine Monatsfassung gespeichert ist. An den Regeln
der Abschnitte 3 bis 8 ist nichts geändert; es gilt Regelversion 1. Nicht gebaut sind die Markt-Schicht und der Kontextstreifen
(beide Stufe 2).

**Nachtrag 22.11.2026, 23:14 (Paket 23.120 — zweiter Teil der Markt-Schicht, Schritt 2a):** Die Prognosemärkte kommen in zwei
Schritten in den Chart, wie die Optionen: erst messen, dann zeichnen (Entscheidung des Nutzers vom 22.11.2026, 22:15 Uhr). 23.120
sammelt zwei weitere Marktreihen und bringt den Bericht Debug 159, der zeigt, was die Prognosemärkte für den Chart hergeben; am
Chart ändert sich nichts. Die Regeln dafür stehen im neuen Abschnitt 9.4. Die Punkte im Chart und der Kontextstreifen folgen mit
23.121 — ihre Regeln werden festgelegt, wenn der erste Bericht vom Pi da ist. An den Regeln der Abschnitte 3 bis 8 ist nichts
geändert; es gilt Regelversion 1.

**Nachtrag 23.11.2026, 05:16 (Paket 23.121 — zweiter Teil der Markt-Schicht, Schritt 2b; festgelegt vor dem Bau):** Der erste
Bericht Debug 159 vom Pi liegt vor (23.11., 04:51). Der Nutzer hat danach drei Fragen entschieden: Punkte nur für lange Märkte (ab 90
Tagen Frist), am Punkt die rohe Zahl, Fed-Marken nur für Sitzungen mit engem Markt. Die Regeln dazu stehen im neuen Abschnitt 9.5
(PM10 bis PM20); drei Regeln aus 9.4 sind dort nach dem Bericht geändert (PM3, PM6, PM7 — der letzte Handel zählt nicht mehr). An
den Regeln der Abschnitte 3 bis 8 ist nichts geändert; es gilt Regelversion 1. Die Schicht geht weiter nicht in den Fächer ein.

Offenlegung — was ich beim Festlegen kannte:

- Debug 52 vom 18.11.: die Fortschreibung von U126 über 365 Tage. Paar „Kurs gegen Power-Law-Fair-Value“, Zeitraum „alles“:
  119.750 USD, Band 60.545–165.393, Halbwertszeit 317 Tage, „Band traf im Rückblick 83 %“ (4 J: 86 %, 8 J: 75 %). Ebenso gesehen:
  Realized Price „alles“ 81.035 (34.502–191.825, 97 %) und 200-Wochen-MA „alles“ 111.474 (40.711–161.931, 84 %). Die Werte für 90
  und 180 Tage rechnet U126 mit; der Bericht zeigt sie nicht.
- Die Literatur aus der BEWERTUNG: Fehler außerhalb der Stichprobe 2014–2024, auf im Kern derselben Kurshistorie.
- Meinen Überschlag (BEWERTUNG, Abschnitt 3): gerechnet aus Berichtszahlen und Literaturwerten, ohne Kursdaten.
- **Nicht gesehen:** irgendeine Rückrechnung für 548 oder 730 Tage auf den Daten des Pi, irgendeinen CRPS-Wert auf echten Daten,
  irgendein Ergebnis der Sichten „Zyklus“ und „Bewertung“ über diese Horizonte. Im Arbeitsordner liegen keine Kursdaten; die
  echten Zahlen entstehen erst auf dem Pi.

---

## 0. Kurzfassung

- **Was entsteht:** ein Fächer für BTC über 24 Monate (Bänder 50 % und 80 %) aus zwei Sichten je zur Hälfte — „ohne Richtung“
  (der Kurs bleibt, Breite aus der Schwankung) und „Trend“ (Power Law mit Rückkehr zum Median, die Rechnung aus Debug 52). Daneben,
  nicht eingerechnet: Optionen, Prognosemärkte, Halving, Wirtschaftstermine.
- **Zuerst die Vorprüfung** (Debug 153): dieselben Regeln rückwirkend ab 2014, alle 30 Tage, für 3, 6, 12, 18 und 24 Monate — an
  jedem Stichtag nur mit Daten, die damals bekannt waren.
- **Drei Regeln stehen vorher fest:**
  1. *Ablösung.* Zyklus (4-Jahres-Theorie), Bewertung oder wandernde Gewichte kommen nur in den Fächer, wenn sie bei 12 Monaten
     nachweisbar besser waren, bei 24 Monaten nicht schlechter und in den letzten vier Jahren nicht schlechter (Abschnitt 7.1).
  2. *Alarm.* Hält das 80-%-Band deutlich seltener als 80 %, wird nicht gebaut, ohne zu fragen (7.2).
  3. *Nichts wird nach dem Blick auf die Zahlen angepasst* (7.6).
- **Auf erzeugten Reihen ausprobiert** (1.000 Welten, keine echten Daten; Abschnitt 8): Ohne Zusammenhang lösen Zyklus oder
  Bewertung den Fächer in 0 bis 1 % der Welten fälschlich ab, ein Fehlalarm kommt in 0 bis 3 %. Ein eingebauter Zyklus wird ab
  rund 2 σ in vier von fünf Welten erkannt; ein schrumpfender Zyklus, grob wie in der Geschichte, nur in einer von fünf.
- **Was die Vorprüfung nicht kann:** belegen, dass das Band bei 24 Monaten stimmt (6 Fenster ohne Überlappung). Sie kann zeigen,
  dass es grob falsch ist, sie prüft die Rechnung, und sie liefert die Breiten aus den Daten des Pi statt aus der Literatur.
- **Reihenfolge:** Paket 23.113 (offene Fehler; dazu Erstlauf Optionen, Debug 154) → Vorprüfung (Debug 153; Paket 23.115) → Chart →
  Markt-Schicht.
- **Stand 21.11.2026:** Urteil der Vorprüfung — H bleibt, kein Alarm, „kann gebaut werden“ (Abschnitt 15). Der Chart ist mit
  Paket 23.116 gebaut (Abschnitt 10a); die Vorwärtsbilanz beginnt mit dem Einspielen, die erste Fassung gilt dem nächsten
  Monatsersten.

## 1. Entscheidungen des Nutzers (20.11.2026, Auswahl)

| Frage | Entschieden | Folge |
|---|---|---|
| Form | Fächer mit zwei Sichten | Bänder 50 % und 80 %; beide Sichten bleiben sichtbar; keine einzelne Prognoselinie |
| Coins | nur BTC | Power Law und Halving gibt es nur dort |
| Optionen | Deribit und IBIT | neue Quelle; zuerst ein Erstlauf (Abschnitt 9) |
| Start | erst Vorprüfung | Abschnitte 3 bis 8; der Chart kommt danach |

## 2. Was in den Fächer fließt und was daneben steht

| Baustein | Platz | Grund |
|---|---|---|
| Kurs seit 2010: Schwankung | **im Fächer** (Sicht A) | trägt über Jahre |
| Power Law und Abweichung davon | **im Fächer** (Sicht B) | der am besten belegte Anker; Fehler bekannt |
| Halving-Zyklus (4-Jahres-Theorie) | Kandidat (Sicht C); sonst dünne Vergleichslinien | drei Zyklen; in den Fächer nur über 7.1 |
| Bewertung: Realized Price, 200-Wochen-MA | Kandidat (Sicht D); sonst Zonenstreifen | zweite Meinung zum Trend; in den Fächer nur über 7.1 |
| Optionen (Deribit, IBIT) | eigene Schicht, Punkte je Verfalltag | risikoneutral; keine Historie zum Prüfen |
| Prognosemärkte BTC | Punkte bis Ende 2027 | reichen nicht weiter; lange Fristen verzerrt |
| Halving-Termin, FOMC, Preis- und Arbeitsmarkttermine, US-Wahl | Zeitachse | Termine bewegen Tage, nicht den Pfad; das Halving ist ein Datum, keine Wahrscheinlichkeit |
| Makro (FRED), Fed-Pfad aus Kalshi | Kontextstreifen | im Projekt nichts belegt (0 von 45) |
| Aktienmarkt, Hyperliquid-Daten | nicht im Chart (nur der Startkurs) | reichen Stunden bis Wochen |

## 3. Daten, Raster, Horizonte

- **Kurs:** `cm:btc:PriceUSD` (Coin Metrics, Tageswerte) ab 18.07.2010 aus `makro.db`, so wie ihn `hl_makro.ableiten` liefert
  (`D["P"]`). Dieselbe Reihe wie im Makro-Chart.
- **Abgeleitet, je Tag nur aus Daten bis zu diesem Tag:** Fair Value des Power Law mit Monatsparametern (`powerlaw_monatlich`, ab
  Januar 2011), Realized Price, 200-Wochen-MA (ab Mai 2014), Halving-Daten (`HALVINGS`).
- **Ursprünge:** das Raster von U126 (`hl_makro_signal.pruefung`, Zeitraum „alles“): erster Ursprung 365 Tage nach dem ersten Fair
  Value, dann alle 30 Tage. **Gewertet** werden Ursprünge ab 01.01.2014; frühere füllen nur das Fehlergedächtnis.
- **Horizonte:** 90, 180, 365, 548 und 730 Tage (3, 6, 12, 18, 24 Monate). Die ersten drei sind die von U126.
- **Ziel:** ln(Kurs am Tag Ursprung + h). Fehlt der Kurs am Zieltag, entfällt der Fall; der Bericht zählt solche Fälle.
- **Zählung nach heutigem Stand** (nur das Raster gerechnet, ohne Kursdaten; `fenster.py` im Arbeitsordner):

  | Horizont in Tagen | 90 | 180 | 365 | 548 | 730 |
  |---|---:|---:|---:|---:|---:|
  | gewertete Ursprünge | 154 | 151 | 145 | 138 | 132 |
  | Fenster ohne Überlappung | 52 | 26 | 12 | 8 | 6 |

  „Ohne Überlappung“ heißt: jeder ⌈h ÷ 30⌉-te Ursprung ab dem ersten gewerteten (voraussichtlich 20.01.2014). Der Lauf nennt die
  echten Zahlen.

## 4. Die vier Sichten (feste Regeln)

An jedem Ursprung o zählt nur, was bis o bekannt war. P = Kurs, FV = Fair Value des Power Law. Jede Sicht hat einen **Rohwert**
(die Vorhersage der Regel), eine **Verteilung** und eine **Mitte** (den Median der Verteilung).

### 4.1 Sicht A „ohne Richtung“

- **Rohwert und Mitte:** der Kurs am Ursprung.
- **Breite:** s(h) = v · √(h ÷ 365). v = Standardabweichung der täglichen ln-Renditen der letzten 1.461 Tage bis zum Ursprung
  (mindestens 365 Tage), auf ein Jahr hochgerechnet (× √365).
- **Verteilung:** normal in ln um die Mitte.
- **Keine Berichtigung aus früheren Fehlern.** Die Fehler von „Kurs bleibt“ enthalten den Anstieg der Vergangenheit; damit käme
  eine Richtung in die Sicht ohne Richtung.

### 4.2 Sicht B „Trend“ — U126 unverändert, zwei Horizonte mehr

- y = ln(P ÷ FV). Median μ und AR(1) (φ, σ) über alle Tage bis zum Ursprung; Erwartung von y nach h Tagen:
  m(h) = μ + φ^h · (y − μ).
- **Rohwert:** ln(FV am Zieltag) + m(h); FV mit den Monatsparametern des Ursprungs.
- **Fehler** eines früheren Ursprungs: ln(P am Ziel) − Rohwert.
- **Verteilung:** Rohwert + die eigenen bekannten Fehler der letzten vier Jahre (Regel `_fehler_bekannt`: Ursprünge der letzten
  vier Jahre, deren Ziel am Ursprung schon bekannt war; mindestens 20). Darunter gilt das Modellband (normal, aus dem AR(1)).
- **Mitte** = Median der Verteilung. Debug 52 zeigt als Erwartung den Rohwert; die Ränder 10 % und 90 % sind dieselben.
- **B3 (neu, nur für den Fächer): Die Spanne zwischen 10-%- und 90-%-Rand (in ln) fällt nicht mit dem Horizont.** Ist sie bei
  einem Horizont kleiner als beim vorigen, werden die Abstände aller Quantile zur Mitte mit einem gemeinsamen Faktor gestreckt,
  bis sie gleich ist. Grund: Bei 548 und 730 Tagen stammen die bekannten Fehler aus zwei bis drei unabhängigen Zeiträumen; eine
  kleinere Spanne als bei 365 Tagen wäre Zufall.

### 4.3 Sicht C „Zyklus“ — die 4-Jahres-Theorie als Rechenregel

- τ = Tage seit dem letzten Halving am Ursprung. Für jedes frühere Halving H das Kursvielfache von damals, bereinigt um den Trend:
  q(H) = [P(H+τ+h) ÷ P(H+τ)] ÷ [FV(H+τ+h) ÷ FV(H+τ)], FV mit den Parametern des Ursprungs.
- **Rohwert:** P(o) · [FV(o+h) ÷ FV(o)] · geometrisches Mittel der q(H).
  In Worten: Der Kurs entwickelt sich gegenüber dem Trend so wie im Mittel der früheren Zyklen ab demselben Tag nach dem Halving.
  (Abweichung vom Trend statt Kursvielfache, weil die Vielfachen mit jedem Zyklus schrumpfen.)
- Es zählen die vier Halvings (28.11.2012, 09.07.2016, 11.05.2020, 20.04.2024). Die Sicht gibt es darum erst für Ursprünge ab
  09.07.2016 — mit einem, dann zwei, heute drei früheren Zyklen.
- **Verteilung:** Rohwert + eigene bekannte Fehler der letzten vier Jahre (mindestens 20). Darunter: Rohwert + Streuung von B
  (dessen Fehler abzüglich ihres Medians, oder dessen Modellband). B3 gilt.

### 4.4 Sicht D „Bewertung“

- Paare „Kurs gegen Realized Price“ und „Kurs gegen 200-Wochen-MA“ aus U126, Zeitraum „alles“: Rückkehr der Abweichung zum Median
  wie in B; die Referenzlinie wird mit ihrem Trend der letzten 365 Tage fortgeschrieben (wie in Debug 52).
- **Rohwert:** Mittel der ln-Prognosen der vorhandenen Paare (eines oder zwei).
- **Verteilung:** wie bei C.

## 5. Hauptfächer und Kandidaten

| Kennung | Fächer | Gewichte |
|---|---|---|
| **H** | **Hauptfächer** | ½ A + ½ B |
| G | wandernde Gewichte | Gewicht von B = MSE(A) ÷ [MSE(A) + MSE(B)], begrenzt auf ¼ bis ¾; A bekommt den Rest |
| Z | mit Zyklus | ½ A + ¼ B + ¼ C |
| W | mit Bewertung | ½ A + ¼ B + ¼ D |

- **MSE in G:** mittlerer quadrierter ln-Fehler der Mitte einer Sicht über ihre bekannten Fehler der letzten vier Jahre (je
  mindestens 20); sonst bleibt es bei ½.
- **Vergleichslinien** (berichtet; sie können den Fächer nicht ablösen): A, B, C und D je allein.
- **A bleibt in Z und W bei der Hälfte.** Sonst gewönne ein Kandidat schon dadurch, dass er mehr Gewicht auf Trend-Sichten legt —
  und der Trend lag in der Vergangenheit vorn. So misst der Vergleich nur, ob Zyklus oder Bewertung die Trend-Hälfte verbessern.
- **Warum je zur Hälfte:** Der Vorsprung des Power Law vor „Kurs bleibt“ ist in der Literatur nicht gesichert (p 0,196 bei 12 und
  0,079 bei 24 Monaten), die Trendform ist nicht bestimmbar. Gleiche Gewichte sind die Setzung bei Unwissen; G prüft die Alternative.
- **Mischen:** Jede Sicht wird durch 199 Quantile dargestellt (0,5 % bis 99,5 %); die Mischung ist ihre gewichtete Vereinigung.
  Quantile der Mischung: `hl_ausblick.gew_quantile`.
- Gibt es C oder D an einem Ursprung nicht, ist Z bzw. W dort gleich H.

## 6. Maße (je Horizont und Fächer)

- **CRPS** in ln, genau für die gewichtete Vereinigung (kleiner ist besser): Mittel über die gewerteten Ursprünge, dazu im
  Verhältnis zu H. Mit 199 Quantilen weicht der Wert vom genauen CRPS einer Normalverteilung um höchstens 0,7 % ab (gemessen an
  drei Punkten) — für alle Fächer gleich.
- **Deckung** des 50-%- und des 80-%-Bands; dazu der Anteil über dem 90-%-Rand und unter dem 10-%-Rand.
- **Fehler der Mitte:** RMSE in log10 (vergleichbar mit der Literatur) und als Faktor („typisch um den Faktor x daneben“).
- **Ohne Überlappung:** dieselben Zahlen als „x von y Fenstern“.
- **Standardfehler der Deckung:** √(p · (1 − p) ÷ n), n = Zahl der Fenster ohne Überlappung.

Der Blockbootstrap des Ausblicks (U146) trägt hier nicht: Bei 730 Tagen passen keine drei Blöcke in die Historie.

## 7. Regeln vorab

### 7.1 Ablösung des Hauptfächers

H bleibt Hauptfächer. Ein Kandidat (G, Z, W) löst ihn nur ab, wenn alle drei Bedingungen gelten:

1. **Nachweis bei 365 Tagen.** d = CRPS von H − CRPS des Kandidaten, je Fenster ohne Überlappung; Fenster, in denen der Kandidat
   mit H übereinstimmt, zählen nicht; mindestens 6 Fenster. Einseitiger **Vorzeichenwechsel-Test**: p = Anteil aller 2^n
   Vorzeichenmuster, deren Mittel mindestens so groß ist wie das beobachtete. Verlangt ist p ≤ 0,05 ÷ 3 = 0,0167.
2. **730 Tage, alle gewerteten Ursprünge:** Sein mittleres CRPS ist nicht größer als das von H.
3. **Letzte vier Jahre, 365 Tage:** Über die Ursprünge der letzten vier Jahre ist sein mittleres CRPS nicht größer als das von H.
   Grund: Die Ausschläge der Zyklen schrumpfen; was 2016 bis 2021 trug, muss heute nicht mehr tragen.

Bestehen mehrere, gilt der mit dem kleinsten mittleren CRPS bei 365 Tagen. Primär ist 365 Tage, weil dort 9 bis 12 Fenster
liegen (kleinstes mögliches p bei 9 Fenstern: 1 ÷ 512); bei 730 Tagen sind es 5 bis 6 — zu wenige für einen Test.

**Die Hürde ist hoch.** Was nicht besteht, erscheint im Chart nur als Vergleichslinie (frühere Zyklen) oder Streifen (Bewertung),
nicht im Fächer. Nicht bestanden heißt nicht „kein Zusammenhang“ (Nachweisgrenze: Abschnitt 8).

### 7.2 Alarm „Band zu schmal“

Geprüft wird der Fächer, der nach 7.1 Hauptfächer ist. Liegt die Deckung seines 80-%-Bands bei einem Horizont unter
0,80 − 2 · √(0,16 ÷ n) (n = Fenster ohne Überlappung), baue ich den Chart nicht ohne Rückfrage. Nach heutigem Stand sind das
68,9 / 64,3 / 56,9 / 51,7 / 47,3 % für 90 / 180 / 365 / 548 / 730 Tage. Der Nutzer bekommt den Befund und zwei Wege: das Band auf
die gemessene Breite strecken und so beschriften — oder den Horizont nicht zeigen.

### 7.3 Hinweis „Band zu breit“

Deckung über 0,80 + 2 · √(0,16 ÷ n): nur ein Hinweis am Chart. Ab 365 Tagen liegt diese Grenze über 100 %; dort ist „zu breit“
nicht feststellbar.

### 7.4 Aussagekraft

Liegt beim heutigen Hauptfächer der 90-%-Rand bei 730 Tagen über dem 20-Fachen des 10-%-Rands, frage ich nach, ob der Chart so
gebaut werden soll. (Überschlag: Faktor 11.)

### 7.5 Ein Urteil, ein Lauf

Das Urteil zu 7.1 bis 7.4 fällt der erste Lauf auf dem Pi. Spätere Läufe zeigen den Stand, ändern den Hauptfächer aber nicht.

### 7.6 Nichts wird nachträglich angepasst

Fest sind: Zeitraum „alles“, Fehlerfenster vier Jahre, Schwankungsfenster 1.461 Tage, Raster, Start 2014, Horizonte, Gewichte,
Test und Schwellen. Jede spätere Änderung ist eine neue Regelversion mit Datum und Grund in Abschnitt 15; der Chart zeigt die
Regelversion (Start: 1).

### 7.7 Nebenrechnung ohne Folgen

Sicht B mit den Zeiträumen 4 J und 8 J statt „alles“ — zeigt, wie empfindlich die Mitte ist.

## 8. Kalibrierung auf erzeugten Reihen (gemessen 20.11.2026, Arbeitsordner)

Prototyp `lf_proto.py` mit den unveränderten Bausteinen aus Paket 23.112 (`powerlaw_monatlich`, `ar1`, `y_prognose`, `Referenz`).
**Nur erzeugte Reihen, feste Startwerte, keine echten Kurse.** Jede Welt: 5.970 Tage ab 18.07.2010, 179 Ursprünge; eine Welt
rechnet in 0,6 s (Arbeitsrechner, nicht der Pi). σ = Streuung der Abweichung vom Trend in Welt 1 (0,301 in log10).

**Welten ohne Zusammenhang** — wie oft irren die Regeln?

| Welt | Welten | abgelöst durch G | durch Z | durch W | Alarm 7.2 (irgendein Horizont) | Deckung 80 % von H bei 90 / 180 / 365 / 548 / 730 Tagen |
|---|---:|---:|---:|---:|---:|---|
| 1: Power Law + AR(1)-Abweichung (Halbwertszeit 317 Tage) | 200 | 1,0 % | 0,5 % | 0,0 % | 0,0 % | 80 / 80 / 80 / 79 / 79 % |
| 1 mit fallender Schwankung (1,6- auf 0,6-fach) | 100 | 0,0 % | 1,0 % | 0,0 % | 0,0 % | 85 / 85 / 85 / 84 / 84 % |
| 1 mit dicken Rändern und Schwankungsballung (Wölbung rund 15) | 100 | 2,0 % | 0,0 % | 0,0 % | 2,0 % | 81 / 80 / 79 / 77 / 76 % |
| 3: reiner Zufallsweg ohne Trend | 100 | 2,0 % | 0,0 % | 0,0 % | 3,0 % | 78 / 77 / 76 / 74 / 73 % |

- Zyklus und Bewertung lösen ohne Zusammenhang in 0 bis 1 % der Welten ab (Soll: zusammen höchstens 5 %). **Die Schwelle 0,0167
  bleibt.**
- G hat keine „falsche“ Ablösung im selben Sinn: Im Zufallsweg ist mehr Gewicht auf A richtig.
- Alarm 7.2 (auf dem Fächer, der nach 7.1 Hauptfächer ist): 0 bis 3 %.
- In Welt 1 — dort ist B das wahre Modell — deckt B allein nur 73 / 69 / 60 / 56 / 54 %, A allein 79 / 79 / 76 / 73 / 70 %. Das
  Fehlergedächtnis von vier Jahren enthält bei langen Horizonten zu wenige unabhängige Fehler. Die Mischung H gleicht das aus und
  hat dort auch das kleinste CRPS (A allein +2 bis +34 %, B allein +6 bis +13 %, G +0,2 bis +1,3 %, Z +1,3 bis +1,6 %,
  W +0,5 bis +4,5 %).
- B3 hebt in Welt 1 die Deckung von B bei 730 Tagen von 49 auf 53 %, die von H von 76 auf 78 % (60 Welten).

**Welten mit eingebautem Zyklus** (Welt 1 plus Vier-Jahres-Sinus in der Abweichung, Hoch rund 525 Tage nach dem Halving; je
100 Welten) — wie stark muss er sein?

| Stärke des Zyklus | Z löst ab | Alarm 7.2 auf H | Alarm auf dem Hauptfächer nach 7.1 |
|---|---:|---:|---:|
| 1,0 σ | 6 % | 0 % | 0 % |
| 1,5 σ | 46 % | 2 % | 1 % |
| 2,0 σ | 79 % | 11 % | 2 % |
| 3,0 σ | 97 % | 65 % | 1 % |
| schrumpfend: 2,8 / 2,0 / 1,2 / 0,5 σ je Zyklus | 18 % | 0 % | 0 % |

- **Nachweisgrenze: rund 2 σ.** Das ist ein Sinus mit Ausschlag ±1,39 in ln (Faktor 4 über und unter dem Trend); er erklärt rund
  zwei Drittel der Abweichung vom Trend.
- Die schrumpfende Welt ist der Geschichte grob nachempfunden (Überschlag aus den Hochs und Tiefs der BEWERTUNG: 2013 rund 2,4 σ,
  2017 rund 1,9 σ, 2021 rund 1,2 σ, 2025 rund 0,5 σ). Dort besteht Z in 18 % der Welten — obwohl Z in den letzten vier Jahren in
  80 % dieser Welten besser gewesen wäre als H (CRPS im Median −9 % bei 365 Tagen). **Besteht Z auf echten Daten nicht, belegt das
  also nicht, dass der Zyklus nichts beiträgt.**

**Wahl des Tests** (je 60 Welten, 365 Tage, vor dem Ablegen dieses Konzepts): Der zuerst vorgesehene Vorzeichentest („besser in
fast jedem Fenster“) erkannte einen Zyklus von 2 σ nur in 28 % der Welten, der Vorzeichenwechsel-Test in 85 %, bei ähnlicher
Irrtumsquote ohne Zusammenhang (Z in Welt 1: je 0,5 % von 200 Welten). Eine Fassung mit Blöcken aus allen Ursprüngen erkannte
noch mehr (97 %), aber ihre Blöcke überlappen sich an den Rändern; ich habe die saubere Fassung gewählt.

**Proben am Prototyp:** kein Blick in die Zukunft (Vorhersage aus der vollen Reihe = Vorhersage aus der am Stichtag abgeschnittenen
Reihe, Abweichung 0,0; zwei Mutationen fallen auf) · 90, 180 und 365 Tage stimmen mit `pruefung` und `prognose` von U126 überein
(Zahl der Fälle und Ränder auf 12 Stellen) · CRPS gleich `hl_ausblick.crps_ens` · C gleich B ergibt Z gleich H.

Dateien im Arbeitsordner `/home/claude/audit/work/prog24/`: `lf_proto.py`, `lf_proben.py`, `lf_kalib2.py`, `lf_tests.py`,
`lf_b3.py`; Protokolle `k2_*.log`, `tests_*.log`, `kalib_w1.log`.

## 9. Optionen: Erstlauf (U278, Debug 154) und Regel danach

### 9.1 Was der Erstlauf misst

Je ein Abruf; gespeichert wird nur der Bericht.

- **Deribit** (öffentliche Schnittstelle, schon Quelle für DVOL): Liste der BTC-Optionen und ihre Kurszusammenfassung. Bericht:
  Zahl der Verfalltage, längster Verfall, Strikes je Verfall, Anteil mit Geld- und Briefkurs, Spanne am Geld für die drei
  längsten Verfalltage, Größe und Dauer der Antwort.
- **IBIT** (Cboe, verzögerte Kurse; dieselben zwei Hosts wie für VVIX und VIX9D): erreichbar ja oder nein, mit Statuscode; Größe
  und Dauer; Zahl der Kontrakte; Verfalltage und der längste; für Verfalltage ab 12 Monaten: Strikes mit Geld- und Briefkurs,
  Spanne am Geld, offene Kontrakte; Zeitstempel der Kurse; IBIT-Kurs.
- Der Erstlauf stürzt bei unerwartetem Format nicht ab; er meldet dann die Struktur der Antwort.

Bekannt vorab: Deribit führt bei BTC-Optionen (invers) bis zu vier Tages-, drei Wochen-, drei Monats- und vier Quartalsverfälle
([Deribit](https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy)). Der längste wäre heute
der 24.09.2027, gut zehn Monate entfernt (eigene Rechnung: letzter Freitag im vierten kommenden Quartalsmonat). Für das zweite
Jahr bleibt also nur IBIT. Cboe speist seine Kursseiten aus frei abrufbaren JSON-Daten mit verzögerten Kursen
([apis.io](https://apis.io/providers/cboe/)); ob der Pi die IBIT-Kette dort vollständig bekommt, ist ungeprüft.

### 9.2 Regel danach (vorab)

- Ein Verfalltag ist **brauchbar für Quantile**, wenn auf jeder Seite des Terminkurses mindestens fünf Strikes Geld- und Briefkurs
  haben und die Spanne am Geld höchstens 15 % des Mittelkurses beträgt. Sonst zählt nur die implizite Schwankung am Geld; fehlt
  auch sie, entfällt der Verfalltag.
- **IBIT kommt nur in den Chart, wenn mindestens ein brauchbarer Verfalltag 18 Monate oder länger läuft.** Sonst bleibt es bei
  Deribit, und der Nutzer bekommt den Befund.
- Rechenweg der Quantile und Abrufzeit lege ich nach dem Erstlauf in einem Nachtrag fest, bevor Stufe 2 gebaut wird. Fest steht
  schon: ein Abruf am Tag kurz vor US-Handelsschluss; gespeichert werden nur Kennzahlen je Verfalltag (Schwankung am Geld,
  Quantile, Terminkurs, Zahl der Strikes); IBIT wird über das Verhältnis Strike ÷ IBIT-Kurs auf BTC umgerechnet.
- **Lesart:** Optionspreise sind risikoneutral; ihre Mitte ist der Terminkurs. Die Schicht steht neben dem Fächer und geht nicht
  in die Mischung, solange es keine Bilanz gibt. Eine Rückrechnung ist nicht möglich: Auf dem Pi gibt es keine Options-Historie.

### 9.3 Rechenweg und Abruf der Optionen-Schicht (Nachtrag 22.11.2026 — vor dem Bau von Stufe 2 festgelegt)

Festgelegt am 22.11.2026 gegen 02:00, bevor eine Zeile der Schicht gebaut ist und bevor ein Rand aus Optionspreisen gerechnet
wurde. Bekannt waren die beiden Erstläufe (Debug 154 vom 20.11.: Zahl der Verfalltage und Strikes, Spannen, das Feld
`underlying_price`) — keine Quantile. Entscheidung des Nutzers vom 22.11.: Markt-Schicht nur mit Deribit; IBIT und die Quelle
für das zweite Jahr bleiben zurückgestellt (U293). Die Schicht reicht deshalb 10 bis 12 Monate.

- **O1 Abruf.** Ein Aufruf bei Deribit (`get_book_summary_by_currency`, BTC, Optionen) je Tag, fällig ab 15:45 Uhr New York —
  auch an Wochenenden und US-Feiertagen, Deribit handelt durchgehend. Der „Tag“ eines Abrufs ist das Datum in New York. Gelingt
  er nicht, versucht es der Makro-Takt wieder (frühestens nach 10 Minuten), bis der New-York-Tag endet; danach hat der Tag
  keinen Wert. Ist noch gar kein Abruf gespeichert, wird einmal sofort abgerufen („Erstabruf“); der Abruf zur festen Zeit
  desselben Tages ersetzt ihn. Sonst wird ein gespeicherter Tag nie geändert.
- **O2 Lesen.** Wie im Erstlauf: Ein Kontrakt zählt mit Geld- und Briefkurs (Z1); sein Kurs ist die Mitte der beiden, in BTC.
  Verfall 08:00 UTC (Z5). Verfalltage, die beim Abruf vorbei sind, entfallen.
- **O3 Terminkurs (U292).** Je Verfalltag aus der Put-Call-Parität: am Strike K, an dem Call und Put beide Kurse haben und
  |Call − Put| am kleinsten ist (bei Gleichstand der niedrigere), gilt F = K ÷ (1 − (Call − Put)) — inverse Optionen, ohne Zins.
  Das Feld `underlying_price` (Median je Verfalltag) ist nur die Gegenprobe; weicht es um mehr als 1 % ab, meldet es der
  Bericht. Ohne ein solches Paar hat der Verfalltag keinen Terminkurs aus der Parität; dann gilt das Feld, und es werden keine
  Ränder gerechnet.
- **O4 Brauchbar** (9.2, unverändert): unter F mindestens fünf Puts und über F mindestens fünf Calls mit beiden Kursen, und die
  Spanne am Geld höchstens 15 %. Sonst zählt nur die Schwankung am Geld; fehlt auch sie, entfällt der Verfalltag.
- **O5 Ränder aus den Preisen** (nur brauchbare Verfalltage):
  1. Preis eines Calls ohne Zins in USD an jedem Strike der beiden Seiten: über F ist C(K) = F · Call(K); unter F folgt er aus
     dem Put: C(K) = F · Put(K) + F − K.
  2. Zwischen zwei benachbarten Strikes K₁ < K₂ dieser Reihe ist s = (C(K₁) − C(K₂)) ÷ (K₂ − K₁) die Wahrscheinlichkeit, dass
     der Kurs am Verfalltag über der Mitte der beiden Strikes liegt (risikoneutral).
  3. s wird auf 0 bis 1 begrenzt. Steigt s von einem Paar zum nächsten, werden die beiden zu EINEM Paar über die ganze Strecke
     zusammengelegt (Wert = Mittel, gewichtet mit dem Abstand der Strikes -- das ist die Abnahme des Preises über die ganze
     Strecke; Mitte = Mitte der Strecke), so oft, bis s mit dem Kurs nirgends mehr steigt.
  4. Der Rand zu q (10, 25, 50, 75, 90 %) ist der kleinste Kurs, an dem 1 − s die Marke q erreicht — zwischen den Mitten gerade
     verbunden. Liegt die Marke außerhalb der Mitten, gibt es diesen Rand nicht („außerhalb der Strikes“); verlängert wird nicht.
  5. Gegenprobe im Bericht, nicht im Chart: dieselben Ränder aus der Schwankung am Geld σ (Normalverteilung in ln um F):
     F · exp(−σ² · t ÷ 2 + z · σ · √t), t = Tage ÷ 365, z = −1,2816 / −0,6745 / 0 / +0,6745 / +1,2816.
- **O6 Speichern.** `makro.db`, Tabelle `lf_option`: je Abruf-Tag und Verfalltag eine Zeile mit Abrufzeit, Tagen bis zum
  Verfall, Terminkurs, Feld, Schwankung am Geld, den fünf Rändern (leer, wo es keinen gibt), Strikes je Seite, Spanne am Geld
  und Stufe. Dazu je Abruf-Tag eine Zeile über den Abruf selbst (`lf_option_abruf`: Zeit, Art, Größe, Dauer, Versuche, letzter
  Fehler). Die Kette selbst wird nicht gespeichert.
- **O7 Anzeige.** Im Chart je brauchbarem Verfalltag ab 28 Tagen (bis dahin reicht der Ausblick) ein Zeichen am Verfalltag:
  dünner Strich vom 10- zum 90-%-Rand, dicker vom 25- zum 75-%-Rand, Punkt an der Mitte; fehlt ein äußerer Rand, endet der
  dünne Strich am inneren; fehlt ein innerer Rand oder die Mitte, gibt es kein Zeichen. Gezeigt wird der jüngste gespeicherte
  Abruf, wenn er höchstens 3 Tage vor dem Stichtag liegt (wie beim Ausblick) — sonst nichts, mit Grund. Der Eintrag in der
  Legende ist schaltbar. Debug 156 führt alle Verfalltage als Tabelle (auch die unter 28 Tagen und die nicht brauchbaren, mit
  Grund), mit Terminkurs gegen Feld, der Gegenprobe aus O5.5 und den Rändern des Fächers am selben Tag.
- **O8 Lesart.** Optionspreise sind risikoneutral: Sie zeigen, zu welchen Preisen sich der Markt absichert, keine Prognose; ihre
  Mitte liegt nahe am Terminkurs. Die Schicht geht nicht in den Fächer ein (9.2). Der Fächer beginnt beim letzten Tagesschluss,
  die Schicht beim Terminkurs zur Abrufzeit. Eine Rückrechnung gibt es nicht. Eine Bilanz der Options-Ränder wird möglich,
  sobald gespeicherte Verfalltage vorbei sind; ihre Regel wird festgelegt, bevor der erste ausgewertet wird.

**Auf erzeugten Ketten ausprobiert (22.11.2026, vor dem ersten echten Abruf; Selbsttest von `hl_marktschicht.py`):** Bei einer
bekannten Verteilung (Strikes alle 2.500 USD, Spanne 2 %) treffen die Ränder aus den Preisen die wahren auf 1 %; bei einer
schiefen Verteilung (Mischung zweier Lognormalverteilungen) auf 1,5 % — die Gegenprobe aus EINER Schwankung liegt dort am
10-%-Rand um 30 % daneben; deshalb kommen die Ränder aus den Preisen. Mit Rauschen (jede Mitte um bis zu 1 % verschoben, Strikes
alle 5.000 USD, 40 Ketten) weicht ein Rand höchstens 2,3 % ab, im Mittel unter 1 %. **Grenze:** Bei dreimal so starkem Rauschen
und doppelt so dichten Strikes lag die Mitte in der Probe 7 % daneben — Differenzen benachbarter Preise verstärken Rauschen. Der
Bericht nennt deshalb je Verfalltag, wie viele Paare zusammengelegt wurden. Eine Änderung dabei: Zuerst blieben zusammengelegte
Werte an ihren alten Mitten stehen; das verschob die Mitte bei Rauschen um bis zu 12 %. Seitdem gilt ein zusammengelegtes Paar als
eines über die ganze Strecke (O5.3). Geändert an erzeugten Ketten, vor jedem echten Abruf.

**Was ich nicht weiß und der erste Abruf auf dem Pi zeigt:** ob die Ränder aus den Preisen bei langen Verfalltagen innerhalb der
Strikes liegen; wie weit sie von der Gegenprobe abweichen (Schiefe der Schwankung über die Strikes); wie groß die Abweichung
zwischen Parität und Feld über den Tag ist. In der Arbeitsumgebung gibt es kein Netz: Der Rechenweg ist an erzeugten Ketten
geprüft (bekannte Verteilung, auch schief und mit verrauschten Kursen), nicht an echten.

**Der erste echte Abruf (22.11.2026, 09:19 Uhr, auf dem Pi unter 23.118; Debug 156 von 09:29 Uhr).** HTTP 200, 1004 Kontrakte,
12 Verfalltage, alle brauchbar; fünf ab 28 Tagen tragen ein Zeichen. Der Terminkurs aus der Parität liegt an allen Verfalltagen
höchstens 0,05 % neben dem Feld. Die Breite zwischen 10- und 90-%-Rand (in ln) weicht von der Gegenprobe um −3,7 bis +3,4 % ab; die
Mitte liegt 0,3 % (1 Tag) bis 5,1 % (306 Tage) über der Gegenprobe, beide äußeren Ränder liegen darunter. Eine gleichmäßig mit dem
Strike fallende Schwankung erklärt alle fünf Ränder jedes Verfalltags (nachgerechnet aus den Zahlen des Berichts) — das Bild einer
Schiefe zu den Puts. Unabhängig belegt ist es nicht. An den beiden längsten Verfalltagen (215 und 306 Tage) gibt es keinen
10-%-Rand. Zusammengelegt wurden an den fünf langen Verfalltagen 5 bis 15 Paare; wo, zeigte der Bericht nicht. Deshalb O9 und O10.

- **O9 Diagnose (Nachtrag 22.11.2026, 10:06 Uhr — nach dem ersten echten Abruf, vor dem zweiten; U302).** Nur für den Bericht:
  Kein Rand und kein Zeichen ändert sich. Je Verfalltag mit Rändern wird beim Abruf zusätzlich gespeichert (`lf_option`, Spalte
  `diag`):
  1. *Wo zusammengelegt wurde.* Eine Zusammenlegung zählt als „im Bereich der Ränder“, wenn die Strecke ihres Paars den Bereich
     vom untersten bis zum obersten vorhandenen Rand berührt; sonst als „außerhalb“. Gezählt wird wie in O5.3 (Paare weniger
     zusammengelegte Paare).
  2. *Die Enden.* Der kleinste und der größte Strike der Reihe aus O5.1, der kleinste und der größte gelistete Strike des
     Verfalltags, und die Wahrscheinlichkeit unter dem untersten und über dem obersten Paar (nach O5.3). Daran ist abzulesen,
     warum ein äußerer Rand fehlt.
  3. *Zweite Gegenprobe aus den Schwankungen der Börse.* Für jeden gelisteten Strike mit einer Schwankung der Börse (`mark_iv`)
     der Call-Preis ohne Zins nach Black-76: C(K) = F · N(d₁) − K · N(d₂), d₁ = [ln(F ÷ K) + σ² · t ÷ 2] ÷ (σ · √t),
     d₂ = d₁ − σ · √t, t = Tage ÷ 365, σ = die Schwankung dieses Strikes (unter F die des Puts, über F die des Calls; fehlt sie
     dort, die der anderen Seite; ein Strike genau bei F zählt nicht). F ist der Terminkurs aus O3 — die Gegenprobe prüft die
     Form, nicht die Lage; die Lage prüft O3 gegen das Feld. Auf diese Reihe O5.2 bis O5.4. Sie hängt an keinem Geld- oder
     Briefkurs und reicht über alle gelisteten Strikes.
  Debug 156 zeigt 1 bis 3 je Verfalltag. Ein Abruf, der vor 23.119 gespeichert wurde, hat keine Diagnose (der Bericht sagt „noch
  keine“).
  *Nachtrag beim Bau (22.11.2026, 14:27 Uhr — vor dem Einfrieren, keine Rechenregel geändert):* Die Diagnose darf den Abruf nicht
  kosten. Scheitert ihre Rechnung an einem Verfalltag, werden seine Ränder trotzdem gespeichert; in der Spalte steht dann der
  Fehler, und der Bericht sagt „nicht gerechnet“. Scheitert die Markierung beim Lesen, bleiben die Zeichen im Chart.
- **O10 Prüflauf ohne Speichern (Debug 158, U302).** Von Hand oder aus dem Berichtsplan: EIN Aufruf bei Deribit, dieselbe Rechnung
  (O2 bis O5, O9), dazu für die brauchbaren Verfalltage ab 28 Tagen die Paare im Bereich der Ränder — je Paar die
  Wahrscheinlichkeit vor und nach dem Zusammenlegen und aus der Schwankung der Börse. Er speichert nichts und ändert den
  gespeicherten Tag nicht (O1 gilt weiter).

**Wozu die Diagnose dient (vorab).** Sie ändert vorerst nichts am Chart. Der Bericht markiert einen Verfalltag mit „prüfen“, wenn
die Mitte aus den Preisen um mehr als 3 % neben der Mitte der zweiten Gegenprobe liegt, wenn ein anderer vorhandener Rand um mehr als
6 % daneben liegt oder wenn im Bereich der Ränder mehr als ein Drittel der Paare zusammengelegt ist. Was eine Markierung für das
Zeichen im Chart bedeutet, entscheidet der Nutzer; eine feste Regel dafür gibt es frühestens nach 14 gespeicherten Tagen. Die
Schwellen sind gesetzt, bevor eine zweite Gegenprobe auf echten Daten gerechnet ist; auf erzeugten Ketten mit Rauschen lag ein
Rand höchstens 2,3 % daneben (oben).

### 9.4 Prognosemärkte für den Chart, Schritt 2a: Sammeln und Bestand als Text (Nachtrag 22.11.2026 — beim Bau von 23.120 festgelegt)

**Anlass.** Abschnitt 10 nennt für die Markt-Schicht neben den Optionen die „Schwellen der Prognosemärkte bis Ende 2027 mit Roh- und
rekalibriertem Wert“. Was davon in `prognosemarkt.db` auf dem Pi liegt — welche Ereignisse, welche Fristen, wie frisch die Kurse
sind —, hat bisher kein Bericht gezeigt (Debug 129 zählt nur Märkte je Art). Deshalb zwei Schritte wie bei den Optionen, wo der
Erstlauf (Debug 154) vor der Schicht kam: **Schritt 2a** (Paket 23.120) sammelt und zeigt den Bestand als Text; **Schritt 2b**
(Paket 23.121) zeichnet. Der Nutzer hat dem am 22.11.2026 um 22:15 Uhr zugestimmt („JA, ich folge deinem Vorschlag“) — das gilt für
die zwei Schritte und für die zwei neuen Reihen in PM1.

**Was es am 22.11.2026 an lang laufenden BTC-Märkten gibt** (öffentliche Seiten der Börsen, Stand 22.11.; Quellen unten):

| Börse | Markt | Frist | vom Pi gesammelt |
|---|---|---|---|
| Kalshi | `KXBTCY` Kurs am Jahresende 2026 in Spannen (Mitte laut Seite rund 60.900 USD) | 31.12.2026 | ja |
| Kalshi | `KXBTCMAXY` Jahreshoch 2026 (100.000 bis 150.000 USD je 1 bis 2 %) | 31.12.2026 | ja |
| Kalshi | `KXBTCMINY` Jahrestief 2026 (55.000: 54 %, 50.000: 28 %, 45.000: 16 %, 40.000: 14 %) | 31.12.2026 | ja |
| Kalshi | `KXBTCPRICE` „When will Bitcoin cross $130k?“ (bis 13.05.2027 8 %, 10.06. 10 %, 08.07. 13 %) | Fristen in 2027 | **neu mit 23.120** |
| Kalshi | `KXBTCMAXMON`, `KXBTCMINMON` Monatshoch und -tief; `KXBTC2026200`, `KXBTC2026250` | Monatsende; 31.12.2026 | nein (zu kurz bzw. bei 2 %) |
| Polymarket | „What price will Bitcoin hit in 2026?“ (Berührleiter) | 31.12.2026 | ja |
| Polymarket | „When will Bitcoin hit $100k?“ (bis 31.03.2027 12 %, 30.06. 21 %, 30.09. 33 %, 31.12.2027 46 %) | bis 31.12.2027 | **neu mit 23.120** |

Jahresleitern für 2027 habe ich bei keiner der beiden Börsen gefunden. Bis sie gelistet sind, reichen nur die beiden Märkte mit
mehreren Fristen ins Jahr 2027. Kalshi führt außerdem einen Markt zum Halving-Termin (`KXBTCHALF`: vor April 2028 32 %, vor Mai
88 %, vor Juni 96 %; Umsatz rund 25.000 USD) — er gehört nicht zu diesem Schritt; gegen die Spanne der eigenen Schätzung (12. bis
21.04.2028, Abschnitt 10a) ist er noch nicht gehalten.

**Regeln (PM1 bis PM9)**

- **PM1 Zwei neue Reihen, nur lesen.** (a) Polymarket-Ereignis `when-will-bitcoin-hit-100k` — in `prognosemarkt.db` die Reihe
  `PMfrist`, Art Berührung, Niveau 100.000 USD nach oben (aus der Vorgabe im Code; der Gruppentitel eines Markts trägt die Frist,
  keine Schwelle). Die Frist eines Markts ist das Ende des Tages in New York, den sein Gruppentitel nennt („by March 31, 2027“);
  nennt ein Text mehrere Daten, gilt das späteste; trägt der Gruppentitel kein Datum, die Frage. Liegt das Datum nicht nach dem
  Beginn des Markts oder ist keines lesbar, gilt das Feld `endDate` der Börse. `endDate` bleibt in jedem Fall als Ablauf
  gespeichert. Entdeckt wird das Ereignis alle 30 Minuten, die Kurse kommen alle 15 Minuten — wie bei den übrigen Leitern.
  (b) Kalshi-Reihe `KXBTCPRICE` — stündlich wie die Jahresleitern. Das Niveau steht in den Feldern der Börse; fehlt es dort, im
  Ereignis (`KXBTCPRICE-130000`). Die Frist ist der Handelsschluss des Markts; liegt er mehr als zwei Tage hinter dem Datum im
  Titel des Markts (etwa weil alle Märkte des Ereignisses denselben Schluss tragen), gilt das Datum im Titel. Keine andere Reihe
  bekommt ein Niveau aus ihrer Kennung oder eine Frist aus ihrem Titel.
- **PM2 Bestand.** Debug 159 (`hl_marktschicht.py --prognosemarkt`) öffnet `prognosemarkt.db` nur lesend, ruft nichts ab und
  speichert nichts. Gelesen werden die BTC-Märkte der Reihen `KXBTCY`, `KXBTCMAXY`, `KXBTCMINY`, `KXBTCMAX150`, `KXBTCPRICE`
  (Kalshi) und `PMberuehrung`, `PMschwelle`, `PMfrist` (Polymarket) mit einer Frist ab 7 Tagen — darunter liegen die Stunden-
  und Tagesleitern. Gesucht wird über den Index (Börse, Reihe, Frist), nie mit einem Durchlauf der Tabellen.
- **PM3 Kurs.** Die Wahrscheinlichkeit eines Markts ist die Mitte aus Geld- und Briefkurs, wenn beide da sind und höchstens 4
  Punkte auseinanderliegen; sonst der letzte Handel; sonst gibt es keinen Wert. Ein Kurs heißt frisch, wenn sein letzter Abruf
  höchstens 3 Stunden zurückliegt und der Markt nicht entschieden ist. Alte Kurse stehen mit ihrem Alter im Bericht, gehen aber in
  keine Rechnung ein.
- **PM4 Formen.** Die Märkte eines Ereignisses bilden eine *Schwellen-Leiter* (eine Frist, ein oder mehrere Niveaus), eine
  *Fristen-Leiter* (ein Niveau, mehrere Fristen) oder *Spannen* (Kurs am Stichtag in Spannen); mehrere Niveaus UND mehrere Fristen
  heißen „gemischt“ und stehen bei den Schwellen. Fristen stehen im Bericht als letzter Tag in New York.
- **PM5 Rekalibriert.** Neben jedem Rohwert steht der Wert nach `KONZEPT_Prognosemaerkte.md`, Regel 1.6 (Steigung 1,09 bei 7 bis 30
  Tagen, 1,36 darüber) — gerechnet mit der Frist DIESES Markts, auch im Reiter „Krypto“ der Prognosemärkte (dort rechnete bisher
  jede Zeile eines Ereignisses mit dessen nächster Frist).
- **PM6 Spannen.** Je Spanne der frische Kurs, sonst 0; die Summe wird auf 1 gebracht (die Rohsumme steht dabei). Daraus je
  Spannengrenze die Wahrscheinlichkeit darüber und die Ränder 10, 25, 50, 75 und 90 % — gerade zwischen zwei Grenzen, außerhalb
  der Grenzen keiner. Die rekalibrierte Reihe wendet Regel 1.6 auf die Wahrscheinlichkeit „über der Grenze“ an. Das ist eine
  eigene Übertragung der Regel auf Spannen (die Regel ist für den Kurs eines Ja/Nein-Markts geschätzt); ob der Chart sie nutzt,
  wird mit Schritt 2b entschieden.
- **PM7 Fed-Pfad.** Je offener Sitzung der Kalshi-Reihe `KXFED` (Obergrenze des Zielbands nach der Sitzung): die Schwellen mit
  frischem Kurs als Grenzen auf dem Raster 0,25 Prozentpunkte, die Wahrscheinlichkeiten fallend geglättet (wie in
  `hl_prognosemarkt.py`), daraus die Wahrscheinlichkeit je Rasterwert, der häufigste Satz, das Mittel und die Wahrscheinlichkeit
  unter und über der Leiter. Fehlt zwischen zwei Schwellen eine, zählt ihre Wahrscheinlichkeit in der Mitte der Lücke; der Bericht
  nennt die Lücke. „Gegen heute“ ist das Mittel weniger der Satz nach der zuletzt abgerechneten Sitzung (Wert der Börse). Dazu als
  Listen: `KXFEDDECISION`, `KXRATECUTCOUNT`, `KXRECSSNBER` und die Ereignisse von Polymarket mit „Fed“ im Titel.
- **PM8 Hinweise.** Der Bericht meldet: eine Leiter, die um mehr als 2 Punkte gegen ihre Ordnung läuft (ein ferneres Niveau
  wahrscheinlicher als ein näheres; eine spätere Frist unwahrscheinlicher als eine frühere); einen Markt ohne Niveau; ein Ereignis
  ohne frischen Kurs; eine Zins-Leiter, unter oder über der mehr als 5 % liegen. Je Ereignis nennt er einen Markt mit Kennung und
  Titel und den Anfang der Regel der Börse — daran ist zu prüfen, ob Niveau und Frist richtig gelesen sind.
- **PM9 Lesart und was fehlt.** Kurse von Prognosemärkten sind Preise von Wetten, keine Prognose des Systems; nichts davon geht in
  den Fächer ein, und im Chart steht davon mit 23.120 noch nichts. Offen für Schritt 2b, festzulegen nach dem ersten Bericht vom
  Pi und vor dem Bau: welche Märkte ein Punkt werden (Fristen ab 28 Tagen wie bei den Optionen? welcher Bereich der
  Wahrscheinlichkeit?), wie ein Punkt aussieht, ob roh oder rekalibriert die Hauptzahl ist, wie Berührungs-Märkte neben dem
  Fächer zu lesen sind (der Fächer nennt den Kurs AM Stichtag, ein Berührungs-Markt das Erreichen BIS zum Stichtag), und der
  Kontextstreifen (Bewertung heute, Fed-Pfad).

**Was ich beim Festlegen kannte.** Die Stände der öffentlichen Seiten vom 22.11. (Tabelle oben) und Debug 129 vom 18.11. (Zahl der
Märkte je Art: 12 Berührungs-Märkte bei Kalshi, 989 bei Polymarket). Keinen Kurs und keinen Markt aus `prognosemarkt.db` des Pi
für die Jahres- und Fristen-Leitern. Die Regeln sind an einer erzeugten Datenbank entstanden; Kennungen und Felder der Reihe
`KXBTCPRICE` und des Ereignisses bei Polymarket habe ich in keiner echten Antwort gesehen — PM1 ist deshalb so gebaut, dass es mit
und ohne Schwelle in den Feldern und mit gemeinsamem wie mit eigenem Handelsschluss je Markt stimmt, und PM8 zeigt je Ereignis ein
Beispiel.

### 9.5 Prognosemärkte im Chart, Schritt 2b: Punkte, Fed-Marken, Bericht (festgelegt 23.11.2026, 05:16 — nach dem ersten Bericht vom Pi, vor dem Bau von 23.121)

**Anlass.** Schritt 2a (9.4) hat gemessen; der erste Debug 159 vom Pi lief am 23.11.2026 um 04:51 (23.120, Laufzeit 0,5 s). Danach
habe ich dem Nutzer drei Fragen mit je drei Antworten zum Anklicken vorgelegt, jeweils mit Vorschlag und Folgen. Seine Antworten
(23.11.2026, zwischen 04:53 und 05:10 Uhr):

1. *Was zeigt der Chart?* — **„Nur lange Märkte“**: ab 90 Tagen Frist, je Niveau eine gepunktete Linie mit Prozentmarken an den
   Fristen; das Jahresende 2026 steht nur im Text. (Abgelehnt: alles ab 28 Tagen; noch nichts zeichnen.)
2. *Welche Zahl steht am Punkt?* — **„Roh“**: der Marktpreis; der rekalibrierte Wert steht im Fadenkreuz und im Bericht.
   (Abgelehnt: rekalibriert; beide.)
3. *Fed-Pfad im Chart?* — **„Nur enge Sitzungen“**: eine Marke mit Richtung an der Zeitachse nur, wenn der Markt eng ist; die Zahl
   im Fadenkreuz und als Satz; spätere Sitzungen bleiben neutrale Striche. (Abgelehnt: nur Text; nicht im Chart.)

**Was ich beim Festlegen kannte** (alles aus dem Bericht vom 23.11., 04:51; Kurs 61.154 USD):

- Beide neuen Reihen sind gesammelt, Niveau und Frist stimmen mit Titel und Regel der Börse: Kalshi `KXBTCPRICE-130000` mit acht
  Fristen (24.12.2026 bis 08.07.2027, je 10:00 Uhr New York; roh 1,0 · 1,5 · 1,5 · 2,5 · 4,5 · 7,5 · 9,5 · 16,5 %), Polymarket
  `when-will-bitcoin-hit-100k` mit fünf Fristen (31.12.2026 bis 31.12.2027; roh 1,7 · 12,0 · 24,0 · 32,5 · 45,0 %).
- Jahresende 2026 (Kalshi `KXBTCY`, 28 Spannen, Summe der Kurse 0,98): Ränder roh 46.800 · 55.681 · 62.582 · 69.027 · 76.472. Der
  Fächer am selben Tag (Stichtag 21.11.): 51.696 · 55.665 · 62.384 · 68.510 · 76.924; Optionen am 25.12.: 48.385 bis 71.820.
- Aus dem Fächer überschlagen (PM14) liegt der Kurs am Tag der Frist mit unter 10 % (31.03.2027), 22 % (30.06.), 32 % (30.09.) und
  37 % (31.12.2027) über 100.000 — die Kurse des Markts (Berührung) liegen damit am unteren Ende der Spanne aus PM14.
- **Fed:** Die Zins-Leitern `KXFED` haben im Dezember, Januar, März und April einen mittleren Spread von 1,0 · 3,2 · 4,6 · 6,9
  Punkten, ab Juni 2027 von 36 bis 55 Punkten; dort stammten die Zahlen aus dem letzten Handel und ergaben einen sprunghaften Pfad
  (Mittel 4,01 · 3,85 · 3,92 · 4,11 · 4,61 · 3,58 %). Die Märkte zum Entscheid je Sitzung (`KXFEDDECISION`) summieren sich je
  Sitzung auf 0,895 bis 1,065; wie eng ihre Kurse sind, zeigt der Bericht nicht.
- In den Leitern von Polymarket stehen viele entschiedene Märkte (25 von 48 im November-Ereignis): Nach einer Entscheidung legt
  die Börse am selben Niveau einen neuen Markt an.
- **Ich kenne damit das Bild, das PM11 heute ergibt:** die Linie 100.000 mit vier Punkten (12 · 24 · 33 · 45 %) und die Linie
  130.000 mit vier Punkten (4,5 · 7,5 · 9,5 · 17 %), sofern die Kurse eng sind. Welche Sitzungen der Fed nach PM15 als eng gelten,
  weiß ich nicht.

**Geändert gegenüber 9.4 (nach dem Bericht, mit Grund)**

- **PM3, PM6, PM7:** Der letzte Handel geht in keine Rechnung mehr ein — er hat kein Alter, und bei weitem Spread kann er Wochen
  alt sein (Zins-Leitern ab Juni 2027). In den Zeilen des Berichts steht er weiter, als „Handel“ gekennzeichnet. Verteilungen
  (Spannen, Zins-Leiter) rechnen nur mit engen Kursen (PM10); eine Spanne oder Schwelle ohne engen Kurs gilt als fehlend.
- **PM3:** Ein Geldkurs von 0 (kein Gebot) bei einem Briefkurs bis 4 Punkte gilt als enger Kurs (bisher: letzter Handel). Betroffen
  sind Märkte mit sehr kleiner Wahrscheinlichkeit (im Bericht: 130.000 bis 24.12.2026 mit 0,0 · 1,0).

**Regeln (PM10 bis PM20)**

- **PM10 Enger Kurs.** Ein Kurs ist eng, wenn Geld- und Briefkurs gespeichert sind, der Briefkurs über 0 und unter 100 % liegt und
  Brief minus Geld höchstens 4 Punkte beträgt; ein Geldkurs von 0 zählt als 0. Sein Wert ist die Mitte. Punkte, Verteilungen und
  Fed-Marken rechnen nur mit frischen engen Kursen (frisch wie PM3: letzter Abruf höchstens 3 Stunden alt, Markt nicht
  entschieden).
- **PM11 Welche Märkte ein Punkt werden.** Ein BTC-Markt der Reihen aus PM2 mit der Art Berührung oder Schwelle wird gezeichnet,
  wenn (a) sein Niveau bekannt ist und er nicht entschieden ist, (b) seine Frist mindestens 90 und höchstens 730 Tage nach dem
  Stichtag des Fächers liegt — gezählt in Kalendertagen vom Stichtag bis zum letzten Tag der Frist in New York —, (c) er einen
  frischen engen Kurs hat und (d) dieser mindestens 3 % und höchstens 97 % beträgt. *Doppelte:* Haben zwei solche Märkte denselben
  letzten Tag, dieselbe Art und Richtung und Niveaus, die höchstens 0,5 % auseinanderliegen, bleibt der mit dem engeren Spread;
  bei gleichem Spread Kalshi vor Polymarket, dann die kleinere Kennung. *Obergrenze:* je letztem Tag höchstens 6 Punkte nach oben
  und 6 nach unten — die, deren Kurs 50 % am nächsten liegt (bei Gleichstand die kleinere Kennung). Vor 90 Tagen stehen der
  Ausblick und die Optionen; dort kommt kein Punkt dazu.
- **PM12 Wie ein Punkt aussieht.** Eine Raute am Ort (letzter Tag der Frist, Niveau) in der neutralen Farbe der Markt-Schicht (wie
  die Zeichen der Optionen; keine neue Farbe). Punkte desselben Ereignisses mit derselben Richtung am selben Niveau verbindet eine
  gepunktete waagrechte Linie (Fristen-Leiter). Am Punkt steht die rohe Wahrscheinlichkeit — unter 10 % mit einer Nachkommastelle,
  sonst in ganzen Prozent, kaufmännisch gerundet —, soweit Platz ist: Die Seite beschriftet je Linie zuerst den spätesten Punkt
  und lässt eine Zahl weg, die näher als 30 px (waagrecht) und 12 px (senkrecht) an einer schon gesetzten läge. Jeder Punkt steht
  im Fadenkreuz mit Börse, Niveau, Frist, rohem und rekalibriertem Wert. Die Legende führt „Prognosemärkte“, schaltbar wie
  „Optionen“; ausgeblendet zählen die Punkte nicht für die Achse.
- **PM13 Kurs am Stichtag aus Spannen.** Eine Verteilung gibt es nur, wenn (a) mindestens 5 Spannen einen frischen engen Kurs
  haben, (b) zwischen der untersten und der obersten Spanne mit Kurs keine ohne Kurs liegt und (c) die Summe der Kurse zwischen
  0,90 und 1,10 liegt. Dann wie PM6: auf Summe 1 gebracht, Ränder gerade zwischen den Grenzen. Liegt die Frist mindestens 90 Tage
  nach dem Stichtag, wird sie als Zeichen wie bei den Optionen gezeichnet (Strich 10 bis 90 %, Balken 25 bis 75 %, Punkt Mitte;
  roh) — das ist dieselbe Größe wie der Fächer, der Kurs AM Tag. Das Ereignis mit der nächsten Frist darunter steht als Satz unter
  dem Chart, mit den Rändern des Fächers am selben Tag.
- **PM14 Überschlag gegen den Fächer (nur Text).** Für einen Berührungs-Punkt über dem Kurs des Stichtags: p = Anteil des Fächers
  über dem Niveau am letzten Tag der Frist — zwischen zwei Rändern gerade in ln des Niveaus; über dem 90-%-Rand „unter 10 %“,
  unter dem 10-%-Rand „über 90 %“. Erreicht wird ein Niveau mindestens so oft, wie der Kurs am Ende darüber liegt, und — bei einem
  Pfad ohne Drift vom Niveau weg — höchstens doppelt so oft (Spiegelungsprinzip). Der Text nennt die Spanne p bis 2·p (höchstens
  100 %); liegt das Niveau über dem 90-%-Rand, nur „höchstens 20 %“. Für Niveaus unter dem Kurs nennt er nur den Anteil darunter
  als untere Grenze. Der Fächer ist kein Pfadmodell; die Spanne ist eine Lesehilfe und geht in nichts ein.
- **PM15 Fed-Marken.** Quelle ist die Kalshi-Reihe `KXFEDDECISION` (je Sitzung ein Ereignis, je Ausgang ein Markt), nicht die
  Zins-Leiter. Der Ausgang eines Markts steht in seinem Titel („Hike rates by 25bps“ = hoch 25; „Hike rates by 0bps“ = gleich;
  „Cut rates by 25bps“ = runter 25; mit „>“ oder „more than“ vor der Zahl = über 25); ist der Titel nicht lesbar, im Ende der
  Kennung (`H0`, `H25`, `C25`; `H26` und `C26` = über 25); widersprechen sich beide oder ist keines lesbar, ist der Ausgang
  unbekannt. Eine Sitzung ist **eng**, wenn (a) die Ausgänge gleich, hoch 25 und runter 25 vorhanden sind und keiner unbekannt
  ist, (b) JEDER Ausgang einen frischen engen Kurs hat und (c) die Summe der Kurse zwischen 0,90 und 1,10 liegt. Dann werden die
  Kurse auf Summe 1 gebracht und zu drei Anteilen zusammengefasst: hoch, gleich, runter. Die Marke zeigt die Richtung des Anteils,
  der mindestens 60 % hat; hat keiner 60 %, heißt die Marke „offen“. Erwartete Änderung = Summe aus Anteil mal Schritt (25: 0,25
  Punkte; über 25: 0,50 Punkte — eine Annahme, die Börse nennt dort keinen Betrag). Die Marke steht am Fed-Termin der Zeitachse,
  wenn der Handelsschluss des Ereignisses auf denselben Tag (New York) oder den Tag davor fällt. Sitzungen, die nicht eng sind,
  behalten ihren neutralen Strich. Im Fadenkreuz stehen am Termin die drei Anteile und die erwartete Änderung.
- **PM16 Sätze unter dem Chart.** (a) Die Punkte je Linie in Worten („100.000 USD erreicht bis 31.03.2027 mit 12 %, …“) mit dem
  Stand der Kurse und der Lesart: Die Punkte nennen, wie wahrscheinlich der Kurs das Niveau BIS zu diesem Tag einmal erreicht —
  nicht, wo er AM Tag steht; Preise von Wetten, keine Prognose; die Schicht geht nicht in den Fächer ein. (b) Der Überschlag nach
  PM14 für den spätesten Punkt jeder Linie. (c) Der Satz nach PM13. (d) Die engen Sitzungen der Fed mit Anteilen und erwarteter
  Änderung, danach die Zahl der Sitzungen mit zu weitem Markt. Gibt es keinen Punkt, nennt der Satz den Grund.
- **PM17 Bericht (Debug 159).** Entschiedene Märkte stehen je Leiter in einer Zeile (Zahl und Niveaus), nicht mehr einzeln. Jede
  Zeile sagt, ob ihr Kurs eng ist. Abschnitt 4 und 5 rechnen nach PM10 und PM13; Abschnitt 5 führt je Sitzung den Entscheid nach
  PM15 mit dem Grund, wenn sie nicht eng ist. Neuer Abschnitt 7 „Für den Chart“: die Punkte nach PM11, die Zahl der nicht
  gezeichneten Märkte je Grund, das Zeichen oder der Satz nach PM13, die Marken nach PM15. Der Bericht kennt den Fächer nicht (er
  öffnet `makro.db` nicht); als Stichtag nimmt er den Vortag (UTC), wie der Chart bei aktuellen Daten.
- **PM18 Text des Charts (Debug 156).** Neuer Abschnitt 9: dieselben Punkte wie die Seite, je Punkt roh, rekalibriert und der
  Überschlag nach PM14, die Sätze und die Fed-Marken. Debug 156 und die Seite lesen dieselbe Antwort.
- **PM19 Fehler.** Fehlt `prognosemarkt.db`, ist sie nicht lesbar oder scheitert die Rechnung dieser Schicht, bleibt der Chart
  ohne Punkte und ohne Fed-Marken; der Satz nennt den Grund. Diese Schicht darf weder den Chart noch Debug 156 kosten. Sie liest
  nur, speichert nichts und geht in keine Rechnung des Fächers ein.
- **PM20 Was fehlt.** Die Zonenkarte (Bewertung heute) bleibt im Reiter „Überblick“ — sie ist kein Teil von 23.121. Eine Bilanz
  der Punkte (ob die Märkte recht behielten) gibt es nicht; dafür reichen die Fristen nicht. Die Schwellen 90 Tage, 3 %, 60 % und
  die Obergrenze von 6 sind Setzungen für die Lesbarkeit, keine geprüften Größen. Sobald die Börsen Jahresmärkte für 2027 listen,
  zeigt der erste Bericht, ob PM11 dafür taugt.

**Erwartung vorab** (damit nichts überrascht): Auf dem Pi stehen nach dem Einspielen zwei gepunktete Linien — 100.000 mit vier
Punkten und 130.000 mit vier Punkten —, kein Zeichen aus Spannen (das Jahresende liegt unter 90 Tagen; dafür ein Satz) und
Fed-Marken an den nächsten Sitzungen, falls ihre Märkte eng sind. Kommt es anders, steht der Grund in Abschnitt 7 von Debug 159.

**Präzisierungen beim Bau (23.11.2026, 06:55 — nach dem Festlegen von 05:16, vor der Lieferung).** Beim Bauen und Prüfen
brauchten sieben Stellen eine genauere Fassung. Keine Schwelle aus PM10 bis PM15 ist dabei geändert; kein Bericht vom Pi ist seit
dem Festlegen dazugekommen. Sie stehen hier, damit Konzept und Code dasselbe sagen:

1. *Zeichen aus Spannen (PM13).* Ein Zeichen gibt es nur, wenn die Frist höchstens 730 Tage nach dem Stichtag liegt (wie PM11)
   und die Verteilung die Mitte und die Ränder 25 und 75 % hat. Liegt einer davon in einer nach außen offenen Spanne, gibt es kein
   Zeichen; der Bericht nennt den Grund. Fehlt nur der 10- oder der 90-%-Rand, endet der Strich am Balken, und das Fadenkreuz
   nennt den Rand „außerhalb“. Die Mitte ist eine Raute wie die Punkte, kein Kreis.
2. *Doppelter Ausgang (PM15).* Steht ein Ausgang in einer Sitzung zweimal, ist die Sitzung nicht eng.
3. *Schalter (PM12, PM15).* „Prognosemärkte“ in der Legende blendet auch die Zeichen der Fed und ihre Zeilen im Fadenkreuz aus;
   die neutralen Striche der Termine bleiben.
4. *Schwellen-Punkt (PM14).* Bei einem Punkt der Art Schwelle (Schluss über oder unter dem Niveau AM Tag) ist der Anteil des
   Fächers dieselbe Größe wie der Kurs des Markts. Der Text nennt diesen Anteil selbst, ohne die Spanne p bis 2·p.
5. *Lücken der Zins-Leiter (PM7).* Der Bericht nennt, wie viel Wahrscheinlichkeit in Lücken der Leiter liegt (zwischen zwei
   Schwellen mit Kurs fehlt eine); ab 5 % steht dazu ein Hinweis in Abschnitt 6.
6. *Fadenkreuz (PM12, PM15).* Der Fangbereich richtet sich auch nach der Breite des Bilds: mindestens 5 px um Rauten und
   Zeichen, mindestens 4 px um einen Fed-Termin; liegen mehrere Termine im Bereich, gilt der nächste. Auf dem Handy sind zwei
   Tage ein halbes Pixel — mit einer Schwelle nur in Tagen waren die Zeilen dort nicht zu treffen (bei der Probe im Browser
   gefunden, vor der Lieferung behoben). Der Zeiger wird dafür an der Trefferfläche des Bilds gemessen: Das Bild hat einen Rahmen
   von 1 px, und bis 23.120 stand das Fadenkreuz in allen Reitern des Makro-Charts 1 px rechts vom Zeiger (nachgetragen um 07:45,
   nach dem Fund mit der Klickprobe).
7. *Meldungen.* Summen stehen in Meldungen mit drei Nachkommastellen („0,899“), damit eine Summe knapp unter der Grenze nicht
   als „0,90“ dasteht.

## 10. Chart und Vorwärtsbilanz (Stufe 1, Eckpunkte)

- **Ort:** Reiter „24 Monate“ im Makro-Chart; logarithmische Skala; von heute bis heute + 730 Tage.
- **Fächer:** Bänder 50 % und 80 % des Hauptfächers; Stützstellen bei 90, 180, 365, 548 und 730 Tagen, dazwischen gerade
  verbunden; bei 0 Tagen der Kurs.
- **Linien:** Mitte von A, Mitte von B, Fair Value. Dünn: die früheren Zyklen aus 4.3 (je Halving eine), ohne Wahrscheinlichkeit.
- **Die ersten vier Wochen:** das Band des Ausblicks (U146) als eigener, beschrifteter Anschluss.
- **Markt-Schicht (Stufe 2):** Punkte je Verfalltag aus Optionen; Schwellen der Prognosemärkte bis Ende 2027 mit Roh- und
  rekalibriertem Wert (`KONZEPT_Prognosemaerkte.md`, Regel 1.6).
- **Zeitachse:** Halving (Spanne der Schätzung 12. bis 21.04.2028), FOMC, Preis- und Arbeitsmarkttermine, US-Wahl 07.11.2028.
  **Kontextstreifen:** Zonenkarte, Fed-Pfad.
- **Beschriftung:** Kopfzeile „Szenarien, keine geprüfte Prognose“. Unter dem Chart die Rückblick-Zeile aus Debug 153 („80-%-Band
  hielt in x von y Fenstern“), Regelversion und Datenstand. Keine Kauf- oder Verkaufswörter.
- **Gleiche Rechnung:** Der Chart ruft dieselbe Funktion wie die Vorprüfung, mit heute als Ursprung.
- **Vorwärtsbilanz:** Am Ersten jedes Monats wird die Fassung unveränderlich gespeichert (Quantile je Horizont, Mitten,
  Regelversion, Datenstand). Zwischenbilanz nach 3, 6 und 12 Monaten, nur aus gespeicherten Fassungen.
- **Zurückgestellt:** die zweite Trendform mit Deckel (BEWERTUNG, Abschnitt 5). Eine weitere Linie ohne Rückrechnung widerspräche
  „erst Vorprüfung“; die Unsicherheit über die Trendform tragen schon Sicht A und die Fehlerbreite von B.

## 10a. Der Chart, wie er gebaut ist (Paket 23.116) — und die Regeln der Vorwärtsbilanz

Festgelegt am 21.11.2026, nach dem Urteil der Vorprüfung und bevor eine Monatsfassung gespeichert ist. Abschnitt 10 bleibt der
Auftrag; hier steht, was daraus gebaut ist, was fehlt und wie gezählt wird.

**Rechnung und Ort**

- Reiter „24 Monate“ im Makro-Chart (`/makro?tab=langfrist`) und Debug 156 lesen dieselbe Antwort (`hl_langfrist.chart_stand`).
  Stichtag ist der letzte Kurstag (Tagesschluss UTC, Coin Metrics), nicht der laufende Kurs.
- Gezeigt wird der Hauptfächer des abgelegten Urteils, gerechnet von `Lauf.fan` — der Funktion, deren Ränder die Vorprüfung
  wertet (Probe P9; Probe C2 vergleicht den Chart mit dem Weg von Debug 153). Ohne abgelegtes Urteil „bauen“ der geltenden
  Regelversion gibt es keinen Chart, nur den Grund.
- Zwischen den Stützstellen (0, 90, 180, 365, 548 und 730 Tage) sind die Ränder in ln gerade verbunden — je Tag ein Wert für
  Fadenkreuz und Tabelle. Das ist die Verbindung aus Abschnitt 10, keine eigene Rechnung für die Tage dazwischen.

**Linien (zum Vergleich, ohne Wahrscheinlichkeit)**

- Mitte von A (der Kurs bleibt) und Mitte von B, verbunden wie die Ränder.
- Fair Value mit den Power-Law-Parametern des Stichtags — auch links vom Stichtag. Damals galten andere Parameter (Reiter
  „Trend“: Exponent über die Zeit).
- Frühere Zyklen: je früherem Halving ein Pfad nach der Formel aus 4.3, ein Wert je Woche und an den fünf Horizonten. An den
  Horizonten ist das Mittel der Pfade (in ln) der Rohwert von Sicht C (Probe C3). Der Fächer mit Zyklus hat H nicht abgelöst;
  die Linien sind ein Vergleich.

**Die ersten vier Wochen**

- Die jüngste Rechnung des Ausblicks (U146) für BTC: Ränder 10, 25, 50, 75 und 90 % nach 7, 14 und 28 Tagen ab ihrem Anker.
  Gezeigt wird das 80-%-Band. Liegt der Anker mehr als 3 Tage vor dem Stichtag, wird nichts gezeigt. Der Ausblick geht nicht in
  den Fächer ein; er beginnt beim laufenden Kurs, der Fächer beim letzten Tagesschluss.

**Zeitachse**

- **Halving:** Spanne aus der Blockzählung des Pi (`cm:btc:BlkCnt`): Blöcke seit dem Tag des letzten Halvings, Rest bis 210.000,
  geteilt durch 144 je Tag und durch das Mittel der letzten 365 Tage. Gegenprobe vorab: Dieselbe Zählung, am vorletzten Halving
  begonnen, muss das letzte auf 2 Tage treffen; sonst — oder wenn die Zählung seit dem vorletzten Halving nicht genau einen
  Wert je Tag trägt (Lücke, doppelter Tag, später Beginn) — gilt der Kalenderwert (letztes Halving plus 210.000
  Blöcke zu 144 je Tag: 17.04.2028). Die Uhrzeit des Halvings am Tag selbst kennt die Zählung nicht; sie irrt um bis zu einen
  Tag. Die Spanne „12. bis 21.04.2028“ in Abschnitt 10 stammt aus zwei Rechnern im Netz (CoinGecko, CoinWarz; BEWERTUNG 2.2,
  Stand 19.11.); der Chart rechnet seine eigene aus den Daten des Pi.
- **US-Wahl** 07.11.2028. **Fed-Entscheide** als kleine Striche aus der Liste in `hl_volatil.py` (bekannt bis 08.12.2027, das
  Jahr 2027 laut Fed vorläufig). **Verbraucherpreise und Arbeitsmarktbericht:** nur der jeweils nächste Termin, als Text
  (`mk_termin`); Marken auf der Achse gibt es für sie nicht — über 24 Monate sind nur wenige Monate bekannt.

**Beschriftung und Farben**

- Kopfzeile „Szenarien, keine geprüfte Prognose“; darunter die Rückblick-Zeile aus dem abgelegten Urteil (Fenster ohne
  Überlappung je Horizont), Regelversion, Datenstand. Keine Kauf- oder Verkaufswörter (Probe C9). Der Kopf sagt, was der
  Rückblick prüft: wie oft das 80-%-Band hielt — nicht, ob die Mitte die Richtung trifft. (Die Mitte des Hauptfächers H liegt
  zwischen „Kurs bleibt“ und „Trend“; sie steigt also mit dem Trend. Ein erster Wortlaut, „eine Richtung sagt der Fächer nicht
  voraus“, war deshalb falsch und ist vor der Lieferung ersetzt.)
- Drei Farbtöne, die sich auch paarweise alle unterscheiden lassen (Prüfskript für die dunkle Chartfläche): Fächer blau, Power
  Law grün (Fair Value durchgezogen, Mitte von B gestrichelt), frühere Zyklen gelbbraun mit drei Stricharten; Kurs, „Kurs
  bleibt“ und das Band des Ausblicks neutral. Eine Achse, logarithmisch.

**Nicht gebaut in 23.116**

- Markt-Schicht (Stufe 2, U280) und **Kontextstreifen** (Zonenkarte, Fed-Pfad): Der Fed-Pfad kommt wie die Markt-Schicht aus
  `prognosemarkt.db` und gehört zu Stufe 2; die Zonenkarte steht bis dahin im Reiter „Überblick“.
- Die zweite Trendform bleibt zurückgestellt (Abschnitt 10).

**Vorwärtsbilanz — Regeln V1 bis V7 (vorab)**

- **V1 Start.** Der erste Lauf des Makro-Takts oder von Debug 156 unter 23.116 hält den Starttag fest (`makro.db`, `mk_meta`,
  Schlüssel `langfrist:fassung_start`). Für Monatserste bis einschließlich Starttag gibt es keine Fassung — rückwirkend wird
  nichts erzeugt.
- **V2 Fassung.** Für jeden Monatsersten nach dem Starttag wird genau eine Fassung gespeichert (Tabelle `lf_fassung`, Schlüssel
  ist der Monat). Stichtag ist der Monatserste (Tagesschluss UTC); gerechnet wird mit `Lauf.fan` am Stichtag, also nur mit Daten
  bis zu diesem Tag. Inhalt: je Horizont die fünf Ränder des Hauptfächers und die Mitten von A und B, dazu Kurs, Schwankung,
  Art des Bands, Hauptfächer, Regelversion, Modulversion, Prüfsumme der Kursreihe bis zum Stichtag und der Zeitpunkt des
  Speicherns.
- **V3 Zeitpunkt.** Gespeichert wird, sobald der Kurs des Monatsersten da ist — in der Regel am Zweiten. War der Pi aus, wird
  nachgeholt: mit denselben Daten bis zum Stichtag (Probe C7: gleich der Rechnung auf der am Stichtag abgeschnittenen Reihe);
  das Speicherdatum zeigt die Verspätung. Fehlt der Kurs des Monatsersten, gibt es für den Monat keine Fassung, bis er da ist.
- **V4 Unveränderlich.** Eine gespeicherte Fassung wird nie geändert oder gelöscht — auch nicht nach korrigierter Historie oder
  mit einer neuen Modulversion. Kommt eine neue Regelversion, tragen spätere Fassungen sie; gezählt werden dann nur die
  Fassungen der geltenden Regelversion, die älteren bleiben stehen und werden als Zahl genannt.
- **V5 Zwischenbilanz.** Je gespeicherter Fassung und Horizont, sobald der Zieltag (Stichtag plus 90, 180, 365, 548 oder 730
  Tage) einen Kurs hat: Lag der Tagesschluss im 80-%-Band (10- bis 90-%-Rand, die Ränder zählen dazu — wie in der Vorprüfung)
  und im 50-%-Band? Gezählt wird je Horizont „x von y“. Hat der Zieltag keinen Kurs, wird der Fall nicht gewertet; es gibt
  keinen Ersatztag. Abschnitt 10 nennt 3, 6 und 12 Monate; 18 und 24 Monate zählen mit, sobald sie fällig sind.
- **V6 Lesart.** Die Fassungen überlappen sich (monatlich, Horizonte bis 24 Monate): Die Zählung beschreibt, sie ist kein
  Test. Der erste Fall wird am 01.03.2027 fällig (Fassung vom 01.12.2026, 90 Tage). **Eine Regel, wann die Vorwärtsbilanz den
  Fächer infrage stellt, gibt es noch nicht; sie wird festgelegt, bevor der erste Fall fällig ist (U295).**
- **V7 Keine Rückwirkung.** Die Bilanz ändert nichts am Fächer und nichts an den Regeln (7.6).

**Nachtrag 22.11.2026 (Paket 23.119, U303) — die Verbindung bis zur ersten Stützstelle.** Bis 23.118 waren die Ränder auch zwischen
dem Kurs (0 Tage) und der ersten Stützstelle (90 Tage) in ln gerade verbunden. Unsicherheit wächst aber nicht gleichmäßig mit der
Zeit, sondern am Anfang schnell (Sicht A: Breite mal √Tage, 4.1). Die gerade Verbindung zeichnete den Fächer dort zu schmal: Am
25.12.2026 (34 Tage nach dem Stichtag) zeigte er 55.772 bis 69.860 USD; das Band des Ausblicks reichte nach 28 Tagen von 48.603
bis 72.952, die Ränder der Optionen (33 Tage) von 46.621 bis 70.634. Die Abweichung zum Band des Ausblicks war seit 23.116 im Chart
zu sehen; als Fehler der Verbindung erkannt habe ich sie erst am 22.11., als die Zeichen der Optionen dazukamen (Debug 156,
Abschnitt 8). **Entscheidung des Nutzers vom 22.11.2026 (Auswahl „Wurzel-Verlauf“; die anderen Wege waren: so lassen mit Hinweis,
oder den Fächer erst ab 90 Tagen zeichnen):** Bis zur ersten Stützstelle läuft die Mitte des Fächers wie bisher gerade (in ln) vom
Kurs zur Mitte bei 90 Tagen; der Abstand jedes Rands zur Mitte (in ln) ist sein Abstand bei 90 Tagen mal √(Tage ÷ 90). Ab 90 Tagen
bleibt die gerade Verbindung. Die Linien „Kurs bleibt“ und „Trend“ sind Mitten ohne Breite und bleiben gerade. Das ändert die
Darstellung nach dem Blick auf den Chart — keine Zahl der Vorprüfung, keine Stützstelle, keine Monatsfassung und nicht die
Regelversion (7.6 gilt den Regeln der Abschnitte 3 bis 8). Zwischen 0 und 90 Tagen bleibt der Fächer eine Verbindung, keine
geprüfte Aussage; die ersten vier Wochen zeigt das Band des Ausblicks. Am 25.12.2026 ergibt die neue Verbindung 52.171 bis 75.259 USD.

## 11. Proben und Mutationen (Selbsttest ohne Netz)

| Probe | prüft | Mutation, die sie fangen muss |
|---|---|---|
| P1 Kausalität | Vorhersage am Ursprung aus der vollen Reihe = Vorhersage aus der am Ursprung abgeschnittenen Reihe, für alle Sichten | Median über 30 Tage nach dem Ursprung; Fehlergedächtnis mit noch unbekannten Zielen |
| P2 Gleichheit mit U126 | 90, 180 und 365 Tage: Zahl der Fälle und Ränder wie `pruefung`; heutiges Band wie `prognose` | Raster 31 statt 30 Tage |
| P3 CRPS | gleiche Gewichte gegen `crps_ens`; ungleiche gegen die Doppelsumme; Normalverteilung gegen die geschlossene Formel (Toleranz 1 %) | Vorzeichen; falsches Gewicht |
| P4 Mischung | C gleich B ergibt Z gleich H (CRPS genau, Quantile auf 0,005 in ln); Gewicht 1 ergibt die Einzelsicht; Quantile steigen | A einfach statt doppelt gewichtet |
| P5 Vorzeichenwechsel-Test | neun gleiche Vorzeichen: 1 ÷ 512; ein kleiner Gegenwert: 2 ÷ 512; ein großer: kein Nachweis; Gleichstände zählen nicht | Gleichstand als Sieg; zweiseitig statt einseitig |
| P6 Regel B3 | gebaute Fehler mit schrumpfender Spanne werden gestreckt | Regel entfernt |
| P7 Deckung | bekannte Verteilung: 80 % innerhalb der Toleranz; Ränder 10 und 90, nicht 25 und 75 | falsches Quantil |
| P8 Welten (klein) | Abschnitt 8 mit je fünf Welten: Welt 1 löst nicht ab, Zyklus 3 σ löst ab | Gewichte von G vertauscht; Bedingung 3 entfernt |
| P9 Gleiche Rechnung | Chart-Funktion = Rückrechnung für denselben Tag | eigener Rechenweg im Chart |

P1 bis P3 liefen am Prototyp schon, P4 und P5 in Teilen (Abschnitt 8). Dazu wie üblich: Update-Probe, Eintrag im BERICHTSPLAN
(`nach_update`), Browserprobe für den Chart in Stufe 1.

## 12. Erwartung vorab (damit nichts überrascht)

- **A:** Das Band wird zu oft nach oben verlassen (der Anstieg der Vergangenheit); Deckung bei 730 Tagen unter 80 %.
- **B:** bei 365 Tagen nahe dem, was Debug 52 zeigt (83 %); bei 548 und 730 Tagen deutlich darunter — das war schon in der Welt
  so, in der B das wahre Modell ist (54 %), und ist kein Fehler der Rechnung. Die Mitte von B liegt heute vermutlich unter dem
  Überschlag — bei 12 Monaten eher um 100.000 als bei 118.000 USD —, weil die Fehler der letzten vier Jahre überwiegend nach unten
  zeigten (geometrische Mitte des Bands aus Debug 52: 100.069).
- **H:** Deckung im Soll oder darüber. Breiter als der Überschlag (Faktor 11) ist möglich.
- **CRPS:** A vorn bei 90 Tagen, B ab 365 Tagen — wie in der Literatur. Gesichert ist das nicht.
- **G** wandert zu B; ob es 7.1 besteht, ist offen. **W** besteht vermutlich nicht.
- **Z** ist offen. In der schrumpfenden Welt besteht Z in einem von fünf Fällen. Besteht Z, verschiebt sich der Fächer vermutlich
  nach oben: In früheren Zyklen stand der Kurs zwei Jahre nach diesem Zyklustag (944 Tage nach dem Halving) weit über dem Trend
  — aus dem Gedächtnis, nicht gerechnet.
- **Alarm 7.2:** nicht erwartet; wenn doch, dann bei 730 Tagen.

## 13. Stufen, Pakete, Nummern

| Stufe | Inhalt | Plan | Debug | Paket (geplant) |
|---|---|---|---|---|
| — | offene Fehler: U276, U275, U272 Teil 2, Wortlaut U246 | — | — | 23.113, nach der Messung vom 20.11. gegen 06:13 |
| Erstlauf | Optionen: Deribit und IBIT, je ein Abruf | U278 | 154 | 23.113 |
| 0 | Vorprüfung (Abschnitte 3 bis 8) | U277 | 153 | 23.115 |
| 1 | Chart „24 Monate“, Text-Lauf, Monatsfassungen, Vorwärtsbilanz | U279 | 156 ★ | danach |
| 2 | Markt-Schicht: Optionen täglich, Punkte der Prognosemärkte | U280 | in 156 | danach |

**Nachtrag 20.11.2026 (Paket 23.114):** 23.114 wurde das Paket zur Stabilität (Hänger des Dashboards vom 19.11., Auftrag des Nutzers vom 20.11.). Die Vorprüfung kommt frühestens mit 23.115. Debug 155 gehört jetzt der Probe der Selbstheilung; der Text-Lauf des Charts bekommt 156. An den Regeln der Abschnitte 3 bis 8 und an der Zählweise Z1 bis Z6 ändert das nichts.

**Nachtrag 20.11.2026 (Paket 23.115):** Die Vorprüfung kommt mit 23.115 (Debug 153). Die Nummer 156 ist im Dashboard für den
Text-Lauf des Charts reserviert (Stufe 1). Debug 157 gehört der Messung der Recorder-Runden (U287) und hat mit diesem Konzept
nichts zu tun.

**Nachtrag 21.11.2026 (Paket 23.116):** Stufe 1 ist gebaut (U279): Reiter „24 Monate“, Debug 156 (`hl_langfrist.py --stand`),
Monatsfassungen in `makro.db` (Tabelle `lf_fassung`), Vorwärtsbilanz. Der Makro-Takt speichert fällige Fassungen selbst; Debug
156 tut es auch. Offen: Stufe 2 mit Markt-Schicht und Kontextstreifen (U280), die Regel zur Vorwärtsbilanz (U295, vor dem
01.03.2027), der Probe-Abruf bei Alpha Vantage (U293, zurückgestellt — Abschnitt 15).

**Nachtrag 22.11.2026 (Paket 23.118):** Stufe 2 kommt in zwei Teilen. Teil 1 ist gebaut (U280, U292): die Optionen von Deribit --
Modul `hl_marktschicht.py`, Regeln in Abschnitt 9.3, Abschnitt 8 in Debug 156, Zeichen im Chart. Teil 2 folgt: Punkte der
Prognosemärkte und Kontextstreifen. Offen dazu: die Regel für eine Bilanz der Options-Ränder (U298).

**Nachtrag 22.11.2026 (Paket 23.119):** keine neue Stufe. 23.119 ändert die Verbindung des Fächers bis 90 Tage (U303, Abschnitt 10a)
und bringt die Diagnose der Optionen-Schicht (U302: O9 und O10 in Abschnitt 9.3; neu Debug 158, der Prüflauf ohne Speichern). Teil 2
der Markt-Schicht (Punkte der Prognosemärkte, Kontextstreifen) folgt danach mit 23.120.

**Nachtrag 22.11.2026 (Paket 23.120):** Teil 2 der Markt-Schicht kommt in zwei Schritten (Abschnitt 9.4). Schritt 2a ist gebaut
(U280): zwei weitere Marktreihen werden gesammelt (PM1), und Debug 159 (`hl_marktschicht.py --prognosemarkt`) zeigt, was die
Prognosemärkte für den Chart hergeben — nur lesen, im Chart steht davon noch nichts. Schritt 2b (Punkte im Chart, Kontextstreifen)
folgt mit 23.121, nach dem ersten Bericht vom Pi.

**Nachtrag 23.11.2026 (Paket 23.121):** Schritt 2b ist gebaut (U280): Punkte der Prognosemärkte ab 90 Tagen Frist als gepunktete
Linien mit Prozentmarken, Fed-Marken für Sitzungen mit engem Markt, Sätze unter dem Chart; Debug 159 mit Abschnitt 7 „Für den
Chart“, Debug 156 mit Abschnitt 9 (Regeln PM10 bis PM20, Abschnitt 9.5). Keine neue Debug-Nummer. Die Zonenkarte bleibt im Reiter
„Überblick“.

Jedes Paket plant seine Debug-Läufe selbst (Regel seit 23.109): 23.113 den Lauf 154, das Paket der Vorprüfung die Läufe 153 und 52. Neues Modul:
`hl_langfrist.py` (die Rechnung ohne Datenbank, wie `hl_makro_signal.py`; dazu der Lauf, der `makro.db` liest und das Urteil
dort ablegt), hervorgegangen aus dem Prototyp. Last auf dem Pi:
Tageswerte, rund 180 Ursprünge. Zum Vergleich: U126 rechnet alle Paare und Zeiträume in 4,4 s (Debug 52, 18.11.). Die Laufzeit
der Vorprüfung misst der Bericht.

## 14. Grenzen und nicht Geprüftes

**Grenzen** (zusätzlich zu Abschnitt 8 der BEWERTUNG):

- Die Vorprüfung ist keine unabhängige Prüfung: Sie rechnet auf der Historie, aus der Power Law und Zyklus-These stammen.
- Bei 730 Tagen gibt es 6 Fenster ohne Überlappung. Fünf Treffer von sechs sind mit einer wahren Deckung zwischen 42 und 99 %
  vereinbar (90-%-Bereich; eigene Rechnung).
- Die erzeugten Welten sind einfach: ein AR(1), ein Sinus, in einer Welt dicke Ränder. Echte Kurse können anders irren. Die
  Kalibrierung zeigt, dass die Regeln in diesen Welten halten — nicht, dass sie auf BTC halten.
- Sicht A wird im Rückblick mit der realisierten Schwankung gerechnet; Optionen haben keine Historie auf dem Pi.
- Sicht C stützt sich auf ein bis drei frühere Zyklen.
- Ein Strukturbruch (ETF-Zeit) kann die Historie vor 2024 entwerten.
- *(21.11.2026, nach dem Urteil)* Das Band von H war im Rückblick eher zu weit: Bei 730 Tagen hielt es in 6 von 6 Fenstern
  (96 % aller Stichtage). Die mittlere Spanne lag dort im Rückblick beim Faktor 33,4, heute beim Faktor 7,5, weil die Schwankung
  der letzten vier Jahre kleiner ist. Ob das schmalere Band von heute hält, kann die Rückrechnung nicht zeigen.
- *(21.11.2026)* Sicht D rechnet am heutigen Stichtag nur aus der 200-Wochen-MA: Der MVRV-Wert von Coin Metrics endet einen Tag
  vor dem Kurs. In der Rückrechnung stand er an jedem Stichtag bereit — das begünstigt D und W im Rückblick leicht. Sie bestehen
  trotzdem nicht; H enthält D nicht.
- *(Chart, 23.116)* Die Linien der früheren Zyklen sind Wochenwerte. Der Fair Value links vom Stichtag trägt die Parameter von
  heute. Die Spanne des Halvings hängt an der Blockzählung von Coin Metrics und irrt um bis zu einen Tag. Eine nachgeholte
  Monatsfassung stimmt nur dann mit der pünktlichen überein, wenn die Historie bis zum Stichtag inzwischen nicht korrigiert
  wurde; die Prüfsumme in der Fassung hält den Stand fest.

**Nicht geprüft:**

- Ob der Pi die IBIT-Kette bei Cboe abrufen kann. Die Nutzungsbedingungen für verzögerte Kurse habe ich nicht im Wortlaut gelesen.
- Der längste Verfall bei Deribit heute (nach der Regel der Börse der vierte Quartalsverfall; ob Dezember 2027 schon gelistet
  ist, weiß ich nicht).
- Ob das Raster auf dem Pi am 20.01.2014 beginnt (hängt am ersten Tag mit Fair Value).
- Die Laufzeit der Vorprüfung auf dem Pi.
- Proben P6 bis P9 als eigene Proben (die Regeln selbst liefen in Abschnitt 8) und alle Mutationen außer den zwei zu P1 — sie
  kommen mit dem Bau. *(Erledigt mit 23.115: Die Proben P1 bis P9 und weitere stehen im Selbsttest von `hl_langfrist.py`; die
  Mutationen nennt die UEBERGABE zu 23.115.)*

- **Prognosemärkte, Schritt 2a (23.120):** Die zwei neuen Reihen (PM1) sind in keiner echten Antwort der Börsen geprüft — die
  Arbeitsumgebung erreicht sie nicht; der erste Bericht vom Pi zeigt je Ereignis ein Beispiel (PM8). Die Regeltexte der Börsen (was
  als „erreicht“ zählt, welche Kursquelle gilt) sind nicht gelesen; der Bericht zeigt ihren Anfang. Kalshi rechnet nach dem
  eigenen Index ab, Polymarket laut Seite nach Binance BTC/USDT — eine Berührung auf einer Minutenkerze ist leichter als auf einem
  Mittel über 60 Sekunden; gleiche Niveaus beider Börsen sind deshalb nicht ohne Weiteres vergleichbar. Regel 1.6 (Rekalibrierung)
  ist für 2021 bis 2025 in der Stichprobe geschätzt und im Projekt nicht geprüft; ihre Übertragung auf Spannen (PM6) ist meine.
- **Prognosemärkte, Schritt 2b (23.121):** Die Punkte sind Preise weniger Märkte — heute zwei Ereignisse; wie viel dort gehandelt
  wird, speichert das Projekt nicht (nur Geld- und Briefkurs). Ein Berührungs-Markt und der Fächer messen Verschiedenes; der
  Überschlag (PM14) unterstellt einen Pfad ohne Drift vom Niveau weg und behandelt den Fächer, als wäre er ein Pfadmodell. Die
  Fed-Marken kommen aus den Märkten zum Entscheid je Sitzung; ob dort mehr als wenige Kontrakte stehen, ist nicht geprüft. Die
  Titel der Ausgänge „über 25“ habe ich in keiner Antwort gesehen (PM15 liest dann die Kennung). Schwellen und Obergrenzen von
  PM11 bis PM15 sind Setzungen.

## 15. Ergebnis und Nachträge

- **20.11.2026, vor dem Ablegen (nur erzeugte Reihen):** Der Test in 7.1 war zuerst ein Vorzeichentest; ersetzt durch den
  Vorzeichenwechsel-Test, weil der erste einen starken Zyklus kaum erkannte (Abschnitt 8). Bedingung 3 (letzte vier Jahre)
  ergänzt. Regelversion 1 ist die hier beschriebene Fassung.
- **20.11.2026, vor dem ersten Abruf (Paket 23.113, Erstlauf U278): Zählweise zu 9.1 und 9.2.** Die Regel in 9.2 nennt die
  Schwellen, aber nicht, wie gezählt wird. Festgelegt, bevor eine Antwort der beiden Quellen gesehen wurde; `hl_optionen.py`
  zählt so:
  - **Z1** Geld- und Briefkurs: beide vorhanden, größer 0, Brief nicht unter Geld.
  - **Z2** Terminkurs: Deribit = Feld `underlying_price` (Median je Verfalltag). IBIT = Put-Call-Parität am Strike mit dem
    kleinsten Abstand zwischen Call und Put (Mittelkurse): Terminkurs = Strike + Call − Put. Das ist eine Näherung (amerikanische
    Optionen, ohne Zins). Gibt es kein solches Paar, gilt der Kassakurs.
  - **Z3** Seiten: Unter dem Terminkurs zählen die Puts, darüber die Calls (aus dem Geld; aus ihnen kämen die Quantile). Ein
    Strike genau am Terminkurs zählt für keine Seite.
  - **Z4** Am Geld: der Strike nächst dem Terminkurs, an dem Call und Put gelistet sind (bei Gleichstand der niedrigere). Spanne
    am Geld = Spanne des Paars Call + Put: (Brief Call + Brief Put − Geld Call − Geld Put) ÷ Mitte des Paars. Fehlt ein Kurs, gibt
    es keine Spanne, und der Verfalltag ist nicht brauchbar.
  - **Z5** Tage bis zum Verfall: Deribit 08:00 UTC, IBIT 16:00 New York. 12 Monate = 365 Tage, 18 Monate = 548 Tage.
  - **Z6** Die Bedingung für IBIT wird nur in der US-Handelszeit gewertet: an Handelstagen 9:45 bis 16:15 New York (die Kurse
    sind 15 Minuten verzögert). Außerhalb heißt es „kein Urteil“. Es zählt der erste Lauf in der Handelszeit; spätere ändern das
    Urteil nicht. Frühe Handelsschlüsse kennt der Lauf nicht.

  Dazu: Cboe selbst dokumentiert das Format der Antwort nicht. Drei unabhängige Beschreibungen (Quellen, gelesen am 20.11.2026)
  nennen denselben Aufbau: eine Liste `data.options`, je Kontrakt `option` (OCC-Kennung), `bid`, `ask`, `iv`, `open_interest`,
  dazu `data.current_price`; eine nennt eine Weiterleitung (HTTP 307) vor der Antwort. Der Lauf verlässt sich nicht darauf: Er
  erkennt die Kontrakte an ihren OCC-Kennungen und meldet sonst den Aufbau der Antwort. Aus der Arbeitsumgebung war die Adresse
  nicht abrufbar. Angepasste Kontrakte (andere Wurzel als IBIT) werden gezählt, aber nicht gewertet. Der zweite Cboe-Host wird
  nur gefragt, wenn der erste nicht liefert; ob er diesen Pfad kennt, ist ungeprüft. Die Felder der Deribit-Antwort stehen in
  der Dokumentation der Börse (Quellen).
- **20.11.2026, 22:10 — Ergebnis des Erstlaufs der Optionen (Debug 154; zwei Läufe auf dem Pi, 12:52 und 20:30).**
  - **Deribit:** beide Läufe HTTP 200; 12 Verfalltage, der längste am 24.09.2027 (307 Tage); nach Regel 9.2 in beiden Läufen
    12 von 12 brauchbar für Quantile. Mittags 950 Kontrakte, 96 % mit Geld- und Briefkurs, Spanne am Geld 8,9 bis 1,2 %. Abends
    (BTC rund 6 % tiefer) 996 Kontrakte, 48 % mit beiden Kursen, Spanne am Geld 12,2 bis 2,2 %.
  - **IBIT (Cboe):** beide Läufe HTTP 403 mit einer HTML-Seite, auf beiden Hosts. Der Lauf von 20:30 lag in der US-Handelszeit
    (Freitag, 14:30 New York) und zählt nach Z6. **IBIT ist auf diesem Weg nicht nutzbar; die Bedingung aus 9.2 ist nicht
    erfüllt, es bleibt bei Deribit.** Die Sperre wird nicht umgangen. Zu den Bedingungen der Cboe-Website:
    `BEFUND_Paket113_Haenger_20-11-2026.md`, Abschnitt 2.
  - **Entscheidung des Nutzers (20.11., 21:35, Auswahl „1 und 2“):** vorerst nur Deribit; dazu eine Recherche, ob eine andere
    Quelle den täglichen Abruf mit Speichern klar erlaubt. Ergebnis: `RECHERCHE_Optionsquellen_20-11-2026.md` — ins zweite Jahr
    reicht nur IBIT (bis Dezember 2028); ausdrücklich erlaubt ist das Speichern nur bei einem bezahlten Anbieter (EODHD, 29,99
    im Monat; ob IBIT dort enthalten ist, ist ungeprüft). Der Nutzer entscheidet danach neu; bis dahin gilt „nur Deribit“.
  - **Auffällig im Abendlauf — Folge für Z2.** Das Feld `underlying_price` zeigte für 11 von 12 Verfalltagen denselben Wert
    (58.060 USD; mittags 61.688 bis 64.648, steigend mit der Laufzeit). Aus der Put-Call-Parität der drei längsten Verfalltage
    folgen 59.078 / 59.917 / 60.765 USD — 5,2 bis 5,6 % pro Jahr über dem Feld, so viel wie mittags zwischen den Verfalltagen
    lag. Mittags stimmten Feld und Parität auf 4 bis 13 USD überein. Die Ursache kenne ich nicht; die Dokumentation der Börse
    sagt nur, das Feld `underlying_index` nenne den zugrunde liegenden Future oder `index_price`. Am Urteil ändert es nichts: Die
    Seiten verschieben sich um wenige Strikes, je Seite bleiben mehr als fünf.
    **Für Stufe 2 gilt deshalb, vor ihrem Bau festgelegt: Der Terminkurs kommt auch bei Deribit aus der Parität am Geld**
    (inverse Optionen, Mittelkurse in BTC: Terminkurs = Strike ÷ (1 − (Call − Put)), ohne Zins); `underlying_price` ist nur die
    Gegenprobe, eine Abweichung über 1 % meldet der Bericht. Das ändert die Zählweise Z2 nach dem Blick auf Daten — offen
    gesagt; es betrifft weder das Urteil des Erstlaufs noch die Regeln der Abschnitte 3 bis 8. Nachrechnung:
    `up2011d/pruef.py` im Arbeitsordner (27 von 27).
- **20.11.2026, 23:00 — vor dem ersten Lauf der Vorprüfung (Paket 23.115, `hl_langfrist.py`, Debug 153).** Beim Bau aus dem
  Prototyp geklärt und festgelegt, bevor der Lauf eine Zahl auf echten Daten gerechnet hat. Die Regeln der Abschnitte 3 bis 8
  sind unverändert; das Modul ergibt auf vier erzeugten Welten (ohne Zusammenhang, mit Zyklus, Zufallsweg) dieselben Tabellen
  und dieselben Urteile wie der Prototyp, Abweichung 0,0 (`dev/gleich_proto.py` im Arbeitsordner).
  - **Wann der erste Lauf zählt (zu 7.5).** Das Urteil wird nur abgelegt, wenn die Daten vollständig sind: Der letzte Kurstag ist
    höchstens 7 Tage alt, zwischen erstem und letztem Tag liegen höchstens 30 Tage ohne Kurs, und bei 365 Tagen gibt es
    mindestens 100 gewertete Stichtage (erwartet: 145). Sonst zeigt der Bericht die Zahlen als vorläufig und nennt den Grund.
    Das ist ein Schutz vor einem Urteil auf halben Daten, keine Stellschraube.
  - **Ablage.** `makro.db`, Tabelle `mk_meta`, Schlüssel `langfrist:urteil` — so legt auch die Datentage-Studie ihr Ergebnis
    ab. Ein Urteil derselben Regelversion wird nie überschrieben; eine neue Regelversion legt das alte mit Datum unter
    `langfrist:archiv` ab. Spätere Läufe rechnen den Alarm (7.2) und den Fächer von heute mit dem abgelegten Hauptfächer; was
    Regel 7.1 auf dem Stand von heute ergäbe, steht daneben.
  - **Fenster ohne Überlappung bei fehlenden Stichtagen.** „Jeder ⌈h ÷ 30⌉-te Stichtag ab dem ersten gewerteten“ ist ein festes
    Raster: Fällt ein Stichtag aus (kein Kurs am Stichtag oder am Ziel), verschiebt sich das Raster nicht. Ohne Ausfälle ist das
    dasselbe wie im Prototyp.
  - **Fehlende Kurstage.** Sicht A rechnet die Schwankung aus den Tagesrenditen zwischen aufeinanderfolgenden Tagen mit Kurs
    (mindestens 365 Renditen in den 1.461 Tagen). Ein Stichtag ohne Kurs entfällt. Der Bericht zählt Stichtage ohne Rechnung
    und Ziele ohne Kurs.
  - **Test in 7.1.** Ausgezählt werden alle 2^n Vorzeichenmuster; gebaut ist das für 6 bis 20 Fenster (heute 9 bis 12). Mehr als
    20 Fenster gibt es frühestens Mitte der 2030er-Jahre — dann sagt der Lauf „nicht gebaut“, statt etwas anderes zu rechnen.
  - **Sicht D.** Das Paar „Kurs gegen Realized Price“ kommt wie in U126 aus dem MVRV von Coin Metrics (y = ln MVRV);
    fortgeschrieben wird der Realized Price. Der Prototyp rechnete y = ln(Kurs ÷ Realized Price); in den erzeugten Welten ist
    das dasselbe. Fehlt am letzten Tag eines der beiden Paare, rechnet Sicht D mit dem anderen (4.4: „eines oder zwei“); der
    Bericht nennt die Paare.
  - **Bekannt und unverändert gelassen: die Ränder der Mischung.** `gew_quantile` setzt jeden der 199 Werte auf die Mitte seines
    Gewichts. Dadurch liegen die Ränder der Mischung bei 10,2 und 89,8 % statt bei 10 und 90 %, die des 50-%-Bands bei 25,1 und
    74,9 %: Bei genau bekannter Verteilung deckt das 80-%-Band 79,6 %, das 50-%-Band 49,75 %. Das war im Prototyp schon so — die
    Kalibrierung in Abschnitt 8 ist damit gerechnet — und ist klein gegen die Standardfehler der Deckung (beim Soll von 80 %: 6 bis 16 Punkte). Es
    bleibt Teil der Regelversion 1 (7.6); Probe P7 hält es fest. Aufgefallen ist es erst beim Bau der Probe.
  - **Nebenrechnung 7.7.** Gezeigt werden je Zeitraum (alles, 8 J, 4 J) die Mitte von Sicht B heute und ihr Fehler im Rückblick
    (RMSE in log10) — jeweils auf dem Raster von U126 für diesen Zeitraum (erster Stichtag = erster Fair Value + Zeitraum).
  - **Gegenproben im Bericht, auf den echten Daten.** (1) Sicht B bei 90, 180 und 365 Tagen gegen `pruefung` und `prognose` von
    U126: Zahl der Fälle, Ränder der bekannten Fehler, heutiges Band (ohne B3). (2) Kein Blick voraus: an drei Stichtagen die
    Vorhersage aus der vollen gegen die am Stichtag abgeschnittene Reihe.
  - **Heute.** Stichtag des Fächers von heute ist der letzte Tageswert von Coin Metrics (meist ein bis zwei Tage alt), nicht der
    laufende Kurs.
- **21.11.2026, 07:15 — Ergebnis der Vorprüfung (Debug 153 auf dem Pi unter 23.115; erster Lauf mit vollständigen Daten, Urteil
  abgelegt, Regelversion 1).** Einzelheiten: `BEFUND_Paket115_Vorpruefung_21-11-2026.md`.
  - **Urteil:** Hauptfächer bleibt H = ½ „ohne Richtung“ + ½ „Trend“; kein Kandidat löst ihn ab (7.1); kein Band zu schmal
    (7.2); bei 730 Tagen liegt der 90-%-Rand beim 7,5-Fachen des 10-%-Rands (7.4: Rückfrage erst ab dem 20-Fachen). **Nach den
    vorab festen Regeln kann der Chart gebaut werden.**
  - **Daten:** 18.07.2010 bis 20.11.2026, 5.970 Tage, keiner ohne Kurs. Gewertete Stichtage 154 / 151 / 145 / 138 / 132, Fenster
    ohne Überlappung 52 / 26 / 12 / 8 / 6 (90 / 180 / 365 / 548 / 730 Tage). Laufzeit auf dem Pi 5,6 s.
  - **CRPS von H** (ln): 0,215 / 0,335 / 0,526 / 0,589 / 0,606. Dagegen Z −1,1 / −6,1 / −9,5 / −6,7 / −2,3 %, G +0,2 / +1,5 /
    +4,6 / −1,6 / −8,2 %, W +3,8 bis +18,5 %.
  - **Regel 7.1:** Z war bei 365 Tagen in 7 von 9 Fenstern besser, p = 0,0723 bei verlangten 0,0167 — Bedingung 1 nicht erfüllt,
    die Bedingungen 2 und 3 erfüllt. G: 6 von 11, p = 0,7124. W: 1 von 12, p = 0,9934. „Nicht bestanden“ heißt nicht „kein
    Zusammenhang“ (Abschnitt 8).
  - **Deckung des 80-%-Bands von H:** 84 / 87 / 88 / 92 / 96 % aller Stichtage; ohne Überlappung 41 von 52, 22 von 26, 11 von 12,
    6 von 8, 6 von 6. 50-%-Band: 55 / 54 / 46 / 50 / 59 %.
  - **Fächer H vom 20.11.2026** (Kurs 58.851 USD), 10-%-Rand · Mitte · 90-%-Rand: 90 Tage 48.355 · 64.072 · 87.783; 180 Tage
    44.253 · 68.126 · 107.284; 365 Tage 38.955 · 72.898 · 150.266; 548 Tage 36.895 · 82.816 · 197.113; 730 Tage 34.332 · 96.079 ·
    256.479.
  - **Gegenproben auf den Daten des Pi:** Sicht B gleich der Rechnung von U126 (größte Abweichung 1,8e-15 in ln); das Band für
    365 Tage steht mit denselben Zahlen in Debug 52; kein Blick voraus (Abweichung 0).
  - **Gegen die Erwartung (Abschnitt 12):** eingetroffen bei A (Deckung bei 730 Tagen 67 %), bei der Mitte von B (95.026 bei 365
    Tagen), bei H (Deckung im Soll oder darüber), W und dem Alarm. Anders: B deckte bei 730 Tagen 83 % statt „deutlich darunter“;
    im CRPS lag A bis 365 Tage vorn, B erst ab 548 Tagen; die Spanne von H ist heute schmaler als der Überschlag (Faktor 7,5
    statt 11).
- **21.11.2026 — Entscheidungen des Nutzers.** 04:36 (Auswahl „1+3“): bei Deribit bleiben und Alpha Vantage ohne Kosten
  prüfen. 08:22 („Alles in einem“): Paket 23.116 bringt den Chart mit Debug 156, den Probe-Abruf bei Alpha Vantage und die
  Korrektur an Debug 157.
- **21.11.2026, 08:33 — Alpha Vantage: Probe-Abruf zurückgestellt (U293).** Die Dokumentation des Anbieters führt die
  historischen Optionsdaten (`HISTORICAL_OPTIONS`) unter „Premium“. Ein Abruf mit kostenlosem Schlüssel wäre demnach kein Test
  der Quelle. Der Nutzer ist gefragt („Probe trotzdem“ oder „EODHD testen“); ohne Antwort ist der Abruf nicht in 23.116. Bei
  Deribit bleibt es in jedem Fall.
- **21.11.2026, 09:05 — vor der ersten Monatsfassung (Paket 23.116):** Abschnitt 10a mit den Regeln V1 bis V7 der
  Vorwärtsbilanz. Beim Bau entschieden und dort begründet: Halving-Spanne aus der Blockzählung mit Gegenprobe; Linien der
  früheren Zyklen als Wochenwerte; Fair Value links mit den Parametern von heute; der Ausblick wird nur angeschlossen, wenn
  seine Rechnung höchstens 3 Tage vor dem Stichtag liegt; Preis- und Arbeitsmarkttermine nur als Text; Kontextstreifen erst mit
  Stufe 2. Das sind Fragen der Darstellung — an der Rechnung des Fächers ändert keine etwas.
- **22.11.2026 — Entscheidung des Nutzers und Bau der Optionen-Schicht (Paket 23.118).** Auswahl „Markt-Schicht mit Deribit“ (nicht
  „erst EODHD testen“, nicht „Alpha Vantage trotzdem proben“); U293 bleibt zurückgestellt. Die Regeln O1 bis O8 stehen in Abschnitt
  9.3, festgelegt vor dem Bau. An erzeugten Ketten danach geändert: O5.3 (zusammengelegte Paare als ein Paar über die ganze
  Strecke) — vor jedem echten Abruf. Ein echter Abruf lief in der Arbeitsumgebung nicht; die ersten Zahlen kommen vom Pi.
- **22.11.2026, 10:06 — nach dem ersten echten Abruf der Optionen (Paket 23.119).** Auswertung in Abschnitt 9.3. Festgelegt vor dem
  Bau: O9 (Diagnose je Verfalltag: wo zusammengelegt wurde, die Enden, zweite Gegenprobe aus den Schwankungen der Börse) und O10
  (Prüflauf ohne Speichern, Debug 158) — beide nur für den Bericht, kein Rand ändert sich. **Entscheidung des Nutzers (22.11., rund
  10:00 Uhr, Auswahl „Wurzel-Verlauf“):** Der Fächer bekommt bis 90 Tage eine Breite, die mit der Wurzel der Zeit wächst (Abschnitt
  10a, Nachtrag); Stützstellen, Monatsfassungen und Regelversion bleiben.
- **22.11.2026, 14:27 — beim Bau von 23.119, vor dem Einfrieren.** Zusatz zu O9: Die Diagnose darf weder den Abruf noch die
  Zeichen kosten (ein Fehler wird vermerkt statt geworfen). Anlass: Durchsicht vor dem Einfrieren — die Diagnose läuft auf dem Pi
  zum ersten Mal auf echten Daten, und zwar im Tagesabruf. Keine Rechenregel geändert.

- **22.11.2026, 21:57 — erste Diagnose auf echten Daten (Debug 158 und 156 unter 23.119 auf dem Pi).** Ein Abruf, 1.014 Kontrakte,
  12 Verfalltage, alle mit Rändern, keine Markierung „prüfen“. (1) Zusammenlegungen: an allen 12 Verfalltagen 0 im Bereich der
  Ränder (bis zu 10 je Verfalltag außerhalb). (2) Zweite Gegenprobe (21 bis 62 Strikes je Verfalltag): größter Abstand der Ränder aus
  den Preisen, aus dem Bericht nachgerechnet: 0,4 % (10-%-Rand), 1,5 % (25-%-Rand), 0,7 % (Mitte), 0,8 % (75-%-Rand), 0,5 %
  (90-%-Rand) — Schwellen 3 % und 6 %. (3) Die Mitte liegt an den fünf langen Verfalltagen 2,5 bis 5,6 % über der Gegenprobe am
  Geld; die Mitte aus den Schwankungen der Börse liegt dort 2,3 bis 4,8 % darüber. Die Verschiebung kommt also aus der Schiefe über
  die Strikes, nicht aus einzelnen Geld- und Briefkursen und nicht aus dem Zusammenlegen (unabhängig vom Markt ist die zweite
  Gegenprobe nicht). (4) Der 10-%-Rand fehlt am 25.06. und 24.09.2027, weil unter dem untersten Strike-Paar 10,5 und 10,8 % liegen;
  kleinster gelisteter Strike dort 30.000. Der Abruf von 21:45 Uhr stammte noch von 23.118 (Dienste neu seit 21:45:43) und trägt
  keine Diagnose; die erste gespeicherte kommt mit dem Abruf vom 23.11. Fächer bis 90 Tage unter 23.119 am 25.12.2026: 52.170 ·
  62.040 · 75.258 (unter 23.118: 55.772 · 62.040 · 69.860). Einzelheiten: `BEFUND_Paket119_Berichte_22-11-2026.md`.
- **22.11.2026, 22:15 — Entscheidung des Nutzers zu Teil 2 der Markt-Schicht (Paket 23.120).** Auf meinen Vorschlag: zwei Schritte
  (erst der Bericht Debug 159, dann der Chart mit 23.121) und zwei weitere Marktreihen sammeln (PM1). Wortlaut: „Ich sage dir
  bereits vorab JA, ich folge deinem Vorschlag/Empfehlung“. Abschnitt 9.4 ist danach beim Bau geschrieben; kein Wert aus
  `prognosemarkt.db` des Pi war dabei bekannt.
- **23.11.2026, 04:51 — erster Debug 159 auf dem Pi (23.120, eingespielt 04:40).** Laufzeit 0,5 s. Acht Ereignisse mit Frist ab 7
  Tagen; beide neuen Reihen gesammelt, Niveau und Frist wie in Titel und Regel der Börse (`KXBTCPRICE-130000`: acht Fristen bis
  08.07.2027; `when-will-bitcoin-hit-100k`: fünf Fristen bis 31.12.2027, das Feld `endDate` je Markt wie die Frist). Zahlen in
  Abschnitt 9.5 („Was ich beim Festlegen kannte“). Zwei Schwächen des Berichts, beide meine: Der letzte Handel als Ersatz bei
  weitem Spread (PM3) ergab für die Zins-Leitern ab Juni 2027 unbrauchbare Zahlen, ohne Warnung; entschiedene Märkte füllten die
  Tabellen. Debug 20 vom selben Lauf zeigt die neue Zeile des Wächters (288 Prüfungen in 24 Stunden). Einzelheiten:
  `BEFUND_Paket120_Berichte_23-11-2026.md`.
- **23.11.2026, zwischen 04:53 und 05:10 — Entscheidungen des Nutzers zu Schritt 2b (Paket 23.121).** Drei Fragen zum Anklicken,
  je drei Antworten mit Vorschlag und Folgen; gewählt je der Vorschlag: „Nur lange Märkte“ (ab 90 Tagen Frist), „Roh“, „Nur enge
  Sitzungen“. Danach Abschnitt 9.5 geschrieben, vor der ersten Zeile Code für Schritt 2b.

## Quellen

- `BEWERTUNG_Prognosechart_24_Monate_19-11-2026.md` (Belegstand, Überschlag, alle Literaturquellen)
- [Baquero & Menezes, Bitcoin’s Power Law: Weak Structure, Strong Forecasts (arXiv 2605.21316)](https://arxiv.org/html/2605.21316v1)
- [Baquero, Deceleration without identification (arXiv 2611.13962)](https://arxiv.org/html/2611.13962v1)
- [Molnar, Bitcoin Runs on a Clock (arXiv 2607.26188)](https://arxiv.org/html/2607.26188)
- [Deribit, Contract Introduction Policy](https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy)
- [apis.io, Cboe Global Markets](https://apis.io/providers/cboe/)
- [Deribit, public/get_book_summary_by_currency](https://docs.deribit.com/api-reference/market-data/public-get_book_summary_by_currency)
- `RECHERCHE_Optionsquellen_20-11-2026.md` (Reichweite der Märkte, Anbieter, Bedingungen; mit allen Quellen)
- Stand der lang laufenden BTC-Märkte am 22.11.2026 (Abschnitt 9.4): [Kalshi, Bitcoin price prediction](https://kalshi.com/crypto/bitcoin-price-prediction)
  (Seite „Updated today at 8:02 AM ET“), [Polymarket, When will Bitcoin hit $100k?](https://polymarket.com/event/when-will-bitcoin-hit-100k)
- `KONZEPT_Prognosemaerkte.md` (Regel 1.6; Nachtrag 13.10 zu den zwei Fristen-Leitern), `BEFUND_Paket119_Berichte_22-11-2026.md`,
  `BEFUND_Paket120_Berichte_23-11-2026.md` (erster Debug 159 vom Pi)
- [Alpha Vantage, API Documentation](https://www.alphavantage.co/documentation/) (Abschnitt „Options Data“, gelesen am 21.11.2026:
  `HISTORICAL_OPTIONS` ist als „Premium“ geführt)
- `BEFUND_Paket115_Vorpruefung_21-11-2026.md` (Urteil der Vorprüfung mit allen Zahlen)
- Aufbau der Cboe-Antwort, drei Beschreibungen: [OpenBB, Diskussion 2741](https://github.com/OpenBB-finance/OpenBBTerminal/discussions/2741),
  [RevenueChaser, Issue 418](https://github.com/alsanvolkan/RevenueChaser-public/issues/418),
  [David Arias, Gamma exposure step by step](https://davidariasfinance.com/scripts/gamma-exposure-gex/)
- Code: `hl_makro.py` (`powerlaw_monatlich`, `HALVINGS`, `ableiten`), `hl_makro_signal.py` (`pruefung`, `prognose`, `ar1`,
  `_fehler_bekannt`), `hl_ausblick.py` (`crps_ens`, `gew_quantile`), `hl_aktien.py` (Cboe, Deribit), `hl_optionen.py` (Erstlauf),
  `hl_langfrist.py` (Vorprüfung, Chart, Monatsfassungen), `hl_makro_js.py` (`mkLangfrist`), `hl_volatil.py` (`FOMC`),
  `hl_marktschicht.py` (Optionen-Schicht; seit 23.120 Teil 2a: Prognosemärkte als Text; seit 23.121 Teil 2b: Auswahl für den
  Chart), `hl_prognosemarkt.py` (Sammeln)
