#!/usr/bin/env python3
"""
hl_profis.py -- "Aktive Profis", Phase 2: Bewertung der Pool-Konten (Konzept KONZEPT_Aktive_Profis.md, §5-6).

Nur Lesen der Hauptdatenbank; keine Nebenwirkungen. Alle Größen sind auf den VERFOLGTEN Coins definiert
(der Trade-Stream ist nur für sie abonniert; ein Konto, das andere Coins handelt, hat hier keine Trades).

Darwin-Liste, Regeln v2 (23.37, Nutzer 30.09.: „Die besten kommen auf Bewährung, rein kommen nicht besonders gute“) --
Aufnahme streng, Verbleib großzügig. Timing über 14 Tage, Aktivität über 7 Tage; Kontowert >= 1 Mio (Pool), nicht gesperrt.
  Aufnahme (alles Pflicht):
  - Aktivität: 2 <= gebündelte Trades/Tag <= 150 in den verfolgten Coins (Fills je Minute und Richtung, pool_fills_hourly)
  - Gewinn 7 T > 0 UND 30 T > 0 (Hyperliquids einzahlungsbereinigte Fenster, pool_accounts.pnl_7d/pnl_30d)
  - Timing: mindestens 6 bewertbare Ein- und Ausstiege in 14 T (gleichgerichtete im selben 4-h-Block einmal); ein Treffer
    ist eine Bewegung >= 2 % in die richtige Richtung binnen 12 h; die Trefferbilanz darf höchstens mit 1 % Wahrscheinlichkeit
    Glück sein (exakter Test gegen die Zufallsquote je Coin und Richtung aus 200 Placebo-Zeitpunkten), und der gedämpfte
    Vorsprung vor dem Zufall beträgt mindestens 10 Punkte
  - Einstiege ab 5 nur als Veto: Entry-Lift nicht belegbar negativ (t > -1)
  Verbleib (Mitglieder): 1 <= Trades/Tag <= 150, Gewinn 30 T > 0, mindestens 4 Ein-/Ausstiege in 14 T, Timing weiter über dem
  Zufall (Glück höchstens 50 %, Vorsprung > 0), kein Einstiegs-Veto. Abstieg erst nach 3 Tagesbewertungen in Folge ohne
  Verbleib (darwin_tag). Simulation (200 Konten ohne, 10 mit 20 Punkten Vorsprung): Könner auf der Liste 30 % -> 68 % der Zeit,
  Zufallsaufnahmen 8,8 -> 0,9 je Woche, Könner fliegen raus 3,4 -> 0,5 je Woche.
Regeln v3 (23.38, Bericht 30.09.): Diese Schonung (großzügiger Verbleib, 3 Fehltage) gilt nur für Konten, die die strenge
  Aufnahme bestanden haben -- Merker „streng“ im Stand. Jeder Weg auf die Liste verlangt die strenge Aufnahme. Beim Umstieg auf
  v3 bleiben Mitglieder ohne strenge Aufnahme (Altbestand aus v1, Rückkehr über die Verbleib-Regel beim Umstieg auf v2) nur,
  wenn sie die Aufnahme jetzt erfüllen. Anlass: v2 hatte beim Umstieg ein Konto mit Verlust über 7 Tage und 11 % Glück über
  die Verbleib-Regel zurückgeholt und drei Altmitglieder ohne einen einzigen bewertbaren Ein-/Ausstieg bzw. mit Verlust über
  30 Tage noch drei Tage auf der Liste gelassen -- „rein kommen nicht besonders gute“.
  Bis 23.36 galt EINE Regel für beides (7 T, Glück <= 5 %, 4 Entscheidungen, Gewinn 7 T), Abstieg nach 2 Tagen: Ein Treffer,
  der aus dem Fenster fiel, kippte ein Konto (7/10 -> 6/10 bei 32 % Zufall: 1,6 % -> 6,4 %), und bei ~200 geprüften Konten
  kam fast täglich eines durch Glück hinein.
  Ereignisse (Ein-/Ausstiege) aus whale_positions, lb_events und -- 23.34 -- pool_positions (alle Pool-Konten, 10-min-Raster);
  dieselbe Entscheidung aus mehreren Quellen binnen 15 min zählt einmal.
Anzeige:
  - Entry-Lift (Einstiege vor einer Bewegung >= 2 % in die eigene Richtung binnen 12 h, gleiches Placebo)
  - Bot-Marke: über 7 Tage nie länger als 4 h ohne Trade (Stundenraster), ab 5 Tagen Daten
  - Reaktionszeit: Median der Minuten von einer Bewegung >= 1 % in 15 min bis zum nächsten Trade
  - bester Coin (closedPnl, sobald der REST-Nachtrag ihn liefert; sonst Umsatz)
Rang: ROI 12 h aus eigenen Daten (Σ closedPnl der Fills in 12 h nach REST-Nachtrag + Änderung des
unrealisierten Gewinns, relativ zum Kontowert); Konten ohne Nachtrag vorerst nach Hyperliquids roi_1d.
Eingefroren alle 12 h (00/12 UTC) -- Feld "rang_basis" sagt, was gilt.
Schatten der Darwin-Liste (U136, 23.57; Nutzer 07.10.: „ja“ zur Beobachtung der Beinahe-Aufnahmen): Konten, die die Aufnahme bis
auf die Glücksschwelle erfüllen (Glück 1–3 % und 3–5 %), dazu die echten Aufnahmen (≤ 1 %) und eine Kontrollgruppe (ebenso
geprüft, Glück über 5 %) -- je Gruppe die Ein- und Ausstiege NACH dem Eintritt, Treffer wie oben. Vorab festgelegtes Urteil am
18.11.2026 (KONZEPT_Aktive_Profis.md 11). Wirkt nicht auf Liste, Labor oder Familien.
"""
import bisect
import calendar
import json
import math
import random
import sqlite3
import statistics
import sys
import time

PROFI_MIN_TRADES = 2           # 23.31 (Nutzer 25.09.): vorher 5 -- an ruhigen Tagen ist Ruhe; alle übrigen Regeln unverändert
PROFI_MAX_TRADES = 150          # Nutzer 22.09.
KORREKTUR = 0.02                # 2 % ...
HORIZONT = 12 * 3600            # ... binnen 12 h
PLACEBO_N = 200
QUALI_TAGE = 7                  # Aktivität (Trades/Tag) über 7 Tage
TIMING_TAGE = 14                # 23.37: Timing-Beleg über 14 Tage (vorher 7) -- doppelt so viele Entscheidungen
REGEL_VERSION = 3               # 23.37: v2 (Aufnahme streng, Verbleib großzügig); 23.38: v3 -- die Schonung nur nach strenger Aufnahme
AUFNAHME_P_GLUECK = 0.01        # Aufnahme: Glückswahrscheinlichkeit höchstens 1 % (bis 23.36: 5 % für Aufnahme UND Verbleib)
AUFNAHME_MIN_ENTSCH = 6         # ... mindestens 6 bewertbare Ein-/Ausstiege in 14 T
AUFNAHME_MIN_VORSPRUNG = 0.10   # ... gedämpfter Vorsprung (lift_s) mindestens 10 Punkte über dem Zufall
VERBLEIB_P_GLUECK = 0.50        # Verbleib: Timing weiter über dem Zufall (Glück höchstens 50 %, Vorsprung > 0)
VERBLEIB_MIN_ENTSCH = 4
VERBLEIB_MIN_TRADES = 1         # Verbleib: mindestens 1 gebündelter Trade je Tag (Aufnahme 2)
DARWIN_ABSTIEG_TAGE = 3         # Abstieg nach 3 Tagesbewertungen in Folge ohne Verbleib (bis 23.36: 2, ohne eigene Verbleib-Regel)
DARWIN_PROTOKOLL_TAGE = 14      # Zu- und Abgänge mit Grund so lange im Stand
BOT_MAX_LUECKE_H = 4
MIN_EXITS = 5                   # Anzeige: Exit-/Entry-Lift erst ab 5 Fällen (t sonst nicht aussagekräftig)
T_MIN = 1.0
# 23.32 (Entscheidung Nutzer 25.09.): Qualifikation über ALLE Timing-Entscheidungen -- Einstiege und Ausstiege zusammen
# („wer 2x kauft, kann nur 2x verkaufen“) --, mindestens MIN_ENTSCHEIDUNGEN, und die Trefferbilanz darf höchstens mit
# P_GLUECK_MAX Wahrscheinlichkeit reines Glück sein (exakter Test gegen die Zufallsquote je Coin und Richtung). Die Schwelle
# passt sich selbst an: wenige Entscheidungen müssen fast alle stimmen, viele dürfen auch danebenliegen. Vorher:
# mindestens 5 Ausstiege und Exit-Lift > 0 mit t ≥ 1 -- das ließ 4 von 5 durch (bei 40 % Zufall 8,7 % Glück).
MIN_ENTSCHEIDUNGEN = AUFNAHME_MIN_ENTSCH     # 23.37: Namen für Anzeige und Berichte -- es gilt die Aufnahme-Regel
P_GLUECK_MAX = AUFNAHME_P_GLUECK
ENTRY_VETO_MIN = 5              # Einstiege nur als Veto: ab 5 Einstiegen deutlich negativ (t ≤ −1)
M_PSEUDO = 4                    # Dämpfung kleiner Zahlen für die Rangfolge: 4 gedachte Entscheidungen zur Zufallsquote
TIMING_BLOCK = 4 * 3600         # gleichgerichtete Entscheidungen im selben 4-h-Block zählen einmal (sie hängen zusammen)


# ----------------------------------------------------------------------------------------------
# Kursreihe
# ----------------------------------------------------------------------------------------------
class Kurs:
    """Minutenkurse eines Coins im Fenster; extrem_nach(t, h, richtung) = Tief/Hoch der nächsten h Sekunden."""

    def __init__(self, con, coin: str, seit: int, bis: int):
        rows = con.execute("SELECT ts, close, low, high FROM bars WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                           (coin, seit - 60, bis)).fetchall()
        self.ts = [r[0] for r in rows]; self.close = [r[1] for r in rows]
        self.low = [(r[2] if r[2] else r[1]) for r in rows]; self.high = [(r[3] if r[3] else r[1]) for r in rows]
        self._np = None

    def zuerst(self, t: int, h: int, s: float) -> int | None:
        """
        23.22 „Zuerst richtig“: +1 = binnen h zuerst +s erreicht, -1 = zuerst -s, 0 = keines von beiden, None = keine
        Daten oder beide in derselben Minute (nicht entscheidbar).
        """
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        import numpy as np
        if self._np is None:
            self._np = (np.asarray(self.low, dtype=float), np.asarray(self.high, dtype=float))
        auf = np.flatnonzero(self._np[1][i:j] >= p0 * (1 + s)); ab = np.flatnonzero(self._np[0][i:j] <= p0 * (1 - s))
        ia = int(auf[0]) if len(auf) else None; ib = int(ab[0]) if len(ab) else None
        if ia is None and ib is None:
            return 0
        if ia is not None and ib is not None and ia == ib:
            return None
        return 1 if ib is None or (ia is not None and ia < ib) else -1

    def at(self, t: int):
        i = bisect.bisect_right(self.ts, t) - 1
        return self.close[i] if i >= 0 and t - self.ts[i] <= 120 else None

    def rueckgang_binnen(self, t: int, h: int) -> float | None:
        """Größter Rückgang (negativ) relativ zum Kurs bei t innerhalb der nächsten h Sekunden."""
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        lo = min(self.low[i:j])
        return lo / p0 - 1.0

    def anstieg_binnen(self, t: int, h: int) -> float | None:
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        return max(self.high[i:j]) / p0 - 1.0


# ----------------------------------------------------------------------------------------------
# Ereignisse je Konto (Ausstiege / Einstiege) aus whale_positions, lb_events und pool_positions
# ----------------------------------------------------------------------------------------------
# 23.34: pool_positions ist die dritte -- und für die meisten Pool-Konten die einzige -- Quelle. Sie protokolliert seit 23.27 die
# Positionsänderungen ALLER Pool-Konten (10-min-Raster, Positionen ab 50k, Änderungen ab 10k), wurde hier aber nie gelesen: Konten
# unter der Wal-Schwelle und außerhalb des Leaderboard-Trackings hatten 0 bewertbare Ereignisse, obwohl sie handelten („nur 0
# bewertbare Ein-/Ausstiege“ trotz 37 Trades/Tag). Dieselbe Entscheidung kann in mehreren Quellen auftauchen (Wal-Abfrage und
# Pool-Abfrage Minuten auseinander) -- je Konto, Coin, Ein-/Ausstieg und Seite zählt sie binnen DOPPEL_S einmal.
QUELLEN = (("whale_positions", "Wal-Positionen"), ("lb_events", "Leaderboard"), ("pool_positions", "Pool-Positionen"))
DOPPEL_S = 900


def lade_ereignisse(con, addrs, coins, seit: int, bis: int, quellen: dict | None = None) -> dict:
    """
    {addr: [(ts, coin, art, side)]} mit art in {'exit','entry'} (reduce/close = Ausstieg, open/add/flip = Einstieg; beim Flip
    ist die Seite die NEUE). quellen (optional): wird mit der Zahl der übernommenen Ereignisse je Tabelle gefüllt.
    """
    out: dict = {}
    if not addrs or not coins:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l)); cmarks = ",".join("?" * len(coins))
    roh = []
    for tab, _ in QUELLEN:
        try:
            for ts, a, coin, ev, side in con.execute(f"SELECT ts, lower(addr), coin, event, side FROM {tab} WHERE ts>=? AND ts<=? AND lower(addr) IN ({marks}) "
                                                     f"AND coin IN ({cmarks}) AND event IN ('open','add','reduce','close','flip')", (seit, bis, *a_l, *coins)):
                roh.append((int(ts), a, coin, "exit" if ev in ("reduce", "close") else "entry", str(side or "").lower(), tab))
        except sqlite3.OperationalError:
            continue                                        # Tabelle fehlt (ältere Datenbank) -- die übrigen Quellen gelten
    roh.sort()
    letzt: dict = {}
    for ts, a, coin, art, side, tab in roh:
        key = (a, coin, art, side)
        if key in letzt and ts - letzt[key] < DOPPEL_S:
            continue
        letzt[key] = ts
        out.setdefault(a, []).append((ts, coin, art, side))
        if quellen is not None:
            quellen[tab] = quellen.get(tab, 0) + 1
    return out


def grund_kategorie(grund: str) -> str:
    """23.34: Kategorie eines Ausschlussgrunds (für check_profis und das Dashboard -- vorher zählte „Glück“ als „zu wenige Ausstiege“)."""
    g = grund or ""
    if "Trades/Tag" in g:
        return "Aktivität"
    if "Gewinn 7 T" in g:
        return "Gewinn 7 T"
    if "Gewinn 30 T" in g:
        return "Gewinn 30 T"
    if "bewertbare" in g:
        return "zu wenige Ein-/Ausstiege"
    if "Glückswahrscheinlichkeit" in g or "über dem Zufall" in g:
        return "Timing nicht belegt"
    if "Vorsprung" in g:
        return "Vorsprung zu klein"
    if "gesperrt" in g or "Pool" in g:
        return "gesperrt oder nicht im Pool"
    if "Entry-Lift" in g:
        return "Einstiege widerlegt"
    return "sonstige"


def grund_zaehlung(konten: list) -> dict:
    """{Kategorie: Zahl} nach dem ERSTEN Grund je nicht qualifiziertem Konto, absteigend."""
    z: dict = {}
    for k in konten:
        if k.get("gruende"):
            c = grund_kategorie(k["gruende"][0]); z[c] = z.get(c, 0) + 1
    return dict(sorted(z.items(), key=lambda kv: -kv[1]))


def n_eff_bloecke(zeiten, block_s: int = HORIZONT) -> int:
    return len({int(t) // block_s for t in zeiten})


def glueck_p(treffer: int, quoten: list) -> float:
    """
    23.32: Wahrscheinlichkeit, mindestens `treffer` Treffer rein zufällig zu erzielen, wenn Entscheidung i mit der
    Wahrscheinlichkeit quoten[i] zufällig trifft (Poisson-Binomial, exakt per dynamischer Programmierung).
    """
    dp = [1.0]
    for q in quoten:
        neu = [0.0] * (len(dp) + 1)
        for k, w in enumerate(dp):
            neu[k] += w * (1 - q); neu[k + 1] += w * q
        dp = neu
    return float(min(1.0, sum(dp[max(0, treffer):])))


def timing_beleg(ents: list) -> dict:
    """ents: [(Treffer 0/1, Zufallsquote, 'entry'|'exit')] -- Bilanz, Glückswahrscheinlichkeit, gedämpfte Untergrenze."""
    n = len(ents)
    if not n:
        return {"n": 0, "treffer": 0, "n_ein": 0, "n_aus": 0, "zufall": None, "p_glueck": None, "lift_s": None, "lcb": None}
    k = sum(h for h, _, _ in ents); quoten = [min(max(e, 0.01), 0.99) for _, e, _ in ents]
    pbar = sum(quoten) / n
    post = (k + M_PSEUDO * pbar) / (n + M_PSEUDO)
    se0 = math.sqrt(pbar * (1 - pbar) / (n + M_PSEUDO))
    return {"n": n, "treffer": k, "n_ein": sum(1 for _, _, a in ents if a == "entry"), "n_aus": sum(1 for _, _, a in ents if a == "exit"),
            "zufall": round(pbar, 3), "p_glueck": glueck_p(k, quoten), "lift_s": post - pbar, "lcb": post - pbar - se0}


def lift(treffer: list, placebo_quote: float, n_eff: int) -> tuple:
    """Lift = Trefferanteil − Placebo; t gegen SE der Differenz auf n_eff und PLACEBO_N."""
    if not treffer:
        return None, None
    p = sum(treffer) / len(treffer)
    se = math.sqrt(max(p * (1 - p), 0.0025) / max(n_eff, 1) + max(placebo_quote * (1 - placebo_quote), 0.0025) / PLACEBO_N)
    l = p - placebo_quote
    return l, (l / se if se > 0 else None)


_PL_CACHE: dict = {}


def placebo_berechnen(kurse: dict, seit: int, bis: int, rng: random.Random) -> tuple:
    """
    Zufallsquoten je Coin aus PLACEBO_N zufälligen Zeitpunkten desselben Fensters: (Rückgang, Anstieg) >= 2 % binnen 12 h
    und -- 23.22 -- dieselben binnen 1 h und 4 h sowie „zuerst -2 %“ / „zuerst +2 %“ unter den entschiedenen Fällen.
    23.22: einmal je Bewertung gerechnet und für alle Konten geteilt (vorher je Konto neu -- langsam und uneinheitlich).
    """
    key = (seit, bis, tuple((c, len(k.ts), k.ts[0] if k.ts else 0, k.ts[-1] if k.ts else 0) for c, k in sorted(kurse.items())))
    if key in _PL_CACHE:
        return _PL_CACHE[key]
    placebo: dict = {}; placebo_x: dict = {}
    for coin, k in kurse.items():
        if not k.ts:
            continue
        q = {n_: [] for n_ in ("r12", "a12", "r1", "a1", "r4", "a4")}; zz = []
        for _ in range(PLACEBO_N):
            t = rng.randint(seit, bis - HORIZONT)
            for n_, h_ in (("12", HORIZONT), ("1", 3600), ("4", 4 * 3600)):
                r = k.rueckgang_binnen(t, h_); a = k.anstieg_binnen(t, h_)
                if r is not None:
                    q["r" + n_].append(1 if r <= -KORREKTUR else 0)
                if a is not None:
                    q["a" + n_].append(1 if a >= KORREKTUR else 0)
            z_ = k.zuerst(t, HORIZONT, KORREKTUR)
            if z_ in (1, -1):
                zz.append(z_)
        m_ = lambda v: sum(v) / len(v) if v else None
        placebo[coin] = (m_(q["r12"]), m_(q["a12"]))
        placebo_x[coin] = {"d1": m_(q["r1"]), "a1": m_(q["a1"]), "d4": m_(q["r4"]), "a4": m_(q["a4"]),
                           "zd": (zz.count(-1) / len(zz)) if zz else None, "za": (zz.count(1) / len(zz)) if zz else None}
    _PL_CACHE.clear(); _PL_CACHE[key] = (placebo, placebo_x)
    return placebo, placebo_x


def bewerte_konto(con, addr: str, ereignisse: list, kurse: dict, seit: int, bis: int, rng: random.Random, pl: tuple | None = None) -> dict:
    """Exit-/Entry-Lift eines Kontos über alle verfolgten Coins (Placebo je Coin aus demselben Fenster)."""
    ex_treffer: list = []; ex_zeiten: list = []; en_treffer: list = []; en_zeiten: list = []
    placebo, placebo_x = pl if pl is not None else placebo_berechnen(kurse, seit, bis, rng)
    pl_r = [v[0] for v in placebo.values() if v[0] is not None]; pl_a = [v[1] for v in placebo.values() if v[1] is not None]
    placebo_r = statistics.mean(pl_r) if pl_r else None; placebo_a = statistics.mean(pl_a) if pl_a else None
    ex_erw: list = []; en_erw: list = []
    bilanz = {k_: [0, 0, 0.0] for k_ in ("long_ein", "short_ein", "long_aus", "short_aus")}   # n, Treffer, Summe der Zufallsquoten
    tempo = {h_: [0, 0, 0.0] for h_ in ("1h", "4h", "12h")}; zuerst = [0, 0, 0.0, 0]          # zuerst: entschieden, richtig, Zufall, offen
    entsch: list = []                                                                           # 23.32: alle Ein- und Ausstiege
    for ts, coin, art, side in ereignisse:
        k = kurse.get(coin); pc = placebo.get(coin)
        if side not in ("long", "short") or not k or not k.ts or not pc or ts + HORIZONT > bis:
            continue                                        # 23.21: ohne gültige Seite kein Urteil (vorher galt alles außer long als short)
        faellt = (art == "exit") == (side == "long")        # Treffer = Rückgang: Long zu oder Short auf; sonst Anstieg
        v = k.rueckgang_binnen(ts, HORIZONT) if faellt else k.anstieg_binnen(ts, HORIZONT)
        erw = pc[0] if faellt else pc[1]                    # 23.21: Vergleich mit DEMSELBEN Coin und DERSELBEN Richtung (vorher Mittel über
        if v is None or erw is None:                        # Coins und Richtungen: im Trendmarkt +41 pp für zufällige Short-Schließungen)
            continue
        hit = (v <= -KORREKTUR) if faellt else (v >= KORREKTUR)
        b_ = bilanz[f"{side}_{'aus' if art == 'exit' else 'ein'}"]; b_[0] += 1; b_[1] += 1 if hit else 0; b_[2] += erw
        entsch.append((ts, faellt, 1 if hit else 0, erw, art))
        pxc = placebo_x.get(coin) or {}
        for hk, hs in (("1h", 3600), ("4h", 4 * 3600)):                   # 23.22 Tempo: Treffer schon nach 1 h / 4 h?
            vv = k.rueckgang_binnen(ts, hs) if faellt else k.anstieg_binnen(ts, hs)
            ee = pxc.get(("d" if faellt else "a") + hk[0])
            if vv is not None and ee is not None:
                tp = tempo[hk]; tp[0] += 1; tp[1] += 1 if ((vv <= -KORREKTUR) if faellt else (vv >= KORREKTUR)) else 0; tp[2] += ee
        tp = tempo["12h"]; tp[0] += 1; tp[1] += 1 if hit else 0; tp[2] += erw
        z_ = k.zuerst(ts, HORIZONT, KORREKTUR); ez = pxc.get("zd" if faellt else "za")    # 23.22 „Zuerst richtig“
        if z_ == 0:
            zuerst[3] += 1
        elif z_ in (1, -1) and ez is not None:
            zuerst[0] += 1; zuerst[1] += 1 if z_ == (-1 if faellt else 1) else 0; zuerst[2] += ez
        if art == "exit":
            ex_treffer.append(1 if hit else 0); ex_zeiten.append(ts); ex_erw.append(erw)
        else:
            en_treffer.append(1 if hit else 0); en_zeiten.append(ts); en_erw.append(erw)
    out = {"n_exits": len(ex_treffer), "n_entries": len(en_treffer), "exit_lift": None, "exit_t": None, "entry_lift": None, "entry_t": None,
           "placebo": statistics.mean(ex_erw) if ex_erw else None, "n_eff_exit": n_eff_bloecke(ex_zeiten), "n_eff_entry": n_eff_bloecke(en_zeiten),
           "bilanz": {k_: {"n": v_[0], "treffer": v_[1], "zufall": round(v_[2] / v_[0], 3) if v_[0] else None} for k_, v_ in bilanz.items()},
           "tempo": {k_: {"n": v_[0], "treffer": v_[1], "zufall": round(v_[2] / v_[0], 3) if v_[0] else None} for k_, v_ in tempo.items()},
           "zuerst": {"n": zuerst[0], "richtig": zuerst[1], "zufall": round(zuerst[2] / zuerst[0], 3) if zuerst[0] else None, "offen": zuerst[3]}}
    gesehen: set = set(); ents = []
    for ts_, fa_, h_, e_, a_ in sorted(entsch):                                                 # 23.32: je Richtung und 4-h-Block einmal
        key_ = (fa_, int(ts_) // TIMING_BLOCK)
        if key_ not in gesehen:
            gesehen.add(key_); ents.append((h_, e_, a_))
    out["timing"] = timing_beleg(ents)
    if len(ex_treffer) >= MIN_EXITS:
        out["exit_lift"], out["exit_t"] = lift(ex_treffer, statistics.mean(ex_erw), out["n_eff_exit"])
    if len(en_treffer) >= MIN_EXITS:
        out["entry_lift"], out["entry_t"] = lift(en_treffer, statistics.mean(en_erw), out["n_eff_entry"])
    return out


def aktivitaet(con, addrs, seit: int, bis: int) -> dict:
    """{addr: {trades_tag, tage, stunden_aktiv, laengste_luecke_h, bot, umsatz, closed_pnl, bester_coin}} aus pool_fills_hourly."""
    out: dict = {}
    if not addrs:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l))
    rows = con.execute(f"SELECT lower(addr), stunde, coin, n_trades, buy_usd+sell_usd, closed_pnl FROM pool_fills_hourly "
                       f"WHERE stunde>=? AND stunde<? AND lower(addr) IN ({marks}) ORDER BY 1, 2", (seit, bis, *a_l)).fetchall()
    stunden_da = con.execute("SELECT COUNT(DISTINCT stunde) FROM pool_fills_hourly WHERE stunde>=? AND stunde<?", (seit, bis)).fetchone()[0] or 0
    tage_da = max(1.0, stunden_da / 24.0)
    je: dict = {}
    for a, st, coin, n, umsatz, pnl in rows:
        d = je.setdefault(a, {"stunden": set(), "n": 0, "umsatz": 0.0, "pnl": 0.0, "coins": {}})
        if n:
            d["stunden"].add(st); d["n"] += n
        d["umsatz"] += umsatz or 0.0; d["pnl"] += pnl or 0.0
        c = d["coins"].setdefault(coin, [0.0, 0.0]); c[0] += pnl or 0.0; c[1] += umsatz or 0.0
    for a in a_l:
        d = je.get(a)
        if not d:
            out[a] = {"trades_tag": 0.0, "tage": round(tage_da, 1), "stunden_aktiv": 0, "laengste_luecke_h": None, "bot": False, "umsatz": 0.0, "closed_pnl": 0.0, "bester_coin": None}
            continue
        st = sorted(d["stunden"]); luecke = 0
        for i in range(1, len(st)):
            luecke = max(luecke, (st[i] - st[i - 1]) // 3600 - 1)
        if st:
            luecke = max(luecke, (st[0] - seit) // 3600, (bis - st[-1]) // 3600 - 1)
        bot = bool(st) and tage_da >= 5 and luecke <= BOT_MAX_LUECKE_H
        coins = d["coins"]
        best = max(coins.items(), key=lambda kv: (kv[1][0], kv[1][1]))[0] if coins else None
        out[a] = {"trades_tag": round(d["n"] / tage_da, 1), "tage": round(tage_da, 1), "stunden_aktiv": len(st), "laengste_luecke_h": luecke,
                  "bot": bot, "umsatz": d["umsatz"], "closed_pnl": d["pnl"], "bester_coin": best}
    return out


def reaktionszeit(kurse: dict, ereignisse: list) -> float | None:
    """Median der Minuten von einer Bewegung >= 1 % in 15 min bis zum nächsten Trade des Kontos (alle Coins)."""
    if not ereignisse:
        return None
    zeiten = sorted(ts for ts, _, _, _ in ereignisse)
    werte = []
    for coin, k in kurse.items():
        if len(k.ts) < 20:
            continue
        for i in range(15, len(k.ts), 5):
            if k.ts[i] - k.ts[i - 15] > 16 * 60:
                continue
            if abs(k.close[i] / k.close[i - 15] - 1.0) >= 0.01:
                t_move = k.ts[i]; j = bisect.bisect_left(zeiten, t_move)
                if j < len(zeiten) and zeiten[j] - t_move <= 6 * 3600:
                    werte.append((zeiten[j] - t_move) / 60.0)
    return statistics.median(werte) if werte else None


def roi_12h(con, addrs, now: int) -> dict:
    """
    Eigene 12-h-Rechnung (U5): realisierter Gewinn Σ closedPnl der Fills der letzten 12 h (nach REST-Nachtrag)
    plus Änderung des unrealisierten Gewinns (jüngste whale_positions-Zeile je Coin gegen die Zeile vor 12 h),
    relativ zum Kontowert. None, wenn für das Konto in 12 h weder Fills mit closedPnl noch Positionszeilen
    vorliegen -- dann gilt Hyperliquids roi_1d.
    """
    out: dict = {}
    if not addrs:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l)); t12 = now - 12 * 3600
    real: dict = {}; hat_fills: set = set()
    try:
        for a, pnl, n in con.execute(f"SELECT lower(addr), SUM(COALESCE(closed_pnl,0)), COUNT(*) FROM lb_fills WHERE ts>=? AND lower(addr) IN ({marks}) GROUP BY 1", (t12, *a_l)):
            real[a] = pnl or 0.0
            if n:
                hat_fills.add(a)
    except sqlite3.OperationalError:
        pass
    upnl_now: dict = {}; upnl_alt: dict = {}
    try:
        # 23.35: jüngster Stand je Position aus 6 h vor dem Stichtag (Snapshot alle 10 min) statt über die ganze Tabelle
        w6 = 6 * 3600
        for a, coin, u in con.execute(f"""SELECT lower(w.addr), w.coin, w.upnl FROM whale_positions w WHERE w.ts>=? AND lower(w.addr) IN ({marks})
                                          AND w.ts=(SELECT MAX(ts) FROM whale_positions x WHERE x.addr=w.addr AND x.coin=w.coin AND x.ts>=?) AND w.event!='close'""",
                                      (now - w6, *a_l, now - w6)):
            upnl_now[(a, coin)] = u or 0.0
        for a, coin, u in con.execute(f"""SELECT lower(w.addr), w.coin, w.upnl FROM whale_positions w WHERE w.ts>=? AND w.ts<=? AND lower(w.addr) IN ({marks})
                                          AND w.ts=(SELECT MAX(ts) FROM whale_positions x WHERE x.addr=w.addr AND x.coin=w.coin AND x.ts>=? AND x.ts<=?)
                                          AND w.event!='close'""", (t12 - w6, t12, *a_l, t12 - w6, t12)):
            upnl_alt[(a, coin)] = u or 0.0
    except sqlite3.OperationalError:
        pass
    av = {}
    try:
        for a, v in con.execute(f"SELECT lower(addr), account_value FROM pool_accounts WHERE lower(addr) IN ({marks})", a_l):
            av[a] = v or 0.0
    except sqlite3.OperationalError:
        pass
    for a in a_l:
        d_upnl = sum(v for (x, c), v in upnl_now.items() if x == a) - sum(v for (x, c), v in upnl_alt.items() if x == a)
        hat_pos = any(x == a for (x, c) in upnl_now) or any(x == a for (x, c) in upnl_alt)
        if a not in hat_fills and not hat_pos:
            out[a] = None; continue
        pnl = real.get(a, 0.0) + d_upnl
        out[a] = {"pnl_12h": pnl, "roi_12h": (pnl / av[a]) if av.get(a) else None, "realisiert": real.get(a, 0.0), "d_upnl": d_upnl}
    return out


# ----------------------------------------------------------------------------------------------
# Gesamtbewertung
# ----------------------------------------------------------------------------------------------
def _mio(v) -> str:
    return f"{(v or 0) / 1e6:+.2f} Mio"


def bewerten(con, now: int | None = None, coins: list | None = None, seed: int = 7, mitglieder=None) -> dict:
    """
    Bewertung aller Pool-Konten (stündlich). 23.37 (Regeln v2): je Konto zwei Urteile mit Gründen -- „aufnahme“ (streng,
    für Nicht-Mitglieder) und „verbleib“ (großzügig, für Mitglieder der Darwin-Liste). mitglieder = aktuelle Liste
    (kleingeschrieben): für sie wird das Timing auch dann gerechnet, wenn sie an der Aufnahme schon vorher scheitern.
    „qualifiziert“ = Aufnahme erfüllt (wie bisher „top“). Mitglieder ohne Bewertung (gesperrt, nicht mehr im Pool) stehen
    mit Grund in „fehlend“. „kleinfill“: von der Neubewertung der Masterregel 23.37 Freigegebene (Recorder, meta); 23.38: ohne
    die zurückgenommenen Freigaben. (Bis 23.37 suchte der Umstieg auf v2 hier auch „ehemalige“ Mitglieder -- v3 kennt keine
    Rückkehr über die Verbleib-Regel mehr.)
    """
    now = now or int(time.time()); seit = now - QUALI_TAGE * 86_400; seit_t = now - TIMING_TAGE * 86_400
    mitglieder = {str(a).lower() for a in (mitglieder or [])}
    coins = coins or [r[0] for r in con.execute("SELECT coin FROM bars WHERE ts>=? GROUP BY coin", (now - 86_400,))]
    try:
        pool = con.execute("SELECT addr, account_value, pnl_7d, roi_7d, pnl_1d, roi_1d, vlm_1d, vlm_7d, name, zuletzt_erfuellt, pnl_30d, roi_30d "
                           "FROM pool_accounts WHERE zuletzt_erfuellt >= ?", (now - 7 * 86_400,)).fetchall()
    except sqlite3.OperationalError:
        try:
            pool = [tuple(r) + (None, None) for r in con.execute("SELECT addr, account_value, pnl_7d, roi_7d, pnl_1d, roi_1d, vlm_1d, vlm_7d, name, "
                                                                  "zuletzt_erfuellt FROM pool_accounts WHERE zuletzt_erfuellt >= ?", (now - 7 * 86_400,))]
        except sqlite3.OperationalError:
            pool = []
    status: dict = {}
    try:
        status = {r[0].lower(): r[1] for r in con.execute("SELECT addr, status FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}   # 23.29
    except sqlite3.OperationalError:
        pass
    gesperrt = set(status)
    kleinfill: dict = {}
    try:
        row = con.execute("SELECT v FROM meta WHERE k='sperre_kleinfill_neubewertung'").fetchone()
        if row and row[0]:
            j = json.loads(row[0])
            kleinfill = {"ts": int(j.get("ts") or 0), "frei": [str(e.get("addr") if isinstance(e, dict) else e).lower() for e in (j.get("frei") or [])],
                         "zurueck": [str(e.get("addr") if isinstance(e, dict) else e).lower() for e in (j.get("zurueckgenommen") or [])],   # 23.38
                         "zurueck_ts": int(j.get("korrektur_ts") or 0)}
    except (sqlite3.OperationalError, ValueError, TypeError):
        pass
    bewerten_auch = mitglieder | set(kleinfill.get("frei") or [])               # Urteile auch für die zu Unrecht Gesperrten
    im_pool = {r[0].lower() for r in pool}
    addrs = [r[0].lower() for r in pool if r[0].lower() not in gesperrt]
    akt = aktivitaet(con, addrs, seit, now)
    info = {r[0].lower(): r for r in pool}

    def aufnahme_vorab(a):                                              # billige Prüfungen vor der Timing-Rechnung
        r, ak = info[a], akt[a]
        return PROFI_MIN_TRADES <= ak["trades_tag"] <= PROFI_MAX_TRADES and (r[2] or 0) > 0 and (r[10] or 0) > 0

    def verbleib_vorab(a):
        r, ak = info[a], akt[a]
        return VERBLEIB_MIN_TRADES <= ak["trades_tag"] <= PROFI_MAX_TRADES and (r[10] is None or r[10] > 0)
    kand = [a for a in addrs if aufnahme_vorab(a) or (a in bewerten_auch and verbleib_vorab(a))]
    quellen: dict = {}
    ereignisse = lade_ereignisse(con, kand, coins, seit_t, now, quellen)
    kurse = {c: Kurs(con, c, seit_t, now) for c in coins}
    rng = random.Random(seed)
    konten = []
    for a in addrs:
        r = info[a]; ak = akt[a]
        rec = {"addr": a, "name": r[8] or "", "account_value": r[1], "pnl_7d": r[2], "roi_7d": r[3], "pnl_1d": r[4], "roi_1d": r[5],
               "vlm_1d": r[6], "vlm_7d": r[7], "pnl_30d": r[10], "roi_30d": r[11], **ak, "gruende": [], "gruende_verbleib": [],
               "qualifiziert": False, "aufnahme": False, "verbleib": False, "mitglied": a in mitglieder,
               "n_exits": 0, "exit_lift": None, "exit_t": None, "entry_lift": None, "entry_t": None, "reaktion_min": None}
        g, gv = rec["gruende"], rec["gruende_verbleib"]
        tr = ak["trades_tag"]
        if tr < PROFI_MIN_TRADES:
            g.append(f"nur {tr:.0f} Trades/Tag in den verfolgten Coins (mind. {PROFI_MIN_TRADES})")
        elif tr > PROFI_MAX_TRADES:
            g.append(f"{tr:.0f} Trades/Tag (Grenze {PROFI_MAX_TRADES})")
        if tr < VERBLEIB_MIN_TRADES:
            gv.append(f"nur {tr:.1f} Trades/Tag in den verfolgten Coins (Verbleib mind. {VERBLEIB_MIN_TRADES})")
        elif tr > PROFI_MAX_TRADES:
            gv.append(f"{tr:.0f} Trades/Tag (Grenze {PROFI_MAX_TRADES})")
        if (r[2] or 0) <= 0:
            g.append(f"Gewinn 7 T {_mio(r[2])} (mind. > 0)")
        if r[10] is None:
            g.append("Gewinn 30 T unbekannt (Aufnahme verlangt > 0)")
        elif r[10] <= 0:
            g.append(f"Gewinn 30 T {_mio(r[10])} (mind. > 0)")
            gv.append(f"Gewinn 30 T {_mio(r[10])} (Verbleib > 0)")
        if a in kand:
            ev = ereignisse.get(a, [])
            l = bewerte_konto(con, a, ev, kurse, seit_t, now, rng)
            rec.update({k: v for k, v in l.items()})
            rec["reaktion_min"] = reaktionszeit(kurse, ev)
            t_ = l.get("timing") or {}
            n_, p_, ls_ = t_.get("n") or 0, (t_.get("p_glueck") if t_.get("p_glueck") is not None else 1.0), (t_.get("lift_s") or 0.0)
            bilanz = (f"{t_.get('treffer', 0)} von {n_} Ein-/Ausstiegen richtig (Zufall {(t_.get('zufall') or 0) * 100:.0f} %)" if n_ else "")
            if n_ < AUFNAHME_MIN_ENTSCH:                                  # 23.32: Ein- und Ausstiege zusammen; 23.37: 14 Tage
                g.append(f"nur {n_} bewertbare Ein-/Ausstiege in {TIMING_TAGE} T (Aufnahme mind. {AUFNAHME_MIN_ENTSCH})")
            elif not (p_ <= AUFNAHME_P_GLUECK and ls_ > 0):
                g.append(f"{bilanz} -- Glückswahrscheinlichkeit {p_ * 100:.1f} % (Aufnahme ≤ {AUFNAHME_P_GLUECK * 100:.0f} %)")
            elif ls_ < AUFNAHME_MIN_VORSPRUNG:
                g.append(f"{bilanz} -- Vorsprung nur {ls_ * 100:.0f} Punkte über dem Zufall (Aufnahme mind. {AUFNAHME_MIN_VORSPRUNG * 100:.0f})")
            if n_ < VERBLEIB_MIN_ENTSCH:
                gv.append(f"nur {n_} bewertbare Ein-/Ausstiege in {TIMING_TAGE} T (Verbleib mind. {VERBLEIB_MIN_ENTSCH})")
            elif not (p_ <= VERBLEIB_P_GLUECK and ls_ > 0):
                gv.append(f"{bilanz} -- Timing nicht mehr über dem Zufall (Glück {p_ * 100:.0f} %, Verbleib ≤ {VERBLEIB_P_GLUECK * 100:.0f} %)")
            # Einstiege nur als Veto (23.32): ab ENTRY_VETO_MIN Einstiegen und belegbar FALSCHEM Einstiegs-Timing (Entry-Lift < 0, t ≤ −1)
            if (l.get("n_entries") or 0) >= ENTRY_VETO_MIN and l["entry_lift"] is not None and l["entry_lift"] < 0 and (l["entry_t"] or 0) <= -T_MIN:
                veto = f"Entry-Lift {l['entry_lift'] * 100:+.0f} pp, t {l['entry_t']:.1f} (Einstiege belegbar vor Gegenbewegungen)"
                g.append(veto); gv.append(veto)
            rec["aufnahme"] = not g
            rec["verbleib"] = not gv
        elif not gv and a in bewerten_auch:
            gv.append("Timing nicht gerechnet")                           # kann nicht vorkommen (verbleib_vorab), zur Sicherheit
        rec["qualifiziert"] = rec["aufnahme"]
        konten.append(rec)
    fehlend: dict = {}
    for a in bewerten_auch:
        if a in gesperrt:
            fehlend[a] = "vorläufig gesperrt (Masterregel)" if status.get(a) == "vorlaeufig" else "gesperrt (Masterregel)"
        elif a not in im_pool:
            fehlend[a] = "nicht mehr im Pool (Kriterien der Leaderboard-Datei seit 7 Tagen nicht erfüllt)"
    quali = [k for k in konten if k["qualifiziert"]]
    r12 = roi_12h(con, [k["addr"] for k in quali], now)
    n_eigen = 0
    for k in quali:
        e = r12.get(k["addr"])
        k["roi_12h"] = e["roi_12h"] if e else None; k["pnl_12h"] = e["pnl_12h"] if e else None
        k["rang_wert"] = k["roi_12h"] if (e and e["roi_12h"] is not None) else (k["roi_1d"] if k["roi_1d"] is not None else -1e9)
        k["rang_quelle"] = "12 h eigen" if (e and e["roi_12h"] is not None) else "HL 1 T"
        n_eigen += 1 if k["rang_quelle"] == "12 h eigen" else 0
    quali.sort(key=lambda k: -k["rang_wert"])
    stempel = now // (12 * 3600) * (12 * 3600)
    return {"ts": now, "stempel": stempel, "regel": REGEL_VERSION,
            "rang_basis": f"ROI 12 h aus eigenen Daten (Σ closedPnl 12 h + Δ uPnL) für {n_eigen} von {len(quali)}; Konten ohne Nachtrag: Hyperliquids roi_1d",
            "n_pool": len(pool), "n_gesperrt": sum(1 for r in pool if r[0].lower() in gesperrt),
            "n_aktiv": sum(1 for a in addrs if aufnahme_vorab(a)), "n_qualifiziert": len(quali),
            "n_mitglieder": len(mitglieder), "n_verbleib": sum(1 for k in konten if k["mitglied"] and k["verbleib"]),
            "quellen": {n_: quellen.get(t_, 0) for t_, n_ in QUELLEN}, "n_mit_ereignissen": sum(1 for a in kand if ereignisse.get(a)),
            "gruende": grund_zaehlung(konten), "coins": coins, "top": quali[:20], "alle": konten, "fehlend": fehlend, "kleinfill": kleinfill}


def darwin_tag(st: dict, r: dict, now: int | None = None) -> dict:
    """
    Darwin-Liste (Entscheidung Nutzer 24.09., Regeln v2 ab 23.37, v3 ab 23.38) -- reine Funktion auf dem gespeicherten Stand st
    und der stündlichen Bewertung r; ändert st und gibt es zurück (Feld „_geaendert“: speichern nötig).
    - Jeder Weg auf die Liste verlangt die strenge Aufnahme; wer so hineinkam, steht in st["streng"] (Adresse -> Zeitpunkt).
    - Einmal täglich (erste Bewertung nach 00 UTC): Mitglieder mit erfülltem Verbleib -> Fehltage 0; sonst Fehltag + 1 und nach
      DARWIN_ABSTIEG_TAGE in Folge Abstieg (die Schonung der streng Aufgenommenen). Nicht-Mitglieder mit erfüllter Aufnahme ->
      aufgenommen. Ein Mitglied ohne Merker „streng“ (kann nach dem Umstieg nicht mehr vorkommen) bleibt nur mit Aufnahme.
    - Umstieg auf REGEL_VERSION (einmalig, sofort): Merker „streng“ aus dem Protokoll (Zugänge über die Aufnahme-Regel unter v2);
      Mitglieder ohne ihn (Altbestand aus v1, Rückkehr über die Verbleib-Regel beim Umstieg auf v2) bleiben nur, wenn sie die
      Aufnahme jetzt erfüllen, sonst sofort Abgang mit Grund; dann Aufnahme nach den Regeln. Fehltage der übrigen bleiben stehen.
    - Rückkehr (sofort, je Neubewertung einmal): Konten, die die Neubewertung der Masterregel 23.37 freigegeben hat (sie flogen
      wegen des Zählfehlers 23.34–23.36 hinaus), kommen zurück, wenn sie die Aufnahme-Regel erfüllen (v2: die Verbleib-Regel).
    - Protokoll der Zu- und Abgänge mit Grund, DARWIN_PROTOKOLL_TAGE Tage; Grund des letzten Fehltags je Mitglied.
    """
    now = int(now or r.get("ts") or time.time())
    for k_, v_ in (("liste", []), ("seit", {}), ("verfehlt", {}), ("grund", {}), ("zugaenge", []), ("abgaenge", []), ("streng", {})):
        st.setdefault(k_, v_)
    alle = {k["addr"]: k for k in (r.get("alle") or [])}
    fehlend = r.get("fehlend") or {}
    tag = now // 86_400
    geaendert = False

    def name_(a):
        return (alle.get(a) or {}).get("name") or ""

    def rein(a, grund):
        nonlocal geaendert
        if a in st["liste"]:
            return
        st["liste"].append(a); st["seit"][a] = now; st["verfehlt"][a] = 0; st["grund"].pop(a, None); st["streng"][a] = now
        st["zugaenge"].append({"addr": a, "name": name_(a), "ts": now, "grund": grund}); geaendert = True

    def raus(a, grund):
        nonlocal geaendert
        st["liste"] = [x for x in st["liste"] if x != a]
        for k_ in ("seit", "verfehlt", "grund", "streng"):
            st[k_].pop(a, None)
        st["abgaenge"].append({"addr": a, "name": name_(a), "ts": now, "grund": grund}); geaendert = True

    def aufnahme_grund(a):
        k = alle.get(a)
        if not k:
            return fehlend.get(a) or "nicht bewertet (gesperrt oder nicht mehr im Pool)"
        return None if k.get("aufnahme") else (k.get("gruende") or ["Aufnahme-Regel verfehlt"])[0]

    def verbleib_grund(a):
        k = alle.get(a)
        if not k:
            return fehlend.get(a) or "nicht bewertet (gesperrt oder nicht mehr im Pool)"
        if k.get("verbleib"):
            return None
        return (k.get("gruende_verbleib") or ["Verbleib-Regel verfehlt"])[0]
    if st.get("regel") != REGEL_VERSION:
        st["regel"] = REGEL_VERSION; geaendert = True
        for e in st["zugaenge"]:                                        # v2: wer über die Aufnahme-Regel kam, behält die Schonung
            a = e.get("addr")
            if a in st["liste"] and str(e.get("grund") or "").startswith("Aufnahme"):
                st["streng"].setdefault(a, int(e.get("ts") or now))
        for a in list(st["liste"]):
            if a in st["streng"]:
                continue
            g = aufnahme_grund(a)
            if g is None:
                st["streng"][a] = now                                   # erfüllt die strenge Aufnahme jetzt
            else:
                raus(a, f"Umstieg auf die Regeln v{REGEL_VERSION}: ohne strenge Aufnahme auf der Liste (Altbestand oder Rückkehr über "
                        f"die Verbleib-Regel) und Aufnahme jetzt nicht erfüllt -- {g}")
        for a, k in alle.items():
            if k.get("aufnahme"):
                rein(a, f"Aufnahme beim Umstieg auf die Regeln v{REGEL_VERSION}")
    kf = r.get("kleinfill") or {}
    if kf.get("ts") and kf["ts"] != st.get("kleinfill_ts"):
        st["kleinfill_ts"] = kf["ts"]; geaendert = True
        for a in kf.get("frei") or []:
            if a not in st["liste"] and (alle.get(a) or {}).get("aufnahme"):
                rein(a, "zurück: zu Unrecht gesperrt (Zählfehler der Masterregel 23.34–23.36), Aufnahme-Regel erfüllt")
    if st.get("tag") != tag:
        for a in list(st["liste"]):
            if a not in st["streng"]:                                   # Sicherheitsnetz: ohne strenge Aufnahme keine Schonung
                g = aufnahme_grund(a)
                if g is None:
                    st["streng"][a] = now
                else:
                    raus(a, f"ohne strenge Aufnahme auf der Liste und Aufnahme nicht erfüllt -- {g}")
                    continue
            g = verbleib_grund(a)
            if g is None:
                st["verfehlt"][a] = 0; st["grund"].pop(a, None)
            else:
                st["verfehlt"][a] = int(st["verfehlt"].get(a, 0)) + 1; st["grund"][a] = g
                if st["verfehlt"][a] >= DARWIN_ABSTIEG_TAGE:
                    raus(a, f"{DARWIN_ABSTIEG_TAGE} Tage in Folge ohne Verbleib -- zuletzt: {g}")
        for a, k in alle.items():
            if k.get("aufnahme"):
                rein(a, "Aufnahme-Regel erfüllt")
        st["tag"] = tag; geaendert = True
    fremd = [a for a in st["streng"] if a not in st["liste"]]
    for a in fremd:                                                     # Merker nur für Mitglieder
        st["streng"].pop(a, None); geaendert = True
    grenze = now - DARWIN_PROTOKOLL_TAGE * 86_400
    for k_ in ("zugaenge", "abgaenge"):
        kurz = [e for e in st[k_] if int(e.get("ts") or 0) >= grenze][-100:]
        if len(kurz) != len(st[k_]):
            st[k_] = kurz; geaendert = True
    st["_geaendert"] = geaendert
    return st


# ----------------------------------------------------------------------------------------------
# U136 (23.57): Schatten der Darwin-Liste -- Beinahe-Aufnahmen vorwärts, gegen eine Kontrollgruppe
# ----------------------------------------------------------------------------------------------
# Vorab festgelegt am 07.10.2026 (KONZEPT_Aktive_Profis.md Abschnitt 11), bevor ein Ergebnis zu sehen ist. Eigener Stand im
# Prognosespeicher (learned „*“/„darwin_schatten“), nur Bericht (check_profis); Liste, Labor und Familien lesen ihn nicht.
# Warum eine Kontrollgruppe: Konten handeln eher in bewegten Phasen, dann treffen auch Ein-/Ausstiege OHNE Können öfter als die
# Zufallsquote aus beliebigen Zeitpunkten (Simulation: Bias +4 Punkte -> gegen die Zufallsquote allein 25 % Fehlurteile, gegen
# die Kontrolle 3 %). Im Pool vom 06.10. trafen 68 geprüfte Konten 28,1 % gegen 24,6 % Zufall -- Können, Auswahl nach Gewinn
# oder dieser Bias, das trennt erst der Vergleich vorwärts.
SCHATTEN_BAENDER = (("1", 0.01, "Glück ≤ 1 % (Aufnahme)"), ("3", 0.03, "Glück 1–3 %"), ("5", 0.05, "Glück 3–5 %"))
SCHATTEN_KONTROLLE = "k"
SCHATTEN_NAMEN = {**{g: n for g, _, n in SCHATTEN_BAENDER}, SCHATTEN_KONTROLLE: "Kontrolle: Glück über 5 %"}
SCHATTEN_AUSWERTUNG = ("2026-11-18", "2026-12-16")   # Urteil am ersten Termin; reichen die Daten dann nicht, am zweiten
SCHATTEN_MIN_ENTSCH = 60                             # vorwärts im Band 1–3 % (und in der Kontrolle) ...
SCHATTEN_MIN_KONTEN = 3                              # ... aus mindestens so vielen Konten
SCHATTEN_MIN_MEHR = 0.05                             # Mehr-Treffer gegen die Kontrolle mindestens 5 Punkte
SCHATTEN_P = 0.05                                    # einseitig
SCHATTEN_MAX_KONTEN = 800
SCHATTEN_SEED = 11


def _tag_ts(s: str) -> int:
    return calendar.timegm(time.strptime(s, "%Y-%m-%d"))


def schatten_gruppe(k: dict, mitglied: bool = False):
    """
    Gruppe eines bewerteten Kontos (Eintrag aus bewerten()["alle"]): „1“, „3“, „5“ = alle Bedingungen der Aufnahme außer der
    Glücksschwelle erfüllt (Aktivität, Gewinn 7 T und 30 T, ≥ 6 Ein-/Ausstiege, Vorsprung ≥ 10 Punkte, kein Einstiegs-Veto) und
    Glück ≤ 1 / 3 / 5 % -- „1“ ist genau die Aufnahme; „k“ (Kontrolle) = ebenso geprüft (Aktivität, Gewinn, ≥ 6, kein Veto), Glück
    über 5 %; sonst None. Mitglieder der Darwin-Liste nur in „1“ (sonst lägen Bewährte in der Kontrolle).
    """
    t = k.get("timing") or {}
    n = t.get("n") or 0; p = t.get("p_glueck"); ls = t.get("lift_s")
    if n < AUFNAHME_MIN_ENTSCH or p is None or ls is None:
        return None
    if any(("Glückswahrscheinlichkeit" not in g and "Vorsprung nur" not in g) for g in (k.get("gruende") or [])):
        return None                                                   # Aktivität, Gewinn 7 T / 30 T, Einstiegs-Veto
    if p <= SCHATTEN_BAENDER[-1][1]:
        if ls < AUFNAHME_MIN_VORSPRUNG:
            return None
        g = next(g_ for g_, grenze, _ in SCHATTEN_BAENDER if p <= grenze)
    else:
        g = SCHATTEN_KONTROLLE
    return g if (g == "1" or not mitglied) else None


def schatten_tag(sch: dict, r: dict, now=None, mitglieder=()) -> dict:
    """
    Einmal täglich (erster Lauf nach 00 UTC): jedes bewertete Konto in seine Gruppe eintragen -- beim ERSTEN Mal mit Zeitpunkt
    („seit“) und Glück, Ein-/Ausstiegen und Zufallsquote dieses Tages. Ein Band bleibt (eine spätere Bilanz ändert die Gruppe nicht,
    sonst wählte man nach dem Ergebnis aus); aus der Kontrolle führt genau ein Weg in ein Band, ab dann zählt das Konto dort.
    Reine Funktion auf dem gespeicherten Stand; Feld „_geaendert“.
    """
    now = int(now or r.get("ts") or time.time()); tag = now // 86_400
    sch.setdefault("v", 1); sch.setdefault("konten", {})
    if sch.get("tag") == tag:
        sch["_geaendert"] = False
        return sch
    sch.setdefault("start", now)
    mit = {str(a).lower() for a in mitglieder}
    for k in r.get("alle") or []:
        a = str(k["addr"]).lower(); g = schatten_gruppe(k, a in mit)
        if g is None:
            continue
        t = k.get("timing") or {}
        e = sch["konten"].get(a)
        if e is None or (e["ab"][-1]["g"] == SCHATTEN_KONTROLLE and g != SCHATTEN_KONTROLLE):
            ab = {"g": g, "seit": now, "p0": round(float(t.get("p_glueck")), 5), "n0": int(t.get("n") or 0), "k0": int(t.get("treffer") or 0),
                  "z0": t.get("zufall"), "f": [0, 0, 0.0, 0.0], "tage": 1, "zuletzt": now}
            if e is None:
                if len(sch["konten"]) >= SCHATTEN_MAX_KONTEN:
                    continue
                sch["konten"][a] = {"name": k.get("name") or "", "ab": [ab], "lb": {}}
            else:
                e["ab"].append(ab)
        elif e["ab"][-1]["g"] == g:
            e["ab"][-1]["tage"] += 1; e["ab"][-1]["zuletzt"] = now
    sch["tag"] = tag; sch["_geaendert"] = True
    return sch


def _schatten_abschnitt(e: dict, ts: int):
    """Abschnitt, in dem eine Entscheidung zählt: der letzte, der VOR ihr begann (strikt vorwärts)."""
    for ab in reversed(e["ab"]):
        if ts > ab["seit"]:
            return ab
    return None


def schatten_buchen(e: dict, ts: int, faellt: bool, treffer: int, erw: float) -> bool:
    """Eine bewertete Entscheidung vorwärts buchen -- je Konto, Richtung und 4-h-Block einmal (wie timing_beleg), Quote wie dort
    auf [1 %, 99 %] begrenzt. f = [Entscheidungen, Treffer, Σ Zufallsquote, Σ q(1−q)]."""
    ab = _schatten_abschnitt(e, ts)
    if ab is None:
        return False
    blk = int(ts) // TIMING_BLOCK; key = "1" if faellt else "0"
    if e["lb"].get(key) == blk:
        return False
    e["lb"][key] = blk
    q = min(max(float(erw), 0.01), 0.99)
    f = ab["f"]; f[0] += 1; f[1] += int(treffer); f[2] += q; f[3] += q * (1 - q)
    return True


def _entscheidung(k, pc, ts: int, art: str, side: str, bis: int):
    """Wie in bewerte_konto: (fällt, Treffer 0/1, Zufallsquote) oder None (ohne gültige Seite, ohne Daten, 12-h-Fenster offen)."""
    if side not in ("long", "short") or not k or not k.ts or not pc or ts + HORIZONT > bis:
        return None
    faellt = (art == "exit") == (side == "long")
    v = k.rueckgang_binnen(ts, HORIZONT) if faellt else k.anstieg_binnen(ts, HORIZONT)
    erw = pc[0] if faellt else pc[1]
    if v is None or erw is None:
        return None
    return faellt, (1 if ((v <= -KORREKTUR) if faellt else (v >= KORREKTUR)) else 0), erw


def schatten_entscheidungen(con, sch: dict, now=None, coins=None, seed: int = SCHATTEN_SEED, pl=None, kurse=None) -> dict:
    """
    Vorwärts-Bilanz fortschreiben: Ein-/Ausstiege der Schatten-Konten im Fenster (bis, now − 12 h] -- nur, was NACH dem Eintritt in
    die Gruppe lag; das 12-h-Fenster ist dann vorbei. Treffer und Zufallsquote wie bewerte_konto (Placebo je Coin und Richtung aus
    200 Zeitpunkten der letzten 14 Tage). „bis“ rückt vor, so zählt jede Entscheidung genau einmal; nachgeholt wird höchstens
    14 Tage. Die 15-min-Doppelerkennung von lade_ereignisse sieht auch die Viertelstunde vor dem Fenster.
    """
    now = int(now or time.time()); obere = now - HORIZONT
    untere = max(int(sch.get("bis") or 0), now - TIMING_TAGE * 86_400)
    sch.setdefault("konten", {})
    if obere <= untere:
        return sch
    if sch["konten"]:
        seit_t = now - TIMING_TAGE * 86_400
        if coins is None:
            coins = [r_[0] for r_ in con.execute("SELECT coin FROM bars WHERE ts>=? GROUP BY coin", (now - 86_400,))]
        ev = lade_ereignisse(con, list(sch["konten"]), coins, untere - DOPPEL_S, obere)
        if ev:
            if kurse is None:
                kurse = {c: Kurs(con, c, seit_t, now) for c in coins}
            if pl is None:
                pl = placebo_berechnen(kurse, seit_t, now, random.Random(seed))
            for a, liste in ev.items():
                e = sch["konten"].get(a)
                if not e:
                    continue
                for ts, coin, art, side in liste:
                    if ts <= untere:
                        continue                                      # nur für die Doppelerkennung geladen
                    x = _entscheidung(kurse.get(coin), pl[0].get(coin), ts, art, side, now)
                    if x:
                        schatten_buchen(e, ts, *x)
    sch["bis"] = obere
    return sch


def schatten_summen(sch: dict, ohne=None) -> dict:
    """{Gruppe: {n, k, e, v, konten (mit Entscheidungen), eingetragen}} über alle Abschnitte; ohne = eine Adresse auslassen."""
    out = {g: {"n": 0, "k": 0, "e": 0.0, "v": 0.0, "konten": 0, "eingetragen": 0} for g in SCHATTEN_NAMEN}
    for a, e in (sch.get("konten") or {}).items():
        if a == ohne:
            continue
        for ab in e["ab"]:
            o = out[ab["g"]]; f = ab["f"]
            o["eingetragen"] += 1
            if f[0]:
                o["n"] += f[0]; o["k"] += f[1]; o["e"] += f[2]; o["v"] += f[3]; o["konten"] += 1
    return out


def _mehr(o: dict):
    return (o["k"] - o["e"]) / o["n"] if o["n"] else None


def _vergleich(B: dict, C: dict):
    """Δ = Mehr-Treffer(B) − Mehr-Treffer(C), Streuung aus Σ q(1−q) beider Gruppen, einseitiger z-Test -> (Δ, se, p)."""
    if not B["n"] or not C["n"]:
        return None, None, None
    d = _mehr(B) - _mehr(C)
    se = math.sqrt(B["v"] / B["n"] ** 2 + C["v"] / C["n"] ** 2)
    p = 0.5 * math.erfc(d / se / math.sqrt(2)) if se > 0 else (0.0 if d > 0 else 1.0)
    return d, se, p


def schatten_urteil(sch: dict, now=None) -> dict:
    """
    Vorab festgelegt (KONZEPT_Aktive_Profis.md 11): Mehr-Treffer je Gruppe = (richtig − Zufall) / Entscheidungen; Δ = Band 1–3 %
    minus Kontrolle. „Timing belegt“ nur mit Δ ≥ 5 Punkten, p < 0,05 (einseitig), mindestens 60 Entscheidungen aus mindestens 3
    Konten im Band und 60 in der Kontrolle UND Δ > 0 auch ohne jedes einzelne Konto des Bands. Urteil erst ab dem ersten Termin;
    reichen die Daten dann nicht, am zweiten; davor nur Zwischenstand. Nebenbei (ohne Urteil): 1–5 % zusammen und ≤ 1 % gegen
    die Kontrolle.
    """
    now = int(now or time.time())
    S = schatten_summen(sch)
    B, C = S["3"], S[SCHATTEN_KONTROLLE]
    d, se, p = _vergleich(B, C)
    loo = []
    for a, e in (sch.get("konten") or {}).items():
        if any(ab["g"] == "3" and ab["f"][0] for ab in e["ab"]):
            S2 = schatten_summen(sch, ohne=a)
            loo.append((a, _vergleich(S2["3"], S2[SCHATTEN_KONTROLLE])[0]))
    loo_ok = bool(loo) and all(x is not None and x > 0 for _, x in loo)
    entscheidbar = B["n"] >= SCHATTEN_MIN_ENTSCH and B["konten"] >= SCHATTEN_MIN_KONTEN and C["n"] >= SCHATTEN_MIN_ENTSCH
    t1, t2 = (_tag_ts(x) for x in SCHATTEN_AUSWERTUNG)
    belegt = bool(entscheidbar and d is not None and d >= SCHATTEN_MIN_MEHR and p < SCHATTEN_P and loo_ok)
    if now < t1:
        urteil = "Zwischenstand"
    elif not entscheidbar:
        urteil = "noch nicht entscheidbar" if now < t2 else "nicht entscheidbar"
    else:
        urteil = "Timing belegt" if belegt else "nicht belegt"
    S15 = {k_: S["3"][k_] + S["5"][k_] for k_ in ("n", "k", "e", "v", "konten")}
    return {"summen": S, "mehr": {g: _mehr(o) for g, o in S.items()}, "delta": d, "se": se, "p": p, "loo": loo, "loo_ok": loo_ok,
            "entscheidbar": entscheidbar, "belegt": belegt, "urteil": urteil,
            "nebenbei": {"1–5 %": _vergleich(S15, C), "≤ 1 %": _vergleich(S["1"], C)}}


def schatten_text(sch: dict, now=None) -> list:
    """Zeilen für check_profis: je Gruppe Konten, Entscheidungen, richtig, Zufall, Mehr-Treffer; Vergleich, Regel, Urteil, Konten."""
    now = int(now or time.time())
    d_ = lambda ts: time.strftime("%d.%m.%Y", time.localtime(int(ts))) if ts else "—"
    z = lambda x, n=1: ("—" if x is None else f"{x:+.{n}f}").replace(".", ",")              # mit Vorzeichen, Dezimalkomma
    zn = lambda x, n=1: ("—" if x is None else f"{x:.{n}f}").replace(".", ",")               # ohne Vorzeichen
    if not (sch or {}).get("konten"):
        return ["Schatten der Darwin-Liste (U136): noch nichts eingetragen -- das Dashboard trägt bei seiner nächsten (stündlichen) "
                "Bewertung ein, danach einmal täglich nach 00 UTC; vorwärts gezählt wird ab dem Eintrag (12-h-Fenster abgewartet), die ersten "
                "Zahlen stehen nach ein bis zwei Tagen hier."]
    U = schatten_urteil(sch, now)
    zl = [f"Schatten der Darwin-Liste (U136) seit {d_(sch.get('start'))}: Ein- und Ausstiege NACH dem Eintritt in die Gruppe, richtig wie oben, "
          f"gegen eine Kontrollgruppe; ausgewertet bis {time.strftime('%d.%m. %H:%M', time.localtime(int(sch.get('bis') or 0)))} -- "
          "wirkt nicht auf Liste, Labor oder Familien.",
          f"   {'Gruppe':<28}{'Konten (mit Entsch.)':>21}{'Entsch.':>9}{'richtig':>9}{'Zufall':>8}   Mehr-Treffer (± 1 SE)"]
    for g, o in U["summen"].items():                                  # 23.58: „Konten“ und „mit Entsch.“ lasen sich als eine Spalte
        m = U["mehr"][g]; se_ = math.sqrt(o["v"]) / o["n"] if o["n"] else None
        kk = f"{o['eingetragen']} ({o['konten']})"
        zl.append(f"   {SCHATTEN_NAMEN[g]:<28}{kk:>21}{o['n']:>9}{o['k']:>9}{zn(o['e']):>8}   "
                  + (f"{z(m * 100)} ± {zn(se_ * 100)} Punkte" if m is not None else "—"))
    if U["delta"] is not None:
        lo = [x for _, x in U["loo"] if x is not None]
        zl.append(f"   Band 1–3 % gegen Kontrolle: Δ {z(U['delta'] * 100)} Punkte ± {zn(U['se'] * 100)} (p {zn(U['p'], 3)})"
                  + (f"; ohne je ein Konto des Bands: Δ von {z(min(lo) * 100)} bis {z(max(lo) * 100)}" if lo else "")
                  + "".join(f" · nebenbei {k_} gegen Kontrolle: Δ {z(v[0] * 100)} ± {zn(v[1] * 100)} (p {zn(v[2], 3)})"
                            for k_, v in U["nebenbei"].items() if v[0] is not None))
    t1, t2 = SCHATTEN_AUSWERTUNG
    zl.append(f"   Vorab festgelegt (KONZEPT_Aktive_Profis.md 11): „Timing belegt“ nur mit Δ ≥ {SCHATTEN_MIN_MEHR * 100:.0f} Punkten, p < "
              f"{zn(SCHATTEN_P, 2)}, ≥ {SCHATTEN_MIN_ENTSCH} Entscheidungen aus ≥ {SCHATTEN_MIN_KONTEN} Konten im Band (Kontrolle ≥ {SCHATTEN_MIN_ENTSCH}) "
              f"und Δ > 0 ohne jedes einzelne Konto; Urteil am {d_(_tag_ts(t1))}, reichen die Daten nicht, am {d_(_tag_ts(t2))}.")
    urteil = U["urteil"]
    if urteil == "Zwischenstand":
        zl.append(f"   Jetzt: Zwischenstand -- kein Urteil vor dem {d_(_tag_ts(t1))} (Band {U['summen']['3']['n']} von {SCHATTEN_MIN_ENTSCH} "
                  f"Entscheidungen, {U['summen']['3']['konten']} von {SCHATTEN_MIN_KONTEN} Konten).")
    else:
        zl.append(f"   URTEIL: {urteil}" + (" -- Aufnahme bei Glück ≤ 3 % wäre ein Kandidat für Regeln v4 (neue Labor-Kennung liste=4), "
                                              "Entscheidung beim Nutzer" if urteil == "Timing belegt" else
                                              " -- Aufnahme bleibt bei Glück ≤ 1 %" if urteil == "nicht belegt" else ""))
    nm = lambda a, e: (e.get("name") or "")[:14] or (a[:6] + "…" + a[-4:])
    zb = [(a, e, ab) for a, e in sch["konten"].items() for ab in e["ab"] if ab["g"] != SCHATTEN_KONTROLLE]
    if zb:
        zl.append("   Konten der Bänder (Eintritt, Glück dabei, vorwärts richtig/Entscheidungen, Zufall):")
        for a, e, ab in sorted(zb, key=lambda x: (x[2]["g"], x[2]["seit"])):
            f = ab["f"]
            zl.append(f"     {nm(a, e):<16} {SCHATTEN_NAMEN[ab['g']]:<24} seit {d_(ab['seit'])[:6]}  Glück {zn(ab['p0'] * 100)} %  "
                      f"vorwärts {f[1]}/{f[0]}, Zufall {zn(f[2])}" + (f" · {ab['tage']} Tage in der Gruppe" if ab.get("tage", 1) > 1 else ""))
    return zl


# ----------------------------------------------------------------------------------------------
# Nulltest / Positivtest der Lift-Rechnung
# ----------------------------------------------------------------------------------------------
def _glueck_test() -> tuple:
    """
    23.32/23.37: exakte Glückswahrscheinlichkeit (Beispiele bei 40 % Zufall), die Schwellen der Aufnahme (1 %) und des
    Verbleibs (50 %), die Rangfolge nach gedämpfter Untergrenze und die Fehlalarmrate der Aufnahme an 3.000 Zufallskonten
    (6–30 Entscheidungen, Zufallsquoten 30–50 %).
    """
    q = 0.4
    werte = {"4/4": glueck_p(4, [q] * 4), "3/4": glueck_p(3, [q] * 4), "4/5": glueck_p(4, [q] * 5), "8/10": glueck_p(8, [q] * 10), "7/10": glueck_p(7, [q] * 10),
             "9/10": glueck_p(9, [q] * 10), "12/15": glueck_p(12, [q] * 15), "1/4": glueck_p(1, [q] * 4)}
    soll = {"4/4": 0.0256, "3/4": 0.1792, "4/5": 0.0870, "8/10": 0.0123, "7/10": 0.0548}
    genau = all(abs(werte[k] - soll[k]) < 0.0005 for k in soll)
    auf = lambda k: werte[k] <= AUFNAHME_P_GLUECK
    bleib = lambda k: werte[k] <= VERBLEIB_P_GLUECK
    schwelle = (auf("9/10") and auf("12/15") and not any(auf(k) for k in ("4/4", "8/10", "7/10"))
                and all(bleib(k) for k in ("4/4", "8/10", "7/10", "3/4")) and not bleib("1/4"))
    lcb = lambda k, n: timing_beleg([(1, q, "exit")] * k + [(0, q, "exit")] * (n - k))["lcb"]
    rang = lcb(12, 15) > lcb(8, 10) > lcb(4, 4) > 0
    rng = random.Random(11); fehl = 0; n_k = 3000
    for _ in range(n_k):
        n = rng.randint(6, 30); qs = [rng.uniform(0.3, 0.5) for _ in range(n)]
        tr = sum(1 for x in qs if rng.random() < x)
        if glueck_p(tr, qs) <= AUFNAHME_P_GLUECK:
            fehl += 1
    ok = genau and schwelle and rang and fehl / n_k <= AUFNAHME_P_GLUECK + 0.005
    return ok, (f"Glückswahrscheinlichkeit bei 40 % Zufall: 4/4 {werte['4/4'] * 100:.1f} %, 8/10 {werte['8/10'] * 100:.1f} %, 9/10 {werte['9/10'] * 100:.2f} %, "
                f"12/15 {werte['12/15'] * 100:.2f} %, 1/4 {werte['1/4'] * 100:.0f} % · Aufnahme ≤ {AUFNAHME_P_GLUECK * 100:.0f} % / Verbleib ≤ "
                f"{VERBLEIB_P_GLUECK * 100:.0f} % richtig getrennt: {'ja' if schwelle else 'NEIN'} · Rangfolge 12/15 > 8/10 > 4/4: {'ja' if rang else 'NEIN'} · "
                f"Zufallskonten aufgenommen: {fehl / n_k * 100:.2f} % (Soll ≤ {AUFNAHME_P_GLUECK * 100:.0f} %)")


def _darwin_test() -> tuple:
    """
    23.37/23.38: Tagesentscheidung der Darwin-Liste (darwin_tag) an einer Folge von Bewertungen. Umstieg v2 -> v3: wer unter v2
    über die Aufnahme-Regel kam, behält die Schonung (auch in einer Schwächephase); Altbestand ohne Zugang und die Rückkehr über
    die Verbleib-Regel fliegen sofort mit Grund, außer sie erfüllen die Aufnahme jetzt; neue Aufnahmen sofort; keine
    Tagesentscheidung am selben Tag. Danach: ein streng Aufgenommener mit erfülltem Verbleib bleibt, auch ohne Aufnahme; zwei
    Fehltage und ein erfüllter Tag setzen zurück; drei Fehltage in Folge -> Abstieg mit Grund; ein gesperrtes Mitglied zählt
    Fehltage mit Grund „gesperrt“; Rückkehr zu Unrecht Gesperrter nur mit erfüllter Aufnahme und nur einmal je Neubewertung;
    Sicherheitsnetz für ein Mitglied ohne Merker; mehrere Bewertungen am selben Tag entscheiden nur einmal; Protokoll 14 Tage.
    """
    T = 1_790_640_000 + 3600                                   # 29.09. 01:00 UTC
    S, R, V, W, N, D, E, F, X = ("0xs", "0xr", "0xv", "0xw", "0xn", "0xd", "0xe", "0xf", "0xx")

    def k(a, auf=False, bleib=False, gv="Timing nicht mehr über dem Zufall", ga="Glückswahrscheinlichkeit 11.0 % (Aufnahme ≤ 1 %)"):
        return {"addr": a, "name": a.upper(), "aufnahme": auf, "verbleib": bleib or auf, "gruende": [] if auf else [ga],
                "gruende_verbleib": [] if (bleib or auf) else [gv]}

    def r(t, konten, fehlend=None, kleinfill=None):
        return {"ts": t, "alle": konten, "fehlend": fehlend or {}, "kleinfill": kleinfill or {}}
    # Stand wie auf dem Pi nach 23.37: S streng über den Umstieg auf v2, R über die Verbleib-Regel zurück, V und W Altbestand aus v1
    st = {"regel": 2, "liste": [V, W, S, R], "seit": {V: T - 5 * 86_400, W: T - 4 * 86_400, S: T - 600, R: T - 600},
          "verfehlt": {V: 0, W: 0, S: 1, R: 0}, "grund": {S: "alt"}, "tag": T // 86_400,
          "zugaenge": [{"addr": S, "ts": T - 600, "grund": "Aufnahme beim Umstieg auf die Regeln v2"},
                       {"addr": R, "ts": T - 600, "grund": "zurück beim Umstieg auf die Regeln v2: seit 29.09. auf der Liste gewesen, "
                                                          "Verbleib-Regel erfüllt"}], "abgaenge": []}
    pr = []
    r0 = r(T + 600, [k(V), k(W, auf=True), k(S, bleib=True), k(R, bleib=True), k(N, auf=True)])
    st = darwin_tag(st, r0)
    ab = {e["addr"]: e["grund"] for e in st["abgaenge"]}
    pr.append(("Umstieg: S (streng unter v2) bleibt trotz Schwächephase, W erfüllt die Aufnahme, N neu; R und V raus",
               st["liste"] == [W, S, N] and set(ab) == {V, R} and all("Umstieg auf die Regeln v3" in g and "ohne strenge Aufnahme" in g for g in ab.values())
               and "11.0 %" in ab[R] and st["streng"] == {S: T - 600, W: T + 600, N: T + 600}))
    pr.append(("Umstieg: Fehltage von S bleiben, keine Tagesentscheidung am selben Tag", st["verfehlt"].get(S) == 1 and st["tag"] == T // 86_400))
    st = darwin_tag(st, r0)
    pr.append(("Umstieg nur einmal", st["liste"] == [W, S, N] and len(st["abgaenge"]) == 2 and not st["_geaendert"]))
    t1 = T + 86_400
    st = darwin_tag(st, r(t1, [k(W, bleib=True), k(S), k(N, bleib=True), k(R, bleib=True)]))
    pr.append(("Tag 1: W hält Verbleib (ohne Aufnahme), S zweiter Fehltag mit Grund; R kommt über den Verbleib nicht zurück",
               st["verfehlt"] == {W: 0, S: 2, N: 0} and "Zufall" in st["grund"].get(S, "") and R not in st["liste"]))
    st = darwin_tag(st, r(t1 + 3600, [k(W), k(S), k(N)]))
    pr.append(("Zweite Bewertung am selben Tag entscheidet nicht", st["verfehlt"] == {W: 0, S: 2, N: 0}))
    t2 = t1 + 86_400
    st = darwin_tag(st, r(t2, [k(W, bleib=True), k(N)], fehlend={S: "vorläufig gesperrt (Masterregel)"}))
    abs_ = [e for e in st["abgaenge"] if e["addr"] == S]
    pr.append(("Tag 2: dritter Fehltag (gesperrt) -> Abstieg mit Grund", S not in st["liste"] and len(abs_) == 1 and "3 Tage" in abs_[0]["grund"]
               and "gesperrt" in abs_[0]["grund"] and S not in st["streng"]))
    pr.append(("Tag 2: N erster Fehltag", st["verfehlt"].get(N) == 1))
    t3 = t2 + 86_400
    st = darwin_tag(st, r(t3, [k(W, bleib=True), k(N, bleib=True), k(D, auf=True)], kleinfill={"ts": t3 - 100, "frei": [E, F]}))
    pr.append(("Tag 3: D aufgenommen (streng), erfüllter Tag setzt N zurück", D in st["liste"] and D in st["streng"] and st["verfehlt"].get(N) == 0
               and N not in st["grund"]))
    pr.append(("Rückkehr: E und F fehlen in der Bewertung -> nicht zurück", E not in st["liste"] and F not in st["liste"]))
    st = darwin_tag(st, r(t3 + 3600, [k(W, bleib=True), k(N, bleib=True), k(D, bleib=True), k(E, auf=True), k(F, bleib=True)],
                          kleinfill={"ts": t3 - 100, "frei": [E, F]}))
    pr.append(("Rückkehr nur einmal je Neubewertung", E not in st["liste"]))
    st = darwin_tag(st, r(t3 + 7200, [k(W, bleib=True), k(N, bleib=True), k(D, bleib=True), k(E, auf=True), k(F, bleib=True)],
                          kleinfill={"ts": t3 + 5000, "frei": [E, F]}))
    zu = [e for e in st["zugaenge"] if e["addr"] == E]
    pr.append(("Rückkehr mit Aufnahme (E), mit bloßem Verbleib nicht (F)", E in st["liste"] and F not in st["liste"] and zu
               and "zu Unrecht" in zu[0]["grund"] and E in st["streng"]))
    st["liste"].append(X); st["seit"][X] = t3; st["verfehlt"][X] = 0                  # Sicherheitsnetz: Mitglied ohne Merker
    t4 = t3 + 86_400
    st = darwin_tag(st, r(t4, [k(W, bleib=True), k(N, bleib=True), k(D, bleib=True), k(E, bleib=True), k(X, bleib=True)]))
    ax = [e for e in st["abgaenge"] if e["addr"] == X]
    pr.append(("Mitglied ohne strenge Aufnahme: raus trotz Verbleib", X not in st["liste"] and ax and "ohne strenge Aufnahme" in ax[0]["grund"]))
    st = darwin_tag(st, r(t4 + 16 * 86_400, [k(W, bleib=True), k(N, bleib=True), k(D, bleib=True), k(E, bleib=True)]))
    pr.append(("Protokoll nach 14 Tagen leer, Merker nur für Mitglieder", not st["abgaenge"] and not st["zugaenge"]
               and set(st["streng"]) == set(st["liste"]) == {W, N, D, E}))
    frisch = darwin_tag({}, r(T, [k(N, auf=True), k(W, bleib=True)]))
    pr.append(("Neuer Stand: nur Aufnahmen, alle mit Merker", frisch["liste"] == [N] and frisch["streng"] == {N: T} and frisch["regel"] == REGEL_VERSION))
    ok = all(b for _, b in pr)
    return ok, f"Darwin-Liste v{REGEL_VERSION}: " + " · ".join(f"{n} {'ok' if b else 'FEHL'}" for n, b in pr)


def _richtung_trend_test() -> tuple:
    """
    23.21, fester Zeitpunkt (deterministisch): (1) Richtungslogik -- Long auf vor Anstieg, Short auf vor Rückgang, Long zu vor
    Rückgang, Short zu vor Anstieg (auch Flip) = richtig, die vier Gegenstücke = falsch; (2) Trendfalle -- 60 Short-Schließungen
    zu ZUFÄLLIGEN Zeiten in einem steigenden Markt dürfen keinen belegten Lift bekommen (vorher +41 pp, t 3,2).
    """
    global MIN_EXITS
    t_ende = 1_790_006_400; von = t_ende - 8 * 86_400
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    a_ = t_ende - 5 * 86_400; b_ = t_ende - 3 * 86_400
    rows = []
    for t in range(von, t_ende + 60, 60):
        c = 100.0 * (1.05 if a_ <= t < a_ + 86_400 else 1.0) * (0.95 if b_ <= t < b_ + 86_400 else 1.0)
        rows.append((t, "AAA", c, c, c, c, 1, 1))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    kurse = {"AAA": Kurs(con, "AAA", von, t_ende)}
    faelle = [(a_ - 600, "entry", "long", True), (b_ - 600, "entry", "short", True), (b_ - 600, "exit", "long", True),
              (a_ - 600, "exit", "short", True), (b_ - 600, "entry", "short", True),            # Flip auf Short = Einstieg Short
              (b_ - 600, "entry", "long", False), (a_ - 600, "entry", "short", False), (a_ - 600, "exit", "long", False),
              (b_ - 600, "exit", "short", False)]
    alt = MIN_EXITS; MIN_EXITS = 1; richtig = 0
    try:
        for ts, art, side, soll in faelle:
            o = bewerte_konto(con, "x", [(ts, "AAA", art, side)], kurse, von, t_ende, random.Random(1))
            l_ = o["exit_lift"] if art == "exit" else o["entry_lift"]
            richtig += ((l_ is not None and l_ > 0) == soll)
    finally:
        MIN_EXITS = alt
    con.execute("DELETE FROM bars"); rng = random.Random(5); lp = math.log(100.0); rows = []
    for t in range(von, t_ende + 60, 60):
        lp += rng.gauss(0.00004, 0.0012); c = math.exp(lp)
        rows.append((t, "BBB", c, c, c, c, 1, 1)); rows.append((t, "PAX", 100.0, 100.0, 100.0, 100.0, 1, 1))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    k2 = {c: Kurs(con, c, von, t_ende) for c in ("BBB", "PAX")}
    ev = sorted((rng.randint(t_ende - 7 * 86_400, t_ende - 13 * 3600), "BBB", "exit", "short") for _ in range(60))
    o = bewerte_konto(con, "x", ev, k2, von, t_ende, random.Random(2))
    trend_ok = o["exit_lift"] is not None and (abs(o["exit_lift"]) < 0.15 or (o["exit_t"] or 0) < 2)
    ok = richtig == len(faelle) and trend_ok
    return ok, (f"Richtungslogik {richtig} von {len(faelle)} richtig · Trendfalle: zufällige Short-Schließungen im steigenden Markt "
                f"Lift {(o['exit_lift'] or 0) * 100:+.0f} pp, t {(o['exit_t'] or 0):.1f} (Soll kein Beleg)")


def _quellen_test() -> tuple:
    """
    23.34: Ereignisquellen -- pool_positions wird gelesen; dieselbe Entscheidung aus Wal- und Pool-Abfrage (3 min auseinander)
    zählt einmal, dieselbe Richtung 20 min später wieder; „snap“, fremde Coins und fremde Konten zählen nicht; Großschreibung
    der Adresse stört nicht; eine fehlende Tabelle (ältere Datenbank) auch nicht.
    """
    con = sqlite3.connect(":memory:")
    for tab in ("whale_positions", "lb_events", "pool_positions"):
        con.execute(f"CREATE TABLE {tab} (ts INTEGER, addr TEXT, coin TEXT, event TEXT, side TEXT)")
    t = 1_790_000_000; a = "0x" + "ab" * 20; b = "0x" + "cd" * 20
    con.executemany("INSERT INTO whale_positions VALUES (?,?,?,?,?)", [(t, a.upper().replace("0X", "0x"), "BTC", "open", "long")])
    con.executemany("INSERT INTO pool_positions VALUES (?,?,?,?,?)", [
        (t + 180, a, "BTC", "open", "long"), (t + 1200, a, "BTC", "add", "long"), (t + 3 * 3600, a, "BTC", "reduce", "long"),
        (t + 3 * 3600 + 60, a, "BTC", "snap", "long"), (t + 4 * 3600, a, "DOGE", "open", "short"), (t + 5 * 3600, b, "BTC", "open", "long"),
        (t + 6 * 3600, a, "BTC", "flip", "short")])
    con.executemany("INSERT INTO lb_events VALUES (?,?,?,?,?)", [(t + 6 * 3600 + 120, a, "BTC", "flip", "short"), (t + 8 * 3600, a, "ETH", "close", "short")])
    q: dict = {}
    ev = lade_ereignisse(con, [a], ["BTC", "ETH"], t - 60, t + 86_400, q)
    soll = [(t, "BTC", "entry", "long"), (t + 1200, "BTC", "entry", "long"), (t + 3 * 3600, "BTC", "exit", "long"),
            (t + 6 * 3600, "BTC", "entry", "short"), (t + 8 * 3600, "ETH", "exit", "short")]
    ok1 = ev.get(a) == soll and q == {"whale_positions": 1, "pool_positions": 3, "lb_events": 1} and set(ev) == {a}
    con.execute("DROP TABLE pool_positions")
    ev2 = lade_ereignisse(con, [a], ["BTC", "ETH"], t - 60, t + 86_400)
    ok2 = [e[0] for e in ev2.get(a, [])] == [t, t + 6 * 3600 + 120, t + 8 * 3600]
    return ok1 and ok2, (f"Ereignisquellen: {len(ev.get(a, []))} von 5 erwarteten Ein-/Ausstiegen (Pool {q.get('pool_positions', 0)}, Wal "
                         f"{q.get('whale_positions', 0)}, Leaderboard {q.get('lb_events', 0)}; Doppel, snap, fremder Coin, fremdes Konto verworfen) · "
                         f"ohne pool_positions {len(ev2.get(a, []))} von 3")


def _schatten_sim(seed: int, M: int = 150, n_gut: int = 0, s: float = 0.15, b: float = 0.04, tage: int = 56, ab: int = 14) -> dict:
    """
    U136: Pool im Modell, durch die echten Funktionen (schatten_gruppe, schatten_tag, schatten_buchen). M Konten, davon n_gut mit
    Können s; Entscheidungen Poisson (Median 1,1 je Tag), Zufallsquote je Entscheidung U(0,08; 0,58), Treffer mit q + b + s -- b ist
    der Bias „gehandelt wird in bewegten Phasen“, der für ALLE gilt. Tägliche PnL N(0,3; 1) mit Können, sonst N(0; 1). Eintragen ab
    Tag 14 (14-T-Fenster voll), 42 Tage vorwärts. Glück im Modell mit der mittleren Quote (Binomial) -- schneller, gleiche Rolle.
    """
    rng = random.Random(seed); T0 = _tag_ts("2026-09-23"); sch: dict = {}
    K = [{"lam": math.exp(rng.gauss(math.log(1.1), 0.6)), "ents": [], "pnl": [], "mu": 0.3 if i < n_gut else 0.0, "s": s if i < n_gut else 0.0}
         for i in range(M)]
    for tag in range(tage):
        now = T0 + tag * 86_400 + 3600
        if tag >= ab:
            alle = []
            for i, k in enumerate(K):
                ents = [e for e in k["ents"] if now - TIMING_TAGE * 86_400 < e[0] < now]
                n = len(ents)
                if n < AUFNAHME_MIN_ENTSCH:
                    continue
                kk = sum(e[1] for e in ents); pbar = sum(e[2] for e in ents) / n
                p = sum(math.comb(n, j) * pbar ** j * (1 - pbar) ** (n - j) for j in range(kk, n + 1))
                ls = (kk + M_PSEUDO * pbar) / (n + M_PSEUDO) - pbar
                g = []
                if sum(k["pnl"][-7:]) <= 0:
                    g.append("Gewinn 7 T -0.10 Mio (mind. > 0)")
                if sum(k["pnl"][-30:]) <= 0:
                    g.append("Gewinn 30 T -0.10 Mio (mind. > 0)")
                if not (p <= AUFNAHME_P_GLUECK and ls > 0):
                    g.append(f"{kk} von {n} -- Glückswahrscheinlichkeit {p * 100:.1f} % (Aufnahme ≤ 1 %)")
                elif ls < AUFNAHME_MIN_VORSPRUNG:
                    g.append(f"{kk} von {n} -- Vorsprung nur {ls * 100:.0f} Punkte über dem Zufall (Aufnahme mind. 10)")
                alle.append({"addr": f"0x{i:04x}", "name": "", "gruende": g,
                             "timing": {"n": n, "treffer": kk, "zufall": round(pbar, 3), "p_glueck": p, "lift_s": ls}})
            schatten_tag(sch, {"ts": now, "alle": alle}, now)
        for i, k in enumerate(K):
            L = math.exp(-k["lam"]); n = 0; pr = 1.0
            while True:
                pr *= rng.random()
                if pr < L:
                    break
                n += 1
            e = (sch.get("konten") or {}).get(f"0x{i:04x}")
            for ts in sorted(T0 + tag * 86_400 + rng.randint(0, 86_399) for _ in range(n)):
                q = rng.uniform(0.08, 0.58); faellt = rng.random() < 0.5
                hit = 1 if rng.random() < min(0.95, q + b + k["s"]) else 0
                k["ents"].append((ts, hit, q))
                if e:
                    schatten_buchen(e, ts, faellt, hit, q)
            k["pnl"].append(rng.gauss(k["mu"], 1.0))
    return sch


def _schatten_test(laeufe_null: int = 60, laeufe_pos: int = 30) -> tuple:
    """
    U136 (23.57): (a) Gruppen = Aufnahme bis auf die Glücksschwelle, Kontrolle, Mitglieder; (b) Eintragen: ein Band bleibt, aus der
    Kontrolle genau ein Weg ins Band, einmal je Tag; (c) vorwärts auf Kursdaten: dieselben Treffer und Zufallsquoten wie
    bewerte_konto, nur nach dem Eintritt, in zwei Schritten wie in einem (ein 4-h-Block über die Grenze zählt einmal), der Wechsel
    Kontrolle -> Band teilt die Entscheidungen; (d) Statistik gegen eine Rechnung von Hand, ohne ein Konto, Termine; (e) Simulation:
    ohne Können (mit Bias) selten „belegt“ und nur gegen die Zufallsquote oft, mit Können im halben Pool fast immer.
    """
    pr = []
    # (a) Gruppen
    L = "-- Glückswahrscheinlichkeit {} % (Aufnahme ≤ 1 %)"
    faelle = [  # (n, p, ls, gründe, Mitglied, Soll)
        (10, 0.005, 0.20, [], False, "1"), (13, 0.014, 0.17, [L.format("1.4")], False, "3"), (11, 0.044, 0.14, [L.format("4.4")], False, "5"),
        (11, 0.044, 0.06, [L.format("4.4")], False, None), (20, 0.30, 0.02, [L.format("30.0")], False, "k"),
        (13, 0.014, 0.17, [L.format("1.4"), "Gewinn 7 T -0.07 Mio (mind. > 0)"], False, None),
        (10, 0.005, 0.06, ["9 von 10 -- Vorsprung nur 6 Punkte über dem Zufall (Aufnahme mind. 10)"], False, None),
        (13, 0.014, 0.17, [L.format("1.4"), "Entry-Lift -20 pp, t -1.5 (Einstiege belegbar vor Gegenbewegungen)"], False, None),
        (5, 0.001, 0.30, ["nur 5 bewertbare Ein-/Ausstiege in 14 T (Aufnahme mind. 6)"], False, None),
        (20, 0.30, 0.02, [L.format("30.0")], True, None), (10, 0.005, 0.20, [], True, "1"), (8, 0.05, 0.11, [L.format("5.0")], False, "5")]
    ist = [schatten_gruppe({"timing": {"n": n, "p_glueck": p, "lift_s": ls}, "gruende": g}, m) for n, p, ls, g, m, _s in faelle]
    gleich_auf = all((x == "1") == (not g and n >= AUFNAHME_MIN_ENTSCH) for x, (n, p, ls, g, m, _s) in zip(ist, faelle))
    pr.append(("Gruppen wie die Aufnahme bis auf die Glücksschwelle, Kontrolle über 5 %, Mitglieder nur in „1“",
               ist == [f[-1] for f in faelle] and gleich_auf))
    # (b) Eintragen
    T = _tag_ts("2026-10-08") + 3600
    rec = lambda a, p, ls=0.15, extra=(): {"addr": a, "name": a.upper(), "timing": {"n": 12, "treffer": 6, "zufall": 0.2, "p_glueck": p, "lift_s": ls},
                                           "gruende": ([] if p <= 0.01 else [L.format(f"{p * 100:.1f}")]) + list(extra)}
    sch: dict = {}
    sch = schatten_tag(sch, {"alle": [rec("0xa", 0.02), rec("0xb", 0.40, 0.0), rec("0xc", 0.005), rec("0xd", 0.02, 0.15, ["Gewinn 30 T -1.00 Mio (mind. > 0)"])]}, T)
    ok_b = set(sch["konten"]) == {"0xa", "0xb", "0xc"} and [sch["konten"][a]["ab"][-1]["g"] for a in ("0xa", "0xb", "0xc")] == ["3", "k", "1"]
    ok_b = ok_b and sch["konten"]["0xa"]["ab"][0]["p0"] == 0.02 and sch["start"] == T and sch["_geaendert"]
    sch = schatten_tag(sch, {"alle": [rec("0xa", 0.30, 0.0), rec("0xe", 0.30, 0.0)]}, T + 3600)        # derselbe Tag: nichts
    ok_b = ok_b and not sch["_geaendert"] and "0xe" not in sch["konten"]
    sch = schatten_tag(sch, {"alle": [rec("0xa", 0.005), rec("0xb", 0.02), rec("0xc", 0.40, 0.0), rec("0xe", 0.40, 0.0)]}, T + 86_400)
    ok_b = ok_b and [len(sch["konten"][a]["ab"]) for a in ("0xa", "0xb", "0xc")] == [1, 2, 1] and sch["konten"]["0xb"]["ab"][1]["g"] == "3"
    ok_b = ok_b and sch["konten"]["0xb"]["ab"][1]["seit"] == T + 86_400 and sch["konten"]["0xa"]["ab"][0]["g"] == "3" and sch["konten"]["0xe"]["ab"][0]["g"] == "k"
    sch = schatten_tag(sch, {"alle": [rec("0xb", 0.40, 0.0), rec("0xe", 0.40, 0.0)]}, T + 2 * 86_400)
    ok_b = ok_b and len(sch["konten"]["0xb"]["ab"]) == 2 and sch["konten"]["0xe"]["ab"][0]["tage"] == 2
    pr.append(("Eintragen: Band bleibt, Kontrolle -> Band genau einmal, einmal je Tag, ohne Gewinn kein Eintrag", ok_b))
    # (c) vorwärts auf Kursdaten
    now = 1_791_000_000 // TIMING_BLOCK * TIMING_BLOCK + 2 * 3600 + 12 * 3600        # now − 12 h liegt 2 h in einem 4-h-Block
    seit_t = now - TIMING_TAGE * 86_400
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    for tab in ("whale_positions", "lb_events", "pool_positions"):
        con.execute(f"CREATE TABLE {tab} (ts INTEGER, addr TEXT, coin TEXT, event TEXT, side TEXT)")
    rng = random.Random(21); lp = math.log(100.0); rows = []
    for t in range(seit_t - 7200, now + 60, 60):
        lp += rng.gauss(0, 0.0016); c = math.exp(lp); rows.append((t, "AAA", c, c, c, c, 1, 1))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    A = "0x" + "aa" * 20
    zeiten = sorted(rng.randint(seit_t + 3600, now - 13 * 3600) for _ in range(40))
    grenze = now - 3 * 86_400 - HORIZONT                                  # obere Grenze des ersten Schritts (2 h in ihrem Block)
    zeiten += [grenze - 1800, grenze + 1800]                             # gleiche Richtung, gleicher 4-h-Block, je eine Seite der Grenze
    ev = [(t, A, "AAA", rng.choice(["open", "close", "reduce", "add"]), rng.choice(["long", "short"])) for t in zeiten[:-2]]
    ev += [(grenze - 1800, A, "AAA", "open", "long"), (grenze + 1800, A, "AAA", "add", "long")]
    con.executemany("INSERT INTO pool_positions VALUES (?,?,?,?,?)", ev)
    kurse = {"AAA": Kurs(con, "AAA", seit_t, now)}
    pl = placebo_berechnen(kurse, seit_t, now, random.Random(5))
    ref = bewerte_konto(con, A, lade_ereignisse(con, [A], ["AAA"], seit_t, now)[A], kurse, seit_t, now, random.Random(5), pl)["timing"]
    neu = lambda seit_: {"konten": {A: {"name": "", "ab": [{"g": "3", "seit": seit_, "p0": 0.02, "n0": 8, "k0": 5, "z0": 0.3, "f": [0, 0, 0.0, 0.0],
                                                           "tage": 1, "zuletzt": seit_}], "lb": {}}}}
    s1 = schatten_entscheidungen(con, neu(seit_t - 1), now, ["AAA"], pl=pl, kurse=kurse)
    f1 = s1["konten"][A]["ab"][0]["f"]
    gleich_ref = f1[0] == ref["n"] and f1[1] == ref["treffer"] and abs(f1[2] / max(f1[0], 1) - ref["zufall"]) < 0.0006 and s1["bis"] == now - HORIZONT
    s2 = schatten_entscheidungen(con, neu(seit_t - 1), now - 3 * 86_400, ["AAA"], pl=pl, kurse=kurse)
    s2 = schatten_entscheidungen(con, s2, now, ["AAA"], pl=pl, kurse=kurse)
    zwei = s2["konten"][A]["ab"][0]["f"] == f1
    s3 = schatten_entscheidungen(con, neu(now - 5 * 86_400), now, ["AAA"], pl=pl, kurse=kurse)
    n_nach = s3["konten"][A]["ab"][0]["f"][0]
    s4 = neu(seit_t - 1); s4["konten"][A]["ab"][0]["g"] = "k"
    s4["konten"][A]["ab"].append({"g": "3", "seit": now - 5 * 86_400, "p0": 0.02, "n0": 8, "k0": 5, "z0": 0.3, "f": [0, 0, 0.0, 0.0], "tage": 1, "zuletzt": now})
    s4 = schatten_entscheidungen(con, s4, now, ["AAA"], pl=pl, kurse=kurse)
    teil = [ab_["f"][0] for ab_ in s4["konten"][A]["ab"]]
    leer = schatten_entscheidungen(con, {"bis": now - HORIZONT}, now, ["AAA"], pl=pl, kurse=kurse)
    con.close()
    pr.append(("Vorwärts auf Kursdaten: Treffer und Zufall wie bewerte_konto; nur nach dem Eintritt; zwei Schritte = einer (Block über "
               "die Grenze einmal); Wechsel Kontrolle -> Band teilt", gleich_ref and zwei and 0 < n_nach < f1[0] and teil == [f1[0] - n_nach, n_nach]
               and leer.get("bis") == now - HORIZONT and ref["n"] >= 15))
    # (d) Statistik von Hand
    def stand(band, kontr):
        k_ = {}
        for i, f in enumerate(band):
            k_[f"0xb{i}"] = {"name": "", "lb": {}, "ab": [{"g": "3", "seit": 0, "p0": 0.02, "f": list(f), "tage": 1}]}
        for i, f in enumerate(kontr):
            k_[f"0xk{i}"] = {"name": "", "lb": {}, "ab": [{"g": "k", "seit": 0, "p0": 0.3, "f": list(f), "tage": 1}]}
        return {"start": 0, "bis": 0, "konten": k_}
    st_d = stand([(30, 12, 7.5, 5.6), (25, 9, 6.0, 4.5), (10, 4, 2.5, 1.9)], [(100, 27, 25.0, 18.0), (80, 22, 20.0, 15.0)])
    d_soll = 9 / 65 - 4 / 180; se_soll = math.sqrt(12.0 / 65 ** 2 + 33.0 / 180 ** 2); p_soll = 0.5 * math.erfc(d_soll / se_soll / math.sqrt(2))
    U0 = schatten_urteil(st_d, _tag_ts("2026-11-17")); U1 = schatten_urteil(st_d, _tag_ts("2026-11-18") + 3600)
    st_2 = stand([(40, 16, 10.0, 7.5), (25, 9, 6.0, 4.5)], [(100, 27, 25.0, 18.0), (80, 22, 20.0, 15.0)])
    st_l = stand([(60, 30, 15.0, 11.0), (10, 1, 3.0, 2.0), (10, 1, 3.0, 2.0)], [(100, 27, 25.0, 18.0), (80, 22, 20.0, 15.0)])
    U2a = schatten_urteil(st_2, _tag_ts("2026-11-18") + 3600); U2b = schatten_urteil(st_2, _tag_ts("2026-12-16") + 3600)
    Ul = schatten_urteil(st_l, _tag_ts("2026-11-18") + 3600)
    # 23.58: Spalte „Konten (mit Entsch.)“ -- eingetragen und davon mit Entscheidungen in EINER Zelle (ein Bandkonto ohne Entscheidung)
    zt = schatten_text(stand([(30, 12, 7.5, 5.6), (25, 9, 6.0, 4.5), (10, 4, 2.5, 1.9), (0, 0, 0.0, 0.0)], [(100, 27, 25.0, 18.0)]),
                       _tag_ts("2026-10-20"))
    kopf = (any("Konten (mit Entsch.)" in z_ for z_ in zt) and any(z_.lstrip().startswith("Glück 1–3 %") and " 4 (3) " in z_ for z_ in zt)
            and any(z_.lstrip().startswith("Kontrolle") and " 1 (1) " in z_ for z_ in zt))
    ok_d = kopf and (abs(U1["delta"] - d_soll) < 1e-12 and abs(U1["se"] - se_soll) < 1e-12 and abs(U1["p"] - p_soll) < 1e-12 and 0.02 < p_soll < 0.05
            and U0["urteil"] == "Zwischenstand" and U1["urteil"] == "Timing belegt" and U1["loo_ok"] and len(U1["loo"]) == 3
            and U2a["urteil"] == "noch nicht entscheidbar" and U2b["urteil"] == "nicht entscheidbar"
            and Ul["delta"] > SCHATTEN_MIN_MEHR and Ul["p"] < SCHATTEN_P and not Ul["loo_ok"] and Ul["urteil"] == "nicht belegt"
            and any("URTEIL: Timing belegt" in z_ for z_ in schatten_text(st_d, _tag_ts("2026-11-18") + 3600))
            and any("Zwischenstand" in z_ for z_ in schatten_text(st_d, _tag_ts("2026-10-20"))))
    pr.append(("Statistik = Rechnung von Hand (Δ, Streuung, p); ohne ein Konto; Termine 18.11./16.12.; Bericht (Spalte Konten (mit Entsch.))", ok_d))
    # (e) Simulation: Nulltest mit Bias, Gegenprobe ohne Kontrolle, Positivkontrolle
    t_urteil = _tag_ts("2026-11-18") + 3600
    bel_null = naiv = 0
    for sd in range(laeufe_null):
        U = schatten_urteil(_schatten_sim(5000 + sd), t_urteil)
        bel_null += U["belegt"]
        B = U["summen"]["3"]
        if B["n"] >= SCHATTEN_MIN_ENTSCH and B["konten"] >= SCHATTEN_MIN_KONTEN:
            m_ = _mehr(B); se_ = math.sqrt(B["v"]) / B["n"]
            naiv += m_ >= SCHATTEN_MIN_MEHR and 0.5 * math.erfc(m_ / se_ / math.sqrt(2)) < SCHATTEN_P
    bel_pos = sum(schatten_urteil(_schatten_sim(7000 + sd, n_gut=75), t_urteil)["belegt"] for sd in range(laeufe_pos))
    f_null, f_naiv, f_pos = bel_null / laeufe_null, naiv / laeufe_null, bel_pos / laeufe_pos
    pr.append((f"Simulation ohne Können, Bias +4 Punkte: belegt {f_null * 100:.0f} % (Soll ≤ 8), gegen die Zufallsquote allein {f_naiv * 100:.0f} % "
               f"(Soll ≥ 15: der Bias ist da); halber Pool +15 Punkte: belegt {f_pos * 100:.0f} % (Soll ≥ 80)", f_null <= 0.08 and f_naiv >= 0.15 and f_pos >= 0.80))
    ok = all(b_ for _, b_ in pr)
    return ok, "Schatten der Darwin-Liste (U136): " + " · ".join(f"{n} {'ok' if b_ else 'FEHL'}" for n, b_ in pr)


def nulltest(verbose: bool = True, seed: int = 3) -> bool:
    """Rauschen: Exit-Lift ≈ 0 (|Mittel| < 5 pp über 40 Konten); Kante: Ausstiege kurz vor konstruierten Rückgängen -> Lift deutlich > 0."""
    rng = random.Random(seed); con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    now = int(time.time()) // 60 * 60; seit = now - QUALI_TAGE * 86_400; px = 100.0; rows = []
    t = seit - 3600
    while t <= now:
        r = rng.gauss(0, 0.0006); px *= math.exp(r); rows.append((t, "BTC", px, px * (1 + abs(rng.gauss(0, 0.0003))), px * (1 - abs(rng.gauss(0, 0.0003))), px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    k = Kurs(con, "BTC", seit, now); kurse = {"BTC": k}
    # Rauschkonten: zufällige Ausstiege
    lifts = []
    for i in range(40):
        ev = sorted((rng.randint(seit, now - HORIZONT - 60), "BTC", "exit", rng.choice(["long", "short"])) for _ in range(25))
        l = bewerte_konto(con, f"0x{i:040x}", ev, kurse, seit, now, random.Random(seed + i))
        if l["exit_lift"] is not None:
            lifts.append(l["exit_lift"])
    mittel = statistics.mean(lifts) if lifts else 0.0
    ok_null = abs(mittel) < 0.05
    # Kante: Ausstiege genau vor den größten 12-h-Rückgängen
    ts_list = k.ts
    kand = []
    for t0 in range(seit, now - HORIZONT - 60, 1800):
        r = k.rueckgang_binnen(t0, HORIZONT)
        if r is not None and r <= -KORREKTUR:
            kand.append(t0)
    ev = sorted((t0, "BTC", "exit", "long") for t0 in kand[:40])
    l = bewerte_konto(con, "0xkante", ev, kurse, seit, now, random.Random(99)) if len(ev) >= MIN_EXITS else {"exit_lift": None, "exit_t": None}
    ok_kante = (l["exit_lift"] or 0) > 0.3 and (l["exit_t"] or 0) >= 2 if l["exit_lift"] is not None else False
    if verbose:
        print(f"  Nulltest Exit-Lift: 40 Rauschkonten, mittlerer Lift {mittel * 100:+.1f} pp (Soll |x| < 5) -> {'ok' if ok_null else 'FEHL'}")
        print(f"  Positivtest: {len(ev)} Ausstiege vor konstruierten Rückgängen -> Lift {((l['exit_lift'] or 0) * 100):+.0f} pp, t {(l['exit_t'] or 0):.1f} (Soll > 30 pp, t >= 2) -> {'ok' if ok_kante else 'FEHL'}")
    ok_rt, txt_rt = _richtung_trend_test()
    ok_gl, txt_gl = _glueck_test()
    ok_q, txt_q = _quellen_test()
    ok_dw, txt_dw = _darwin_test()
    ok_sc, txt_sc = _schatten_test()                                    # 23.57 (U136)
    if verbose:
        print(f"  {txt_gl} -> {'ok' if ok_gl else 'FEHL'}")
        print(f"  {txt_q} -> {'ok' if ok_q else 'FEHL'}")
        print(f"  {txt_dw} -> {'ok' if ok_dw else 'FEHL'}")
        print(f"  {txt_sc} -> {'ok' if ok_sc else 'FEHL'}")
    ok_rt = ok_rt and ok_gl and ok_q and ok_dw and ok_sc
    if verbose:
        print(f"  {txt_rt} -> {'ok' if ok_rt else 'FEHL'}")
        print("  Ergebnis:", "bestanden" if ok_null and ok_kante and ok_rt else "NICHT bestanden")
    return ok_null and ok_kante and ok_rt


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    print(__doc__)
