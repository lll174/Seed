#!/usr/bin/env python3
"""
hl_profis.py -- "Aktive Profis", Phase 2: Bewertung der Pool-Konten (Konzept KONZEPT_Aktive_Profis.md, §5-6).

Nur Lesen der Hauptdatenbank; keine Nebenwirkungen. Alle Größen sind auf den VERFOLGTEN Coins definiert
(der Trade-Stream ist nur für sie abonniert; ein Konto, das andere Coins handelt, hat hier keine Trades).

Qualifikation (7 Tage), alles Pflicht:
  - Kontowert >= 1 Mio (Pool), nicht gesperrt (Masterregel)
  - Aktivität: 5 <= gebündelte Trades/Tag <= 150  (Fills je Minute und Richtung, pool_fills_hourly)
  - Gewinn 7 T > 0  (Hyperliquids einzahlungsbereinigtes Wochenfenster, pool_accounts.pnl_7d)
  - Exit-Lift > 0 mit t >= 1: Anteil der Ausstiege (reduce/close), denen binnen 12 h eine Korrektur
    >= 2 % gegen die aufgegebene Richtung folgte, MINUS derselbe Anteil an 200 zufälligen Zeitpunkten
    desselben 7-Tage-Fensters (Placebo). n_eff = getrennte 12-h-Blöcke.
  - Entry-Lift nicht signifikant negativ (t > -1): Einstiege dürfen nicht belegbar vor Gegenbewegungen
    liegen (Variante 2, 23.09.; nach zwei Wochen Beobachtung: beide Lifts > 0 mit t >= 1)
Anzeige:
  - Entry-Lift (Einstiege vor einer Bewegung >= 2 % in die eigene Richtung binnen 12 h, gleiches Placebo)
  - Bot-Marke: über 7 Tage nie länger als 4 h ohne Trade (Stundenraster), ab 5 Tagen Daten
  - Reaktionszeit: Median der Minuten von einer Bewegung >= 1 % in 15 min bis zum nächsten Trade
  - bester Coin (closedPnl, sobald der REST-Nachtrag ihn liefert; sonst Umsatz)
Rang: ROI 12 h. Bis der REST-Nachtrag closedPnl je Fill für den Pool liefert (Plan U5), steht dafür
Hyperliquids einzahlungsbereinigte Tages-ROI (pool_accounts.roi_1d, stündlich frisch), eingefroren
alle 12 h (00/12 UTC) -- Feld "rang_basis" sagt, was gilt.
"""
import bisect
import json
import math
import random
import sqlite3
import statistics
import sys
import time

PROFI_MIN_TRADES = 5
PROFI_MAX_TRADES = 150          # Nutzer 22.09.
KORREKTUR = 0.02                # 2 % ...
HORIZONT = 12 * 3600            # ... binnen 12 h
PLACEBO_N = 200
QUALI_TAGE = 7
BOT_MAX_LUECKE_H = 4
MIN_EXITS = 5                   # weniger Ausstiege: kein Beleg (t nicht berechenbar)
T_MIN = 1.0


# ----------------------------------------------------------------------------------------------
# Kursreihe
# ----------------------------------------------------------------------------------------------
class Kurs:
    """Minutenkurse eines Coins im Fenster; extrem_nach(t, h, richtung) = Tief/Hoch der nächsten h Sekunden."""

    def __init__(self, con, coin: str, seit: int, bis: int):
        rows = con.execute("SELECT ts, close, low, high FROM bars WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                           (coin, seit - 60, bis)).fetchall()
        self.ts = [r[0] for r in rows]; self.close = [r[1] for r in rows]
        self.low = [(r[2] if r[2] else r[1]) for r in rows]; self.high = [(r[3] if r[3] else r[1]) for r in rows]

    def at(self, t: int):
        i = bisect.bisect_right(self.ts, t) - 1
        return self.close[i] if i >= 0 and t - self.ts[i] <= 120 else None

    def rueckgang_binnen(self, t: int, h: int) -> float | None:
        """Größter Rückgang (negativ) relativ zum Kurs bei t innerhalb der nächsten h Sekunden."""
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        lo = min(self.low[i:j])
        return lo / p0 - 1.0

    def anstieg_binnen(self, t: int, h: int) -> float | None:
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        return max(self.high[i:j]) / p0 - 1.0


# ----------------------------------------------------------------------------------------------
# Ereignisse je Konto (Ausstiege / Einstiege) aus whale_positions und lb_events
# ----------------------------------------------------------------------------------------------
def lade_ereignisse(con, addrs, coins, seit: int, bis: int) -> dict:
    """{addr: [(ts, coin, art, side)]} mit art in {'exit','entry'}; je Minute und Coin ein Ereignis."""
    out: dict = {}
    if not addrs:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l)); cmarks = ",".join("?" * len(coins))
    seen = set()
    for tab, cols in (("whale_positions", "ts, lower(addr), coin, event, side"), ("lb_events", "ts, lower(addr), coin, event, side")):
        try:
            for ts, a, coin, ev, side in con.execute(f"SELECT {cols} FROM {tab} WHERE ts>=? AND ts<=? AND lower(addr) IN ({marks}) AND coin IN ({cmarks}) "
                                                     f"AND event IN ('open','add','reduce','close','flip')", (seit, bis, *a_l, *coins)):
                key = (a, coin, ts // 60)
                if key in seen:
                    continue
                seen.add(key)
                art = "exit" if ev in ("reduce", "close") else "entry"
                out.setdefault(a, []).append((int(ts), coin, art, str(side or "").lower()))
        except sqlite3.OperationalError:
            continue
    for a in out:
        out[a].sort()
    return out


def n_eff_bloecke(zeiten, block_s: int = HORIZONT) -> int:
    return len({int(t) // block_s for t in zeiten})


def lift(treffer: list, placebo_quote: float, n_eff: int) -> tuple:
    """Lift = Trefferanteil − Placebo; t gegen SE der Differenz auf n_eff und PLACEBO_N."""
    if not treffer:
        return None, None
    p = sum(treffer) / len(treffer)
    se = math.sqrt(max(p * (1 - p), 0.0025) / max(n_eff, 1) + max(placebo_quote * (1 - placebo_quote), 0.0025) / PLACEBO_N)
    l = p - placebo_quote
    return l, (l / se if se > 0 else None)


def bewerte_konto(con, addr: str, ereignisse: list, kurse: dict, seit: int, bis: int, rng: random.Random) -> dict:
    """Exit-/Entry-Lift eines Kontos über alle verfolgten Coins (Placebo je Coin aus demselben Fenster)."""
    ex_treffer: list = []; ex_zeiten: list = []; en_treffer: list = []; en_zeiten: list = []
    placebo: dict = {}
    for coin, k in kurse.items():
        if not k.ts:
            continue
        # Placebo: 200 zufällige Zeitpunkte im Fenster, Anteil mit Rückgang bzw. Anstieg >= 2 % binnen 12 h
        pr = []; pa = []
        for _ in range(PLACEBO_N):
            t = rng.randint(seit, bis - HORIZONT)
            r = k.rueckgang_binnen(t, HORIZONT); a = k.anstieg_binnen(t, HORIZONT)
            if r is not None:
                pr.append(1 if r <= -KORREKTUR else 0)
            if a is not None:
                pa.append(1 if a >= KORREKTUR else 0)
        placebo[coin] = (sum(pr) / len(pr) if pr else None, sum(pa) / len(pa) if pa else None)
    pl_r = [v[0] for v in placebo.values() if v[0] is not None]; pl_a = [v[1] for v in placebo.values() if v[1] is not None]
    placebo_r = statistics.mean(pl_r) if pl_r else None; placebo_a = statistics.mean(pl_a) if pl_a else None
    for ts, coin, art, side in ereignisse:
        k = kurse.get(coin)
        if not k or not k.ts or ts + HORIZONT > bis:
            continue
        if art == "exit":
            # Long geschlossen: Korrektur = Rückgang; Short geschlossen: Korrektur = Anstieg
            v = k.rueckgang_binnen(ts, HORIZONT) if side == "long" else k.anstieg_binnen(ts, HORIZONT)
            if v is None:
                continue
            hit = (v <= -KORREKTUR) if side == "long" else (v >= KORREKTUR)
            ex_treffer.append(1 if hit else 0); ex_zeiten.append(ts)
        else:
            v = k.anstieg_binnen(ts, HORIZONT) if side == "long" else k.rueckgang_binnen(ts, HORIZONT)
            if v is None:
                continue
            hit = (v >= KORREKTUR) if side == "long" else (v <= -KORREKTUR)
            en_treffer.append(1 if hit else 0); en_zeiten.append(ts)
    # Placebo für Longs = Rückgangsquote, für Shorts = Anstiegsquote; hier gemischt -> mittlere Placebo-Quote
    pl_exit = statistics.mean([x for x in (placebo_r, placebo_a) if x is not None]) if (placebo_r is not None or placebo_a is not None) else None
    out = {"n_exits": len(ex_treffer), "n_entries": len(en_treffer), "exit_lift": None, "exit_t": None, "entry_lift": None, "entry_t": None,
           "placebo": pl_exit, "n_eff_exit": n_eff_bloecke(ex_zeiten), "n_eff_entry": n_eff_bloecke(en_zeiten)}
    if pl_exit is not None and len(ex_treffer) >= MIN_EXITS:
        out["exit_lift"], out["exit_t"] = lift(ex_treffer, pl_exit, out["n_eff_exit"])
    if pl_exit is not None and len(en_treffer) >= MIN_EXITS:
        out["entry_lift"], out["entry_t"] = lift(en_treffer, pl_exit, out["n_eff_entry"])
    return out


def aktivitaet(con, addrs, seit: int, bis: int) -> dict:
    """{addr: {trades_tag, tage, stunden_aktiv, laengste_luecke_h, bot, umsatz, closed_pnl, bester_coin}} aus pool_fills_hourly."""
    out: dict = {}
    if not addrs:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l))
    rows = con.execute(f"SELECT lower(addr), stunde, coin, n_trades, buy_usd+sell_usd, closed_pnl FROM pool_fills_hourly "
                       f"WHERE stunde>=? AND stunde<? AND lower(addr) IN ({marks}) ORDER BY 1, 2", (seit, bis, *a_l)).fetchall()
    stunden_da = con.execute("SELECT COUNT(DISTINCT stunde) FROM pool_fills_hourly WHERE stunde>=? AND stunde<?", (seit, bis)).fetchone()[0] or 0
    tage_da = max(1.0, stunden_da / 24.0)
    je: dict = {}
    for a, st, coin, n, umsatz, pnl in rows:
        d = je.setdefault(a, {"stunden": set(), "n": 0, "umsatz": 0.0, "pnl": 0.0, "coins": {}})
        if n:
            d["stunden"].add(st); d["n"] += n
        d["umsatz"] += umsatz or 0.0; d["pnl"] += pnl or 0.0
        c = d["coins"].setdefault(coin, [0.0, 0.0]); c[0] += pnl or 0.0; c[1] += umsatz or 0.0
    for a in a_l:
        d = je.get(a)
        if not d:
            out[a] = {"trades_tag": 0.0, "tage": round(tage_da, 1), "stunden_aktiv": 0, "laengste_luecke_h": None, "bot": False, "umsatz": 0.0, "closed_pnl": 0.0, "bester_coin": None}
            continue
        st = sorted(d["stunden"]); luecke = 0
        for i in range(1, len(st)):
            luecke = max(luecke, (st[i] - st[i - 1]) // 3600 - 1)
        if st:
            luecke = max(luecke, (st[0] - seit) // 3600, (bis - st[-1]) // 3600 - 1)
        bot = bool(st) and tage_da >= 5 and luecke <= BOT_MAX_LUECKE_H
        coins = d["coins"]
        best = max(coins.items(), key=lambda kv: (kv[1][0], kv[1][1]))[0] if coins else None
        out[a] = {"trades_tag": round(d["n"] / tage_da, 1), "tage": round(tage_da, 1), "stunden_aktiv": len(st), "laengste_luecke_h": luecke,
                  "bot": bot, "umsatz": d["umsatz"], "closed_pnl": d["pnl"], "bester_coin": best}
    return out


def reaktionszeit(kurse: dict, ereignisse: list) -> float | None:
    """Median der Minuten von einer Bewegung >= 1 % in 15 min bis zum nächsten Trade des Kontos (alle Coins)."""
    if not ereignisse:
        return None
    zeiten = sorted(ts for ts, _, _, _ in ereignisse)
    werte = []
    for coin, k in kurse.items():
        if len(k.ts) < 20:
            continue
        for i in range(15, len(k.ts), 5):
            if k.ts[i] - k.ts[i - 15] > 16 * 60:
                continue
            if abs(k.close[i] / k.close[i - 15] - 1.0) >= 0.01:
                t_move = k.ts[i]; j = bisect.bisect_left(zeiten, t_move)
                if j < len(zeiten) and zeiten[j] - t_move <= 6 * 3600:
                    werte.append((zeiten[j] - t_move) / 60.0)
    return statistics.median(werte) if werte else None


# ----------------------------------------------------------------------------------------------
# Gesamtbewertung
# ----------------------------------------------------------------------------------------------
def bewerten(con, now: int | None = None, coins: list | None = None, seed: int = 7) -> dict:
    now = now or int(time.time()); seit = now - QUALI_TAGE * 86_400
    coins = coins or [r[0] for r in con.execute("SELECT coin FROM bars WHERE ts>=? GROUP BY coin", (now - 86_400,))]
    try:
        pool = con.execute("SELECT addr, account_value, pnl_7d, roi_7d, pnl_1d, roi_1d, vlm_1d, vlm_7d, name, zuletzt_erfuellt FROM pool_accounts "
                           "WHERE zuletzt_erfuellt >= ?", (now - 7 * 86_400,)).fetchall()
    except sqlite3.OperationalError:
        pool = []
    try:
        gesperrt = {r[0].lower() for r in con.execute("SELECT addr FROM konto_status WHERE status='gesperrt'")}
    except sqlite3.OperationalError:
        gesperrt = set()
    addrs = [r[0].lower() for r in pool if r[0].lower() not in gesperrt]
    akt = aktivitaet(con, addrs, seit, now)
    # Kandidaten für die teure Lift-Rechnung: aktiv im Rahmen und Gewinn > 0
    info = {r[0].lower(): r for r in pool}
    kand = [a for a in addrs if PROFI_MIN_TRADES <= akt[a]["trades_tag"] <= PROFI_MAX_TRADES and (info[a][2] or 0) > 0]
    ereignisse = lade_ereignisse(con, kand, coins, seit, now)
    kurse = {c: Kurs(con, c, seit, now) for c in coins}
    rng = random.Random(seed)
    konten = []
    for a in addrs:
        r = info[a]; ak = akt[a]
        rec = {"addr": a, "name": r[8] or "", "account_value": r[1], "pnl_7d": r[2], "roi_7d": r[3], "pnl_1d": r[4], "roi_1d": r[5],
               "vlm_1d": r[6], "vlm_7d": r[7], **ak, "gruende": [], "qualifiziert": False,
               "n_exits": 0, "exit_lift": None, "exit_t": None, "entry_lift": None, "entry_t": None, "reaktion_min": None}
        if ak["trades_tag"] < PROFI_MIN_TRADES:
            rec["gruende"].append(f"nur {ak['trades_tag']:.0f} Trades/Tag in den verfolgten Coins (mind. {PROFI_MIN_TRADES})")
        elif ak["trades_tag"] > PROFI_MAX_TRADES:
            rec["gruende"].append(f"{ak['trades_tag']:.0f} Trades/Tag (Grenze {PROFI_MAX_TRADES})")
        if (r[2] or 0) <= 0:
            rec["gruende"].append(f"Gewinn 7 T {((r[2] or 0) / 1e6):+.2f} Mio (mind. > 0)")
        if a in kand:
            ev = ereignisse.get(a, [])
            l = bewerte_konto(con, a, ev, kurse, seit, now, rng)
            rec.update({k: v for k, v in l.items()})
            rec["reaktion_min"] = reaktionszeit(kurse, ev)
            if l["exit_lift"] is None:
                rec["gruende"].append(f"nur {l['n_exits']} Ausstiege in 7 T (mind. {MIN_EXITS} für einen Beleg)")
            elif not (l["exit_lift"] > 0 and (l["exit_t"] or 0) >= T_MIN):
                rec["gruende"].append(f"Exit-Lift {l['exit_lift'] * 100:+.0f} pp, t {l['exit_t']:.1f} (nötig > 0 und t ≥ {T_MIN:.0f})")
            # Einstiege (Nutzer 23.09., Variante 2): kein Ausschluss ohne Beleg, aber ein belegbar FALSCHES Einstiegs-
            # Timing (Entry-Lift signifikant negativ, t ≤ −1) disqualifiziert. Nach zwei Wochen Pool-Beobachtung
            # ist die strenge Variante (beide Lifts > 0, t ≥ 1) vorgesehen (Plan U3b).
            if l["entry_lift"] is not None and l["entry_lift"] < 0 and (l["entry_t"] or 0) <= -T_MIN:
                rec["gruende"].append(f"Entry-Lift {l['entry_lift'] * 100:+.0f} pp, t {l['entry_t']:.1f} (Einstiege belegbar vor Gegenbewegungen)")
        rec["qualifiziert"] = not rec["gruende"]
        konten.append(rec)
    quali = [k for k in konten if k["qualifiziert"]]
    quali.sort(key=lambda k: -(k["roi_1d"] or -1e9))
    stempel = now // (12 * 3600) * (12 * 3600)
    return {"ts": now, "stempel": stempel, "rang_basis": "roi_1d (Hyperliquid, einzahlungsbereinigt, stündlich; 12-h-Eigenrechnung folgt mit dem REST-Nachtrag U5)",
            "n_pool": len(pool), "n_gesperrt": sum(1 for r in pool if r[0].lower() in gesperrt), "n_aktiv": len(kand), "n_qualifiziert": len(quali),
            "coins": coins, "top": quali[:20], "alle": konten}


# ----------------------------------------------------------------------------------------------
# Nulltest / Positivtest der Lift-Rechnung
# ----------------------------------------------------------------------------------------------
def nulltest(verbose: bool = True, seed: int = 3) -> bool:
    """Rauschen: Exit-Lift ≈ 0 (|Mittel| < 5 pp über 40 Konten); Kante: Ausstiege kurz vor konstruierten Rückgängen -> Lift deutlich > 0."""
    rng = random.Random(seed); con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    now = int(time.time()) // 60 * 60; seit = now - QUALI_TAGE * 86_400; px = 100.0; rows = []
    t = seit - 3600
    while t <= now:
        r = rng.gauss(0, 0.0006); px *= math.exp(r); rows.append((t, "BTC", px, px * (1 + abs(rng.gauss(0, 0.0003))), px * (1 - abs(rng.gauss(0, 0.0003))), px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    k = Kurs(con, "BTC", seit, now); kurse = {"BTC": k}
    # Rauschkonten: zufällige Ausstiege
    lifts = []
    for i in range(40):
        ev = sorted((rng.randint(seit, now - HORIZONT - 60), "BTC", "exit", rng.choice(["long", "short"])) for _ in range(25))
        l = bewerte_konto(con, f"0x{i:040x}", ev, kurse, seit, now, random.Random(seed + i))
        if l["exit_lift"] is not None:
            lifts.append(l["exit_lift"])
    mittel = statistics.mean(lifts) if lifts else 0.0
    ok_null = abs(mittel) < 0.05
    # Kante: Ausstiege genau vor den größten 12-h-Rückgängen
    ts_list = k.ts
    kand = []
    for t0 in range(seit, now - HORIZONT - 60, 1800):
        r = k.rueckgang_binnen(t0, HORIZONT)
        if r is not None and r <= -KORREKTUR:
            kand.append(t0)
    ev = sorted((t0, "BTC", "exit", "long") for t0 in kand[:40])
    l = bewerte_konto(con, "0xkante", ev, kurse, seit, now, random.Random(99)) if len(ev) >= MIN_EXITS else {"exit_lift": None, "exit_t": None}
    ok_kante = (l["exit_lift"] or 0) > 0.3 and (l["exit_t"] or 0) >= 2 if l["exit_lift"] is not None else False
    if verbose:
        print(f"  Nulltest Exit-Lift: 40 Rauschkonten, mittlerer Lift {mittel * 100:+.1f} pp (Soll |x| < 5) -> {'ok' if ok_null else 'FEHL'}")
        print(f"  Positivtest: {len(ev)} Ausstiege vor konstruierten Rückgängen -> Lift {((l['exit_lift'] or 0) * 100):+.0f} pp, t {(l['exit_t'] or 0):.1f} (Soll > 30 pp, t >= 2) -> {'ok' if ok_kante else 'FEHL'}")
        print("  Ergebnis:", "bestanden" if ok_null and ok_kante else "NICHT bestanden")
    return ok_null and ok_kante


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    print(__doc__)
