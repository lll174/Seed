#!/usr/bin/env python3
"""
hl_profis.py -- "Aktive Profis", Phase 2: Bewertung der Pool-Konten (Konzept KONZEPT_Aktive_Profis.md, §5-6).

Nur Lesen der Hauptdatenbank; keine Nebenwirkungen. Alle Größen sind auf den VERFOLGTEN Coins definiert
(der Trade-Stream ist nur für sie abonniert; ein Konto, das andere Coins handelt, hat hier keine Trades).

Qualifikation (7 Tage), alles Pflicht:
  - Kontowert >= 1 Mio (Pool), nicht gesperrt (Masterregel)
  - Aktivität: 2 <= gebündelte Trades/Tag <= 150 (bis 23.30: 5)  (Fills je Minute und Richtung, pool_fills_hourly)
  - Gewinn 7 T > 0  (Hyperliquids einzahlungsbereinigtes Wochenfenster, pool_accounts.pnl_7d)
  - Exit-Lift > 0 mit t >= 1: Anteil der Ausstiege (reduce/close), denen binnen 12 h eine Korrektur
    >= 2 % gegen die aufgegebene Richtung folgte, MINUS derselbe Anteil an 200 zufälligen Zeitpunkten
    desselben 7-Tage-Fensters (Placebo). n_eff = getrennte 12-h-Blöcke.
  - Entry-Lift nicht signifikant negativ (t > -1): Einstiege dürfen nicht belegbar vor Gegenbewegungen
    liegen (Variante 2, 23.09.; nach zwei Wochen Beobachtung: beide Lifts > 0 mit t >= 1)
Anzeige:
  - Entry-Lift (Einstiege vor einer Bewegung >= 2 % in die eigene Richtung binnen 12 h, gleiches Placebo)
  - Bot-Marke: über 7 Tage nie länger als 4 h ohne Trade (Stundenraster), ab 5 Tagen Daten
  - Reaktionszeit: Median der Minuten von einer Bewegung >= 1 % in 15 min bis zum nächsten Trade
  - bester Coin (closedPnl, sobald der REST-Nachtrag ihn liefert; sonst Umsatz)
Rang: ROI 12 h aus eigenen Daten (Σ closedPnl der Fills in 12 h nach REST-Nachtrag + Änderung des
unrealisierten Gewinns, relativ zum Kontowert); Konten ohne Nachtrag vorerst nach Hyperliquids roi_1d.
Eingefroren alle 12 h (00/12 UTC) -- Feld "rang_basis" sagt, was gilt.
"""
import bisect
import json
import math
import random
import sqlite3
import statistics
import sys
import time

PROFI_MIN_TRADES = 2           # 23.31 (Nutzer 25.09.): vorher 5 -- an ruhigen Tagen ist Ruhe; alle übrigen Regeln unverändert
PROFI_MAX_TRADES = 150          # Nutzer 22.09.
KORREKTUR = 0.02                # 2 % ...
HORIZONT = 12 * 3600            # ... binnen 12 h
PLACEBO_N = 200
QUALI_TAGE = 7
BOT_MAX_LUECKE_H = 4
MIN_EXITS = 5                   # Anzeige: Exit-/Entry-Lift erst ab 5 Fällen (t sonst nicht aussagekräftig)
T_MIN = 1.0
# 23.32 (Entscheidung Nutzer 25.09.): Qualifikation über ALLE Timing-Entscheidungen -- Einstiege und Ausstiege zusammen
# („wer 2x kauft, kann nur 2x verkaufen“) --, mindestens MIN_ENTSCHEIDUNGEN, und die Trefferbilanz darf höchstens mit
# P_GLUECK_MAX Wahrscheinlichkeit reines Glück sein (exakter Test gegen die Zufallsquote je Coin und Richtung). Die Schwelle
# passt sich selbst an: wenige Entscheidungen müssen fast alle stimmen, viele dürfen auch danebenliegen. Vorher:
# mindestens 5 Ausstiege und Exit-Lift > 0 mit t ≥ 1 -- das ließ 4 von 5 durch (bei 40 % Zufall 8,7 % Glück).
MIN_ENTSCHEIDUNGEN = 4
P_GLUECK_MAX = 0.05
ENTRY_VETO_MIN = 5              # Einstiege nur als Veto: ab 5 Einstiegen deutlich negativ (t ≤ −1)
M_PSEUDO = 4                    # Dämpfung kleiner Zahlen für die Rangfolge: 4 gedachte Entscheidungen zur Zufallsquote
TIMING_BLOCK = 4 * 3600         # gleichgerichtete Entscheidungen im selben 4-h-Block zählen einmal (sie hängen zusammen)


# ----------------------------------------------------------------------------------------------
# Kursreihe
# ----------------------------------------------------------------------------------------------
class Kurs:
    """Minutenkurse eines Coins im Fenster; extrem_nach(t, h, richtung) = Tief/Hoch der nächsten h Sekunden."""

    def __init__(self, con, coin: str, seit: int, bis: int):
        rows = con.execute("SELECT ts, close, low, high FROM bars WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                           (coin, seit - 60, bis)).fetchall()
        self.ts = [r[0] for r in rows]; self.close = [r[1] for r in rows]
        self.low = [(r[2] if r[2] else r[1]) for r in rows]; self.high = [(r[3] if r[3] else r[1]) for r in rows]
        self._np = None

    def zuerst(self, t: int, h: int, s: float) -> int | None:
        """
        23.22 „Zuerst richtig“: +1 = binnen h zuerst +s erreicht, -1 = zuerst -s, 0 = keines von beiden, None = keine
        Daten oder beide in derselben Minute (nicht entscheidbar).
        """
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        import numpy as np
        if self._np is None:
            self._np = (np.asarray(self.low, dtype=float), np.asarray(self.high, dtype=float))
        auf = np.flatnonzero(self._np[1][i:j] >= p0 * (1 + s)); ab = np.flatnonzero(self._np[0][i:j] <= p0 * (1 - s))
        ia = int(auf[0]) if len(auf) else None; ib = int(ab[0]) if len(ab) else None
        if ia is None and ib is None:
            return 0
        if ia is not None and ib is not None and ia == ib:
            return None
        return 1 if ib is None or (ia is not None and ia < ib) else -1

    def at(self, t: int):
        i = bisect.bisect_right(self.ts, t) - 1
        return self.close[i] if i >= 0 and t - self.ts[i] <= 120 else None

    def rueckgang_binnen(self, t: int, h: int) -> float | None:
        """Größter Rückgang (negativ) relativ zum Kurs bei t innerhalb der nächsten h Sekunden."""
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        lo = min(self.low[i:j])
        return lo / p0 - 1.0

    def anstieg_binnen(self, t: int, h: int) -> float | None:
        p0 = self.at(t)
        if not p0:
            return None
        i = bisect.bisect_right(self.ts, t); j = bisect.bisect_right(self.ts, t + h)
        if j - i < 5 or t + h > self.ts[-1]:
            return None
        return max(self.high[i:j]) / p0 - 1.0


# ----------------------------------------------------------------------------------------------
# Ereignisse je Konto (Ausstiege / Einstiege) aus whale_positions und lb_events
# ----------------------------------------------------------------------------------------------
def lade_ereignisse(con, addrs, coins, seit: int, bis: int) -> dict:
    """{addr: [(ts, coin, art, side)]} mit art in {'exit','entry'}; je Minute und Coin ein Ereignis."""
    out: dict = {}
    if not addrs:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l)); cmarks = ",".join("?" * len(coins))
    seen = set()
    for tab, cols in (("whale_positions", "ts, lower(addr), coin, event, side"), ("lb_events", "ts, lower(addr), coin, event, side")):
        try:
            for ts, a, coin, ev, side in con.execute(f"SELECT {cols} FROM {tab} WHERE ts>=? AND ts<=? AND lower(addr) IN ({marks}) AND coin IN ({cmarks}) "
                                                     f"AND event IN ('open','add','reduce','close','flip')", (seit, bis, *a_l, *coins)):
                key = (a, coin, ts // 60)
                if key in seen:
                    continue
                seen.add(key)
                art = "exit" if ev in ("reduce", "close") else "entry"
                out.setdefault(a, []).append((int(ts), coin, art, str(side or "").lower()))
        except sqlite3.OperationalError:
            continue
    for a in out:
        out[a].sort()
    return out


def n_eff_bloecke(zeiten, block_s: int = HORIZONT) -> int:
    return len({int(t) // block_s for t in zeiten})


def glueck_p(treffer: int, quoten: list) -> float:
    """
    23.32: Wahrscheinlichkeit, mindestens `treffer` Treffer rein zufällig zu erzielen, wenn Entscheidung i mit der
    Wahrscheinlichkeit quoten[i] zufällig trifft (Poisson-Binomial, exakt per dynamischer Programmierung).
    """
    dp = [1.0]
    for q in quoten:
        neu = [0.0] * (len(dp) + 1)
        for k, w in enumerate(dp):
            neu[k] += w * (1 - q); neu[k + 1] += w * q
        dp = neu
    return float(min(1.0, sum(dp[max(0, treffer):])))


def timing_beleg(ents: list) -> dict:
    """ents: [(Treffer 0/1, Zufallsquote, 'entry'|'exit')] -- Bilanz, Glückswahrscheinlichkeit, gedämpfte Untergrenze."""
    n = len(ents)
    if not n:
        return {"n": 0, "treffer": 0, "n_ein": 0, "n_aus": 0, "zufall": None, "p_glueck": None, "lift_s": None, "lcb": None}
    k = sum(h for h, _, _ in ents); quoten = [min(max(e, 0.01), 0.99) for _, e, _ in ents]
    pbar = sum(quoten) / n
    post = (k + M_PSEUDO * pbar) / (n + M_PSEUDO)
    se0 = math.sqrt(pbar * (1 - pbar) / (n + M_PSEUDO))
    return {"n": n, "treffer": k, "n_ein": sum(1 for _, _, a in ents if a == "entry"), "n_aus": sum(1 for _, _, a in ents if a == "exit"),
            "zufall": round(pbar, 3), "p_glueck": glueck_p(k, quoten), "lift_s": post - pbar, "lcb": post - pbar - se0}


def lift(treffer: list, placebo_quote: float, n_eff: int) -> tuple:
    """Lift = Trefferanteil − Placebo; t gegen SE der Differenz auf n_eff und PLACEBO_N."""
    if not treffer:
        return None, None
    p = sum(treffer) / len(treffer)
    se = math.sqrt(max(p * (1 - p), 0.0025) / max(n_eff, 1) + max(placebo_quote * (1 - placebo_quote), 0.0025) / PLACEBO_N)
    l = p - placebo_quote
    return l, (l / se if se > 0 else None)


_PL_CACHE: dict = {}


def placebo_berechnen(kurse: dict, seit: int, bis: int, rng: random.Random) -> tuple:
    """
    Zufallsquoten je Coin aus PLACEBO_N zufälligen Zeitpunkten desselben Fensters: (Rückgang, Anstieg) >= 2 % binnen 12 h
    und -- 23.22 -- dieselben binnen 1 h und 4 h sowie „zuerst -2 %“ / „zuerst +2 %“ unter den entschiedenen Fällen.
    23.22: einmal je Bewertung gerechnet und für alle Konten geteilt (vorher je Konto neu -- langsam und uneinheitlich).
    """
    key = (seit, bis, tuple((c, len(k.ts), k.ts[0] if k.ts else 0, k.ts[-1] if k.ts else 0) for c, k in sorted(kurse.items())))
    if key in _PL_CACHE:
        return _PL_CACHE[key]
    placebo: dict = {}; placebo_x: dict = {}
    for coin, k in kurse.items():
        if not k.ts:
            continue
        q = {n_: [] for n_ in ("r12", "a12", "r1", "a1", "r4", "a4")}; zz = []
        for _ in range(PLACEBO_N):
            t = rng.randint(seit, bis - HORIZONT)
            for n_, h_ in (("12", HORIZONT), ("1", 3600), ("4", 4 * 3600)):
                r = k.rueckgang_binnen(t, h_); a = k.anstieg_binnen(t, h_)
                if r is not None:
                    q["r" + n_].append(1 if r <= -KORREKTUR else 0)
                if a is not None:
                    q["a" + n_].append(1 if a >= KORREKTUR else 0)
            z_ = k.zuerst(t, HORIZONT, KORREKTUR)
            if z_ in (1, -1):
                zz.append(z_)
        m_ = lambda v: sum(v) / len(v) if v else None
        placebo[coin] = (m_(q["r12"]), m_(q["a12"]))
        placebo_x[coin] = {"d1": m_(q["r1"]), "a1": m_(q["a1"]), "d4": m_(q["r4"]), "a4": m_(q["a4"]),
                           "zd": (zz.count(-1) / len(zz)) if zz else None, "za": (zz.count(1) / len(zz)) if zz else None}
    _PL_CACHE.clear(); _PL_CACHE[key] = (placebo, placebo_x)
    return placebo, placebo_x


def bewerte_konto(con, addr: str, ereignisse: list, kurse: dict, seit: int, bis: int, rng: random.Random, pl: tuple | None = None) -> dict:
    """Exit-/Entry-Lift eines Kontos über alle verfolgten Coins (Placebo je Coin aus demselben Fenster)."""
    ex_treffer: list = []; ex_zeiten: list = []; en_treffer: list = []; en_zeiten: list = []
    placebo, placebo_x = pl if pl is not None else placebo_berechnen(kurse, seit, bis, rng)
    pl_r = [v[0] for v in placebo.values() if v[0] is not None]; pl_a = [v[1] for v in placebo.values() if v[1] is not None]
    placebo_r = statistics.mean(pl_r) if pl_r else None; placebo_a = statistics.mean(pl_a) if pl_a else None
    ex_erw: list = []; en_erw: list = []
    bilanz = {k_: [0, 0, 0.0] for k_ in ("long_ein", "short_ein", "long_aus", "short_aus")}   # n, Treffer, Summe der Zufallsquoten
    tempo = {h_: [0, 0, 0.0] for h_ in ("1h", "4h", "12h")}; zuerst = [0, 0, 0.0, 0]          # zuerst: entschieden, richtig, Zufall, offen
    entsch: list = []                                                                           # 23.32: alle Ein- und Ausstiege
    for ts, coin, art, side in ereignisse:
        k = kurse.get(coin); pc = placebo.get(coin)
        if side not in ("long", "short") or not k or not k.ts or not pc or ts + HORIZONT > bis:
            continue                                        # 23.21: ohne gültige Seite kein Urteil (vorher galt alles außer long als short)
        faellt = (art == "exit") == (side == "long")        # Treffer = Rückgang: Long zu oder Short auf; sonst Anstieg
        v = k.rueckgang_binnen(ts, HORIZONT) if faellt else k.anstieg_binnen(ts, HORIZONT)
        erw = pc[0] if faellt else pc[1]                    # 23.21: Vergleich mit DEMSELBEN Coin und DERSELBEN Richtung (vorher Mittel über
        if v is None or erw is None:                        # Coins und Richtungen: im Trendmarkt +41 pp für zufällige Short-Schließungen)
            continue
        hit = (v <= -KORREKTUR) if faellt else (v >= KORREKTUR)
        b_ = bilanz[f"{side}_{'aus' if art == 'exit' else 'ein'}"]; b_[0] += 1; b_[1] += 1 if hit else 0; b_[2] += erw
        entsch.append((ts, faellt, 1 if hit else 0, erw, art))
        pxc = placebo_x.get(coin) or {}
        for hk, hs in (("1h", 3600), ("4h", 4 * 3600)):                   # 23.22 Tempo: Treffer schon nach 1 h / 4 h?
            vv = k.rueckgang_binnen(ts, hs) if faellt else k.anstieg_binnen(ts, hs)
            ee = pxc.get(("d" if faellt else "a") + hk[0])
            if vv is not None and ee is not None:
                tp = tempo[hk]; tp[0] += 1; tp[1] += 1 if ((vv <= -KORREKTUR) if faellt else (vv >= KORREKTUR)) else 0; tp[2] += ee
        tp = tempo["12h"]; tp[0] += 1; tp[1] += 1 if hit else 0; tp[2] += erw
        z_ = k.zuerst(ts, HORIZONT, KORREKTUR); ez = pxc.get("zd" if faellt else "za")    # 23.22 „Zuerst richtig“
        if z_ == 0:
            zuerst[3] += 1
        elif z_ in (1, -1) and ez is not None:
            zuerst[0] += 1; zuerst[1] += 1 if z_ == (-1 if faellt else 1) else 0; zuerst[2] += ez
        if art == "exit":
            ex_treffer.append(1 if hit else 0); ex_zeiten.append(ts); ex_erw.append(erw)
        else:
            en_treffer.append(1 if hit else 0); en_zeiten.append(ts); en_erw.append(erw)
    out = {"n_exits": len(ex_treffer), "n_entries": len(en_treffer), "exit_lift": None, "exit_t": None, "entry_lift": None, "entry_t": None,
           "placebo": statistics.mean(ex_erw) if ex_erw else None, "n_eff_exit": n_eff_bloecke(ex_zeiten), "n_eff_entry": n_eff_bloecke(en_zeiten),
           "bilanz": {k_: {"n": v_[0], "treffer": v_[1], "zufall": round(v_[2] / v_[0], 3) if v_[0] else None} for k_, v_ in bilanz.items()},
           "tempo": {k_: {"n": v_[0], "treffer": v_[1], "zufall": round(v_[2] / v_[0], 3) if v_[0] else None} for k_, v_ in tempo.items()},
           "zuerst": {"n": zuerst[0], "richtig": zuerst[1], "zufall": round(zuerst[2] / zuerst[0], 3) if zuerst[0] else None, "offen": zuerst[3]}}
    gesehen: set = set(); ents = []
    for ts_, fa_, h_, e_, a_ in sorted(entsch):                                                 # 23.32: je Richtung und 4-h-Block einmal
        key_ = (fa_, int(ts_) // TIMING_BLOCK)
        if key_ not in gesehen:
            gesehen.add(key_); ents.append((h_, e_, a_))
    out["timing"] = timing_beleg(ents)
    if len(ex_treffer) >= MIN_EXITS:
        out["exit_lift"], out["exit_t"] = lift(ex_treffer, statistics.mean(ex_erw), out["n_eff_exit"])
    if len(en_treffer) >= MIN_EXITS:
        out["entry_lift"], out["entry_t"] = lift(en_treffer, statistics.mean(en_erw), out["n_eff_entry"])
    return out


def aktivitaet(con, addrs, seit: int, bis: int) -> dict:
    """{addr: {trades_tag, tage, stunden_aktiv, laengste_luecke_h, bot, umsatz, closed_pnl, bester_coin}} aus pool_fills_hourly."""
    out: dict = {}
    if not addrs:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l))
    rows = con.execute(f"SELECT lower(addr), stunde, coin, n_trades, buy_usd+sell_usd, closed_pnl FROM pool_fills_hourly "
                       f"WHERE stunde>=? AND stunde<? AND lower(addr) IN ({marks}) ORDER BY 1, 2", (seit, bis, *a_l)).fetchall()
    stunden_da = con.execute("SELECT COUNT(DISTINCT stunde) FROM pool_fills_hourly WHERE stunde>=? AND stunde<?", (seit, bis)).fetchone()[0] or 0
    tage_da = max(1.0, stunden_da / 24.0)
    je: dict = {}
    for a, st, coin, n, umsatz, pnl in rows:
        d = je.setdefault(a, {"stunden": set(), "n": 0, "umsatz": 0.0, "pnl": 0.0, "coins": {}})
        if n:
            d["stunden"].add(st); d["n"] += n
        d["umsatz"] += umsatz or 0.0; d["pnl"] += pnl or 0.0
        c = d["coins"].setdefault(coin, [0.0, 0.0]); c[0] += pnl or 0.0; c[1] += umsatz or 0.0
    for a in a_l:
        d = je.get(a)
        if not d:
            out[a] = {"trades_tag": 0.0, "tage": round(tage_da, 1), "stunden_aktiv": 0, "laengste_luecke_h": None, "bot": False, "umsatz": 0.0, "closed_pnl": 0.0, "bester_coin": None}
            continue
        st = sorted(d["stunden"]); luecke = 0
        for i in range(1, len(st)):
            luecke = max(luecke, (st[i] - st[i - 1]) // 3600 - 1)
        if st:
            luecke = max(luecke, (st[0] - seit) // 3600, (bis - st[-1]) // 3600 - 1)
        bot = bool(st) and tage_da >= 5 and luecke <= BOT_MAX_LUECKE_H
        coins = d["coins"]
        best = max(coins.items(), key=lambda kv: (kv[1][0], kv[1][1]))[0] if coins else None
        out[a] = {"trades_tag": round(d["n"] / tage_da, 1), "tage": round(tage_da, 1), "stunden_aktiv": len(st), "laengste_luecke_h": luecke,
                  "bot": bot, "umsatz": d["umsatz"], "closed_pnl": d["pnl"], "bester_coin": best}
    return out


def reaktionszeit(kurse: dict, ereignisse: list) -> float | None:
    """Median der Minuten von einer Bewegung >= 1 % in 15 min bis zum nächsten Trade des Kontos (alle Coins)."""
    if not ereignisse:
        return None
    zeiten = sorted(ts for ts, _, _, _ in ereignisse)
    werte = []
    for coin, k in kurse.items():
        if len(k.ts) < 20:
            continue
        for i in range(15, len(k.ts), 5):
            if k.ts[i] - k.ts[i - 15] > 16 * 60:
                continue
            if abs(k.close[i] / k.close[i - 15] - 1.0) >= 0.01:
                t_move = k.ts[i]; j = bisect.bisect_left(zeiten, t_move)
                if j < len(zeiten) and zeiten[j] - t_move <= 6 * 3600:
                    werte.append((zeiten[j] - t_move) / 60.0)
    return statistics.median(werte) if werte else None


def roi_12h(con, addrs, now: int) -> dict:
    """
    Eigene 12-h-Rechnung (U5): realisierter Gewinn Σ closedPnl der Fills der letzten 12 h (nach REST-Nachtrag)
    plus Änderung des unrealisierten Gewinns (jüngste whale_positions-Zeile je Coin gegen die Zeile vor 12 h),
    relativ zum Kontowert. None, wenn für das Konto in 12 h weder Fills mit closedPnl noch Positionszeilen
    vorliegen -- dann gilt Hyperliquids roi_1d.
    """
    out: dict = {}
    if not addrs:
        return out
    a_l = [a.lower() for a in addrs]; marks = ",".join("?" * len(a_l)); t12 = now - 12 * 3600
    real: dict = {}; hat_fills: set = set()
    try:
        for a, pnl, n in con.execute(f"SELECT lower(addr), SUM(COALESCE(closed_pnl,0)), COUNT(*) FROM lb_fills WHERE ts>=? AND lower(addr) IN ({marks}) GROUP BY 1", (t12, *a_l)):
            real[a] = pnl or 0.0
            if n:
                hat_fills.add(a)
    except sqlite3.OperationalError:
        pass
    upnl_now: dict = {}; upnl_alt: dict = {}
    try:
        for a, coin, u in con.execute(f"""SELECT lower(w.addr), w.coin, w.upnl FROM whale_positions w WHERE lower(w.addr) IN ({marks})
                                          AND w.ts=(SELECT MAX(ts) FROM whale_positions x WHERE x.addr=w.addr AND x.coin=w.coin) AND w.event!='close'""", a_l):
            upnl_now[(a, coin)] = u or 0.0
        for a, coin, u in con.execute(f"""SELECT lower(w.addr), w.coin, w.upnl FROM whale_positions w WHERE lower(w.addr) IN ({marks}) AND w.ts<=?
                                          AND w.ts=(SELECT MAX(ts) FROM whale_positions x WHERE x.addr=w.addr AND x.coin=w.coin AND x.ts<=?) AND w.event!='close'""", (*a_l, t12, t12)):
            upnl_alt[(a, coin)] = u or 0.0
    except sqlite3.OperationalError:
        pass
    av = {}
    try:
        for a, v in con.execute(f"SELECT lower(addr), account_value FROM pool_accounts WHERE lower(addr) IN ({marks})", a_l):
            av[a] = v or 0.0
    except sqlite3.OperationalError:
        pass
    for a in a_l:
        d_upnl = sum(v for (x, c), v in upnl_now.items() if x == a) - sum(v for (x, c), v in upnl_alt.items() if x == a)
        hat_pos = any(x == a for (x, c) in upnl_now) or any(x == a for (x, c) in upnl_alt)
        if a not in hat_fills and not hat_pos:
            out[a] = None; continue
        pnl = real.get(a, 0.0) + d_upnl
        out[a] = {"pnl_12h": pnl, "roi_12h": (pnl / av[a]) if av.get(a) else None, "realisiert": real.get(a, 0.0), "d_upnl": d_upnl}
    return out


# ----------------------------------------------------------------------------------------------
# Gesamtbewertung
# ----------------------------------------------------------------------------------------------
def bewerten(con, now: int | None = None, coins: list | None = None, seed: int = 7) -> dict:
    now = now or int(time.time()); seit = now - QUALI_TAGE * 86_400
    coins = coins or [r[0] for r in con.execute("SELECT coin FROM bars WHERE ts>=? GROUP BY coin", (now - 86_400,))]
    try:
        pool = con.execute("SELECT addr, account_value, pnl_7d, roi_7d, pnl_1d, roi_1d, vlm_1d, vlm_7d, name, zuletzt_erfuellt FROM pool_accounts "
                           "WHERE zuletzt_erfuellt >= ?", (now - 7 * 86_400,)).fetchall()
    except sqlite3.OperationalError:
        pool = []
    try:
        gesperrt = {r[0].lower() for r in con.execute("SELECT addr FROM konto_status WHERE status IN ('gesperrt','vorlaeufig')")}   # 23.29
    except sqlite3.OperationalError:
        gesperrt = set()
    addrs = [r[0].lower() for r in pool if r[0].lower() not in gesperrt]
    akt = aktivitaet(con, addrs, seit, now)
    # Kandidaten für die teure Lift-Rechnung: aktiv im Rahmen und Gewinn > 0
    info = {r[0].lower(): r for r in pool}
    kand = [a for a in addrs if PROFI_MIN_TRADES <= akt[a]["trades_tag"] <= PROFI_MAX_TRADES and (info[a][2] or 0) > 0]
    ereignisse = lade_ereignisse(con, kand, coins, seit, now)
    kurse = {c: Kurs(con, c, seit, now) for c in coins}
    rng = random.Random(seed)
    konten = []
    for a in addrs:
        r = info[a]; ak = akt[a]
        rec = {"addr": a, "name": r[8] or "", "account_value": r[1], "pnl_7d": r[2], "roi_7d": r[3], "pnl_1d": r[4], "roi_1d": r[5],
               "vlm_1d": r[6], "vlm_7d": r[7], **ak, "gruende": [], "qualifiziert": False,
               "n_exits": 0, "exit_lift": None, "exit_t": None, "entry_lift": None, "entry_t": None, "reaktion_min": None}
        if ak["trades_tag"] < PROFI_MIN_TRADES:
            rec["gruende"].append(f"nur {ak['trades_tag']:.0f} Trades/Tag in den verfolgten Coins (mind. {PROFI_MIN_TRADES})")
        elif ak["trades_tag"] > PROFI_MAX_TRADES:
            rec["gruende"].append(f"{ak['trades_tag']:.0f} Trades/Tag (Grenze {PROFI_MAX_TRADES})")
        if (r[2] or 0) <= 0:
            rec["gruende"].append(f"Gewinn 7 T {((r[2] or 0) / 1e6):+.2f} Mio (mind. > 0)")
        if a in kand:
            ev = ereignisse.get(a, [])
            l = bewerte_konto(con, a, ev, kurse, seit, now, rng)
            rec.update({k: v for k, v in l.items()})
            rec["reaktion_min"] = reaktionszeit(kurse, ev)
            t_ = l.get("timing") or {}
            if (t_.get("n") or 0) < MIN_ENTSCHEIDUNGEN:                  # 23.32: Ein- und Ausstiege zusammen
                rec["gruende"].append(f"nur {t_.get('n', 0)} bewertbare Ein-/Ausstiege in 7 T (mind. {MIN_ENTSCHEIDUNGEN})")
            elif not ((t_.get("p_glueck") if t_.get("p_glueck") is not None else 1.0) <= P_GLUECK_MAX and (t_.get("lift_s") or 0) > 0):
                rec["gruende"].append(f"{t_['treffer']} von {t_['n']} Ein-/Ausstiegen richtig (Zufall {t_['zufall'] * 100:.0f} %) -- "
                                      f"Glückswahrscheinlichkeit {t_['p_glueck'] * 100:.0f} % (nötig ≤ {P_GLUECK_MAX * 100:.0f} %)")
            # Einstiege nur als Veto (23.32): ab ENTRY_VETO_MIN Einstiegen und belegbar FALSCHEM Einstiegs-Timing
            # (Entry-Lift negativ, t ≤ −1). Wenige Einstiege entscheiden nichts.
            if (l.get("n_entries") or 0) >= ENTRY_VETO_MIN and l["entry_lift"] is not None and l["entry_lift"] < 0 and (l["entry_t"] or 0) <= -T_MIN:
                rec["gruende"].append(f"Entry-Lift {l['entry_lift'] * 100:+.0f} pp, t {l['entry_t']:.1f} (Einstiege belegbar vor Gegenbewegungen)")
        rec["qualifiziert"] = not rec["gruende"]
        konten.append(rec)
    quali = [k for k in konten if k["qualifiziert"]]
    r12 = roi_12h(con, [k["addr"] for k in quali], now)
    n_eigen = 0
    for k in quali:
        e = r12.get(k["addr"])
        k["roi_12h"] = e["roi_12h"] if e else None; k["pnl_12h"] = e["pnl_12h"] if e else None
        k["rang_wert"] = k["roi_12h"] if (e and e["roi_12h"] is not None) else (k["roi_1d"] if k["roi_1d"] is not None else -1e9)
        k["rang_quelle"] = "12 h eigen" if (e and e["roi_12h"] is not None) else "HL 1 T"
        n_eigen += 1 if k["rang_quelle"] == "12 h eigen" else 0
    quali.sort(key=lambda k: -k["rang_wert"])
    stempel = now // (12 * 3600) * (12 * 3600)
    return {"ts": now, "stempel": stempel,
            "rang_basis": f"ROI 12 h aus eigenen Daten (Σ closedPnl 12 h + Δ uPnL) für {n_eigen} von {len(quali)}; Konten ohne Nachtrag: Hyperliquids roi_1d",
            "n_pool": len(pool), "n_gesperrt": sum(1 for r in pool if r[0].lower() in gesperrt), "n_aktiv": len(kand), "n_qualifiziert": len(quali),
            "coins": coins, "top": quali[:20], "alle": konten}


# ----------------------------------------------------------------------------------------------
# Nulltest / Positivtest der Lift-Rechnung
# ----------------------------------------------------------------------------------------------
def _glueck_test() -> tuple:
    """
    23.32: exakte Glückswahrscheinlichkeit (Beispiele bei 40 % Zufall), die Schwelle 5 %, die Rangfolge nach gedämpfter
    Untergrenze und die Fehlalarmrate an 3.000 Zufallskonten (4–20 Entscheidungen, Zufallsquoten 30–50 %).
    """
    q = 0.4
    werte = {"4/4": glueck_p(4, [q] * 4), "3/4": glueck_p(3, [q] * 4), "4/5": glueck_p(4, [q] * 5), "8/10": glueck_p(8, [q] * 10), "7/10": glueck_p(7, [q] * 10)}
    soll = {"4/4": 0.0256, "3/4": 0.1792, "4/5": 0.0870, "8/10": 0.0123, "7/10": 0.0548}
    genau = all(abs(werte[k] - soll[k]) < 0.0005 for k in soll)
    schwelle = werte["4/4"] <= P_GLUECK_MAX and werte["8/10"] <= P_GLUECK_MAX and not any(werte[k] <= P_GLUECK_MAX for k in ("3/4", "4/5", "7/10"))
    lcb = lambda k, n: timing_beleg([(1, q, "exit")] * k + [(0, q, "exit")] * (n - k))["lcb"]
    rang = lcb(12, 15) > lcb(8, 10) > lcb(4, 4) > 0
    rng = random.Random(11); fehl = 0; n_k = 3000
    for _ in range(n_k):
        n = rng.randint(4, 20); qs = [rng.uniform(0.3, 0.5) for _ in range(n)]
        tr = sum(1 for x in qs if rng.random() < x)
        if glueck_p(tr, qs) <= P_GLUECK_MAX:
            fehl += 1
    ok = genau and schwelle and rang and fehl / n_k <= P_GLUECK_MAX + 0.01
    return ok, (f"Glückswahrscheinlichkeit bei 40 % Zufall: 4/4 {werte['4/4'] * 100:.1f} %, 3/4 {werte['3/4'] * 100:.1f} %, 4/5 {werte['4/5'] * 100:.1f} %, "
                f"8/10 {werte['8/10'] * 100:.1f} %, 7/10 {werte['7/10'] * 100:.1f} % · Rangfolge 12/15 > 8/10 > 4/4: {'ja' if rang else 'NEIN'} · "
                f"Zufallskonten qualifiziert: {fehl / n_k * 100:.1f} % (Soll ≤ {P_GLUECK_MAX * 100:.0f} %)")


def _richtung_trend_test() -> tuple:
    """
    23.21, fester Zeitpunkt (deterministisch): (1) Richtungslogik -- Long auf vor Anstieg, Short auf vor Rückgang, Long zu vor
    Rückgang, Short zu vor Anstieg (auch Flip) = richtig, die vier Gegenstücke = falsch; (2) Trendfalle -- 60 Short-Schließungen
    zu ZUFÄLLIGEN Zeiten in einem steigenden Markt dürfen keinen belegten Lift bekommen (vorher +41 pp, t 3,2).
    """
    global MIN_EXITS
    t_ende = 1_790_006_400; von = t_ende - 8 * 86_400
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    a_ = t_ende - 5 * 86_400; b_ = t_ende - 3 * 86_400
    rows = []
    for t in range(von, t_ende + 60, 60):
        c = 100.0 * (1.05 if a_ <= t < a_ + 86_400 else 1.0) * (0.95 if b_ <= t < b_ + 86_400 else 1.0)
        rows.append((t, "AAA", c, c, c, c, 1, 1))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    kurse = {"AAA": Kurs(con, "AAA", von, t_ende)}
    faelle = [(a_ - 600, "entry", "long", True), (b_ - 600, "entry", "short", True), (b_ - 600, "exit", "long", True),
              (a_ - 600, "exit", "short", True), (b_ - 600, "entry", "short", True),            # Flip auf Short = Einstieg Short
              (b_ - 600, "entry", "long", False), (a_ - 600, "entry", "short", False), (a_ - 600, "exit", "long", False),
              (b_ - 600, "exit", "short", False)]
    alt = MIN_EXITS; MIN_EXITS = 1; richtig = 0
    try:
        for ts, art, side, soll in faelle:
            o = bewerte_konto(con, "x", [(ts, "AAA", art, side)], kurse, von, t_ende, random.Random(1))
            l_ = o["exit_lift"] if art == "exit" else o["entry_lift"]
            richtig += ((l_ is not None and l_ > 0) == soll)
    finally:
        MIN_EXITS = alt
    con.execute("DELETE FROM bars"); rng = random.Random(5); lp = math.log(100.0); rows = []
    for t in range(von, t_ende + 60, 60):
        lp += rng.gauss(0.00004, 0.0012); c = math.exp(lp)
        rows.append((t, "BBB", c, c, c, c, 1, 1)); rows.append((t, "PAX", 100.0, 100.0, 100.0, 100.0, 1, 1))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    k2 = {c: Kurs(con, c, von, t_ende) for c in ("BBB", "PAX")}
    ev = sorted((rng.randint(t_ende - 7 * 86_400, t_ende - 13 * 3600), "BBB", "exit", "short") for _ in range(60))
    o = bewerte_konto(con, "x", ev, k2, von, t_ende, random.Random(2))
    trend_ok = o["exit_lift"] is not None and (abs(o["exit_lift"]) < 0.15 or (o["exit_t"] or 0) < 2)
    ok = richtig == len(faelle) and trend_ok
    return ok, (f"Richtungslogik {richtig} von {len(faelle)} richtig · Trendfalle: zufällige Short-Schließungen im steigenden Markt "
                f"Lift {(o['exit_lift'] or 0) * 100:+.0f} pp, t {(o['exit_t'] or 0):.1f} (Soll kein Beleg)")


def nulltest(verbose: bool = True, seed: int = 3) -> bool:
    """Rauschen: Exit-Lift ≈ 0 (|Mittel| < 5 pp über 40 Konten); Kante: Ausstiege kurz vor konstruierten Rückgängen -> Lift deutlich > 0."""
    rng = random.Random(seed); con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    now = int(time.time()) // 60 * 60; seit = now - QUALI_TAGE * 86_400; px = 100.0; rows = []
    t = seit - 3600
    while t <= now:
        r = rng.gauss(0, 0.0006); px *= math.exp(r); rows.append((t, "BTC", px, px * (1 + abs(rng.gauss(0, 0.0003))), px * (1 - abs(rng.gauss(0, 0.0003))), px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    k = Kurs(con, "BTC", seit, now); kurse = {"BTC": k}
    # Rauschkonten: zufällige Ausstiege
    lifts = []
    for i in range(40):
        ev = sorted((rng.randint(seit, now - HORIZONT - 60), "BTC", "exit", rng.choice(["long", "short"])) for _ in range(25))
        l = bewerte_konto(con, f"0x{i:040x}", ev, kurse, seit, now, random.Random(seed + i))
        if l["exit_lift"] is not None:
            lifts.append(l["exit_lift"])
    mittel = statistics.mean(lifts) if lifts else 0.0
    ok_null = abs(mittel) < 0.05
    # Kante: Ausstiege genau vor den größten 12-h-Rückgängen
    ts_list = k.ts
    kand = []
    for t0 in range(seit, now - HORIZONT - 60, 1800):
        r = k.rueckgang_binnen(t0, HORIZONT)
        if r is not None and r <= -KORREKTUR:
            kand.append(t0)
    ev = sorted((t0, "BTC", "exit", "long") for t0 in kand[:40])
    l = bewerte_konto(con, "0xkante", ev, kurse, seit, now, random.Random(99)) if len(ev) >= MIN_EXITS else {"exit_lift": None, "exit_t": None}
    ok_kante = (l["exit_lift"] or 0) > 0.3 and (l["exit_t"] or 0) >= 2 if l["exit_lift"] is not None else False
    if verbose:
        print(f"  Nulltest Exit-Lift: 40 Rauschkonten, mittlerer Lift {mittel * 100:+.1f} pp (Soll |x| < 5) -> {'ok' if ok_null else 'FEHL'}")
        print(f"  Positivtest: {len(ev)} Ausstiege vor konstruierten Rückgängen -> Lift {((l['exit_lift'] or 0) * 100):+.0f} pp, t {(l['exit_t'] or 0):.1f} (Soll > 30 pp, t >= 2) -> {'ok' if ok_kante else 'FEHL'}")
    ok_rt, txt_rt = _richtung_trend_test()
    ok_gl, txt_gl = _glueck_test()
    if verbose:
        print(f"  {txt_gl} -> {'ok' if ok_gl else 'FEHL'}")
    ok_rt = ok_rt and ok_gl
    if verbose:
        print(f"  {txt_rt} -> {'ok' if ok_rt else 'FEHL'}")
        print("  Ergebnis:", "bestanden" if ok_null and ok_kante and ok_rt else "NICHT bestanden")
    return ok_null and ok_kante and ok_rt


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    print(__doc__)
