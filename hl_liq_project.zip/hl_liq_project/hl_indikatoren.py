#!/usr/bin/env python3
"""
hl_indikatoren.py -- neue Treiber und Regime-Flags aus vorhandenen Tabellen (Auditbericht v3, Abschnitt 3).

Alle Funktionen sind rein: Sie lesen die Hauptdatenbank, geben ein dict {"score", "text", ...}
oder None zurück (None = zu wenig Daten -> Treiber erscheint nicht). Scores liegen in [-1, 1];
Vorzeichen: + = aufwärts. Was die Langzeitstudien als VOLATILITÄTS-Signal (nicht Richtung)
ausweisen, kommt nicht als Richtungs-Score, sondern als Regime-Flag in regime(): Es weitet das
Prognoseband, verschiebt aber nichts.

Evidenz (Auditbericht v3, Quellen: TradeWize-Langzeitstudien 6-7 Jahre Binance, BIS WP 1087,
arXiv 2607.27070):
  N3  OI-Perzentil     OI > 1,15x 30-T-Mittel: Folgewoche Range 17 % statt 12 %, Drawdowns > 10 % in
                       37 % statt 16 % der Fälle, Richtung 44 % statt 53 % aufwärts -> Regime + leichter Kontra
  N7  Crowding         Long/Short-Verhältnis der Top-Konten gegen die eigene Historie: unterstes Dezil
                       +6,9 %/30 T (BTC), oberstes nur mild -> Extreme als Kontra, Änderung als Trend
  N8  ETF-Momentum     Flüsse Granger-kausal, Wirkung Tag 3-4 -> 3-T- gegen 10-T-Mittel
  N9  Vol-Regime       Parkinson-sigma 24 h gegen 20 Tage: Band-Multiplikator; Spike -> Reversion
  N1  Funding-Spread   Basis/Carry ist das stärkste untersuchte Signal: HL-Funding gegen Bybit/OKX/
                       Binance, Perzentil des Spreads -> Kontra
  N6  Liquidationen    Kapitulation über drei Börsen (Bybit-Stream vollständig); Intensität als Regime
      Varianz-Kompression des Taker-Flows (bars10): einzige placebotestete Regularität vor Kaskaden
                       -> Regime-Flag, kein Trigger

Jeder Treiber startet mit kleinem Prior, lernt über die Kalibrierung, unterliegt dem Killkriterium
und muss den Nulltest bestehen (hl_forecast --nulltest: kein Vorzeichen-Bias auf Rauschen).
"""
from __future__ import annotations

import math
import sqlite3
import time

__all__ = ["oi_perzentil", "crowding", "etf_momentum", "vol_regime", "funding_spread", "liquidationsdruck",
           "varianz_kompression", "regime", "PRIORS_NEU"]

PRIORS_NEU = {"OI-Überhitzung": 0.3, "Crowding-Extrem": 0.5, "Crowding-Trend 7 T": 0.4, "ETF-Momentum": 0.5,
              "Vol-Spike-Reversion": 0.3, "Funding-Spread": 0.4, "Liquidationsdruck (3 Börsen)": 0.5}


def _rank(wert: float, reihe: list) -> float | None:
    """
    Perzentil von `wert` in `reihe` als MIDRANK: Bindungen zählen halb (Audit v4 M1 -- mit striktem
    "<" bekam ein Plateau, etwa acht Stunden konstantes Funding, Perzentil 0 und damit ein
    Vollsignal). None bei zu kurzer Reihe oder wenn die Reihe praktisch konstant ist.
    """
    if not reihe or len(reihe) < 20:
        return None
    lo, hi = min(reihe), max(reihe)
    if hi - lo <= 1e-12 * max(1.0, abs(hi), abs(lo)):
        return None                                         # kein Rang auf einer Konstanten
    kleiner = sum(1 for x in reihe if x < wert); gleich = sum(1 for x in reihe if x == wert)
    return (kleiner + 0.5 * gleich) / len(reihe)


def _clip(x, lo, hi):
    return max(lo, min(hi, x))


# ---------------------------------------------------------------------------
# N3 OI-Perzentil
# ---------------------------------------------------------------------------

def oi_perzentil(con, coin: str, days: int = 90, min_days: int = 14) -> dict | None:
    now = int(time.time())
    # Quellenwahl (Audit v4 L1): Binance-OI, wenn lang genug UND frisch; sonst Hyperliquid-OI (ctx_bars),
    # wenn lang genug und frisch; sonst nichts.
    reihe = []; span = None
    for sql_r, sql_s in (("SELECT value FROM bnc_metrics WHERE coin=? AND metric='open_interest' AND ts>=? ORDER BY ts",
                          "SELECT MIN(ts), MAX(ts) FROM bnc_metrics WHERE coin=? AND metric='open_interest' AND ts>=?"),
                         ("SELECT oi FROM ctx_bars WHERE coin=? AND ts>=? AND oi>0 ORDER BY ts",
                          "SELECT MIN(ts), MAX(ts) FROM ctx_bars WHERE coin=? AND ts>=? AND oi>0")):
        try:
            r_ = [r[0] for r in con.execute(sql_r, (coin, now - days * 86400)) if r[0]]
            s_ = con.execute(sql_s, (coin, now - days * 86400)).fetchone()
        except sqlite3.OperationalError:
            continue
        if r_ and s_ and s_[0] and s_[1] - s_[0] >= min_days * 86400 and now - s_[1] <= 6 * 3600:
            reihe, span = r_, s_; break
    if not reihe:
        return None
    akt = reihe[-1]
    pct = _rank(akt, reihe[:-1])
    if pct is None:
        return None
    ueberhitzt = _clip((pct - 0.90) / 0.10, 0.0, 1.0)
    # Richtung: nur die leichte Kontra-Neigung der Studie (44 % statt 53 % aufwärts), gedeckelt
    score = -0.6 * ueberhitzt
    return {"pct": pct, "ueberhitzt": ueberhitzt, "score": score,
            "text": f"Open Interest im {pct * 100:.0f}. Perzentil der letzten {min(days, (span[1] - span[0]) // 86400)} Tage"
                    + (" — überhitzt: breitere Spanne, Drawdown-Risiko, leichte Kontra-Neigung" if ueberhitzt > 0 else " — unauffällig")}


# ---------------------------------------------------------------------------
# N7 Crowding der Top-Konten (lb_trend, stündlich, unbegrenzt)
# ---------------------------------------------------------------------------

def crowding(con, coin: str, top_n: int = 20, days: int = 365, min_days: int = 14) -> dict | None:
    now = int(time.time())
    try:
        rows = con.execute("SELECT ts, usd_long, usd_short FROM lb_trend WHERE coin=? AND top_n=? AND ts>=? ORDER BY ts",
                           (coin, top_n, now - days * 86400)).fetchall()
    except sqlite3.OperationalError:
        return None
    reihe = [(ts, (l - s) / (l + s)) for ts, l, s in rows if (l or 0) + (s or 0) > 0]
    if len(reihe) < 24 * min_days or now - reihe[-1][0] > 3 * 3600:
        return None
    crowd = reihe[-1][1]
    pct = _rank(crowd, [c for _, c in reihe[:-1]])
    if pct is None:
        return None
    # Kontra an den Extremen (asymmetrisch wie in der Studie: unten stark, oben mild)
    if pct <= 0.10:
        kontra = (0.10 - pct) / 0.10            # 0 .. 1
    elif pct >= 0.90:
        kontra = -0.5 * (pct - 0.90) / 0.10     # 0 .. -0,5
    else:
        kontra = 0.0
    # Trend: Änderung über 7 Tage, normiert an der Verteilung solcher Änderungen
    t7 = reihe[-1][0] - 7 * 86400
    alt = [c for ts, c in reihe if ts <= t7]
    d7 = crowd - alt[-1] if alt else None
    trend = None
    if d7 is not None and len(reihe) > 24 * 21:
        diffs = []
        by_ts = {ts: c for ts, c in reihe}
        for ts, c in reihe[::6]:
            c0 = by_ts.get(ts - 7 * 86400)
            if c0 is not None:
                diffs.append(c - c0)
        if len(diffs) >= 20:
            sd = (sum((x - sum(diffs) / len(diffs)) ** 2 for x in diffs) / (len(diffs) - 1)) ** 0.5
            if sd > 1e-9:
                trend = math.tanh(d7 / sd)
    return {"crowd": crowd, "pct": pct, "kontra": kontra, "trend": trend, "d7": d7,
            "text_kontra": f"Netto-Ausrichtung der Top-{top_n} {crowd:+.2f} ({'long' if crowd > 0 else 'short'}-lastig), "
                           f"{pct * 100:.0f}. Perzentil der eigenen Historie" + (" — Extrem, Kontra" if kontra else ""),
            "text_trend": (f"Ausrichtung über 7 Tage {d7:+.2f} verändert" if d7 is not None else "")}


# ---------------------------------------------------------------------------
# N8 ETF-Momentum (etf_flows: eine Zeile je Tag, Mio USD)
# ---------------------------------------------------------------------------

def etf_momentum(con, coin: str) -> dict | None:
    if coin not in ("BTC", "ETH"):
        return None
    try:
        rows = con.execute("SELECT day, flow_musd FROM etf_flows WHERE coin=? ORDER BY day DESC LIMIT 60", (coin,)).fetchall()
    except sqlite3.OperationalError:
        return None
    fl = [r[1] for r in rows if r[1] is not None]
    if len(fl) < 12:
        return None
    try:                                                  # Audit v4 L3: Frische -- bei gestopptem Farside-Import nicht ewig feuern
        juengst = time.mktime(time.strptime(rows[0][0], "%Y-%m-%d"))
        if time.time() - juengst > 4 * 86400:
            return None
    except ValueError:
        return None
    m3 = sum(fl[:3]) / 3; m10 = sum(fl[:10]) / 10
    basis = fl[:60]
    mean = sum(basis) / len(basis)
    sd = (sum((x - mean) ** 2 for x in basis) / max(1, len(basis) - 1)) ** 0.5
    if sd < 1e-6:
        return None
    score = math.tanh((m3 - m10) / sd)
    return {"m3": m3, "m10": m10, "score": score,
            "text": f"ETF-Flüsse 3-T-Mittel {m3:+.0f} Mio gegen 10-T-Mittel {m10:+.0f} Mio (jüngster Tag {rows[0][0]})"}


# ---------------------------------------------------------------------------
# N9 Vol-Regime: Parkinson-sigma 24 h gegen 20 Tage
# ---------------------------------------------------------------------------

def _parkinson(hl_pairs: list) -> float | None:
    v = [math.log(h / l) ** 2 for h, l in hl_pairs if h and l and h >= l > 0]
    if len(v) < 6:
        return None
    return math.sqrt(sum(v) / len(v) / (4 * math.log(2)))


def vol_regime(con, coin: str) -> dict | None:
    now = int(time.time())
    try:
        rows = con.execute("SELECT ts, high, low, close FROM bars WHERE coin=? AND ts>=? ORDER BY ts", (coin, now - 21 * 86400)).fetchall()
    except sqlite3.OperationalError:
        return None
    if len(rows) < 20 * 24 * 30:
        return None
    # Stunden-Hoch/Tief der letzten 24 h, Tages-Hoch/Tief der 20 Tage davor
    std = {}
    for ts, h, l, c in rows:
        k = ts // 3600
        e = std.get(k)
        if e is None:
            std[k] = [h, l]
        else:
            e[0] = max(e[0], h); e[1] = min(e[1], l)
    h24 = [v for k, v in std.items() if k * 3600 >= now - 24 * 3600]
    tag = {}
    for ts, h, l, c in rows:
        if ts < now - 24 * 3600:
            k = ts // 86400
            e = tag.get(k)
            if e is None:
                tag[k] = [h, l]
            else:
                e[0] = max(e[0], h); e[1] = min(e[1], l)
    s24 = _parkinson(h24); s20 = _parkinson(list(tag.values()))
    if not s24 or not s20:
        return None
    ratio = (s24 * math.sqrt(24)) / s20              # Stunden-sigma auf Tag skaliert gegen Tages-sigma
    mult = _clip(ratio, 0.7, 1.6)
    p_now = rows[-1][3]; p_24 = next((c for ts, h, l, c in rows if ts >= now - 24 * 3600), None)
    ret24 = (p_now / p_24 - 1) if p_24 else 0.0
    spike = _clip((ratio - 1.5) / 1.5, 0.0, 1.0)
    reversion = -math.copysign(spike, ret24) if spike > 0 and abs(ret24) > 0.005 else 0.0
    return {"ratio": ratio, "band_mult": mult, "spike": spike, "score": reversion, "ret24": ret24,
            "text": f"Volatilität 24 h ist das {ratio:.2f}-fache der 20-Tage-Norm" + (f" — Spike nach {ret24 * 100:+.1f} %: Rückschlagneigung" if reversion else "")}


# ---------------------------------------------------------------------------
# N1 Funding-Spread HL gegen Fremdbörsen
# ---------------------------------------------------------------------------

def funding_spread(con, coin: str, days: int = 30, min_days: int = 3) -> dict | None:
    now = int(time.time())
    hl, fremd, bnc = [], [], []                           # Audit v4 L2: je Quelle ein try -- eine fehlende Tabelle kippt nicht alles
    try:
        hl = con.execute("SELECT ts, funding FROM ctx_bars WHERE coin=? AND ts>=? AND funding IS NOT NULL ORDER BY ts",
                         (coin, now - days * 86400)).fetchall()
    except sqlite3.OperationalError:
        return None
    try:
        fremd = con.execute("SELECT ts, exchange, value FROM ext_metrics WHERE coin=? AND metric='funding_8h' AND ts>=? ORDER BY ts",
                            (coin, now - days * 86400)).fetchall()
    except sqlite3.OperationalError:
        pass
    try:
        bnc = con.execute("SELECT ts, value FROM bnc_metrics WHERE coin=? AND metric='funding' AND ts>=? ORDER BY ts",
                          (coin, now - days * 86400)).fetchall()
    except sqlite3.OperationalError:
        pass
    if len(hl) < 24 * min_days or not (fremd or bnc):
        return None
    # je Stunde: HL-Funding (Stundensatz x 8 = 8-h-Satz) minus Mittel der Fremdbörsen (8-h-Sätze)
    hl_h = {}
    for ts, f in hl:
        hl_h[ts // 3600] = f * 8
    fr_h: dict = {}
    for ts, ex, v in fremd:
        fr_h.setdefault(ts // 3600, []).append(v)
    for ts, v in bnc:
        fr_h.setdefault(ts // 3600, []).append(v)
    reihe = []
    for k in sorted(hl_h):
        if k in fr_h:
            reihe.append((k, hl_h[k] - sum(fr_h[k]) / len(fr_h[k])))
    if len(reihe) < 24 * min_days or now // 3600 - reihe[-1][0] > 3:
        return None
    spread = reihe[-1][1]
    pct = _rank(spread, [s for _, s in reihe[:-1]])
    if pct is None:
        return None
    score = -_clip((pct - 0.5) * 2, -1, 1) * (1.0 if abs(spread) >= 0.0001 else 0.5)   # Carry: teuer auf HL -> Kontra
    return {"spread_8h": spread, "pct": pct, "score": score, "n_fremd": len({e for _, e, _ in fremd}) + (1 if bnc else 0),
            "text": f"HL-Funding {spread * 100:+.3f} %/8 h über dem Mittel von {len({e for _, e, _ in fremd}) + (1 if bnc else 0)} Fremdbörsen "
                    f"({pct * 100:.0f}. Perzentil der {len(reihe) // 24} Tage)" + (" — Carry gegen HL" if score < -0.4 else " — Carry für HL" if score > 0.4 else "")}


# ---------------------------------------------------------------------------
# N6 Liquidationsdruck über drei Börsen + Intensität als Regime
# ---------------------------------------------------------------------------

def liquidationsdruck(con, coin: str, days: int = 30) -> dict | None:
    now = int(time.time())
    # 21.09.: Stundensummen in SQL (GROUP BY) statt Rohzeilen -- der Bybit-Stream liefert tausende
    # Zeilen je Stunde; 30 Tage Rohzeilen je Coin und Prognose kosteten drei Kerne SQLite + Python.
    stunden: dict = {}; n_rows = 0
    for sql in ("SELECT ts/3600, side, SUM(notional), COUNT(*) FROM bnc_liquidations WHERE coin=? AND ts>=? GROUP BY 1, 2",
                "SELECT ts/3600, side, SUM(notional), COUNT(*) FROM ext_liquidations WHERE coin=? AND ts>=? GROUP BY 1, 2",
                # H1 (Audit v10): liquidations speichert die Rohseite A/B (A = Verkauf des liquidierten Kontos = Long liquidiert);
                # der alte Filter side IN ('long','short') ließ null HL-Zeilen durch
                "SELECT ts/3600, CASE side WHEN 'A' THEN 'long' WHEN 'B' THEN 'short' ELSE side END, SUM(COALESCE(px,0)*COALESCE(sz,0)), COUNT(*) "
                "FROM liquidations WHERE coin=? AND ts>=? AND side IN ('A','B','long','short') GROUP BY 1, 2"):
        try:
            for h, side, usd, n in con.execute(sql, (coin, now - days * 86400)):
                d = stunden.setdefault(int(h), [0.0, 0.0])
                d[0 if str(side) == "long" else 1] += usd or 0.0
                n_rows += n or 0
        except sqlite3.OperationalError:
            continue
    if n_rows < 200:
        return None
    jetzt = now // 3600
    letzte = [stunden.get(jetzt - 1, [0.0, 0.0]), stunden.get(jetzt, [0.0, 0.0])]
    l_now = sum(v[0] for v in letzte); s_now = sum(v[1] for v in letzte)
    # Audit v4 M2: Referenz aus ECHTEN rollierenden 2-h-Summen (gleiche Varianz wie die Messgröße),
    # nicht aus verdoppelten Einzelstunden -- die hatten die Perzentile zur Mitte gedrückt.
    keys = sorted(k for k in stunden if k < jetzt - 1)
    basis = [(stunden[k][0] + stunden[k][1]) + (stunden.get(k - 1, [0.0, 0.0])[0] + stunden.get(k - 1, [0.0, 0.0])[1]) for k in keys]
    if len(basis) < 48:
        return None
    total = l_now + s_now
    pct = _rank(total, basis)
    if pct is None:
        return None
    imb = (l_now - s_now) / total if total > 0 else 0.0     # + = Longs liquidiert (Kapitulation), - = Shorts (Squeeze)
    intens = _clip((pct - 0.90) / 0.10, 0.0, 1.0)
    # Kontra wie die bestehende Kapitulation: Long-Liquidationen -> Erholungschance, Short-Squeeze -> Rückschlag
    score = imb * intens
    return {"long_usd": l_now, "short_usd": s_now, "imb": imb, "pct": pct, "intens": intens, "score": score,
            "text": f"Liquidationen 2 h über 3 Börsen: Longs {l_now / 1e6:.1f} Mio, Shorts {s_now / 1e6:.1f} Mio "
                    f"({pct * 100:.0f}. Perzentil der {len(basis) // 24} Tage)"
                    + (" — Kapitulation, Erholungschance" if score > 0.3 else " — Squeeze, Rückschlagrisiko" if score < -0.3 else "")}


# ---------------------------------------------------------------------------
# Varianz-Kompression des Taker-Flows (bars10) -- Regime-Flag
# ---------------------------------------------------------------------------

_VAR_CACHE: dict = {}


def varianz_kompression(con, coin: str, days: int = 30) -> dict | None:
    """
    Varianz der 10-s-Salden (vol_buy - vol_sell) je Stunde; die laufende (abgeschlossene) Stunde
    gegen die Verteilung der letzten `days` Tage. Kompression = unterstes Dezil -> Kaskadenrisiko.
    Die Verteilung wird je Coin und Tag zwischengespeichert (259k Zeilen je Rechnung).
    """
    now = int(time.time())
    tag = now // 86400
    key = (coin, tag)
    dist = _VAR_CACHE.get(key)
    try:
        if dist is None:
            rows = con.execute("SELECT ts, vol_buy, vol_sell, close FROM bars10 WHERE coin=? AND ts>=? ORDER BY ts",
                               (coin, now - days * 86400)).fetchall()
            if len(rows) < 6 * 60 * 24 * 7:
                return None
            acc: dict = {}
            for ts, vb, vs, c in rows:
                acc.setdefault(ts // 3600, []).append(((vb or 0) - (vs or 0)) * (c or 0))
            dist = []
            for k, v in acc.items():
                if len(v) >= 180 and k < now // 3600 - 1:      # Audit v4 L4: die gemessene Stunde gehört nicht in ihre Referenz
                    m = sum(v) / len(v)
                    dist.append(sum((x - m) ** 2 for x in v) / (len(v) - 1))
            for k_alt in [k for k in _VAR_CACHE if k[0] == coin and k != key]:
                _VAR_CACHE.pop(k_alt, None)                      # 21.09.: nur den eigenen Coin erneuern -- clear() warf die anderen fünf weg
            _VAR_CACHE[key] = dist
        cur = con.execute("SELECT vol_buy, vol_sell, close FROM bars10 WHERE coin=? AND ts>=? AND ts<?",
                          (coin, (now // 3600 - 1) * 3600, now // 3600 * 3600)).fetchall()
    except sqlite3.OperationalError:
        return None
    if len(dist) < 100 or len(cur) < 180:
        return None
    v = [((vb or 0) - (vs or 0)) * (c or 0) for vb, vs, c in cur]
    m = sum(v) / len(v)
    var = sum((x - m) ** 2 for x in v) / (len(v) - 1)
    pct = _rank(var, dist)
    if pct is None:
        return None
    kompr = _clip((0.10 - pct) / 0.10, 0.0, 1.0)
    return {"pct": pct, "kompression": kompr,
            "text": f"Taker-Flow-Varianz der letzten Stunde im {pct * 100:.0f}. Perzentil" + (" — komprimiert: erhöhtes Kaskadenrisiko" if kompr > 0 else "")}


# ---------------------------------------------------------------------------
# Regime: Band-Multiplikator und Flags (keine Richtung)
# ---------------------------------------------------------------------------

def regime(oi: dict | None, vol: dict | None, liq: dict | None, var: dict | None) -> dict:
    mult = (vol or {}).get("band_mult", 1.0)
    mult *= 1 + 0.25 * (oi or {}).get("ueberhitzt", 0.0)
    mult *= 1 + 0.25 * (liq or {}).get("intens", 0.0)
    mult *= 1 + 0.20 * (var or {}).get("kompression", 0.0)
    teile = []
    if vol:
        teile.append(f"Vol {vol['ratio']:.2f}× Norm")
    if oi:
        teile.append(f"OI {oi['pct'] * 100:.0f}. Perzentil" + (" überhitzt" if oi["ueberhitzt"] else ""))
    if liq and liq.get("intens"):
        teile.append(f"Liquidationen {liq['pct'] * 100:.0f}. Perzentil")
    if var and var.get("kompression"):
        teile.append(f"Taker-Varianz komprimiert ({var['pct'] * 100:.0f}. Perzentil)")
    return {"band_mult": round(_clip(mult, 0.7, 2.2), 3), "teile": teile,
            "text": " · ".join(teile) + (f" → Band ×{_clip(mult, 0.7, 2.2):.2f}" if teile else "")}
