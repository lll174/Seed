#!/usr/bin/env python3
"""
hl_konstellation.py -- zwei Rückschau-Statistiken auf den gespeicherten Prognosen (23.09.2026):

1. KONSTELLATIONEN: Für die Treiberpaare mit dem höchsten v2-Gewicht (sonst Prior): Wenn beide Treiber
   im selben Block in dieselbe Richtung ausschlagen (|Score| >= SCHWELLE), wie oft folgte der Kurs binnen
   4 h dieser Richtung? Bedingte Quote mit Wilson-Intervall auf n_eff (getrennte 4-h-Blöcke) gegen die
   Basisrate derselben Richtung über alle Blöcke -> Lift.
2. VORBEDINGUNGEN: Welche Treiber standen wie, BEVOR der Kurs binnen HORIZONT_V um mindestens BEWEGUNG
   stieg bzw. fiel? Je Treiber: Anteil der Vorlauf-Blöcke, in denen er in die Richtung der späteren
   Bewegung zeigte (Score >= SCHWELLE), gegen den Anteil über alle Blöcke (Basis = Placebo). Lift mit
   z-Wert (Zwei-Anteile-Test). Eine Bewegung wird einmal gezählt: Blöcke, deren Fenster dieselbe
   Bewegung enthalten, werden zum ersten Block zusammengefasst.

Beides ist Anzeige, kein Treiber und kein Modellbestandteil -- die Interaktionsterme für v2 (Plan U25,
Stufe 2) folgen erst, wenn hier ein Paar über Wochen einen belegten Lift zeigt.
"""
import json
import math
import sqlite3
import sys
import time

import hl_forecast as F

TAGE = 90
SCHWELLE = 0.3          # |Score| ab dem ein Treiber "ausschlägt"
BEWEGUNG = 0.03         # 3 %
HORIZONT_V = 24 * 3600  # Vorbedingungen: Bewegung binnen 24 h
BLOCK4 = 4 * 3600
MAX_PAARE = 15


def _wilson(hits, n, z=1.96):
    if n <= 0:
        return None
    p = hits / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def _z_zwei_anteile(h1, n1, h2, n2):
    if n1 <= 0 or n2 <= 0:
        return None
    p1, p2 = h1 / n1, h2 / n2; p = (h1 + h2) / (n1 + n2)
    se = math.sqrt(max(p * (1 - p), 1e-6) * (1 / n1 + 1 / n2))
    return (p1 - p2) / se if se > 0 else None


def lade(con_main, coin: str, path: str, now: int | None = None) -> dict:
    """Ein Fall je 4-h-Block (die früheste Prognose): Scores, p0, Kurs nach 4 h, max. Anstieg/Rückgang binnen HORIZONT_V."""
    now = now or int(time.time())
    st = F.store_connect(path)
    rows = st.execute("SELECT ts, price, payload FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                      (coin, now - TAGE * 86_400, now - BLOCK4)).fetchall()
    st.close()
    bars = con_main.execute("SELECT ts, close, high, low FROM bars WHERE coin=? AND ts>=? ORDER BY ts", (coin, now - (TAGE + 2) * 86_400)).fetchall()
    b_ts = [b[0] for b in bars]
    import bisect
    def close_at(t):
        i = bisect.bisect_right(b_ts, t) - 1
        return bars[i][1] if i >= 0 and t - b_ts[i] <= 120 else None
    def extrema(t, h):
        i = bisect.bisect_right(b_ts, t); j = bisect.bisect_right(b_ts, t + h)
        if j - i < 5 or t + h > b_ts[-1]:
            return None, None
        seg = bars[i:j]
        return max((s[2] or s[1]) for s in seg), min((s[3] or s[1]) for s in seg)
    seen = set(); faelle = []
    for ts, p0, payload in rows:
        b = ts // BLOCK4
        if b in seen or not p0:
            continue
        seen.add(b)
        try:
            pl = json.loads(payload)
        except (TypeError, ValueError):
            continue
        sc = {d["name"]: float(d["score"]) for d in pl.get("drivers", []) if d.get("score") is not None}
        c4 = close_at(ts + BLOCK4)
        hi, lo = extrema(ts, HORIZONT_V)
        faelle.append({"ts": ts, "block": b, "p0": p0, "sc": sc, "r4": (c4 / p0 - 1.0) if c4 else None,
                       "up": (hi / p0 - 1.0) if hi else None, "down": (lo / p0 - 1.0) if lo else None})
    return {"faelle": faelle, "now": now}


def konstellationen(faelle: list, gewichte: dict | None) -> list:
    """Paare der gewichtigsten Treiber: bedingte 4-h-Quote bei gemeinsamem Ausschlag, gegen die Basisrate."""
    if not faelle:
        return []
    w = gewichte or {}
    namen = sorted(F.PRIORS, key=lambda n: -abs(w.get(n, F.PRIORS[n])))[:MAX_PAARE]
    gueltig = [f for f in faelle if f["r4"] is not None and abs(f["r4"]) >= F.TOLERANZ]
    n_all = len(gueltig); up_all = sum(1 for f in gueltig if f["r4"] > 0)
    basis = {"up": up_all / n_all if n_all else None, "down": (n_all - up_all) / n_all if n_all else None}
    out = []
    for i in range(len(namen)):
        for j in range(i + 1, len(namen)):
            a, b = namen[i], namen[j]
            for richtung, vorz in (("up", 1), ("down", -1)):
                sel = [f for f in gueltig if vorz * f["sc"].get(a, 0.0) >= SCHWELLE and vorz * f["sc"].get(b, 0.0) >= SCHWELLE]
                if len(sel) < 5:
                    continue
                treffer = sum(1 for f in sel if (f["r4"] > 0) == (vorz > 0))
                n_eff = len({f["block"] for f in sel})
                q = treffer / len(sel); ci = _wilson(q * n_eff, n_eff)
                bs = basis[richtung]
                out.append({"a": a, "b": b, "richtung": richtung, "n": len(sel), "n_eff": n_eff, "quote": round(q, 3),
                            "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None, "basis": round(bs, 3) if bs is not None else None,
                            "lift": round(q - bs, 3) if bs is not None else None,
                            "z": round(_z_zwei_anteile(treffer, len(sel), up_all if richtung == "up" else n_all - up_all, n_all) or 0.0, 2)})
    # Auswahl-Effekt ehrlich ausweisen: unter der Nullhypothese überschreiten ~2,3 % aller Prüfungen z >= 2
    n_tests = len(out); n_z2 = sum(1 for r in out if r["z"] >= 2)
    out.sort(key=lambda r: -(r["lift"] or 0) * math.sqrt(r["n_eff"]))
    top = out[:40]
    for r in top:
        r["n_tests"] = n_tests; r["n_z2"] = n_z2; r["erwartet_z2"] = round(0.023 * n_tests, 1)
    return top


def vorbedingungen(faelle: list) -> dict:
    """Treiberprofile vor Bewegungen >= BEWEGUNG binnen HORIZONT_V: Anteil 'zeigte in die spätere Richtung' gegen Basis."""
    if not faelle:
        return {"up": [], "down": [], "n_up": 0, "n_down": 0, "n_all": 0}
    gueltig = [f for f in faelle if f["up"] is not None and f["down"] is not None]
    n_all = len(gueltig)
    out = {"n_all": n_all, "bewegung": BEWEGUNG, "horizont_h": HORIZONT_V // 3600, "schwelle": SCHWELLE}
    for richtung, key, vorz in (("up", "up", 1), ("down", "down", -1)):
        # Ereignisse: Blöcke mit Bewegung, zusammengefasst -- aufeinanderfolgende Blöcke (Abstand <= HORIZONT_V), deren
        # Fenster dieselbe Bewegung enthalten, zählen als EIN Ereignis (der erste Block = Vorbedingung)
        ev_bl = [f for f in gueltig if (f[key] >= BEWEGUNG if vorz > 0 else f[key] <= -BEWEGUNG)]
        ereignisse = []; letzte = None
        for f in ev_bl:
            if letzte is None or f["ts"] - letzte > HORIZONT_V:
                ereignisse.append(f)
            letzte = f["ts"]
        n_ev = len(ereignisse)
        profil = []
        for name in F.PRIORS:
            in_ev = sum(1 for f in ereignisse if vorz * f["sc"].get(name, 0.0) >= SCHWELLE)
            in_all = sum(1 for f in gueltig if vorz * f["sc"].get(name, 0.0) >= SCHWELLE)
            vorhanden_ev = sum(1 for f in ereignisse if name in f["sc"])
            if n_ev < 3 or vorhanden_ev < 3 or in_all == 0:
                continue
            q_ev = in_ev / n_ev; q_all = in_all / n_all
            profil.append({"treiber": name, "anteil_vor": round(q_ev, 3), "basis": round(q_all, 3), "lift": round(q_ev - q_all, 3),
                           "z": round(_z_zwei_anteile(in_ev, n_ev, in_all, n_all) or 0.0, 2), "n_ev": n_ev,
                           "mittel_vor": round(sum(vorz * f["sc"].get(name, 0.0) for f in ereignisse) / n_ev, 3)})
        profil.sort(key=lambda r: -r["lift"])
        out[richtung] = profil[:12]; out[f"n_{richtung}"] = n_ev
        out[f"beispiele_{richtung}"] = [{"ts": f["ts"], "bewegung": round(f[key] * 100, 2)} for f in ereignisse[-5:]]
    return out


def berechnen(con_main, coin: str, path: str = F.STORE, now: int | None = None, speichern: bool = True) -> dict:
    D = lade(con_main, coin, path, now)
    gew = None
    try:
        import hl_kalib
        m = hl_kalib.laden(coin, 4, path)
        gew = (m or {}).get("weights")
    except Exception:
        gew = None
    aus = {"coin": coin, "ts": D["now"], "n_bloecke": len(D["faelle"]), "konstellationen": konstellationen(D["faelle"], gew),
           "vorbedingungen": vorbedingungen(D["faelle"])}
    if speichern:
        st = F.store_connect(path)
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, "konstellation", json.dumps(aus), D["now"]))
        # Tägliche Historie (23.09.): Ein Paar qualifiziert sich für Stufe 2 nur, wenn sein Lift über Wochen hält --
        # dafür braucht es die Zeitreihe der Ergebnisse, nicht nur den letzten Stand. Je Coin und Tag ein Eintrag.
        st.execute("""CREATE TABLE IF NOT EXISTS konstellation_hist (coin TEXT, tag INTEGER, ts INTEGER, n_bloecke INTEGER,
                      paare TEXT, vorbedingungen TEXT, PRIMARY KEY (coin, tag))""")
        tag = D["now"] // 86_400 * 86_400
        kompakt = [{k: r.get(k) for k in ("a", "b", "richtung", "n", "n_eff", "quote", "basis", "lift", "z")} for r in aus["konstellationen"]]
        vb = {k: aus["vorbedingungen"].get(k) for k in ("up", "down", "n_up", "n_down", "n_all")}
        st.execute("INSERT OR REPLACE INTO konstellation_hist VALUES (?,?,?,?,?,?)", (coin, tag, D["now"], aus["n_bloecke"], json.dumps(kompakt), json.dumps(vb)))
        st.commit(); st.close()
    return aus


def stabil(coin: str, path: str = F.STORE, min_tage: int = 14, min_z: float = 2.0) -> list:
    """Paare, die an mindestens min_tage Tagen z >= min_z hielten -- die Kandidaten für Interaktionsterme (Stufe 2)."""
    try:
        st = F.store_connect(path)
        rows = st.execute("SELECT tag, paare FROM konstellation_hist WHERE coin=? ORDER BY tag", (coin,)).fetchall(); st.close()
    except sqlite3.Error:
        return []
    tage: dict = {}
    for tag, paare in rows:
        try:
            for r in json.loads(paare):
                if (r.get("z") or 0) >= min_z and (r.get("lift") or 0) > 0:
                    tage.setdefault((r["a"], r["b"], r["richtung"]), set()).add(tag)
        except (ValueError, TypeError):
            continue
    return sorted([{"a": a, "b": b, "richtung": r, "tage": len(t), "tage_gesamt": len(rows)} for (a, b, r), t in tage.items() if len(t) >= min_tage],
                  key=lambda x: -x["tage"])


def laden(coin: str, path: str = F.STORE) -> dict | None:
    try:
        st = F.store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin=? AND key='konstellation'", (coin,)).fetchone(); st.close()
        return json.loads(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError, TypeError):
        return None


def nulltest(verbose: bool = True, seed: int = 5) -> bool:
    """Rauschen: Paare und Vorbedingungen ohne Lift (Mittel der Lifts nahe null, kein |z| >= 3 häufiger als erwartet)."""
    import random as _rnd
    rng = _rnd.Random(seed); con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    now = int(time.time()) // 900 * 900; start = now - 60 * 86_400; px = 100.0; rows = []
    t = start - 3600
    while t <= now:
        px *= math.exp(rng.gauss(0, 0.0008)); rows.append((t, "BTC", px, px * (1 + abs(rng.gauss(0, 0.0004))), px * (1 - abs(rng.gauss(0, 0.0004))), px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); close = {r[0]: r[5] for r in rows}
    import tempfile, os
    tmp = tempfile.mkdtemp(); path = os.path.join(tmp, "f.db"); st = F.store_connect(path)
    namen = list(F.PRIORS)[:12]
    for ts in range(start, now - BLOCK4, 900):
        p0 = close.get(ts)
        if not p0:
            continue
        st.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)",
                   (ts, "BTC", p0, 0, p0, p0, json.dumps({"drivers": [{"name": n, "score": rng.uniform(-0.8, 0.8)} for n in namen]})))
    st.commit(); st.close()
    r = berechnen(con, "BTC", path=path, now=now, speichern=False)
    k = r["konstellationen"]; v = r["vorbedingungen"]
    lifts = [x["lift"] for x in k if x["lift"] is not None]
    zs = [abs(x["z"]) for x in k] + [abs(x["z"]) for x in v.get("up", [])] + [abs(x["z"]) for x in v.get("down", [])]
    mittel = sum(lifts) / len(lifts) if lifts else 0.0
    anteil_z3 = sum(1 for z in zs if z >= 3) / len(zs) if zs else 0.0
    ok = abs(mittel) < 0.06 and anteil_z3 <= 0.05
    if verbose:
        print(f"  Nulltest Konstellation: {len(k)} Paare, mittlerer Lift {mittel * 100:+.1f} pp (Soll |x| < 6) · Anteil |z| >= 3: {anteil_z3 * 100:.1f} % (Soll <= 5) · "
              f"Vorbedingungen: {v.get('n_up', 0)} Anstiege, {v.get('n_down', 0)} Rückgänge -> {'ok' if ok else 'FEHL'}")
        print("  Ergebnis:", "bestanden" if ok else "NICHT bestanden")
    try:
        for f in os.listdir(tmp):
            os.remove(os.path.join(tmp, f))
        os.rmdir(tmp)
    except OSError:
        pass
    return ok


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    print(__doc__)
