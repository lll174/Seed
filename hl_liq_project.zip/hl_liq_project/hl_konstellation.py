#!/usr/bin/env python3
"""
hl_konstellation.py -- zwei Rückschau-Statistiken auf den gespeicherten Prognosen (23.09.2026):

1. KONSTELLATIONEN: Für die Treiberpaare mit dem höchsten v2-Gewicht (sonst Prior): Wenn beide Treiber
   im selben Block in dieselbe Richtung ausschlagen (|Score| >= SCHWELLE), wie oft folgte der Kurs binnen
   4 h dieser Richtung? Bedingte Quote mit Wilson-Intervall auf n_eff (getrennte 4-h-Blöcke) gegen die
   Basisrate derselben Richtung über alle Blöcke -> Lift.
2. VORBEDINGUNGEN: Welche Treiber standen wie, BEVOR der Kurs binnen HORIZONT_V um mindestens BEWEGUNG
   stieg bzw. fiel? Je Treiber: Anteil der Ereignisse, in denen er an der Vorbedingung in die Richtung der
   späteren Bewegung zeigte (Score >= SCHWELLE), gegen den Anteil über alle Blöcke (Basis = Placebo). Lift
   mit z-Wert (Zwei-Anteile-Test).
   EREIGNISSE (U131, 05.10.2026): Bezugspunkt ist jede gespeicherte Prognose (die erste je 15-min-Fenster),
   nicht mehr nur die erste je 4-h-Block -- vom Blockbeginn aus erschienen Rückgänge, deren Hoch mitten im
   Block lag, kleiner, als sie waren (BTC 02.10.: Hoch -> Tief -3,9 %, vom Blockbeginn aus -2,9 %). Ein Punkt
   ist Kandidat, wenn der Kurs binnen HORIZONT_V mindestens BEWEGUNG von seinem Kurs aus lief. Er gehört zum
   laufenden Ereignis, solange dessen Bewegung noch läuft (der Kurs war noch nicht bis auf NAEHE_V an ihrem
   Extrem) oder er auf dasselbe Ziel zuläuft (schon das bisherige Extrem liegt BEWEGUNG jenseits seines Kurses),
   und sich der Kurs seit dem Eintreten der Bewegung nicht um BEWEGUNG zurückbewegt hat; sonst beginnt ein neues
   Ereignis. Der früheste Punkt ist die Vorbedingung. Vorher wurden Ereignisblöcke verkettet (Abstand
   <= 24 h zum VORIGEN Ereignisblock): zwei getrennte Rückgänge mit Erholung oder Pause dazwischen zählten als
   einer. Probe: _vorbed_probe (15 Szenarien mit bekannter Zahl von Bewegungen, Abgleich mit den Kursdaten, Positivkontrolle des Profils).
   Debug-Eintrag "Vorbedingungen: Ereignisliste" (--vorbedingungen): erfasste Ereignisse je Coin, Abgleich mit
   den Kursdaten (was der Chart zeigt, was nicht erfasst wurde und warum) und die bisherige Zählung.

Beides ist Anzeige, kein Treiber und kein Modellbestandteil -- die Interaktionsterme für v2 (Plan U25,
Stufe 2) folgen erst, wenn hier ein Paar über Wochen einen belegten Lift zeigt.
"""
import json
import math
import sqlite3
import sys
import time

import hl_forecast as F

TAGE = 90
SCHWELLE = 0.3          # |Score| ab dem ein Treiber "ausschlägt"
BEWEGUNG = 0.03         # 3 %
HORIZONT_V = 24 * 3600  # Vorbedingungen: Bewegung binnen 24 h
BLOCK4 = 4 * 3600
MAX_PAARE = 15
RASTER_V = 900          # U131: Bezugspunkte der Vorbedingungen -- die erste gespeicherte Prognose je 15-min-Fenster


def _wilson(hits, n, z=1.96):
    if n <= 0:
        return None
    p = hits / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def _z_zwei_anteile(h1, n1, h2, n2):
    if n1 <= 0 or n2 <= 0:
        return None
    p1, p2 = h1 / n1, h2 / n2; p = (h1 + h2) / (n1 + n2)
    se = math.sqrt(max(p * (1 - p), 1e-6) * (1 / n1 + 1 / n2))
    return (p1 - p2) / se if se > 0 else None


def lade(con_main, coin: str, path: str, now: int | None = None) -> dict:
    """Ein Fall je 4-h-Block (die früheste Prognose): Scores, p0, Kurs nach 4 h, max. Anstieg/Rückgang binnen HORIZONT_V."""
    now = now or int(time.time())
    st = F.store_connect(path)
    rows = st.execute("SELECT ts, price, payload FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                      (coin, now - TAGE * 86_400, now - BLOCK4)).fetchall()
    st.close()
    bars = con_main.execute("SELECT ts, close, high, low FROM bars WHERE coin=? AND ts>=? ORDER BY ts", (coin, now - (TAGE + 2) * 86_400)).fetchall()
    b_ts = [b[0] for b in bars]
    import bisect
    def close_at(t):
        i = bisect.bisect_right(b_ts, t) - 1
        return bars[i][1] if i >= 0 and t - b_ts[i] <= 120 else None
    def extrema(t, h):
        i = bisect.bisect_right(b_ts, t); j = bisect.bisect_right(b_ts, t + h)
        if j - i < 5 or t + h > b_ts[-1]:
            return None, None
        seg = bars[i:j]
        return max((s[2] or s[1]) for s in seg), min((s[3] or s[1]) for s in seg)
    cb_ab = F.cb_seite_ab(con_main)                                 # U41: Spot-Taker-Flow davor vertauscht
    seen = set(); faelle = []
    for ts, p0, payload in rows:
        b = ts // BLOCK4
        if b in seen or not p0:
            continue
        seen.add(b)
        try:
            pl = json.loads(payload)
        except (TypeError, ValueError):
            continue
        sc = {d["name"]: float(d["score"]) for d in pl.get("drivers", []) if d.get("score") is not None}
        if cb_ab and ts < cb_ab:
            sc.pop(F.CB_TREIBER, None)                                  # U41
        c4 = close_at(ts + BLOCK4)
        hi, lo = extrema(ts, HORIZONT_V)
        faelle.append({"ts": ts, "block": b, "p0": p0, "sc": sc, "r4": (c4 / p0 - 1.0) if c4 else None,
                       "up": (hi / p0 - 1.0) if hi else None, "down": (lo / p0 - 1.0) if lo else None})
    # U131: Bezugspunkte der Vorbedingungen -- jede gespeicherte Prognose (die erste je 15-min-Fenster). Die Treiberwerte
    # werden erst für die Vorbedingungen der Ereignisse gelesen (_scores), die Fälle oben bleiben unverändert.
    B = _bar_arrays(bars)
    punkte = []; seen15 = set()
    for ts, p0, payload in rows:
        w = ts // RASTER_V
        if w in seen15 or not p0:
            continue
        seen15.add(w)
        punkte.append(_punkt(B, ts, p0, payload, bool(cb_ab and ts < cb_ab)))
    return {"faelle": faelle, "punkte": punkte, "B": B, "now": now}


# ---------------------------------------------------------------------------
# U131 (05.10.2026): Ereignisse der Vorbedingungen
# ---------------------------------------------------------------------------
def _bar_arrays(bars: list):
    """1-min-Bars (ts, close, high, low) als numpy-Arrays; fehlendes Hoch/Tief -> Schluss (dieselbe Regel wie extrema)."""
    import numpy as np
    nan = float("nan")
    return (np.array([b[0] for b in bars], dtype=np.int64),
            np.array([(b[2] or b[1]) or nan for b in bars], dtype=float),
            np.array([(b[3] or b[1]) or nan for b in bars], dtype=float))


def _punkt_extrema(B, t: int, h: int = HORIZONT_V):
    """Höchstes Hoch und tiefstes Tief in (t, t + h] mit Zeitpunkt (erstes Auftreten). None bei unvollständigem Fenster:
    weniger als 5 Bars oder Fensterende hinter dem letzten Bar -- dieselbe Regel wie extrema() in lade()."""
    import numpy as np
    ts, hi, lo = B
    if not len(ts):
        return None
    i = int(np.searchsorted(ts, t, side="right")); j = int(np.searchsorted(ts, t + h, side="right"))
    if j - i < 5 or t + h > ts[-1]:
        return None
    sh, sl = hi[i:j], lo[i:j]
    if np.all(np.isnan(sh)) or np.all(np.isnan(sl)):
        return None
    kh, kl = int(np.nanargmax(sh)), int(np.nanargmin(sl))
    return float(sh[kh]), int(ts[i + kh]), float(sl[kl]), int(ts[i + kl])


def _punkt(B, ts: int, p0: float, payload, cb_alt: bool = False) -> dict:
    e = _punkt_extrema(B, ts)
    d = {"ts": int(ts), "p0": float(p0), "pl": payload, "cb_alt": cb_alt,
         "ext_up": None, "ext_ts_up": None, "ext_down": None, "ext_ts_down": None}
    if e:
        d.update(ext_up=e[0], ext_ts_up=e[1], ext_down=e[2], ext_ts_down=e[3])
    return d


def _scores(p: dict) -> dict:
    """Treiberwerte eines Bezugspunkts aus seiner gespeicherten Prognose (einmal gelesen, dann gemerkt); U41 wie in lade()."""
    if "sc" not in p:
        sc = {}
        try:
            pl = json.loads(p.get("pl") or "{}")
            sc = {d["name"]: float(d["score"]) for d in pl.get("drivers", []) if d.get("score") is not None}
        except (TypeError, ValueError, KeyError):
            sc = {}
        if p.get("cb_alt"):
            sc.pop(F.CB_TREIBER, None)
        p["sc"] = sc
    return p["sc"]


def _kandidat(p: dict, richtung: str) -> bool:
    """Lief der Kurs binnen HORIZONT_V vom Kurs des Punkts aus mindestens BEWEGUNG in die Richtung?"""
    x = p.get("ext_" + richtung)
    if x is None:
        return False
    return x >= p["p0"] * (1 + BEWEGUNG) if richtung == "up" else x <= p["p0"] * (1 - BEWEGUNG)


def _erste_ueberschreitung(B, t: int, p0: float, richtung: str, h: int = HORIZONT_V):
    """Erster Bar in (t, t + h], an dem die Bewegung von p0 aus BEWEGUNG erreicht -- None, wenn nie."""
    import numpy as np
    ts, hi, lo = B
    i = int(np.searchsorted(ts, t, side="right")); j = int(np.searchsorted(ts, t + h, side="right"))
    with np.errstate(invalid="ignore"):
        m = lo[i:j] <= p0 * (1 - BEWEGUNG) if richtung == "down" else hi[i:j] >= p0 * (1 + BEWEGUNG)
    k = np.flatnonzero(m)
    return int(ts[i + k[0]]) if len(k) else None


def _gegenbewegung(B, von: int, bis: int, richtung: str) -> bool:
    """
    Lief der Kurs zwischen von und bis (beide eingeschlossen) nach seinem Extrem in Ereignisrichtung um mindestens
    BEWEGUNG zurück? down: auf ein Tief folgte ein Hoch >= Tief x (1 + BEWEGUNG); up: auf ein Hoch ein Tief <= Hoch x
    (1 - BEWEGUNG). Jeder Bar wird mit dem Extrem VOR ihm verglichen -- die Spanne eines einzelnen Bars zählt nicht.
    """
    import numpy as np
    ts, hi, lo = B
    i = int(np.searchsorted(ts, von, side="left")); j = int(np.searchsorted(ts, bis, side="right"))
    if j - i < 2:
        return False
    with np.errstate(invalid="ignore"):
        if richtung == "down":
            m = np.fmin.accumulate(lo[i:j])
            return bool(np.any(hi[i + 1:j] >= m[:-1] * (1 + BEWEGUNG)))
        m = np.fmax.accumulate(hi[i:j])
        return bool(np.any(lo[i + 1:j] <= m[:-1] * (1 - BEWEGUNG)))


NAEHE_V = BEWEGUNG / 2  # U131: ein Ereignis gilt als "angekommen", sobald der Kurs erstmals so nah an seinem Extrem lag


def _extrem_im(B, von: int, bis: int, richtung: str):
    """Tiefstes Tief (down) bzw. höchstes Hoch (up) in (von, bis] mit Zeitpunkt -- für die Anzeige eines Ereignisses."""
    import numpy as np
    ts, hi, lo = B
    i = int(np.searchsorted(ts, von, side="right")); j = int(np.searchsorted(ts, bis, side="right"))
    seg = lo[i:j] if richtung == "down" else hi[i:j]
    if j <= i or np.all(np.isnan(seg)):
        return None, None
    k = int(np.nanargmin(seg)) if richtung == "down" else int(np.nanargmax(seg))
    return float(seg[k]), int(ts[i + k])


def _angekommen(B, von: int, extrem: float, extrem_ts: int, richtung: str) -> int:
    """Erster Bar in (von, extrem_ts], an dem der Kurs bis auf NAEHE_V an das Extrem herankam (down: Tief <= Extrem x
    (1 + NAEHE_V), up: Hoch >= Extrem x (1 - NAEHE_V)) -- robust gegen den Zufall, WO in einer flachen Bodenzone das
    tiefste Tief liegt. Spätestens der Bar des Extrems selbst."""
    import numpy as np
    ts, hi, lo = B
    i = int(np.searchsorted(ts, von, side="right")); j = int(np.searchsorted(ts, extrem_ts, side="right"))
    with np.errstate(invalid="ignore"):
        m = lo[i:j] <= extrem * (1 + NAEHE_V) if richtung == "down" else hi[i:j] >= extrem * (1 - NAEHE_V)
    k = np.flatnonzero(m)
    return int(ts[i + k[0]]) if len(k) else int(extrem_ts)


def ereignisse(punkte: list, B, richtung: str) -> list:
    """
    U131: Ereignisse einer Richtung aus den zeitlich sortierten Bezugspunkten (je 15 min die erste gespeicherte Prognose).
    KANDIDAT: Der Kurs lief binnen HORIZONT_V mindestens BEWEGUNG vom Kurs des Punkts aus in die Richtung.
    EXTREM eines Ereignisses: das tiefste Tief bzw. höchste Hoch, das die Fenster seiner Punkte sehen; ANGEKOMMEN ist
    es, sobald der Kurs erstmals bis auf NAEHE_V (1,5 %) an dieses Extrem herankam.
    Ein Kandidat gehört zum laufenden Ereignis, wenn er VOR dem Ankommen liegt (die Bewegung läuft noch) oder auf dasselbe
    Ziel zuläuft (schon das bisherige Extrem liegt BEWEGUNG jenseits seines Kurses -- ein früher Docht lässt das Ereignis
    sonst zu früh „ankommen“), und sich der Kurs seit dem Eintreten der Bewegung (erster Bar jenseits der Schwelle der
    Vorbedingung) nicht um BEWEGUNG zurückbewegt hat. Sonst beginnt er ein neues Ereignis; dessen frühester Punkt ist die
    Vorbedingung.
    Folgen: ein Rückgang zählt einmal -- auch ein langer, solange er weiterläuft, und einer mit Lücken davor; ein zweiter
    Rückgang zählt neu, wenn er nach dem Ankommen des ersten beginnt (Treppe, Bodenbildung) oder nach einer Erholung um
    BEWEGUNG -- auch weniger als 24 h später. Die alte Regel verkettete alles, was weniger als 24 h auseinanderlag.
    Anzeige je Ereignis: Extrem in (Vorbedingung, Ende], Ende = Beginn des nächsten Ereignisses (ohne nächstes: letzter
    Punkt + HORIZONT_V; tritt die Bewegung der Vorbedingung erst nach dem nächsten Beginn ein: ihr eigenes Fenster);
    bewegung = vom Kurs der Vorbedingung, max = vom extremsten Kurs seiner Punkte (Hoch vor einem Rückgang, Tief vor
    einem Anstieg) bis zum Extrem.
    """
    vorz = 1 if richtung == "up" else -1
    aus, E = [], None
    for p in punkte:
        if not _kandidat(p, richtung):
            continue
        ext, ext_ts = p["ext_" + richtung], p["ext_ts_" + richtung]
        # dasselbe Ziel: schon das bisherige Extrem des Ereignisses liegt BEWEGUNG jenseits des Kurses dieses Punkts -- dann
        # läuft er auf dieselbe Bewegung zu, auch wenn ein Docht das Ereignis früh „ankommen“ ließ
        gleiches_ziel = E is not None and (E["extrem"] <= p["p0"] * (1 - BEWEGUNG) if vorz < 0 else E["extrem"] >= p["p0"] * (1 + BEWEGUNG))
        if E is not None and (p["ts"] < E["angekommen"] or gleiches_ziel) \
                and not (E["t1"] is not None and p["ts"] > E["t1"] and _gegenbewegung(B, E["t1"], p["ts"], richtung)):
            E["n_punkte"] += 1; E["letzter"] = p["ts"]
            if vorz * (ext - E["extrem"]) > 0:                      # tieferes Tief bzw. höheres Hoch: die Bewegung läuft weiter
                E["extrem"], E["extrem_ts"] = ext, ext_ts
                E["angekommen"] = _angekommen(B, E["ts"], ext, ext_ts, richtung)
            if vorz * (E["p0_best"] - p["p0"]) > 0:                 # höherer Bezugskurs vor einem Rückgang, tieferer vor einem Anstieg
                E["p0_best"] = p["p0"]
            continue
        E = {"ts": p["ts"], "p0": p["p0"], "p0_best": p["p0"], "extrem": ext, "extrem_ts": ext_ts, "letzter": p["ts"],
             "angekommen": _angekommen(B, p["ts"], ext, ext_ts, richtung),
             "t1": _erste_ueberschreitung(B, p["ts"], p["p0"], richtung), "n_punkte": 1, "punkt": p}
        aus.append(E)
    for k, E in enumerate(aus):
        # Anzeige: Extrem bis zum Beginn des nächsten Ereignisses -- dessen Extrem gehört nicht hierher. Nur wenn die eigene
        # Bewegung der Vorbedingung erst danach eintritt (t1 nach dem nächsten Beginn), reicht die Anzeige über das eigene Fenster.
        nxt = aus[k + 1]["ts"] if k + 1 < len(aus) else None
        if nxt is not None and E["t1"] is not None and E["t1"] <= nxt:
            ende = nxt
        else:
            ende = max(min(nxt if nxt is not None else E["letzter"] + HORIZONT_V, E["letzter"] + HORIZONT_V), E["ts"] + HORIZONT_V)
        x, x_ts = _extrem_im(B, E["ts"], ende, richtung)
        if x is None:
            x, x_ts = E["extrem"], E["extrem_ts"]
        E["anz_extrem"], E["anz_extrem_ts"] = x, x_ts
        E["bewegung"] = x / E["p0"] - 1.0
        E["max"] = x / E["p0_best"] - 1.0
    return aus


def _ereignisse_alt(faelle: list, richtung: str) -> list:
    """Zählung bis 23.52 -- nur zum Vergleich (Debug-Eintrag, Probe): Bezug = erste Prognose je 4-h-Block; ein Ereignisblock
    im Abstand <= HORIZONT_V zum VORIGEN Ereignisblock verlängerte das Ereignis (Verkettung)."""
    gueltig = [f for f in faelle if f["up"] is not None and f["down"] is not None]
    ev_bl = [f for f in gueltig if (f["up"] >= BEWEGUNG if richtung == "up" else f["down"] <= -BEWEGUNG)]
    aus, letzte = [], None
    for f in ev_bl:
        if letzte is None or f["ts"] - letzte > HORIZONT_V:
            aus.append(f)
        letzte = f["ts"]
    return aus


def konstellationen(faelle: list, gewichte: dict | None) -> list:
    """Paare der gewichtigsten Treiber: bedingte 4-h-Quote bei gemeinsamem Ausschlag, gegen die Basisrate."""
    if not faelle:
        return []
    w = gewichte or {}
    namen = sorted(F.PRIORS, key=lambda n: -abs(w.get(n, F.PRIORS[n])))[:MAX_PAARE]
    gueltig = [f for f in faelle if f["r4"] is not None and abs(f["r4"]) >= F.TOLERANZ]
    n_all = len(gueltig); up_all = sum(1 for f in gueltig if f["r4"] > 0)
    basis = {"up": up_all / n_all if n_all else None, "down": (n_all - up_all) / n_all if n_all else None}
    out = []
    for i in range(len(namen)):
        for j in range(i + 1, len(namen)):
            a, b = namen[i], namen[j]
            for richtung, vorz in (("up", 1), ("down", -1)):
                sel = [f for f in gueltig if vorz * f["sc"].get(a, 0.0) >= SCHWELLE and vorz * f["sc"].get(b, 0.0) >= SCHWELLE]
                if len(sel) < 5:
                    continue
                treffer = sum(1 for f in sel if (f["r4"] > 0) == (vorz > 0))
                n_eff = len({f["block"] for f in sel})
                q = treffer / len(sel); ci = _wilson(q * n_eff, n_eff)
                bs = basis[richtung]
                out.append({"a": a, "b": b, "richtung": richtung, "n": len(sel), "n_eff": n_eff, "quote": round(q, 3),
                            "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None, "basis": round(bs, 3) if bs is not None else None,
                            "lift": round(q - bs, 3) if bs is not None else None,
                            "z": round(_z_zwei_anteile(treffer, len(sel), up_all if richtung == "up" else n_all - up_all, n_all) or 0.0, 2)})
    # Auswahl-Effekt ehrlich ausweisen: unter der Nullhypothese überschreiten ~2,3 % aller Prüfungen z >= 2
    n_tests = len(out); n_z2 = sum(1 for r in out if r["z"] >= 2)
    out.sort(key=lambda r: -(r["lift"] or 0) * math.sqrt(r["n_eff"]))
    top = out[:40]
    for r in top:
        r["n_tests"] = n_tests; r["n_z2"] = n_z2; r["erwartet_z2"] = round(0.023 * n_tests, 1)
    return top


def vorbedingungen(faelle: list, punkte: list | None = None, B=None) -> dict:
    """
    Treiberprofile vor Bewegungen >= BEWEGUNG binnen HORIZONT_V: Anteil 'zeigte an der Vorbedingung in die spätere
    Richtung' gegen die Basis aller 4-h-Blöcke. Ereignisse aus den Bezugspunkten (U131, ereignisse()); ohne Bezugspunkte
    oder Kursdaten gibt es keine Ereignisse (die Basis bleibt).
    """
    leer = {"up": [], "down": [], "n_up": 0, "n_down": 0, "n_all": 0, "ereignisse_up": [], "ereignisse_down": [], "methode": "u131"}
    if not faelle:
        return leer
    gueltig = [f for f in faelle if f["up"] is not None and f["down"] is not None]
    n_all = len(gueltig)
    bewertbar = [p for p in (punkte or []) if p.get("ext_up") is not None]
    out = {"n_all": n_all, "bewegung": BEWEGUNG, "horizont_h": HORIZONT_V // 3600, "schwelle": SCHWELLE, "methode": "u131",
           "n_punkte": len(bewertbar), "von": bewertbar[0]["ts"] if bewertbar else None,
           "bis": bewertbar[-1]["ts"] if bewertbar else None}
    for richtung, vorz in (("up", 1), ("down", -1)):
        evs = ereignisse(bewertbar, B, richtung) if (B is not None and bewertbar) else []
        scs = [_scores(e["punkt"]) for e in evs]
        n_ev = len(evs)
        profil = []
        for name in F.PRIORS:
            in_ev = sum(1 for sc in scs if vorz * sc.get(name, 0.0) >= SCHWELLE)
            in_all = sum(1 for f in gueltig if vorz * f["sc"].get(name, 0.0) >= SCHWELLE)
            vorhanden_ev = sum(1 for sc in scs if name in sc)
            if n_ev < 3 or vorhanden_ev < 3 or in_all == 0:
                continue
            q_ev = in_ev / n_ev; q_all = in_all / n_all
            profil.append({"treiber": name, "anteil_vor": round(q_ev, 3), "basis": round(q_all, 3), "lift": round(q_ev - q_all, 3),
                           "z": round(_z_zwei_anteile(in_ev, n_ev, in_all, n_all) or 0.0, 2), "n_ev": n_ev,
                           "mittel_vor": round(sum(vorz * sc.get(name, 0.0) for sc in scs) / n_ev, 3)})
        profil.sort(key=lambda r: -r["lift"])
        out[richtung] = profil[:12]; out[f"n_{richtung}"] = n_ev
        out[f"ohne_treiber_{richtung}"] = sum(1 for sc in scs if not sc)      # Vorbedingung ohne lesbare Treiberwerte
        out[f"ereignisse_{richtung}"] = [{"ts": e["ts"], "bewegung": round(e["bewegung"] * 100, 2), "max": round(e["max"] * 100, 2),
                                          "extrem_ts": e["anz_extrem_ts"], "n_punkte": e["n_punkte"]} for e in evs]
        out[f"beispiele_{richtung}"] = [{"ts": e["ts"], "bewegung": round(e["bewegung"] * 100, 2)} for e in evs[-5:]]
    return out


def berechnen(con_main, coin: str, path: str = F.STORE, now: int | None = None, speichern: bool = True) -> dict:
    D = lade(con_main, coin, path, now)
    gew = None
    try:
        import hl_kalib
        m = hl_kalib.laden(coin, 4, path)
        gew = (m or {}).get("weights")
    except Exception:
        gew = None
    aus = {"coin": coin, "ts": D["now"], "n_bloecke": len(D["faelle"]), "konstellationen": konstellationen(D["faelle"], gew),
           "vorbedingungen": vorbedingungen(D["faelle"], D.get("punkte"), D.get("B"))}
    if speichern:
        st = F.store_connect(path)
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, "konstellation", json.dumps(aus), D["now"]))
        # Tägliche Historie (23.09.): Ein Paar qualifiziert sich für Stufe 2 nur, wenn sein Lift über Wochen hält --
        # dafür braucht es die Zeitreihe der Ergebnisse, nicht nur den letzten Stand. Je Coin und Tag ein Eintrag.
        st.execute("""CREATE TABLE IF NOT EXISTS konstellation_hist (coin TEXT, tag INTEGER, ts INTEGER, n_bloecke INTEGER,
                      paare TEXT, vorbedingungen TEXT, PRIMARY KEY (coin, tag))""")
        tag = D["now"] // 86_400 * 86_400
        kompakt = [{k: r.get(k) for k in ("a", "b", "richtung", "n", "n_eff", "quote", "basis", "lift", "z")} for r in aus["konstellationen"]]
        vb = {k: aus["vorbedingungen"].get(k) for k in ("up", "down", "n_up", "n_down", "n_all")}
        st.execute("INSERT OR REPLACE INTO konstellation_hist VALUES (?,?,?,?,?,?)", (coin, tag, D["now"], aus["n_bloecke"], json.dumps(kompakt), json.dumps(vb)))
        st.commit(); st.close()
    return aus


def stabil(coin: str, path: str = F.STORE, min_tage: int = 14, min_z: float = 2.0) -> list:
    """Paare, die an mindestens min_tage Tagen z >= min_z hielten -- die Kandidaten für Interaktionsterme (Stufe 2)."""
    try:
        st = F.store_connect(path)
        rows = st.execute("SELECT tag, paare FROM konstellation_hist WHERE coin=? ORDER BY tag", (coin,)).fetchall(); st.close()
    except sqlite3.Error:
        return []
    tage: dict = {}
    for tag, paare in rows:
        try:
            for r in json.loads(paare):
                if (r.get("z") or 0) >= min_z and (r.get("lift") or 0) > 0:
                    tage.setdefault((r["a"], r["b"], r["richtung"]), set()).add(tag)
        except (ValueError, TypeError):
            continue
    return sorted([{"a": a, "b": b, "richtung": r, "tage": len(t), "tage_gesamt": len(rows)} for (a, b, r), t in tage.items() if len(t) >= min_tage],
                  key=lambda x: -x["tage"])


def laden(coin: str, path: str = F.STORE) -> dict | None:
    try:
        st = F.store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin=? AND key='konstellation'", (coin,)).fetchone(); st.close()
        return json.loads(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# U131: Debug-Eintrag "Vorbedingungen: Ereignisliste" -- welche Bewegungen erfasst wurden, Abgleich mit den Kursdaten
# ---------------------------------------------------------------------------
def _punkte_kursdaten(B, von: int, bis: int, richtung: str) -> list:
    """Bezugspunkte allein aus den Kursdaten: je 15-min-Abschnitt das Hoch (vor Rückgängen) bzw. das Tief (vor Anstiegen)
    als Bezugskurs, Fenster ab dem letzten Bar des Abschnitts -- so liest man eine Bewegung im Chart."""
    import numpy as np
    ts, hi, lo = B
    aus = []
    g = von // RASTER_V * RASTER_V
    while g <= bis:
        i = int(np.searchsorted(ts, g, side="left")); j = int(np.searchsorted(ts, g + RASTER_V, side="left"))
        if j > i:
            seg = hi[i:j] if richtung == "down" else lo[i:j]
            if not np.all(np.isnan(seg)):
                aus.append(_punkt(B, int(ts[j - 1]), float(np.nanmax(seg) if richtung == "down" else np.nanmin(seg)), None))
        g += RASTER_V
    return aus


def _pc_rand(x: float) -> str:
    """Prozent mit Vorzeichen, eine Nachkommastelle; knapp unter der Schwelle (rundet auf 3,0, liegt aber darunter) auf zwei
    Stellen abgeschnitten -- „höchstens -3,0 %“ sähe aus wie erreicht."""
    a = abs(x) * 100
    s = f"{math.floor(a * 100 + 1e-9) / 100:.2f}" if a < BEWEGUNG * 100 <= round(a, 1) else f"{a:.1f}"
    return ("-" if x < 0 else "+") + s.replace(".", ",") + " %"


def _abgleich(ref: list, ev: list, punkte: list, richtung: str) -> list:
    """
    Je Bewegung aus den Kursdaten: erfasst (ein Ereignis der Vorbedingungen überlappt [Beginn, Extrem]) oder der Grund.
    23.56 (U135): Der Grund misst dieselbe Spanne wie die Regel -- alle Prognosepunkte vom 15-min-Abschnitt des Beginns bis zum
    Extrem, je mit ihrer EIGENEN 24-h-Bewegung (Kandidat-Regel). Bis 23.55 zählten nur die Punkte der 24 h vor dem Extrem mit
    ihrem Weg bis dorthin; bei langen Bewegungen untertrieb das, wie knapp die Prognosepunkte an der Schwelle lagen (BTC 11.09.:
    „höchstens -1,3 %“ bei -4,4 % über 58 h). Dazu der Docht: wie weit das 15-min-Hoch (Rückgang) bzw. -Tief (Anstieg), von
    dem aus die Kursdaten zählen, über bzw. unter dem extremsten Prognosekurs derselben Spanne lag.
    """
    vorz = 1 if richtung == "up" else -1
    aus = []
    for K in ref:
        k0, k1 = K["ts"], K["anz_extrem_ts"]
        if any(E["ts"] <= k1 and k0 <= E["anz_extrem_ts"] for E in ev):
            aus.append((K, None))
            continue
        span = [p for p in punkte if k0 - RASTER_V < p["ts"] < k1]
        bew = [p for p in span if p.get("ext_" + richtung) is not None]
        if not span:
            grund = f"keine Prognose zwischen Beginn und {'Hoch' if vorz > 0 else 'Tief'} gespeichert"
        elif not bew:
            grund = "24-h-Fenster der Prognosen unvollständig (Lücke in den Kursdaten)"
        elif any(_kandidat(p, richtung) for p in bew):
            grund = "im benachbarten Ereignis enthalten"
        else:
            best = max(vorz * (p["ext_" + richtung] / p["p0"] - 1.0) for p in bew)
            grund = f"vom Prognosekurs aus binnen 24 h höchstens {_pc_rand(vorz * best)}"
            p_ext = min(p["p0"] for p in span) if vorz > 0 else max(p["p0"] for p in span)
            docht = -vorz * (K["p0_best"] / p_ext - 1.0)
            if docht >= 0.001:
                grund += (f"; das 15-min-{'Tief' if vorz > 0 else 'Hoch'} lag {docht * 100:.1f} % ".replace(".", ",")
                          + ("unter dem tiefsten" if vorz > 0 else "über dem höchsten") + " Prognosekurs")
        aus.append((K, grund))
    return aus


def vorbedingungen_bericht(con_main, path: str = F.STORE, now: int | None = None, coins: list | None = None) -> dict:
    """Je Coin: erfasste Ereignisse, die bisherige Zählung (bis 23.52) und der Abgleich mit den Kursdaten."""
    now = now or int(time.time())
    if coins is None:
        st = F.store_connect(path)
        try:
            coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast WHERE ts >= ?", (now - TAGE * 86_400,))]
        finally:
            st.close()
    out = {"ts": now, "coins": {}}
    for c in sorted(coins):
        D = lade(con_main, c, path, now)
        bewertbar = [p for p in D["punkte"] if p.get("ext_up") is not None]
        info = {"n_punkte": len(D["punkte"]), "n_bewertbar": len(bewertbar), "n_bloecke": len(D["faelle"]),
                "n_basis": sum(1 for f in D["faelle"] if f["up"] is not None and f["down"] is not None),
                "von": bewertbar[0]["ts"] if bewertbar else None, "bis": bewertbar[-1]["ts"] if bewertbar else None, "richtungen": {}}
        for r in ("down", "up"):
            ev = ereignisse(bewertbar, D["B"], r) if bewertbar else []
            ref = ereignisse(_punkte_kursdaten(D["B"], bewertbar[0]["ts"], bewertbar[-1]["ts"], r), D["B"], r) if bewertbar else []
            info["richtungen"][r] = {"ev": ev, "alt": _ereignisse_alt(D["faelle"], r), "abgleich": _abgleich(ref, ev, D["punkte"], r)}
        out["coins"][c] = info
    return out


def vorbedingungen_text(b: dict) -> str:
    def t(x):
        return time.strftime("%d.%m. %H:%M", time.localtime(x)) if x else "—"

    def pc(x):
        return f"{x * 100:+.1f} %".replace(".", ",")
    z = [f"Vorbedingungen (U131): erfasste Rückgänge und Anstiege ≥ {BEWEGUNG * 100:.0f} % binnen {HORIZONT_V // 3600} h",
         "Bezug: jede gespeicherte Prognose (die erste je 15 min). Ein Ereignis = eine Bewegung: Punkte gehören zusammen, solange sie",
         f"läuft (der Kurs war noch nicht bis auf {f'{NAEHE_V * 100:.1f}'.replace('.', ',')} % an ihrem Extrem) oder sie auf dasselbe Tief bzw. Hoch zulaufen;",
         f"neu nach diesem Ankommen oder nach einer Gegenbewegung um {BEWEGUNG * 100:.0f} %. Vorbedingung = frühester Punkt.",
         "Abgleich: dieselbe Erkennung allein auf den Kursdaten (Hoch bzw. Tief jedes 15-min-Abschnitts als Bezug) -- das, was der Chart zeigt.",
         "Nicht erfasst, Grund: „binnen 24 h höchstens …“ = größte eigene 24-h-Bewegung eines Prognosepunkts zwischen Beginn und Extrem;",
         "„das 15-min-Hoch/-Tief lag … über/unter dem Prognosekurs“ = Docht, den nur die Kursdaten sehen.",
         "Bisher (bis 23.52): Bezug nur die erste Prognose je 4-h-Block, Ereignisblöcke bis 24 h auseinander verkettet.", ""]
    for c, info in b["coins"].items():
        z.append(f"{c} · Rückschau {t(info['von'])} – {t(info['bis'])} · {info['n_bewertbar']} Prognosepunkte bewertbar "
                 f"(von {info['n_punkte']}; die letzten 24 h sind noch offen) · Basis {info['n_basis']} Blöcke")
        for r, titel in (("down", "RÜCKGÄNGE"), ("up", "ANSTIEGE")):
            R = info["richtungen"][r]
            z.append(f"  {titel}: {len(R['ev'])} Ereignisse (bisherige Zählung: {len(R['alt'])})")
            if len(R["ev"]) > 15:                                     # 23.56 (U135): Hinweis VOR der Liste (aufsteigend)
                z.append(f"    ({len(R['ev']) - 15} frühere nicht gezeigt; es folgen die 15 jüngsten)")
            for E in R["ev"][-15:]:
                z.append(f"    {t(E['ts'])}  {pc(E['bewegung'])} vom Bezugskurs (größte Bewegung {pc(E['max'])})  "
                         f"{'Hoch' if r == 'up' else 'Tief'} {t(E['anz_extrem_ts'])} · {E['n_punkte']} Punkte")
            ab = R["abgleich"]; fehlt = [(K, g) for K, g in ab if g]
            z.append(f"  Abgleich mit den Kursdaten: {len(ab)} {'Anstiege' if r == 'up' else 'Rückgänge'}, davon {len(ab) - len(fehlt)} erfasst")
            if len(fehlt) > 10:
                z.append(f"    ({len(fehlt) - 10} frühere nicht erfasste nicht gezeigt; es folgen die 10 jüngsten)")
            for K, g in fehlt[-10:]:
                z.append(f"    nicht erfasst: {t(K['ts'])}  {pc(K['max'])} ({'Hoch' if r == 'up' else 'Tief'} {t(K['anz_extrem_ts'])}) — {g}")
        z.append("")
    if not b["coins"]:
        z.append("Keine gespeicherten Prognosen in der Rückschau.")
    return "\n".join(z)


# 23.13: fester, auf 4 h ausgerichteter Zeitpunkt und feste Szenarien -- das 4-h-Raster hing sonst an der Uhr; bei
# unverändertem Code fiel der Nulltest in 5 von 24 Viertelstunden durch (mittlerer Lift eines Szenarios > 6 pp).
PROBE_NOW = 1_790_006_400
PROBE_SEEDS = (5, 6, 7, 8, 9)


def _nulllauf(seed: int, now: int) -> tuple:
    """Ein Rausch-Szenario: Lifts der Paare, |z| aller Prüfungen, Vorbedingungen."""
    import random as _rnd
    rng = _rnd.Random(seed); con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    now = now // 900 * 900; start = now - 60 * 86_400; px = 100.0; rows = []
    t = start - 3600
    while t <= now:
        px *= math.exp(rng.gauss(0, 0.0008)); rows.append((t, "BTC", px, px * (1 + abs(rng.gauss(0, 0.0004))), px * (1 - abs(rng.gauss(0, 0.0004))), px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); close = {r[0]: r[5] for r in rows}
    import tempfile, os
    tmp = tempfile.mkdtemp(); path = os.path.join(tmp, "f.db"); st = F.store_connect(path)
    namen = list(F.PRIORS)[:12]
    for ts in range(start, now - BLOCK4, 900):
        p0 = close.get(ts)
        if not p0:
            continue
        st.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)",
                   (ts, "BTC", p0, 0, p0, p0, json.dumps({"drivers": [{"name": n, "score": rng.uniform(-0.8, 0.8)} for n in namen]})))
    st.commit(); st.close()
    r = berechnen(con, "BTC", path=path, now=now, speichern=False)
    k = r["konstellationen"]; v = r["vorbedingungen"]
    lifts = [x["lift"] for x in k if x["lift"] is not None]
    zs = [abs(x["z"]) for x in k] + [abs(x["z"]) for x in v.get("up", [])] + [abs(x["z"]) for x in v.get("down", [])]
    try:
        for f in os.listdir(tmp):
            os.remove(os.path.join(tmp, f))
        os.rmdir(tmp)
    except OSError:
        pass
    return lifts, zs, v


# ---------------------------------------------------------------------------
# U131 -- Probe der Ereigniserkennung (05.10.2026): Szenarien mit bekannter Zahl von Bewegungen
# ---------------------------------------------------------------------------
# Stützstellen (Stunde ab Beginn, Kursniveau; 1.0 = 100, dazwischen linear), Soll je Richtung: Liste (Schwelle erreicht,
# Bewegung zu Ende) in Stunden -- die Vorbedingung muss in den 24 h vor dem Erreichen der Schwelle liegen, das angezeigte
# Extrem nicht vor dem Ende der Bewegung. Beginn = PROBE_NOW - V_STUNDEN (auf 4 h ausgerichtet wie die Blöcke).
V_STUNDEN = 288
V_SZENARIEN = {
    # Hoch mitten im 4-h-Block: vom Blockbeginn aus -1,7 %, von den 15-min-Punkten am Hoch -3,25 % (BTC 02.10.: -2,9 % gegen -3,9 %)
    "BLOCKMITTE": ([(0, 1.0), (145, 1.0), (145.5, 1.016), (146.25, 1.016), (148.5, 0.983), (288, 0.983)],
                   [(148.33, 148.5)], []),
    "BLOCKMITTE_AUF": ([(0, 1.0), (145, 1.0), (145.5, 0.984), (146.25, 0.984), (148.5, 1.0165), (288, 1.0165)],
                       [], [(148.29, 148.5)]),
    # zwei Rückgänge 30 h auseinander, dazwischen volle Erholung -- die Verkettung machte daraus einen
    "ZWEI_MIT_ERHOLUNG": ([(0, 1.0), (100, 1.0), (101, 0.96), (107, 1.0), (130, 1.0), (131, 0.96), (137, 1.0), (288, 1.0)],
                          [(100.75, 101), (130.75, 131)], [(106.87, 107), (136.87, 137)]),
    # ein langer Rückgang (-8 % über 20 h) zählt einmal
    "LANG": ([(0, 1.0), (100, 1.0), (120, 0.92), (288, 0.92)], [(107.5, 120)], []),
    # Treppe: -4 %, 36 h Pause, -4 % -- zwei Rückgänge ohne Erholung dazwischen (verkettet: einer)
    "TREPPE": ([(0, 1.0), (100, 1.0), (101, 0.96), (137, 0.96), (138, 0.92), (288, 0.92)],
               [(100.75, 101), (137.72, 138)], []),
    # zwei Rückgänge binnen 19 h, der zweite tiefer, dazwischen Erholung um 4 % -- die Erholung trennt sie
    "ERHOLUNG_BINNEN_24H": ([(0, 1.0), (100, 1.0), (101, 0.96), (105, 1.0), (119, 1.0), (120, 0.94), (288, 0.94)],
                            [(100.75, 101), (119.66, 120)], [(104.9, 105)]),
    # Lücke vor dem Tief: 9 h Delle (-1 %), in der kein Punkt 3 % vor sich hat, dann derselbe Rückgang -- bleibt EINER
    "LUECKE_VOR_DEM_TIEF": ([(0, 1.0), (88, 1.0), (89, 0.99), (97, 0.99), (98, 1.0), (100, 1.0), (101, 0.965), (288, 0.965)],
                            [(100.86, 101)], []),
    # Docht am Fensterende: die Vorbedingung sieht -3,1 % erst am Ende ihres Fensters, der nächste Rückgang beginnt davor --
    # die Anzeige muss trotzdem die eigene Bewegung zeigen (mindestens das Fenster der Vorbedingung)
    "DOCHT_AM_FENSTERENDE": ([(0, 1.0), (80, 1.0), (82, 0.975), (103.4, 0.975), (103.5, 0.969), (104.5, 0.969), (104.6, 0.975),
                              (120, 0.975), (121, 0.94), (288, 0.94)], [(103.5, 103.5), (120.84, 121)], []),
    # Lücke in der Ablage (Dashboard 28 h aus): die Vorbedingung des ersten Rückgangs ist der erste Punkt danach, der zweite
    # Rückgang (tiefer) beginnt binnen 24 h nach ihr -- die Anzeige des ersten darf nicht das Tief des zweiten zeigen
    # (Demo-Lauf ZEC 25.09.: zweimal "Tief 18:57")
    "LUECKE_IN_DER_ABLAGE": ([(0, 1.0), (100, 1.0), (101, 0.96), (104, 1.0), (108, 1.0), (109, 0.93), (288, 0.93)],
                             [(100.75, 101), (108.58, 109)], [(103.16, 104)], [(70, 98)]),
    # BEKANNTE GRENZE: Kurs steigt in einen Rückgang hinein, binnen 7 h folgt nach einer Erholung ein tieferer -- die früheste
    # Vorbedingung erreicht 3 % erst mit dem zweiten Tief, beide zählen als EIN Rückgang (Zufallswege: 1 von 660 Bewegungen)
    "GRENZE_ZWEITER_TIEFER": ([(0, 0.95), (100, 0.95), (104, 1.0), (105, 1.0), (106, 0.96), (108, 1.0), (112, 1.0), (113, 0.94),
                               (288, 0.94)], [(112.9, 113)], [(102.28, 104), (107.96, 108)]),
    # Docht vorab: -2,5 % für 30 min, zurück, 15 h später -3,4 % -- EIN Rückgang (vorher: der Docht ließ das Ereignis
    # „ankommen“, die Punkte danach zählten ein zweites Mal auf dasselbe Tief; Zufallswege: 2 von 343)
    "DOCHT_VORAB": ([(0, 1.0), (90, 1.0), (90.5, 0.975), (91, 1.0), (105, 1.0), (106, 0.966), (288, 0.966)], [(105.88, 106)], []),
    # Abwärts mit Zwischenerholung um 2 % (unter der Schwelle): ein Rückgang
    "ZWISCHENERHOLUNG_2": ([(0, 1.0), (100, 1.0), (101, 0.96), (103, 0.98), (105, 0.93), (288, 0.93)], [(100.75, 105)], []),
    # Treppe mit nur 24 h Pause: die Punkte der Pause sehen schon den zweiten Rückgang (keine Lücke) -- trotzdem zwei
    "TREPPE_24H": ([(0, 1.0), (100, 1.0), (101, 0.96), (125, 0.96), (126, 0.92), (288, 0.92)],
                   [(100.75, 101), (125.72, 126)], []),
    # Bodenbildung: Rückgang, 26 h Seitwärts mit einem Docht 0,8 % unter das erste Tief, dann ein neuer Rückgang -- zwei
    "BODENBILDUNG": ([(0, 1.0), (100, 1.0), (101, 0.965), (105, 0.975), (110, 0.966), (114.5, 0.97), (115, 0.958), (115.5, 0.97),
                      (120, 0.968), (127, 0.972), (128, 0.935), (288, 0.935)],
                     [(100.86, 101), (127.84, 128)], []),
    "RUHIG": ([(0, 1.0), (288, 1.0)], [], []),
}
# bisherige Zählung (bis 23.52), die das Szenario belegt: (Rückgänge, Anstiege) -- None = nicht geprüft
V_ALT = {"BLOCKMITTE": (0, 0), "BLOCKMITTE_AUF": (0, 0), "ZWEI_MIT_ERHOLUNG": (1, None), "TREPPE": (1, None), "LUECKE_VOR_DEM_TIEF": (1, 0),
         "TREPPE_24H": (1, 0), "BODENBILDUNG": (1, 0), "DOCHT_AM_FENSTERENDE": (1, 0), "LUECKE_IN_DER_ABLAGE": (1, 0)}


def _v_daten(pfade: dict, now: int, stunden: int, seed: int, treiber=None, luecken: dict | None = None):
    """Temporäre Datenbanken: je Coin 1-min-Bars entlang der Stützstellen (kleines Rauschen) und alle 15 min eine Prognose
    mit dem Kurs dieses Bars; treiber(coin, stunde, rng) -> {name: score}; luecken = {coin: [(von_h, bis_h)]} ohne Prognosen
    (Dashboard aus, Kursdaten laufen weiter)."""
    import os as _os, tempfile as _tf
    import numpy as np
    rng = np.random.default_rng(seed)
    tmp = _tf.mkdtemp(); con = sqlite3.connect(_os.path.join(tmp, "m.db"))
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    pfad = _os.path.join(tmp, "f.db"); st = F.store_connect(pfad)
    start = now - stunden * 3600
    for coin, knoten in pfade.items():
        t = np.arange(start, now + 1, 60)
        px = 100.0 * np.interp((t - start) / 3600.0, [k[0] for k in knoten], [k[1] for k in knoten]) * (1 + rng.normal(0, 0.0002, len(t)))
        hi = px * (1 + np.abs(rng.normal(0, 0.0002, len(t)))); lo = px * (1 - np.abs(rng.normal(0, 0.0002, len(t))))
        con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)",
                        [(int(a), coin, float(c), float(b), float(d), float(c), 1.0, 1) for a, b, c, d in zip(t, hi, px, lo)])
        close = dict(zip(t.tolist(), px.tolist()))
        zeilen = []
        for ts in range(start, now - BLOCK4 + 1, RASTER_V):
            if any(a * 3600 <= ts - start < b * 3600 for a, b in (luecken or {}).get(coin, [])):
                continue
            sc = treiber(coin, (ts - start) / 3600.0, rng) if treiber else {}
            zeilen.append((ts, coin, close[ts], 0, close[ts], close[ts],
                           json.dumps({"drivers": [{"name": n, "score": v} for n, v in sc.items()]})))
        st.executemany("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)", zeilen)
    con.commit(); st.commit(); st.close()
    return tmp, con, pfad


def _v_aufraeumen(tmp: str, con) -> None:
    import os as _os
    try:
        con.close()
        for f_ in _os.listdir(tmp):
            _os.remove(_os.path.join(tmp, f_))
        _os.rmdir(tmp)
    except OSError:
        pass


def _vorbed_probe(seed: int = 21) -> dict:
    """
    U131: (1) Szenarien mit bekannter Zahl von Bewegungen -- Zahl, Lage der Vorbedingung, angezeigtes Extrem; die alte
    Zählung belegt den Fehler (BLOCKMITTE vorher 0, ZWEI_MIT_ERHOLUNG und TREPPE vorher 1). (2) Abgleich mit den Kursdaten:
    jede Bewegung erfasst. (3) Extrema je Punkt gegen eine Rechnung von Hand (Python-Schleife über die Bars).
    (4) Positivkontrolle des Profils: ein eingepflanzter Vorläufer vor jedem Rückgang (MA 200 Tage) und vor jedem Anstieg
    (RSI 14 (1 h)) steht oben mit z >= 3; die Rauschtreiber nicht über |z| 3.
    """
    import numpy as np
    now = PROBE_NOW; H = 3600
    start = now - V_STUNDEN * H
    tmp, con, pfad = _v_daten({k: v[0] for k, v in V_SZENARIEN.items()}, now, V_STUNDEN, seed,
                              luecken={k: v[3] for k, v in V_SZENARIEN.items() if len(v) > 3})
    ok = True; txt = []; fehler = []; zahl = {}
    try:
        for name, (knoten, soll_d, soll_u, *_l) in V_SZENARIEN.items():
            D = lade(con, name, pfad, now)
            v = vorbedingungen(D["faelle"], D["punkte"], D["B"])
            bew = [p for p in D["punkte"] if p.get("ext_up") is not None]
            for r, soll in (("down", soll_d), ("up", soll_u)):
                ev = ereignisse(bew, D["B"], r)
                ok_r = len(ev) == len(soll) == v[f"n_{r}"]
                for k_, (E, (t_s, t_e)) in enumerate(zip(ev, soll)):
                    t_s, t_e = start + t_s * H, start + t_e * H
                    ok_r = ok_r and t_s - 24.5 * H <= E["ts"] < t_s and t_e - 0.5 * H <= E["anz_extrem_ts"] <= t_e + 24 * H \
                        and abs(E["bewegung"]) >= BEWEGUNG
                    # das angezeigte Extrem gehört zu diesem Ereignis: vor dem Beginn des nächsten, es sei denn, die eigene
                    # Bewegung der Vorbedingung tritt erst danach ein
                    if k_ + 1 < len(ev) and E["t1"] is not None and E["t1"] <= ev[k_ + 1]["ts"]:
                        ok_r = ok_r and E["anz_extrem_ts"] <= ev[k_ + 1]["ts"]
                ref = ereignisse(_punkte_kursdaten(D["B"], bew[0]["ts"], bew[-1]["ts"], r), D["B"], r)
                ab = _abgleich(ref, ev, D["punkte"], r)
                ok_r = ok_r and len(ref) == len(soll) and all(g is None for _, g in ab)
                alt_soll = V_ALT.get(name, (None, None))[0 if r == "down" else 1]
                n_alt = len(_ereignisse_alt(D["faelle"], r))
                ok_r = ok_r and (alt_soll is None or n_alt == alt_soll)
                zahl[(name, r)] = (len(ev), n_alt)
                if not ok_r:
                    fehler.append(f"{name}/{r}: {len(ev)} statt {len(soll)} (alt {n_alt}, Kursdaten {len(ref)}) "
                                  f"{[(round((E['ts'] - start) / H, 2), round((E['anz_extrem_ts'] - start) / H, 2)) for E in ev]}")
                ok = ok and ok_r
        # (3) Extrema von Hand: dieselbe Fensterregel wie extrema() in lade() -- (t, t + 24 h], Fallback Hoch/Tief -> Schluss
        bars = con.execute("SELECT ts, close, high, low FROM bars WHERE coin='LANG' ORDER BY ts").fetchall()
        D = lade(con, "LANG", pfad, now)
        stich = D["punkte"][::37]; ok_x = True
        for p in stich:
            seg = [b for b in bars if p["ts"] < b[0] <= p["ts"] + HORIZONT_V]
            if len(seg) < 5 or p["ts"] + HORIZONT_V > bars[-1][0]:
                ok_x = ok_x and p["ext_up"] is None
                continue
            h_ = max((b[2] or b[1]) for b in seg); l_ = min((b[3] or b[1]) for b in seg)
            th = next(b[0] for b in seg if (b[2] or b[1]) == h_); tl = next(b[0] for b in seg if (b[3] or b[1]) == l_)
            ok_x = ok_x and (p["ext_up"], p["ext_ts_up"], p["ext_down"], p["ext_ts_down"]) == (h_, th, l_, tl)
        ok = ok and ok_x
        if not ok_x:
            fehler.append("Extrema je Punkt weichen von der Rechnung von Hand ab")
    finally:
        _v_aufraeumen(tmp, con)
    # (4) Profil: Sägezahn (-4 % in 1 h, 11 h Tief, +4,2 % in 2 h, alle 36 h), 7 Rückgänge und 7 Anstiege. Vorbedingung eines
    # Rückgangs: 23 bis 22,5 h vor dem Tief (erster Punkt, dessen Fenster es enthält); eines Anstiegs: im Rückgang davor, wenn
    # der Kurs 3 % unter dem späteren Hoch liegt. Vorläufer je 6 h um diese Zeitpunkte, sonst Rauschen unter der Schwelle.
    zyklen = [30 + 36 * k for k in range(7)]
    knoten = [(0, 1.0)]
    for z_ in zyklen:
        knoten += [(z_, 1.0), (z_ + 1, 0.96), (z_ + 12, 0.96), (z_ + 14, 1.0)]
    knoten.append((V_STUNDEN, 1.0))
    rausch = ["MA 50 Wochen", "60-min-Trend", "7-Tage-Drift", "Funding", "Orderbuch", "Taker-Flow", "Wal-Flow 30 min", "Smart Money (direktional)"]
    rausch = [n for n in rausch if n in F.PRIORS][:6]

    def treiber(coin, h, rng):
        sc = {n: float(rng.uniform(-0.8, 0.8)) for n in rausch}
        sc["MA 200 Tage"] = -0.8 if any(z_ - 23.25 <= h < z_ - 17.25 for z_ in zyklen) else float(rng.uniform(-0.25, 0.25))
        sc["RSI 14 (1 h)"] = 0.8 if any(z_ + 0.5 <= h < z_ + 6.5 for z_ in zyklen) else float(rng.uniform(-0.25, 0.25))
        return sc
    tmp, con, pfad = _v_daten({"PROFIL": knoten}, now, V_STUNDEN, seed + 1, treiber)
    try:
        D = lade(con, "PROFIL", pfad, now)
        v = vorbedingungen(D["faelle"], D["punkte"], D["B"])
    finally:
        _v_aufraeumen(tmp, con)
    ok_p = True; ptxt = []
    for r, vorl in (("down", "MA 200 Tage"), ("up", "RSI 14 (1 h)")):
        prof = v.get(r) or []
        top = prof[0] if prof else {}
        rest = [x for x in prof if x["treiber"] not in ("MA 200 Tage", "RSI 14 (1 h)")]
        ok_r = v.get(f"n_{r}") == 7 and top.get("treiber") == vorl and top.get("z", 0) >= 3 and all(abs(x["z"]) < 3 for x in rest)
        ok_p = ok_p and ok_r
        ptxt.append(f"{'Rückgänge' if r == 'down' else 'Anstiege'} {v.get(f'n_{r}')} (Soll 7), oben {top.get('treiber')} "
                    f"Lift {top.get('lift', 0) * 100:+.0f} pp z {top.get('z', 0):.1f}, Rauschen max |z| "
                    f"{max([abs(x['z']) for x in rest], default=0):.1f}")
    ok = ok and ok_p
    if not ok_p:
        fehler.append("Profil: " + " · ".join(ptxt))
    alt_txt = ", ".join(f"{k} {zahl[(k, 'down')][0]}/{zahl[(k, 'up')][0]} (bisher {zahl[(k, 'down')][1]}/{zahl[(k, 'up')][1]})"
                        for k in V_ALT if (k, "down") in zahl and (k, "up") in zahl)
    txt.append(f"{len(V_SZENARIEN)} Szenarien: Zahl, Vorbedingung in den 24 h vor der Schwelle, Extrem, Abgleich mit den Kursdaten -- "
               f"Rückgänge/Anstiege {alt_txt}")
    txt.append("Extrema je Punkt = Rechnung von Hand")
    txt.append("Profil: " + " · ".join(ptxt))
    return {"ok": ok, "text": " · ".join(txt) + (" · FEHL: " + "; ".join(fehler) if fehler else "")}


def _abgleich_probe(seed: int = 31) -> dict:
    """
    23.56 (U135): Begründung des Abgleichs „nicht erfasst“. Kurs fällt in 24 h um 2,7 %, danach in 34 h um weitere 1 %; ein
    1-min-Docht +0,6 % über dem Schluss am Beginn. Die Kursdaten zählen vom Docht aus (-3,3 % binnen 24 h), die Prognosepunkte
    (Schluss alle 15 min) sehen höchstens -2,7 % -> nicht erfasst.
    (a) Bewegung über 58 h (wie BTC 11.09.): Soll „binnen 24 h höchstens -2,7 %“ und Docht 0,6 % -- die Regel bis 23.55 (nur
        die 24 h vor dem Extrem, Weg bis dorthin) meldete hier „-0,7 %“.
    (b) gespiegelt (Anstieg, Docht nach unten); (c) Schwellenrand -2,96 % erscheint nicht als „-3,0 %“; (d) ein Kandidat in der
    Spanne -> „im benachbarten Ereignis enthalten“; (e) keine Prognose in der Spanne; (f) Fenster unvollständig;
    (g) ganze Kette (Datenbank, lade, Ereignisse, Abgleich) mit Rauschen: dieselbe Begründung.
    """
    import numpy as np
    H = 3600; t0 = PROBE_NOW - 140 * H
    ts = np.arange(t0, t0 + 140 * H + 1, 60, dtype=np.int64)
    hh = (ts - t0) / H

    def B_(knoten, docht_h=None, docht=0.0):
        c = 100.0 * np.interp(hh, [k[0] for k in knoten], [k[1] for k in knoten])
        hi, lo = c.copy(), c.copy()
        if docht_h is not None:
            i = int(np.searchsorted(ts, t0 + int(round(docht_h * H))))
            if docht > 0:
                hi[i] = c[i] * (1 + docht)
            else:
                lo[i] = c[i] * (1 + docht)
        return (ts, hi, lo), c

    def punkte_(B, c):
        return [_punkt(B, int(t), float(c[int((t - t0) // 60)]), None) for t in range(t0, t0 + 140 * H - 3600 + 1, RASTER_V)]

    def K_(B, c, h_beginn, h_extrem, p0_best):
        k0 = t0 + int(h_beginn * H) + RASTER_V - 60
        k1 = t0 + int(h_extrem * H)
        return {"ts": k0, "anz_extrem_ts": k1, "anz_extrem": float(c[int((k1 - t0) // 60)]), "p0_best": p0_best,
                "max": float(c[int((k1 - t0) // 60)]) / p0_best - 1.0}

    ab_knoten = [(0, 1.0), (20, 1.0), (44, 0.973), (78, 0.96327), (140, 0.96327)]
    fehler, ergebnis = [], {}
    # (a) Rückgang über 58 h
    B, c = B_(ab_knoten, 20 + 7 / 60, 0.006)
    P = punkte_(B, c)
    ev = ereignisse([p for p in P if p.get("ext_down") is not None], B, "down")
    g_a = _abgleich([K_(B, c, 20, 78, 100.6)], ev, P, "down")[0][1] or ""
    ergebnis["a"] = g_a
    if ev or "binnen 24 h höchstens -2,7 %" not in g_a or "das 15-min-Hoch lag 0,6 % über dem höchsten Prognosekurs" not in g_a:
        fehler.append(f"(a) {len(ev)} Ereignisse, Grund „{g_a}“")
    # (b) gespiegelt: Anstieg
    auf_knoten = [(0, 1.0), (20, 1.0), (44, 1.027), (78, 1.03673), (140, 1.03673)]
    B, c = B_(auf_knoten, 20 + 7 / 60, -0.006)
    P = punkte_(B, c)
    ev = ereignisse([p for p in P if p.get("ext_up") is not None], B, "up")
    g_b = _abgleich([K_(B, c, 20, 78, 99.4)], ev, P, "up")[0][1] or ""
    ergebnis["b"] = g_b
    if ev or "binnen 24 h höchstens +2,7 %" not in g_b or "das 15-min-Tief lag 0,6 % unter dem tiefsten Prognosekurs" not in g_b:
        fehler.append(f"(b) {len(ev)} Ereignisse, Grund „{g_b}“")
    # (c) Schwellenrand: -2,96 % binnen 24 h
    B, c = B_([(0, 1.0), (20, 1.0), (44, 0.9704), (140, 0.9704)], 20 + 7 / 60, 0.003)
    P = punkte_(B, c)
    g_c = _abgleich([K_(B, c, 20, 44, 100.3)], [], P, "down")[0][1] or ""
    ergebnis["c"] = g_c
    if "höchstens -2,96 %" not in g_c:
        fehler.append(f"(c) Grund „{g_c}“")
    # (d) Kandidat in der Spanne (-3,5 %), dessen Ereignis die Bewegung nicht überlappt (hier: keins übergeben)
    B, c = B_([(0, 1.0), (20, 1.0), (44, 0.965), (140, 0.965)], 20 + 7 / 60, 0.003)
    P = punkte_(B, c)
    g_d = _abgleich([K_(B, c, 20, 44, 100.3)], [], P, "down")[0][1] or ""
    ergebnis["d"] = g_d
    if g_d != "im benachbarten Ereignis enthalten":
        fehler.append(f"(d) Grund „{g_d}“")
    # (e) keine Prognose in der Spanne; (f) nur Punkte mit offenem 24-h-Fenster (die letzten 24 h)
    B, c = B_(ab_knoten, 20 + 7 / 60, 0.006)
    P = punkte_(B, c)
    g_e = _abgleich([K_(B, c, 20, 78, 100.6)], [], [p for p in P if not (t0 + 19 * H < p["ts"] < t0 + 79 * H)], "down")[0][1] or ""
    g_f = _abgleich([K_(B, c, 125, 138, 97.0)], [], P, "down")[0][1] or ""
    ergebnis["e"], ergebnis["f"] = g_e, g_f
    if g_e != "keine Prognose zwischen Beginn und Tief gespeichert":
        fehler.append(f"(e) Grund „{g_e}“")
    if g_f != "24-h-Fenster der Prognosen unvollständig (Lücke in den Kursdaten)":
        fehler.append(f"(f) Grund „{g_f}“")
    # (g) ganze Kette über die Datenbank (Rauschen 0,02 % je Bar): ein Rückgang der Kursdaten, nicht erfasst, Grund mit Zahlen
    now = PROBE_NOW
    d = 0.027 / 24
    knoten = [(0, 1.0), (100, 1.0), (100 + 6 / 60, 1.0 - d * 6 / 60), (100 + 7 / 60, 1.006), (100 + 8 / 60, 1.0 - d * 8 / 60),
              (124, 0.973), (158, 0.96327), (V_STUNDEN, 0.96327)]
    tmp, con, pfad = _v_daten({"DOCHT_START": knoten}, now, V_STUNDEN, seed)
    try:
        D = lade(con, "DOCHT_START", pfad, now)
        bew = [p for p in D["punkte"] if p.get("ext_up") is not None]
        ev = ereignisse(bew, D["B"], "down")
        ref = ereignisse(_punkte_kursdaten(D["B"], bew[0]["ts"], bew[-1]["ts"], "down"), D["B"], "down")
        ab = _abgleich(ref, ev, D["punkte"], "down")
    finally:
        _v_aufraeumen(tmp, con)
    import re
    g_g = ab[0][1] if len(ab) == 1 else None
    m = re.search(r"binnen 24 h höchstens -(\d+),(\d+) %; das 15-min-Hoch lag (\d+),(\d) % über", g_g or "")
    ergebnis["g"] = g_g
    if not (len(ev) == 0 and m and abs(float(f"{m.group(1)}.{m.group(2)}") - 2.7) <= 0.15 and abs(float(f"{m.group(3)}.{m.group(4)}") - 0.6) <= 0.1):
        fehler.append(f"(g) {len(ev)} Ereignisse, {len(ref)} Kursdaten-Bewegungen, Grund „{g_g}“")
    # (h) Bericht: Hinweis auf ausgelassene frühere Ereignisse bzw. nicht erfasste Bewegungen VOR der Liste (sie ist aufsteigend)
    evs = [{"ts": t0 + i * H, "bewegung": -0.031, "max": -0.035, "anz_extrem_ts": t0 + i * H + 1800, "n_punkte": 2} for i in range(17)]
    fe_ = [({"ts": t0 + i * H, "max": -0.031, "anz_extrem_ts": t0 + i * H + 900}, "Grund") for i in range(12)]
    b_ = {"coins": {"AAA": {"von": t0, "bis": t0 + 20 * H, "n_bewertbar": 10, "n_punkte": 10, "n_basis": 5, "richtungen": {
        "down": {"ev": evs, "alt": [], "abgleich": fe_}, "up": {"ev": [], "alt": [], "abgleich": []}}}}}
    zl = vorbedingungen_text(b_).splitlines()
    pos = lambda s_: next((i for i, l_ in enumerate(zl) if s_ in l_), None)
    i_h, i_e = pos("2 frühere nicht gezeigt; es folgen die 15 jüngsten"), pos("vom Bezugskurs")
    i_f, i_n = pos("2 frühere nicht erfasste nicht gezeigt; es folgen die 10 jüngsten"), pos("nicht erfasst:")
    if not (None not in (i_h, i_e, i_f, i_n) and i_h < i_e and i_f < i_n and sum("vom Bezugskurs" in l_ for l_ in zl) == 15
            and sum("nicht erfasst:" in l_ for l_ in zl) == 10 and not any("… und" in l_ for l_ in zl)):
        fehler.append(f"(h) Hinweis/Liste {i_h}/{i_e}, {i_f}/{i_n}")
    zp = profil_text({"richtungen": {"ab": {"n_ereignisse": 15, "n_faelle": 15, "faelle": [
        {"ts": t0 + i * H, "coins": ["BTC"], "z": -1.5} for i in range(15)]}}}).splitlines()
    i_p = next((i for i, l_ in enumerate(zp) if "3 frühere nicht gezeigt; es folgen die 12 jüngsten" in l_), None)
    i_q = next((i for i, l_ in enumerate(zp) if l_.rstrip().endswith("σ") and "BTC" in l_), None)
    if not (i_p is not None and i_q is not None and i_p < i_q and sum("BTC" in l_ and "σ" in l_ for l_ in zp) == 12):
        fehler.append(f"(h) Ereignis-Profile: Hinweis {i_p}, erster Fall {i_q}")
    txt = f"lange Bewegung „{ergebnis['a']}“ (bis 23.55: -0,7 %) · Anstieg, Schwellenrand -2,96 %, Nachbarereignis, Lücke, offenes Fenster, ganze Kette, Hinweis vor der Liste"
    return {"ok": not fehler, "text": txt + (" · FEHL: " + "; ".join(fehler) if fehler else ""), "ergebnis": ergebnis}


def nulltest(verbose: bool = True) -> bool:
    """
    Rauschen: Paare und Vorbedingungen ohne Lift (Mittel der Lifts nahe null, kein |z| >= 3 häufiger als erwartet) --
    über PROBE_SEEDS am festen Zeitpunkt PROBE_NOW, gepoolt (deterministisch).
    """
    alle_l, alle_z = [], []
    for s_ in PROBE_SEEDS:
        lifts, zs, v = _nulllauf(s_, PROBE_NOW)
        alle_l += lifts; alle_z += zs
        if verbose:
            m_ = sum(lifts) / len(lifts) if lifts else 0.0
            print(f"    Szenario {s_}: {len(lifts)} Paare, mittlerer Lift {m_ * 100:+.1f} pp · Vorbedingungen: {v.get('n_up', 0)} Anstiege, "
                  f"{v.get('n_down', 0)} Rückgänge")
    mittel = sum(alle_l) / len(alle_l) if alle_l else 0.0
    anteil_z3 = sum(1 for z in alle_z if z >= 3) / len(alle_z) if alle_z else 0.0
    ok = abs(mittel) < 0.06 and anteil_z3 <= 0.05
    p43 = _profil_probe()                                            # U43: Ereignis-Profile (Positivkontrolle + Rauschen)
    ok = ok and p43["ok"]
    p131 = _vorbed_probe()                                           # U131: Ereigniserkennung der Vorbedingungen
    ok = ok and p131["ok"]
    if verbose:
        print(f"  Vorbedingungen, Ereignisse (U131): {p131['text']} -> {'ok' if p131['ok'] else 'FEHL'}")
    p135 = _abgleich_probe()                                         # 23.56 (U135): Begründung „nicht erfasst“
    ok = ok and p135["ok"]
    if verbose:
        print(f"  Abgleich mit den Kursdaten, Begründung (U135): {p135['text']} -> {'ok' if p135['ok'] else 'FEHL'}")
    # 23.46: ohne Streuung kein z (toter Treiber: in allen Fällen dieselbe Abweichung -- vorher z aus Rundungsrauschen)
    import numpy as np
    Mz = np.full((8, 3), np.nan); Mz[:, 0] = 0.1; Mz[:, 1] = np.linspace(-0.2, 0.5, 8); Mz[:3, 2] = 0.3
    _, z_, _ = _profil_zwerte(Mz, 8)
    z_soll = float(np.mean(Mz[:, 1]) / (np.std(Mz[:, 1], ddof=1) / math.sqrt(8)))
    with np.errstate(all="ignore"):
        z_alt = float(np.mean(Mz[:, 0]) / (np.std(Mz[:, 0], ddof=1) / math.sqrt(8)))
    ok_z = bool(np.isnan(z_[0]) and abs(z_[1] - z_soll) < 1e-9 and np.isnan(z_[2]))
    ok = ok and ok_z
    if verbose:
        print(f"  Ereignis-Profile: ohne Streuung kein z (toter Treiber: vorher z {z_alt:.3g}), gewöhnliche Zelle z {z_[1]:+.2f} = Formel, "
              f"unter 8 Fällen kein z -> {'ok' if ok_z else 'FEHL'}")
    if verbose:
        print(f"  Ereignis-Profile (U43): {p43['text']} -> {'ok' if p43['ok'] else 'FEHL'}")
        print(f"  Nulltest Konstellation über {len(PROBE_SEEDS)} Szenarien: {len(alle_l)} Paare, mittlerer Lift {mittel * 100:+.1f} pp (Soll |x| < 6) · "
              f"Anteil |z| >= 3: {anteil_z3 * 100:.1f} % (Soll <= 5) -> {'ok' if ok else 'FEHL'}")
        print("  Ergebnis:", "bestanden" if ok else "NICHT bestanden")
    return ok


# ---------------------------------------------------------------------------
# U43 -- Fingerabdruck, Stufe 1: Ereignis-Profile (23.09.2026)
# Was taten die Treiber in den 12 h VOR einem Rutsch bzw. Anstieg -- gegen normale Zeiten gleicher Schwankung?
# ---------------------------------------------------------------------------
RASTER = 900
PROFIL_H = 4                                   # Ereignis: Rendite der nächsten 4 h ...
PROFIL_K = 2.0                                 # ... mindestens 2 Standardabweichungen (4-h-Schwankung der 7 Tage davor)
PROFIL_LAGS_H = (-12, -8, -6, -4, -3, -2, -1, 0)
PROFIL_CLUSTER_S = 2 * 3600                    # gleichgerichtete Ereignisse mehrerer Coins binnen 2 h = ein Fall
PROFIL_NULL_R = 200                            # verschobene Ereigniszeiten -> Schwelle für den Familienfehler 5 %


def _profil_zwerte(M, n_min: int = 3):
    """z je Zelle (Vorlauf × Treiber) = Mittel / Standardfehler über die Fälle, erst ab n_min Fällen (23.21). 23.46: ohne Streuung kein
    z -- ein toter Treiber hat in allen Fällen dieselbe Abweichung; die Streuung ist dann 0 oder Rundungsrauschen, und z wurde
    unendlich oder riesig (dieselbe Rechnung wie das z der Treiberfamilien, auf dem Pi 1,2 · 10¹⁶)."""
    import warnings
    import numpy as np
    with warnings.catch_warnings(), np.errstate(all="ignore"):
        warnings.simplefilter("ignore", category=RuntimeWarning)
        cnt = np.sum(~np.isnan(M), axis=0); mu = np.nanmean(M, axis=0); sd = np.nanstd(M, axis=0, ddof=1)
        ok = (cnt >= n_min) & (sd > 1e-9 * np.maximum(1.0, np.abs(mu)))
        z = np.where(ok, mu / (sd / np.sqrt(np.maximum(cnt, 1))), np.nan)
    return mu, z, cnt


def _profil_kurse(con_main, coin: str, g0: int, n: int):
    """Schlusskurs der letzten Minute vor jedem 15-min-Rasterpunkt g0 + k * RASTER (NaN, wenn sie fehlt)."""
    import numpy as np
    P = np.full(n, np.nan)
    for ts, c in con_main.execute("SELECT ts, close FROM bars WHERE coin=? AND ts>=? AND ts<? AND ts % 900 >= 780 ORDER BY ts",
                                  (coin, g0 - RASTER, g0 + n * RASTER)):
        k = (ts // RASTER + 1) - g0 // RASTER
        if 0 <= k < n and c:
            P[k] = c
    return P


def _profil_sigma(P):
    """log-Kurs und 4-h-Schwankung aus den 7 Tagen davor (Standardabweichung der 15-min-Renditen x Wurzel 16)."""
    import numpy as np
    n = len(P); w = 7 * 96; nach = PROFIL_H * 3600 // RASTER
    with np.errstate(all="ignore"):
        lp = np.log(P); r = np.diff(lp, prepend=np.nan)
    v = ~np.isnan(r)
    cs1 = np.concatenate([[0.0], np.cumsum(np.where(v, r, 0.0))]); cs2 = np.concatenate([[0.0], np.cumsum(np.where(v, r * r, 0.0))])
    cn = np.concatenate([[0], np.cumsum(v)])
    sig = np.full(n, np.nan)
    for k in range(w, n):
        m_ = cn[k] - cn[k - w]
        if m_ >= 300:
            mu = (cs1[k] - cs1[k - w]) / m_
            sig[k] = math.sqrt(max((cs2[k] - cs2[k - w]) / m_ - mu * mu, 0.0)) * math.sqrt(nach)
    return lp, sig


def _profil_ereignisse(lp, sig, a: int, b: int):
    """
    Ereignisse nach der U43-Definition mit Fensterstart in [a, b): Rendite der nächsten 4 h >= PROFIL_K σ;
    Startpunkte derselben Richtung im Abstand <= 4 h = ein Ereignis; Beginn = im ersten Fenster der letzte
    Rasterpunkt, bevor sich der Kurs um 0,5 σ in Ereignisrichtung bewegt hat. Liefert ([(k, k0, richtung, z)], z-Reihe).
    """
    import numpy as np
    n = len(lp); nach = PROFIL_H * 3600 // RASTER
    with np.errstate(all="ignore"):
        fr = np.full(n, np.nan); fr[:n - nach] = lp[nach:] - lp[:n - nach]
        zs = fr / sig
        m_auf, m_ab = zs >= PROFIL_K, zs <= -PROFIL_K
    gueltig = np.zeros(n, bool); gueltig[a:b] = ~np.isnan(zs[a:b])
    aus = []
    for richtung, maske in (("auf", m_auf), ("ab", m_ab)):
        letzte = -10 ** 9
        for k0 in np.where(gueltig & maske)[0]:
            if k0 - letzte > nach:
                vz = 1 if richtung == "auf" else -1; k = int(k0)
                for j in range(1, nach + 1):
                    if not np.isnan(lp[k0 + j]) and vz * (lp[k0 + j] - lp[k0]) >= 0.5 * sig[k0]:
                        k = int(k0) + j - 1
                        break
                if k + nach < n and not np.isnan(sig[k]):
                    aus.append((k, int(k0), richtung, float(zs[k0])))
            letzte = k0
    return aus, zs


def ereignisse_kurs(con_main, coin: str, t_von: int, t_bis: int) -> list:
    """Ereignisse (Definition wie in den Ereignis-Profile) mit Beginn in t_von..t_bis -- nur aus Kursen, für die Markierung
    im Verlauf der Treiber. Erst 4 h nach dem Beginn erkennbar (die Bewegung muss stattgefunden haben)."""
    g0 = (t_von - 7 * 86_400) // RASTER * RASTER
    n = (t_bis // RASTER * RASTER - g0) // RASTER + 1
    lp, sig = _profil_sigma(_profil_kurse(con_main, coin, g0, n))
    nach = PROFIL_H * 3600 // RASTER
    a = max((t_von - g0) // RASTER - nach, 7 * 96)
    b = min(n - nach, (t_bis - PROFIL_H * 3600 - g0) // RASTER + 1)
    if b <= a:
        return []
    eig, _ = _profil_ereignisse(lp, sig, a, b)
    return sorted(({"ts": int(g0 + k * RASTER), "dir": r, "z": round(z, 2)} for k, k0, r, z in eig if g0 + k * RASTER >= t_von),
                  key=lambda e: e["ts"])


def _profil_raster(con_main, st, coin: str, t_von: int, t_bis: int, cb_ab):
    """15-min-Raster eines Coins: Schlusskurs am Rasterpunkt, Treiberwerte (jüngster Wert bis zum Rasterpunkt)."""
    import numpy as np
    g0 = (t_von - 7 * 86_400) // RASTER * RASTER                  # 7 Tage Vorlauf für die Schwankung
    n = (t_bis // RASTER * RASTER - g0) // RASTER + 1
    P = _profil_kurse(con_main, coin, g0, n)
    zeilen = st.execute("SELECT ts, name, score FROM forecast_drivers WHERE coin=? AND ts>? AND ts<=? ORDER BY ts",
                        (coin, t_von - RASTER, g0 + (n - 1) * RASTER)).fetchall()
    namen = sorted({z[1] for z in zeilen})
    j_ = {nm: j for j, nm in enumerate(namen)}
    S = np.full((n, len(namen)), np.nan)
    for ts, nm, sc in zeilen:
        if sc is None or (nm == F.CB_TREIBER and cb_ab and ts < cb_ab):
            continue                                                # U41: vor der Seiten-Umstellung vertauscht
        k = -(-ts // RASTER) - g0 // RASTER                         # nächster Rasterpunkt: der Wert lag dort schon vor
        if 0 <= k < n:
            S[k, j_[nm]] = sc
    alter = np.zeros(len(namen), dtype=int)                         # 23.21: Lücken höchstens 30 min (2 Rasterpunkte) füllen --
    for k in range(1, n):                                           # vorher wurde der letzte Wert unbegrenzt fortgeschrieben
        leer = np.isnan(S[k])
        fuell = leer & (alter < 2) & ~np.isnan(S[k - 1])
        S[k, fuell] = S[k - 1, fuell]
        alter = np.where(leer, alter + 1, 0)
    return g0, P, S, namen


def ereignis_profile(con_main, path: str = F.STORE, now: int | None = None, coins: list | None = None, tage: int = TAGE,
                     r_null: int = PROFIL_NULL_R, seed: int = 11) -> dict:
    """
    U43, Stufe 1 des Fingerabdrucks. EREIGNIS: Rendite der nächsten PROFIL_H Stunden von mindestens PROFIL_K
    Standardabweichungen (4-h-Schwankung aus den 7 Tagen davor), je Coin. Aufeinanderfolgende Startpunkte derselben
    Richtung (Abstand <= 4 h) sind ein Ereignis. BEGINN: im ersten solchen Fenster der letzte Rasterpunkt, bevor sich der
    Kurs um 0,5 σ in Ereignisrichtung bewegt hat -- alles bis zum Beginn liegt vor der Bewegung. Gleichgerichtete Ereignisse mehrerer Coins binnen 2 h sind EIN Fall (die Coins sind korreliert).
    PROFIL: je Treiber und Vorlauf (12 h bis 0 h vor Beginn) die mittlere Abweichung vom Normalwert desselben Coins in
    Zeiten gleicher Schwankung (Terzile; ohne die Fenster um Ereignisse), gemittelt über die Fälle; z = Mittel / SE.
    SCHWELLE: 95-%-Quantil des größten |z| aus r_null Läufen mit zufällig verschobenen Ereigniszeiten (je Coin
    zirkulär) -- schützt vor Zufallsfunden über alle Treiber x Vorläufe (Familienfehler 5 %) und vor Autokorrelation.
    """
    import numpy as np
    import warnings
    now = now or int(time.time())
    t_von = now - tage * 86_400
    st = F.store_connect(path)
    try:
        if coins is None:
            coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ?", (t_von,))]
        cb_ab = F.cb_seite_ab(con_main)
        raster = {}
        for c in sorted(coins):
            try:
                raster[c] = _profil_raster(con_main, st, c, t_von, now, cb_ab)
            except sqlite3.Error:
                continue
    finally:
        st.close()
    namen = sorted({nm for g0, P, S, nms in raster.values() for nm in nms})
    jn = {nm: j for j, nm in enumerate(namen)}
    lags = [h * 3600 // RASTER for h in PROFIL_LAGS_H]
    vor, nach = -min(lags), PROFIL_H * 3600 // RASTER
    ereignisse, info = [], {}
    for c, (g0, P, S, nms) in raster.items():
        n = len(P); w = 7 * 96
        lp, sig = _profil_sigma(P)
        erste = np.where(~np.all(np.isnan(S), axis=1))[0]
        if not len(erste):
            continue
        a = max(int(erste[0]) + vor, w)                             # Beginn frühestens 12 h nach dem ersten Treiberwert
        b = min(n - nach, (now - PROFIL_H * 3600 - g0) // RASTER + 1)
        if b - a < 96 * 2:
            continue
        eig, zs = _profil_ereignisse(lp, sig, a, b)
        gueltig = np.zeros(n, bool); gueltig[a:b] = ~np.isnan(zs[a:b])
        terz = np.full(n, -1); e_ = min(n, b + nach)                 # Terzile auch für geschärfte Beginnpunkte hinter b
        q1, q2 = np.nanpercentile(sig[a:b], [100 / 3, 200 / 3])
        with np.errstate(invalid="ignore"):
            terz[a:e_] = np.where(sig[a:e_] <= q1, 0, np.where(sig[a:e_] <= q2, 1, 2))
        frei = gueltig.copy()
        for k, k0, richtung, z0 in eig:
            frei[max(0, k - vor):k + nach + 1] = False
            ereignisse.append({"coin": c, "k": int(k), "ts": int(g0 + k * RASTER), "dir": richtung, "z": z0, "terz": int(terz[k])})
        B = np.full((3, len(namen)), np.nan)
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore", category=RuntimeWarning)
            for t_ in range(3):
                zeilen_ = frei & (terz == t_)
                if zeilen_.any():
                    B[t_, [jn[x] for x in nms]] = np.nanmean(S[zeilen_], axis=0)
        info[c] = {"g0": g0, "P": P, "S": S, "cols": [jn[x] for x in nms], "B": B, "sig": sig, "terz": terz, "a": a, "b": b, "lp": lp}

    def einheiten(ev: list) -> list:
        ev = sorted(ev, key=lambda e: e["ts"]); gruppen = []
        for e in ev:
            if gruppen and e["ts"] - gruppen[-1][0]["ts"] <= PROFIL_CLUSTER_S:
                gruppen[-1].append(e)
            else:
                gruppen.append([e])
        return gruppen

    def matrix(gruppen: list, ks: list | None = None):
        """Abweichungen je Fall (Mittel über seine Coins): Fälle x Vorläufe x Treiber; ks = verschobene Beginnpunkte."""
        M = np.full((len(gruppen), len(lags), len(namen)), np.nan); preis = np.full((len(gruppen), len(lags) + 1), np.nan)
        i_e = 0
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore", category=RuntimeWarning)
            for u, grp in enumerate(gruppen):
                zeilen_, pz = [], []
                for e in grp:
                    d = info[e["coin"]]; k = ks[i_e] if ks is not None else e["k"]; i_e += 1
                    t_ = d["terz"][k] if ks is not None else e["terz"]
                    z_ = np.full((len(lags), len(namen)), np.nan)
                    z_[:, d["cols"]] = d["S"][[k + L for L in lags]] - d["B"][max(t_, 0)][d["cols"]]
                    zeilen_.append(z_)
                    s_ = d["sig"][k]
                    pz.append([(d["lp"][k + L] - d["lp"][k - vor]) / s_ for L in lags] + [(d["lp"][k + nach] - d["lp"][k]) / s_])
                M[u] = np.nanmean(np.stack(zeilen_), axis=0); preis[u] = np.nanmean(np.array(pz), axis=0)
        return M, preis

    zwerte = _profil_zwerte

    rng = np.random.default_rng(seed)
    aus = {"ts": now, "k": PROFIL_K, "h": PROFIL_H, "lags_h": list(PROFIL_LAGS_H), "coins": sorted(info), "treiber": namen,
           "seit": min((int(d["g0"] + d["a"] * RASTER - vor * RASTER) for d in info.values()), default=None), "richtungen": {}}
    for richtung in ("ab", "auf"):
        ev = [e for e in ereignisse if e["dir"] == richtung]
        gruppen = einheiten(ev)
        blk = {"n_ereignisse": len(ev), "n_faelle": len(gruppen),
               "faelle": [{"ts": g[0]["ts"], "coins": [e["coin"] for e in g], "z": round(float(np.mean([e["z"] for e in g])), 2)} for g in gruppen]}
        if len(gruppen) >= 3:
            M, preis = matrix(gruppen)
            n_min = max(8, math.ceil(0.5 * len(gruppen)))            # 23.21: 3 Fälle gaben z = 20 durch Zufall und trieben die Schwelle
            mu, z, cnt = zwerte(M, n_min)
            maxima = []
            flach = [e for g in gruppen for e in g]
            for _ in range(r_null):
                ks = []
                for e in flach:
                    d = info[e["coin"]]; m_ = d["b"] - d["a"]
                    s_ = int(rng.integers(min(96, m_ // 4), max(m_ - min(96, m_ // 4), min(96, m_ // 4) + 1)))
                    ks.append(d["a"] + (e["k"] - d["a"] + s_) % m_)
                _, z0, _ = zwerte(matrix(gruppen, ks)[0], n_min)
                maxima.append(float(np.nanmax(np.abs(z0))) if np.any(~np.isnan(z0)) else 0.0)
            schwelle = float(np.quantile(maxima, 0.95))
            zeilen = []
            for j, nm in enumerate(namen):
                if not np.any(cnt[:, j] >= 3):
                    continue
                zz = z[:, j]; sig_ = [bool(abs(x) >= schwelle) if not np.isnan(x) else False for x in zz]
                vorlauf = None                                      # zusammenhängender Abschnitt, der dem Beginn am nächsten liegt
                treffer_ = [i for i, s_ in enumerate(sig_) if s_]
                if treffer_:
                    i_end = treffer_[-1]; vz = np.sign(mu[i_end, j]); i = i_end
                    while i > 0 and sig_[i - 1] and np.sign(mu[i - 1, j]) == vz:
                        i -= 1
                    vorlauf = [PROFIL_LAGS_H[i], PROFIL_LAGS_H[i_end]]
                zeilen.append({"treiber": nm, "abw": [None if np.isnan(x) else round(float(x), 3) for x in mu[:, j]],
                               "z": [None if np.isnan(x) else round(float(x), 2) for x in zz], "sig": sig_,
                               "n": int(np.max(cnt[:, j])), "vorlauf_h": vorlauf,
                               "max_z": float(np.nanmax(np.abs(zz))) if np.any(~np.isnan(zz)) else 0.0})
            zeilen.sort(key=lambda x: -x["max_z"])
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=RuntimeWarning)
                blk.update(schwelle=round(schwelle, 2), treiber=zeilen, n_min=n_min,
                           kurs=[None if np.isnan(x) else round(float(x), 2) for x in np.nanmean(preis, axis=0)])
        aus["richtungen"][richtung] = blk
    return aus


def profil_text(e: dict) -> str:
    """Tabelle für den Debug-Eintrag (U43)."""
    L = e.get("lags_h") or list(PROFIL_LAGS_H)
    z = [f"Ereignis-Profile (U43, Fingerabdruck Stufe 1) · Ereignis = Rendite der nächsten {e.get('h')} h von mindestens {e.get('k')} σ "
         f"(4-h-Schwankung der 7 Tage davor), je Coin · gleichgerichtete Ereignisse mehrerer Coins binnen 2 h = ein Fall",
         f"Coins: {', '.join(e.get('coins') or [])} · Treiberwerte seit "
         f"{time.strftime('%d.%m.%Y %H:%M', time.localtime(e['seit'])) if e.get('seit') else '—'} (forecast_drivers, alle 15 min)",
         "Wert = mittlere Abweichung vom Normalwert desselben Coins in Zeiten gleicher Schwankung (Score-Punkte), * = über der Schwelle.",
         "Schwelle = 95 % des größten |z| bei zufällig verschobenen Ereigniszeiten (schützt vor Zufallsfunden über alle Treiber und Vorläufe).",
         "Vorlauf = zusammenhängender Abschnitt über der Schwelle, der dem Beginn am nächsten liegt. Beginn = letzter Rasterpunkt, bevor",
         "sich der Kurs um 0,5 σ bewegt hat -- alles bis 0 h liegt VOR der Bewegung.", ""]
    for richtung, titel in (("ab", "RUTSCHE"), ("auf", "ANSTIEGE")):
        b = (e.get("richtungen") or {}).get(richtung) or {}
        z.append(f"{titel}: {b.get('n_ereignisse', 0)} Ereignisse → {b.get('n_faelle', 0)} Fälle" +
                 (f" · Schwelle |z| ≥ {b['schwelle']} · getestet werden Zellen ab {b.get('n_min')} Fällen" if b.get("schwelle") is not None
                  else " · zu wenige Fälle für ein Profil (mindestens 3)"))
        if len(b.get("faelle") or []) > 12:                                 # 23.56 (U135): Hinweis VOR der Liste
            z.append(f"  ({len(b['faelle']) - 12} frühere nicht gezeigt; es folgen die 12 jüngsten)")
        for f_ in (b.get("faelle") or [])[-12:]:
            z.append(f"  {time.strftime('%d.%m. %H:%M', time.localtime(f_['ts']))}  {'/'.join(f_['coins']):<22} {f_['z']:+.1f} σ")
        if b.get("treiber"):
            kopf = "".join(f"{('%+dh' % h) if h else '0h':>8}" for h in L)
            z.append(f"  {'':<30}{kopf}   Vorlauf")
            k_ = b.get("kurs") or []
            z.append(f"  {'Kurs seit −12 h (σ)':<30}" + "".join(f"{(('%+.2f' % x) if x is not None else '—'):>8}" for x in k_[:len(L)])
                     + (f"   danach {k_[-1]:+.2f} σ" if k_ and k_[-1] is not None else ""))
            for t in b["treiber"]:
                zellen = "".join(f"{(('%+.2f' % a) + ('*' if s else ' ')) if a is not None else '—':>8}" for a, s in zip(t["abw"], t["sig"]))
                v_ = t["vorlauf_h"]
                if b.get("n_min") and t["n"] < b["n_min"]:
                    z.append(f"  {t['treiber'][:29]:<30}{zellen}   nicht getestet (n {t['n']} < {b['n_min']})"); continue
                vl = "—" if not v_ else (f"{v_[0]:+d} h bis {v_[1]:+d} h" if v_[0] != v_[1] else f"bei {v_[0]:+d} h").replace("+0 h", "0 h")
                z.append(f"  {t['treiber'][:29]:<30}{zellen}   {vl} (max |z| {t['max_z']:.1f}, n {t['n']})")
        z.append("")
    z.append("Lesart: Ein Vorläufer weicht VOR dem Beginn ab und liegt über der Schwelle. Mit wenigen Fällen ist die Schwelle hoch --"
             " dass nichts markiert ist, heißt dann nur: noch nicht belegbar.")
    return "\n".join(z)


def _profil_probe(seed: int = 3) -> dict:
    """
    Selbsttest U43 (fester Zeitpunkt PROBE_NOW, fester Seed): 3 Coins, 40 Tage, eingebaute Sprünge (4-h-Trend von 4 σ)
    und ein eingebauter Vorläufer (+0,6 in den 3 h vor Anstiegen, -0,6 vor Rutschen) neben drei reinen Rauschtreibern.
    Soll: Vorläufer in beiden Richtungen markiert, mit richtigem Vorzeichen; kein Rauschtreiber markiert.
    """
    import os as _os, tempfile as _tf
    import numpy as np
    rng = np.random.default_rng(seed); now = PROBE_NOW; tage = 40
    tmp = _tf.mkdtemp(); con = sqlite3.connect(_os.path.join(tmp, "m.db"))
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    pfad = _os.path.join(tmp, "f.db"); st = F.store_connect(pfad)
    g_start = (now - tage * 86_400) // RASTER * RASTER; n = tage * 96
    for c in ("AAA", "BBB", "CCC"):
        drift = np.zeros(n); vorl = np.zeros(n); k = 7 * 96 + 60
        while k < n - 40:
            d = rng.choice((-1, 1)); drift[k:k + 16] += d * 4 * 0.008 / 16; vorl[k - 12:k] = 0.6 * d   # 4 σ(4 h) über 16 Schritte
            k += int(rng.integers(100, 200))
        lp = np.cumsum(rng.normal(0, 0.002, n) + drift) + math.log(100)
        rows = []; drv = []
        rausch = [np.clip(rng.normal(0, 0.3, n), -1, 1) for _ in range(3)]
        for i in range(n):
            g = g_start + i * RASTER; px = math.exp(lp[i])
            rows.append((g - 60, c, px, px, px, px, 1, 1))
            if i >= 7 * 96:
                t_f = g - 840                                          # Prognose kurz nach dem vorigen Rasterpunkt
                drv += [(t_f, c, "Vorläufer", float(np.clip(rausch[0][i] * 0.5 + vorl[i], -1, 1)))]
                drv += [(t_f, c, f"Rauschen {q}", float(rausch[q][i])) for q in (1, 2)]
        con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
        st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", drv)
    con.commit(); st.commit(); st.close()
    e = ereignis_profile(con, path=pfad, now=now, coins=["AAA", "BBB", "CCC"], tage=tage - 7, r_null=100)
    con.close()
    try:
        for f_ in _os.listdir(tmp):
            _os.remove(_os.path.join(tmp, f_))
        _os.rmdir(tmp)
    except OSError:
        pass
    ok = True; txt = []; fehl_ges = 0
    for richtung, vz in (("auf", 1), ("ab", -1)):
        b = e["richtungen"].get(richtung) or {}
        tr = {t["treiber"]: t for t in b.get("treiber") or []}
        v = tr.get("Vorläufer") or {}
        treffer = any(s and a is not None and a * vz > 0 for a, s in zip(v.get("abw") or [], v.get("sig") or []))
        falsch = [t for t in tr.values() if t["treiber"] != "Vorläufer" and any(t["sig"])]
        fehl_ges += len(falsch)
        ok = ok and treffer and b.get("n_faelle", 0) >= 20
        txt.append(f"{'Anstiege' if richtung == 'auf' else 'Rutsche'}: {b.get('n_faelle', 0)} Fälle, Schwelle {b.get('schwelle')}, "
                   f"Vorläufer {'erkannt' if treffer else 'NICHT erkannt'} (Vorlauf {v.get('vorlauf_h')} h), Rauschtreiber markiert: {len(falsch)}")
    # Familienfehler 5 % je Richtung: ein Zufallsfund in beiden Richtungen zusammen ist erlaubt (~10 %), zwei nicht (~0,3 %)
    ok = ok and fehl_ges <= 1
    return {"ok": ok, "text": " · ".join(txt) + f" · Zufallsfunde gesamt {fehl_ges} (Soll ≤ 1)"}


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--vorbedingungen" in sys.argv:                              # U131: Debug-Eintrag "Vorbedingungen: Ereignisliste"
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else "hl_liq.db"
        _con = sqlite3.connect(f"file:{_db}?mode=ro", uri=True)
        _coins = [sys.argv[sys.argv.index("--coin") + 1]] if "--coin" in sys.argv else None
        print(vorbedingungen_text(vorbedingungen_bericht(_con, coins=_coins)))
        _con.close()
        sys.exit(0)
    if "--profile" in sys.argv:                                     # U43: Debug-Eintrag "Ereignis-Profile"
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else "hl_liq.db"
        _con = sqlite3.connect(f"file:{_db}?mode=ro", uri=True)
        print(profil_text(ereignis_profile(_con)))
        _con.close()
        sys.exit(0)
    print(__doc__)
