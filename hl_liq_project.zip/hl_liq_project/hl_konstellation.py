#!/usr/bin/env python3
"""
hl_konstellation.py -- zwei Rückschau-Statistiken auf den gespeicherten Prognosen (23.09.2026):

1. KONSTELLATIONEN: Für die Treiberpaare mit dem höchsten v2-Gewicht (sonst Prior): Wenn beide Treiber
   im selben Block in dieselbe Richtung ausschlagen (|Score| >= SCHWELLE), wie oft folgte der Kurs binnen
   4 h dieser Richtung? Bedingte Quote mit Wilson-Intervall auf n_eff (getrennte 4-h-Blöcke) gegen die
   Basisrate derselben Richtung über alle Blöcke -> Lift.
2. VORBEDINGUNGEN: Welche Treiber standen wie, BEVOR der Kurs binnen HORIZONT_V um mindestens BEWEGUNG
   stieg bzw. fiel? Je Treiber: Anteil der Vorlauf-Blöcke, in denen er in die Richtung der späteren
   Bewegung zeigte (Score >= SCHWELLE), gegen den Anteil über alle Blöcke (Basis = Placebo). Lift mit
   z-Wert (Zwei-Anteile-Test). Eine Bewegung wird einmal gezählt: Blöcke, deren Fenster dieselbe
   Bewegung enthalten, werden zum ersten Block zusammengefasst.

Beides ist Anzeige, kein Treiber und kein Modellbestandteil -- die Interaktionsterme für v2 (Plan U25,
Stufe 2) folgen erst, wenn hier ein Paar über Wochen einen belegten Lift zeigt.
"""
import json
import math
import sqlite3
import sys
import time

import hl_forecast as F

TAGE = 90
SCHWELLE = 0.3          # |Score| ab dem ein Treiber "ausschlägt"
BEWEGUNG = 0.03         # 3 %
HORIZONT_V = 24 * 3600  # Vorbedingungen: Bewegung binnen 24 h
BLOCK4 = 4 * 3600
MAX_PAARE = 15


def _wilson(hits, n, z=1.96):
    if n <= 0:
        return None
    p = hits / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def _z_zwei_anteile(h1, n1, h2, n2):
    if n1 <= 0 or n2 <= 0:
        return None
    p1, p2 = h1 / n1, h2 / n2; p = (h1 + h2) / (n1 + n2)
    se = math.sqrt(max(p * (1 - p), 1e-6) * (1 / n1 + 1 / n2))
    return (p1 - p2) / se if se > 0 else None


def lade(con_main, coin: str, path: str, now: int | None = None) -> dict:
    """Ein Fall je 4-h-Block (die früheste Prognose): Scores, p0, Kurs nach 4 h, max. Anstieg/Rückgang binnen HORIZONT_V."""
    now = now or int(time.time())
    st = F.store_connect(path)
    rows = st.execute("SELECT ts, price, payload FROM forecast WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                      (coin, now - TAGE * 86_400, now - BLOCK4)).fetchall()
    st.close()
    bars = con_main.execute("SELECT ts, close, high, low FROM bars WHERE coin=? AND ts>=? ORDER BY ts", (coin, now - (TAGE + 2) * 86_400)).fetchall()
    b_ts = [b[0] for b in bars]
    import bisect
    def close_at(t):
        i = bisect.bisect_right(b_ts, t) - 1
        return bars[i][1] if i >= 0 and t - b_ts[i] <= 120 else None
    def extrema(t, h):
        i = bisect.bisect_right(b_ts, t); j = bisect.bisect_right(b_ts, t + h)
        if j - i < 5 or t + h > b_ts[-1]:
            return None, None
        seg = bars[i:j]
        return max((s[2] or s[1]) for s in seg), min((s[3] or s[1]) for s in seg)
    cb_ab = F.cb_seite_ab(con_main)                                 # U41: Spot-Taker-Flow davor vertauscht
    seen = set(); faelle = []
    for ts, p0, payload in rows:
        b = ts // BLOCK4
        if b in seen or not p0:
            continue
        seen.add(b)
        try:
            pl = json.loads(payload)
        except (TypeError, ValueError):
            continue
        sc = {d["name"]: float(d["score"]) for d in pl.get("drivers", []) if d.get("score") is not None}
        if cb_ab and ts < cb_ab:
            sc.pop(F.CB_TREIBER, None)                                  # U41
        c4 = close_at(ts + BLOCK4)
        hi, lo = extrema(ts, HORIZONT_V)
        faelle.append({"ts": ts, "block": b, "p0": p0, "sc": sc, "r4": (c4 / p0 - 1.0) if c4 else None,
                       "up": (hi / p0 - 1.0) if hi else None, "down": (lo / p0 - 1.0) if lo else None})
    return {"faelle": faelle, "now": now}


def konstellationen(faelle: list, gewichte: dict | None) -> list:
    """Paare der gewichtigsten Treiber: bedingte 4-h-Quote bei gemeinsamem Ausschlag, gegen die Basisrate."""
    if not faelle:
        return []
    w = gewichte or {}
    namen = sorted(F.PRIORS, key=lambda n: -abs(w.get(n, F.PRIORS[n])))[:MAX_PAARE]
    gueltig = [f for f in faelle if f["r4"] is not None and abs(f["r4"]) >= F.TOLERANZ]
    n_all = len(gueltig); up_all = sum(1 for f in gueltig if f["r4"] > 0)
    basis = {"up": up_all / n_all if n_all else None, "down": (n_all - up_all) / n_all if n_all else None}
    out = []
    for i in range(len(namen)):
        for j in range(i + 1, len(namen)):
            a, b = namen[i], namen[j]
            for richtung, vorz in (("up", 1), ("down", -1)):
                sel = [f for f in gueltig if vorz * f["sc"].get(a, 0.0) >= SCHWELLE and vorz * f["sc"].get(b, 0.0) >= SCHWELLE]
                if len(sel) < 5:
                    continue
                treffer = sum(1 for f in sel if (f["r4"] > 0) == (vorz > 0))
                n_eff = len({f["block"] for f in sel})
                q = treffer / len(sel); ci = _wilson(q * n_eff, n_eff)
                bs = basis[richtung]
                out.append({"a": a, "b": b, "richtung": richtung, "n": len(sel), "n_eff": n_eff, "quote": round(q, 3),
                            "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None, "basis": round(bs, 3) if bs is not None else None,
                            "lift": round(q - bs, 3) if bs is not None else None,
                            "z": round(_z_zwei_anteile(treffer, len(sel), up_all if richtung == "up" else n_all - up_all, n_all) or 0.0, 2)})
    # Auswahl-Effekt ehrlich ausweisen: unter der Nullhypothese überschreiten ~2,3 % aller Prüfungen z >= 2
    n_tests = len(out); n_z2 = sum(1 for r in out if r["z"] >= 2)
    out.sort(key=lambda r: -(r["lift"] or 0) * math.sqrt(r["n_eff"]))
    top = out[:40]
    for r in top:
        r["n_tests"] = n_tests; r["n_z2"] = n_z2; r["erwartet_z2"] = round(0.023 * n_tests, 1)
    return top


def vorbedingungen(faelle: list) -> dict:
    """Treiberprofile vor Bewegungen >= BEWEGUNG binnen HORIZONT_V: Anteil 'zeigte in die spätere Richtung' gegen Basis."""
    if not faelle:
        return {"up": [], "down": [], "n_up": 0, "n_down": 0, "n_all": 0}
    gueltig = [f for f in faelle if f["up"] is not None and f["down"] is not None]
    n_all = len(gueltig)
    out = {"n_all": n_all, "bewegung": BEWEGUNG, "horizont_h": HORIZONT_V // 3600, "schwelle": SCHWELLE}
    for richtung, key, vorz in (("up", "up", 1), ("down", "down", -1)):
        # Ereignisse: Blöcke mit Bewegung, zusammengefasst -- aufeinanderfolgende Blöcke (Abstand <= HORIZONT_V), deren
        # Fenster dieselbe Bewegung enthalten, zählen als EIN Ereignis (der erste Block = Vorbedingung)
        ev_bl = [f for f in gueltig if (f[key] >= BEWEGUNG if vorz > 0 else f[key] <= -BEWEGUNG)]
        ereignisse = []; letzte = None
        for f in ev_bl:
            if letzte is None or f["ts"] - letzte > HORIZONT_V:
                ereignisse.append(f)
            letzte = f["ts"]
        n_ev = len(ereignisse)
        profil = []
        for name in F.PRIORS:
            in_ev = sum(1 for f in ereignisse if vorz * f["sc"].get(name, 0.0) >= SCHWELLE)
            in_all = sum(1 for f in gueltig if vorz * f["sc"].get(name, 0.0) >= SCHWELLE)
            vorhanden_ev = sum(1 for f in ereignisse if name in f["sc"])
            if n_ev < 3 or vorhanden_ev < 3 or in_all == 0:
                continue
            q_ev = in_ev / n_ev; q_all = in_all / n_all
            profil.append({"treiber": name, "anteil_vor": round(q_ev, 3), "basis": round(q_all, 3), "lift": round(q_ev - q_all, 3),
                           "z": round(_z_zwei_anteile(in_ev, n_ev, in_all, n_all) or 0.0, 2), "n_ev": n_ev,
                           "mittel_vor": round(sum(vorz * f["sc"].get(name, 0.0) for f in ereignisse) / n_ev, 3)})
        profil.sort(key=lambda r: -r["lift"])
        out[richtung] = profil[:12]; out[f"n_{richtung}"] = n_ev
        out[f"beispiele_{richtung}"] = [{"ts": f["ts"], "bewegung": round(f[key] * 100, 2)} for f in ereignisse[-5:]]
    return out


def berechnen(con_main, coin: str, path: str = F.STORE, now: int | None = None, speichern: bool = True) -> dict:
    D = lade(con_main, coin, path, now)
    gew = None
    try:
        import hl_kalib
        m = hl_kalib.laden(coin, 4, path)
        gew = (m or {}).get("weights")
    except Exception:
        gew = None
    aus = {"coin": coin, "ts": D["now"], "n_bloecke": len(D["faelle"]), "konstellationen": konstellationen(D["faelle"], gew),
           "vorbedingungen": vorbedingungen(D["faelle"])}
    if speichern:
        st = F.store_connect(path)
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, "konstellation", json.dumps(aus), D["now"]))
        # Tägliche Historie (23.09.): Ein Paar qualifiziert sich für Stufe 2 nur, wenn sein Lift über Wochen hält --
        # dafür braucht es die Zeitreihe der Ergebnisse, nicht nur den letzten Stand. Je Coin und Tag ein Eintrag.
        st.execute("""CREATE TABLE IF NOT EXISTS konstellation_hist (coin TEXT, tag INTEGER, ts INTEGER, n_bloecke INTEGER,
                      paare TEXT, vorbedingungen TEXT, PRIMARY KEY (coin, tag))""")
        tag = D["now"] // 86_400 * 86_400
        kompakt = [{k: r.get(k) for k in ("a", "b", "richtung", "n", "n_eff", "quote", "basis", "lift", "z")} for r in aus["konstellationen"]]
        vb = {k: aus["vorbedingungen"].get(k) for k in ("up", "down", "n_up", "n_down", "n_all")}
        st.execute("INSERT OR REPLACE INTO konstellation_hist VALUES (?,?,?,?,?,?)", (coin, tag, D["now"], aus["n_bloecke"], json.dumps(kompakt), json.dumps(vb)))
        st.commit(); st.close()
    return aus


def stabil(coin: str, path: str = F.STORE, min_tage: int = 14, min_z: float = 2.0) -> list:
    """Paare, die an mindestens min_tage Tagen z >= min_z hielten -- die Kandidaten für Interaktionsterme (Stufe 2)."""
    try:
        st = F.store_connect(path)
        rows = st.execute("SELECT tag, paare FROM konstellation_hist WHERE coin=? ORDER BY tag", (coin,)).fetchall(); st.close()
    except sqlite3.Error:
        return []
    tage: dict = {}
    for tag, paare in rows:
        try:
            for r in json.loads(paare):
                if (r.get("z") or 0) >= min_z and (r.get("lift") or 0) > 0:
                    tage.setdefault((r["a"], r["b"], r["richtung"]), set()).add(tag)
        except (ValueError, TypeError):
            continue
    return sorted([{"a": a, "b": b, "richtung": r, "tage": len(t), "tage_gesamt": len(rows)} for (a, b, r), t in tage.items() if len(t) >= min_tage],
                  key=lambda x: -x["tage"])


def laden(coin: str, path: str = F.STORE) -> dict | None:
    try:
        st = F.store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin=? AND key='konstellation'", (coin,)).fetchone(); st.close()
        return json.loads(r[0]) if r and r[0] else None
    except (sqlite3.Error, ValueError, TypeError):
        return None


# 23.13: fester, auf 4 h ausgerichteter Zeitpunkt und feste Szenarien -- das 4-h-Raster hing sonst an der Uhr; bei
# unverändertem Code fiel der Nulltest in 5 von 24 Viertelstunden durch (mittlerer Lift eines Szenarios > 6 pp).
PROBE_NOW = 1_790_006_400
PROBE_SEEDS = (5, 6, 7, 8, 9)


def _nulllauf(seed: int, now: int) -> tuple:
    """Ein Rausch-Szenario: Lifts der Paare, |z| aller Prüfungen, Vorbedingungen."""
    import random as _rnd
    rng = _rnd.Random(seed); con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    now = now // 900 * 900; start = now - 60 * 86_400; px = 100.0; rows = []
    t = start - 3600
    while t <= now:
        px *= math.exp(rng.gauss(0, 0.0008)); rows.append((t, "BTC", px, px * (1 + abs(rng.gauss(0, 0.0004))), px * (1 - abs(rng.gauss(0, 0.0004))), px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); close = {r[0]: r[5] for r in rows}
    import tempfile, os
    tmp = tempfile.mkdtemp(); path = os.path.join(tmp, "f.db"); st = F.store_connect(path)
    namen = list(F.PRIORS)[:12]
    for ts in range(start, now - BLOCK4, 900):
        p0 = close.get(ts)
        if not p0:
            continue
        st.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)",
                   (ts, "BTC", p0, 0, p0, p0, json.dumps({"drivers": [{"name": n, "score": rng.uniform(-0.8, 0.8)} for n in namen]})))
    st.commit(); st.close()
    r = berechnen(con, "BTC", path=path, now=now, speichern=False)
    k = r["konstellationen"]; v = r["vorbedingungen"]
    lifts = [x["lift"] for x in k if x["lift"] is not None]
    zs = [abs(x["z"]) for x in k] + [abs(x["z"]) for x in v.get("up", [])] + [abs(x["z"]) for x in v.get("down", [])]
    try:
        for f in os.listdir(tmp):
            os.remove(os.path.join(tmp, f))
        os.rmdir(tmp)
    except OSError:
        pass
    return lifts, zs, v


def nulltest(verbose: bool = True) -> bool:
    """
    Rauschen: Paare und Vorbedingungen ohne Lift (Mittel der Lifts nahe null, kein |z| >= 3 häufiger als erwartet) --
    über PROBE_SEEDS am festen Zeitpunkt PROBE_NOW, gepoolt (deterministisch).
    """
    alle_l, alle_z = [], []
    for s_ in PROBE_SEEDS:
        lifts, zs, v = _nulllauf(s_, PROBE_NOW)
        alle_l += lifts; alle_z += zs
        if verbose:
            m_ = sum(lifts) / len(lifts) if lifts else 0.0
            print(f"    Szenario {s_}: {len(lifts)} Paare, mittlerer Lift {m_ * 100:+.1f} pp · Vorbedingungen: {v.get('n_up', 0)} Anstiege, "
                  f"{v.get('n_down', 0)} Rückgänge")
    mittel = sum(alle_l) / len(alle_l) if alle_l else 0.0
    anteil_z3 = sum(1 for z in alle_z if z >= 3) / len(alle_z) if alle_z else 0.0
    ok = abs(mittel) < 0.06 and anteil_z3 <= 0.05
    p43 = _profil_probe()                                            # U43: Ereignis-Profile (Positivkontrolle + Rauschen)
    ok = ok and p43["ok"]
    if verbose:
        print(f"  Ereignis-Profile (U43): {p43['text']} -> {'ok' if p43['ok'] else 'FEHL'}")
        print(f"  Nulltest Konstellation über {len(PROBE_SEEDS)} Szenarien: {len(alle_l)} Paare, mittlerer Lift {mittel * 100:+.1f} pp (Soll |x| < 6) · "
              f"Anteil |z| >= 3: {anteil_z3 * 100:.1f} % (Soll <= 5) -> {'ok' if ok else 'FEHL'}")
        print("  Ergebnis:", "bestanden" if ok else "NICHT bestanden")
    return ok


# ---------------------------------------------------------------------------
# U43 -- Fingerabdruck, Stufe 1: Ereignis-Profile (23.09.2026)
# Was taten die Treiber in den 12 h VOR einem Rutsch bzw. Anstieg -- gegen normale Zeiten gleicher Schwankung?
# ---------------------------------------------------------------------------
RASTER = 900
PROFIL_H = 4                                   # Ereignis: Rendite der nächsten 4 h ...
PROFIL_K = 2.0                                 # ... mindestens 2 Standardabweichungen (4-h-Schwankung der 7 Tage davor)
PROFIL_LAGS_H = (-12, -8, -6, -4, -3, -2, -1, 0)
PROFIL_CLUSTER_S = 2 * 3600                    # gleichgerichtete Ereignisse mehrerer Coins binnen 2 h = ein Fall
PROFIL_NULL_R = 200                            # verschobene Ereigniszeiten -> Schwelle für den Familienfehler 5 %


def _profil_kurse(con_main, coin: str, g0: int, n: int):
    """Schlusskurs der letzten Minute vor jedem 15-min-Rasterpunkt g0 + k * RASTER (NaN, wenn sie fehlt)."""
    import numpy as np
    P = np.full(n, np.nan)
    for ts, c in con_main.execute("SELECT ts, close FROM bars WHERE coin=? AND ts>=? AND ts<? AND ts % 900 >= 780 ORDER BY ts",
                                  (coin, g0 - RASTER, g0 + n * RASTER)):
        k = (ts // RASTER + 1) - g0 // RASTER
        if 0 <= k < n and c:
            P[k] = c
    return P


def _profil_sigma(P):
    """log-Kurs und 4-h-Schwankung aus den 7 Tagen davor (Standardabweichung der 15-min-Renditen x Wurzel 16)."""
    import numpy as np
    n = len(P); w = 7 * 96; nach = PROFIL_H * 3600 // RASTER
    with np.errstate(all="ignore"):
        lp = np.log(P); r = np.diff(lp, prepend=np.nan)
    v = ~np.isnan(r)
    cs1 = np.concatenate([[0.0], np.cumsum(np.where(v, r, 0.0))]); cs2 = np.concatenate([[0.0], np.cumsum(np.where(v, r * r, 0.0))])
    cn = np.concatenate([[0], np.cumsum(v)])
    sig = np.full(n, np.nan)
    for k in range(w, n):
        m_ = cn[k] - cn[k - w]
        if m_ >= 300:
            mu = (cs1[k] - cs1[k - w]) / m_
            sig[k] = math.sqrt(max((cs2[k] - cs2[k - w]) / m_ - mu * mu, 0.0)) * math.sqrt(nach)
    return lp, sig


def _profil_ereignisse(lp, sig, a: int, b: int):
    """
    Ereignisse nach der U43-Definition mit Fensterstart in [a, b): Rendite der nächsten 4 h >= PROFIL_K σ;
    Startpunkte derselben Richtung im Abstand <= 4 h = ein Ereignis; Beginn = im ersten Fenster der letzte
    Rasterpunkt, bevor sich der Kurs um 0,5 σ in Ereignisrichtung bewegt hat. Liefert ([(k, k0, richtung, z)], z-Reihe).
    """
    import numpy as np
    n = len(lp); nach = PROFIL_H * 3600 // RASTER
    with np.errstate(all="ignore"):
        fr = np.full(n, np.nan); fr[:n - nach] = lp[nach:] - lp[:n - nach]
        zs = fr / sig
        m_auf, m_ab = zs >= PROFIL_K, zs <= -PROFIL_K
    gueltig = np.zeros(n, bool); gueltig[a:b] = ~np.isnan(zs[a:b])
    aus = []
    for richtung, maske in (("auf", m_auf), ("ab", m_ab)):
        letzte = -10 ** 9
        for k0 in np.where(gueltig & maske)[0]:
            if k0 - letzte > nach:
                vz = 1 if richtung == "auf" else -1; k = int(k0)
                for j in range(1, nach + 1):
                    if not np.isnan(lp[k0 + j]) and vz * (lp[k0 + j] - lp[k0]) >= 0.5 * sig[k0]:
                        k = int(k0) + j - 1
                        break
                if k + nach < n and not np.isnan(sig[k]):
                    aus.append((k, int(k0), richtung, float(zs[k0])))
            letzte = k0
    return aus, zs


def ereignisse_kurs(con_main, coin: str, t_von: int, t_bis: int) -> list:
    """Ereignisse (Definition wie in den Ereignis-Profile) mit Beginn in t_von..t_bis -- nur aus Kursen, für die Markierung
    im Verlauf der Treiber. Erst 4 h nach dem Beginn erkennbar (die Bewegung muss stattgefunden haben)."""
    g0 = (t_von - 7 * 86_400) // RASTER * RASTER
    n = (t_bis // RASTER * RASTER - g0) // RASTER + 1
    lp, sig = _profil_sigma(_profil_kurse(con_main, coin, g0, n))
    nach = PROFIL_H * 3600 // RASTER
    a = max((t_von - g0) // RASTER - nach, 7 * 96)
    b = min(n - nach, (t_bis - PROFIL_H * 3600 - g0) // RASTER + 1)
    if b <= a:
        return []
    eig, _ = _profil_ereignisse(lp, sig, a, b)
    return sorted(({"ts": int(g0 + k * RASTER), "dir": r, "z": round(z, 2)} for k, k0, r, z in eig if g0 + k * RASTER >= t_von),
                  key=lambda e: e["ts"])


def _profil_raster(con_main, st, coin: str, t_von: int, t_bis: int, cb_ab):
    """15-min-Raster eines Coins: Schlusskurs am Rasterpunkt, Treiberwerte (jüngster Wert bis zum Rasterpunkt)."""
    import numpy as np
    g0 = (t_von - 7 * 86_400) // RASTER * RASTER                  # 7 Tage Vorlauf für die Schwankung
    n = (t_bis // RASTER * RASTER - g0) // RASTER + 1
    P = _profil_kurse(con_main, coin, g0, n)
    zeilen = st.execute("SELECT ts, name, score FROM forecast_drivers WHERE coin=? AND ts>? AND ts<=? ORDER BY ts",
                        (coin, t_von - RASTER, g0 + (n - 1) * RASTER)).fetchall()
    namen = sorted({z[1] for z in zeilen})
    j_ = {nm: j for j, nm in enumerate(namen)}
    S = np.full((n, len(namen)), np.nan)
    for ts, nm, sc in zeilen:
        if sc is None or (nm == F.CB_TREIBER and cb_ab and ts < cb_ab):
            continue                                                # U41: vor der Seiten-Umstellung vertauscht
        k = -(-ts // RASTER) - g0 // RASTER                         # nächster Rasterpunkt: der Wert lag dort schon vor
        if 0 <= k < n:
            S[k, j_[nm]] = sc
    for k in range(1, n):                                           # Lücken bis 30 min mit dem letzten Wert füllen
        leer = np.isnan(S[k])
        if leer.any():
            S[k, leer] = S[k - 1, leer]
    return g0, P, S, namen


def ereignis_profile(con_main, path: str = F.STORE, now: int | None = None, coins: list | None = None, tage: int = TAGE,
                     r_null: int = PROFIL_NULL_R, seed: int = 11) -> dict:
    """
    U43, Stufe 1 des Fingerabdrucks. EREIGNIS: Rendite der nächsten PROFIL_H Stunden von mindestens PROFIL_K
    Standardabweichungen (4-h-Schwankung aus den 7 Tagen davor), je Coin. Aufeinanderfolgende Startpunkte derselben
    Richtung (Abstand <= 4 h) sind ein Ereignis. BEGINN: im ersten solchen Fenster der letzte Rasterpunkt, bevor sich der
    Kurs um 0,5 σ in Ereignisrichtung bewegt hat -- alles bis zum Beginn liegt vor der Bewegung. Gleichgerichtete Ereignisse mehrerer Coins binnen 2 h sind EIN Fall (die Coins sind korreliert).
    PROFIL: je Treiber und Vorlauf (12 h bis 0 h vor Beginn) die mittlere Abweichung vom Normalwert desselben Coins in
    Zeiten gleicher Schwankung (Terzile; ohne die Fenster um Ereignisse), gemittelt über die Fälle; z = Mittel / SE.
    SCHWELLE: 95-%-Quantil des größten |z| aus r_null Läufen mit zufällig verschobenen Ereigniszeiten (je Coin
    zirkulär) -- schützt vor Zufallsfunden über alle Treiber x Vorläufe (Familienfehler 5 %) und vor Autokorrelation.
    """
    import numpy as np
    import warnings
    now = now or int(time.time())
    t_von = now - tage * 86_400
    st = F.store_connect(path)
    try:
        if coins is None:
            coins = [r[0] for r in st.execute("SELECT DISTINCT coin FROM forecast_drivers WHERE ts > ?", (t_von,))]
        cb_ab = F.cb_seite_ab(con_main)
        raster = {}
        for c in sorted(coins):
            try:
                raster[c] = _profil_raster(con_main, st, c, t_von, now, cb_ab)
            except sqlite3.Error:
                continue
    finally:
        st.close()
    namen = sorted({nm for g0, P, S, nms in raster.values() for nm in nms})
    jn = {nm: j for j, nm in enumerate(namen)}
    lags = [h * 3600 // RASTER for h in PROFIL_LAGS_H]
    vor, nach = -min(lags), PROFIL_H * 3600 // RASTER
    ereignisse, info = [], {}
    for c, (g0, P, S, nms) in raster.items():
        n = len(P); w = 7 * 96
        lp, sig = _profil_sigma(P)
        erste = np.where(~np.all(np.isnan(S), axis=1))[0]
        if not len(erste):
            continue
        a = max(int(erste[0]) + vor, w)                             # Beginn frühestens 12 h nach dem ersten Treiberwert
        b = min(n - nach, (now - PROFIL_H * 3600 - g0) // RASTER + 1)
        if b - a < 96 * 2:
            continue
        eig, zs = _profil_ereignisse(lp, sig, a, b)
        gueltig = np.zeros(n, bool); gueltig[a:b] = ~np.isnan(zs[a:b])
        terz = np.full(n, -1); e_ = min(n, b + nach)                 # Terzile auch für geschärfte Beginnpunkte hinter b
        q1, q2 = np.nanpercentile(sig[a:b], [100 / 3, 200 / 3])
        with np.errstate(invalid="ignore"):
            terz[a:e_] = np.where(sig[a:e_] <= q1, 0, np.where(sig[a:e_] <= q2, 1, 2))
        frei = gueltig.copy()
        for k, k0, richtung, z0 in eig:
            frei[max(0, k - vor):k + nach + 1] = False
            ereignisse.append({"coin": c, "k": int(k), "ts": int(g0 + k * RASTER), "dir": richtung, "z": z0, "terz": int(terz[k])})
        B = np.full((3, len(namen)), np.nan)
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore", category=RuntimeWarning)
            for t_ in range(3):
                zeilen_ = frei & (terz == t_)
                if zeilen_.any():
                    B[t_, [jn[x] for x in nms]] = np.nanmean(S[zeilen_], axis=0)
        info[c] = {"g0": g0, "P": P, "S": S, "cols": [jn[x] for x in nms], "B": B, "sig": sig, "terz": terz, "a": a, "b": b, "lp": lp}

    def einheiten(ev: list) -> list:
        ev = sorted(ev, key=lambda e: e["ts"]); gruppen = []
        for e in ev:
            if gruppen and e["ts"] - gruppen[-1][0]["ts"] <= PROFIL_CLUSTER_S:
                gruppen[-1].append(e)
            else:
                gruppen.append([e])
        return gruppen

    def matrix(gruppen: list, ks: list | None = None):
        """Abweichungen je Fall (Mittel über seine Coins): Fälle x Vorläufe x Treiber; ks = verschobene Beginnpunkte."""
        M = np.full((len(gruppen), len(lags), len(namen)), np.nan); preis = np.full((len(gruppen), len(lags) + 1), np.nan)
        i_e = 0
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore", category=RuntimeWarning)
            for u, grp in enumerate(gruppen):
                zeilen_, pz = [], []
                for e in grp:
                    d = info[e["coin"]]; k = ks[i_e] if ks is not None else e["k"]; i_e += 1
                    t_ = d["terz"][k] if ks is not None else e["terz"]
                    z_ = np.full((len(lags), len(namen)), np.nan)
                    z_[:, d["cols"]] = d["S"][[k + L for L in lags]] - d["B"][max(t_, 0)][d["cols"]]
                    zeilen_.append(z_)
                    s_ = d["sig"][k]
                    pz.append([(d["lp"][k + L] - d["lp"][k - vor]) / s_ for L in lags] + [(d["lp"][k + nach] - d["lp"][k]) / s_])
                M[u] = np.nanmean(np.stack(zeilen_), axis=0); preis[u] = np.nanmean(np.array(pz), axis=0)
        return M, preis

    def zwerte(M):
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore", category=RuntimeWarning)
            cnt = np.sum(~np.isnan(M), axis=0); mu = np.nanmean(M, axis=0); sd = np.nanstd(M, axis=0, ddof=1)
            z = np.where(cnt >= 3, mu / (sd / np.sqrt(np.maximum(cnt, 1))), np.nan)
        return mu, z, cnt

    rng = np.random.default_rng(seed)
    aus = {"ts": now, "k": PROFIL_K, "h": PROFIL_H, "lags_h": list(PROFIL_LAGS_H), "coins": sorted(info), "treiber": namen,
           "seit": min((int(d["g0"] + d["a"] * RASTER - vor * RASTER) for d in info.values()), default=None), "richtungen": {}}
    for richtung in ("ab", "auf"):
        ev = [e for e in ereignisse if e["dir"] == richtung]
        gruppen = einheiten(ev)
        blk = {"n_ereignisse": len(ev), "n_faelle": len(gruppen),
               "faelle": [{"ts": g[0]["ts"], "coins": [e["coin"] for e in g], "z": round(float(np.mean([e["z"] for e in g])), 2)} for g in gruppen]}
        if len(gruppen) >= 3:
            M, preis = matrix(gruppen)
            mu, z, cnt = zwerte(M)
            maxima = []
            flach = [e for g in gruppen for e in g]
            for _ in range(r_null):
                ks = []
                for e in flach:
                    d = info[e["coin"]]; m_ = d["b"] - d["a"]
                    s_ = int(rng.integers(min(96, m_ // 4), max(m_ - min(96, m_ // 4), min(96, m_ // 4) + 1)))
                    ks.append(d["a"] + (e["k"] - d["a"] + s_) % m_)
                _, z0, _ = zwerte(matrix(gruppen, ks)[0])
                maxima.append(float(np.nanmax(np.abs(z0))) if np.any(~np.isnan(z0)) else 0.0)
            schwelle = float(np.quantile(maxima, 0.95))
            zeilen = []
            for j, nm in enumerate(namen):
                if not np.any(cnt[:, j] >= 3):
                    continue
                zz = z[:, j]; sig_ = [bool(abs(x) >= schwelle) if not np.isnan(x) else False for x in zz]
                vorlauf = None                                      # zusammenhängender Abschnitt, der dem Beginn am nächsten liegt
                treffer_ = [i for i, s_ in enumerate(sig_) if s_]
                if treffer_:
                    i_end = treffer_[-1]; vz = np.sign(mu[i_end, j]); i = i_end
                    while i > 0 and sig_[i - 1] and np.sign(mu[i - 1, j]) == vz:
                        i -= 1
                    vorlauf = [PROFIL_LAGS_H[i], PROFIL_LAGS_H[i_end]]
                zeilen.append({"treiber": nm, "abw": [None if np.isnan(x) else round(float(x), 3) for x in mu[:, j]],
                               "z": [None if np.isnan(x) else round(float(x), 2) for x in zz], "sig": sig_,
                               "n": int(np.max(cnt[:, j])), "vorlauf_h": vorlauf,
                               "max_z": float(np.nanmax(np.abs(zz))) if np.any(~np.isnan(zz)) else 0.0})
            zeilen.sort(key=lambda x: -x["max_z"])
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=RuntimeWarning)
                blk.update(schwelle=round(schwelle, 2), treiber=zeilen,
                           kurs=[None if np.isnan(x) else round(float(x), 2) for x in np.nanmean(preis, axis=0)])
        aus["richtungen"][richtung] = blk
    return aus


def profil_text(e: dict) -> str:
    """Tabelle für den Debug-Eintrag (U43)."""
    L = e.get("lags_h") or list(PROFIL_LAGS_H)
    z = [f"Ereignis-Profile (U43, Fingerabdruck Stufe 1) · Ereignis = Rendite der nächsten {e.get('h')} h von mindestens {e.get('k')} σ "
         f"(4-h-Schwankung der 7 Tage davor), je Coin · gleichgerichtete Ereignisse mehrerer Coins binnen 2 h = ein Fall",
         f"Coins: {', '.join(e.get('coins') or [])} · Treiberwerte seit "
         f"{time.strftime('%d.%m.%Y %H:%M', time.localtime(e['seit'])) if e.get('seit') else '—'} (forecast_drivers, alle 15 min)",
         "Wert = mittlere Abweichung vom Normalwert desselben Coins in Zeiten gleicher Schwankung (Score-Punkte), * = über der Schwelle.",
         "Schwelle = 95 % des größten |z| bei zufällig verschobenen Ereigniszeiten (schützt vor Zufallsfunden über alle Treiber und Vorläufe).",
         "Vorlauf = zusammenhängender Abschnitt über der Schwelle, der dem Beginn am nächsten liegt. Beginn = letzter Rasterpunkt, bevor",
         "sich der Kurs um 0,5 σ bewegt hat -- alles bis 0 h liegt VOR der Bewegung.", ""]
    for richtung, titel in (("ab", "RUTSCHE"), ("auf", "ANSTIEGE")):
        b = (e.get("richtungen") or {}).get(richtung) or {}
        z.append(f"{titel}: {b.get('n_ereignisse', 0)} Ereignisse → {b.get('n_faelle', 0)} Fälle" +
                 (f" · Schwelle |z| ≥ {b['schwelle']}" if b.get("schwelle") is not None else " · zu wenige Fälle für ein Profil (mindestens 3)"))
        for f_ in (b.get("faelle") or [])[-12:]:
            z.append(f"  {time.strftime('%d.%m. %H:%M', time.localtime(f_['ts']))}  {'/'.join(f_['coins']):<22} {f_['z']:+.1f} σ")
        if len(b.get("faelle") or []) > 12:
            z.append(f"  … und {len(b['faelle']) - 12} frühere")
        if b.get("treiber"):
            kopf = "".join(f"{('%+dh' % h) if h else '0h':>8}" for h in L)
            z.append(f"  {'':<30}{kopf}   Vorlauf")
            k_ = b.get("kurs") or []
            z.append(f"  {'Kurs seit −12 h (σ)':<30}" + "".join(f"{(('%+.2f' % x) if x is not None else '—'):>8}" for x in k_[:len(L)])
                     + (f"   danach {k_[-1]:+.2f} σ" if k_ and k_[-1] is not None else ""))
            for t in b["treiber"]:
                zellen = "".join(f"{(('%+.2f' % a) + ('*' if s else ' ')) if a is not None else '—':>8}" for a, s in zip(t["abw"], t["sig"]))
                v_ = t["vorlauf_h"]
                vl = "—" if not v_ else (f"{v_[0]:+d} h bis {v_[1]:+d} h" if v_[0] != v_[1] else f"bei {v_[0]:+d} h").replace("+0 h", "0 h")
                z.append(f"  {t['treiber'][:29]:<30}{zellen}   {vl} (max |z| {t['max_z']:.1f}, n {t['n']})")
        z.append("")
    z.append("Lesart: Ein Vorläufer weicht VOR dem Beginn ab und liegt über der Schwelle. Mit wenigen Fällen ist die Schwelle hoch --"
             " dass nichts markiert ist, heißt dann nur: noch nicht belegbar.")
    return "\n".join(z)


def _profil_probe(seed: int = 3) -> dict:
    """
    Selbsttest U43 (fester Zeitpunkt PROBE_NOW, fester Seed): 3 Coins, 40 Tage, eingebaute Sprünge (4-h-Trend von 4 σ)
    und ein eingebauter Vorläufer (+0,6 in den 3 h vor Anstiegen, -0,6 vor Rutschen) neben drei reinen Rauschtreibern.
    Soll: Vorläufer in beiden Richtungen markiert, mit richtigem Vorzeichen; kein Rauschtreiber markiert.
    """
    import os as _os, tempfile as _tf
    import numpy as np
    rng = np.random.default_rng(seed); now = PROBE_NOW; tage = 40
    tmp = _tf.mkdtemp(); con = sqlite3.connect(_os.path.join(tmp, "m.db"))
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    pfad = _os.path.join(tmp, "f.db"); st = F.store_connect(pfad)
    g_start = (now - tage * 86_400) // RASTER * RASTER; n = tage * 96
    for c in ("AAA", "BBB", "CCC"):
        drift = np.zeros(n); vorl = np.zeros(n); k = 7 * 96 + 60
        while k < n - 40:
            d = rng.choice((-1, 1)); drift[k:k + 16] += d * 4 * 0.008 / 16; vorl[k - 12:k] = 0.6 * d   # 4 σ(4 h) über 16 Schritte
            k += int(rng.integers(100, 200))
        lp = np.cumsum(rng.normal(0, 0.002, n) + drift) + math.log(100)
        rows = []; drv = []
        rausch = [np.clip(rng.normal(0, 0.3, n), -1, 1) for _ in range(3)]
        for i in range(n):
            g = g_start + i * RASTER; px = math.exp(lp[i])
            rows.append((g - 60, c, px, px, px, px, 1, 1))
            if i >= 7 * 96:
                t_f = g - 840                                          # Prognose kurz nach dem vorigen Rasterpunkt
                drv += [(t_f, c, "Vorläufer", float(np.clip(rausch[0][i] * 0.5 + vorl[i], -1, 1)))]
                drv += [(t_f, c, f"Rauschen {q}", float(rausch[q][i])) for q in (1, 2)]
        con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
        st.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)", drv)
    con.commit(); st.commit(); st.close()
    e = ereignis_profile(con, path=pfad, now=now, coins=["AAA", "BBB", "CCC"], tage=tage - 7, r_null=100)
    con.close()
    try:
        for f_ in _os.listdir(tmp):
            _os.remove(_os.path.join(tmp, f_))
        _os.rmdir(tmp)
    except OSError:
        pass
    ok = True; txt = []; fehl_ges = 0
    for richtung, vz in (("auf", 1), ("ab", -1)):
        b = e["richtungen"].get(richtung) or {}
        tr = {t["treiber"]: t for t in b.get("treiber") or []}
        v = tr.get("Vorläufer") or {}
        treffer = any(s and a is not None and a * vz > 0 for a, s in zip(v.get("abw") or [], v.get("sig") or []))
        falsch = [t for t in tr.values() if t["treiber"] != "Vorläufer" and any(t["sig"])]
        fehl_ges += len(falsch)
        ok = ok and treffer and b.get("n_faelle", 0) >= 20
        txt.append(f"{'Anstiege' if richtung == 'auf' else 'Rutsche'}: {b.get('n_faelle', 0)} Fälle, Schwelle {b.get('schwelle')}, "
                   f"Vorläufer {'erkannt' if treffer else 'NICHT erkannt'} (Vorlauf {v.get('vorlauf_h')} h), Rauschtreiber markiert: {len(falsch)}")
    # Familienfehler 5 % je Richtung: ein Zufallsfund in beiden Richtungen zusammen ist erlaubt (~10 %), zwei nicht (~0,3 %)
    ok = ok and fehl_ges <= 1
    return {"ok": ok, "text": " · ".join(txt) + f" · Zufallsfunde gesamt {fehl_ges} (Soll ≤ 1)"}


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--profile" in sys.argv:                                     # U43: Debug-Eintrag "Ereignis-Profile"
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else "hl_liq.db"
        _con = sqlite3.connect(f"file:{_db}?mode=ro", uri=True)
        print(profil_text(ereignis_profile(_con)))
        _con.close()
        sys.exit(0)
    print(__doc__)
