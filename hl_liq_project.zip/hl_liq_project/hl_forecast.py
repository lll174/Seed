#!/usr/bin/env python3
"""
AI-Prognose: kalkulierte Kursprognose aus allen gesammelten Daten.

Kein Orakel. Ein transparentes Modell mit vier Teilen:
  1. Regime und Drift      -- MA 200 Tage / MA 50 Wochen, 60-min-Trend, RSI, 7-Tage-Drift
  2. Richtungsdruck S      -- direktionale Wale, direktionales Smart Money, Käufe/Verkäufe
                              direktionaler Leaderboard-Konten (24 h), Taker-Flow, Funding, ETF
  3. Magneten und Wände    -- Liquidationscluster ziehen, Limit-Wände halten, Kaskadenmodell
  4. Pfad und Band         -- Stunde für Stunde bis 7 Tage, Unsicherheitsband aus der
                              realisierten Volatilität (sigma * sqrt(t))
Daraus: optimaler Kaufpreis (4-12 h) und optimaler Verkaufspreis für offene Positionen,
jeweils mit Fenster und Begründung. Jede Prognose wird gespeichert; nach 24 h wird die
Richtung gegen den echten Kurs geprüft -- die Trefferquote steht im Chart.

Nur direktionale Konten zählen: Hedges und Market Maker haben keine Meinung.
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import time

HORIZON_H = 7 * 24
def _default_store() -> str:
    """
    Ablage der Prognosen: neben der Hauptdatenbank, damit die SD-Karte des Pi geschont wird.
    Reihenfolge: HL_FORECAST_DB (Umgebung) -> Ordner der Hauptdatenbank (HL_DB oder --db der
    systemd-Einheit) -> Projektordner. Der Ordner muss beschreibbar sein, sonst der nächste.
    """
    import re
    cand = []
    env = os.environ.get("HL_FORECAST_DB")
    if env:
        cand.append(env)
    main = os.environ.get("HL_DB")
    if not main:
        try:
            with open("/etc/systemd/system/hl-recorder.service") as f:
                m = re.search(r"--db\s+(\S+)", f.read())
            main = m.group(1) if m else None
        except OSError:
            main = None
    if main:
        cand.append(os.path.join(os.path.dirname(os.path.abspath(main)), "forecasts.db"))
    here = os.path.dirname(os.path.abspath(__file__))
    cand.append(os.path.join(here, "forecasts.db"))
    for path in cand:
        d = os.path.dirname(path) or "."
        if os.path.isdir(d) and os.access(d, os.W_OK):
            return path
    return cand[-1]


STORE = _default_store()


# ---------------------------------------------------------------------------
# Speicher für Prognosen (eigene kleine Datenbank des Dashboards)
# ---------------------------------------------------------------------------

def store_connect(path: str = STORE) -> sqlite3.Connection:
    con = sqlite3.connect(path, timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA temp_store=MEMORY")      # Sortierpuffer im RAM, nicht auf der SD-Karte
    con.execute("PRAGMA synchronous=NORMAL")     # im WAL-Modus sicher, spart Schreibvorgänge
    con.execute("""CREATE TABLE IF NOT EXISTS forecast (
        ts INTEGER, coin TEXT, price REAL, bias REAL, confidence REAL,
        p_4h REAL, p_12h REAL, p_24h REAL, p_72h REAL, p_168h REAL,
        buy_px REAL, sell_px REAL, payload TEXT,
        PRIMARY KEY (ts, coin))""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_fc_coin_ts ON forecast(coin, ts)")
    cols = {r[1] for r in con.execute("PRAGMA table_info(forecast)")}
    for col in ("model_p24", "analog_p24", "wver"):
        if col not in cols:
            con.execute(f"ALTER TABLE forecast ADD COLUMN {col} REAL")
    con.execute("""CREATE TABLE IF NOT EXISTS weights (
        coin TEXT, name TEXT, prior REAL, weight REAL, n INTEGER, hit_rate REAL, updated INTEGER,
        PRIMARY KEY (coin, name))""")
    con.execute("""CREATE TABLE IF NOT EXISTS learned (
        coin TEXT, key TEXT, value TEXT, updated INTEGER, PRIMARY KEY (coin, key))""")
    return con


def store_forecast(fc: dict, path: str = STORE) -> None:
    try:
        con = store_connect(path)
        path_map = {p["h"]: p["px"] for p in fc["path"]}
        con.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, confidence, p_4h, p_12h, p_24h, p_72h, p_168h, buy_px, sell_px, payload, model_p24, analog_p24, wver) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (fc["ts"], fc["coin"], fc["price"], fc["bias"], fc["confidence"],
                     path_map.get(4), path_map.get(12), path_map.get(24), path_map.get(72), path_map.get(168),
                     (fc.get("buy") or {}).get("px"), (fc.get("sell") or {}).get("px"),
                     json.dumps({k: v for k, v in fc.items() if k not in ("path", "band", "history", "analog_paths")}),
                     (fc.get("ensemble") or {}).get("model_p24"), (fc.get("ensemble") or {}).get("analog_p24"), fc.get("wver")))
        con.execute("DELETE FROM forecast WHERE ts < ?", (int(time.time()) - 60 * 86_400,))
        con.commit(); con.close()
    except sqlite3.Error:
        pass


def score_forecasts(con_main, coin: str, path: str = STORE, wver: float | None = None) -> dict:
    """
    Trefferquote: vorhergesagte Richtung nach 4 h und 24 h gegen den echten Kurs, dazu der mittlere
    absolute Fehler nach 24 h -- getrennt für Ensemble, reines Modell und Analog-Pfad, und
    out-of-sample: nur Prognosen, die mit der aktuellen Gewichtsversion entstanden sind.
    """
    out = {"n": 0, "hits": 0, "hit_rate": None, "mae_pct": None, "n_4h": 0, "hits_4h": 0,
           "model": {"n": 0, "hits": 0}, "analog": {"n": 0, "hits": 0}, "oos": {"n": 0, "hits": 0}}
    try:
        st = store_connect(path)
        rows = st.execute("SELECT ts, price, p_4h, p_24h, model_p24, analog_p24, wver FROM forecast WHERE coin=? AND ts<=? ORDER BY ts",
                          (coin, int(time.time()) - 4 * 3600)).fetchall()
        st.close()
    except sqlite3.Error:
        return out
    if not rows:
        return out
    errs = []
    cache: dict = {}
    def real_at(t):
        if t not in cache:
            r = con_main.execute("SELECT close FROM bars WHERE coin=? AND ts<=? ORDER BY ts DESC LIMIT 1", (coin, t)).fetchone()
            cache[t] = r[0] if r and r[0] else None
        return cache[t]
    def hit(p0, pred, real):
        return (pred - p0) * (real - p0) > 0 or (abs(pred / p0 - 1) < 0.002 and abs(real / p0 - 1) < 0.002)
    for ts, p0, p4, p24, mp, ap, wv in rows:
        if not p0:
            continue
        if p4 is not None and ts + 4 * 3600 <= time.time():
            real = real_at(ts + 4 * 3600)
            if real:
                out["n_4h"] += 1; out["hits_4h"] += 1 if hit(p0, p4, real) else 0
        if p24 is not None and ts + 24 * 3600 <= time.time():
            real = real_at(ts + 24 * 3600)
            if real:
                h = hit(p0, p24, real); out["n"] += 1; out["hits"] += 1 if h else 0; errs.append(abs(p24 / real - 1) * 100)
                if mp:
                    out["model"]["n"] += 1; out["model"]["hits"] += 1 if hit(p0, mp, real) else 0
                if ap:
                    out["analog"]["n"] += 1; out["analog"]["hits"] += 1 if hit(p0, ap, real) else 0
                if wver is not None and wv is not None and abs(wv - wver) < 1:
                    out["oos"]["n"] += 1; out["oos"]["hits"] += 1 if h else 0
    for k in ("model", "analog", "oos"):
        out[k]["hit_rate"] = out[k]["hits"] / out[k]["n"] if out[k]["n"] else None
    if out["n"]:
        out["hit_rate"] = out["hits"] / out["n"]
    if out["n_4h"]:
        out["hit_rate_4h"] = out["hits_4h"] / out["n_4h"]
    if errs:
        out["mae_pct"] = sum(errs) / len(errs)
    return out


# ---------------------------------------------------------------------------
# Selbstkalibrierung: Treibergewichte aus der eigenen Trefferbilanz lernen
# ---------------------------------------------------------------------------

PRIORS = {"MA 200 Tage": 0.8, "MA 50 Wochen": 0.6, "60-min-Trend": 0.5, "RSI 14 (1 h)": 0.5, "7-Tage-Drift": 0.4,
          "Direktionale Wale": 1.2, "Smart Money (direktional)": 1.0, "Käufe/Verkäufe 24 h (direktional)": 1.0,
          "Top-20-Trend 24 h": 0.6, "Taker-Flow": 0.7, "Funding": 0.4, "ETF-Flows": 0.6, "Orderbuch": 0.4,
          "Kapitulation": 0.5, "Analog-Suche": 0.8, "Wal-Flow 30 min": 1.3, "Leaderboard-Flow 60 min": 1.0,
          # Jede Wal-Gruppe als eigener Treiber. Startgewichte nach Erwartung: direktionale Konten
          # handeln mit Meinung, Market Maker stellen Liquidität, Hedges sichern ab. Ob die Erwartung
          # stimmt, misst die Selbstkalibrierung -- deshalb bekommen auch die "unwahrscheinlichen"
          # Gruppen ein Gewicht > 0 statt ausgeschlossen zu werden.
          "Wal-Flow Hedge": 0.4, "Wal-Flow Market Maker": 0.4, "Wal-Flow gemischt": 0.6}


MAX_TRAIN = 2000          # höchstens so viele Fenster ins Training (Laufzeit auf dem Pi, ~7 s)
HALF_LIFE_DAYS = 14.0     # ältere Prognosen zählen weniger: der Markt wechselt das Regime


def calibrate_weights(con_main, coin: str, path: str = STORE, min_n: int = 40) -> dict:
    """
    Lernt je Treiber ein Gewicht aus den gespeicherten Prognosen: Logit der 24-h-Richtung auf die
    Treiberwerte, per Gradientenabstieg, mit L2-Zug zum Prior. Wenig Daten -> Prior gewinnt;
    viel Evidenz -> die Daten gewinnen. Gewichte bleiben in [0, 2 x Prior]: ein Treiber wird nie
    umgedreht (das wäre Überanpassung), nur auf- oder abgewertet.

    Zwei Begrenzungen, damit das Lernen nicht mit der Zeit teuer und träge wird:
    höchstens MAX_TRAIN Fenster (die jüngsten) und ein Alters-Gewicht mit 14 Tagen Halbwertszeit --
    eine Prognose von gestern zählt doppelt so viel wie eine von vor zwei Wochen. So bleibt die
    Laufzeit konstant und das Modell folgt einem Regimewechsel, statt ihn auszumitteln.
    Liefert {name: {prior, weight, n, hit_rate}}.
    """
    out = {name: {"prior": w, "weight": w, "n": 0, "hit_rate": None} for name, w in PRIORS.items()}
    try:
        st = store_connect(path)
        rows = st.execute("SELECT ts, price, payload FROM forecast WHERE coin=? AND ts<=? ORDER BY ts", (coin, int(time.time()) - 24 * 3600)).fetchall()
        st.close()
    except sqlite3.Error:
        return out
    X, y, sw = [], [], []
    names = list(PRIORS)
    seen_win: set = set()
    now_ = time.time()
    # Rückwärts lesen und aufhören, sobald MAX_TRAIN Fenster beisammen sind: die teure
    # Kursabfrage je Zeile läuft sonst über die ganze Historie (bei 8.000 Prognosen 30 s auf dem Pi).
    for ts, p0, payload in reversed(rows):
        if len(y) >= MAX_TRAIN:
            break
        win = ts // 900                                             # eine Prognose je 15-min-Fenster
        if win in seen_win:
            continue
        seen_win.add(win)
        try:
            pl = json.loads(payload)
        except (TypeError, ValueError):
            continue
        r = con_main.execute("SELECT close FROM bars WHERE coin=? AND ts<=? ORDER BY ts DESC LIMIT 1", (coin, ts + 24 * 3600)).fetchone()
        if not r or not r[0] or not p0:
            continue
        label = 1.0 if r[0] > p0 else -1.0
        vec = {d["name"]: d["score"] for d in pl.get("drivers", [])}
        X.append([vec.get(n, 0.0) for n in names]); y.append(label)
        sw.append(0.5 ** ((now_ - ts) / (HALF_LIFE_DAYS * 86_400)))     # Alters-Gewicht
    X.reverse(); y.reverse(); sw.reverse()
    n = len(y)
    # Trefferquote je Treiber (Vorzeichen), unabhängig vom Logit
    for j, name in enumerate(names):
        pairs = [(x[j], yy, s_) for x, yy, s_ in zip(X, y, sw) if abs(x[j]) > 0.1]
        out[name]["n"] = len(pairs)
        if pairs:
            tot = sum(s_ for _, _, s_ in pairs) or 1.0
            out[name]["hit_rate"] = sum(s_ for sc, yy, s_ in pairs if sc * yy > 0) / tot
    if n < min_n:
        return out
    # Logit: P(up) = sigmoid(sum w_j x_j); Verlust + lambda * sum (w_j - prior_j)^2; lambda schrumpft mit n
    # Nur Treiber trainieren, die überhaupt vorkommen -- spart Rechenzeit und verhindert Drift
    active = [j for j in range(len(names)) if any(abs(x[j]) > 1e-9 for x in X)]
    Xa = [[x[j] for j in active] for x in X]
    wsum_ = sum(sw) or 1.0
    w = [PRIORS[nm] for nm in names]; lam = 4.0 / max(n, 1); lr = 0.05
    wa = [w[j] for j in active]; pa = [PRIORS[names[j]] for j in active]
    for _ in range(300):
        grad = [0.0] * len(active)
        for x, yy, s_ in zip(Xa, y, sw):
            z = sum(wj * xj for wj, xj in zip(wa, x))
            pz = 1 / (1 + math.exp(-_clip(z, -30, 30)))
            err = (pz - (1.0 if yy > 0 else 0.0)) * s_
            for j in range(len(active)):
                grad[j] += err * x[j] / wsum_
        step = 0.0
        for j in range(len(active)):
            grad[j] += 2 * lam * (wa[j] - pa[j])
            new = _clip(wa[j] - lr * grad[j], 0.0, 2 * pa[j])
            step = max(step, abs(new - wa[j])); wa[j] = new
        if step < 1e-4:                                   # ausgelernt, weitere Runden bringen nichts
            break
    for k, j in enumerate(active):
        w[j] = wa[k]
    for j, nm in enumerate(names):
        out[nm]["weight"] = round(w[j], 3)
    return out


def learned_weights_save(coin: str, weights: dict, path: str = STORE, bump: bool = True) -> None:
    """
    Gewichte sichern. `bump=False` behält den Zeitstempel der bisherigen Version bei:
    Die Version markiert die letzte NENNENSWERTE Änderung, nicht jede kleine Verschiebung.
    Sonst sprang sie alle 15 Minuten, und die Out-of-sample-Quote -- die Prognosen misst,
    die mit der aktuellen Version entstanden und 24 h alt sind -- blieb für immer leer.
    """
    try:
        st = store_connect(path); now = int(time.time())
        alt = 0
        if not bump:
            r = st.execute("SELECT MAX(updated) FROM weights WHERE coin=?", (coin,)).fetchone()
            alt = int(r[0]) if r and r[0] else 0
        stamp = now if bump or not alt else alt
        st.executemany("INSERT OR REPLACE INTO weights VALUES (?,?,?,?,?,?,?)",
                       [(coin, nm, v["prior"], v["weight"], v["n"], v["hit_rate"], stamp) for nm, v in weights.items()])
        st.commit(); st.close()
    except sqlite3.Error:
        pass


def learned_weights_load(coin: str, path: str = STORE) -> tuple[dict, float | None]:
    """Gelernte Gewichte und ihre Version (Zeitpunkt der letzten Kalibrierung)."""
    try:
        st = store_connect(path)
        rows = st.execute("SELECT name, prior, weight, n, hit_rate, updated FROM weights WHERE coin=?", (coin,)).fetchall()
        st.close()
    except sqlite3.Error:
        return {}, None
    if not rows:
        return {}, None
    return {r[0]: {"prior": r[1], "weight": r[2], "n": r[3], "hit_rate": r[4]} for r in rows}, float(rows[0][5])


def learned_save(coin: str, key: str, value, path: str = STORE) -> None:
    try:
        st = store_connect(path)
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, key, json.dumps(value), int(time.time()))); st.commit(); st.close()
    except sqlite3.Error:
        pass


def _intkeys(d):
    """JSON macht aus Zahlen-Schlüsseln Text (24 -> "24"); hier zurück, wo es Horizonte sind."""
    if isinstance(d, dict) and d and all(isinstance(k, str) and k.lstrip("-").isdigit() for k in d):
        return {int(k): v for k, v in d.items()}
    return d


def learned_load(coin: str, key: str, max_age: int, path: str = STORE):
    try:
        st = store_connect(path)
        r = st.execute("SELECT value, updated FROM learned WHERE coin=? AND key=?", (coin, key)).fetchone(); st.close()
    except sqlite3.Error:
        return None
    if not r or time.time() - r[1] > max_age:
        return None
    try:
        val = json.loads(r[0])
    except ValueError:
        return None
    if key == "analog" and isinstance(val, dict) and isinstance(val.get("ret"), dict):
        val["ret"] = _intkeys(val["ret"])
    return val


# ---------------------------------------------------------------------------
# Hilfen
# ---------------------------------------------------------------------------

def _clip(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def _num(x, key: str | None = None):
    """Zahl aus Wert oder Datensatz: funding kommt aus Hyperliquid als {ts, funding, oi}, von Binance als Zahl."""
    if isinstance(x, dict):
        x = x.get(key) if key else None
    try:
        return float(x) if x is not None else None
    except (TypeError, ValueError):
        return None


def realized_vol(candles: list[dict]) -> float:
    """Stunden-Volatilität (Standardabweichung der Log-Renditen der Stundenkerzen)."""
    rets = []
    for a, b in zip(candles[:-1], candles[1:]):
        if a["c"] and b["c"]:
            rets.append(math.log(b["c"] / a["c"]))
    if len(rets) < 12:
        return 0.006                                     # Rückfall: 0,6 % je Stunde
    m = sum(rets) / len(rets)
    var = sum((r - m) ** 2 for r in rets) / max(1, len(rets) - 1)
    return _clip(math.sqrt(var), 0.002, 0.03)


def lb_groups(con, coin: str | None = None) -> dict:
    """
    Verhaltensklasse der Leaderboard-Konten -- wie bei den Walen JE COIN, wenn einer angegeben ist.

    Ein Konto, das BTC short und ETH long hält, ist kontoweit "gemischt", in BTC aber klar
    positioniert. Für ein coinbezogenes Signal zählt das Verhalten in diesem Coin. Ohne `coin`
    wird kontoweit klassifiziert (für Übersichten). Gruppen: dir, hedge, mixed.
    """
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_positions").fetchone()[0]
        if not last:
            return {}
        per: dict = {}
        for addr, c, side, lev in con.execute("SELECT addr, coin, side, leverage FROM lb_positions WHERE ts=?", (last,)):
            d = per.setdefault(addr, {"coins": set(), "sides": set(), "lev": 0.0})
            d["coins"].add(c); d["sides"].add(side); d["lev"] = max(d["lev"], _num(lev) or 0.0)
    except sqlite3.OperationalError:
        return {}
    out = {}
    for addr, d in per.items():
        if len(d["coins"]) >= 3 and len(d["sides"]) == 1 and d["lev"] <= 10:
            out[addr] = "hedge"                          # viele Coins, eine Seite, wenig Hebel
        elif len(d["sides"]) == 2 and len(d["coins"]) >= 2:
            # kontoweit gemischt -- mit Coin-Bezug zählt es trotzdem als direktional,
            # denn in diesem Coin hält es genau eine Seite
            out[addr] = "dir" if coin and coin in d["coins"] else "mixed"
        else:
            out[addr] = "dir"
    return out


def lb_directional_addrs(con, coin: str | None = None) -> set[str]:
    """Leaderboard-Konten, die in diesem Coin direktional sind."""
    return {a for a, g in lb_groups(con, coin).items() if g == "dir"}


# ---------------------------------------------------------------------------
# Analog-Suche: die ähnlichsten Momente der Kurshistorie und was danach geschah
# ---------------------------------------------------------------------------

def _fold_30m(rows) -> list[tuple[int, float]]:
    """Beliebige (ts, close)-Reihe auf 30-Minuten-Schlusskurse falten."""
    out = []; cur = None
    for ts, c in rows:
        b = ts // 1800 * 1800
        if cur is None or cur[0] != b:
            if cur:
                out.append(cur)
            cur = (b, c)
        else:
            cur = (b, c)
    if cur:
        out.append(cur)
    return out


def _series_30m(con, coin: str) -> list[tuple[int, float]]:
    """
    30-min-Schlusskurse bis JETZT: die Historie aus klines30 (bis zu 3 Jahre, von
    hl_timestats einmalig geladen), danach angestückelt aus bnc_bars und den eigenen Bars.

    Ohne das Anstückeln endete die Reihe dort, wo hl_timestats zuletzt lief -- gemessen
    acht Tage in der Vergangenheit. Die Analog-Suche verglich dann den Zustand von vor acht
    Tagen mit der Historie und lieferte Analoge zu einem Markt, den es nicht mehr gibt.
    """
    hist = []
    try:
        hist = [(r[0], r[1]) for r in con.execute("SELECT ts, close FROM klines30 WHERE coin=? ORDER BY ts", (coin,))]
    except sqlite3.OperationalError:
        hist = []
    letzte = hist[-1][0] if hist else 0
    neu = []
    for table in ("bnc_bars", "bars"):
        try:
            rows = con.execute(f"SELECT ts, close FROM {table} WHERE coin=? AND ts>? ORDER BY ts",
                               (coin, letzte)).fetchall()
        except sqlite3.OperationalError:
            continue
        if rows:
            neu = _fold_30m(rows)
            break
    reihe = hist + [r for r in neu if r[0] > letzte]
    if len(reihe) >= 400:
        return reihe
    # keine Historie: aus den eigenen Bars falten
    for table in ("bnc_bars", "bars"):
        try:
            rows = con.execute(f"SELECT ts, close FROM {table} WHERE coin=? ORDER BY ts", (coin,)).fetchall()
        except sqlite3.OperationalError:
            continue
        gefaltet = _fold_30m(rows)
        if len(gefaltet) >= 400:
            return gefaltet
    return reihe


def series_age(con, coin: str) -> tuple[int, int]:
    """(Anzahl Punkte, Alter des letzten Punktes in Sekunden) -- für die Diagnose."""
    r = _series_30m(con, coin)
    return (len(r), int(time.time() - r[-1][0]) if r else -1)


def _feature_table(closes: list[float], ts_list: list[int]) -> list:
    """
    Zustandsvektoren für alle Indizes in einem Durchgang (Präfixsummen statt Fensterschleifen --
    auf dem Pi zählt das): Renditen 1/7/30 Tage, 3-Tage-Volatilität, RSI 14, Lage zum 7-Tage-Mittel,
    Tageszeit (sin/cos), Wochentag. None, wo der Vorlauf fehlt.
    """
    n = len(closes)
    lg = [math.log(c) if c > 0 else 0.0 for c in closes]
    r = [0.0] + [lg[i] - lg[i - 1] for i in range(1, n)]
    cs = [0.0] * (n + 1); cs2 = [0.0] * (n + 1); cc = [0.0] * (n + 1); gain = [0.0] * (n + 1); loss = [0.0] * (n + 1)
    for i in range(n):
        cs[i + 1] = cs[i] + r[i]; cs2[i + 1] = cs2[i] + r[i] * r[i]; cc[i + 1] = cc[i] + closes[i]
        d = closes[i] - closes[i - 1] if i else 0.0
        gain[i + 1] = gain[i] + (d if d > 0 else 0.0); loss[i + 1] = loss[i] + (-d if d < 0 else 0.0)
    out = [None] * n
    for i in range(1440, n):
        r1d, r7d, r30d = lg[i] - lg[i - 48], lg[i] - lg[i - 336], lg[i] - lg[i - 1440]
        m = (cs[i + 1] - cs[i - 144]) / 145; v = (cs2[i + 1] - cs2[i - 144]) / 145 - m * m
        vol3d = math.sqrt(max(v, 0.0))
        g = gain[i + 1] - gain[i - 13]; l = loss[i + 1] - loss[i - 13]
        rsi = 100.0 if l == 0 else 100 - 100 / (1 + g / l)
        sma7 = (cc[i + 1] - cc[i - 335]) / 336
        hod = (ts_list[i] % 86400) / 86400 * 2 * math.pi; wd = (ts_list[i] // 86400 + 3) % 7      # 0 = Montag
        out[i] = [r1d / 0.03, r7d / 0.08, r30d / 0.15, vol3d / 0.004, (rsi - 50) / 25, math.log(closes[i] / sma7) / 0.05,
                  math.sin(hod) * 0.5, math.cos(hod) * 0.5, (wd - 3) / 3 * 0.5]
    return out


def analog_forecast(con, coin: str, k: int = 50, min_gap: int = 12) -> dict | None:
    """
    Die k ähnlichsten Momente der Historie (Euklid auf standardisierten Merkmalen), mindestens
    min_gap Halbstunden auseinander, die letzten 7 Tage ausgeschlossen (kein Blick in die Zukunft).
    Liefert je Horizont Median und 20/80-Quantile der folgenden Renditen.
    """
    ser = _series_30m(con, coin)
    if len(ser) < 2000:
        return None
    ts_list = [t for t, _ in ser]; closes = [c for _, c in ser]
    n = len(closes); horizons = {4: 8, 12: 24, 24: 48, 72: 144, 168: 336}
    now_i = n - 1
    F = _feature_table(closes, ts_list)
    cur = F[now_i]
    if cur is None:
        return None
    cands = []
    last_ok = now_i - 336 - 336                                     # 7 Tage Zukunft + 7 Tage Abstand
    for i in range(1440, last_ok, 2):
        f = F[i]
        if f is None:
            continue
        d = math.sqrt(sum((a - b) ** 2 for a, b in zip(f, cur)))
        cands.append((d, i))
    cands.sort()
    picked = []
    for d, i in cands:
        if all(abs(i - j) >= min_gap for _, j in picked):
            picked.append((d, i))
        if len(picked) >= k:
            break
    if len(picked) < 15:
        return None
    out = {"n": len(picked), "n_hist": n, "span_days": (ts_list[-1] - ts_list[0]) / 86400,
           "last_age_h": (time.time() - ts_list[-1]) / 3600, "ret": {}, "examples": []}
    for h, steps in horizons.items():
        rets = sorted(math.log(closes[i + steps] / closes[i]) for _, i in picked if i + steps < n)
        if not rets:
            continue
        q = lambda p: rets[min(len(rets) - 1, int(p * len(rets)))]
        out["ret"][h] = {"med": q(0.5), "q20": q(0.2), "q80": q(0.8), "p_up": sum(1 for r in rets if r > 0) / len(rets)}
    out["examples"] = [{"ts": ts_list[i], "dist": round(d, 2), "r24": math.log(closes[min(n - 1, i + 48)] / closes[i])} for d, i in picked[:5]]
    out["mean_dist"] = sum(d for d, _ in picked) / len(picked)
    return out


# ---------------------------------------------------------------------------
# Zeitprofil der Volatilität (Wochentag x Stunde) und Magnet-Statistik aus den Snapshots
# ---------------------------------------------------------------------------

def time_vol_profile(con, coin: str) -> dict | None:
    """Relative Volatilität je (Wochentag, Stunde) aus den 30-min-Kerzen; 1,0 = Durchschnitt."""
    ser = _series_30m(con, coin)
    if len(ser) < 2000:
        return None
    acc: dict = {}
    for (t0, c0), (t1, c1) in zip(ser[:-1], ser[1:]):
        if c0 > 0 and c1 > 0:
            g = time.gmtime(t1); key = f"{g.tm_wday}-{g.tm_hour}"
            acc.setdefault(key, []).append(abs(math.log(c1 / c0)))
    if not acc:
        return None
    means = {k: sum(v) / len(v) for k, v in acc.items() if len(v) >= 20}
    avg = sum(means.values()) / len(means)
    return {k: round(v / avg, 3) for k, v in means.items()}


def magnet_stats(con, coin: str, days: int = 14) -> dict | None:
    """
    Aus Heatmap-Snapshots (alle 15 min) und Bars: Wie oft wurde ein großes Cluster innerhalb 12 h
    erreicht, wenn der Kurs ihm auf <= 3 % nahe kam? Wie weit ging es darüber hinaus (Überschuss)?
    Wie viel der Bewegung kam binnen 12 h zurück? Getrennt nach Abstandsklassen.
    """
    now = int(time.time()); since = now - days * 86400
    try:
        # ein Snapshot je 15 min: erst die Zeitpunkte, dann nur diese Zeilen (der Snapshot-Takt ist nicht am Raster ausgerichtet)
        all_ts = [r[0] for r in con.execute("SELECT DISTINCT ts FROM heatmap WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts", (coin, since, now - 12 * 3600))]
        picked_ts = []; last_b = None
        for t in all_ts:
            b = t // 900
            if b != last_b:
                picked_ts.append(t); last_b = b
        snaps = []
        for i in range(0, len(picked_ts), 400):
            chunk = picked_ts[i:i + 400]
            snaps.extend(con.execute(f"SELECT ts, bucket_px, side, notional FROM heatmap WHERE coin=? AND ts IN ({','.join('?' * len(chunk))})",
                                     (coin, *chunk)).fetchall())
        bars = con.execute("SELECT ts, high, low, close FROM bars WHERE coin=? AND ts>=? ORDER BY ts", (coin, since)).fetchall()
        vol = con.execute("SELECT AVG(v) FROM (SELECT SUM(volume*close) v FROM bars WHERE coin=? AND ts>=? GROUP BY ts/3600)", (coin, since)).fetchone()[0] or 0
    except sqlite3.OperationalError:
        return None
    if len(snaps) < 200 or len(bars) < 720:
        return None
    b_ts = [b[0] for b in bars]
    import bisect
    def price_at(t):
        i = bisect.bisect_right(b_ts, t) - 1
        return bars[i][3] if i >= 0 else None
    def window(t0, t1):
        i = bisect.bisect_left(b_ts, t0); j = bisect.bisect_right(b_ts, t1)
        return bars[i:j]
    by_ts: dict = {}
    for ts, px, side, usd in snaps:
        if usd >= max(vol * 0.5, 5e6):
            by_ts.setdefault(ts, []).append((px, side, usd))
    stats: dict = {}
    for ts, clusters in by_ts.items():
        p0 = price_at(ts)
        if not p0:
            continue
        w = window(ts, ts + 12 * 3600)
        if len(w) < 60:
            continue
        for px, side, usd in clusters:
            dist = px / p0 - 1
            if abs(dist) > 0.03 or abs(dist) < 0.001:
                continue
            up = dist > 0
            cls = "0-1" if abs(dist) < 0.01 else "1-2" if abs(dist) < 0.02 else "2-3"
            st = stats.setdefault(cls, {"n": 0, "touched": 0, "overshoot": [], "retrace": []})
            st["n"] += 1
            touched_at = None
            for b in w:
                if (up and b[1] >= px) or (not up and b[2] <= px):
                    touched_at = b[0]; break
            if touched_at is None:
                continue
            st["touched"] += 1
            after = window(touched_at, touched_at + 4 * 3600)
            if up:
                ext = max(b[1] for b in after); over = ext / px - 1
                back = window(touched_at, touched_at + 12 * 3600); low = min(b[2] for b in back)
                ret = (ext - low) / max(ext - p0, 1e-9)
            else:
                ext = min(b[2] for b in after); over = 1 - ext / px
                back = window(touched_at, touched_at + 12 * 3600); high = max(b[1] for b in back)
                ret = (high - ext) / max(p0 - ext, 1e-9)
            st["overshoot"].append(max(0.0, over)); st["retrace"].append(_clip(ret, 0, 1.5))
    out = {}
    for cls, st in stats.items():
        if st["n"] >= 5:
            out[cls] = {"n": st["n"], "p_touch": st["touched"] / st["n"],
                        "overshoot": sorted(st["overshoot"])[len(st["overshoot"]) // 2] if st["overshoot"] else 0.0,
                        "retrace": sorted(st["retrace"])[len(st["retrace"]) // 2] if st["retrace"] else 0.3}
    return out or None


def capitulation_signal(con, coin: str) -> dict | None:
    """
    Kapitulation: großer Schub eingetretener Long-Liquidationen (Binance) in den letzten 30 min
    gegenüber dem 3-Tage-Durchschnitt -> Erholungschance; Short-Liquidationsschub -> Rückschlagchance.
    Die Stärke wird aus der eigenen Historie geschätzt: mittlere 4-h-Rendite nach solchen Schüben.
    """
    now = int(time.time())
    try:
        rows = con.execute("SELECT ts, side, notional FROM bnc_liquidations WHERE coin=? AND ts>=?", (coin, now - 3 * 86400)).fetchall()
    except sqlite3.OperationalError:
        return None
    if len(rows) < 50:
        return None
    buckets: dict = {}
    for ts, side, usd in rows:
        b = ts // 1800 * 1800; d = buckets.setdefault(b, [0.0, 0.0])
        d[0 if str(side).upper().startswith("S") else 1] += usd
    if len(buckets) < 20:
        return None
    longs = [v[0] for v in buckets.values()]; shorts = [v[1] for v in buckets.values()]
    avg_l = sum(longs) / len(longs); avg_s = sum(shorts) / len(shorts)
    cur = buckets.get(now // 1800 * 1800, [0.0, 0.0]); prev = buckets.get(now // 1800 * 1800 - 1800, [0.0, 0.0])
    l_now = cur[0] + prev[0]; s_now = cur[1] + prev[1]
    if avg_l > 0 and l_now >= 4 * avg_l and l_now >= 3e6:
        return {"kind": "long", "ratio": l_now / avg_l, "usd": l_now, "text": f"Long-Liquidationsschub: {l_now/1e6:.1f} Mio in 60 min, {l_now/avg_l:.0f}× Durchschnitt — Kapitulation, Erholungschance"}
    if avg_s > 0 and s_now >= 4 * avg_s and s_now >= 3e6:
        return {"kind": "short", "ratio": s_now / avg_s, "usd": s_now, "text": f"Short-Liquidationsschub: {s_now/1e6:.1f} Mio in 60 min, {s_now/avg_s:.0f}× Durchschnitt — Squeeze läuft, Rückschlagrisiko"}
    return None


# ---------------------------------------------------------------------------
# Kern
# ---------------------------------------------------------------------------

def compute_forecast(con, coin: str, chart: dict, whales: dict | None, smart: dict | None, lb: dict | None,
                     lb_act: dict | None, etf: dict | None, bnc: dict | None, cdc: dict | None,
                     bybit: dict | None = None, okx: dict | None = None, learned: dict | None = None) -> dict | None:
    """
    chart: Ergebnis von load_chart(agg=60, minutes=7*1440) -- Stundenkerzen, Marken, Stops, Buch, Funding, MAs.
    whales: load_whales (mit 'directional'); smart: smart_money; lb: load_leaderboard; lb_act: load_lb_activity(3 T).
    """
    C = chart.get("candles") or []
    p0 = chart.get("price") or (C[-1]["c"] if C else None)
    if not p0 or len(C) < 24:
        return None
    now = int(time.time())
    learned = learned or {}
    W = learned.get("weights") or {}                      # gelernte Gewichte je Treiber
    analog = learned.get("analog"); tprof = learned.get("tprof"); mstat = learned.get("magnets"); capit = learned.get("capitulation")
    if analog and isinstance(analog.get("ret"), dict):
        analog = dict(analog, ret=_intkeys(analog["ret"]))
    ens_w = learned.get("ensemble") or {"model": 0.6, "analog": 0.4}
    drivers: list[dict] = []          # {name, score (-1..1), weight, text}
    missing: list[str] = []

    def add(name, score, weight, text):
        lw = (W.get(name) or {}).get("weight")
        drivers.append({"name": name, "score": _clip(score, -1, 1), "weight": lw if lw is not None else weight, "prior": weight,
                        "learned": lw is not None and abs(lw - weight) > 1e-9, "hit_rate": (W.get(name) or {}).get("hit_rate"),
                        "n": (W.get(name) or {}).get("n"), "text": text})

    # ---- 1. Regime und Drift ------------------------------------------------------------------
    mas = chart.get("mas") or {}
    ma200 = _num(mas.get("ma200d")); ma50w = _num(mas.get("ma50w"))
    if ma200:
        d = p0 / ma200 - 1
        add("MA 200 Tage", _clip(d / 0.10, -1, 1) * 0.6, 0.8, f"Kurs {d*100:+.1f} % zum MA 200 Tage ({ma200:,.0f})")
    else:
        missing.append("MA 200 Tage")
    if ma50w:
        d = p0 / ma50w - 1
        add("MA 50 Wochen", _clip(d / 0.10, -1, 1) * 0.5, 0.6, f"Kurs {d*100:+.1f} % zum MA 50 Wochen ({ma50w:,.0f})")
    tr = _num(chart.get("trend_60m"))
    if tr is not None:
        add("60-min-Trend", _clip(tr / 0.01, -1, 1) * 0.5, 0.5, f"60-Minuten-Trend {tr*100:+.2f} %")
    rsi = _num(chart.get("rsi14"))
    if rsi is not None:
        # Mean Reversion: überkauft drückt, überverkauft stützt
        add("RSI 14 (1 h)", _clip((50 - rsi) / 30, -1, 1) * 0.5, 0.5, f"RSI {rsi:.0f} — {'überkauft, Rückschlagrisiko' if rsi >= 70 else 'überverkauft, Erholungschance' if rsi <= 30 else 'neutral'}")
    # 7-Tage-Drift, gedämpft
    if len(C) >= 48:
        drift7 = math.log(C[-1]["c"] / C[max(0, len(C) - 168)]["c"]) / max(1, min(168, len(C) - 1))   # je Stunde
    else:
        drift7 = 0.0
    sigma = realized_vol(C)                                                       # je Stunde
    add("7-Tage-Drift", _clip(drift7 / (sigma * 0.3), -1, 1) * 0.4, 0.4, f"Drift der letzten Tage {drift7*24*100:+.2f} %/Tag bei Volatilität {sigma*100:.2f} %/h")

    # ---- 2. Richtungsdruck: nur direktionale Konten ---------------------------------------------
    D = (whales or {}).get("directional") or {}
    if D.get("n_directional"):
        tot = D["usd_long"] + D["usd_short"]
        if tot > 0:
            sc = (D["usd_long"] - D["usd_short"]) / tot
            add("Direktionale Wale", sc, 1.2, f"{D['n_long']} long {D['usd_long']/1e6:.0f} Mio gegen {D['n_short']} short {D['usd_short']/1e6:.0f} Mio ({D['n_directional']} direktionale Wale)")
    else:
        missing.append("direktionale Wale")
    # Wal-Flow: Positionsänderungen der direktionalen Wale in den letzten 30 min (Ereignis-Signal bei Breite und Z-Score)
    FL = (whales or {}).get("flow") or {}
    ok = lambda w: bool(w) and (w["buy_usd"] + w["sell_usd"]) >= 3e5 and (w["n_buy"] + w["n_sell"]) >= 2
    GNAMES = {"dir": ("Wal-Flow 30 min", "direktionale Wale"), "hedge": ("Wal-Flow Hedge", "Hedge-Konten"),
              "mm": ("Wal-Flow Market Maker", "Market Maker"), "mixed": ("Wal-Flow gemischt", "gemischte Konten")}
    groups = FL.get("groups") or ({"dir": FL} if FL.get("w30") else {})
    any_group = False
    for g, (drv, label) in GNAMES.items():
        gf = groups.get(g)
        if not gf:
            continue
        w30g, w60g = gf.get("w30"), gf.get("w60")
        win, wf, z = ("30 min", w30g, gf.get("z30")) if ok(w30g) else ("60 min", w60g, gf.get("z60")) if ok(w60g) else (None, None, None)
        if not wf:
            continue
        any_group = True
        gross = wf["buy_usd"] + wf["sell_usd"]
        sc = (wf["net_usd"] / gross) * _clip((abs(z) if z is not None else 1.0) / 2.5, 0.4, 1.0)
        boost = 1.5 if gf.get("event_signal") else 1.0
        add(drv, sc * boost, PRIORS[drv],
            f"{wf['n_buy']} {label} kaufen {wf['buy_usd']/1e6:.1f} Mio, {wf['n_sell']} verkaufen {wf['sell_usd']/1e6:.1f} Mio in {win}"
            + (f" (Z {z:.1f})" if z is not None else "") + (" — EREIGNIS-SIGNAL" if gf.get("event_signal") else ""))
    if not any_group and FL:
        missing.append("Wal-Flow (ruhig)")
    # Leaderboard-Flow: Positionsänderungen der direktionalen Top-Konten (Stände alle 5 min)
    LF = (lb or {}).get("flow") or {}
    okL = lambda w: bool(w) and (w["buy_usd"] + w["sell_usd"]) >= 1.5e5 and (w["n_buy"] + w["n_sell"]) >= 2
    lwin, lw = ("60 min", LF.get("w60")) if okL(LF.get("w60")) else ("3 h", LF.get("w180")) if okL(LF.get("w180")) else ("60 min", None)
    if lw:
        gross = lw["buy_usd"] + lw["sell_usd"]; z = LF.get("z60")
        sc = (lw["net_usd"] / gross) * _clip((abs(z) if z is not None else 1.0) / 2.5, 0.4, 1.0)
        add("Leaderboard-Flow 60 min", sc * (1.5 if LF.get("event_signal") else 1.0), PRIORS["Leaderboard-Flow 60 min"],
            f"{lw['n_buy']} Top-Konten kaufen {lw['buy_usd']/1e6:.1f} Mio, {lw['n_sell']} verkaufen {lw['sell_usd']/1e6:.1f} Mio in {lwin}" + (f" (Z {z:.1f})" if z is not None else "") + (" — EREIGNIS-SIGNAL" if LF.get("event_signal") else ""))
    dir_addrs = lb_directional_addrs(con, coin)
    if smart and dir_addrs:
        # Smart Money nur direktional: aus lb_positions selbst rechnen
        try:
            last = con.execute("SELECT MAX(ts) FROM lb_positions").fetchone()[0]
            nl = ns = 0; ul = us = 0.0
            net: dict = {}
            for addr, c_, side, val in con.execute("SELECT addr, coin, side, pos_value FROM lb_positions WHERE ts=? AND rank<=50", (last,)):
                if addr not in dir_addrs:
                    continue
                if c_ != coin:
                    continue
                net[addr] = net.get(addr, 0.0) + (val or 0) * (1 if side == "long" else -1)
            for v in net.values():
                if v > 0: nl += 1; ul += v
                elif v < 0: ns += 1; us += -v
            if nl + ns >= 3:
                add("Smart Money (direktional)", (ul - us) / max(ul + us, 1), 1.0, f"{nl} long {ul/1e6:.1f} Mio gegen {ns} short {us/1e6:.1f} Mio in {coin} — profitabelste Konten, nur direktionale")
            else:
                missing.append(f"Smart Money in {coin} (zu wenige direktionale Konten)")
        except sqlite3.OperationalError:
            missing.append("Smart Money")
    else:
        missing.append("Smart Money")
    # Käufe/Verkäufe direktionaler Leaderboard-Konten, letzte 24 h
    if dir_addrs:
        try:
            since = now - 86_400
            marks = ",".join("?" * len(dir_addrs))
            has_buy = "buy" in {r[1] for r in con.execute("PRAGMA table_info(lb_fills)")}
            BUY = "buy" if has_buy else "(CASE WHEN lower(dir) LIKE '%open long%' OR lower(dir) LIKE '%close short%' OR lower(dir) LIKE '%buy%' THEN 1 ELSE 0 END)"
            row = con.execute(f"SELECT SUM(CASE WHEN {BUY}=1 THEN notional ELSE 0 END), SUM(CASE WHEN {BUY}=0 THEN notional ELSE 0 END), COUNT(DISTINCT addr) "
                              f"FROM lb_fills WHERE coin=? AND ts>=? AND addr IN ({marks})", (coin, since, *dir_addrs)).fetchone()
            b, s_, n = (row[0] or 0), (row[1] or 0), (row[2] or 0)
            if b + s_ >= 5e5 and n >= 2:
                add("Käufe/Verkäufe 24 h (direktional)", (b - s_) / (b + s_), 1.0, f"direktionale Top-Konten: {b/1e6:.1f} Mio gekauft, {s_/1e6:.1f} Mio verkauft ({n} Konten, Perp + Spot)")
            else:
                missing.append("Käufe/Verkäufe der Top-Konten (zu wenig in 24 h)")
        except sqlite3.OperationalError:
            missing.append("Fills")
    # Leaderboard-Trend Top 20 (Veränderung 24 h) im Coin
    if lb and lb.get("summary") and lb.get("trend") and len(lb["trend"]) >= 2:
        S = lb["summary"]; T = [dict(r, ts=int(r["ts"])) for r in lb["trend"]]; ago = next((r for r in reversed(T) if r["ts"] <= T[-1]["ts"] - 86_400), T[0])
        gross = S["usd_long"] + S["usd_short"]
        if gross > 0:
            delta = (S["net_usd"] - ago["net_usd"]) / gross
            add("Top-20-Trend 24 h", _clip(delta / 0.5, -1, 1) * 0.6, 0.6, f"Netto-Positionierung der Top 20 in {coin} seit 24 h {'+' if delta >= 0 else '−'}{abs(delta)*100:.0f} % des Bruttowerts")
    # Taker-Flow börsenübergreifend
    parts = []
    for name, src in (("Binance", (bnc or {}).get("metrics") or {}), ("Crypto.com", cdc or {}), ("Bybit", bybit or {}), ("OKX", okx or {})):
        r = src.get("taker_ls")
        if r and r < 9 and (src.get("taker_span_s") is None or src.get("taker_span_s", 0) >= 60):
            parts.append((name, float(r)))
    if parts:
        avg = sum(math.log(r) for _, r in parts) / len(parts)                 # log-Verhältnis, symmetrisch
        add("Taker-Flow", _clip(avg / math.log(1.5), -1, 1) * 0.7, 0.7, "Taker Kauf/Verkauf: " + ", ".join(f"{n} {r:.2f}" for n, r in parts))
    # Funding: extremes Funding wirkt gegen die Menge
    f = _num(chart.get("funding"), "funding")
    if f is not None:
        add("Funding", _clip(-f / 0.0002, -1, 1) * 0.4, 0.4, f"Funding {f*100:.4f} %/h — {'Longs zahlen, Squeeze-Risiko nach unten' if f > 0.0001 else 'Shorts zahlen, Squeeze-Risiko nach oben' if f < -0.00005 else 'neutral'}")
    # ETF-Flows (BTC/ETH)
    if etf and coin in ("BTC", "ETH"):
        sc = 0.0
        if etf["last"] > 0 and etf["sum5"] > 0: sc = _clip(etf["sum5"] / 1000, 0.2, 1)
        elif etf["last"] < 0 and etf["sum5"] < 0: sc = -_clip(-etf["sum5"] / 1000, 0.2, 1)
        add("ETF-Flows", sc * 0.6, 0.6, f"ETF {etf['last']:+.0f} Mio am {etf['last_date']}, 5 Tage {etf['sum5']:+.0f} Mio")
    # Orderbuch-Imbalance
    book = chart.get("book") or {}
    imb = _num(book.get("imb_50")) if isinstance(book, dict) else None
    if imb is not None:
        add("Orderbuch", _clip(imb / 0.5, -1, 1) * 0.4, 0.4, f"Orderbuch-Imbalance ±50 bps {imb*100:+.0f} %")

    if capit:
        add("Kapitulation", 0.8 if capit["kind"] == "long" else -0.8, PRIORS["Kapitulation"], capit["text"])
    if analog and analog.get("ret", {}).get(24):
        a24 = analog["ret"][24]
        add("Analog-Suche", _clip((a24["p_up"] - 0.5) * 4, -1, 1) * 0.8, PRIORS["Analog-Suche"],
            f"{analog['n']} ähnliche Momente aus {analog['span_days']:.0f} Tagen: danach 24 h im Median {a24['med']*100:+.2f} %, {a24['p_up']*100:.0f} % davon aufwärts")
    else:
        missing.append("Analog-Suche")

    wsum = sum(d["weight"] for d in drivers) or 1.0
    bias = sum(d["score"] * d["weight"] for d in drivers) / wsum                 # -1 .. 1
    agree = sum(d["weight"] for d in drivers if d["score"] * bias > 0) / wsum if bias else 0.5
    completeness = 1 - min(0.5, 0.08 * len([m for m in missing if "(ruhig)" not in m]))
    confidence = _clip(0.35 + 0.45 * abs(bias) + 0.3 * (agree - 0.5), 0.15, 0.9) * completeness

    # ---- 3. Magneten, Wände, Kaskade ------------------------------------------------------------
    levels = [dict(l, px=_num(l.get("px")) or 0.0, notional=_num(l.get("notional")) or 0.0) for l in (chart.get("levels") or []) if _num(l.get("px"))]
    SC = [dict(c, px=_num(c.get("px")) or 0.0, notional=_num(c.get("notional")) or 0.0) for c in ((chart.get("stops") or {}).get("clusters") or []) if _num(c.get("px"))]
    vol1h = _num(chart.get("vol_1h")) or 0
    big = lambda n: n >= max(vol1h * 0.5, 5e6)
    liq_up = sorted([l for l in levels if l["side"] == "short" and l["px"] > p0 and big(l["notional"])], key=lambda l: l["px"])
    liq_dn = sorted([l for l in levels if l["side"] == "long" and l["px"] < p0 and big(l["notional"])], key=lambda l: -l["px"])
    wall_up = sorted([s for s in SC if s["kind"] in ("limit_sell", "tp_sell") and s["px"] > p0 and big(s["notional"])], key=lambda s: s["px"])
    wall_dn = sorted([s for s in SC if s["kind"] in ("limit_buy", "tp_buy") and s["px"] < p0 and big(s["notional"])], key=lambda s: -s["px"])
    stop_up = sorted([s for s in SC if s["kind"] == "stop_buy" and s["px"] > p0 and s["notional"] >= max(vol1h * 0.25, 5e6)], key=lambda s: s["px"])
    stop_dn = sorted([s for s in SC if s["kind"] == "stop_sell" and s["px"] < p0 and s["notional"] >= max(vol1h * 0.25, 5e6)], key=lambda s: -s["px"])
    magnets = {
        "liq_up": [{"px": l["px"], "usd": l["notional"]} for l in liq_up[:3]],
        "liq_dn": [{"px": l["px"], "usd": l["notional"]} for l in liq_dn[:3]],
        "wall_up": [{"px": s["px"], "usd": s["notional"]} for s in wall_up[:2]],
        "wall_dn": [{"px": s["px"], "usd": s["notional"]} for s in wall_dn[:2]],
        "stop_up": [{"px": s["px"], "usd": s["notional"]} for s in stop_up[:2]],
        "stop_dn": [{"px": s["px"], "usd": s["notional"]} for s in stop_dn[:2]],
    }

    # ---- 4. Pfad: Stunde für Stunde --------------------------------------------------------------
    # Kurzfrist (0-12 h): zum nächsten Magneten in Richtung des Drucks, gebremst von der ersten Wand.
    # Mittelfrist (12-72 h): Kaskade, falls der Weg einen Stop-Auslöser kreuzt; danach Teilrückkehr.
    # Langfrist (72-168 h): Regime-Drift, gedämpft. Band: sigma * sqrt(t), skaliert mit (1 - Konfidenz/2).
    def first_px(lst):
        return lst[0]["px"] if lst else None
    dir_sign = 1 if bias > 0.12 else -1 if bias < -0.12 else 0
    reach = _clip(abs(bias), 0, 1)                                          # wie weit der Magnet erreicht wird
    retrace_frac = 0.3; overshoot = 0.0; mag_used = None
    if mstat:
        nearest = (liq_up[0] if dir_sign > 0 and liq_up else liq_dn[0] if dir_sign < 0 and liq_dn else None)
        if nearest:
            dd = abs(nearest["px"] / p0 - 1); cls = "0-1" if dd < 0.01 else "1-2" if dd < 0.02 else "2-3"
            ms = mstat.get(cls)
            if ms:
                reach = _clip(0.5 * reach + 0.5 * ms["p_touch"], 0, 1); retrace_frac = _clip(ms["retrace"], 0.1, 0.9); overshoot = ms["overshoot"]
                mag_used = {"class": cls, **ms}
    if dir_sign > 0:
        target = first_px(liq_up) or (p0 * (1 + sigma * 4)); wall = first_px(wall_up)
        if wall and wall < target: target = wall * 0.998                         # Wand bremst
    elif dir_sign < 0:
        target = first_px(liq_dn) or (p0 * (1 - sigma * 4)); wall = first_px(wall_dn)
        if wall and wall > target: target = wall * 1.002
    else:
        target = p0 * (1 + drift7 * 12)
    target = p0 + (target - p0) * (0.5 + 0.5 * reach)
    move = target / p0 - 1
    h1 = int(_clip(abs(move) / max(sigma, 1e-4) * 1.5, 4, 12))              # Dauer der ersten Bewegung
    if FL.get("event_signal"):
        h1 = max(2, h1 // 2)                                                # Ereignis: die Bewegung kommt schneller
        confidence = _clip(confidence + 0.08, 0.15, 0.92)
    # Kaskade: kreuzt der Weg einen Stop-Auslöser?
    cascade = None
    trig = first_px(stop_dn) if dir_sign < 0 else first_px(stop_up) if dir_sign > 0 else None
    if trig and ((dir_sign < 0 and target <= trig) or (dir_sign > 0 and target >= trig)):
        nxt = (liq_dn[1]["px"] if dir_sign < 0 and len(liq_dn) > 1 else liq_up[1]["px"] if dir_sign > 0 and len(liq_up) > 1 else None)
        c_target = nxt or (trig * (1 - 0.02 * dir_sign * -1) if dir_sign < 0 else trig * 1.02)
        cascade = {"trigger": trig, "target": c_target, "type": "Long-Squeeze" if dir_sign < 0 else "Short-Squeeze"}
    path = []; band = []
    for h in range(0, HORIZON_H + 1):
        if h <= h1:
            k = h / max(h1, 1); ease = 0.5 - 0.5 * math.cos(math.pi * k)
            px = p0 + (target - p0) * ease
        elif h <= 24:
            k = (h - h1) / max(24 - h1, 1)
            if cascade:
                px = target + (cascade["target"] - target) * min(1, k * 2)
                if k > 0.5:                                                    # Teilrückkehr nach der Kaskade
                    px = cascade["target"] + (target - cascade["target"]) * 0.5 * (k - 0.5) * 2
            else:
                px = target + (p0 - target) * retrace_frac * k                  # gemessene Rückkehr nach dem Sweep
        else:
            base = path[24]["px"] if len(path) > 24 else target
            dvol = sigma * math.sqrt(24)                                          # Tagesvolatilität
            daily = _clip(bias * dvol * 0.25 + drift7 * 24 * 0.3, -dvol * 0.3, dvol * 0.3)   # gedämpft: Drift ist die schwächste Information
            px = base * math.exp(daily * (h - 24) / 24)
        path.append({"h": h, "ts": now + h * 3600, "px": px})
    # Ensemble: Modellpfad mit dem Analog-Median mischen (Gewichte aus der laufenden Trefferquote beider Modelle)
    model_p24 = path[24]["px"] if len(path) > 24 else None
    analog_p24 = None
    if analog and analog.get("ret"):
        ar = analog["ret"]; ah = sorted(ar)
        def a_ret(h):
            if h <= 0: return 0.0
            lo_h = max([x for x in ah if x <= h], default=None); hi_h = min([x for x in ah if x >= h], default=None)
            if lo_h is None: return ar[hi_h]["med"] * h / hi_h
            if hi_h is None: return ar[lo_h]["med"]
            if lo_h == hi_h: return ar[lo_h]["med"]
            return ar[lo_h]["med"] + (ar[hi_h]["med"] - ar[lo_h]["med"]) * (h - lo_h) / (hi_h - lo_h)
        wm, wa = ens_w.get("model", 0.6), ens_w.get("analog", 0.4)
        analog_p24 = p0 * math.exp(a_ret(24))
        for p in path:
            p["px_model"] = p["px"]
            p["px"] = math.exp(wm * math.log(p["px"]) + wa * math.log(p0 * math.exp(a_ret(p["h"]))))
    # Band: Volatilität x sqrt(t), je Stunde mit dem Zeitprofil der Stunde skaliert; ab 24 h mit den Analog-Quantilen gemischt
    vol_acc = 0.0
    for p in path:
        h = p["h"]; px = p["px"]
        if h > 0:
            g = time.gmtime(now + h * 3600); mult = (tprof or {}).get(f"{g.tm_wday}-{g.tm_hour}", 1.0)
            vol_acc += (sigma * mult) ** 2
        w = math.sqrt(vol_acc) * (1.3 - confidence * 0.6) if h > 0 else sigma * 0.5
        lo_b, hi_b = px * math.exp(-w), px * math.exp(w)
        if analog and analog.get("ret") and h >= 24:
            ah = sorted(analog["ret"]); key = max([x for x in ah if x <= h], default=None)
            if key:
                q = analog["ret"][key]; alo, ahi = p0 * math.exp(q["q20"]), p0 * math.exp(q["q80"])
                lo_b, hi_b = math.exp(0.5 * math.log(lo_b) + 0.5 * math.log(alo)), math.exp(0.5 * math.log(hi_b) + 0.5 * math.log(ahi))
        band.append({"h": h, "lo": lo_b, "hi": hi_b})

    # ---- 5. Optimaler Kauf- und Verkaufspreis im Fenster 4-12 h --------------------------------------
    win = [p for p in path if 4 <= p["h"] <= 12]
    lo_pt = min(win, key=lambda p: p["px"]); hi_pt = max(win, key=lambda p: p["px"])
    # Kauf: an der Kaufwand oder dem Long-Cluster (nach dem Sweep), sonst Pfadtief; nie über dem Kurs, wenn Druck nach unten
    buy_px = lo_pt["px"]; buy_reason = f"Pfadtief im Fenster (Stunde {lo_pt['h']})"
    if wall_dn and wall_dn[0]["px"] < p0 and wall_dn[0]["px"] > buy_px * 0.99:
        buy_px = wall_dn[0]["px"] * 1.0015; buy_reason = f"knapp über der Kaufwand {wall_dn[0]['px']:,.0f} ({wall_dn[0]['notional']/1e6:.0f} Mio)"
    if liq_dn and abs(liq_dn[0]["px"] / buy_px - 1) < 0.006:
        buy_px = liq_dn[0]["px"] * (1 - max(0.003, overshoot)); buy_reason = f"unter dem Long-Liquidationscluster {liq_dn[0]['px']:,.0f} — nach dem Sweep kaufen (gemessener Überschuss {max(0.3, overshoot*100):.1f} %)"
    if cascade and cascade["type"] == "Long-Squeeze":
        buy_px = min(buy_px, cascade["target"] * 1.003); buy_reason = f"Kaskadenziel {cascade['target']:,.0f} — erst nach der Kaskade kaufen"
    sell_px = hi_pt["px"]; sell_reason = f"Pfadhoch im Fenster (Stunde {hi_pt['h']})"
    if wall_up and wall_up[0]["px"] > p0 and wall_up[0]["px"] < sell_px * 1.01:
        sell_px = wall_up[0]["px"] * 0.9985; sell_reason = f"knapp unter der Verkaufswand {wall_up[0]['px']:,.0f} ({wall_up[0]['notional']/1e6:.0f} Mio)"
    if liq_up and abs(liq_up[0]["px"] / sell_px - 1) < 0.006:
        sell_px = liq_up[0]["px"] * (1 + max(0.003, overshoot)); sell_reason = f"über dem Short-Liquidationscluster {liq_up[0]['px']:,.0f} — in den Squeeze verkaufen (gemessener Überschuss {max(0.3, overshoot*100):.1f} %)"
    if cascade and cascade["type"] == "Short-Squeeze":
        sell_px = max(sell_px, cascade["target"] * 0.997); sell_reason = f"Kaskadenziel {cascade['target']:,.0f} — in die Kaufkaskade verkaufen"
    # Liegt der ganze Pfad im Fenster über dem Kurs, ist jetzt der beste Kauf -- als Limit knapp unter dem Kurs,
    # sonst an der nächsten Kaufwand. Umgekehrt für den Verkauf.
    if buy_px > p0:
        if wall_dn and wall_dn[0]["px"] > p0 * 0.985:
            buy_px = wall_dn[0]["px"] * 1.0015; buy_reason = f"Pfad steigt — Limit knapp über der Kaufwand {wall_dn[0]['px']:,.0f} (sonst Markt)"
        else:
            buy_px = p0 * 0.998; buy_reason = "Pfad liegt im Fenster über dem Kurs — jetzt, Limit knapp unter dem Kurs"
    if sell_px < p0:
        if wall_up and wall_up[0]["px"] < p0 * 1.015:
            sell_px = wall_up[0]["px"] * 0.9985; sell_reason = f"Pfad fällt — Limit knapp unter der Verkaufswand {wall_up[0]['px']:,.0f} (sonst Markt)"
        else:
            sell_px = p0 * 1.002; sell_reason = "Pfad liegt im Fenster unter dem Kurs — jetzt, Limit knapp über dem Kurs"
    buy_ok = bias > -0.45
    sell_ok = bias < 0.45
    buy = {"px": buy_px, "dist_pct": (buy_px / p0 - 1) * 100, "window_h": [4, 12], "reason": buy_reason, "advised": buy_ok,
           "note": None if buy_ok else f"Richtungsdruck klar nach unten ({bias:+.2f}) — Kauf im Fenster nicht ratsam; Kaufzone erst nach der Bewegung"}
    sell = {"px": sell_px, "dist_pct": (sell_px / p0 - 1) * 100, "window_h": [4, 12], "reason": sell_reason, "advised": sell_ok,
            "note": None if sell_ok else f"Richtungsdruck klar nach oben ({bias:+.2f}) — Verkauf im Fenster nicht ratsam; halten, Verkaufszone weiter oben"}
    end = path[-1]["px"]; b_end = band[-1]
    outlook = {"end_px": end, "end_pct": (end / p0 - 1) * 100, "lo": b_end["lo"], "hi": b_end["hi"],
               "target_12h": target, "target_pct": move * 100, "h1": h1, "cascade": cascade}
    label = "bullisch" if bias > 0.35 else "leicht bullisch" if bias > 0.12 else "bärisch" if bias < -0.35 else "leicht bärisch" if bias < -0.12 else "neutral"
    return {"ts": now, "coin": coin, "price": p0, "bias": round(bias, 3), "label": label, "confidence": round(confidence, 2),
            "sigma_h": sigma, "drivers": sorted(drivers, key=lambda d: -abs(d["score"] * d["weight"])), "missing": missing,
            "magnets": magnets, "path": path, "band": band, "buy": buy, "sell": sell, "outlook": outlook,
            "n_directional_lb": len(dir_addrs), "wver": learned.get("wver"),
            "ensemble": {"model_p24": model_p24, "analog_p24": analog_p24, "w_model": ens_w.get("model", 0.6), "w_analog": ens_w.get("analog", 0.4)},
            "analog": {k: v for k, v in (analog or {}).items() if k != "examples"} if analog else None,
            "analog_examples": (analog or {}).get("examples"), "magnet_stats": mstat, "magnet_used": mag_used, "tprof_used": bool(tprof),
            "learned_n": sum(1 for d in drivers if d.get("learned"))}


if __name__ == "__main__":
    # Selbsttest mit synthetischen Daten
    import random
    rng = random.Random(1); now = int(time.time()); p = 77000.0; C = []
    for h in range(200):
        o = p; p *= 1 + rng.gauss(0.0002, 0.006); C.append({"t": now - (200 - h) * 3600, "o": o, "h": max(o, p), "l": min(o, p), "c": p, "v": 100})
    chart = {"candles": C, "price": p, "mas": {"ma200d": p * 0.9, "ma50w": p * 1.02}, "trend_60m": 0.004, "rsi14": 58, "funding": 0.00003,
             "vol_1h": 30e6, "book": {"imb_50": 0.3},
             "levels": [{"px": p * 1.02, "side": "short", "notional": 40e6}, {"px": p * 0.985, "side": "long", "notional": 35e6}, {"px": p * 0.97, "side": "long", "notional": 60e6}],
             "stops": {"clusters": [{"kind": "limit_buy", "px": p * 0.99, "notional": 25e6}, {"kind": "limit_sell", "px": p * 1.015, "notional": 30e6}, {"kind": "stop_sell", "px": p * 0.992, "notional": 12e6}]}}
    con = sqlite3.connect(":memory:"); con.execute("CREATE TABLE bars (ts, coin, close)")
    con.execute("CREATE TABLE lb_positions (ts, rank, addr, coin, side, size, pos_value, entry_px, liq_px, leverage, upnl, mark_px)")
    con.execute("CREATE TABLE lb_fills (ts, addr, coin, market, dir, side, px, sz, notional, closed_pnl, fee, tid, buy)")
    fc = compute_forecast(con, "BTC", chart, {"directional": {"n_long": 12, "usd_long": 300e6, "n_short": 5, "usd_short": 90e6, "n_directional": 17}},
                          None, None, None, {"last": 120, "sum5": 400, "last_date": "2026-09-10"}, {"metrics": {"taker_ls": 1.3}}, {"taker_ls": 1.1, "taker_span_s": 120})
    print(f"Bias {fc['bias']:+.2f} ({fc['label']}) · Konfidenz {fc['confidence']:.0%} · Kauf {fc['buy']['px']:,.0f} ({fc['buy']['dist_pct']:+.2f} %) — {fc['buy']['reason']}")
    print(f"Verkauf {fc['sell']['px']:,.0f} ({fc['sell']['dist_pct']:+.2f} %) — {fc['sell']['reason']} · 7 T: {fc['outlook']['end_pct']:+.2f} % · Band {fc['outlook']['lo']:,.0f}–{fc['outlook']['hi']:,.0f}")
    for d in fc["drivers"][:5]:
        print(f"  {d['name']:<28} {d['score']:+.2f} × {d['weight']:.1f}  {d['text']}")
    print("fehlend:", fc["missing"])
