#!/usr/bin/env python3
"""
AI-Prognose: kalkulierte Kursprognose aus allen gesammelten Daten.

Kein Orakel. Ein transparentes Modell mit vier Teilen:
  1. Regime und Drift      -- MA 200 Tage / MA 50 Wochen, 60-min-Trend, RSI, 7-Tage-Drift
  2. Richtungsdruck S      -- direktionale Wale, direktionales Smart Money, Käufe/Verkäufe
                              direktionaler Leaderboard-Konten (24 h), Taker-Flow, Funding, ETF
  3. Magneten und Wände    -- Liquidationscluster ziehen, Limit-Wände halten, Kaskadenmodell
  4. Pfad und Band         -- Stunde für Stunde bis 7 Tage, Unsicherheitsband aus der
                              realisierten Volatilität (sigma * sqrt(t))
Daraus: optimaler Kaufpreis (4-12 h) und optimaler Verkaufspreis für offene Positionen,
jeweils mit Fenster und Begründung. Jede Prognose wird gespeichert; nach 24 h wird die
Richtung gegen den echten Kurs geprüft -- die Trefferquote steht im Chart.

Nur direktionale Konten zählen: Hedges und Market Maker haben keine Meinung.
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import time

import hl_indikatoren

HORIZON_H = 7 * 24
def _default_store() -> str:
    """
    Ablage der Prognosen: neben der Hauptdatenbank, damit die SD-Karte des Pi geschont wird.
    Reihenfolge: HL_FORECAST_DB (Umgebung) -> Ordner der Hauptdatenbank (HL_DB oder --db der
    systemd-Einheit) -> Projektordner. Der Ordner muss beschreibbar sein, sonst der nächste.
    """
    import re
    cand = []
    env = os.environ.get("HL_FORECAST_DB")
    if env:
        cand.append(env)
    main = os.environ.get("HL_DB")
    if not main:
        try:
            with open("/etc/systemd/system/hl-recorder.service") as f:
                m = re.search(r"--db\s+(\S+)", f.read())
            main = m.group(1) if m else None
        except OSError:
            main = None
    if main:
        cand.append(os.path.join(os.path.dirname(os.path.abspath(main)), "forecasts.db"))
    here = os.path.dirname(os.path.abspath(__file__))
    cand.append(os.path.join(here, "forecasts.db"))
    for path in cand:
        d = os.path.dirname(path) or "."
        if os.path.isdir(d) and os.access(d, os.W_OK):
            return path
    return cand[-1]


STORE = _default_store()


# ---------------------------------------------------------------------------
# Speicher für Prognosen (eigene kleine Datenbank des Dashboards)
# ---------------------------------------------------------------------------

def store_connect(path: str = STORE) -> sqlite3.Connection:
    con = sqlite3.connect(path, timeout=30)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA temp_store=MEMORY")      # Sortierpuffer im RAM, nicht auf der SD-Karte
    con.execute("PRAGMA synchronous=NORMAL")     # im WAL-Modus sicher, spart Schreibvorgänge
    con.execute("""CREATE TABLE IF NOT EXISTS forecast (
        ts INTEGER, coin TEXT, price REAL, bias REAL, confidence REAL,
        p_4h REAL, p_12h REAL, p_24h REAL, p_72h REAL, p_168h REAL,
        buy_px REAL, sell_px REAL, payload TEXT,
        PRIMARY KEY (ts, coin))""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_fc_coin_ts ON forecast(coin, ts)")
    cols = {r[1] for r in con.execute("PRAGMA table_info(forecast)")}
    for col in ("model_p24", "analog_p24", "wver", "p_up", "p_up_24"):
        if col not in cols:
            con.execute(f"ALTER TABLE forecast ADD COLUMN {col} REAL")
    con.execute("""CREATE TABLE IF NOT EXISTS weights (
        coin TEXT, name TEXT, prior REAL, weight REAL, n INTEGER, hit_rate REAL, updated INTEGER,
        PRIMARY KEY (coin, name))""")
    # Gewichte je Horizont (4 h = Hauptspur, 24 h). `weights` bleibt als Spiegel der Hauptspur
    # bestehen, damit ältere Leser (check_report, Lernplan) weiter funktionieren.
    con.execute("""CREATE TABLE IF NOT EXISTS weights_h (
        coin TEXT, h INTEGER, name TEXT, prior REAL, weight REAL, n INTEGER, n_eff REAL, hit_rate REAL, updated INTEGER,
        PRIMARY KEY (coin, h, name))""")
    con.execute("""CREATE TABLE IF NOT EXISTS learned (
        coin TEXT, key TEXT, value TEXT, updated INTEGER, PRIMARY KEY (coin, key))""")
    # Audit v9 §5.5: weights_h wird je (coin, h, name) überschrieben -- ein "Rollback per Gewichtsversion"
    # gab es nicht. Jede geschriebene Version landet zusätzlich hier, unverändert, mit ihrem Stempel.
    con.execute("""CREATE TABLE IF NOT EXISTS weights_hist (
        coin TEXT, h INTEGER, name TEXT, prior REAL, weight REAL, n INTEGER, n_eff REAL, hit_rate REAL, updated INTEGER,
        PRIMARY KEY (coin, h, name, updated))""")
    # Audit v3 S4: Prognosezeilen werden nach 60 Tagen gelöscht (Payload ~5-10 kB je Zeile). Die
    # Treiber-Scores und Wahrscheinlichkeiten je Prognose leben hier schmal und UNBEGRENZT weiter --
    # Grundlage für die 72-h/168-h-Spuren, die im 60-Tage-Fenster nie genug Blöcke bekämen.
    con.execute("""CREATE TABLE IF NOT EXISTS forecast_drivers (
        ts INTEGER, coin TEXT, name TEXT, score REAL, PRIMARY KEY (ts, coin, name))""")
    con.execute("""CREATE TABLE IF NOT EXISTS forecast_slim (
        ts INTEGER, coin TEXT, price REAL, bias REAL, p_4h REAL, p_24h REAL, p_72h REAL, p_168h REAL,
        p_up REAL, p_up_24 REAL, PRIMARY KEY (ts, coin))""")
    return con


STORE_FEHLER = {"n": 0, "letzter": None}       # M11 (Audit v10): verlorene Prognosen sichtbar machen


def store_forecast(fc: dict, path: str = STORE) -> None:
    for versuch in range(2):
        try:
            _store_forecast_einmal(fc, path)
            return
        except sqlite3.Error as e:
            STORE_FEHLER["n"] += 1; STORE_FEHLER["letzter"] = f"{type(e).__name__}: {e}"
            if versuch == 0:
                time.sleep(0.5)
    print(f"  store_forecast: verloren ({STORE_FEHLER['letzter']}) -- Zähler {STORE_FEHLER['n']}", flush=True)


def _store_forecast_einmal(fc: dict, path: str = STORE) -> None:
    if True:
        con = store_connect(path)
        path_map = {p["h"]: p["px"] for p in fc["path"]}
        con.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, confidence, p_4h, p_12h, p_24h, p_72h, p_168h, buy_px, sell_px, payload, model_p24, analog_p24, wver, p_up, p_up_24) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (fc["ts"], fc["coin"], fc["price"], fc["bias"], fc["confidence"],
                     path_map.get(4), path_map.get(12), path_map.get(24), path_map.get(72), path_map.get(168),
                     (fc.get("buy") or {}).get("px"), (fc.get("sell") or {}).get("px"),
                     json.dumps({k: v for k, v in fc.items() if k not in ("path", "band", "history", "analog_paths")}),
                     (fc.get("ensemble") or {}).get("model_p24"), (fc.get("ensemble") or {}).get("analog_p24"), fc.get("wver"),
                     fc.get("p_up"), fc.get("p_up_24")))
        con.executemany("INSERT OR REPLACE INTO forecast_drivers VALUES (?,?,?,?)",
                        [(fc["ts"], fc["coin"], d.get("name"), float(d.get("score") or 0.0)) for d in (fc.get("drivers") or []) if d.get("name")])
        con.execute("INSERT OR REPLACE INTO forecast_slim VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (fc["ts"], fc["coin"], fc["price"], fc["bias"], path_map.get(4), path_map.get(24), path_map.get(72), path_map.get(168),
                     fc.get("p_up"), fc.get("p_up_24")))
        con.execute("DELETE FROM forecast WHERE ts < ?", (int(time.time()) - 60 * 86_400,))
        con.commit(); con.close()


TOLERANZ = 0.002          # 0,2 % -- darunter gilt eine Bewegung als Seitwärtsrauschen


def urteil(p0, pred, real) -> str | None:
    """
    Treffer, Fehlschlag -- oder unentschieden.

    Die frühere Fassung zählte Toleranzfälle als TREFFER: Lagen Prognose und
    Wirklichkeit beide unter 0,2 %, galt das als richtig, selbst wenn sie in
    entgegengesetzte Richtungen zeigten. In der Simulation mit reinem Rauschen
    (echte Quote 50 %) meldete sie 55,1 %.

    Richtig ist: Wo keine Richtung erkennbar war, gibt es nichts zu treffen. Solche
    Fenster kommen als "unentschieden" aus der Stichprobe heraus, statt sie zu füllen.
    """
    if not p0 or p0 <= 0 or pred is None or real is None:
        return None
    d_pred = pred / p0 - 1
    d_real = real / p0 - 1
    if abs(d_pred) < TOLERANZ and abs(d_real) < TOLERANZ:
        return "offen"
    return "treffer" if d_pred * d_real > 0 else "fehl"


def _quote_block(h_h: int) -> dict:
    return {"h": h_h, "n": 0, "hits": 0, "offen": 0, "up": 0, "hit_rate": None, "n_eff": 0.0, "ci": None,
            "base_up": None, "base": None, "brier": None, "brier_ref": None, "brier_skill": None, "_bs": [], "_bs_p": 0, "_bl": set()}


def _quote_schliessen(q: dict) -> None:
    """Quote, Intervall (auf n_eff), Basisrate und Brier-Skill aus den Zählern ableiten."""
    n = q["n"]
    if n:
        q["hit_rate"] = q["hits"] / n
        q["n_eff"] = float(len(q["_bl"]))                    # getrennte Horizont-Blöcke
        ci = wilson(q["hit_rate"] * q["n_eff"], q["n_eff"]) if q["n_eff"] >= 1 else None
        q["ci"] = [round(ci[0], 3), round(ci[1], 3)] if ci else None
        # Basisrate: Wie oft hätte "immer aufwärts" bzw. "immer abwärts" in denselben Fenstern
        # getroffen? Eine Quote ist nur so gut wie ihr Abstand zu dieser Drift.
        q["base_up"] = q["up"] / n
        q["base"] = max(q["base_up"], 1 - q["base_up"])
    if q["_bs"]:
        # Brier: mittlerer quadratischer Fehler der Wahrscheinlichkeit; Referenz ist die
        # Klimatologie (konstant Basisrate). Skill > 0 heißt: besser als Raten mit der Drift.
        q["brier"] = sum(q["_bs"]) / len(q["_bs"])
        pu = q["_bs_p"] / len(q["_bs"])
        q["brier_ref"] = pu * (1 - pu)
        q["brier_skill"] = (1 - q["brier"] / q["brier_ref"]) if q["brier_ref"] > 1e-9 else None
        q["n_brier"] = len(q["_bs"])
    q.pop("_bs", None); q.pop("_bs_p", None); q.pop("_bl", None)


def score_forecasts(con_main, coin: str, path: str = STORE, wver: float | None = None) -> dict:
    """
    Trefferbilanz der gespeicherten Prognosen -- EINE Prognose je 15-min-Fenster (die früheste;
    Sofortprognosen bei Wal-Ereignissen zählen nicht doppelt), Richtung nach 4 h und 24 h gegen
    den echten Kurs. Je Horizont: n, n_eff (unabhängige Fälle), Wilson-Intervall, Basisrate
    ("immer aufwärts" in denselben Fenstern), Brier-Score und Brier-Skill der gespeicherten
    Wahrscheinlichkeit, dazu MAE nach 24 h; getrennt für reines Modell und Analog-Pfad (24 h).

    Alle gespeicherten Prognosen sind per Konstruktion walk-forward: Ihre Gewichte wurden nur
    aus Daten gelernt, die vor ihrem Zeitpunkt lagen. "oos" (nur Fenster seit der aktuellen
    Gewichtsversion) bleibt als engere Sicht erhalten.
    """
    out = {"n": 0, "hits": 0, "hit_rate": None, "mae_pct": None, "n_4h": 0, "hits_4h": 0,
           "model": {"n": 0, "hits": 0}, "analog": {"n": 0, "hits": 0}, "oos": {"n": 0, "hits": 0},
           "q4": _quote_block(4), "q24": _quote_block(24), "q72": _quote_block(72), "q168": _quote_block(168)}
    rows_lang = []
    try:
        st = store_connect(path)
        rows = st.execute("SELECT ts, price, p_4h, p_24h, model_p24, analog_p24, wver, p_up, p_up_24, json_extract(payload,'$.p_up_v2'), json_extract(payload,'$.p_up_v1') FROM forecast "
                          "WHERE coin=? AND ts<=? ORDER BY ts",
                          (coin, int(time.time()) - 4 * 3600)).fetchall()
        # Audit v3 S5: 72-h- und 168-h-Pfade wurden gespeichert, aber nie bewertet. Quelle ist die
        # schmale, unbegrenzte Tabelle (die Prognosezeilen selbst leben nur 60 Tage).
        rows_lang = st.execute("SELECT ts, price, p_72h, p_168h FROM forecast_slim WHERE coin=? AND ts<=? ORDER BY ts",
                               (coin, int(time.time()) - 72 * 3600)).fetchall()
        st.close()
    except sqlite3.Error:
        rows = []
    if not rows and not rows_lang:
        # Auch ohne Prognosen die Blöcke schließen: Sie tragen interne Zähler (Listen, ein
        # set), die nicht in JSON gehören -- ein früher Rücksprung ließ /forecast für einen
        # Coin ohne gespeicherte Prognosen mit HTTP 500 scheitern (gefunden 13.09.).
        for q in (out["q4"], out["q24"], out["q72"], out["q168"]):
            _quote_schliessen(q)
        return out
    errs = []
    cache: dict = {}
    now = time.time()

    def real_at(t):
        if t not in cache:
            # H4 (Audit v10): Bar muss frisch sein (≤ 120 s vor t), sonst gilt der Fall als "ohne Kurs" -- nach
            # einem Ausfall wurde vorher gegen einen Kurs von vor Stunden bewertet
            r = con_main.execute("SELECT close FROM bars WHERE coin=? AND ts<=? AND ts>=? ORDER BY ts DESC LIMIT 1", (coin, t, t - 120)).fetchone()
            cache[t] = r[0] if r and r[0] else None
        return cache[t]

    seen: set = set()
    q4, q24 = out["q4"], out["q24"]
    dv = {"v1": {"n": 0, "hits": 0, "_bs": []}, "v2": {"n": 0, "hits": 0, "_bs": []}, "enthalten_v2": 0}   # H6/K2: direkte Bewertung der Wahrscheinlichkeiten (4 h)
    for ts, p0, p4, p24, mp, ap, wv, pu4, pu24, pv2, pv1 in rows:
        if not p0:
            continue
        win = ts // 900
        if win in seen:
            continue
        seen.add(win)
        if p4 is not None and ts + 4 * 3600 <= now:
            real = real_at(ts + 4 * 3600)
            if real:
                u = urteil(p0, p4, real)
                if u == "offen":
                    q4["offen"] += 1
                elif u:
                    q4["n"] += 1; q4["hits"] += 1 if u == "treffer" else 0; q4["up"] += 1 if real > p0 else 0
                    q4["_bl"].add(ts // (4 * 3600))
                    if pu4 is not None:
                        yy = 1.0 if real > p0 else 0.0
                        q4["_bs"].append((pu4 - yy) ** 2); q4["_bs_p"] += yy
                    # direkte Bewertung: Ruf = Vorzeichen von p − 0,5, Enthaltung bei |p − 0,5| < 0,02
                    yy = 1.0 if real > p0 else 0.0
                    for key, pv in (("v1", pv1 if pv1 is not None else pu4), ("v2", pv2)):
                        if pv is None:
                            continue
                        pv = float(pv)
                        dv[key]["_bs"].append((pv - yy) ** 2)
                        if abs(pv - 0.5) >= 0.02:
                            dv[key]["n"] += 1; dv[key]["hits"] += 1 if ((pv > 0.5) == (yy > 0.5)) else 0
                        elif key == "v2":
                            dv["enthalten_v2"] += 1
        if p24 is not None and ts + 24 * 3600 <= now:
            real = real_at(ts + 24 * 3600)
            if real:
                u = urteil(p0, p24, real)
                if u == "offen":
                    q24["offen"] += 1
                elif u:
                    q24["n"] += 1; q24["hits"] += 1 if u == "treffer" else 0; q24["up"] += 1 if real > p0 else 0
                    q24["_bl"].add(ts // (24 * 3600))
                    errs.append(abs(p24 / real - 1) * 100)
                    if pu24 is not None:
                        yy = 1.0 if real > p0 else 0.0
                        q24["_bs"].append((pu24 - yy) ** 2); q24["_bs_p"] += yy
                if mp:
                    um = urteil(p0, mp, real)
                    if um and um != "offen":
                        out["model"]["n"] += 1; out["model"]["hits"] += 1 if um == "treffer" else 0
                if ap:
                    ua = urteil(p0, ap, real)
                    if ua and ua != "offen":
                        out["analog"]["n"] += 1; out["analog"]["hits"] += 1 if ua == "treffer" else 0
                if (wver is not None and wv is not None and abs(wv - wver) < 1 and u and u != "offen"):
                    out["oos"]["n"] += 1; out["oos"]["hits"] += 1 if u == "treffer" else 0
    # 72 h / 168 h: eine Prognose je Block, nur Richtung (Treffer gegen den Pfadpunkt)
    q72, q168 = out["q72"], out["q168"]
    seen_l: set = set()
    for ts, p0, p72, p168 in rows_lang:
        if not p0:
            continue
        win = ts // 3600
        if win in seen_l:
            continue
        seen_l.add(win)
        for h, pval, q in ((72, p72, q72), (168, p168, q168)):
            if pval is None or ts + h * 3600 > now:
                continue
            real = real_at(ts + h * 3600)
            if not real:
                continue
            u = urteil(p0, pval, real)
            if u == "offen":
                q["offen"] += 1
            elif u:
                q["n"] += 1; q["hits"] += 1 if u == "treffer" else 0; q["up"] += 1 if real > p0 else 0
                q["_bl"].add(ts // (h * 3600))
    for q in (q4, q24, q72, q168):
        _quote_schliessen(q)
    out["q72"]["kalibriert"] = False; out["q168"]["kalibriert"] = False       # Drift ohne gelernte Gewichte -- bis eine Spur dafür existiert
    for k in ("model", "analog", "oos"):
        blk = out[k]
        blk["hit_rate"] = blk["hits"] / blk["n"] if blk["n"] else None
        blk["n_eff"] = round(n_eff_of(blk["n"], 24), 1)
        ci = wilson(blk["hits"] / blk["n"] * blk["n_eff"], blk["n_eff"]) if blk["n"] and blk["n_eff"] >= 1 else None
        blk["ci"] = [round(ci[0], 3), round(ci[1], 3)] if ci else None
    # Abwärtskompatible Felder (Dashboard, check_report, check_forecast)
    out["n"], out["hits"], out["hit_rate"], out["offen"] = q24["n"], q24["hits"], q24["hit_rate"], q24["offen"]
    out["n_4h"], out["hits_4h"], out["offen_4h"] = q4["n"], q4["hits"], q4["offen"]
    if q4["n"]:
        out["hit_rate_4h"] = q4["hit_rate"]
    if errs:
        out["mae_pct"] = sum(errs) / len(errs)
    # H6/K2 (23.09.): direkte Bilanz der Wahrscheinlichkeiten -- v1 (altes Modell) und v2 (Schatten/aktiv)
    bu = (q4["up"] / q4["n"]) if q4.get("n") else None
    for key in ("v1", "v2"):
        d_ = dv[key]
        if d_["_bs"]:
            br = sum(d_["_bs"]) / len(d_["_bs"]); ref = (bu * (1 - bu)) if bu is not None else None
            out[f"direkt_{key}"] = {"n": d_["n"], "hit_rate": (d_["hits"] / d_["n"]) if d_["n"] else None, "brier": round(br, 4),
                                    "brier_skill": (round(1 - br / ref, 4) if ref and ref > 1e-9 else None), "n_brier": len(d_["_bs"])}
        else:
            out[f"direkt_{key}"] = None
    out["enthalten_v2"] = dv["enthalten_v2"]

    return out


# ---------------------------------------------------------------------------
# Selbstkalibrierung: Treibergewichte aus der eigenen Trefferbilanz lernen
# ---------------------------------------------------------------------------

PRIORS = {"MA 200 Tage": 0.8, "MA 50 Wochen": 0.6, "60-min-Trend": 0.5, "RSI 14 (1 h)": 0.5, "7-Tage-Drift": 0.4,
          "Direktionale Wale": 1.2, "Smart Money (direktional)": 1.0, "Käufe/Verkäufe 24 h (direktional)": 1.0,
          "Top-20-Trend 24 h": 0.6, "Taker-Flow": 0.7, "Funding": 0.4, "ETF-Flows": 0.6, "Orderbuch": 0.4,
          "Kapitulation": 0.5, "Analog-Suche": 0.8, "Wal-Flow 30 min": 1.3, "Leaderboard-Flow 60 min": 1.0,
          # Die Flow-Treiber für Hedge-, Market-Maker- und gemischte Konten sind gestrichen
          # (13.09., Sitzung 2): Ihre Fills tragen per Klassifikation keine Richtung, und jeder
          # Treiber kostet Freiheitsgrade, die auf 20 unabhängigen Beobachtungen knapp sind.
          # An ihre Stelle treten Treiber, die QUALITÄT statt Menge messen (hl_score):
          #   Smart-Flow 4 h        Fluss aller Konten, mit dem Konto-Score gewichtet (Wurzel des
          #                         Notionals, damit kein Einzelkonto das Signal ist)
          #   Elite-Positionierung  Netto-Ausrichtung der zehn besten Konten -- die reinste Form
          #                         der goldenen Regel
          #   Gegen-Flow            Fluss der Konten mit belegt NEGATIVEM Vorlauf, invertiert.
          #                         Experiment mit kleinem Prior; wenn Verlierer zufällig handeln,
          #                         ist das Rauschen, und die Kalibrierung parkt den Treiber.
          "Smart-Flow 4 h": 1.0, "Elite-Positionierung": 1.0, "Gegen-Flow": 0.3,
          # Coinbase-Spot: Nachfrage, die ohne Hebel bezahlt werden muss. Die Prämie gilt
          # als Anzeiger für US-Nachfrage, der Taker-Flow ist die direkte Messung, das
          # Orderbuch die schwächste der drei Größen. Ob die Erwartung stimmt, misst die
          # Selbstkalibrierung -- deshalb Startwerte, keine Festlegung.
          "Coinbase-Prämie": 0.8, "Spot-Taker-Flow": 0.7, "Spot-Orderbuch": 0.4}


# Horizonte, auf denen gelernt und bewertet wird.
#
# Warum zwei Spuren: Alle 15 Minuten entsteht eine Prognose, bewertet wird sie nach
# h Stunden. Zwei benachbarte Fenster teilen sich damit (h - 0,25) Stunden ihres
# Ergebnisses -- die Fenster sind NICHT unabhängig. Wie viel Information wirklich
# darin steckt, sagt n_eff = n_Fenster * 0,25 / h: bei 24 h ist es ein Sechsundneunzigstel
# der Fensterzahl (ein unabhängiger Fall je Tag), bei 4 h ein Sechzehntel (sechs je Tag).
# Die 4-h-Spur ist deshalb die Hauptspur des Lernens; 24 h braucht Monate, bis ein
# Gewicht dort mehr als Rauschen ist, und bleibt bis dahin Anzeige.
LERN_HORIZONTE = (4, 24)
HAUPT_HORIZONT = 4
MIN_N_EFF = 40            # Lernstart je Horizont: unabhängige Beobachtungen, nicht Fenster
# Ein Treiber darf erst ab so vielen eigenen unabhängigen Fällen vom Prior abweichen -- je
# Horizont gestaffelt: forecasts.db behält 60 Tage, die 24-h-Spur kann also nie mehr als
# rund 60 unabhängige Blöcke sehen. Mit 50 hätte sie faktisch nie gelernt (Re-Audit N1).
MIN_N_EFF_TREIBER = {4: 50, 24: 30}
# Höchstens so viele Fenster ins Training (Laufzeit auf dem Pi). Die 24-h-Spur nimmt ein
# Fenster je Stunde (TRAIN_STRIDE): Viertelstunden-Nachbarn tragen bei 24 h nichts Eigenes,
# und 60 Tage passen so in 1.440 Fenster statt 5.760.
MAX_TRAIN = {4: 2000, 24: 1500}
TRAIN_STRIDE = {4: 1, 24: 4}


def min_n_eff_treiber(horizon_h: int) -> int:
    return MIN_N_EFF_TREIBER.get(horizon_h, 50)
HALF_LIFE_DAYS = 14.0     # ältere Prognosen zählen weniger: der Markt wechselt das Regime
PRIORS.update(hl_indikatoren.PRIORS_NEU)      # Auditbericht v3: N3, N7, N8, N9, N1, N6 -- kleine Priors, Kalibrierung entscheidet
PRIOR_SUMME = sum(PRIORS.values())
# Ereignis-Treiber: liefern nur bei einem Ereignis einen Score (bedingt) oder tragen ein Ereignis-Signal.
# In der Tabelle stehen ALLE 30 Treiber; bei diesen zeigt eine Marke "EREIGNIS", wenn es anschlägt,
# sonst "kein Ereignis" mit dem Stand der Bedingung (Nutzer-Entscheidung 22.09.).
EREIGNIS_TREIBER = {"Kapitulation", "OI-Überhitzung", "Crowding-Extrem", "Vol-Spike-Reversion", "Liquidationsdruck (3 Börsen)",
                    "Wal-Flow 30 min", "Leaderboard-Flow 60 min"}
# Grund je Treiber, wenn er ohne eigene Meldung inaktiv ist (Bedingung aus der Formel, nicht geraten)
INAKTIV_GRUND = {
    "Leaderboard-Flow 60 min": "keine Leaderboard-Flussdaten (lb_events) geladen",
    "Top-20-Trend 24 h": "keine lb_trend-Zeile von vor 24 h",
    "Taker-Flow": "keine verwertbaren Taker-Verhältnisse (Fremdbörsen fehlen, Spanne < 60 s oder Verhältnis ≥ 9)",
    "Funding": "kein Funding-Wert jünger als 15 min",
    "Orderbuch": "kein Orderbuch-Stand jünger als 10 min",
    "MA 50 Wochen": "keine 50 Wochen Tageskerzen",
    "MA 200 Tage": "keine 200 Tageskerzen",
    "60-min-Trend": "zu wenige Stundenkerzen",
    "RSI 14 (1 h)": "zu wenige Stundenkerzen (14 nötig)",
    "7-Tage-Drift": "weniger als 168 Stundenkerzen",
    "ETF-Flows": "keine ETF-Daten (Farside) oder letzter Tag und 5-Tage-Summe mit verschiedenen Vorzeichen",
    "Analog-Suche": "noch nicht berechnet (stündlich) oder zu wenig Historie",
    "Direktionale Wale": "keine direktionalen Wale mit Position im Coin",
    "Spot-Orderbuch": "Coinbase-Tiefe unter 100k oder Dienst aus",
}
AKTIV_SCHWELLE = 0.05    # Stufe 1 (21.09.): ein Treiber zählt in der Bilanz ab |Score| > 0,05 (vorher 0,1) -- Funding/Vol-Spike laufen im Logit mit, gehören in die Bilanz

# Magnet-Schwelle: Ab welcher Größe gilt ein Liquidationscluster als Ziel des Pfadmodells?
#
# Sitzung 1 setzte "mindestens die Hälfte des Stundenvolumens, mindestens 5 Mio" -- eine
# Annahme, nie gemessen, und in der Prognose gegen das FUSIONIERTE Volumen gerechnet, sodass
# bei BTC praktisch kein Cluster je Magnet war. Seit 14.09.: ein Zehntel des HL-Stunden-
# volumens, mindestens 5 Mio -- ein Cluster von 10 Mio gegen 100 Mio Stundenumsatz ist
# erzwungener einseitiger Fluss an einem Preis, das ist die Größenordnung, um die es in
# diesem Projekt geht. Ob das die richtige Grenze ist, misst magnet_stats jetzt selbst:
# Lift (Berührquote gegen Placebo) je GRÖSSENKLASSE. Die Klasse, ab der der Lift über 1
# liegt, ist die richtige Schwelle -- dann wird dieser Wert nachgezogen, nicht geraten.
MAGNET_MIN_USD = 5e6
MAGNET_VOL_ANTEIL = 0.10
MAGNET_GROESSEN = ((0.05, "5-10 %"), (0.10, "10-25 %"), (0.25, "25-50 %"), (0.50, ">50 %"))   # Anteil am Stundenvolumen


def magnet_schwelle(vol_1h: float) -> float:
    return max((vol_1h or 0.0) * MAGNET_VOL_ANTEIL, MAGNET_MIN_USD)


def magnet_groessenklasse(usd: float, vol_1h: float) -> str | None:
    r = usd / vol_1h if vol_1h else 0.0
    kl = None
    for grenze, name in MAGNET_GROESSEN:
        if r >= grenze:
            kl = name
    return kl


def n_eff_of(n_windows: int, horizon_h: float) -> float:
    """
    Unabhängige Beobachtungen in n überlappenden 15-min-Fenstern bei h Stunden Horizont --
    Näherung für gleichmäßig verteilte Fenster. Wo die Fenster bekannt sind, ist
    n_eff_bloecke() vorzuziehen: Sie zählt getrennte Horizont-Blöcke und wird von geklumpten
    Fenstern (ein Ereignis-Treiber feuert acht Fenster lang) nicht getäuscht.
    """
    return n_windows * 0.25 / max(horizon_h, 0.25)


def n_eff_bloecke(ts_liste, horizon_h: float) -> int:
    """Zahl getrennter Blöcke von h Stunden, in die die Fenster fallen -- je Block ein Fall."""
    breite = max(int(horizon_h * 3600), 900)
    return len({int(t) // breite for t in ts_liste})


def wilson(hits: float, n: float, z: float = 1.96) -> tuple[float, float] | None:
    """Wilson-Intervall (95 %) einer Quote; n darf ein effektives, nicht ganzzahliges n sein."""
    if not n or n <= 0:
        return None
    p = hits / n
    den = 1 + z * z / n
    mid = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, mid - half), min(1.0, mid + half))


def _sigmoid(z: float) -> float:
    return 1 / (1 + math.exp(-_clip(z, -30, 30)))


def rang_in_reihe(wert: float, aktive: list, fenster: int = 168) -> float | None:
    """
    Perzentilrang von |wert| in der VOLLSTÄNDIGEN Stundenreihe: aktive Stunden plus so viele
    Nullstunden, dass `fenster` Stunden beisammen sind. "In dieser Stunde floss nichts" ist eine
    Beobachtung, kein fehlender Messwert -- aber ein Z-Wert wäre dafür das falsche Werkzeug
    (M9: Nullstunden nachzutragen ließ die Streuung schrumpfen und das Signal in 42 statt
    2 Prozent der Stunden feuern). Der Rang ist robust gegen die Nullflut.

    Achtung, Konstruktionseigenschaft: Ein Perzentil-Schwellwert feuert per Definition mit
    fester Rate (die obersten 2 % von 168 Stunden sind immer 3,4 Stunden je Woche). Deshalb
    gehört zu jedem Signal eine absolute Untergrenze und eine Breitenbedingung.
    """
    alle = list(aktive) + [0.0] * max(0, fenster - len(aktive))
    if len(alle) < 48:
        return None
    betrag = abs(wert)
    kleiner = sum(1 for v in alle if abs(v) < betrag)
    return kleiner / len(alle) * 100


def calibrate_weights(con_main, coin: str, path: str = STORE, min_n: float = MIN_N_EFF,
                      horizon_h: int = HAUPT_HORIZONT, meta: dict | None = None) -> dict:
    """
    Lernt je Treiber ein Gewicht aus den gespeicherten Prognosen: Logit der Richtung nach
    horizon_h Stunden auf die Treiberwerte, per Gradientenabstieg, mit L2-Zug zum Prior.
    Gewichte bleiben in [0, 2 x Prior]: ein Treiber wird nie umgedreht, nur auf- oder abgewertet.

    Modell: P(auf) = sigmoid(beta * sum_j w_j x_j / PRIOR_SUMME). beta ist ein gelernter
    Maßstab (Prior 1): Die Gewichte verteilen den Druck auf die Treiber, beta sagt, wie viel
    Wahrscheinlichkeit dieser Druck wert ist. Ohne beta wäre die Wahrscheinlichkeit aus 23
    zustimmenden Treibern rechnerisch 99 % -- das hat mit Kalibrierung nichts zu tun.

    Stichprobe: Die Regularisierung lam = 4 / n_eff hängt an der Zahl UNABHÄNGIGER
    Beobachtungen (getrennte Horizont-Blöcke, n_eff_bloecke), nicht an der Fensterzahl. Die
    alte Fassung teilte durch die Fensterzahl; bei 2.000 überlappenden Fenstern war lam = 0,002,
    der Prior damit praktisch abgeschafft, während die echte Information bei rund 20
    Beobachtungen lag. Ein Treiber verlässt seinen Prior erst ab MIN_N_EFF_TREIBER[h] eigenen
    unabhängigen Fällen (4 h: 50, 24 h: 30 -- die 24-h-Spur sieht in 60 Tagen Vorhalt nie
    mehr als ~60 Blöcke).

    Zwei Begrenzungen, damit das Lernen nicht mit der Zeit teuer und träge wird: höchstens
    MAX_TRAIN[h] Fenster (die jüngsten) und ein Alters-Gewicht mit 14 Tagen Halbwertszeit.
    Liefert {name: {prior, weight, n, n_eff, hit_rate, ci}}; meta (falls übergeben) bekommt
    h, n, n_eff, lam, beta, gelernt.
    """
    out = {name: {"prior": w, "weight": w, "n": 0, "n_eff": 0.0, "hit_rate": None, "ci": None}
           for name, w in PRIORS.items()}
    if meta is None:
        meta = {}
    meta.update({"h": horizon_h, "n": 0, "n_eff": 0.0, "lam": None, "beta": 1.0, "gelernt": False, "min_n_eff": min_n})
    h_s = horizon_h * 3600
    try:
        st = store_connect(path)
        rows = st.execute("SELECT ts, price, payload FROM forecast WHERE coin=? AND ts<=? ORDER BY ts",
                          (coin, int(time.time()) - h_s)).fetchall()
        st.close()
    except sqlite3.Error:
        return out
    X, y, sw, T = [], [], [], []; WV = []
    names = list(PRIORS)
    seen_win: set = set()
    now_ = time.time()
    max_train = MAX_TRAIN.get(horizon_h, 2000)
    schritt = 900 * TRAIN_STRIDE.get(horizon_h, 1)                 # 15 min (4 h) bzw. 60 min (24 h)
    # Rückwärts lesen und aufhören, sobald genug Fenster beisammen sind: die teure
    # Kursabfrage je Zeile läuft sonst über die ganze Historie.
    for ts, p0, payload in reversed(rows):
        if len(y) >= max_train:
            break
        win = ts // schritt                                         # eine Prognose je Fenster (15 min bzw. 1 h)
        if win in seen_win:
            continue
        seen_win.add(win)
        try:
            pl = json.loads(payload)
        except (TypeError, ValueError):
            continue
        r = con_main.execute("SELECT close FROM bars WHERE coin=? AND ts<=? ORDER BY ts DESC LIMIT 1", (coin, ts + h_s)).fetchone()
        if not r or not r[0] or not p0:
            continue
        label = 1.0 if r[0] > p0 else -1.0
        vec = {d["name"]: d["score"] for d in pl.get("drivers", [])}
        wver_row = pl.get("wver")                                        # Gewichtsversion der Prognose (F: OOS je Treiber)
        X.append([vec.get(n, 0.0) for n in names]); y.append(label); T.append(ts); WV.append(wver_row)
        sw.append(0.5 ** ((now_ - ts) / (HALF_LIFE_DAYS * 86_400)))     # Alters-Gewicht
    X.reverse(); y.reverse(); sw.reverse(); T.reverse(); WV.reverse()
    n = len(y)
    n_eff = float(n_eff_bloecke(T, horizon_h))
    meta.update({"n": n, "n_eff": round(n_eff, 1)})
    # Trefferquote je Treiber (Vorzeichen), unabhängig vom Logit -- mit effektivem n und Intervall.
    # n_eff je Treiber = getrennte Horizont-Blöcke, in denen der Treiber aktiv war.
    n_eff_j = [0.0] * len(names)
    wver_akt = max((wv for wv in WV if wv), default=None)          # laufende Gewichtsversion (F)
    pairs_wv = [[(x[j], yy, s_) for x, yy, s_, wv in zip(X, y, sw, WV) if abs(x[j]) > AKTIV_SCHWELLE] for j in range(len(names))]
    pairs_wver = [[wv for x, wv in zip(X, WV) if abs(x[j]) > AKTIV_SCHWELLE] for j in range(len(names))]
    for j, name in enumerate(names):
        pairs = [(x[j], yy, s_) for x, yy, s_ in zip(X, y, sw) if abs(x[j]) > AKTIV_SCHWELLE]
        out[name]["n"] = len(pairs)
        n_eff_j[j] = float(n_eff_bloecke([t for x, t in zip(X, T) if abs(x[j]) > AKTIV_SCHWELLE], horizon_h))
        out[name]["n_eff"] = round(n_eff_j[j], 1)
        if pairs:
            tot = sum(s_ for _, _, s_ in pairs) or 1.0
            hr = sum(s_ for sc, yy, s_ in pairs if sc * yy > 0) / tot
            out[name]["hit_rate"] = hr
            ci = wilson(hr * n_eff_j[j], n_eff_j[j]) if n_eff_j[j] >= 1 else None
            out[name]["ci"] = [round(ci[0], 3), round(ci[1], 3)] if ci else None
            # Änderung E (Audit v9 §5.3): Lift = Trefferquote minus Zufalls-Erwartung aus den
            # Randverteilungen der EIGENEN Fälle (q = Anteil Aufwärts-Rufe, p = Anteil Aufwärts-Ausgänge):
            # erwartet = q·p + (1−q)(1−p). Ein Treiber, der im Aufwärtstrend immer "auf" sagt, hat hohe
            # Quote und Lift null. z gegen SE der Differenz auf n_eff (kein Wilson: gepaarte Quoten).
            q = sum(s_ for sc, _, s_ in pairs if sc > 0) / tot
            pu = sum(s_ for _, yy, s_ in pairs if yy > 0) / tot
            erwartet = q * pu + (1 - q) * (1 - pu)
            lift = hr - erwartet
            se = math.sqrt(max(hr * (1 - hr), 0.0025) / max(n_eff_j[j], 1.0) + max(erwartet * (1 - erwartet), 0.0025) / max(n_eff_j[j], 1.0))
            out[name]["lift"] = round(lift, 3); out[name]["basis"] = round(erwartet, 3); out[name]["lift_z"] = round(lift / se, 2) if se > 0 else None
            # Änderung F: Out-of-sample je Treiber -- Fälle seit der laufenden Gewichtsversion, ab 25 Blöcken
            if wver_akt:
                oos = [(sc, yy, s_) for (sc, yy, s_), wv in zip(pairs_wv[j], pairs_wver[j]) if wv == wver_akt]
                n_oos = float(n_eff_bloecke([t for (x, t, wv) in zip(X, T, WV) if abs(x[j]) > AKTIV_SCHWELLE and wv == wver_akt], horizon_h))
                if n_oos >= 25 and oos:
                    tot_o = sum(s_ for _, _, s_ in oos) or 1.0
                    out[name]["oos"] = {"hit_rate": round(sum(s_ for sc, yy, s_ in oos if sc * yy > 0) / tot_o, 3), "n_eff": round(n_oos, 1)}
    if n_eff < min_n:
        return out
    # Logit: P(up) = sigmoid(beta * sum w_j x_j / PRIOR_SUMME); Verlust + lam * [sum (w_j - prior_j)^2 + (beta - 1)^2]
    # Nur Treiber trainieren, die vorkommen UND genug eigene unabhängige Fälle haben.
    schwelle = min_n_eff_treiber(horizon_h)
    active = [j for j in range(len(names)) if any(abs(x[j]) > 1e-9 for x in X) and n_eff_j[j] >= schwelle]
    meta["n_active"] = len(active); meta["min_n_eff_treiber"] = schwelle
    lam = 4.0 / max(n_eff, 1.0)
    meta["lam"] = round(lam, 4)
    w = [PRIORS[nm] for nm in names]
    if not active:
        meta["gelernt"] = False                                   # Spur bewertet, aber noch kein Treiber über der Schwelle
        return out
    Xa = [[x[j] for j in active] for x in X]
    wsum_ = sum(sw) or 1.0
    S = PRIOR_SUMME
    # Der Logit ist durch S normiert, der Gradient je Gewicht damit um 1/S kleiner als in der
    # früheren Fassung (lr 0,05 auf unnormierten Summen). Die Lernrate der Gewichte wird mit S
    # skaliert, damit der Schritt IM GEWICHTSRAUM je Einheit Fehler gleich bleibt (im Logit-Raum
    # ist er entsprechend der Normierung kleiner -- das ist beabsichtigt). beta bekommt eine
    # eigene, moderate Rate.
    lr = 0.05 * S; lr_b = 0.2
    wa = [w[j] for j in active]; pa = [PRIORS[names[j]] for j in active]
    # Beiträge der NICHT trainierten Treiber (sie stehen auf ihrem Prior) gehören trotzdem in den Logit
    fixed = [j for j in range(len(names)) if j not in active]
    zfix = [sum(PRIORS[names[j]] * x[j] for j in fixed) for x in X]
    beta = 1.0
    for _ in range(300):
        grad = [0.0] * len(active); gb = 0.0
        for x, yy, s_, zf in zip(Xa, y, sw, zfix):
            # Nenner KONSTANT (Audit v9 §3.1): Der Logit ist eine Evidenzsumme -- ein fehlender Treiber
            # ist ein Beleg mit Bayes-Faktor 1, Beitrag null. Ein Nenner je Fall (Stufe 1, verworfen)
            # hätte den Logit bei 2 aktiven Treibern um das 11-fache aufgebläht.
            lin = (sum(wj * xj for wj, xj in zip(wa, x)) + zf) / S
            pz = _sigmoid(beta * lin)
            err = (pz - (1.0 if yy > 0 else 0.0)) * s_
            for j in range(len(active)):
                grad[j] += err * beta * x[j] / S / wsum_
            gb += err * lin / wsum_
        step = 0.0
        for j in range(len(active)):
            grad[j] += 2 * lam * (wa[j] - pa[j])
            new = _clip(wa[j] - lr * grad[j], 0.0, 2 * pa[j])
            step = max(step, abs(new - wa[j])); wa[j] = new
        gb += 2 * lam * (beta - 1.0)
        nb = _clip(beta - lr_b * gb, 0.2, 4.0)
        step = max(step, abs(nb - beta)); beta = nb
        if step < 1e-4:                                   # ausgelernt, weitere Runden bringen nichts
            break
    for k, j in enumerate(active):
        w[j] = wa[k]
    for j, nm in enumerate(names):
        out[nm]["weight"] = round(w[j], 3)
    meta.update({"beta": round(beta, 3), "gelernt": True})
    return out


RESET_MARKE = "reset_2026_09_13_binance_fix"


def reset_weights_once(coin: str, path: str = STORE) -> bool:
    """
    Gelernte Gewichte einmalig verwerfen.

    Grund: Bis zum 13.09.2026 speiste ein Kapitulationssignal die Kalibrierung, das wegen
    eines Zeitstempel-Fehlers nie feuerte und nach dessen Behebung die Seiten vertauscht
    hätte; zugleich waren sämtliche Binance-Zeitfilter wirkungslos. Gewichte, die auf
    solchen Eingaben gelernt wurden, sind wertlos -- schlimmer noch, sie sehen belastbar
    aus. Die Marke in der Tabelle verhindert, dass der Reset sich wiederholt.
    """
    try:
        st = store_connect(path)
        st.execute("CREATE TABLE IF NOT EXISTS learned (coin TEXT, key TEXT, value TEXT, updated INTEGER, PRIMARY KEY (coin, key))")
        vorhanden = st.execute("SELECT 1 FROM learned WHERE coin=? AND key=?", (coin, RESET_MARKE)).fetchone()
        if vorhanden:
            st.close()
            return False
        n = st.execute("DELETE FROM weights WHERE coin=?", (coin,)).rowcount
        st.execute("DELETE FROM weights_h WHERE coin=?", (coin,))
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)",
                   (coin, RESET_MARKE, "1", int(time.time())))
        st.commit(); st.close()
        print(f"  Gewichte für {coin} zurückgesetzt ({n} Zeilen) — Kalibrierung beginnt neu beim Prior", flush=True)
        return True
    except sqlite3.Error:
        return False


def learned_weights_save(coin: str, weights: dict, path: str = STORE, bump: bool = True,
                         h: int = HAUPT_HORIZONT, meta: dict | None = None) -> None:
    """
    Gewichte eines Horizonts sichern (weights_h); die Hauptspur zusätzlich in `weights` spiegeln.
    `bump=False` behält den Zeitstempel der bisherigen Version bei: Die Version markiert die
    letzte NENNENSWERTE Änderung, nicht jede kleine Verschiebung. Sonst sprang sie alle
    15 Minuten, und die Out-of-sample-Quote blieb für immer leer.
    meta (beta, n_eff, lam) wandert in `learned` unter dem Schlüssel cal_<h>.
    """
    try:
        st = store_connect(path); now = int(time.time())
        alt = 0
        if not bump:
            r = st.execute("SELECT MAX(updated) FROM weights_h WHERE coin=? AND h=?", (coin, h)).fetchone()
            alt = int(r[0]) if r and r[0] else 0
        stamp = now if bump or not alt else alt
        st.executemany("INSERT OR REPLACE INTO weights_h VALUES (?,?,?,?,?,?,?,?,?)",
                       [(coin, h, nm, v["prior"], v["weight"], v.get("n", 0), v.get("n_eff", 0.0), v.get("hit_rate"), stamp)
                        for nm, v in weights.items()])
        st.executemany("INSERT OR REPLACE INTO weights_hist VALUES (?,?,?,?,?,?,?,?,?)",
                       [(coin, h, nm, v["prior"], v["weight"], v.get("n", 0), v.get("n_eff", 0.0), v.get("hit_rate"), stamp)
                        for nm, v in weights.items()])
        if h == HAUPT_HORIZONT:
            st.executemany("INSERT OR REPLACE INTO weights VALUES (?,?,?,?,?,?,?)",
                           [(coin, nm, v["prior"], v["weight"], v.get("n", 0), v.get("hit_rate"), stamp) for nm, v in weights.items()])
        if meta is not None:
            st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, f"cal_{h}", json.dumps(meta), now))
        # Änderung E/F (Audit v9): Lift und OOS je Treiber -- Statistik, kein Gewicht; landet neben den Gewichten
        stats = {nm: {k: v.get(k) for k in ("lift", "basis", "lift_z", "oos") if v.get(k) is not None} for nm, v in weights.items()}
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, f"cal_stats_{h}", json.dumps(stats), now))
        st.commit(); st.close()
    except sqlite3.Error:
        pass


def learned_weights_load(coin: str, path: str = STORE, h: int = HAUPT_HORIZONT) -> tuple[dict, float | None]:
    """Gelernte Gewichte eines Horizonts und ihre Version (Zeitpunkt der letzten Kalibrierung)."""
    try:
        st = store_connect(path)
        rows = st.execute("SELECT name, prior, weight, n, n_eff, hit_rate, updated FROM weights_h WHERE coin=? AND h=?", (coin, h)).fetchall()
        if not rows and h == HAUPT_HORIZONT:                        # Altbestand vor der Umstellung
            rows = [(r[0], r[1], r[2], r[3], None, r[4], r[5]) for r in
                    st.execute("SELECT name, prior, weight, n, hit_rate, updated FROM weights WHERE coin=?", (coin,)).fetchall()]
        st.close()
    except sqlite3.Error:
        return {}, None
    if not rows:
        return {}, None
    stats = {}
    try:
        st2 = store_connect(path)
        r2 = st2.execute("SELECT value FROM learned WHERE coin=? AND key=?", (coin, f"cal_stats_{h}")).fetchone(); st2.close()
        stats = json.loads(r2[0]) if r2 and r2[0] else {}
    except (sqlite3.Error, ValueError, TypeError):
        stats = {}
    def mit_ci(r):
        ci = wilson(r[5] * r[4], r[4]) if (r[5] is not None and r[4] and r[4] >= 1) else None
        d = {"prior": r[1], "weight": r[2], "n": r[3], "n_eff": r[4], "hit_rate": r[5],
             "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None}
        d.update(stats.get(r[0]) or {})
        return d
    return {r[0]: mit_ci(r) for r in rows}, float(rows[0][6])


def learned_cal_meta(coin: str, path: str = STORE, h: int = HAUPT_HORIZONT) -> dict:
    """Kalibrierungs-Kennzahlen (beta, n_eff, lam) des Horizonts, wie zuletzt gesichert."""
    try:
        st = store_connect(path)
        r = st.execute("SELECT value FROM learned WHERE coin=? AND key=?", (coin, f"cal_{h}")).fetchone(); st.close()
        return json.loads(r[0]) if r else {}
    except (sqlite3.Error, ValueError):
        return {}


def learned_save(coin: str, key: str, value, path: str = STORE) -> None:
    try:
        st = store_connect(path)
        st.execute("INSERT OR REPLACE INTO learned VALUES (?,?,?,?)", (coin, key, json.dumps(value), int(time.time()))); st.commit(); st.close()
    except sqlite3.Error:
        pass


def _intkeys(d):
    """JSON macht aus Zahlen-Schlüsseln Text (24 -> "24"); hier zurück, wo es Horizonte sind."""
    if isinstance(d, dict) and d and all(isinstance(k, str) and k.lstrip("-").isdigit() for k in d):
        return {int(k): v for k, v in d.items()}
    return d


def learned_load(coin: str, key: str, max_age: int, path: str = STORE):
    try:
        st = store_connect(path)
        r = st.execute("SELECT value, updated FROM learned WHERE coin=? AND key=?", (coin, key)).fetchone(); st.close()
    except sqlite3.Error:
        return None
    if not r or time.time() - r[1] > max_age:
        return None
    try:
        val = json.loads(r[0])
    except ValueError:
        return None
    if key == "analog" and isinstance(val, dict) and isinstance(val.get("ret"), dict):
        val["ret"] = _intkeys(val["ret"])
    return val


# ---------------------------------------------------------------------------
# Hilfen
# ---------------------------------------------------------------------------

def _clip(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def _num(x, key: str | None = None):
    """Zahl aus Wert oder Datensatz: funding kommt aus Hyperliquid als {ts, funding, oi}, von Binance als Zahl."""
    if isinstance(x, dict):
        x = x.get(key) if key else None
    try:
        return float(x) if x is not None else None
    except (TypeError, ValueError):
        return None


def realized_vol(candles: list[dict]) -> float:
    """Stunden-Volatilität (Standardabweichung der Log-Renditen der Stundenkerzen)."""
    rets = []
    for a, b in zip(candles[:-1], candles[1:]):
        if a["c"] and b["c"]:
            rets.append(math.log(b["c"] / a["c"]))
    if len(rets) < 12:
        return 0.006                                     # Rückfall: 0,6 % je Stunde
    m = sum(rets) / len(rets)
    var = sum((r - m) ** 2 for r in rets) / max(1, len(rets) - 1)
    return _clip(math.sqrt(var), 0.002, 0.03)


def lb_groups(con, coin: str | None = None) -> dict:
    """
    Verhaltensklasse der Leaderboard-Konten -- wie bei den Walen JE COIN, wenn einer angegeben ist.

    Ein Konto, das BTC short und ETH long hält, ist kontoweit "gemischt", in BTC aber klar
    positioniert. Für ein coinbezogenes Signal zählt das Verhalten in diesem Coin. Ohne `coin`
    wird kontoweit klassifiziert (für Übersichten). Gruppen: dir, hedge, mixed.
    """
    try:
        last = con.execute("SELECT MAX(ts) FROM lb_positions").fetchone()[0]
        if not last:
            return {}
        per: dict = {}
        for addr, c, side, lev in con.execute("SELECT addr, coin, side, leverage FROM lb_positions WHERE ts=?", (last,)):
            d = per.setdefault(addr, {"coins": set(), "sides": set(), "lev": 0.0})
            d["coins"].add(c); d["sides"].add(side); d["lev"] = max(d["lev"], _num(lev) or 0.0)
    except sqlite3.OperationalError:
        return {}
    out = {}
    for addr, d in per.items():
        if len(d["coins"]) >= 3 and len(d["sides"]) == 1 and d["lev"] <= 10:
            out[addr] = "hedge"                          # viele Coins, eine Seite, wenig Hebel
        elif len(d["sides"]) == 2 and len(d["coins"]) >= 2:
            # kontoweit gemischt -- mit Coin-Bezug zählt es trotzdem als direktional,
            # denn in diesem Coin hält es genau eine Seite
            out[addr] = "dir" if coin and coin in d["coins"] else "mixed"
        else:
            out[addr] = "dir"
    return out


def lb_directional_addrs(con, coin: str | None = None) -> set[str]:
    """Leaderboard-Konten, die in diesem Coin direktional sind."""
    return {a for a, g in lb_groups(con, coin).items() if g == "dir"}


# ---------------------------------------------------------------------------
# Analog-Suche: die ähnlichsten Momente der Kurshistorie und was danach geschah
# ---------------------------------------------------------------------------

def _fold_30m(rows) -> list[tuple[int, float]]:
    """Beliebige (ts, close)-Reihe auf 30-Minuten-Schlusskurse falten."""
    out = []; cur = None
    for ts, c in rows:
        b = ts // 1800 * 1800
        if cur is None or cur[0] != b:
            if cur:
                out.append(cur)
            cur = (b, c)
        else:
            cur = (b, c)
    if cur:
        out.append(cur)
    return out


def _series_30m(con, coin: str) -> list[tuple[int, float]]:
    """
    30-min-Schlusskurse bis JETZT: die Historie aus klines30 (bis zu 3 Jahre, von
    hl_timestats einmalig geladen), danach angestückelt aus bnc_bars und den eigenen Bars.

    Ohne das Anstückeln endete die Reihe dort, wo hl_timestats zuletzt lief -- gemessen
    acht Tage in der Vergangenheit. Die Analog-Suche verglich dann den Zustand von vor acht
    Tagen mit der Historie und lieferte Analoge zu einem Markt, den es nicht mehr gibt.
    """
    hist = []
    try:
        hist = [(r[0], r[1]) for r in con.execute("SELECT ts, close FROM klines30 WHERE coin=? ORDER BY ts", (coin,))]
    except sqlite3.OperationalError:
        hist = []
    letzte = hist[-1][0] if hist else 0
    neu = []
    for table in ("bnc_bars", "bars"):
        try:
            rows = con.execute(f"SELECT ts, close FROM {table} WHERE coin=? AND ts>? ORDER BY ts",
                               (coin, letzte)).fetchall()
        except sqlite3.OperationalError:
            continue
        if rows:
            neu = _fold_30m(rows)
            break
    reihe = hist + [r for r in neu if r[0] > letzte]
    if len(reihe) >= 400:
        return reihe
    # keine Historie: aus den eigenen Bars falten
    for table in ("bnc_bars", "bars"):
        try:
            rows = con.execute(f"SELECT ts, close FROM {table} WHERE coin=? ORDER BY ts", (coin,)).fetchall()
        except sqlite3.OperationalError:
            continue
        gefaltet = _fold_30m(rows)
        if len(gefaltet) >= 400:
            return gefaltet
    return reihe


def series_age(con, coin: str) -> tuple[int, int]:
    """(Anzahl Punkte, Alter des letzten Punktes in Sekunden) -- für die Diagnose."""
    r = _series_30m(con, coin)
    return (len(r), int(time.time() - r[-1][0]) if r else -1)


def _feature_table(closes: list[float], ts_list: list[int]) -> list:
    """
    Zustandsvektoren für alle Indizes in einem Durchgang (Präfixsummen statt Fensterschleifen --
    auf dem Pi zählt das): Renditen 1/7/30 Tage, 3-Tage-Volatilität, RSI 14, Lage zum 7-Tage-Mittel,
    Tageszeit (sin/cos), Wochentag. None, wo der Vorlauf fehlt.
    """
    n = len(closes)
    lg = [math.log(c) if c > 0 else 0.0 for c in closes]
    r = [0.0] + [lg[i] - lg[i - 1] for i in range(1, n)]
    cs = [0.0] * (n + 1); cs2 = [0.0] * (n + 1); cc = [0.0] * (n + 1); gain = [0.0] * (n + 1); loss = [0.0] * (n + 1)
    for i in range(n):
        cs[i + 1] = cs[i] + r[i]; cs2[i + 1] = cs2[i] + r[i] * r[i]; cc[i + 1] = cc[i] + closes[i]
        d = closes[i] - closes[i - 1] if i else 0.0
        gain[i + 1] = gain[i] + (d if d > 0 else 0.0); loss[i + 1] = loss[i] + (-d if d < 0 else 0.0)
    out = [None] * n
    for i in range(1440, n):
        r1d, r7d, r30d = lg[i] - lg[i - 48], lg[i] - lg[i - 336], lg[i] - lg[i - 1440]
        m = (cs[i + 1] - cs[i - 144]) / 145; v = (cs2[i + 1] - cs2[i - 144]) / 145 - m * m
        vol3d = math.sqrt(max(v, 0.0))
        g = gain[i + 1] - gain[i - 13]; l = loss[i + 1] - loss[i - 13]
        rsi = 100.0 if l == 0 else 100 - 100 / (1 + g / l)
        sma7 = (cc[i + 1] - cc[i - 335]) / 336
        hod = (ts_list[i] % 86400) / 86400 * 2 * math.pi; wd = (ts_list[i] // 86400 + 3) % 7      # 0 = Montag
        out[i] = [r1d / 0.03, r7d / 0.08, r30d / 0.15, vol3d / 0.004, (rsi - 50) / 25, math.log(closes[i] / sma7) / 0.05,
                  math.sin(hod) * 0.5, math.cos(hod) * 0.5, (wd - 3) / 3 * 0.5]
    return out


def analog_forecast(con, coin: str, k: int = 50, min_gap: int = 12) -> dict | None:
    """
    Die k ähnlichsten Momente der Historie (Euklid auf standardisierten Merkmalen), mindestens
    min_gap Halbstunden auseinander, die letzten 7 Tage ausgeschlossen (kein Blick in die Zukunft).
    Liefert je Horizont Median und 20/80-Quantile der folgenden Renditen.
    """
    ser = _series_30m(con, coin)
    if len(ser) < 2000:
        return None
    ts_list = [t for t, _ in ser]; closes = [c for _, c in ser]
    n = len(closes); horizons = {4: 8, 12: 24, 24: 48, 72: 144, 168: 336}
    now_i = n - 1
    F = _feature_table(closes, ts_list)
    cur = F[now_i]
    if cur is None:
        return None
    cands = []
    last_ok = now_i - 336 - 336                                     # 7 Tage Zukunft + 7 Tage Abstand
    for i in range(1440, last_ok, 2):
        f = F[i]
        if f is None:
            continue
        d = math.sqrt(sum((a - b) ** 2 for a, b in zip(f, cur)))
        cands.append((d, i))
    cands.sort()
    picked = []
    for d, i in cands:
        if all(abs(i - j) >= min_gap for _, j in picked):
            picked.append((d, i))
        if len(picked) >= k:
            break
    if len(picked) < 15:
        return None
    out = {"n": len(picked), "n_hist": n, "span_days": (ts_list[-1] - ts_list[0]) / 86400,
           "last_age_h": (time.time() - ts_list[-1]) / 3600, "ret": {}, "examples": []}
    for h, steps in horizons.items():
        rets = sorted(math.log(closes[i + steps] / closes[i]) for _, i in picked if i + steps < n)
        if not rets:
            continue
        q = lambda p: rets[min(len(rets) - 1, int(p * len(rets)))]
        ups = sum(1 for r in rets if r > 0)
        # Unbedingte Basisrate derselben Historie: Wie oft ging es in h Stunden ohnehin aufwärts?
        # Ein p_up von 0,57 aus 50 Analogen (Streuung ±7 Punkte) ist erst gegen diese Zahl lesbar.
        base_n = 0; base_up = 0
        for i in range(1440, n - steps, max(1, steps // 2)):
            base_n += 1; base_up += 1 if closes[i + steps] > closes[i] else 0
        ci = wilson(ups, len(rets))
        out["ret"][h] = {"med": q(0.5), "q20": q(0.2), "q80": q(0.8), "p_up": ups / len(rets),
                         "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None,
                         "p_up_base": (base_up / base_n) if base_n else None}
    out["examples"] = [{"ts": ts_list[i], "dist": round(d, 2), "r24": math.log(closes[min(n - 1, i + 48)] / closes[i])} for d, i in picked[:5]]
    out["mean_dist"] = sum(d for d, _ in picked) / len(picked)
    return out


# ---------------------------------------------------------------------------
# Zeitprofil der Volatilität (Wochentag x Stunde) und Magnet-Statistik aus den Snapshots
# ---------------------------------------------------------------------------

MAGNET_VARIANTEN = (("0.5-1", 0.005, 0.01), ("1-2", 0.01, 0.02))     # Name, Abstand von .. bis (Anteil)
MAGNET_HORIZONTE = (4, 8, 12, 24)                                    # Stunden


def magnet_varianten(con, coin: str, days: int = 14, min_usd: float | None = None) -> dict | None:
    """
    Ziehen Liquidationscluster den Kurs an? Zwei Abstandsvarianten (0,5-1 % und 1-2 % vom
    Kurs), vier Horizonte (4, 8, 12, 24 h), drei Messgrößen je Zelle -- nach der Literatur:

      Lift        Berührquote des Clusters gegen ein Placebo-Niveau in gleichem Abstand auf der
                  anderen Seite, zum selben Zeitpunkt (Placebo-Prinzip wie magnet_stats). 1,0 =
                  das Cluster zieht nicht stärker an als der Zufall. Wilson-Intervall auf n_eff.
      Anziehung   mittlere Kursbewegung ZUM Cluster nach h Stunden (Anteil des Abstands, den der
                  Kurs zurücklegt), abzüglich dessen, was die Marktdrift derselben Tage ohnehin
                  in diese Richtung beigetragen hätte -- Überschuss in Prozent des Kurses, mit
                  t-Wert auf n_eff. (Sinn: Avellaneda/Lipkin -- ein Niveau mit Exposure erzeugt
                  einen Drift zum Niveau; Brunnermeier/Pedersen -- Händler drücken dorthin.)
      Näher       Anteil der Fälle, in denen der Kurs nach h Stunden näher am Cluster steht als
                  zu Beginn, gegen denselben Anteil für das Placebo-Niveau.
      Cho 15 min  bedingte Wahrscheinlichkeit, dass sich der Kurs in den NÄCHSTEN 15 Minuten zum
                  Cluster bewegt, solange er im Abstandsband steht, gegen die unbedingte
                  Wahrscheinlichkeit derselben Richtung (Cho/Russell/Tiao/Tsay 2003: der
                  Magnet-Effekt als Anstieg der bedingten Wahrscheinlichkeit mit sinkendem Abstand).

    Unabhängigkeit: je Niveau nur ein Ereignis je 24 h (Dedup wie magnet_stats), n_eff je
    Horizont = getrennte h-Stunden-Blöcke. Cluster ab min_usd (Vorgabe: 5 Mio). Ergebnis:
    {variante: {h: {...}, "cho15": {...}, "n": ..}, "meta": {...}} oder None bei zu wenig Daten.
    """
    now = int(time.time()); since = now - days * 86400
    min_usd = MAGNET_MIN_USD if min_usd is None else min_usd
    try:
        snaps = con.execute("SELECT ts, bucket_px, side, notional FROM heatmap WHERE coin=? AND ts>=? AND notional>=? ORDER BY ts",
                            (coin, since, min_usd)).fetchall()
        bars = con.execute("SELECT ts, high, low, close FROM bars WHERE coin=? AND ts>=? ORDER BY ts", (coin, since - 3600)).fetchall()
    except sqlite3.OperationalError:
        return None
    if len(snaps) < 200 or len(bars) < 720:
        return None
    import bisect
    b_ts = [b[0] for b in bars]
    def price_at(t):
        i = bisect.bisect_right(b_ts, t) - 1
        return bars[i][3] if i >= 0 and t - b_ts[i] <= 120 else None    # H4: nur frische Bar (≤ 120 s)
    def window(t0, t1):
        i = bisect.bisect_left(b_ts, t0); j = bisect.bisect_right(b_ts, t1)
        return bars[i:j]
    H = max(MAGNET_HORIZONTE) * 3600
    # Marktdrift derselben Tage je Horizont (alle 15 min ein Punkt) -- Basis für den Überschuss
    drift = {}; p_up15 = None
    for h in MAGNET_HORIZONTE:
        acc = []
        t = b_ts[0]
        while t + h * 3600 <= b_ts[-1]:
            p0 = price_at(t); p1 = price_at(t + h * 3600)
            if p0 and p1:
                acc.append(p1 / p0 - 1)
            t += 900
        drift[h] = sum(acc) / len(acc) if acc else 0.0
    acc = []
    t = b_ts[0]
    while t + 900 <= b_ts[-1]:
        p0 = price_at(t); p1 = price_at(t + 900)
        if p0 and p1 and p1 != p0:
            acc.append(1 if p1 > p0 else 0)
        t += 900
    p_up15 = sum(acc) / len(acc) if acc else 0.5
    by_ts: dict = {}
    for ts, px, side, usd in snaps:
        by_ts.setdefault(ts, []).append((px, side, usd))
    out: dict = {}
    for name, lo, hi in MAGNET_VARIANTEN:
        zellen = {h: {"n": 0, "touch": 0, "placebo": 0, "naeher": 0, "naeher_pl": 0, "bew": [], "signs": [], "bl": set()} for h in MAGNET_HORIZONTE}
        cho = {"n": 0, "zum": 0, "sign": []}
        gesehen: dict = {}
        for ts in sorted(by_ts):
            if ts + H > now:
                continue                                  # noch kein vollständiges 24-h-Ergebnis
            p0 = price_at(ts)
            if not p0:
                continue
            for px, side, usd in by_ts[ts]:
                dist = px / p0 - 1
                up = dist > 0
                if not (lo <= abs(dist) < hi):
                    continue
                if (up and side != "short") or ((not up) and side != "long"):
                    continue                              # Cluster auf der "falschen" Seite: kein Liquidationsziel
                stelle = -int(math.floor(math.log10(max(px, 1)))) + 3
                key = (side, round(px, stelle))
                # Cho: jeder 15-min-Schnappschuss im Band zählt (kaum Überlappung bei 15 min)
                p15 = price_at(ts + 900)
                if p15 and p15 != p0:
                    cho["n"] += 1; cho["zum"] += 1 if ((p15 > p0) == up) else 0; cho["sign"].append(1 if up else -1)
                letzte = gesehen.get(key)
                if letzte is not None and ts - letzte < 24 * 3600:
                    continue                              # dasselbe Niveau binnen 24 h: ein Ereignis
                gesehen[key] = ts
                mirror = p0 * (1 - dist)
                for h in MAGNET_HORIZONTE:
                    w = window(ts, ts + h * 3600)
                    if not w:
                        continue
                    z = zellen[h]; z["n"] += 1; z["bl"].add(ts // (h * 3600))
                    z["touch"] += 1 if any((up and b[1] >= px) or (not up and b[2] <= px) for b in w) else 0
                    z["placebo"] += 1 if any((up and b[2] <= mirror) or (not up and b[1] >= mirror) for b in w) else 0
                    ph = price_at(ts + h * 3600) or w[-1][3]
                    z["naeher"] += 1 if abs(ph - px) < abs(p0 - px) else 0
                    z["naeher_pl"] += 1 if abs(ph - mirror) < abs(p0 - mirror) else 0
                    z["bew"].append((ph / p0 - 1) * (1 if up else -1)); z["signs"].append(1 if up else -1)
        res: dict = {"n": 0}
        for h, z in zellen.items():
            n = z["n"]
            if n < 3:
                res[h] = {"n": n, "n_eff": len(z["bl"])}
                continue
            n_eff = max(1, len(z["bl"]))
            p_t = z["touch"] / n; p_pl = z["placebo"] / n
            ci = wilson(p_t * n_eff, n_eff)
            mean_bew = sum(z["bew"]) / n
            basis = (sum(z["signs"]) / n) * drift[h]                     # was die Drift in Richtung Cluster beigetragen hätte
            ueber = mean_bew - basis
            sd = (sum((x - mean_bew) ** 2 for x in z["bew"]) / max(1, n - 1)) ** 0.5
            t_wert = (ueber / (sd / math.sqrt(n_eff))) if sd > 0 else 0.0
            # Differenz statt Quotient als Hauptmaß: Bei kleinem n ist der Lift (ein Quotient mit
            # rauschendem Nenner) nach oben verzerrt -- acht Seeds reines Rauschen ergaben Ø 1,15.
            # Die Differenz der Quoten ist unverzerrt; z = Differenz / Standardfehler auf n_eff.
            se = math.sqrt(max(p_t * (1 - p_t), 0.0) / n_eff + max(p_pl * (1 - p_pl), 0.0) / n_eff)
            res[h] = {"n": n, "n_eff": n_eff, "p_touch": round(p_t, 3), "p_placebo": round(p_pl, 3),
                      "delta_pp": round((p_t - p_pl) * 100, 1), "z_delta": round((p_t - p_pl) / se, 2) if se > 0 else None,
                      "lift": round(p_t / p_pl, 2) if p_pl > 0 else None,
                      "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None,
                      "anziehung_pct": round(ueber * 100, 3), "t": round(t_wert, 2),
                      "naeher": round(z["naeher"] / n, 3), "naeher_placebo": round(z["naeher_pl"] / n, 3)}
            res["n"] = max(res["n"], n)
        if cho["n"] >= 20:
            p_zum = cho["zum"] / cho["n"]
            anteil_up = sum(1 for s_ in cho["sign"] if s_ > 0) / len(cho["sign"])
            basis15 = anteil_up * p_up15 + (1 - anteil_up) * (1 - p_up15)  # unbedingt "in Richtung Cluster"
            ci = wilson(cho["zum"], cho["n"])
            res["cho15"] = {"n": cho["n"], "p_zum": round(p_zum, 3), "basis": round(basis15, 3),
                            "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None}
        out[name] = res
    out["meta"] = {"days": days, "min_usd": min_usd, "drift": {h: round(v * 100, 3) for h, v in drift.items()}, "p_up15": round(p_up15, 3),
                   "ts": now}
    return out


def time_vol_profile(con, coin: str, days: int = 180) -> dict | None:
    """
    Relative Volatilität je (Wochentag, Stunde) aus den 30-min-Kerzen; 1,0 = Durchschnitt.
    Rollierend über `days` Tage: Über die gesamte Historie gerechnet mittelt das Profil
    Regimewechsel aus (ETF-Zeiten, Asien-Sitzungen verschieben sich über Jahre).
    """
    ser = _series_30m(con, coin)
    if len(ser) < 2000:
        return None
    cut = ser[-1][0] - days * 86400
    ser = [x for x in ser if x[0] >= cut] or ser
    acc: dict = {}
    for (t0, c0), (t1, c1) in zip(ser[:-1], ser[1:]):
        if c0 > 0 and c1 > 0:
            g = time.gmtime(t1); key = f"{g.tm_wday}-{g.tm_hour}"
            acc.setdefault(key, []).append(abs(math.log(c1 / c0)))
    if not acc:
        return None
    means = {k: sum(v) / len(v) for k, v in acc.items() if len(v) >= 20}
    if len(means) < 24:                      # zu wenig Historie je (Wochentag, Stunde): kein Profil statt Division durch null
        return None
    avg = sum(means.values()) / len(means)
    return {k: round(v / avg, 3) for k, v in means.items()}


def magnet_stats(con, coin: str, days: int = 14) -> dict | None:
    """
    Aus Heatmap-Snapshots (alle 15 min) und Bars: Wie oft wurde ein großes Cluster innerhalb 12 h
    erreicht, wenn der Kurs ihm auf <= 3 % nahe kam? Wie weit ging es darüber hinaus (Überschuss)?
    Wie viel der Bewegung kam binnen 12 h zurück? Getrennt nach Abstandsklassen.
    """
    now = int(time.time()); since = now - days * 86400
    try:
        # ein Snapshot je 15 min: erst die Zeitpunkte, dann nur diese Zeilen (der Snapshot-Takt ist nicht am Raster ausgerichtet)
        all_ts = [r[0] for r in con.execute("SELECT DISTINCT ts FROM heatmap WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts", (coin, since, now - 12 * 3600))]
        picked_ts = []; last_b = None
        for t in all_ts:
            b = t // 900
            if b != last_b:
                picked_ts.append(t); last_b = b
        snaps = []
        for i in range(0, len(picked_ts), 400):
            chunk = picked_ts[i:i + 400]
            snaps.extend(con.execute(f"SELECT ts, bucket_px, side, notional FROM heatmap WHERE coin=? AND ts IN ({','.join('?' * len(chunk))})",
                                     (coin, *chunk)).fetchall())
        bars = con.execute("SELECT ts, high, low, close FROM bars WHERE coin=? AND ts>=? ORDER BY ts", (coin, since)).fetchall()
        vol = con.execute("SELECT AVG(v) FROM (SELECT SUM(volume*close) v FROM bars WHERE coin=? AND ts>=? GROUP BY ts/3600)", (coin, since)).fetchone()[0] or 0
    except sqlite3.OperationalError:
        return None
    if len(snaps) < 200 or len(bars) < 720:
        return None
    b_ts = [b[0] for b in bars]
    import bisect
    def price_at(t):
        i = bisect.bisect_right(b_ts, t) - 1
        return bars[i][3] if i >= 0 and t - b_ts[i] <= 120 else None    # H4: nur frische Bar (≤ 120 s)
    def window(t0, t1):
        i = bisect.bisect_left(b_ts, t0); j = bisect.bisect_right(b_ts, t1)
        return bars[i:j]
    by_ts: dict = {}
    for ts, px, side, usd in snaps:
        if usd >= MAGNET_MIN_USD:                          # alle ab 5 Mio: die Größenklassen brauchen auch die kleinen
            by_ts.setdefault(ts, []).append((px, side, usd))
    schwelle = magnet_schwelle(vol)
    stats: dict = {}
    # Jedes Cluster nur EINMAL zählen.
    #
    # Die Schnappschüsse kommen alle 15 Minuten, die Beobachtungsfenster sind 12 Stunden
    # lang -- dasselbe Cluster tauchte damit in bis zu 48 aufeinanderfolgenden Schnappschüssen
    # auf und wurde 48-mal gezählt. Das Ergebnis sah nach einer großen Stichprobe aus
    # (im Test n = 1.295), bestand aber aus einer Handvoll unabhängiger Ereignisse. Die
    # daraus abgeleiteten Größen -- Berührwahrscheinlichkeit, Überschuss, Rücklauf --
    # fließen direkt in die Pfadlogik der Prognose; eine aufgeblähte Stichprobe täuscht
    # dort eine Sicherheit vor, die es nicht gibt.
    #
    # Als dasselbe Ereignis gilt: gleiche Seite, Preis im selben Promille-Raster, und
    # der Beginn liegt innerhalb des noch laufenden 12-Stunden-Fensters des ersten
    # Auftretens. Erst danach zählt dasselbe Preisniveau wieder als neue Gelegenheit.
    gesehen: dict = {}
    for ts in sorted(by_ts):
        clusters = by_ts[ts]
        p0 = price_at(ts)
        if not p0:
            continue
        w = window(ts, ts + 12 * 3600)
        if len(w) < 60:
            continue
        for px, side, usd in clusters:
            dist = px / p0 - 1
            if abs(dist) > 0.03 or abs(dist) < 0.001:
                continue
            up = dist > 0
            # Preisraster: rund ein Promille, damit leicht wandernde Cluster als
            # dasselbe Niveau gelten (77.000 und 77.004 ja, 77.000 und 77.100 nein).
            stelle = -int(math.floor(math.log10(max(px, 1)))) + 3
            schluessel = (side, round(px, stelle))
            letzte = gesehen.get(schluessel)
            if letzte is not None and ts - letzte < 12 * 3600:
                continue                       # noch dasselbe Ereignis, nicht erneut zählen
            gesehen[schluessel] = ts
            # Zwei Sichten auf dasselbe Ereignis: nach Abstand (nur Cluster über der Schwelle --
            # das ist die Population, die das Pfadmodell nutzt) und nach GRÖSSE (alle ab 5 Mio --
            # daraus wird gemessen, wo die Schwelle liegen sollte).
            ziele = []
            if usd >= schwelle:
                ziele.append("0-1" if abs(dist) < 0.01 else "1-2" if abs(dist) < 0.02 else "2-3")
            gk = magnet_groessenklasse(usd, vol)
            if gk:
                ziele.append("g:" + gk)
            if not ziele:
                continue
            sts = []
            for k in ziele:
                st = stats.setdefault(k, {"n": 0, "touched": 0, "placebo": 0, "overshoot": [], "retrace": [], "bloecke": set()})
                st["n"] += 1
                st["bloecke"].add(ts // (12 * 3600))   # unabhängige Fälle: höchstens einer je 12-h-Block
                sts.append(st)
            # Placebo: dasselbe Niveau in gleichem Abstand auf der ANDEREN Seite, zum selben
            # Zeitpunkt. Ohne diesen Vergleich ist "41 % berührt" keine Aussage -- wenn der Kurs
            # in 12 h ohnehin in 60 % der Fälle 1 % zurücklegt, ist das Cluster kein Magnet.
            # Ausgewiesen wird der Lift p_touch / p_placebo.
            mirror = p0 * (1 - dist)
            for b in w:
                if (up and b[2] <= mirror) or (not up and b[1] >= mirror):
                    for st in sts:
                        st["placebo"] += 1
                    break
            touched_at = None
            for b in w:
                if (up and b[1] >= px) or (not up and b[2] <= px):
                    touched_at = b[0]; break
            if touched_at is None:
                continue
            for st in sts:
                st["touched"] += 1
            after = window(touched_at, touched_at + 4 * 3600)
            if up:
                ext = max(b[1] for b in after); over = ext / px - 1
                back = window(touched_at, touched_at + 12 * 3600); low = min(b[2] for b in back)
                ret = (ext - low) / max(ext - p0, 1e-9)
            else:
                ext = min(b[2] for b in after); over = 1 - ext / px
                back = window(touched_at, touched_at + 12 * 3600); high = max(b[1] for b in back)
                ret = (high - ext) / max(p0 - ext, 1e-9)
            for st in sts:
                st["overshoot"].append(max(0.0, over)); st["retrace"].append(_clip(ret, 0, 1.5))
    out = {}
    for cls, st in stats.items():
        if st["n"] >= 5:
            p_t = st["touched"] / st["n"]; p_b = st["placebo"] / st["n"]
            # Intervall auf der Zahl getrennter 12-h-Blöcke: Ereignisse innerhalb eines Blocks
            # teilen sich denselben Kursverlauf und sind keine eigenen Beobachtungen.
            n_eff = len(st["bloecke"])
            ci = wilson(p_t * n_eff, n_eff)
            out[cls] = {"n": st["n"], "n_eff": n_eff, "p_touch": p_t, "p_placebo": p_b,
                        "lift": (p_t / p_b) if p_b > 0 else None,
                        "ci": [round(ci[0], 3), round(ci[1], 3)] if ci else None,
                        "overshoot": sorted(st["overshoot"])[len(st["overshoot"]) // 2] if st["overshoot"] else 0.0,
                        "retrace": sorted(st["retrace"])[len(st["retrace"]) // 2] if st["retrace"] else 0.3}
    return out or None


def capitulation_signal(con, coin: str) -> dict | None:
    """
    Kapitulation: großer Schub eingetretener Long-Liquidationen (Binance) in den letzten
    beiden abgeschlossenen Halbstundenblöcken (also 30-60 min zurück)
    gegenüber dem 3-Tage-Durchschnitt -> Erholungschance; Short-Liquidationsschub -> Rückschlagchance.
    Die Stärke wird aus der eigenen Historie geschätzt: mittlere 4-h-Rendite nach solchen Schüben.
    """
    now = int(time.time())
    try:
        rows = con.execute("SELECT ts, side, notional FROM bnc_liquidations WHERE coin=? AND ts>=?", (coin, now - 3 * 86400)).fetchall()
    except sqlite3.OperationalError:
        return None
    if len(rows) < 50:
        return None
    # side ist bereits normalisiert ("long" = Long-Position wurde liquidiert). Der frühere
    # Vergleich str(side).startswith("S") traf auf "short" zu und ordnete damit jeden
    # Long-Schub der Short-Spalte zu -- das Signal zeigte zuverlässig in die falsche Richtung.
    def ist_long(v) -> bool:
        t = str(v).strip().lower()
        return t == "long" if t in ("long", "short") else t.startswith("s")   # SELL-Fill = Long liquidiert

    buckets: dict = {}
    for ts, side, usd in rows:
        b = int(ts) // 1800 * 1800
        d = buckets.setdefault(b, [0.0, 0.0])
        d[0 if ist_long(side) else 1] += usd
    if len(buckets) < 20:
        return None
    # Der laufende Halbstundenblock ist unvollständig und darf den Durchschnitt nicht
    # verwässern; verglichen werden die beiden letzten ABGESCHLOSSENEN Blöcke gegen den
    # Durchschnitt der übrigen.
    jetzt_b = now // 1800 * 1800
    fenster = [jetzt_b - 1800, jetzt_b - 3600]
    # M2 (Audit v10): Referenz in derselben Fenstergröße (zwei Halbstunden = 1 h) und INKLUSIVE der Blöcke ohne
    # Liquidation -- vorher 1-h-Summe gegen 4× einen 30-min-Schnitt nur belegter Blöcke (effektiv 2×, bei
    # dünnen Coins noch weniger)
    erste_b = min(buckets) if buckets else jetzt_b
    basis = []
    b_ = erste_b // 3600 * 3600
    while b_ + 3600 <= jetzt_b - 3600:
        v1 = buckets.get(b_, [0.0, 0.0]); v2 = buckets.get(b_ + 1800, [0.0, 0.0])
        basis.append([v1[0] + v2[0], v1[1] + v2[1]]); b_ += 3600
    if len(basis) < 10:
        return None
    avg_l = sum(v[0] for v in basis) / len(basis)
    avg_s = sum(v[1] for v in basis) / len(basis)
    cur = buckets.get(fenster[0], [0.0, 0.0]); prev = buckets.get(fenster[1], [0.0, 0.0])
    l_now = cur[0] + prev[0]; s_now = cur[1] + prev[1]
    if avg_l > 0 and l_now >= 4 * avg_l and l_now >= 3e6:
        return {"kind": "long", "ratio": l_now / avg_l, "usd": l_now, "text": f"Long-Liquidationsschub: {l_now/1e6:.1f} Mio in zwei Halbstundenblöcken, {l_now/avg_l:.0f}× Durchschnitt — Kapitulation, Erholungschance"}
    if avg_s > 0 and s_now >= 4 * avg_s and s_now >= 3e6:
        return {"kind": "short", "ratio": s_now / avg_s, "usd": s_now, "text": f"Short-Liquidationsschub: {s_now/1e6:.1f} Mio in zwei Halbstundenblöcken, {s_now/avg_s:.0f}× Durchschnitt — Squeeze läuft, Rückschlagrisiko"}
    return None


# ---------------------------------------------------------------------------
# Kern
# ---------------------------------------------------------------------------

def compute_forecast(con, coin: str, chart: dict, whales: dict | None, smart: dict | None, lb: dict | None,
                     lb_act: dict | None, etf: dict | None, bnc: dict | None, cdc: dict | None,
                     bybit: dict | None = None, okx: dict | None = None, learned: dict | None = None,
                     coinbase: dict | None = None) -> dict | None:
    """
    chart: Ergebnis von load_chart(agg=60, minutes=7*1440) -- Stundenkerzen, Marken, Stops, Buch, Funding, MAs.
    whales: load_whales (mit 'directional'); smart: smart_money; lb: load_leaderboard; lb_act: load_lb_activity(3 T).
    """
    C = chart.get("candles") or []
    p0 = chart.get("price") or (C[-1]["c"] if C else None)
    if not p0 or len(C) < 24:
        return None
    now = int(time.time())
    learned = learned or {}
    W = learned.get("weights") or {}                      # gelernte Gewichte je Treiber (Hauptspur 4 h)
    W24 = learned.get("weights_24") or {}                 # Gewichte der 24-h-Spur (Prior, solange nicht gelernt)
    beta4 = float((learned.get("cal") or {}).get("beta") or 1.0)       # gelernter Maßstab der Wahrscheinlichkeit
    beta24 = float((learned.get("cal_24") or {}).get("beta") or 1.0)
    analog = learned.get("analog"); tprof = learned.get("tprof"); mstat = learned.get("magnets"); capit = learned.get("capitulation")
    if analog and isinstance(analog.get("ret"), dict):
        analog = dict(analog, ret=_intkeys(analog["ret"]))
    ens_w = learned.get("ensemble") or {"model": 0.6, "analog": 0.4}
    drivers: list[dict] = []          # {name, score (-1..1), weight, text}
    missing: list[str] = []
    elite_konten: list = []                                   # Kontenliste der Elite (Tabelle unter den Treibern, 22.09.)

    def add(name, score, weight, text):
        lw = (W.get(name) or {}).get("weight")
        lw24 = (W24.get(name) or {}).get("weight")
        drivers.append({"name": name, "score": _clip(score, -1, 1), "weight": lw if lw is not None else weight, "prior": weight,
                        "weight_24": lw24 if lw24 is not None else weight,
                        "learned": lw is not None and abs(lw - weight) > 1e-9, "hit_rate": (W.get(name) or {}).get("hit_rate"),
                        "n": (W.get(name) or {}).get("n"), "n_eff": (W.get(name) or {}).get("n_eff"),
                        "ci": (W.get(name) or {}).get("ci"), "lift": (W.get(name) or {}).get("lift"), "lift_z": (W.get(name) or {}).get("lift_z"),
                        "oos": (W.get(name) or {}).get("oos"), "text": text})

    # ---- 1. Regime und Drift ------------------------------------------------------------------
    mas = chart.get("mas") or {}
    ma200 = _num(mas.get("ma200d")); ma50w = _num(mas.get("ma50w"))
    if ma200:
        d = p0 / ma200 - 1
        add("MA 200 Tage", _clip(d / 0.10, -1, 1) * 0.6, 0.8, f"Kurs {d*100:+.1f} % zum MA 200 Tage ({ma200:,.0f})")
    else:
        missing.append("MA 200 Tage")
    if ma50w:
        d = p0 / ma50w - 1
        add("MA 50 Wochen", _clip(d / 0.10, -1, 1) * 0.5, 0.6, f"Kurs {d*100:+.1f} % zum MA 50 Wochen ({ma50w:,.0f})")
    tr = _num(chart.get("trend_60m"))
    if tr is not None:
        add("60-min-Trend", _clip(tr / 0.01, -1, 1) * 0.5, 0.5, f"60-Minuten-Trend {tr*100:+.2f} %")
    rsi = _num(chart.get("rsi14"))
    if rsi is not None:
        # Mean Reversion: überkauft drückt, überverkauft stützt
        add("RSI 14 (1 h)", _clip((50 - rsi) / 30, -1, 1) * 0.5, 0.5, f"RSI {rsi:.0f} — {'überkauft, Rückschlagrisiko' if rsi >= 70 else 'überverkauft, Erholungschance' if rsi <= 30 else 'neutral'}")
    # 7-Tage-Drift, gedämpft
    if len(C) >= 48:
        drift7 = math.log(C[-1]["c"] / C[max(0, len(C) - 168)]["c"]) / max(1, min(168, len(C) - 1))   # je Stunde
    else:
        drift7 = 0.0
    sigma = realized_vol(C)                                                       # je Stunde
    add("7-Tage-Drift", _clip(drift7 / (sigma * 0.3), -1, 1) * 0.4, 0.4, f"Drift der letzten Tage {drift7*24*100:+.2f} %/Tag bei Volatilität {sigma*100:.2f} %/h")

    # ---- 2. Richtungsdruck: nur direktionale Konten ---------------------------------------------
    D = (whales or {}).get("directional") or {}
    if D.get("n_directional"):
        tot = D["usd_long"] + D["usd_short"]
        if tot > 0:
            sc = (D["usd_long"] - D["usd_short"]) / tot
            add("Direktionale Wale", sc, 1.2, f"{D['n_long']} long {D['usd_long']/1e6:.0f} Mio gegen {D['n_short']} short {D['usd_short']/1e6:.0f} Mio ({D['n_directional']} direktionale Wale)")
    else:
        missing.append("Direktionale Wale (keine direktionalen Wale mit Position im Coin)")
    # Wal-Flow: Positionsänderungen der direktionalen Wale in den letzten 30 min (Ereignis-Signal bei Breite und Z-Score)
    FL = (whales or {}).get("flow") or {}
    # Breiten-Regel (22.09., Fund des Nutzers): "mindestens 2 Konten" sollte ein kleines Einzelkonto ausschließen --
    # nicht ein direktionales Konto mit 13 Mio. Jetzt: mindestens 2 Konten ODER ein Einzelkonto ab EINZEL_MIN
    # (Wale 5 Mio, Leaderboard 1 Mio); ein Einzelkonto wird mit 0,7 gedämpft, weil Breite fehlt.
    EINZEL_MIN_WAL, EINZEL_MIN_LB = 5e6, 1e6
    ok = lambda w: bool(w) and (w["buy_usd"] + w["sell_usd"]) >= 1.5e5 and ((w["n_buy"] + w["n_sell"]) >= 2 or (w["buy_usd"] + w["sell_usd"]) >= EINZEL_MIN_WAL)
    GNAMES = {"dir": ("Wal-Flow 30 min", "direktionale Wale")}     # Hedge / MM / gemischt: gestrichen, siehe PRIORS
    groups = FL.get("groups") or ({"dir": FL} if FL.get("w30") else {})
    any_group = False
    for g, (drv, label) in GNAMES.items():
        gf = groups.get(g)
        if not gf:
            continue
        w30g, w60g = gf.get("w30"), gf.get("w60")
        win, wf, z = ("30 min", w30g, gf.get("z30")) if ok(w30g) else ("60 min", w60g, gf.get("z60")) if ok(w60g) else (None, None, None)
        if not wf:
            continue
        any_group = True
        gross = wf["buy_usd"] + wf["sell_usd"]
        sc = (wf["net_usd"] / gross) * _clip((abs(z) if z is not None else 1.0) / 2.5, 0.4, 1.0)
        if wf["n_buy"] + wf["n_sell"] < 2:
            sc *= 0.7                                                  # ein Konto: Größe ja, Breite nein
        if gf.get("event_signal") and sc:
            sc = sc + 0.5 * (math.copysign(1.0, sc) - sc)      # Stufe 1 (21.09.): Ereignis hebt den Score halbwegs zu ±1 -- monoton, ohne Clipping-Verlust (vorher ×1,5, ab 0,67 gekappt)
        add(drv, sc, PRIORS[drv],
            f"{wf['n_buy']} {label} kaufen {wf['buy_usd']/1e6:.1f} Mio, {wf['n_sell']} verkaufen {wf['sell_usd']/1e6:.1f} Mio in {win}"
            + (f" (Z {z:.1f})" if z is not None else "") + (" — EREIGNIS-SIGNAL" if gf.get("event_signal") else ""))
    if not any_group and FL:
        w60_ = (groups.get("dir") or {}).get("w60") or {}
        g60_ = (w60_.get("buy_usd", 0) + w60_.get("sell_usd", 0)); n60_ = w60_.get("n_buy", 0) + w60_.get("n_sell", 0)
        missing.append(f"Wal-Flow 30 min (ruhig: {g60_ / 1e6:.1f} Mio Umsatz von {n60_} Wal(en) in 60 min -- nötig ≥ 150k und ≥ 2 Wale oder ≥ 5 Mio von einem)")
    # Leaderboard-Flow: Positionsänderungen der direktionalen Top-Konten (Stände alle 5 min)
    LF = (lb or {}).get("flow") or {}
    okL = lambda w: bool(w) and (w["buy_usd"] + w["sell_usd"]) >= 7.5e4 and ((w["n_buy"] + w["n_sell"]) >= 2 or (w["buy_usd"] + w["sell_usd"]) >= EINZEL_MIN_LB)
    lwin, lw = ("60 min", LF.get("w60")) if okL(LF.get("w60")) else ("3 h", LF.get("w180")) if okL(LF.get("w180")) else ("60 min", None)
    if lw:
        gross = lw["buy_usd"] + lw["sell_usd"]; z = LF.get("z60")
        sc = (lw["net_usd"] / gross) * _clip((abs(z) if z is not None else 1.0) / 2.5, 0.4, 1.0)
        if lw["n_buy"] + lw["n_sell"] < 2:
            sc *= 0.7                                                  # ein Konto: Größe ja, Breite nein
        if LF.get("event_signal") and sc:
            sc = sc + 0.5 * (math.copysign(1.0, sc) - sc)      # Stufe 1: siehe Wal-Flow
        add("Leaderboard-Flow 60 min", sc, PRIORS["Leaderboard-Flow 60 min"],
            f"{lw['n_buy']} Top-Konten kaufen {lw['buy_usd']/1e6:.1f} Mio, {lw['n_sell']} verkaufen {lw['sell_usd']/1e6:.1f} Mio in {lwin}" + (f" (Z {z:.1f})" if z is not None else "")
            + (" — nur ein Konto, Score ×0,7" if lw["n_buy"] + lw["n_sell"] < 2 else "") + (" — EREIGNIS-SIGNAL" if LF.get("event_signal") else ""))
    elif LF:
        w60_ = LF.get("w60") or {}; g60_ = w60_.get("buy_usd", 0) + w60_.get("sell_usd", 0); n60_ = w60_.get("n_buy", 0) + w60_.get("n_sell", 0)
        missing.append(f"Leaderboard-Flow 60 min (ruhig: {g60_ / 1e6:.2f} Mio Umsatz von {n60_} Konto/Konten in 60 min -- nötig ≥ 75k und ≥ 2 Konten oder ≥ 1 Mio von einem)")
    # Coinbase-Spot -----------------------------------------------------------
    CB = coinbase or {}
    if CB.get("aktiv"):
        pz = CB.get("premium_z")
        if pz is not None:
            # Der Z-Wert misst den Abstand vom eigenen Ruhewert: Eine dauerhaft positive
            # Prämie sagt nichts, ihr plötzliches Anschwellen schon.
            add("Coinbase-Prämie", _clip(pz / 2.5, -1, 1), PRIORS["Coinbase-Prämie"],
                f"Spot {CB['premium_bps']:+.1f} bps zum Perp-Kurs, Mittel {CB['premium_mittel']:+.1f} "
                f"(Z {pz:+.1f}, {CB.get('premium_n', 0):,} Minuten Vergleich)")
        elif CB.get("premium_bps") is not None:
            missing.append("Coinbase-Prämie (noch keine Vergleichsreihe)")
        f60 = CB.get("flow60") or {}
        brutto = (f60.get("buy_usd") or 0) + (f60.get("sell_usd") or 0)
        if brutto >= 2e5:
            fz = CB.get("flow_z")
            anteil = f60["net_usd"] / brutto
            sc = anteil * _clip((abs(fz) if fz is not None else 1.0) / 2.5, 0.4, 1.0)
            add("Spot-Taker-Flow", sc, PRIORS["Spot-Taker-Flow"],
                f"Spot 60 min: {f60['buy_usd']/1e6:.1f} Mio aggressiv gekauft gegen "
                f"{f60['sell_usd']/1e6:.1f} Mio verkauft" + (f" (Z {fz:+.1f})" if fz is not None else "")
                + (f" · Volumen {CB['vol_rel']:.1f}x des Schnitts" if CB.get("vol_rel") else ""))
        else:
            missing.append("Spot-Taker-Flow (zu wenig Umsatz)")
        bk = CB.get("book") or {}
        if bk.get("imbalance") is not None and (bk.get("bid25", 0) + bk.get("ask25", 0)) >= 1e5:
            add("Spot-Orderbuch", _clip(bk["imbalance"] * 2, -1, 1), PRIORS["Spot-Orderbuch"],
                f"Spot-Tiefe ±25 bps: {bk['bid25']/1e3:.0f}k Gebot gegen {bk['ask25']/1e3:.0f}k Angebot "
                f"({bk['imbalance']*100:+.0f} %)")
    elif CB:
        missing.append("Coinbase-Prämie / Spot-Taker-Flow / Spot-Orderbuch (Coinbase-Dienst läuft nicht oder Daten älter als 30 min)")

    dir_addrs = lb_directional_addrs(con, coin)
    if smart and dir_addrs:
        # Smart Money nur direktional: aus lb_positions selbst rechnen
        try:
            last = con.execute("SELECT MAX(ts) FROM lb_positions").fetchone()[0]
            nl = ns = 0; ul = us = 0.0
            net: dict = {}
            for addr, c_, side, val in con.execute("SELECT addr, coin, side, pos_value FROM lb_positions WHERE ts=? AND rank<=50", (last,)):
                if addr not in dir_addrs:
                    continue
                if c_ != coin:
                    continue
                net[addr] = net.get(addr, 0.0) + (val or 0) * (1 if side == "long" else -1)
            for v in net.values():
                if v > 0: nl += 1; ul += v
                elif v < 0: ns += 1; us += -v
            if nl + ns >= 3:
                add("Smart Money (direktional)", (ul - us) / max(ul + us, 1), 1.0, f"{nl} long {ul/1e6:.1f} Mio gegen {ns} short {us/1e6:.1f} Mio in {coin} — profitabelste Konten, nur direktionale")
            else:
                missing.append(f"Smart Money (direktional) (weniger als 3 direktionale Top-50-Konten mit Position in {coin})")
        except sqlite3.OperationalError:
            missing.append("Smart Money")
    else:
        missing.append("Smart Money")
    # Käufe/Verkäufe direktionaler Leaderboard-Konten, letzte 24 h
    if dir_addrs:
        try:
            since = now - 86_400
            marks = ",".join("?" * len(dir_addrs))
            has_buy = "buy" in {r[1] for r in con.execute("PRAGMA table_info(lb_fills)")}
            BUY = "buy" if has_buy else "(CASE WHEN lower(dir) LIKE '%open long%' OR lower(dir) LIKE '%close short%' OR lower(dir) LIKE '%buy%' THEN 1 ELSE 0 END)"
            row = con.execute(f"SELECT SUM(CASE WHEN {BUY}=1 THEN notional ELSE 0 END), SUM(CASE WHEN {BUY}=0 THEN notional ELSE 0 END), COUNT(DISTINCT addr) "
                              f"FROM lb_fills WHERE coin=? AND ts>=? AND addr IN ({marks})", (coin, since, *dir_addrs)).fetchone()
            b, s_, n = (row[0] or 0), (row[1] or 0), (row[2] or 0)
            if b + s_ >= 2.5e5 and n >= 2:
                add("Käufe/Verkäufe 24 h (direktional)", (b - s_) / (b + s_), 1.0, f"direktionale Top-Konten: {b/1e6:.1f} Mio gekauft, {s_/1e6:.1f} Mio verkauft ({n} Konten, Perp + Spot)")
            else:
                missing.append("Käufe/Verkäufe 24 h (direktional) (unter 250k Umsatz oder weniger als 2 Konten in 24 h)")
        except sqlite3.OperationalError:
            missing.append("Käufe/Verkäufe 24 h (direktional) (keine Fills der Top-Konten)")
    # Leaderboard-Trend Top 20 (Veränderung 24 h) im Coin
    if lb and lb.get("summary") and lb.get("trend") and len(lb["trend"]) >= 2:
        S = lb["summary"]; T = [dict(r, ts=int(r["ts"])) for r in lb["trend"]]; ago = next((r for r in reversed(T) if r["ts"] <= T[-1]["ts"] - 86_400), T[0])
        gross = S["usd_long"] + S["usd_short"]
        if gross > 0:
            delta = (S["net_usd"] - ago["net_usd"]) / gross
            add("Top-20-Trend 24 h", _clip(delta / 0.5, -1, 1) * 0.6, 0.6, f"Netto-Positionierung der Top 20 in {coin} seit 24 h {'+' if delta >= 0 else '−'}{abs(delta)*100:.0f} % des Bruttowerts")
    # Taker-Flow börsenübergreifend
    parts = []
    for name, src in (("Binance", (bnc or {}).get("metrics") or {}), ("Crypto.com", cdc or {}), ("Bybit", bybit or {}), ("OKX", okx or {})):
        r = src.get("taker_ls")
        if r and r < 9 and (src.get("taker_span_s") is None or src.get("taker_span_s", 0) >= 60):
            parts.append((name, float(r)))
    if parts:
        avg = sum(math.log(r) for _, r in parts) / len(parts)                 # log-Verhältnis, symmetrisch
        add("Taker-Flow", _clip(avg / math.log(1.5), -1, 1) * 0.7, 0.7, "Taker Kauf/Verkauf: " + ", ".join(f"{n} {r:.2f}" for n, r in parts))
    # Funding: extremes Funding wirkt gegen die Menge
    f = _num(chart.get("funding"), "funding")
    if f is not None:
        f_ = f - 0.0000125                                                # N1: HL-Funding enthält 0,01 %/8 h Zinsanteil (0,00125 %/h) -- den Prämienanteil bewerten
        add("Funding", _clip(-f_ / 0.0002, -1, 1) * 0.4, 0.4, f"Funding {f*100:.4f} %/h (Prämie {f_*100:+.4f}) — {'Longs zahlen, Squeeze-Risiko nach unten' if f > 0.0001 else 'Shorts zahlen, Squeeze-Risiko nach oben' if f < -0.00005 else 'neutral'}")
    # ETF-Flows (BTC/ETH)
    if etf and coin in ("BTC", "ETH"):
        sc = 0.0
        if etf["last"] > 0 and etf["sum5"] > 0: sc = _clip(etf["sum5"] / 1000, 0.2, 1)
        elif etf["last"] < 0 and etf["sum5"] < 0: sc = -_clip(-etf["sum5"] / 1000, 0.2, 1)
        add("ETF-Flows", sc * 0.6, 0.6, f"ETF {etf['last']:+.0f} Mio am {etf['last_date']}, 5 Tage {etf['sum5']:+.0f} Mio")
    # Orderbuch-Imbalance
    book = chart.get("book") or {}
    imb = _num(book.get("imb_50")) if isinstance(book, dict) else None
    if imb is not None:
        add("Orderbuch", _clip(imb / 0.5, -1, 1) * 0.4, 0.4, f"Orderbuch-Imbalance ±50 bps {imb*100:+.0f} %")

    if capit:
        add("Kapitulation", 0.8 if capit["kind"] == "long" else -0.8, PRIORS["Kapitulation"], capit["text"])
    else:
        missing.append("Kapitulation (kein Liquidationsschub ≥ 4× Durchschnitt und ≥ 3 Mio in der letzten Stunde)")

    # ---- Neue Treiber aus vorhandenen Tabellen (Auditbericht v3, Abschnitt 3) -------------------
    # Richtungs-Scores klein und kontra-orientiert, wo die Langzeitstudien das stützen; alles, was
    # nur Volatilität vorhersagt, geht als Regime ins Band (unten), nicht in die Richtung.
    ind = {}
    for key, fn in (("oi", hl_indikatoren.oi_perzentil), ("crowd", hl_indikatoren.crowding), ("etf", hl_indikatoren.etf_momentum),
                    ("vol", hl_indikatoren.vol_regime), ("fspread", hl_indikatoren.funding_spread),
                    ("liq", hl_indikatoren.liquidationsdruck), ("var", hl_indikatoren.varianz_kompression)):
        try:
            ind[key] = fn(con, coin)
        except Exception as e:                                # ein Indikator darf die Prognose nie reißen
            ind[key] = None; missing.append(f"{key}: {type(e).__name__}")
    if ind.get("oi") and ind["oi"]["ueberhitzt"] > 0:
        add("OI-Überhitzung", ind["oi"]["score"], PRIORS["OI-Überhitzung"], ind["oi"]["text"])
    elif ind.get("oi"):
        missing.append(f"OI-Überhitzung (OI im {ind['oi']['pct'] * 100:.0f}. Perzentil, aktiv erst ab dem 90.)")
    else:
        missing.append("OI-Überhitzung (keine OI-Reihe ≥ 14 Tage oder veraltet)")
    if ind.get("crowd"):
        c_ = ind["crowd"]
        if c_["kontra"]:
            add("Crowding-Extrem", c_["kontra"], PRIORS["Crowding-Extrem"], c_["text_kontra"])
        else:
            missing.append(f"Crowding-Extrem (Ausrichtung im {c_['pct'] * 100:.0f}. Perzentil, aktiv nur unter dem 10. oder über dem 90.)")
        if c_.get("trend") is not None:
            add("Crowding-Trend 7 T", c_["trend"] * 0.8, PRIORS["Crowding-Trend 7 T"], c_["text_trend"])
        else:
            missing.append("Crowding-Trend 7 T (weniger als 21 Tage Historie)")
    else:
        missing.append("Crowding-Extrem / Crowding-Trend 7 T (lb_trend unter 14 Tage oder veraltet)")
    if ind.get("etf"):
        add("ETF-Momentum", ind["etf"]["score"], PRIORS["ETF-Momentum"], ind["etf"]["text"])
    else:
        missing.append("ETF-Momentum (nur BTC/ETH; mindestens 12 Tage etf_flows, jüngster Tag ≤ 4 Tage alt)" if coin in ("BTC", "ETH") else "ETF-Momentum (nur BTC/ETH)")
    if ind.get("vol") and ind["vol"]["score"]:
        add("Vol-Spike-Reversion", ind["vol"]["score"], PRIORS["Vol-Spike-Reversion"], ind["vol"]["text"])
    elif ind.get("vol"):
        missing.append(f"Vol-Spike-Reversion (Vol {ind['vol']['ratio']:.2f}× Norm, aktiv erst ab 1,5× mit |24-h-Bewegung| > 0,5 %)")
    else:
        missing.append("Vol-Spike-Reversion (weniger als 20 Tage Minutenkerzen)")
    if ind.get("fspread"):
        add("Funding-Spread", ind["fspread"]["score"], PRIORS["Funding-Spread"], ind["fspread"]["text"])
    else:
        missing.append("Funding-Spread (Fremdbörsen-Funding unter 3 Tage oder veraltet)")
    if ind.get("liq") and ind["liq"]["intens"] > 0:
        add("Liquidationsdruck (3 Börsen)", ind["liq"]["score"], PRIORS["Liquidationsdruck (3 Börsen)"], ind["liq"]["text"])
    elif ind.get("liq"):
        missing.append(f"Liquidationsdruck (3 Börsen) (Intensität im {ind['liq']['pct'] * 100:.0f}. Perzentil, aktiv erst ab dem 90.)")
    else:
        missing.append("Liquidationsdruck (3 Börsen) (unter 200 Liquidationen in 30 Tagen)")
    regime = hl_indikatoren.regime(ind.get("oi"), ind.get("vol"), ind.get("liq"), ind.get("var"))
    if analog and analog.get("ret", {}).get(24):
        a24 = analog["ret"][24]
        # Gegen die unbedingte Basisrate der Historie gemessen, nicht gegen 0,5: In drei Jahren
        # mit Aufwärtsdrift liegt "aufwärts" ohnehin über der Hälfte -- Analoge, die das nur
        # wiedergeben, sagen nichts Eigenes.
        basis = a24.get("p_up_base") if a24.get("p_up_base") is not None else 0.5
        add("Analog-Suche", _clip((a24["p_up"] - basis) * 4, -1, 1) * 0.8, PRIORS["Analog-Suche"],
            f"{analog['n']} ähnliche Momente aus {analog['span_days']:.0f} Tagen: danach 24 h im Median {a24['med']*100:+.2f} %, "
            f"{a24['p_up']*100:.0f} % davon aufwärts (Basisrate {basis*100:.0f} %"
            + (f", Intervall {a24['ci'][0]*100:.0f}–{a24['ci'][1]*100:.0f} %" if a24.get("ci") else "") + ")")
    else:
        missing.append("Analog-Suche")

    # ---- Konto-Score: Qualität statt Menge (hl_score) ----------------------------------------
    SC = learned.get("scores") or {}
    if SC:
        try:
            import hl_score
            schritte = hl_score.lade_schritte(con, coin, now - 4 * 3600, now)
            num = den = 0.0; n_k = 0; brutto = 0.0
            gnum = gden = 0.0; n_g = 0
            for a, lst in schritte.items():
                info = SC.get(a)
                if not info:
                    continue
                w_a = info.get("score") or 0.0
                for ts_, d_, N_ in lst:
                    r = math.sqrt(max(N_, 0.0))
                    if info.get("klasse", 1.0) >= 0.6 and w_a > 0:
                        num += w_a * d_ * r; den += w_a * r; brutto += N_
                    if (info.get("alpha_4h") is not None and info["alpha_4h"] < 0 and (info.get("n") or 0) >= 20
                            and (info.get("t_4h") is not None and info["t_4h"] <= -1.5)):          # H9: Signifikanz, spiegelbildlich zur Elite
                        gnum += d_ * r; gden += r
                n_k += 1 if (info.get("klasse", 1.0) >= 0.6 and w_a > 0) else 0
                n_g += 1 if (info.get("alpha_4h") is not None and info["alpha_4h"] < 0 and (info.get("n") or 0) >= 20
                             and (info.get("t_4h") is not None and info["t_4h"] <= -1.5)) else 0
            if den > 0 and n_k >= 3 and brutto >= 5e5:
                add("Smart-Flow 4 h", num / den, PRIORS["Smart-Flow 4 h"],
                    f"{n_k} bewertete Konten, Fluss mit Konto-Score gewichtet: {num / den:+.2f} (brutto {brutto / 1e6:.1f} Mio, 4 h)")
            else:
                missing.append("Smart-Flow 4 h (weniger als 3 bewertete Konten aktiv oder unter 500k Umsatz in 4 h)")
            if gden > 0 and n_g >= 3:
                add("Gegen-Flow", -gnum / gden, PRIORS["Gegen-Flow"],
                    f"{n_g} Konten mit negativem Vorlauf handelten {'netto Kauf' if gnum > 0 else 'netto Verkauf'} — invertiert ({-gnum / gden:+.2f})")
            # Elite-Positionierung: Netto-Ausrichtung der zehn besten Konten (aktuelle Positionen)
            elite = learned.get("elite") or []
            if not elite:
                missing.append("Elite-Positionierung (Elite leer: kein Konto mit n≥10 Schritten, Vorlauf>0 und t≥1 im Coin -- erscheint, sobald Konten Beleg haben)")
            if elite:
                try:
                    SC_ = learned.get("scores") or {}
                    marks_ = ",".join("?" * len(elite)); el_ = [a.lower() for a in elite]
                    pos_: dict = {}
                    try:
                        last_lb = con.execute("SELECT MAX(ts) FROM lb_positions").fetchone()[0]
                        if last_lb:
                            for a_, sd_, v_, u_ in con.execute(f"SELECT lower(addr), side, pos_value, upnl FROM lb_positions WHERE ts=? AND coin=? AND lower(addr) IN ({marks_})", (last_lb, coin, *el_)):
                                pos_[a_] = (sd_, v_ or 0.0, u_ or 0.0)
                    except sqlite3.OperationalError:
                        pass
                    try:
                        for a_, ev_, sd_, v_, u_ in con.execute(f"""SELECT lower(w.addr), w.event, w.side, w.pos_value, w.upnl FROM whale_positions w
                                                                    WHERE w.coin=? AND lower(w.addr) IN ({marks_}) AND w.ts=(SELECT MAX(ts) FROM whale_positions x WHERE x.addr=w.addr AND x.coin=w.coin)""", (coin, *el_)):
                            if a_ not in pos_:
                                pos_[a_] = (None, 0.0, 0.0) if ev_ == "close" else (sd_, v_ or 0.0, u_ or 0.0)
                    except sqlite3.OperationalError:
                        pass
                    av_: dict = {}
                    try:
                        for a_, v_ in con.execute(f"SELECT lower(addr), account_value FROM addresses WHERE lower(addr) IN ({marks_})", el_):
                            av_[a_] = v_ or 0.0
                    except sqlite3.OperationalError:
                        pass
                    lbav_: dict = {}; lbn_: dict = {}
                    try:
                        last_acc = con.execute("SELECT MAX(ts) FROM lb_accounts").fetchone()[0]
                        if last_acc:
                            for a_, v_, nm_, r_ in con.execute(f"SELECT lower(addr), account_value, name, rank FROM lb_accounts WHERE ts=? AND lower(addr) IN ({marks_})", (last_acc, *el_)):
                                lbav_[a_] = v_ or 0.0; lbn_[a_] = (nm_ or "", r_)
                    except sqlite3.OperationalError:
                        pass
                    pnl30_: dict = {}
                    try:
                        for a_, p_ in con.execute(f"SELECT lower(addr), pnl_30d FROM lb_stats WHERE lower(addr) IN ({marks_})", el_):
                            pnl30_[a_] = p_
                    except sqlite3.OperationalError:
                        pass
                    try:
                        import hl_score as _hs
                        akt_ = _hs.aktivitaets_filter(con, el_)
                    except Exception:
                        akt_ = {}
                    for a_ in el_:
                        sc_ = SC_.get(a_) or {}; sd_, v_, u_ = pos_.get(a_, (None, 0.0, 0.0))
                        elite_konten.append({"addr": a_, "name": lbn_.get(a_, ("", None))[0], "rank": lbn_.get(a_, ("", None))[1],
                                             "score": sc_.get("score"), "n": sc_.get("n"), "alpha_4h": sc_.get("alpha_4h"), "t_4h": sc_.get("t_4h"),
                                             "klasse": sc_.get("klasse"), "account_value": lbav_.get(a_) or av_.get(a_) or None,
                                             "side": sd_, "pos_value": v_, "upnl": u_, "upnl_pct": (u_ / v_) if v_ else None, "pnl_30d": pnl30_.get(a_),
                                             "trades_tag": (akt_.get(a_) or {}).get("trades_tag")})
                    elite_konten.sort(key=lambda x: -(x["score"] or 0))
                except sqlite3.Error:
                    elite_konten = []
            if elite:
                marks = ",".join("?" * len(elite))
                ul = us = 0.0; n_e = 0; n_aus = 0; gezaehlt: set = set(); groesste = 0.0
                # Prüfung 15.09. (Elite -0,95 gegen Smart Money +0,77): Die Elite wird nach Score gewählt,
                # und dort genügt die KONTOWEITE Klasse >= 0,6 -- auch gemischte Konten. Ihre Hedge-Beine
                # im Coin zählten mit, obwohl sie keine Meinung zum Kurs sind. Jetzt zählen nur Positionen
                # von Konten, die IN DIESEM COIN direktional sind (Leaderboard-Gruppe) oder kontoweit
                # rein direktional (Klasse 1,0, Wale ohne Leaderboard-Eintrag). Dazu ein Dominanz-Dämpfer:
                # Hält ein Konto mehr als die Hälfte des Bruttowerts, ist es kein Gruppensignal mehr.
                lb_gruppen = {k.lower(): v for k, v in lb_groups(con, coin).items()}   # Leaderboard-Konten mit ihrer Gruppe im Coin
                dir_l = {a.lower() for a in dir_addrs}
                def zaehlbar(addr_l: str) -> bool:
                    if addr_l in lb_gruppen:
                        return addr_l in dir_l                                      # Leaderboard-Konto: nur die Gruppe im Coin zählt (Hedge-Konten fallen raus)
                    return SC.get(addr_l, {}).get("klasse", 0.0) >= 1.0             # Wal ohne Leaderboard-Eintrag: kontoweit rein direktional
                try:
                    last = con.execute("SELECT MAX(ts) FROM lb_positions").fetchone()[0]
                    if last:
                        for addr_, side_, val_ in con.execute(f"SELECT addr, side, pos_value FROM lb_positions WHERE ts=? AND coin=? AND lower(addr) IN ({marks})",
                                                              (last, coin, *elite)):
                            gezaehlt.add(addr_.lower())
                            if not zaehlbar(addr_.lower()):
                                n_aus += 1; continue
                            if side_ == "long": ul += val_ or 0
                            else: us += val_ or 0
                            n_e += 1; groesste = max(groesste, val_ or 0)
                    for addr_, side_, val_ in con.execute(f"""SELECT w.addr, w.side, w.pos_value FROM whale_positions w
                            WHERE w.coin=? AND lower(w.addr) IN ({marks}) AND w.event != 'close'
                              AND w.ts = (SELECT MAX(ts) FROM whale_positions x WHERE x.addr=w.addr AND x.coin=w.coin)""", (coin, *elite)):
                        if addr_.lower() in gezaehlt:
                            continue                                  # Leaderboard-Stand ist frischer, nicht doppelt zählen
                        if not zaehlbar(addr_.lower()):
                            n_aus += 1; continue
                        if side_ == "long": ul += val_ or 0
                        else: us += val_ or 0
                        n_e += 1; groesste = max(groesste, val_ or 0)
                except sqlite3.OperationalError:
                    pass
                if n_e >= 3 and ul + us > 0:
                    anteil = groesste / (ul + us)
                    daempfer = _clip((1.0 - anteil) / 0.5, 0.5, 1.0)              # ab 50 % Anteil eines Kontos gedämpft, bei 100 % halbiert
                    add("Elite-Positionierung", (ul - us) / (ul + us) * daempfer, PRIORS["Elite-Positionierung"],
                        f"die besten Konten nach Score, nur im Coin direktional: {ul / 1e6:.1f} Mio long gegen {us / 1e6:.1f} Mio short ({n_e} Positionen"
                        + (f", {n_aus} nicht-direktionale ausgelassen" if n_aus else "") + f"; größtes Konto {anteil:.0%} des Bruttowerts"
                        + (f", Score ×{daempfer:.2f}" if daempfer < 1 else "") + ")")
                else:
                    missing.append(f"Elite-Positionierung (Elite: {len(elite)} Konten mit Beleg n≥10, Vorlauf>0, t≥1; davon {n_e} zählbare Positionen im Coin"
                                   + (f", {n_aus} nicht-direktional" if n_aus else "") + " — mindestens 3 nötig)")
        except Exception as e:                                   # der Score darf die Prognose nie stoppen
            missing.append(f"Konto-Score ({type(e).__name__})")
    else:
        missing.append("Smart-Flow 4 h / Gegen-Flow / Elite-Positionierung (Konto-Score noch nicht berechnet -- täglicher Lauf)")

    wsum = sum(d["weight"] for d in drivers) or 1.0
    bias = sum(d["score"] * d["weight"] for d in drivers) / wsum                 # -1 .. 1, Hauptspur 4 h
    wsum24 = sum(d["weight_24"] for d in drivers) or 1.0
    bias24 = sum(d["score"] * d["weight_24"] for d in drivers) / wsum24          # Richtungsdruck der 24-h-Spur
    # Kalibrierte Wahrscheinlichkeit "aufwärts": dasselbe Modell wie in calibrate_weights,
    # damit die gespeicherte Zahl mit dem Brier-Score prüfbar ist. Vor dem Lernen (beta = 1)
    # ist sie eine Vorgabe, keine Aussage.
    # Nenner konstant (Audit v9 §3.1): Evidenzsumme -- wenige aktive Treiber SIND weniger Evidenz.
    p_up = _sigmoid(beta4 * sum(d["score"] * d["weight"] for d in drivers) / PRIOR_SUMME)
    p_up_24 = _sigmoid(beta24 * sum(d["score"] * d["weight_24"] for d in drivers) / PRIOR_SUMME)
    # K2-Neubau (23.09.): Kalibrierung v2 rechnet im Schatten mit; mit gesetztem Schalter (kalib2_aktiv) trägt sie die Prognose
    p_up_v1, p_up_24_v1 = p_up, p_up_24
    p_up_v2 = p_up_24_v2 = None; kalib2_info = None; kalib = "v1"
    try:
        import hl_kalib
        m4 = hl_kalib.laden(coin, 4); m24 = hl_kalib.laden(coin, 24)
        p_up_v2 = hl_kalib.p_up(m4, drivers) if m4 else None
        p_up_24_v2 = hl_kalib.p_up(m24, drivers) if m24 else None
        if m4:
            kalib2_info = {"n": m4.get("n"), "n_eff": m4.get("n_eff"), "lam": m4.get("lam"), "prior_anteil": m4.get("prior_anteil"),
                           "oof": m4.get("oof"), "zuverlaessigkeit": m4.get("zuverlaessigkeit"), "ts": m4.get("ts"), "zu_wenig": m4.get("zu_wenig", False),
                           "min_faelle": m4.get("min_faelle"), "n_bloecke": m4.get("n_bloecke"), "tol_ausgelassen": m4.get("tol_ausgelassen"),
                           "weights": m4.get("weights")}
        if learned and learned.get("kalib2_fehler"):
            kalib2_info = dict(kalib2_info or {}, fehler=learned.get("kalib2_fehler"))
        if m4 and m4.get("weights"):                                   # v2-Gewicht je Treiber (Score-Einheiten) neben dem v1-Gewicht zeigen
            for d in drivers + inaktiv:
                d["weight_v2"] = (m4["weights"] or {}).get(d["name"])
        if hl_kalib.aktiv() and p_up_v2 is not None:
            p_up = p_up_v2; kalib = "v2"
            if p_up_24_v2 is not None:
                p_up_24 = p_up_24_v2
    except Exception:
        pass
    agree = sum(d["weight"] for d in drivers if d["score"] * bias > 0) / wsum if bias else 0.5
    # H5 (Audit v10): nur FEHLENDE DATEN senken die Vollständigkeit -- Ereignis-Treiber ohne Ereignis (Kapitulation,
    # OI-Überhitzung, Crowding-Extrem, Vol-Spike, Liquidationsdruck, ruhige Flows) sind kein Datenmangel. Der alte
    # Filter suchte "(ruhig)", die Texte lauteten "(ruhig: …" -- er griff nie, die Konfidenz war fast immer halbiert.
    n_daten_fehlt = sum(1 for m in missing if not any(k in m for k in ("(ruhig", "Perzentil, aktiv erst", "kein Liquidationsschub", "Vol ", "aktiv nur unter", "(Bedingung nicht erfüllt")))
    completeness = 1 - min(0.5, 0.08 * n_daten_fehlt)
    confidence = _clip(0.35 + 0.45 * abs(bias) + 0.3 * (agree - 0.5), 0.15, 0.9) * completeness

    # ---- 3. Magneten, Wände, Kaskade ------------------------------------------------------------
    levels = [dict(l, px=_num(l.get("px")) or 0.0, notional=_num(l.get("notional")) or 0.0) for l in (chart.get("levels") or []) if _num(l.get("px"))]
    SC = [dict(c, px=_num(c.get("px")) or 0.0, notional=_num(c.get("notional")) or 0.0) for c in ((chart.get("stops") or {}).get("clusters") or []) if _num(c.get("px"))]
    # Schwellen "groß genug, um den Kurs zu ziehen": relativ zum Stundenvolumen DER QUELLE.
    # Die Prognose rechnet immer im Fusionsmodus, und dort ist vol_1h die Summe aus Hyperliquid,
    # Binance und Crypto.com -- bei BTC das Fünf- bis Zehnfache des HL-Volumens. Gemessen daran
    # war kein Hyperliquid-Liquidationscluster je "groß" (Schwelle Hunderte Mio, Cluster 5-50 Mio):
    # die Prognose lief ohne Magneten und Stop-Auslöser und fiel auf den Sigma-Pfad zurück.
    # Jetzt: HL-Cluster und HL-Stops gegen das HL-Volumen, die fusionierten Bücher (Wände)
    # gegen das fusionierte Volumen. (Befund vom 13.09., Prüfung des Mix-Modus.)
    vol_all = _num(chart.get("vol_1h")) or 0
    vs = chart.get("vol_split") or {}
    vol_hl = _num(vs.get("hl")) if vs.get("hl") is not None else vol_all
    big_hl = lambda n: n >= magnet_schwelle(vol_hl)
    big_all = lambda n: n >= max(vol_all * 0.5, 5e6)
    liq_up = sorted([l for l in levels if l["side"] == "short" and l["px"] > p0 and big_hl(l["notional"])], key=lambda l: l["px"])
    liq_dn = sorted([l for l in levels if l["side"] == "long" and l["px"] < p0 and big_hl(l["notional"])], key=lambda l: -l["px"])
    wall_up = sorted([s for s in SC if s["kind"] in ("limit_sell", "tp_sell") and s["px"] > p0 and big_all(s["notional"])], key=lambda s: s["px"])
    wall_dn = sorted([s for s in SC if s["kind"] in ("limit_buy", "tp_buy") and s["px"] < p0 and big_all(s["notional"])], key=lambda s: -s["px"])
    stop_up = sorted([s for s in SC if s["kind"] == "stop_buy" and s["px"] > p0 and s["notional"] >= max(vol_hl * 0.25, 5e6)], key=lambda s: s["px"])
    stop_dn = sorted([s for s in SC if s["kind"] == "stop_sell" and s["px"] < p0 and s["notional"] >= max(vol_hl * 0.25, 5e6)], key=lambda s: -s["px"])
    # Sichtbar machen, woran ein Magnet scheitert: Schwelle und größter Cluster je Seite
    magnet_info = {"schwelle": magnet_schwelle(vol_hl), "anteil": MAGNET_VOL_ANTEIL, "vol_1h_hl": vol_hl, "vol_1h_all": vol_all,
                   "max_up": max([l["notional"] for l in levels if l["side"] == "short" and l["px"] > p0] or [0.0]),
                   "max_dn": max([l["notional"] for l in levels if l["side"] == "long" and l["px"] < p0] or [0.0])}
    magnets = {
        "liq_up": [{"px": l["px"], "usd": l["notional"]} for l in liq_up[:3]],
        "liq_dn": [{"px": l["px"], "usd": l["notional"]} for l in liq_dn[:3]],
        "wall_up": [{"px": s["px"], "usd": s["notional"]} for s in wall_up[:2]],
        "wall_dn": [{"px": s["px"], "usd": s["notional"]} for s in wall_dn[:2]],
        "stop_up": [{"px": s["px"], "usd": s["notional"]} for s in stop_up[:2]],
        "stop_dn": [{"px": s["px"], "usd": s["notional"]} for s in stop_dn[:2]],
    }

    # ---- 4. Pfad: Stunde für Stunde --------------------------------------------------------------
    # Kurzfrist (0-12 h): zum nächsten Magneten in Richtung des Drucks, gebremst von der ersten Wand.
    # Mittelfrist (12-72 h): Kaskade, falls der Weg einen Stop-Auslöser kreuzt; danach Teilrückkehr.
    # Langfrist (72-168 h): Regime-Drift, gedämpft. Band: sigma * sqrt(t), skaliert mit (1 - Konfidenz/2).
    def first_px(lst):
        return lst[0]["px"] if lst else None
    dir_sign = 1 if bias > 0.12 else -1 if bias < -0.12 else 0
    reach = _clip(abs(bias), 0, 1)                                          # wie weit der Magnet erreicht wird
    retrace_frac = 0.3; overshoot = 0.0; mag_used = None
    if mstat:
        nearest = (liq_up[0] if dir_sign > 0 and liq_up else liq_dn[0] if dir_sign < 0 and liq_dn else None)
        if nearest:
            dd = abs(nearest["px"] / p0 - 1); cls = "0-1" if dd < 0.01 else "1-2" if dd < 0.02 else "2-3"
            ms = mstat.get(cls)
            if ms:
                reach = _clip(0.5 * reach + 0.5 * ms["p_touch"], 0, 1); retrace_frac = _clip(ms["retrace"], 0.1, 0.9); overshoot = ms["overshoot"]
                mag_used = {"class": cls, **ms}
    # Warum (k)ein Magnet -- ehrlich, statt "kein großes Cluster in Reichweite" für alle Fälle
    if dir_sign == 0:
        magnet_info["grund"] = "Richtung neutral (|Bias| ≤ 0,12): kein Ziel gewählt, Pfad läuft auf dem Sigma-Band"
    else:
        kand = liq_up if dir_sign > 0 else liq_dn
        if not kand:
            magnet_info["grund"] = f"kein Cluster ≥ Schwelle {'oben' if dir_sign > 0 else 'unten'} (größter dort {magnet_info['max_up' if dir_sign > 0 else 'max_dn'] / 1e6:.1f} Mio)"
        elif mag_used is None:
            dd = abs(kand[0]["px"] / p0 - 1)
            magnet_info["grund"] = (f"Ziel {kand[0]['px']:,.0f} ({kand[0]['notional'] / 1e6:.1f} Mio, {dd * 100:.1f} % entfernt) wird angelaufen; "
                                    f"Berührstatistik der Abstandsklasse fehlt noch (n < 5) -- Reichweite aus dem Bias")
        else:
            magnet_info["grund"] = f"Ziel {kand[0]['px']:,.0f} ({kand[0]['notional'] / 1e6:.1f} Mio) mit Berührstatistik der Klasse {mag_used['class']}"
    if dir_sign > 0:
        target = first_px(liq_up) or (p0 * (1 + sigma * 4)); wall = first_px(wall_up)
        if wall and wall < target: target = wall * 0.998                         # Wand bremst
    elif dir_sign < 0:
        target = first_px(liq_dn) or (p0 * (1 - sigma * 4)); wall = first_px(wall_dn)
        if wall and wall > target: target = wall * 1.002
    else:
        target = p0 * (1 + drift7 * 12)
    target = p0 + (target - p0) * (0.5 + 0.5 * reach)
    move = target / p0 - 1
    h1 = int(_clip(abs(move) / max(sigma, 1e-4) * 1.5, 4, 12))              # Dauer der ersten Bewegung
    if FL.get("event_signal"):
        h1 = max(2, h1 // 2)                                                # Ereignis: die Bewegung kommt schneller
        confidence = _clip(confidence + 0.08, 0.15, 0.92)
    # Kaskade: kreuzt der Weg einen Stop-Auslöser?
    cascade = None
    trig = first_px(stop_dn) if dir_sign < 0 else first_px(stop_up) if dir_sign > 0 else None
    if trig and ((dir_sign < 0 and target <= trig) or (dir_sign > 0 and target >= trig)):
        nxt = (liq_dn[1]["px"] if dir_sign < 0 and len(liq_dn) > 1 else liq_up[1]["px"] if dir_sign > 0 and len(liq_up) > 1 else None)
        c_target = nxt or (trig * (1 - 0.02 * dir_sign * -1) if dir_sign < 0 else trig * 1.02)
        cascade = {"trigger": trig, "target": c_target, "type": "Long-Squeeze" if dir_sign < 0 else "Short-Squeeze"}
    path = []; band = []
    for h in range(0, HORIZON_H + 1):
        if h <= h1:
            k = h / max(h1, 1); ease = 0.5 - 0.5 * math.cos(math.pi * k)
            px = p0 + (target - p0) * ease
        elif h <= 24:
            k = (h - h1) / max(24 - h1, 1)
            if cascade:
                px = target + (cascade["target"] - target) * min(1, k * 2)
                if k > 0.5:                                                    # Teilrückkehr nach der Kaskade
                    px = cascade["target"] + (target - cascade["target"]) * 0.5 * (k - 0.5) * 2
            else:
                px = target + (p0 - target) * retrace_frac * k                  # gemessene Rückkehr nach dem Sweep
        else:
            base = path[24]["px"] if len(path) > 24 else target
            dvol = sigma * math.sqrt(24)                                          # Tagesvolatilität
            daily = _clip(bias24 * dvol * 0.25 + drift7 * 24 * 0.3, -dvol * 0.3, dvol * 0.3)   # gedämpft: Drift ist die schwächste Information; ab hier zählt die 24-h-Spur
            px = base * math.exp(daily * (h - 24) / 24)
        path.append({"h": h, "ts": now + h * 3600, "px": px})
    # Ensemble: Modellpfad mit dem Analog-Median mischen (Gewichte aus der laufenden Trefferquote beider Modelle)
    model_p24 = path[24]["px"] if len(path) > 24 else None
    analog_p24 = None
    if analog and analog.get("ret"):
        ar = analog["ret"]; ah = sorted(ar)
        def a_ret(h):
            if h <= 0: return 0.0
            lo_h = max([x for x in ah if x <= h], default=None); hi_h = min([x for x in ah if x >= h], default=None)
            if lo_h is None: return ar[hi_h]["med"] * h / hi_h
            if hi_h is None: return ar[lo_h]["med"]
            if lo_h == hi_h: return ar[lo_h]["med"]
            return ar[lo_h]["med"] + (ar[hi_h]["med"] - ar[lo_h]["med"]) * (h - lo_h) / (hi_h - lo_h)
        wm, wa = ens_w.get("model", 0.6), ens_w.get("analog", 0.4)
        analog_p24 = p0 * math.exp(a_ret(24))
        for p in path:
            p["px_model"] = p["px"]
            p["px"] = math.exp(wm * math.log(p["px"]) + wa * math.log(p0 * math.exp(a_ret(p["h"]))))
    # Band: Volatilität x sqrt(t), je Stunde mit dem Zeitprofil der Stunde skaliert; ab 24 h mit den Analog-Quantilen gemischt
    vol_acc = 0.0
    for p in path:
        h = p["h"]; px = p["px"]
        if h > 0:
            g = time.gmtime(now + h * 3600); mult = (tprof or {}).get(f"{g.tm_wday}-{g.tm_hour}", 1.0)
            vol_acc += (sigma * mult * regime["band_mult"]) ** 2           # Regime (Vol, OI, Liquidationen, Varianz) weitet das Band
        w = math.sqrt(vol_acc) * (1.3 - confidence * 0.6) if h > 0 else sigma * 0.5
        lo_b, hi_b = px * math.exp(-w), px * math.exp(w)
        if analog and analog.get("ret") and h >= 24:
            ah = sorted(analog["ret"]); key = max([x for x in ah if x <= h], default=None)
            if key:
                q = analog["ret"][key]; alo, ahi = p0 * math.exp(q["q20"]), p0 * math.exp(q["q80"])
                lo_b, hi_b = math.exp(0.5 * math.log(lo_b) + 0.5 * math.log(alo)), math.exp(0.5 * math.log(hi_b) + 0.5 * math.log(ahi))
        band.append({"h": h, "lo": lo_b, "hi": hi_b})

    # ---- 5. Optimaler Kauf- und Verkaufspreis im Fenster 4-12 h --------------------------------------
    win = [p for p in path if 4 <= p["h"] <= 12]
    lo_pt = min(win, key=lambda p: p["px"]); hi_pt = max(win, key=lambda p: p["px"])
    # Kauf: an der Kaufwand oder dem Long-Cluster (nach dem Sweep), sonst Pfadtief; nie über dem Kurs, wenn Druck nach unten
    buy_px = lo_pt["px"]; buy_reason = f"Pfadtief im Fenster (Stunde {lo_pt['h']})"
    if wall_dn and wall_dn[0]["px"] < p0 and wall_dn[0]["px"] > buy_px * 0.99:
        buy_px = wall_dn[0]["px"] * 1.0015; buy_reason = f"knapp über der Kaufwand {wall_dn[0]['px']:,.0f} ({wall_dn[0]['notional']/1e6:.0f} Mio)"
    if liq_dn and abs(liq_dn[0]["px"] / buy_px - 1) < 0.006:
        buy_px = liq_dn[0]["px"] * (1 - max(0.003, overshoot)); buy_reason = f"unter dem Long-Liquidationscluster {liq_dn[0]['px']:,.0f} — nach dem Sweep kaufen (gemessener Überschuss {max(0.3, overshoot*100):.1f} %)"
    if cascade and cascade["type"] == "Long-Squeeze":
        buy_px = min(buy_px, cascade["target"] * 1.003); buy_reason = f"Kaskadenziel {cascade['target']:,.0f} — erst nach der Kaskade kaufen"
    sell_px = hi_pt["px"]; sell_reason = f"Pfadhoch im Fenster (Stunde {hi_pt['h']})"
    if wall_up and wall_up[0]["px"] > p0 and wall_up[0]["px"] < sell_px * 1.01:
        sell_px = wall_up[0]["px"] * 0.9985; sell_reason = f"knapp unter der Verkaufswand {wall_up[0]['px']:,.0f} ({wall_up[0]['notional']/1e6:.0f} Mio)"
    if liq_up and abs(liq_up[0]["px"] / sell_px - 1) < 0.006:
        sell_px = liq_up[0]["px"] * (1 + max(0.003, overshoot)); sell_reason = f"über dem Short-Liquidationscluster {liq_up[0]['px']:,.0f} — in den Squeeze verkaufen (gemessener Überschuss {max(0.3, overshoot*100):.1f} %)"
    if cascade and cascade["type"] == "Short-Squeeze":
        sell_px = max(sell_px, cascade["target"] * 0.997); sell_reason = f"Kaskadenziel {cascade['target']:,.0f} — in die Kaufkaskade verkaufen"
    # Liegt der ganze Pfad im Fenster über dem Kurs, ist jetzt der beste Kauf -- als Limit knapp unter dem Kurs,
    # sonst an der nächsten Kaufwand. Umgekehrt für den Verkauf.
    if buy_px > p0:
        if wall_dn and wall_dn[0]["px"] > p0 * 0.985:
            buy_px = wall_dn[0]["px"] * 1.0015; buy_reason = f"Pfad steigt — Limit knapp über der Kaufwand {wall_dn[0]['px']:,.0f} (sonst Markt)"
        else:
            buy_px = p0 * 0.998; buy_reason = "Pfad liegt im Fenster über dem Kurs — jetzt, Limit knapp unter dem Kurs"
    if sell_px < p0:
        if wall_up and wall_up[0]["px"] < p0 * 1.015:
            sell_px = wall_up[0]["px"] * 0.9985; sell_reason = f"Pfad fällt — Limit knapp unter der Verkaufswand {wall_up[0]['px']:,.0f} (sonst Markt)"
        else:
            sell_px = p0 * 1.002; sell_reason = "Pfad liegt im Fenster unter dem Kurs — jetzt, Limit knapp über dem Kurs"
    buy_ok = bias > -0.45
    sell_ok = bias < 0.45
    buy = {"px": buy_px, "dist_pct": (buy_px / p0 - 1) * 100, "window_h": [4, 12], "reason": buy_reason, "advised": buy_ok,
           "note": None if buy_ok else f"Richtungsdruck klar nach unten ({bias:+.2f}) — Kauf im Fenster nicht ratsam; Kaufzone erst nach der Bewegung"}
    sell = {"px": sell_px, "dist_pct": (sell_px / p0 - 1) * 100, "window_h": [4, 12], "reason": sell_reason, "advised": sell_ok,
            "note": None if sell_ok else f"Richtungsdruck klar nach oben ({bias:+.2f}) — Verkauf im Fenster nicht ratsam; halten, Verkaufszone weiter oben"}
    end = path[-1]["px"]; b_end = band[-1]
    outlook = {"end_px": end, "end_pct": (end / p0 - 1) * 100, "lo": b_end["lo"], "hi": b_end["hi"],
               "target_12h": target, "target_pct": move * 100, "h1": h1, "cascade": cascade}
    # ---- ALLE 30 Treiber in der Tabelle (22.09.): Inaktive mit Grund, Ereignis-Treiber mit Marke ----------
    _aktiv = {d["name"] for d in drivers}
    for d in drivers:
        if d["name"] in EREIGNIS_TREIBER:
            d["ereignis"] = True if d["name"] not in ("Wal-Flow 30 min", "Leaderboard-Flow 60 min") else ("EREIGNIS-SIGNAL" in (d.get("text") or ""))
    inaktiv = []
    for name in PRIORS:
        if name in _aktiv:
            continue
        grund = next((m for m in missing if name in m), None)
        if grund is None:
            grund = f"{name} ({INAKTIV_GRUND.get(name, 'Bedingung nicht erfüllt oder Daten fehlen')})"
            missing.append(grund)
        lw = (W.get(name) or {}).get("weight"); lw24 = (W24.get(name) or {}).get("weight")
        inaktiv.append({"name": name, "score": None, "weight": lw if lw is not None else PRIORS[name], "prior": PRIORS[name],
                        "weight_24": lw24 if lw24 is not None else PRIORS[name], "learned": lw is not None and abs(lw - PRIORS[name]) > 1e-9,
                        "hit_rate": (W.get(name) or {}).get("hit_rate"), "n_eff": (W.get(name) or {}).get("n_eff"), "ci": (W.get(name) or {}).get("ci"),
                        "lift": (W.get(name) or {}).get("lift"), "lift_z": (W.get(name) or {}).get("lift_z"), "oos": (W.get(name) or {}).get("oos"),
                        "ereignis": False if name in EREIGNIS_TREIBER else None,
                        "text": grund[len(name):].strip(" (").rstrip(")") if grund.startswith(name) else grund})
    label = "bullisch" if bias > 0.35 else "leicht bullisch" if bias > 0.12 else "bärisch" if bias < -0.35 else "leicht bärisch" if bias < -0.12 else "neutral"
    return {"ts": now, "coin": coin, "price": p0, "bias": round(bias, 3), "bias_24": round(bias24, 3),
            "p_up": round(p_up, 4), "p_up_24": round(p_up_24, 4), "beta": round(beta4, 3), "beta_24": round(beta24, 3),
            "p_up_v1": round(p_up_v1, 4), "p_up_v2": (round(p_up_v2, 4) if p_up_v2 is not None else None),
            "p_up_24_v2": (round(p_up_24_v2, 4) if p_up_24_v2 is not None else None), "kalib": kalib, "kalib2": kalib2_info,
            "magnet_info": magnet_info, "regime": regime, "n_treiber": len(PRIORS),
            "label": label, "confidence": round(confidence, 2),
            "sigma_h": sigma, "drivers": sorted(drivers, key=lambda d: -abs(d["score"] * d["weight"])), "missing": missing, "inaktiv": inaktiv,
            "elite_konten": elite_konten,
            "magnets": magnets, "path": path, "band": band, "buy": buy, "sell": sell, "outlook": outlook,
            "n_directional_lb": len(dir_addrs), "wver": learned.get("wver"),
            "ensemble": {"model_p24": model_p24, "analog_p24": analog_p24, "w_model": ens_w.get("model", 0.6), "w_analog": ens_w.get("analog", 0.4)},
            "analog": {k: v for k, v in (analog or {}).items() if k != "examples"} if analog else None,
            "analog_examples": (analog or {}).get("examples"), "magnet_stats": mstat, "magnet_used": mag_used, "tprof_used": bool(tprof),
            "learned_n": sum(1 for d in drivers if d.get("learned"))}


def nulltest(seed: int = 1, verbose: bool = True) -> bool:
    """
    Nulltest: Die gesamte Statistikstrecke läuft über reines Rauschen -- Random Walk mit
    realistischer Volatilität, zufällige Treiberwerte, zufällige Cluster. Das Soll kommt aus
    der Mathematik, nicht aus dem heutigen Ergebnis, und kann deshalb keinen Fehler festschreiben
    (der Binance-Selbsttest hatte den Zeitstempel-Fehler jahrelang als korrekt bestätigt):

      - Trefferquote 4 h und 24 h: Intervall enthält 50 %            (M7 hätte 55,1 % gezeigt)
      - Brier-Skill der gespeicherten Wahrscheinlichkeit nahe 0
      - gelernte Gewichte bleiben nahe am Prior, beta nahe 1         (lam = 4 / n_eff)
      - Magnet-Lift: Intervall der Berührquote enthält die Placebo-Quote
      - Rang-Signal feuert mit der Nennrate (etwa 2 % der Stunden), nicht mit 42 %
      - Wilson-Intervall deckt eine Quote von 50 % in rund 95 % der Fälle
    """
    import random, tempfile, os
    rng = random.Random(seed)
    ok_all = True
    def line(ok, name, detail):
        nonlocal ok_all
        ok_all = ok_all and ok
        if verbose:
            print(f"  {'ok  ' if ok else 'FEHL'} {name:<38} {detail}")
    if verbose:
        print("Nulltest der Statistik (reines Rauschen, Soll aus der Mathematik)")

    # 1. Wilson-Überdeckung
    treffer = 0; laeufe = 400
    for _ in range(laeufe):
        n_ = 30; h_ = sum(1 for _ in range(n_) if rng.random() < 0.5)
        lo, hi = wilson(h_, n_)
        treffer += 1 if lo <= 0.5 <= hi else 0
    cov = treffer / laeufe
    line(0.90 <= cov <= 0.99, "Wilson-Überdeckung (Soll ~95 %)", f"{cov:.1%}")

    # 2. Random Walk (Minutenbars) und Rausch-Prognosen alle 15 min über 14 Tage
    tmp = tempfile.mkdtemp(); store = os.path.join(tmp, "null.db")
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    con.execute("CREATE INDEX ix ON bars(coin, ts)")
    now = int(time.time()) // 900 * 900
    tage = 14; start = now - tage * 86400
    px = 60000.0; rows = []
    sig_min = 0.006 / math.sqrt(60)                     # 0,6 % je Stunde
    for t in range(start, now + 60, 60):
        o = px; px *= math.exp(rng.gauss(0, sig_min))
        rows.append((t, "BTC", o, max(o, px), min(o, px), px, 10.0, 5))
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); con.commit()
    closes = {r[0]: r[5] for r in rows}
    st = store_connect(store)
    names = list(PRIORS)[:8]
    n_fc = 0
    for t in range(start, now - 24 * 3600, 900):
        p0 = closes[t]
        drivers = [{"name": nm, "score": rng.uniform(-1, 1), "weight": PRIORS[nm]} for nm in names]
        bias = sum(d["score"] * d["weight"] for d in drivers) / sum(d["weight"] for d in drivers)
        p_up = _sigmoid(sum(d["score"] * d["weight"] for d in drivers) / PRIOR_SUMME)
        pred4 = p0 * (1 + bias * 0.004); pred24 = p0 * (1 + bias * 0.01)
        st.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, confidence, p_4h, p_24h, payload, p_up, p_up_24) VALUES (?,?,?,?,?,?,?,?,?,?)",
                   (t, "BTC", p0, bias, 0.5, pred4, pred24, json.dumps({"drivers": drivers}), p_up, p_up))
        n_fc += 1
    st.commit(); st.close()

    # 3. Trefferquote und Brier auf Rauschen
    sc = score_forecasts(con, "BTC", store)
    for key in ("q4", "q24"):
        q = sc[key]
        ci = q.get("ci") or (0, 1)
        line(q["n"] > 0 and ci[0] <= 0.5 <= ci[1], f"Trefferquote {q['h']} h enthält 50 %",
             f"{(q['hit_rate'] or 0):.1%} ({ci[0]:.0%}–{ci[1]:.0%}), n={q['n']}, n_eff={q['n_eff']}, Basis {(q['base'] or 0):.0%}")
        bs = q.get("brier_skill")
        line(bs is not None and abs(bs) < 0.05, f"Brier-Skill {q['h']} h nahe 0", f"{bs if bs is None else round(bs, 3)}")

    # 4. Kalibrierung: Gewichte bleiben beim Prior, beta nahe 1
    meta: dict = {}
    w = calibrate_weights(con, "BTC", store, horizon_h=4, meta=meta)
    abw = max(abs(v["weight"] - v["prior"]) for k, v in w.items() if k in names)
    line(meta.get("gelernt") and abw <= 0.15 and 0.5 <= meta.get("beta", 1) <= 1.5,
         "Gewichte auf Rauschen nahe Prior", f"max. Abweichung {abw:.3f}, beta {meta.get('beta')}, n={meta.get('n')}, n_eff={meta.get('n_eff')}, lam={meta.get('lam')}")

    # 5. Magnet-Lift: zufällige Cluster in 0,2..3 % Abstand, ein Schnappschuss je 15 min
    con.execute("CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL)")
    con.execute("CREATE INDEX ih ON heatmap(coin, ts)")
    hm = []
    for t in range(start + 86400, now - 12 * 3600, 900):
        p0 = closes[t]
        for _ in range(3):
            d = rng.uniform(0.002, 0.03) * rng.choice((-1, 1))
            hm.append((t, "BTC", round(p0 * (1 + d), 1), "short" if d > 0 else "long", 20e6))
    con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?)", hm); con.commit()
    ms = magnet_stats(con, "BTC", days=tage) or {}
    n_cls = 0; lift_ok = True; txt = []
    for cls, v in sorted(ms.items()):
        n_cls += 1
        lo, hi = v["ci"]
        ok = lo <= v["p_placebo"] <= hi
        lift_ok = lift_ok and ok
        txt.append(f"{cls} %: berührt {v['p_touch']:.0%} ({lo:.0%}–{hi:.0%}) · Placebo {v['p_placebo']:.0%} · n={v['n']}")
    line(n_cls >= 2 and lift_ok, "Magnet-Lift auf Rauschen = 1", " | ".join(txt) or "keine Klassen")

    # 5b. Magnet-Varianten (0,5-1 %, 1-2 %) auf Rauschen: Differenz zum Placebo und Anziehung nahe null
    mv = magnet_varianten(con, "BTC", days=tage) or {}
    ok_mv = True; txt = []
    for vname in ("0.5-1", "1-2"):
        z = mv.get(vname) or {}
        for h in (4, 24):
            c = z.get(h) or {}
            if c.get("z_delta") is None:
                continue
            ok_mv = ok_mv and abs(c["z_delta"]) < 3 and abs(c.get("anziehung_pct", 0)) < 0.5
            txt.append(f"{vname}/{h}h Δ{c['delta_pp']:+.0f} pp z{c['z_delta']:+.1f} Anz {c['anziehung_pct']:+.2f} %")
        ch = z.get("cho15") or {}
        if ch.get("p_zum") is not None:
            ok_mv = ok_mv and abs(ch["p_zum"] - ch["basis"]) < 0.06
            txt.append(f"{vname} Cho15 {ch['p_zum']:.2f}/{ch['basis']:.2f}")
    line(bool(txt) and ok_mv, "Magnet-Varianten auf Rauschen: kein Zug", " · ".join(txt) or "keine Zellen")

    # 5c. Neue Indikatoren (Audit v3) auf Rauschen: Scores ohne Vorzeichen-Bias, Regime nahe 1
    try:
        rng2 = random.Random(11); con2 = sqlite3.connect(":memory:")
        con2.executescript("""
            CREATE TABLE bnc_metrics (ts INTEGER, coin TEXT, metric TEXT, value REAL, PRIMARY KEY (ts, coin, metric));
            CREATE TABLE ctx_bars (ts INTEGER, coin TEXT, mark_px REAL, funding REAL, oi REAL);
            CREATE TABLE lb_trend (ts INTEGER, coin TEXT, top_n INTEGER, n_long INTEGER, n_short INTEGER, usd_long REAL, usd_short REAL, net_usd REAL, n_accounts INTEGER, mark_px REAL);
            CREATE TABLE etf_flows (day TEXT, coin TEXT, flow_musd REAL, fetched INTEGER);
            CREATE TABLE ext_metrics (ts INTEGER, exchange TEXT, coin TEXT, metric TEXT, value REAL);
            CREATE TABLE ext_liquidations (ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT);
            CREATE TABLE bnc_liquidations (ts INTEGER, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, order_id TEXT);
            CREATE TABLE liquidations (ts INTEGER, coin TEXT, user TEXT, method TEXT, mark_px REAL, px REAL, sz REAL, side TEXT, tid INTEGER);
            CREATE TABLE bars10 (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, vol_buy REAL, vol_sell REAL);
            CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER);
        """)
        t0_ = (int(time.time()) - 40 * 86400) // 3600 * 3600; px_ = 100.0; bars_ = []; ctx_ = []; oi_ = 1e9   # auf volle Stunde, damit Stundenreihen entstehen
        for t_ in range(t0_, int(time.time()) + 1, 60):
            px_ *= math.exp(rng2.gauss(0, 0.0008)); bars_.append((t_, "BTC", px_, px_ * 1.0005, px_ * 0.9995, px_, 1.0, 1))
            if t_ % 3600 == 0:
                oi_ *= math.exp(rng2.gauss(0, 0.01)); ctx_.append((t_, "BTC", px_, rng2.gauss(0, 0.00005), oi_))
        con2.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", bars_); con2.executemany("INSERT INTO ctx_bars VALUES (?,?,?,?,?)", ctx_)
        con2.executemany("INSERT INTO bnc_metrics VALUES (?,?,?,?)", [(t_, "BTC", "open_interest", o_ / 1e5) for t_, _, _, _, o_ in ctx_])
        con2.executemany("INSERT INTO bnc_metrics VALUES (?,?,?,?)", [(t_, "BTC", "funding", rng2.gauss(0.0001, 0.0002)) for t_, *_ in ctx_])
        con2.executemany("INSERT INTO ext_metrics VALUES (?,?,?,?,?)", [(t_, "bybit", "BTC", "funding_8h", rng2.gauss(0.0001, 0.0002)) for t_, *_ in ctx_])
        con2.executemany("INSERT INTO lb_trend VALUES (?,?,?,?,?,?,?,?,?,?)", [(t_, "BTC", 20, 10, 10, abs(rng2.gauss(5e8, 1e8)), abs(rng2.gauss(5e8, 1e8)), 0, 20, px_) for t_, *_ in ctx_])
        con2.executemany("INSERT INTO etf_flows VALUES (?,?,?,?)", [(time.strftime("%Y-%m-%d", time.gmtime(t0_ + d_ * 86400)), "BTC", rng2.gauss(0, 200), 0) for d_ in range(40)])
        con2.executemany("INSERT INTO ext_liquidations VALUES (?,?,?,?,?,?,?,?)", [(t_ + rng2.randint(0, 3599), "bybit", "BTC", rng2.choice(("long", "short")), 100.0, 1.0, abs(rng2.gauss(2e5, 1e5)), f"u{i_}") for i_, (t_, *_) in enumerate(ctx_) for _ in range(3)])
        con2.executemany("INSERT INTO bars10 VALUES (?,?,?,?,?,?,?,?)", [(t_, "BTC", 100, 100, 100, 100, abs(rng2.gauss(10, 3)), abs(rng2.gauss(10, 3))) for t_ in range(int(time.time()) - 31 * 86400, int(time.time()) + 1, 10)])
        con2.commit()
        # Vorzeichen-Bias: Scores über viele "Jetzt"-Zeitpunkte lassen sich hier nicht simulieren (Funktionen lesen 'jetzt');
        # stattdessen: alle Funktionen liefern etwas Sinnvolles und keine extremen Scores auf Rauschen
        werte = {}
        for name_, fn_ in (("oi", hl_indikatoren.oi_perzentil), ("crowd", hl_indikatoren.crowding), ("etf", hl_indikatoren.etf_momentum),
                           ("vol", hl_indikatoren.vol_regime), ("fspread", hl_indikatoren.funding_spread), ("liq", hl_indikatoren.liquidationsdruck),
                           ("var", hl_indikatoren.varianz_kompression)):
            werte[name_] = fn_(con2, "BTC")
        sc_ = [abs(v.get("score", 0) or 0) for v in werte.values() if v]
        reg_ = hl_indikatoren.regime(werte.get("oi"), werte.get("vol"), werte.get("liq"), werte.get("var"))
        ok_i = all(werte.get(k) is not None for k in ("oi", "crowd", "etf", "vol", "fspread", "liq", "var")) and max(sc_ or [0]) <= 1.0 and 0.7 <= reg_["band_mult"] <= 2.2
        line(ok_i, "Neue Indikatoren auf Rauschen", " · ".join(f"{k} {'ok' if v else 'None'}{' ' + format(v.get('score', 0) or 0, '+.2f') if v and 'score' in v else ''}" for k, v in werte.items()) + f" · Band ×{reg_['band_mult']}")
    except Exception as e_:
        line(False, "Neue Indikatoren auf Rauschen", f"{type(e_).__name__}: {e_}")

    # 6. Rang-Signal: dünn besetzte Stundenreihe (75 % Nullen, schwere Ränder)
    reihe = [0.0 if rng.random() < 0.75 else rng.gauss(0, 1) * (10 if rng.random() < 0.1 else 1) for _ in range(168 * 8)]
    feuer = 0; n_h = 0
    for i in range(168, len(reihe)):
        aktive = [v for v in reihe[i - 168:i] if v != 0.0]
        r = rang_in_reihe(reihe[i], aktive)
        n_h += 1; feuer += 1 if (r is not None and r >= 98) else 0
    rate = feuer / n_h
    line(rate <= 0.04, "Rang-Signal feuert mit Nennrate", f"{rate:.1%} der Stunden (Soll ≈ 2 %; Z-Wert mit Nullstunden: 42 %)")

    con.close()
    try:
        for f in os.listdir(tmp):
            os.remove(os.path.join(tmp, f))
        os.rmdir(tmp)
    except OSError:
        pass
    if verbose:
        print("  Ergebnis:", "bestanden" if ok_all else "NICHT bestanden")
        try:
            positivkontrolle(seed=seed)
        except Exception as e:
            print(f"  Positivkontrolle nicht ausführbar: {type(e).__name__}: {e}")
    return ok_all


def positivkontrolle(seed: int = 1, tage: int = 21, verbose: bool = True) -> dict:
    """
    Positivkontrolle der Kalibrierung (Audit v10, K2): Der Nulltest prüft, dass Rauschen NICHT gelernt
    wird -- er prüfte nie, dass Signal gelernt WIRD. Hier: ein Treiber trifft die 4-h-Richtung mit
    Wahrscheinlichkeit `kante` (konstant je 4-h-Block), zwölf weitere sind Rauschen; alles läuft durch
    calibrate_weights(4 h). SOLL (nach dem Neubau): kante 0,65 -> p_up bei Score +0,6 in [0,60; 0,70];
    kante 0,50 -> Gewicht nahe null. Bis zum Neubau ist dieser Abschnitt INFORMATIV (kein Tor):
    er dokumentiert den bekannten Befund und fällt auf, sobald sich das Verhalten ändert.
    """
    import random as _rnd, tempfile as _tf, os as _os
    out = {}
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    rng = _rnd.Random(seed); now = int(time.time()) // 900 * 900; start = now - tage * 86_400; px = 100.0; rows = []
    t = start - 5 * 3600
    while t <= now:
        px *= math.exp(rng.gauss(0, 0.0006)); rows.append((t, "BTC", px, px, px, px, 1, 1)); t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows); close = {r[0]: r[5] for r in rows}
    rausch = [n for n in list(PRIORS)[:13] if n != "Taker-Flow"][:12]
    for kante in (0.5, 0.65, 0.9):
        tmp = _tf.mkdtemp(); st = _os.path.join(tmp, "f.db"); c = store_connect(st)
        for ts in range(start, now - 4 * 3600, 900):
            p0 = close[ts]; fut = close.get(ts + 4 * 3600)
            if not fut:
                continue
            up = fut > p0; richtig = _rnd.Random(ts // 14_400 + seed).random() < kante
            s_ = (1 if up else -1) if richtig else (-1 if up else 1)
            drivers = [{"name": "Taker-Flow", "score": 0.6 * s_}] + [{"name": n, "score": rng.uniform(-.6, .6)} for n in rausch]
            c.execute("INSERT OR REPLACE INTO forecast (ts, coin, price, bias, p_4h, p_24h, payload) VALUES (?,?,?,?,?,?,?)",
                      (ts, "BTC", p0, 0, p0, p0, json.dumps({"drivers": drivers})))
        c.commit(); c.close()
        meta = {}; w = calibrate_weights(con, "BTC", path=st, horizon_h=4, meta=meta)
        d = w.get("Taker-Flow") or {}; beta = meta.get("beta", 1.0)
        p_up = _sigmoid(beta * (d.get("weight") or 0) * 0.6 / PRIOR_SUMME)
        out[kante] = {"quote": d.get("hit_rate"), "gewicht": d.get("weight"), "beta": beta, "p_up": p_up, "n_eff": meta.get("n_eff")}
        try:
            for f in _os.listdir(tmp):
                _os.remove(_os.path.join(tmp, f))
            _os.rmdir(tmp)
        except OSError:
            pass
    if verbose:
        print("  Positivkontrolle der Kalibrierung (Audit v10 K2, informativ -- Soll nach Neubau: Kante 0,65 → p_up 0,60–0,70):")
        for k, v in out.items():
            print(f"    Kante {k:.2f}: Quote {(v['quote'] or 0) * 100:5.1f} % · Gewicht {v['gewicht'] or 0:.3f} (Prior 0,7) · β {v['beta']:.2f} · "
                  f"p_up bei Score +0,6 = {v['p_up'] * 100:.1f} % · n_eff {v['n_eff']}")
        lernt = out[0.65]["p_up"] >= 0.58
        print("    Stand v1:", "bildet die Kante ab" if lernt else "NICHT LERNFÄHIG (K2) -- v1 bleibt bis zum Umschalten; der Neubau v2 läuft im Schatten (hl_kalib.py --nulltest zeigt sein Tor)")
    return out


if __name__ == "__main__":
    import sys as _sys
    if "--nulltest" in _sys.argv:
        _sys.exit(0 if nulltest() else 1)
    # Selbsttest mit synthetischen Daten
    import random
    rng = random.Random(1); now = int(time.time()); p = 77000.0; C = []
    for h in range(200):
        o = p; p *= 1 + rng.gauss(0.0002, 0.006); C.append({"t": now - (200 - h) * 3600, "o": o, "h": max(o, p), "l": min(o, p), "c": p, "v": 100})
    chart = {"candles": C, "price": p, "mas": {"ma200d": p * 0.9, "ma50w": p * 1.02}, "trend_60m": 0.004, "rsi14": 58, "funding": 0.00003,
             "vol_1h": 30e6, "book": {"imb_50": 0.3},
             "levels": [{"px": p * 1.02, "side": "short", "notional": 40e6}, {"px": p * 0.985, "side": "long", "notional": 35e6}, {"px": p * 0.97, "side": "long", "notional": 60e6}],
             "stops": {"clusters": [{"kind": "limit_buy", "px": p * 0.99, "notional": 25e6}, {"kind": "limit_sell", "px": p * 1.015, "notional": 30e6}, {"kind": "stop_sell", "px": p * 0.992, "notional": 12e6}]}}
    con = sqlite3.connect(":memory:"); con.execute("CREATE TABLE bars (ts, coin, close)")
    con.execute("CREATE TABLE lb_positions (ts, rank, addr, coin, side, size, pos_value, entry_px, liq_px, leverage, upnl, mark_px)")
    con.execute("CREATE TABLE lb_fills (ts, addr, coin, market, dir, side, px, sz, notional, closed_pnl, fee, tid, buy)")
    fc = compute_forecast(con, "BTC", chart, {"directional": {"n_long": 12, "usd_long": 300e6, "n_short": 5, "usd_short": 90e6, "n_directional": 17}},
                          None, None, None, {"last": 120, "sum5": 400, "last_date": "2026-09-10"}, {"metrics": {"taker_ls": 1.3}}, {"taker_ls": 1.1, "taker_span_s": 120})
    print(f"Bias {fc['bias']:+.2f} ({fc['label']}) · Konfidenz {fc['confidence']:.0%} · Kauf {fc['buy']['px']:,.0f} ({fc['buy']['dist_pct']:+.2f} %) — {fc['buy']['reason']}")
    print(f"Verkauf {fc['sell']['px']:,.0f} ({fc['sell']['dist_pct']:+.2f} %) — {fc['sell']['reason']} · 7 T: {fc['outlook']['end_pct']:+.2f} % · Band {fc['outlook']['lo']:,.0f}–{fc['outlook']['hi']:,.0f}")
    for d in fc["drivers"][:5]:
        print(f"  {d['name']:<28} {d['score']:+.2f} × {d['weight']:.1f}  {d['text']}")
    print("fehlend:", fc["missing"])
