# RECHERCHE U152 — Gängige Kennzahlen für „95 % Hebel gegen 5 % Spot“

**Stand:** 13.10.2026 · **Anlass:** `KONZEPT_Hebel.md` Abschnitt 11 Punkt 2 (entschieden 11.10.2026): Die 95 % stammen aus einer
anderen Kennzahl, die Quelle ist dem Nutzer nicht mehr bekannt. Diese Liste soll ihm helfen, sie wiederzuerkennen; danach folgt ein
neuer Test mit eigener Nummer.
**Bezug:** U142 H3 hat genau eine Abgrenzung geprüft — Perp-Anteil am Binance-Volumen, BTC und ETH, Tageswerte 2020–2026: nie ≥ 95 %
(BTC Jahresmedian 78–90 %, 90-%-Quantil höchstens 91,0 %; ETH 68–92 %, höchstens 93,8 %).

> Keine Anlageberatung. Das Dokument beschreibt Kennzahlen und Datenquellen; es empfiehlt keine Trades.

**Lesart:** „Belegt“ heißt: mit Quelle und URL. „(gerechnet)“ heißt: von mir aus den Zahlen der Quelle umgerechnet. „Behauptung“ heißt:
Aussage in einem Artikel oder Post ohne nachprüfbare Rechnung. Fehlt ein Beleg, steht „nicht belegt“. Werte von Glassnode-Seiten wurden
am 13.10.2026 abgelesen; wann genau der Wert berechnet wurde, zeigt die Seite nicht.

## 0. Kurzfassung

- **Nur eine gängige Kennzahl liegt wirklich bei „95 zu 5“: der Perp-Anteil auf Hyperliquid.** Spot macht dort rund 3 % des
  Perp-Volumens aus (≈ 97 % Perps). In den letzten 30 Tagen bis etwa 27.09.2026 waren es 97,6 % (gerechnet). Im August 2025 lag
  der Spot-Anteil bei 5,3 %, also genau 94,7 zu 5,3. Auf Hyperliquid ist das aber der **Normalzustand**, kein Extremwert.
- **An den Börsen (CEX) kommt nur CryptoQuants BTC-Messung über alle Börsen (in BTC) heran.**
  - Derivate waren 2025 laut Artikeln „durchgehend über 90 %“, im Mai 2025 93,7 % (Monat).
  - Die genannte Spitze der Verhältnisreihe ist 16,6:1 (= 94,3 %) am 06.05.2025.
  - Die in denselben Artikeln genannten **Tagesvolumen** ergeben dagegen an Einzeltagen **über 95 %** (gerechnet): 07.04.2025 über
    97,7 %, 01.05.2025 ≈ 97,6 %, 26.05.2025 ≈ 95,1 %.
  - Beide Angaben widersprechen sich; ob die Verhältnisreihe geglättet ist, sagen die Artikel nicht. **≥ 95 % ist damit wahrscheinlich,
    aber nicht sauber belegt.**
- **Alle anderen Abgrenzungen bleiben deutlich unter 95 %:**
  - CoinDesk Data (früher CCData), alle Coins: Rekord 79–80 % im Jahr 2023, Mai 2026 78,2 %.
  - Glassnode, BTC über alle Börsen: heute 88,7 %; ETH 90,6 %.
  - The Block: 83–84 % (April 2025).
  - Binance: 89–91 % (CryptoQuant, Alphractal 2026).
- **ELR, OI ÷ Marktkapitalisierung, OI ÷ Volumen** sind Verhältniszahlen in anderen Größenordnungen (ELR 0,1–0,8;
  OI ÷ Marktkapitalisierung 2–5 %; OI ÷ Futuresvolumen heute 181 %).
  „95“ passt dort nur als **Perzentil** („Hebel im 95. Perzentil“). Einen gängigen Anbieter-Standard „95. Perzentil“ habe ich nicht
  gefunden.
- **Verwechslungsgefahr mit anderen bekannten „95 %“-Zahlen:**
  - Bitwise 2019: „95 % des gemeldeten Bitcoin-Spotvolumens sind gefälscht“.
  - Perps machen 92–93 % des Derivatevolumens aus (gegenüber Termin-Futures, nicht gegenüber Spot).
  - Hyperliquid gibt „über 95 % der Einnahmen“ für Rückkäufe aus.
- **Liquidations-Vorlauf:** Für keine dieser Kennzahlen fand ich eine systematische, außerhalb der Stichprobe geprüfte Studie. Es gibt
  nur Deutungen von Anbietern und Analysten sowie Einzelfälle. Rigoros belegt ist nur Verwandtes: Hoher Carry (Basis bzw. Funding)
  kündigt Crashs an (BIS WP 1087). Der eigene Test U142 H4 (oberstes Zehntel des Binance-Perp-Anteils) fand eher **weniger** Wellen
  (RR 0,53).

## 1. Umrechnung Anteil ↔ Verhältnis

Derivate-Anteil s = D ÷ (D + S); Derivate ÷ Spot = s ÷ (1 − s); Spot ÷ Derivate (so zeigen es Glassnode und The Block) = (1 − s) ÷ s.

| Derivate-Anteil | Derivate ÷ Spot | Spot ÷ Derivate |
|---|---|---|
| 75 % | 3,0 | 0,333 |
| 80 % | 4,0 | 0,250 |
| 88,9 % | 8,0 | 0,125 |
| 90 % | 9,0 | 0,111 |
| 93,7 % | 14,9 | 0,067 |
| **95 %** | **19,0** | **0,0526** |
| 97 % | 32,3 | 0,031 |

## 2. Übersicht

| Kennzahl | Definition | Anbieter / Kosten | Historie | Höchstwerte seit 2020 / je ≥ 95 %? | Beleg für Liquidations-Vorlauf |
|---|---|---|---|---|---|
| **K0 Referenz: Perp-Anteil Binance** (U142) | Perps (USDⓈ-M + COIN-M) ÷ (Perps + alle Stablecoin-Spotpaare), USD, je Tag | data.binance.vision, kostenlos | täglich ab 2020 | BTC Median 78–90 %, 90-%-Quantil ≤ 91,0 %; ETH ≤ 93,8 % — **nie ≥ 95 %** | eigener Test: H4 (oberstes Zehntel) RR 0,53, eher seltener |
| **K1 Derivate-Anteil am CEX-Gesamtvolumen** (a) | Derivate ÷ (Spot + Derivate), alle Coins, ausgewählte CEX, USD, je Monat | CoinDesk Data (ex CCData) „Exchange Review“: Berichte frei lesbar; freie API seit 21.05.2026 eingestellt, Preis auf Anfrage | monatlich (Berichte mindestens seit 2020); täglich nur per Bezahl-API | Rekord Mai 2023: 79,1–79,8 %; Sep 2023 ≈ 79,6 % (gerechnet); Mai 2026 78,2 % — **nie ≥ 95 %** | kein Beleg gefunden |
| **K2 BTC Derivate ÷ Spot, alle Börsen** (b, CryptoQuant) | Derivatevolumen ÷ Spotvolumen in BTC, je Tag (als Anteil zitiert) | CryptoQuant: API-Stufe Basic kostenlos (Marktdaten täglich, nur 30 Tage); bezahlt 1 Jahr bzw. volle Historie (ca. 29 / 99 / 799 USD/Monat laut Vergleichsseite) | täglich; Börsen ab Listung (Binance-Spot ab 08/2017) | 2025 „durchgehend > 90 %“; Mai 2025 93,7 %; Spitze der Verhältnisreihe 16,6:1 = 94,3 % (06.05.2025); aus genannten Tagesvolumen aber 95–98 % (07.04., 01.05., 26.05.2025, gerechnet) — **≥ 95 % widersprüchlich, wahrscheinlich an Einzeltagen** | nur Analysten-Deutung („keine Richtung, verstärkt Schwankung“) |
| **K3 Spot ÷ Futures, alle Börsen** (b, Glassnode) | Spotvolumen ÷ Futuresvolumen; 95 % ↔ 0,0526 | Glassnode Studio; Advanced ca. 49 USD/Monat (jährlich); API nur eingeschränkt bzw. Professional (individuell) | Seite ohne Angabe; zusätzlich PiT-Variante | 13.10.2026: BTC 0,128 → 88,7 %, ETH 0,103 → 90,6 %; Allzeit-Minimum nicht belegt | kein Beleg gefunden |
| **K4 Spot ÷ Futures (30-Tage-Mittel)** (b, The Block) | Spotvolumen ÷ Futuresvolumen, BTC und ETH | The Block Data (Dashboard, teils Pro-Abo; Preis nicht geprüft) | seit mindestens 2020 | BTC 2020–2022 meist 0,2–0,4 (71–83 %); 04/2025 BTC 0,19 (84 %), ETH 0,20 (83 %) — **nein** | kein Beleg gefunden |
| **K5 Futures ÷ Spot** (b, CoinGlass) | aggregiertes Futures- und Spotvolumen je Coin (Website: 24-h-Werte) | Website frei; API 29 / 79 / 299 / 699 USD/Monat, keine freie Stufe; Tageswerte gesamte Historie ab der kleinsten Stufe | täglich | Q1 2026 Markt 9,6:1 = 90,6 % (Partner-Artikel, Abgrenzung unklar); Binance BTCUSDT 06/2024 6,3–9,1:1 — **≥ 95 % nicht belegt** | Jahresbericht 2025: hoher Hebel vor dem 10.10.2025, nur beschreibend |
| **K6 Perps ÷ Spot** (b, Kaiko) | Perp-Volumen ÷ Spotvolumen, BTC | Kaiko, nur Unternehmenslizenz (Ø ≈ 28.500 USD/Jahr laut Vendr) | nicht geprüft (Forschung hinter Anmeldung) | 2023 „sechsmal Spot“ ≈ 86 % — **≥ 95 % nicht belegt** | kein Beleg gefunden |
| **K7 Estimated Leverage Ratio (ELR)** (c) | OI ÷ Coins auf den Derivatebörsen, Verhältnis ohne Einheit | CryptoQuant (BTC, ETH, XRP; Kosten wie K2); Glassnode-Variante | täglich, seit etwa 2019 | BTC alle Börsen: 0,224 (Rekord 01/2022), 2026 übertroffen (> 0,26, Artikel vom 06.05.2026); Glassnode 0,34 (Rekord 10/2022), heute 0,242; ETH Binance 0,751 (Rekord 03/2026) — **≥ 0,95 seit 2020 nicht belegt**; kein Standard „95. Perzentil“ | Anbieter-Deutung und Einzelfälle, ohne Backtest |
| **K8 OI ÷ Marktkapitalisierung** (d) | Futures-OI ÷ Marktkapitalisierung (Glassnode „Futures OI Leverage Ratio“, auch nur Perps; Variante ÷ Realized Cap) | Glassnode (bezahlt); intern im Makro-Chart (Binance-OI) | täglich | 2022 ≈ 1,9–2,1 %; 05/2025 „erstmals über 0,05“ (Artikel, Abgrenzung unklar); heute 2,07 % — 95 % nur als Perzentil denkbar | kein systematischer Beleg |
| **K9 OI ÷ Volumen; OI ÷ Spotvolumen** (e) | CoinGlass „OI/24h Vol (%)“ = OI ÷ 24-h-Futuresvolumen; Glassnode OI ÷ Futuresvolumen | CoinGlass (Website frei), Glassnode; OI ÷ Spotvolumen: kein gängiger Anbieter-Standard gefunden (U142 rechnet es beschreibend) | täglich | Glassnode heute 1,81 (181 %); ein Wert von 95 % ist möglich, hat aber keinen Spotbezug | kein Beleg gefunden |
| **K10 Perp-Anteil einzelner Börsen** (f) | Perps ÷ (Perps + Spot) je Börse | Binance: CryptoQuant, Alphractal; Bybit/OKX: keine veröffentlichte Kennzahl gefunden; **Hyperliquid**: eigene API kostenlos, DefiLlama | Binance ab 2019/2020; Hyperliquid-Spot seit April 2024 | Binance BTC: Rekord 7,82:1 = 88,7 % (08/2026), ≈ 10:1 = 90,9 % (08/2026); **Hyperliquid ≈ 97 %, Monate 2025: 94,7–98,6 % — ≥ 95 % ist dort der Normalfall** | kein Beleg gefunden |
| **K11 Perp-Anteil am Derivatevolumen** (zusätzlich) | Perps ÷ (Perps + Termin-Futures) — kein Spotbezug | Glassnode, Schätzungen | — | 92,4 % (04/2022); „93 %“ (Schätzung 2025); „> 90 %“ (Coinbase an die CFTC) — ≥ 95 % nicht belegt | — |
| **K12 Behauptungen in Artikeln und Posts** (g) | „9 von 10 Trades sind Futures“, „> 90 %“, „Spot nur 10 % der Perps“, „70–90 % Perps“; „95. Perzentil“: nichts gefunden | — | — | keine Behauptung „95 % Derivate / 5 % Spot“ für CEX gefunden; „95 %“ nur in anderem Sinn (Abschnitt 4) | Behauptungen ohne Test |

## 3. Die Kennzahlen im Einzelnen

### K1 — Derivate-Anteil am Gesamtvolumen der Börsen (CoinDesk Data, früher CCData)

- **Definition:** Derivatevolumen ÷ (Spot + Derivate) über die zentralen Börsen, die CoinDesk Data abdeckt. Gerechnet in USD, alle
  Coins, monatlich im „Exchange Review“. Die Börsenauswahl wird auf den Berichtsseiten nicht genannt.
- **Werte:**
  - **Rekord Mai 2023**: In der Kurzfassung „a record 79.8%“, im Text 79,5 % (April 78,3 %)
    ([Mondo Visione, Juni 2023](https://mondovisione.com/media-and-resources/news/ccdatas-monthly-exchange-review-spot-volumes-reach-lowest-level-since-2019-and-202367/)).
    Der Folgebericht nennt den Mai-Rekord mit 79,1 % und den Juni mit 78,7 %
    ([Mondo Visione, Juli 2023](https://mondovisione.com/media-and-resources/news/ccdatas-monthly-exchange-review-crypto-volumes-rise-for-first-time-in-3-months-202375/)).
  - August 2023: 77,3 %
    ([Mondo Visione](https://mondovisione.com/media-and-resources/news/ccdatas-monthly-exchange-review-monthly-crypto-spot-volumes-fall-to-lowest-lev-202397/)).
  - September 2023: Derivate 1,33 Bio. von 1,67 Bio. USD ≈ 79,6 % (gerechnet;
    [CoinDesk Data](https://data.coindesk.com/reports/exchange-review-september)).
  - Oktober/November 2023: 75,4 % / 73,3 %
    ([Mondo Visione](https://mondovisione.com/media-and-resources/news/ccdata-exchange-review-crypto-spot-and-derivatives-volumes-reach-highest-level-si-2023126/)).
  - Oktober 2025 (Monat der Liquidationen vom 10.10.): Spot 2,70 Bio., Derivate 7,56 Bio. USD ≈ 73,7 % (gerechnet;
    [CoinDesk Data](https://data.coindesk.com/reports/exchange-review-october-2025)).
  - Januar/Februar 2026: 73,1 % / 73,2 %
    ([KuCoin-Mitteilung mit CoinDesk-Daten](https://kucoin.com/blog/en-kucoin-among-top-exchanges-for-derivatives-market-share-growth-in-february-coindesk-data)).
  - März 2026: 76,5 %, „highest dominance since September 2023“
    ([CoinDesk Research](https://www.coindesk.com/research/exchange-review-march-2026)).
  - Mai 2026: 78,2 %, wieder „highest since September 2023“
    ([Post @CoinDeskData, Nitter-Spiegel](https://nitter.kareem.one/CoinDeskData)). Der Post trägt kein Datum; „Mai 2026“ folgt aus dem
    Zusammenhang, denn ein früherer Mai mit 78,2 % widerspräche der März-Aussage.
  - Juli 2026: nur das Gesamtvolumen (3,76 Bio. USD, tiefster Stand seit November 2023) ist auf der Seite genannt, kein Anteil
    ([CoinDesk Data](https://data.coindesk.com/reports/exchange-review-july-2026)).
- **≥ 95 %?** Nein. Seit 2023 schwankt der Anteil zwischen etwa 73 und 80 %. Werte für 2020–2022 habe ich nicht recherchiert.
- **Kosten:** Die Berichte sind online lesbar. Die freie API-Stufe wurde zum 21.05.2026 eingestellt
  ([CoinDesk Data](https://data.coindesk.com/blogs/changes-to-coindesk-data-indices-api-free-tier-access)); Bezahlpläne gibt es nur auf
  Anfrage ([spark.money, Mitte 2026](https://www.spark.money/tools/crypto-api-pricing-comparison)).
- **Liquidations-Vorlauf:** kein Beleg gefunden.
- **Lesart:** Zur Formel „95 zu 5“ passt die Kennzahl nicht. Sie ist zudem monatlich und mischt alle Coins.

### K2 — BTC-Derivatevolumen ÷ Spotvolumen über alle Börsen (CryptoQuant, in BTC)

- **Definition:** Summe des BTC-Derivatevolumens ÷ Summe des BTC-Spotvolumens über die von CryptoQuant erfassten Börsen, gemessen in
  BTC, je Tag. Artikel zitieren es als Verhältnis („derivative-to-spot ratio“) oder als Anteil („derivative share of total activity“).
  Die genaue Börsenauswahl nennen die Artikel nicht.
- **Werte:**
  - 2025: Derivate machten „consistently … over 90% of Bitcoin's total trading activity“ aus.
  - Durchschnitt 2025 bis Anfang Mai: 13,2:1 (Januar 11,27, Mai 13,77).
  - **Spitze der Verhältnisreihe 16,6:1 am 06.05.2025** (= 94,3 %, gerechnet).
  - Am 07.04.2025 erreichten die Derivate einen Tagesrekord von „over 1.26 million BTC … even as spot volume failed to reach 30,000
    BTC“ — das wären über 42:1 bzw. **über 97,7 %** (gerechnet;
    [CryptoSlate, 08.05.2025](https://cryptoslate.com/leverage-outweighs-liquidity-as-btc-spot-volumes-drop-40-since-january/)).
  - Mai 2025: Derivate-Anteil 93,7 %, „the highest monthly print this year“; April: Spot ÷ Derivate 0,0739 (= 93,1 %); Volumen in BTC.
    Der Mai-Wert 0,0702 sei „the lowest the ratio has been since 2023“; 2023 lag er also mindestens einmal noch tiefer (Datum und Höhe
    nicht genannt).
  - Tageswerte im selben Artikel: 01.05.2025 „9,435 BTC … on spot books against 377,196 BTC on futures“ (≈ **97,6 %**, gerechnet);
    26.05.2025 Spot 14.967 BTC gegen Futures 289.617 BTC (≈ **95,1 %**, gerechnet)
    ([CryptoSlate, 28.05.2025](https://cryptoslate.com/futures-desks-made-9-out-of-10-bitcoin-trades-in-may-while-spot-activity-slowed-down/)).
    Die dort zugleich genannten Verhältnisse (0,0746 bzw. 0,0597 = 93,1 bzw. 94,4 %) passen nicht zu diesen Volumen.
    Wahrscheinlich ist die Verhältnisreihe geglättet oder anders abgegrenzt; die Artikel sagen es nicht.
  - März 2026: „Almost every day this month saw derivatives trading at roughly nine times the spot volume“ (≈ 90 %;
    [CryptoSlate, 15.03.2026](https://cryptoslate.com/bitcoins-71k-rally-has-a-problem-most-traders-arent-watching/)).
  - April 2023: 369.000 gegen 35.000 bzw. 900.000 gegen 92.000 (je ≈ 91 %, gerechnet;
    [AMBCrypto](https://ambcrypto.com/bitcoin-futures-outweigh-spots-gauging-the-soaring-btc-volatility-trading-activity/)).
  - Mitte 2024: Derivate-Spitzen „topped two million BTC-equivalent“; das zugehörige Spotvolumen nennt der Artikel nicht
    ([CryptoSlate, 12.02.2025](https://cryptoslate.com/bitcoin-spot-trading-volumes-struggle-to-keep-pace-with-derivatives/)).
- **≥ 95 %?** Widersprüchlich belegt: Nach den in Artikeln genannten Tagesvolumen ja, an Einzeltagen 2025 (95–98 %). Nach den dort
  genannten Verhältniszahlen nein (höchstens 94,3 %). Sauber klären lässt sich das nur mit CryptoQuants Tagesreihe selbst. Es ist die
  einzige CEX-Abgrenzung, bei der 95 % plausibel vorkommt. Der hohe Wert hängt an der Börsenauswahl: CryptoQuants eigene Jahreszahl über
  **alle Coins** lautet Spot 18,6 Bio. gegen Perps 61,7 Bio. USD, also nur 76,8 % (gerechnet;
  [ForkLog, 13.01.2026](https://forklog.com/en/spot-cryptocurrency-market-reaches-18-6-trillion-in-2025/)).
- **Kosten und Abruf:** Die API-Stufe Basic ist kostenlos: Marktdaten auf Tagesbasis, aber nur 30 Tage Historie, 10 Abrufe je Minute,
  10.000 Credits im Monat. Advanced und Professional bieten 1 Jahr, Premium die volle Historie
  ([CryptoQuant APIs](https://cryptoquant.com/apis)). Preise laut Vergleichsseite (geprüft 13.06.2026): Advanced 29, Professional 99,
  Premium 799 USD im Monat ([costbench](https://costbench.com/software/onchain-analytics/cryptoquant/)). Endpunkte:
  `btc/market-data/price-ohlcv` (Spot und Perpetual, auch „all_exchange“; Einheit je Börse USD, USDT oder BTC;
  [Doku](https://userguide.cryptoquant.com/api/btc-market-data)) und die aggregierte Spot-Statistik `market/cq/spot/trade`
  ([Doku](https://docs.cryptoquant.com/v2/market/cq-spot-trade.md)).
- **Liquidations-Vorlauf:** Analysten sagen, die Kennzahl „does not predict price direction“, höhere Derivate-Aktivität könne aber
  Schwankungen verstärken ([Crypto Briefing, 07.08.2026](https://cryptobriefing.com/binance-bitcoin-futures-record-volume/)). Ein
  systematischer Beleg fehlt.

### K3 — Spot ÷ Futures-Volumen, alle Börsen (Glassnode)

- **Definition:** „the ratio of spot trading volume to futures trading volume“, je Börse oder über alle Börsen; unter 1 dominieren
  Futures.
- **Werte am 13.10.2026:**
  - BTC 0,12796 → Futures-Anteil 88,7 % (gerechnet;
    [Glassnode Studio](https://studio.glassnode.com/charts/market.SpotFuturesVolumeRatio?a=BTC)).
  - BTC, Point-in-Time-Variante (unveränderliche Historie, für Backtests gedacht): 0,13295 → 88,3 %
    ([Glassnode Studio](https://studio.glassnode.com/charts/market.SpotFuturesVolumeRatioPit?a=BTC)).
  - ETH 0,10329 → 90,6 %
    ([Glassnode Studio](https://studio.glassnode.com/charts/market.SpotFuturesVolumeRatio?a=ETH)).
  - Ein Glassnode-Post nennt am 7. August Spot 6,61 Mrd. gegen Futures 41,05 Mrd. USD (≈ 86 %, gerechnet;
    [Telegram](https://t.me/s/glassnode?after=1141)).
- **≥ 95 %?** Dazu müsste der Wert unter 0,0526 fallen. Das historische Minimum zeigt die Seite ohne Zugang nicht → nicht belegt.
- **Kosten:** Ob die Kennzahl im freien Studio sichtbar ist, gibt die Seite nicht an.
  - Advanced kostet laut Vergleichsseiten etwa 49 USD im Monat (jährlich bezahlt) mit „Light API“ (50 Abrufe am Tag).
  - Professional wird individuell verhandelt (früher etwa 999 USD im Monat).
  - Eine kostenlose API gibt es nicht ([spark.money](https://www.spark.money/tools/crypto-api-pricing-comparison);
    [costbench](https://costbench.com/software/blockchain-data-api/glassnode-api/)).
- **Liquidations-Vorlauf:** kein Beleg gefunden.

### K4 — Spot ÷ Futures-Volumen (The Block Data)

- **Definition:** 30-Tage-Mittel von Spot- ÷ Futuresvolumen für BTC und ETH.
- **Werte:**
  - April 2025: BTC 0,19 („19% as much spot volume as futures volume“, tiefster Wert seit Anfang August 2024) = 84 %; ETH 0,20, tiefster
    seit Dezember 2023 = 83 % ([The Block, 20.04.2025](https://www.theblock.co/post/351318/crypto-exchange-volume-falls-to-6-month-low-as-traders-flee-spot-for-futures)).
  - BTC seit Januar 2020 „between 0.2 and 0.4“, im Januar 2023 knapp 0,7
    ([CryptoSlate, 18.01.2023](https://cryptoslate.com/research-bitcoin-spot-to-futures-ratio-shows-retail-drove-price-above-20000/)).
  - Mai 2020: Futures etwa fünfmal Spot
    ([The Block, 05.06.2020](https://www.theblock.co/post/67497/bitcoin-derivatives-market-is-growing-faster-than-spot-market-suggesting-rising-institutionalization-in-the-space)).
- **≥ 95 %?** Nein, soweit belegt (höchstens etwa 84–87 %).
- **Kosten:** Dashboard teils frei, sonst The-Block-Pro-Abo; Preis nicht geprüft.
- **Liquidations-Vorlauf:** kein Beleg gefunden.

### K5 — Futures- ÷ Spotvolumen (CoinGlass)

- **Definition:** CoinGlass zeigt je Coin das 24-h-Futures- und das 24-h-Spotvolumen, Taker-Anteile und „OI/24h_Vol (%)“
  ([CoinGlass BTC-Volumen](https://www.coinglass.com/de/volume/BTC)). Eine fertige Kennzahl „Futures/Spot Ratio“ habe ich nicht
  gefunden; das Verhältnis entsteht aus den beiden Reihen. Die API liefert die Reihen über die Endpunkte
  `/api/futures/taker-buy-sell-volume/aggregated-history` und `/api/spot/taker-buy-sell-volume/aggregated-history`
  ([API-Spezifikation, Drittquelle](https://glama.ai/mcp/servers/@forgequant/coinglass-mcp/blob/3ff015e428d99f013e3e7fe363b98d82adeb00a3/docs/02-api-specification.md)).
- **Werte:**
  - **Behauptung (Partner-Artikel):** Q1 2026 Derivate 18,63 Bio. gegen Spot 1,94 Bio. USD = 9,6:1 = 90,6 %, Abgrenzung unklar
    ([Mediaite Partner Content, 30.04.2026](https://www.mediaite.com/partner-content/what-cryptos-9-6x-derivatives-to-spot-ratio-signals-about-market-structure/)).
  - Binance BTCUSDT, Juni 2024: Perp ÷ Spot zwischen 6,32 und 9,06 (86–90 %;
    [CryptoSlate, 19.06.2024](https://cryptoslate.com/perpetual-futures-trading-volume-surges-as-bitcoin-spot-trading-lags/)).
- **≥ 95 %?** Nicht belegt.
- **Kosten:** keine freie API ([CoinGlass Pricing](https://coinglass.com/pricing), abgerufen 13.10.2026):
  - Hobbyist 29 USD im Monat (Tageswerte über die gesamte Historie, 4-h-Werte 180 Tage).
  - Startup 79, Standard 299, Professional 699 USD im Monat.
- **Liquidations-Vorlauf:** Der Jahresbericht 2025 beschreibt vor dem 10.10.2025 „Long leverage utilization … was elevated“ und
  „crowded leverage accumulated in the third quarter“ ([CoinGlass](https://www.coinglass.com/zh/learn/2025-annual-report-en)). Das ist
  beschreibend, ohne Kennzahl und ohne Test.

### K6 — Perps ÷ Spot (Kaiko)

- **Werte:** Kaiko meldete im Mai 2023, das Verhältnis Perps ÷ Spot bei BTC stehe „at its highest in nearly two years“; Perps hätten
  „six times the volumes versus spot“ (≈ 86 %)
  ([Business Standard/Bloomberg, 05.05.2023](https://www.business-standard.com/amp/markets/cryptocurrency/bitcoin-perpetuals-becoming-an-even-bigger-driver-of-digital-token-s-price-123050501173_1.html)).
  Neuere Kaiko-Forschung liegt hinter einer Anmeldung; nicht geprüft.
- **≥ 95 %?** Nicht belegt.
- **Kosten:** nur individuelle Unternehmenspläne ([Kaiko](https://www.kaiko.com/about-kaiko/pricing-and-contracts)); im Schnitt etwa
  28.500 USD im Jahr, Spanne 9.500–55.000 USD ([Vendr](https://vendr.com/buyer-guides/kaiko)).
- **Liquidations-Vorlauf:** kein Beleg gefunden.

### K7 — Estimated Leverage Ratio (CryptoQuant; Glassnode-Variante)

- **Definition:** „ratio of open interest divided by the reserve of an exchange“. CryptoQuant deutet hohe Werte als „Over Leveraged
  Market + Possible Volatility“ ([CryptoQuant-Doku](https://docs.cryptoquant.com/data-guide/market/estimated-leverage-ratio)).
  Glassnode führt eine eigene Fassung
  ([Glassnode Studio](https://studio.glassnode.com/charts/derivatives.FuturesEstimatedLeverageRatio?a=BTC)).
- **Werte** (je nach Börse und Anbieter verschieden):
  - BTC alle Börsen (CryptoQuant): Rekord 0,224 Anfang Januar 2022
    ([Cointelegraph](https://cointelegraph.com/news/bitcoin-leverage-ratio-reaches-new-highs)); 0,195 im April 2023, tiefster Wert
    seit Dezember 2021 ([CoinDesk](https://coindesk.com/markets/2023/04/27/bitcoins-estimated-leverage-ratio-hits-lowest-since-december-2021/));
    „above 0.2611“ laut Artikel vom 06.05.2026 (Messtag nicht genannt), also über dem Rekord von 2022.
  - Binance BTC: 0,1976 im Mai 2026, Jahreshoch
    ([Crypto Times](https://www.cryptotimes.io/2026/05/06/warning-signal-bitcoin-leverage-on-binance-soars-to-yearly-high/)).
  - Binance ETH: Rekord 0,751 im März 2026; 0,55 in der Woche vor dem 10.10.2025
    ([FXStreet](https://www.fxstreet.com/cryptocurrencies/news/ethereums-leverage-ratio-breaks-its-own-record-liquidation-risk-is-rising-202603191319)).
  - Glassnode BTC: Rekord 0,34 im Oktober 2022
    ([CryptoSlate](https://cryptoslate.com/liquidations-expected-as-bitcoin-open-interest-leverage-ratio-spike-higher/)); am 13.10.2026
    0,242.
  - Axel Adler (CryptoQuant-Autor) nennt einen Median von 0,44 seit 2019, Werte über 0,90 Anfang 2019 und 0,70 im Oktober 2025
    ([Leitfaden](https://axeladlerjr.com/bitcoin-open-interest-leverage-ratio-guide/)). Welche Börsen er zählt, ist unklar.
- **Wurde „0,95“ seit 2020 erreicht?** Nicht belegt. Über 0,9 lag die Kennzahl nur Anfang 2019 (Adler).
- **Perzentile:** Eine Anbieter-Konvention „ELR im 95. Perzentil“ habe ich nicht gefunden. Adler arbeitet mit festen Zonen: über 0,50
  hohes Risiko, über 0,55 „consistently precedes elevated volatility“, über 0,60 erhöhte Wahrscheinlichkeit einer Korrektur um 15 % in
  30 Tagen — **Behauptungen ohne Backtest**.
- **Kosten:** wie K2 (ELR gibt es für BTC, ETH und XRP auch per API); Glassnode bezahlt.
- **Liquidations-Vorlauf:**
  - Anbieter-Deutung (siehe oben).
  - Adler: „every major correction since 2020 was preceded by elevated ELR“, belegt nur mit Einzelfällen (Mai 2021, FTX 2022,
    Oktober 2025), ohne Fehlalarm-Quote.
  - CryptoSlate sagte im Oktober 2022 beim Rekord 0,34 „Widespread liquidations may occur“ voraus, ohne Nachprüfung.
  - Ergebnis: kein systematischer Beleg.

### K8 — Open Interest ÷ Marktkapitalisierung

- **Definition:** „Futures OI Leverage Ratio = Total Futures Open Interest / Market Cap“, auch nur mit Perps
  ([Glassnode Studio](https://studio.glassnode.com/charts/futures-leverage-ratio)).
- **Werte:**
  - April 2022: aggregiert 2,1 % → 1,9 %, Perps etwa 1,3 % der Marktkapitalisierung
    ([Glassnode Week 17/2022](https://research.glassnode.com/the-week-onchain-week-17-2022/)).
  - Mai 2025: „pushed the OI-to-market-cap ratio beyond 0.05 for the first time“
    ([CryptoSlate](https://cryptoslate.com/futures-desks-made-9-out-of-10-bitcoin-trades-in-may-while-spot-activity-slowed-down/));
    Abgrenzung unklar. Mit dem dort genannten OI von 80,9 Mrd. USD und rund 2,2 Bio. USD Marktkapitalisierung (von mir angenommen)
    ergäben sich eher 3–4 % (gerechnet).
  - Am 13.10.2026 BTC 0,0207 = 2,07 %
    ([Glassnode Studio](https://studio.glassnode.com/charts/derivatives.FuturesOpenInterestMcapRatio?a=BTC)).
  - Variante „Realized Cap Leverage Ratio“ (OI ÷ Realized Cap): 10,2 % im Juni 2025, „ranks among the top 10.8% of trading days since
    2018“ ([Cointelegraph](https://cointelegraph.com/markets/bitcoin-leverage-use-sends-oi-to-96b-but-there-s-a-catch)).
  - Intern: Makro-Chart (Binance-OI) 0,49 % am 07.10.2026, Perzentil 73,1 (`RECHERCHE_Positionierung_ChartTrader_09-10-2026.md` 5.1).
- **≥ 95 %?** Als Wert ausgeschlossen; nur als Perzentil denkbar.
- **Liquidations-Vorlauf:** kein systematischer Beleg gefunden (verwandter Befund zum Carry in Abschnitt 5).

### K9 — OI ÷ Volumen und OI ÷ Spotvolumen

- **Definition:**
  - CoinGlass zeigt „OI/24h_Vol (%)“ = OI ÷ 24-h-Futuresvolumen ([CoinGlass](https://www.coinglass.com/de/volume/BTC)).
  - Glassnode zeigt „ratio of open interest to futures trading volume“: am 13.10.2026 BTC 1,81 = 181 %
    ([Glassnode Studio](https://studio.glassnode.com/charts/derivatives.FuturesOpenInterestVolumeRatio)).
  - **OI ÷ Spotvolumen** führt kein Anbieter als Standardkennzahl, soweit gefunden. U142 rechnet es beschreibend (Binance, Abschnitt 6.6).
- **≥ 95 %?** Ein Wert von 95 % ist bei OI ÷ Volumen möglich (Glassnode heute 181 %). Zur Formel „gegenüber 5 % Spot“ passt das nicht.
- **Liquidations-Vorlauf:** kein Beleg gefunden.

### K10 — Perp-Anteil einzelner Börsen

- **Binance:**
  - CryptoQuant: BTC-Futures ÷ Spot auf Binance „record“ 7,82 = 88,7 % (Analyse vom 07.08.2026)
    ([Cointelegraph](https://cointelegraph.com/markets/binance-bitcoin-volume-ratio-hits-record-as-futures-outweigh-spot-eight-times-over)).
    Glättung bzw. Zeitfenster sind nicht angegeben; die im Artikel genannten Tageszahlen (57,82 gegen 6,08 Mrd.) ergeben 9,5.
  - Alphractal (João Wedson), August 2026: Spot „roughly 10%“ des Perp-Volumens = 90,9 %
    ([CryptoRank](https://cryptorank.io/news/feed/b1815-binance-spot-volume-perpetual-futures-ratio)).
  - Ein anderer Artikel nennt als Spitze 2026 nur „roughly 5.1:1“ ([Crypto Briefing, 20.08.2026](https://cryptobriefing.com/bitcoin-rally-spot-market-not-leverage/));
    die Abgrenzungen sind uneinheitlich.
  - Gesamtjahr 2025, alle Coins: Spot 7,25 Bio., Futures 27,04 Bio. USD = 78,9 % (gerechnet; CoinGecko-Daten über Wu Blockchain,
    [BitPinas](https://bitpinas.com/feature/2025-cex-annual-report/)).
  - ETH auf Binance 2025: Spot ÷ Futures „about 0.2“ = 83 %
    ([ChainCatcher/CryptoQuant](https://www.chaincatcher.com/en/article/2232954)).
  - Alles im Einklang mit U142 (nie ≥ 95 %).
- **Bybit, OKX:** keine veröffentlichte Perp-Anteil-Kennzahl gefunden. Rechnen lässt sie sich aus den Börsenvolumen bei CoinGlass oder
  CoinDesk Data, oder aus den öffentlichen Kerzen-Endpunkten der Börsen
  ([Bybit v5 Kline](https://bybit-exchange.github.io/docs/api-explorer/v5/market/kline)).
- **Hyperliquid:**
  - Seit dem Start: Spot 168,4 Mrd. gegen Perps 5,387 Bio. USD → **97,0 %** (gerechnet); „Der historische Wert beträgt etwa 3 % des
    Perp-Volumens“.
  - Letzte 30 Tage (Seite aktualisiert 27.09.2026): Spot 5,25 Mrd. gegen Perps 216,9 Mrd. USD → **97,6 %** (gerechnet;
    [Datawallet](https://www.datawallet.com/de/krypto/hyperliquid-statistics); Quelle der Spotzahl laut Methodik DefiLlama).
  - Monatlich (wohl 2025, Jahr aus dem Zusammenhang): Spot-Anteil „1.4% in Apr ($2.6B) to 5.3% in Aug ($22.5B)“ bei 427 Mrd.
    Gesamtvolumen im August → Perps **98,6 % bis 94,7 %**
    ([Four Pillars](https://research.4pillars.io/en/data/content/hyperliquid-monthly-volume-peaked-at-427b-in-aug-25x-the-jan-level-188b-)).
  - Spot gibt es seit April 2024 (PURR als erster HIP-1-Spot-Token; [altFINS](https://altfins.com/crypto-screener/purr-purr)).
  - **≥ 95 %:** auf Hyperliquid der Normalfall, nicht die Ausnahme. Monate oder Tage darunter gibt es (August 2025). Um den HYPE-Start
    Ende November 2024 lag der Spot-Anteil vermutlich höher — nicht belegt.
  - Abruf: Die API ist öffentlich. `candleSnapshot` liefert Tageskerzen je Perp- und Spotmarkt (Basisvolumen `v`; höchstens 5.000
    Kerzen je Antwort, ältere Kerzen per Seitenabruf;
    [Doku](https://goldrush.dev/docs/api-reference/hyperliquid-info/candle-snapshot.md)). `spotMetaAndAssetCtxs` liefert
    `dayNtlVlm` je Spotpaar ([Doku](https://docs.chainstack.com/reference/hyperliquid-info-spot-meta-and-asset-ctxs.md)).
- **Liquidations-Vorlauf:** kein Beleg gefunden.

### K11 — Perp-Anteil am Derivatevolumen (zur Abgrenzung)

Perps gegenüber Termin-Futures, **nicht** gegenüber Spot:
- 92,4 % des Futuresvolumens im April 2022, nach 75 % im Dezember 2020
  ([Glassnode](https://research.glassnode.com/the-week-onchain-week-17-2022/)).
- „93% of all derivatives trading in crypto, according to some estimates“ und „upwards of 90%“ (Coinbase Derivatives an die CFTC;
  [Decrypt, 26.05.2025](https://decrypt.co/322054/crypto-industry-responding-cftcs-call-perpetuals)).

Ein Wert ≥ 95 % ist nicht belegt. Die Zahl liegt nahe an 95 % und kann daher verwechselt werden.

### K12 — Behauptungen in Artikeln und sozialen Medien (als Behauptung gekennzeichnet)

- **Behauptung:** „Futures desks made 9 out of 10 Bitcoin trades in May“ (Überschrift; Daten von CryptoQuant;
  [CryptoSlate, 28.05.2025](https://cryptoslate.com/futures-desks-made-9-out-of-10-bitcoin-trades-in-may-while-spot-activity-slowed-down/)).
- **Behauptung:** Derivate „consistently comprised over 90% of Bitcoin's total trading activity in 2025“; „futures absorbed more than
  92% of daily turnover“ ([CryptoSlate, 08.05.2025](https://cryptoslate.com/leverage-outweighs-liquidity-as-btc-spot-volumes-drop-40-since-january/)).
- **Behauptung:** Binance-Spot „roughly 10% of its perpetual futures volume“ (João Wedson, August 2026;
  [OneKey](https://onekey.so/blog/ecosystem/binance-spot-volume-is-only-10-of-perpetuals-crypto-markets-still-look-heavily-speculative-20260827232402/)).
- **Behauptung:** „70–90% of transactions on major exchanges now come from perpetual futures“ (Pressemitteilung von Traders Union,
  „based on CryptoQuant market data“; [Barchart, 10.03.2026](https://www.barchart.com/story/news/669323/crypto-exchange-competition-heats-up-as-derivatives-drive-up-to-90-of-trading)).
- **Behauptung (Kommentar):** Das Futures-Spot-Verhältnis sei „a reliable fragility indicator“; „When leverage dominates price
  discovery, the market becomes increasingly vulnerable to cascading liquidations“ — ohne Test
  ([Crypto Briefing, 20.08.2026](https://cryptobriefing.com/bitcoin-rally-spot-market-not-leverage/)).
- **„Hebel im 95. Perzentil“:** Diese Formulierung habe ich in gängigen Quellen nicht gefunden (gesucht: CryptoQuant, Glassnode,
  CoinGlass, K33, Artikel-Aggregatoren). Es gibt Perzentil-Sprache anderer Art: „top 10.8% of trading days since 2018“ (Glassnode,
  K8).
- Eine CEX-Aussage der Form „95 % Derivate, 5 % Spot“ habe ich nicht gefunden.

## 4. Verwechslungsgefahr: andere bekannte „95 %“-Zahlen

| Zahl | Was sie wirklich misst | Quelle |
|---|---|---|
| „95 % des Bitcoin-Volumens sind gefälscht“ (Bitwise an die SEC, März 2019) | Wash-Trading: von 6 Mrd. USD gemeldetem Tagesvolumen nur 273 Mio. echt; 71 von 81 Börsen auffällig — sinngemäß „nur 5 % echter Spot“ | [MIT Technology Review](https://www.technologyreview.com/2019/03/26/1206/nearly-all-bitcoin-trades-are-fake-apparently/), [ThinkAdvisor](https://thinkadvisor.com/2019/03/22/95-of-spot-bitcoin-trading-volume-is-fake-report) |
| Top-Derivatebörsen „account for over 95% of all volume“ (CryptoCompare, Mai 2020) | Anteil der großen Börsen am Derivatevolumen, nicht Derivate gegen Spot | [Decrypt, 04.06.2020](https://decrypt.co/31320/crypto-derivatives-all-time-high) |
| Perps 92–93 % des Derivatevolumens | Perps gegen Termin-Futures (K11) | siehe K11 |
| Hyperliquid: „über 95 % seiner Einnahmen für tägliche Rückkäufe“ | Verwendung der Gebühren | [21Shares HYPE-Onepager](https://cdn.21shares.com/uploads/product_documents/OnePager/HYPE_Onepager(DE).pdf) |
| Hyperliquid 2025: Perps 96 % der Einnahmen (808 von 844 Mio. USD) | Gebührenanteil, nicht Volumen | [BlockEden](https://blockeden.xyz/blog/2026/01/10/hyperliquid-844m-revenue-perpetual-dex-dominance/) |

## 5. Belege zum Liquidations-Vorlauf (übergreifend)

- **Rigoros, aber verwandt:** „a high crypto carry predicts future price crashes“; Cash-and-Carry ist riskant „due to spikes in margins
  and liquidations amid drawdowns“ (Schmeling, Schrimpf & Todorov, [BIS WP 1087](https://bis.org/publ/work1087.htm)). Gemessen wird
  dort Carry (Basis bzw. Funding), nicht der Volumenanteil.
- **Vorabdrucke 2026 zu sieben BTC-Liquidationskaskaden (2022–2025):**
  - Kritische Frühwarnzeichen im Kurs zeigten sich in 5 von 7 Fällen, nicht bei den beiden Nachrichten-Schocks. Beim Oktober 2025
    schien das Signal im Hebel statt im Kurs zu liegen; der Autor nennt diesen Fall „the outlier, not the rule“. Einzelfall-Aussagen
    seien „fragile by construction“
    ([Garcia Seuma, arXiv 2607.27070](https://ideas.repec.org/p/arx/papers/2607.27070.html)).
  - Keine Vorab-Kennzahl sagt die Schwere voraus („none of the scalar pre-state measures we can construct grades it“;
    [arXiv 2608.03616](https://ideas.repec.org/p/arx/papers/2608.03616.html)).
- **Anbieter-Aussagen ohne Backtest (Behauptung):** „Funding rates above 15% APR for extended periods have preceded every major
  correction in 2025“ ([Amberdata](https://blog.amberdata.io/leverage-liquidations-the-31b-deleveraging)). Vor dem 10.10.2025 stieg
  das Funding von etwa 10 auf fast 30 % p. a.; FTI sagt aber nicht, dass das den Crash angekündigt habe
  ([FTI Consulting](https://fticonsulting.com/insights/articles/crypto-crash-october-2025-leverage-met-liquidity)).
- **Eigener Befund:** U142 H4 — nach einem Binance-Perp-Anteil im obersten Zehntel der eigenen 90 Tage folgte eine Liquidationswelle in
  2,9 % der Fälle gegen 5,5 % sonst (RR 0,53, nicht belegt, eher seltener).
- **Ergebnis:** Für den Derivate-Anteil (K1–K6, K10), die ELR (K7) und OI ÷ Marktkapitalisierung bzw. ÷ Volumen (K8, K9) habe ich
  keinen systematischen Beleg gefunden. „Fast immer“ braucht zudem eine Basisrate: Auf Hyperliquid gibt es täglich Liquidationen.

## 6. Einschätzung: Was passt am ehesten zu „95 % Hebel gegen 5 % Spot“?

Vom **Wortlaut** her (95 zu 5 als üblicher Wert) passt Hyperliquid. Vom **Sinn der Regel** her (ein seltener Extremwert, nach dem eine
Liquidierung folgt) passt CryptoQuants BTC-Messung über alle Börsen besser: Dort liegt der Normalbereich bei 90–94 %, und 95 % wäre ein
Ausreißer.

**1. Hyperliquid-Perp-Anteil (K10)** = Perps ÷ (Perps + Spot), Plattform je Tag.
- **Warum passend:** Die einzige gängige Zahl, die wörtlich bei 95 zu 5 liegt (≈ 97/3 im Schnitt; 94,7/5,3 im August 2025). Der
  Nutzer arbeitet täglich mit Hyperliquid.
- **Vorbehalt 1:** Dort ist ≥ 95 % der Normalzustand. Eine Regel „ab 95 % folgt fast immer eine Liquidierung“ wäre fast immer an, und
  Liquidationen gibt es dort täglich — die Regel sähe richtig aus, ohne etwas zu sagen.
- **Vorbehalt 2:** Der Spot-Anteil hängt vermutlich stark am HYPE-Spothandel (nicht belegt). Die Kennzahl misst also womöglich eher
  Spot-Aktivität bei HYPE als Hebel.
- **Mit freien Daten testbar:** Ja.
  - Hyperliquid-API vom Pi aus (Tageskerzen je Perp und Spotpaar, Basisvolumen × Kurs) oder DefiLlama (Tagesvolumen der Perps und des
    „Hyperliquid Spot Orderbook“).
  - Historie ab April 2024, also etwa 2,5 Jahre.
  - Prüfen: die Schwelle 95 % wie formuliert („Spot-Anteil < 5 %“) und eine relative Variante; Ereignis und Nullmodell wie in U142.

**2. CryptoQuant BTC Derivate ÷ Spot, alle Börsen, in BTC (K2).**
- **Warum passend:** Die einzige CEX-Abgrenzung mit belegten Werten von 93–94 % (Mai 2025 93,7 %; Spitze der Verhältnisreihe
  94,3 %). Aus den in Artikeln genannten Tagesvolumen ergeben sich an Einzeltagen 95–98 % (07.04., 01.05., 26.05.2025; widersprüchlich,
  siehe K2). Sie wird oft zitiert („9 von 10 Trades“, „> 90 %“). Hier könnte der Nutzer „95 zu 5“ tatsächlich gesehen haben.
- **Mit freien Daten testbar:** Nur eingeschränkt.
  - Die freie API-Stufe Basic liefert Tageswerte, aber nur 30 Tage → nur Vorwärts-Sammlung möglich.
  - Ein Jahr Historie gibt es mit Advanced oder Professional (laut Vergleichsseite 29 bzw. 99 USD im Monat), die volle Historie mit
    Premium (799 USD im Monat).
  - Ein Nachbau aus freien Kerzen von Binance, Bybit und OKX träfe CryptoQuants Börsenauswahl nicht. Er bliebe vermutlich wie Binance
    allein unter 95 % (nicht geprüft).

**3. Die Lesart „Hebel im 95. Perzentil“** (oberste 5 % der eigenen Historie). Anwendbar auf den Binance-Perp-Anteil (K0),
OI ÷ Marktkapitalisierung (K8) oder die ELR (K7).
- **Mit freien Daten testbar:** Sofort, für K0 und K8 aus den vorhandenen Daten (`hebel.db`, Makro-Chart). Die ELR-Historie ist
  kostenpflichtig (CryptoQuant, Glassnode).
- **Erwartung:** gering. Die 90-%-Variante (H4) zeigte eher weniger Wellen. Der Test müsste neu und vorab festgelegt werden.

**4. Weniger passend:**
- Glassnode, CoinGlass und The Block über alle Börsen (K3–K5): belegt 84–91 %, 95 % nicht erreicht. Eine günstige Mehrbörsen-Reihe wäre
  CoinGlass Hobbyist (29 USD im Monat, Tageswerte über die gesamte Historie).
- Ausscheiden dürften:
  - CoinDesk Data, monatlich (K1: höchstens etwa 80 %),
  - ELR als Wert (0,1–0,8),
  - OI ÷ Marktkapitalisierung als Wert (2–5 %),
  - OI ÷ Volumen und Perps gegen Termin-Futures (kein Spotbezug),
  - Bitwise 2019 (gefälschtes Volumen).

**Vorschlag zur Auswahl durch den Nutzer:** Er erkennt seine Quelle am ehesten an einem dieser Bilder:
(1) Hyperliquid-Statistik „Perps gegen Spot“, (2) ein CryptoQuant-Chart „Bitcoin Spot vs. Derivative Volume“ bzw. ein Artikel „9 von
10 Trades sind Futures“, (3) ein Perzentil-Band in einem Hebel-Chart. Danach folgt ein neuer Test mit eigener Nummer; diese Zahl
wird nicht umgedeutet.

## 7. Grenzen dieser Recherche

- **Keine eigenen Abrufe:** Die APIs von Hyperliquid (`api.hyperliquid.xyz`) und DefiLlama (`api.llama.fi`) waren aus der
  Recherche-Umgebung gesperrt (Netzrichtlinie). Alle Hyperliquid-Zahlen stammen aus Veröffentlichungen. Der Pi kann die
  Hyperliquid-API abrufen; das System nutzt sie bereits. Ob DefiLlamas offene API die Volumen-Endpunkte weiter kostenlos liefert, ist
  nicht geprüft; die Preisseite nennt für den freien Plan nur TVL, Gebühren und Preise, die API kostet 300 USD im Monat
  ([DefiLlama](https://docs.llama.fi/pro-api)).
- **Zugang:** Mehrere Anbieterseiten zeigen Werte nur mit Zugang (Kaiko-Forschung, Glassnode-Historie, CoinDesk-Berichte als PDF).
  Allzeit-Extremwerte von K3–K6 sind deshalb nicht belegt.
- **Abgrenzung:** Die Anteile hängen stark an der Börsenauswahl und der Einheit (BTC oder USD, Glättung). Unterschiedliche Zahlen für
  „dieselbe“ Kennzahl (etwa Binance 5,1:1 gegen 7,82:1 gegen 10:1 im Jahr 2026) sind darum kein Widerspruch der Märkte, sondern einer
  der Definitionen.
- **Preise:**
  - Direkt bei den Anbietern abgerufen (13.10.2026): CoinGlass und CryptoQuant (freie Stufe).
  - Aus Vergleichsseiten mit Prüfdatum Juni bis September 2026: CryptoQuant (bezahlte Pläne), Glassnode.
  - Laevitas: Free 0 USD (1 Woche Historie), Premium 50 USD, Enterprise mit API 500 USD je Platz und Monat
    ([Finestel, 06/2026](https://finestel.com/blog/laevitas-review/)).
  - Velo: API nur im Premium-Plan, Preis nicht belegt ([OpenBB](https://openbb.co/blog/velo-brings-digital-assets-market-data-to-OpenBB/)).
  - Coinalyze: Website und API kostenlos, 40 Abrufe je Minute; Stand Mai 2024
    ([GetBlock](https://getblock.io/blog/coinalyze-track-and-monitor-crypto-markets/)), nicht neu geprüft.
