"""
Heatmap als Richtungsanker (25.09.2026, 23.28) -- Auswertung und Anzeige, KEIN Treiber (erst nach Beleg).

Frage: Zeigt das Ungleichgewicht der Liquidationscluster über und unter dem Kurs die kommende Richtung an?
Alles je Coin (jeder Coin hat seine eigene Dynamik), über die ganze gespeicherte Historie (bis 90 Tage):

  Abstand    in Schwankungseinheiten σ(4 h) statt in festen Prozent -- 1 % ist bei PAXG viel, bei HYPE wenig
  Größe      relativ zum Stundenvolumen des Coins (Median der letzten 24 h) statt fester 5 Mio -- sonst hätten
             HYPE, ZEC, XMR und PAXG nie ein Ereignis
  Anker A    (Gewicht oben − Gewicht unten) / Summe; Gewicht = Clustergröße/Volumen / max(Abstand in σ; 0,5)
             über Cluster ab 5 % des Stundenvolumens zwischen 0,25 und 3 σ; A > 0 = Zug nach oben
  Ereignis   |A| >= 0,5 und größtes Cluster der starken Seite ab 10 % (Klasse „ab 10 %“) bzw. 25 % des Volumens
  Treffer    Kurs nach h Stunden in Richtung des Ankers; Zufall TRENDBEREINIGT: Anteil steigender Kurse unter
             allen Zeitpunkten mit derselben 24-h-Vorgeschichte (Trend auf/ab) -- sonst gewinnt im Trendmarkt,
             wer immer die Trendseite nennt (U9)
  Berührung  wird das stärkste Cluster binnen h erreicht -- gegen ein Spiegel-Niveau im gleichen Abstand auf der
             anderen Seite (gepaart)
  Überhitzt  getrennt ausgewertet: Crowding-Extrem oder OI-Überhitzung mit Betrag >= 0,5 zum Zeitpunkt
  Beleg      trendbereinigter Vorsprung mit z >= 2 in mindestens zwei Horizonten (Klasse ab 10 %)

Je Horizontblock zählt ein Ereignis (unabhängigere Fälle). Ergebnis im Prognosespeicher (learned coin/„anker_bilanz“).
"""
import bisect
import json
import math
import os
import sqlite3
import sys
import time

import hl_forecast as F

HORIZONTE = (4, 8, 12, 24, 48)
KLASSEN = (0.10, 0.25)
A_MIN = 0.5
D_MIN, D_MAX = 0.25, 3.0
ABST_MAX = 0.08                  # höchstens 8 % Abstand, auch wenn σ groß ist
GEWICHT_MIN = 0.05               # Cluster ab 5 % des Stundenvolumens zählen zum Anker
TAKT = 1800                      # ein Snapshot je 30 min
TAGE = 90
PROBE_NOW = 1_790_006_400


# ------------------------------------------------------------------------------------------------ Grundlagen
class Markt:
    """Kurse (1 min), σ(4 h) aus 15-min-Renditen der letzten 7 Tage, Stundenvolumen (Median 24 h)."""

    def __init__(self, con, coin: str, von: int, bis: int):
        rows = con.execute("SELECT ts, high, low, close, volume FROM bars WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
                           (coin, von - 8 * 86_400, bis + 49 * 3600)).fetchall()
        self.ts = [r[0] for r in rows]; self.hi = [r[1] or r[3] for r in rows]; self.lo = [r[2] or r[3] for r in rows]
        self.cl = [r[3] for r in rows]
        stunden: dict = {}
        for t, _, _, c, v in rows:
            if c and v:
                stunden[t // 3600] = stunden.get(t // 3600, 0.0) + v * c
        self.st_keys = sorted(stunden); self.st_val = [stunden[k] for k in self.st_keys]
        # σ(4 h) auf dem 15-min-Raster
        self.s_ts, self.s_val = [], []
        if self.ts:
            raster = list(range(self.ts[0] // 900 * 900 + 900, self.ts[-1], 900))
            p = [self.preis(t) for t in raster]; r = []
            for i in range(1, len(p)):
                r.append(math.log(p[i] / p[i - 1]) if p[i] and p[i - 1] else None)
            fenster = 7 * 96; s1 = s2 = 0.0; n_ = 0                     # laufende Summen: O(1) je Rasterpunkt
            for i in range(len(r)):
                if r[i] is not None:
                    s1 += r[i]; s2 += r[i] * r[i]; n_ += 1
                if i >= fenster and r[i - fenster] is not None:
                    s1 -= r[i - fenster]; s2 -= r[i - fenster] ** 2; n_ -= 1
                if i >= fenster - 1 and n_ >= fenster // 2:
                    m = s1 / n_; sd = math.sqrt(max(s2 / n_ - m * m, 0.0) * n_ / max(n_ - 1, 1))
                    self.s_ts.append(raster[i + 1] if i + 1 < len(raster) else raster[-1]); self.s_val.append(sd * 4)

    def preis(self, t: int):
        i = bisect.bisect_right(self.ts, t) - 1
        return self.cl[i] if i >= 0 and t - self.ts[i] <= 120 else None

    def sigma(self, t: int):
        i = bisect.bisect_right(self.s_ts, t) - 1
        return self.s_val[i] if i >= 0 and t - self.s_ts[i] <= 3600 else None

    def volumen(self, t: int):
        k = bisect.bisect_right(self.st_keys, t // 3600 - 1)
        w = sorted(self.st_val[max(0, k - 24):k])
        return w[len(w) // 2] if len(w) >= 12 else None

    def erreicht(self, t0: int, t1: int, px: float, oben: bool) -> bool:
        i = bisect.bisect_left(self.ts, t0); j = bisect.bisect_right(self.ts, t1)
        if j <= i:
            return False
        return max(self.hi[i:j]) >= px if oben else min(self.lo[i:j]) <= px


def anker_aus(buckets: list, p0: float, sig: float, vol: float) -> dict | None:
    """buckets: [(px, side, notional)]. Liefert A, stärkstes Cluster oben/unten (Größe/Volumen, Abstand in σ)."""
    if not (p0 and sig and vol):
        return None
    oben, unten = [], []
    for px, side, usd in buckets:
        if not px or not usd:
            continue
        d = math.log(px / p0) / sig
        if abs(px / p0 - 1) > ABST_MAX or not (D_MIN < abs(d) <= D_MAX):
            continue
        g = usd / vol
        if d > 0 and side == "short":
            oben.append((g, d, px, usd))
        elif d < 0 and side == "long":
            unten.append((g, -d, px, usd))
    w_o = sum(g / max(d, 0.5) for g, d, _, _ in oben if g >= GEWICHT_MIN)
    w_u = sum(g / max(d, 0.5) for g, d, _, _ in unten if g >= GEWICHT_MIN)
    if w_o + w_u <= 0:
        return {"A": None, "oben": max(oben, default=None), "unten": max(unten, default=None)}
    return {"A": (w_o - w_u) / (w_o + w_u), "oben": max(oben, default=None), "unten": max(unten, default=None)}


def _ueberhitzt(st, coin: str, von: int, bis: int) -> tuple:
    """Zeitpunkte (15 min) mit max |Crowding-Extrem|, |OI-Überhitzung| aus dem Prognosespeicher."""
    d: dict = {}
    try:
        for ts, s in st.execute("SELECT ts, score FROM forecast_drivers WHERE coin=? AND ts>=? AND ts<=? AND name IN ('Crowding-Extrem','OI-Überhitzung')",
                                (coin, von, bis)):
            k = ts // 900
            d[k] = max(d.get(k, 0.0), abs(s or 0.0))
    except sqlite3.Error:
        pass
    keys = sorted(d)
    return keys, [d[k] for k in keys]


# ------------------------------------------------------------------------------------------------ Bilanz
def _stat(x: list) -> dict:
    n = len(x)
    if n < 3:
        return {"n": n, "lift": (sum(x) / n) if n else None, "z": None}
    m = sum(x) / n; sd = math.sqrt(sum((v - m) ** 2 for v in x) / (n - 1))
    return {"n": n, "lift": m, "z": (m / (sd / math.sqrt(n))) if sd > 0 else None}


def bilanz(con, coin: str, path: str | None = None, tage: int = TAGE, now: int | None = None, speichern: bool = True) -> dict:
    now = now or int(time.time()); von = now - tage * 86_400
    M = Markt(con, coin, von, now)
    if len(M.ts) < 1000:
        return {"coin": coin, "bereit": False, "hinweis": "zu wenige Kursdaten"}
    v_med = sorted(M.st_val)[len(M.st_val) // 2] if M.st_val else 0.0
    try:
        rows = con.execute("SELECT ts, bucket_px, side, notional FROM heatmap WHERE coin=? AND ts>=? AND ts<=? AND ts % 1800 < 600 AND notional>=? ORDER BY ts",
                           (coin, von, now, max(v_med * GEWICHT_MIN * 0.5, 1.0))).fetchall()
    except sqlite3.Error:
        rows = []
    snaps: dict = {}
    for ts, px, side, usd in rows:
        snaps.setdefault(ts, []).append((px, side, usd))
    auswahl, letzter = [], -10 ** 12
    for ts in sorted(snaps):
        if ts - letzter >= TAKT - 300:                              # Snapshots sind nicht auf 10 min ausgerichtet
            auswahl.append(ts); letzter = ts
    st = F.store_connect(path or F.STORE)
    try:
        uk, uv = _ueberhitzt(st, coin, von, now)
    finally:
        st.close()

    def heiss(t):
        i = bisect.bisect_right(uk, t // 900) - 1
        return (uv[i] >= 0.5) if i >= 0 and t // 900 - uk[i] <= 2 else None
    basis = {h: {"auf": [0, 0], "ab": [0, 0]} for h in HORIZONTE}        # je Trendschicht: [steigend, gesamt]
    faelle = {k: [] for k in KLASSEN}
    t_start = None
    for ts in auswahl:
        p0 = M.preis(ts); sig = M.sigma(ts); vol = M.volumen(ts); p_vor = M.preis(ts - 86_400)
        if not (p0 and sig and vol and p_vor):
            continue
        t_start = t_start or ts
        trend = "auf" if p0 >= p_vor else "ab"
        rets = {}
        for h in HORIZONTE:
            if ts + h * 3600 > now:
                continue
            p1 = M.preis(ts + h * 3600)
            if p1 and p1 != p0:
                rets[h] = math.log(p1 / p0)
                b_ = basis[h][trend]; b_[0] += 1 if p1 > p0 else 0; b_[1] += 1
        a = anker_aus(snaps[ts], p0, sig, vol)
        if not a or a["A"] is None or abs(a["A"]) < A_MIN:
            continue
        dom = a["oben"] if a["A"] > 0 else a["unten"]
        if not dom:
            continue
        g, d, px, _ = dom
        for k in KLASSEN:
            if g >= k:
                faelle[k].append({"ts": ts, "A": a["A"], "trend": trend, "rets": rets, "heiss": heiss(ts), "px": px, "d": d, "p0": p0, "sig": sig})
    p_up = {h: {tr: (b[0] / b[1] if b[1] else None) for tr, b in basis[h].items()} for h in HORIZONTE}
    p_all = {h: ((basis[h]["auf"][0] + basis[h]["ab"][0]) / max(basis[h]["auf"][1] + basis[h]["ab"][1], 1)) for h in HORIZONTE}
    klassen = {}
    for k in KLASSEN:
        zeilen = {}
        for h in HORIZONTE:
            gesehen = set(); tb, roh, beruehr, heiss_d, normal_d, treff = [], [], [], [], [], []
            for f in faelle[k]:
                if h not in f["rets"] or f["ts"] // (h * 3600) in gesehen:
                    continue
                gesehen.add(f["ts"] // (h * 3600))
                hit = 1 if (f["rets"][h] > 0) == (f["A"] > 0) else 0
                pb = p_up[h].get(f["trend"])
                if pb is None:
                    continue
                erw_tb = pb if f["A"] > 0 else 1 - pb
                erw_roh = p_all[h] if f["A"] > 0 else 1 - p_all[h]
                tb.append(hit - erw_tb); roh.append(hit - erw_roh); treff.append(hit)
                (heiss_d if f["heiss"] else normal_d if f["heiss"] is False else []).append(hit - erw_tb)
                oben = f["A"] > 0
                spiegel = f["p0"] * math.exp((-1 if oben else 1) * f["d"] * f["sig"])
                b1 = M.erreicht(f["ts"], f["ts"] + h * 3600, f["px"], oben)
                b2 = M.erreicht(f["ts"], f["ts"] + h * 3600, spiegel, not oben)
                beruehr.append((1 if b1 else 0) - (1 if b2 else 0))
            zeilen[h] = {"trendbereinigt": _stat(tb), "roh": _stat(roh), "beruehrung": _stat(beruehr),
                         "ueberhitzt": _stat(heiss_d), "normal": _stat(normal_d),
                         "treffer": (sum(treff) / len(treff)) if treff else None}
        belegt_h = [h for h in HORIZONTE if (zeilen[h]["trendbereinigt"].get("z") or 0) >= 2 and (zeilen[h]["trendbereinigt"].get("lift") or 0) > 0]
        klassen[f"{int(k * 100)}"] = {"horizonte": zeilen, "belegt_in": belegt_h, "n_ereignisse": len(faelle[k])}
    b = {"coin": coin, "bereit": True, "ts": now, "seit": t_start, "tage": round((now - (t_start or now)) / 86_400, 1),
         "n_snapshots": len(auswahl), "klassen": klassen, "belegt": len(klassen["10"]["belegt_in"]) >= 2,
         "stundenvolumen_median": v_med}
    if speichern:
        try:
            F.learned_save(coin, "anker_bilanz", b)
        except Exception:
            pass
    return b


def jetzt(con, coin: str, now: int | None = None) -> dict:
    """Aktueller Anker aus dem jüngsten Snapshot, dazu der gespeicherte Stand der Bilanz."""
    now = now or int(time.time())
    try:
        r = con.execute("SELECT MAX(ts) FROM heatmap WHERE coin=? AND ts>=?", (coin, now - 3600)).fetchone()
        t = r[0] if r and r[0] else None
        buckets = [(px, s, u) for px, s, u in con.execute("SELECT bucket_px, side, notional FROM heatmap WHERE coin=? AND ts=?", (coin, t))] if t else []
    except sqlite3.Error:
        t, buckets = None, []
    M = Markt(con, coin, now - 9 * 86_400, now)
    p0 = M.preis(t or now) or (M.cl[-1] if M.cl else None); sig = M.sigma(t or now); vol = M.volumen(t or now)
    a = anker_aus(buckets, p0, sig, vol) if t else None
    bil = F.learned_load(coin, "anker_bilanz", 30 * 86_400) or {}
    zelle = lambda c_: None if not c_ else {"anteil_volumen": round(c_[0], 3), "abstand_sigma": round(c_[1], 2), "px": c_[2], "usd": c_[3],
                                           "abstand_pct": round((c_[2] / p0 - 1) * 100, 2) if p0 else None}
    return {"coin": coin, "ts": t, "preis": p0, "sigma_4h": sig, "stundenvolumen": vol, "A": (a or {}).get("A"),
            "oben": zelle((a or {}).get("oben")), "unten": zelle((a or {}).get("unten")),
            "bilanz": {"ts": bil.get("ts"), "belegt": bil.get("belegt"), "tage": bil.get("tage"),
                       "belegt_in": ((bil.get("klassen") or {}).get("10") or {}).get("belegt_in"),
                       "kurz": {h: ((((bil.get("klassen") or {}).get("10") or {}).get("horizonte") or {}).get(str(h)) or
                                    (((bil.get("klassen") or {}).get("10") or {}).get("horizonte") or {}).get(h) or {}).get("trendbereinigt")
                                for h in HORIZONTE}}}


def bericht_text(b: dict) -> str:
    if not b.get("bereit"):
        return f"{b.get('coin')}: {b.get('hinweis')}"
    pp = lambda x: "—" if x is None else f"{x * 100:+.1f} pp"
    zz = lambda x: "—" if x is None else f"{x:+.1f}"
    z = [f"{b['coin']} · Heatmap-Anker · {b['tage']} Tage, {b['n_snapshots']} Snapshots (30-min-Takt) · Stundenvolumen Median "
         f"{(b.get('stundenvolumen_median') or 0) / 1e6:.1f} Mio · Beleg: {'JA' if b['belegt'] else 'nein'}"]
    for k, kl in b["klassen"].items():
        z.append(f"  Cluster ab {k} % des Stundenvolumens · {kl['n_ereignisse']} Ereignisse · belegt in {kl['belegt_in'] or '—'} h")
        z.append(f"    {'Horizont':>8} {'n':>4} {'Treffer':>8}  {'trendber.':>10} {'z':>5}  {'roh':>9}  {'Berührung':>10} {'z':>5}  {'überhitzt':>10} {'normal':>10}")
        for h, c in kl["horizonte"].items():
            tb, ro, be = c["trendbereinigt"], c["roh"], c["beruehrung"]
            tr = "—" if c["treffer"] is None else f"{c['treffer'] * 100:.0f} %"
            z.append(f"    {str(h) + ' h':>8} {tb.get('n', 0):>4} {tr:>8}  "
                     f"{pp(tb.get('lift')):>10} {zz(tb.get('z')):>5}  {pp(ro.get('lift')):>9}  {pp(be.get('lift')):>10} {zz(be.get('z')):>5}  "
                     f"{pp(c['ueberhitzt'].get('lift')) + ' (' + str(c['ueberhitzt'].get('n', 0)) + ')':>10} {pp(c['normal'].get('lift')) + ' (' + str(c['normal'].get('n', 0)) + ')':>10}")
    return "\n".join(z)


# ------------------------------------------------------------------------------------------------ Selbsttest
def _probe_db(seed: int, modus: str):
    """Synthetischer Markt (30 Tage, 1-min-Bars) mit Heatmap-Snapshots alle 30 min.
    modus 'magnet': alle 8 h ein Cluster 1 σ entfernt, zu 80 % binnen 6 h abgeholt (Kurs läuft hin);
    'rauschen': Cluster zufällig, ohne Zusammenhang; 'trend': Aufwärts-, dann Abwärtstrend, Cluster stets auf der Seite
    des 24-h-Trends, ohne jede Wirkung -- die Trendfalle, an der die rohe Rechnung scheitert (U9)."""
    import random
    rng = random.Random(seed); now = PROBE_NOW; start = now - 30 * 86_400; von = start - 8 * 86_400
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE bars (ts INTEGER, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INTEGER)")
    con.execute("CREATE TABLE heatmap (ts INTEGER, coin TEXT, bucket_px REAL, side TEXT, notional REAL, n_pos INTEGER)")
    lp = math.log(100.0); rows, hm = [], []; ziel = None; t = von; mitte = start + 15 * 86_400; verlauf = []
    sig = 0.0006 * math.sqrt(240)                                         # σ(4 h) des Rauschens
    while t <= now + 49 * 3600:
        drift = 0.0
        if modus == "trend" and t >= start:
            drift = 0.00004 if t < mitte else -0.00004
        if ziel and t < ziel[1]:
            drift += (math.log(ziel[0]) - lp) / max((ziel[1] - t) / 60, 1)           # läuft bis zum Ende ans Cluster
        lp += drift + rng.gauss(0, 0.0006); c = math.exp(lp); verlauf.append(lp)
        rows.append((t, "AAA", c, c * 1.0003, c * 0.9997, c, 10.0, 1))
        if start <= t <= now:
            if modus == "magnet" and t % 28_800 == 0:                     # alle 8 h ein Cluster 1 σ entfernt, 80 % werden abgeholt
                oben = rng.random() < 0.5; px = c * math.exp((1 if oben else -1) * sig)
                hm.append((t, "AAA", px, "short" if oben else "long", 20_000.0, 5))
                ziel = (px, t + 6 * 3600) if rng.random() < 0.8 else None
            elif modus == "rauschen" and t % 28_800 == 0:
                oben = rng.random() < 0.5; px = c * math.exp((1 if oben else -1) * sig * rng.uniform(0.5, 2))
                hm.append((t, "AAA", px, "short" if oben else "long", 20_000.0, 5))
            elif modus == "trend" and t % 7_200 == 0 and len(verlauf) > 1440:  # Cluster auf der Seite des 24-h-Trends, ohne Wirkung
                oben = verlauf[-1] >= verlauf[-1441]; px = c * math.exp((1 if oben else -1) * sig)
                hm.append((t, "AAA", px, "short" if oben else "long", 20_000.0, 5))
        t += 60
    con.executemany("INSERT INTO bars VALUES (?,?,?,?,?,?,?,?)", rows)
    con.executemany("INSERT INTO heatmap VALUES (?,?,?,?,?,?)", hm)
    return con


def nulltest(verbose: bool = True) -> bool:
    import tempfile
    tmp = tempfile.mkdtemp(); pfad = os.path.join(tmp, "f.db"); F.store_connect(pfad).close()
    erg = {}
    for modus in ("magnet", "rauschen", "trend"):
        con = _probe_db(3, modus)
        erg[modus] = bilanz(con, "AAA", path=pfad, tage=30, now=PROBE_NOW, speichern=False)
        con.close()
    k8 = lambda m: erg[m]["klassen"]["10"]["horizonte"][8]
    pruef = [("Magnet (eingebaut) belegt", erg["magnet"]["belegt"], f"belegt in {erg['magnet']['klassen']['10']['belegt_in']} h, 8 h Vorsprung "
              f"{(k8('magnet')['trendbereinigt'].get('lift') or 0) * 100:+.0f} pp, Berührung {(k8('magnet')['beruehrung'].get('lift') or 0) * 100:+.0f} pp"),
             ("Rauschen nicht belegt", not erg["rauschen"]["belegt"], f"belegt in {erg['rauschen']['klassen']['10']['belegt_in'] or '—'}"),
             ("Trendfalle: roh scheinbar, trendbereinigt nicht", (not erg["trend"]["belegt"]) and (k8("trend")["roh"].get("lift") or 0) > 0.15,
              f"8 h roh {(k8('trend')['roh'].get('lift') or 0) * 100:+.0f} pp, trendbereinigt {(k8('trend')['trendbereinigt'].get('lift') or 0) * 100:+.0f} pp")]
    ok = all(p[1] for p in pruef)
    if verbose:
        print("Heatmap-Anker -- Selbsttest (fester Zeitpunkt, synthetische Märkte)")
        for name, gut, txt in pruef:
            print(f"  {'ok  ' if gut else 'FEHL'} {name:<46} {txt}")
        print("  Ergebnis:", "bestanden" if ok else "NICHT bestanden")
    try:
        for f_ in os.listdir(tmp):
            os.remove(os.path.join(tmp, f_))
        os.rmdir(tmp)
    except OSError:
        pass
    return ok


if __name__ == "__main__":
    if "--nulltest" in sys.argv:
        sys.exit(0 if nulltest() else 1)
    if "--bericht" in sys.argv:
        _db = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else os.environ.get("HL_DB", "hl_liq.db")
        _con = sqlite3.connect(f"file:{_db}?mode=ro", uri=True)
        coins = [r[0] for r in _con.execute("SELECT DISTINCT coin FROM heatmap WHERE ts > ?", (int(time.time()) - 86_400,))]
        print("Heatmap als Richtungsanker -- Auswertung je Coin (kein Treiber; Beleg = trendbereinigt z >= 2 in zwei Horizonten, Klasse ab 10 %)\n")
        for c in sorted(coins):
            t0 = time.time()
            print(bericht_text(bilanz(_con, c)))
            print(f"  (Rechenzeit {time.time() - t0:.0f} s)\n")
        _con.close()
        sys.exit(0)
    print("Aufruf: hl_anker.py --nulltest | --bericht --db PFAD")
