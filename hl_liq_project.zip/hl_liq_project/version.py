"""
Projektversion (von Hand gepflegt) plus Inhalts-Prüfsumme (automatisch): Die Prüfsumme über alle
Projektdateien macht den Abgleich exakt, auch wenn die Version einmal nicht hochgezählt wurde.
Anzeige: Systemkachel "Version", /system, Kopf der Werkzeugausgaben.
"""
import hashlib
import os

VERSION = "2026-09-23.24"
PROJEKTDATEIEN = ("run_all.py", "hl_recorder.py", "hl_viz.py", "hl_forecast.py", "hl_indikatoren.py", "hl_score.py", "hl_ext.py",
                  "hl_dbcoord.py", "hl_profis.py", "hl_kalib.py", "hl_konstellation.py", "hl_binance.py", "hl_coinbase.py", "hl_timestats.py", "hl_watchdog.py", "hl_backtest.py",
                  "macro_corr.py", "update.py", "migrate_db.py", "install.py", "version.py",
                  # 23.11: auch die Werkzeuge -- check_treiber ist Selbsttest-Schritt, check_* laufen aus der Debug-Konsole;
                  # ohne sie erkannte A1 ein veraltetes Werkzeug auf dem Pi nicht
                  "check_daily.py", "check_elite.py", "check_fills.py", "check_forecast.py", "check_leaderboard.py", "check_m9.py",
                  "check_magnet.py", "check_orders.py", "check_pool.py", "check_profis.py", "check_report.py", "check_sources.py",
                  "check_sperre.py", "check_treiber.py", "check_writes.py", "db_size.py", "make_treiber_pdf.py", "make_treiber_pdf_en.py")


def pruefsumme(root: str | None = None) -> str:
    root = root or os.path.dirname(os.path.abspath(__file__))
    h = hashlib.sha256()
    for f in PROJEKTDATEIEN:
        try:
            with open(os.path.join(root, f), "rb") as fh:
                h.update(f.encode()); h.update(fh.read())
        except OSError:
            h.update(f.encode() + b"?")
    return h.hexdigest()[:10]


def stand(root: str | None = None) -> str:
    return f"{VERSION} · {pruefsumme(root)}"


if __name__ == "__main__":
    print(stand())
