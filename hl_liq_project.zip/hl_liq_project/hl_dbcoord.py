#!/usr/bin/env python3
"""
hl_dbcoord.py -- Koordination paralleler Schreibzugriffe auf die SQLite-Datei.

Fünf Prozesse (Recorder, Binance-Dienst mit Fremdbörsen-Sammler, Coinbase, Watchdog,
Werkzeuge) schreiben in eine Datei. SQLite erlaubt im WAL-Modus beliebig viele Leser, aber
genau EINEN Schreiber -- und reiht wartende Schreiber nicht fair ein: Der Busy-Handler
fragt in wachsenden Abständen nach, wer zufällig zuerst nachfragt, gewinnt; ein Prozess
kann dabei verhungern. Bis 14.09.2026 hieß Koordination hier "warten, wiederholen,
zählen" -- der Poller meldete trotzdem "database is locked".

Das professionelle Muster für mehrere Schreibprozesse (Mozilla application-services,
SQLite-Forum, Praxisleitfäden): Schreibzugriffe auf Anwendungsebene serialisieren --
eine Sperre, die VOR dem ersten schreibenden Statement geholt und beim Commit freigegeben
wird, dazu BEGIN IMMEDIATE und kurze Transaktionen. Dann entsteht SQLITE_BUSY zwischen
den eigenen Prozessen nicht mehr, weil nie zwei gleichzeitig schreiben wollen; der
busy_timeout bleibt nur als Netz für fremde Werkzeuge.

Umsetzung: eine Verbindungsklasse (sqlite3.connect(..., factory=KoordinierteVerbindung)),
die jeder Schreiber benutzt. Sie hält eine prozessübergreifende Sperre (fcntl.flock auf
<db>.wlock) vom ersten schreibenden Statement bis zum Commit/Rollback, misst Wartezeit und
Haltezeit je Prozess, und gibt bei Überschreitung der Wartefrist (Vorgabe 20 s) den Weg
frei -- dann greift wieder SQLites eigener busy_timeout. Auch PRAGMA wal_checkpoint läuft
unter der Sperre: Zwischen 3.7.0 und 3.51.2 gibt es in SQLite eine seltene Race-Bedingung,
wenn getrennte Verbindungen gleichzeitig schreiben und checkpointen.

Lesende Verbindungen (mode=ro) brauchen nichts davon.

Grenze (Audit v3 L14): Ein von Hand ausgeführtes "BEGIN" (deferred) und Schreibzugriffe über
Cursor-Objekte (con.cursor().execute) laufen an dieser Klasse vorbei -- im Projekt ungenutzt.
Neue Schreibpfade müssen con.execute/executemany benutzen.
"""
from __future__ import annotations

import fcntl
import os
import sqlite3
import threading
import time

WARTEFRIST_S = 20.0            # länger wartet niemand; danach entscheidet SQLite (busy_timeout)
_SCHREIBEND = ("INSERT", "UPDATE", "DELETE", "REPLACE", "CREATE", "DROP", "ALTER", "PRAGMA WAL_CHECKPOINT",
               "VACUUM", "REINDEX", "BEGIN IMMEDIATE", "BEGIN EXCLUSIVE", "WITH")


def ist_schreibend(sql: str) -> bool:
    s = sql.lstrip().lstrip("(").upper()
    if s.startswith("WITH"):
        # CTE: nur schreibend, wenn dahinter ein INSERT/UPDATE/DELETE folgt
        return any(k in s for k in (" INSERT ", " UPDATE ", " DELETE ", " REPLACE "))
    return s.startswith(_SCHREIBEND)


class KoordinierteVerbindung(sqlite3.Connection):
    """
    sqlite3.Connection mit prozessübergreifender Schreibsperre.
    Nutzung:  con = sqlite3.connect(pfad, isolation_level="IMMEDIATE", factory=KoordinierteVerbindung)
              con.koordination(pfad, name="recorder")
    """

    def koordination(self, db_path: str, name: str = "", wartefrist: float = WARTEFRIST_S) -> "KoordinierteVerbindung":
        self._lock_path = db_path + ".wlock"
        self._name = name or os.path.basename(db_path)
        self._wartefrist = wartefrist
        self._fh = None
        self._held_since = None
        self._tl = threading.RLock()
        self.stats = {"erwerbe": 0, "wartezeit_s": 0.0, "max_wartezeit_s": 0.0, "haltezeit_s": 0.0, "max_haltezeit_s": 0.0,
                      "fristen": 0, "held_over_1s": 0, "ohne_sperrdatei": 0}
        self._versucht = False                                  # Audit v3 L1: je Transaktion nur EIN Sperrversuch
        self._erstes_sql = ""                                   # Statement, das die laufende Transaktion eröffnet hat
        self.laengste: list = []                                # [(Haltezeit s, Statement-Anfang)] -- die fünf längsten
        return self

    # -- Sperre -------------------------------------------------------------
    def _acquire(self) -> None:
        if getattr(self, "_fh", None) is not None:
            return                                          # schon gehalten (laufende Transaktion)
        if self._versucht:
            return                                          # Frist schon abgelaufen: nicht mit SQLite-Sperre auf flock warten
        self._versucht = True
        try:
            fh = open(self._lock_path, "a+b")
        except OSError as e:
            self.stats["ohne_sperrdatei"] += 1              # Audit v3 L11: sichtbar machen statt still weiter
            if self.stats["ohne_sperrdatei"] == 1:
                print(f"  Schreibkoordination: Sperrdatei {self._lock_path} nicht öffenbar ({e}) -- nur SQLite-Wartemechanik", flush=True)
            return
        t0 = time.monotonic(); frist = t0 + self._wartefrist; pause = 0.002
        while True:
            try:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except (BlockingIOError, OSError):
                if time.monotonic() >= frist:
                    self.stats["fristen"] += 1
                    fh.close()
                    return                                  # Frist um: weiter ohne Sperre, SQLite entscheidet
                time.sleep(pause); pause = min(pause * 1.5, 0.05)
        w = time.monotonic() - t0
        self.stats["erwerbe"] += 1; self.stats["wartezeit_s"] += w
        self.stats["max_wartezeit_s"] = max(self.stats["max_wartezeit_s"], w)
        self._fh = fh; self._held_since = time.monotonic()

    def _release(self) -> None:
        fh = getattr(self, "_fh", None)
        if fh is None:
            return
        h = time.monotonic() - (self._held_since or time.monotonic())
        self.stats["haltezeit_s"] += h; self.stats["max_haltezeit_s"] = max(self.stats["max_haltezeit_s"], h)
        if h > 1.0:
            self.stats["held_over_1s"] += 1
        # Die fünf längsten Transaktionen mit dem Statement, das sie eröffnet hat: Damit steht im
        # Dashboard, WER lange hält -- statt zu raten (14.09.: run_report ohne Commit, 600 s).
        if h > 0.2:
            txt = self._erstes_sql
            txt = txt.split(" VALUES ")[0].split(" WHERE ")[0]         # Tabelle und Aktion genügen
            self.laengste.append((round(h, 3), txt[:60] + ("…" if len(txt) > 60 else "")))
            self.laengste.sort(reverse=True); del self.laengste[5:]
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        fh.close(); self._fh = None; self._held_since = None; self._versucht = False

    # -- Statements ----------------------------------------------------------
    def _vor(self, sql: str) -> None:
        if getattr(self, "_tl", None) is None:
            return                                          # koordination() nicht aufgerufen: normale Verbindung
        if ist_schreibend(sql) and self._fh is None:
            self._erstes_sql = " ".join(str(sql).split())
            self._acquire()

    def _nach(self) -> None:
        # Autocommit-Modus (isolation_level=None): kein Commit folgt, also sofort freigeben
        if getattr(self, "_tl", None) is not None and self._fh is not None and not self.in_transaction:
            self._release()

    def execute(self, sql, *args, **kw):
        with getattr(self, "_tl", threading.RLock()):
            self._vor(sql)
            try:
                cur = super().execute(sql, *args, **kw)
            finally:
                self._nach()
            return cur

    def executemany(self, sql, *args, **kw):
        with getattr(self, "_tl", threading.RLock()):
            self._vor(sql)
            try:
                cur = super().executemany(sql, *args, **kw)
            finally:
                self._nach()
            return cur

    def executescript(self, script, *args, **kw):
        with getattr(self, "_tl", threading.RLock()):
            if getattr(self, "_tl", None) is not None and self._fh is None:
                self._acquire()
            try:
                return super().executescript(script, *args, **kw)
            finally:
                if getattr(self, "_tl", None) is not None and not self.in_transaction:
                    self._release()

    def commit(self):
        with getattr(self, "_tl", threading.RLock()):
            try:
                super().commit()
            finally:
                self._release(); self._versucht = False

    def rollback(self):
        with getattr(self, "_tl", threading.RLock()):
            try:
                super().rollback()
            finally:
                self._release(); self._versucht = False

    def close(self):
        try:
            self._release()
        finally:
            super().close()

    def kennzahlen(self) -> dict:
        s = dict(self.stats)
        s["laengste"] = list(self.laengste)
        n = max(1, s["erwerbe"])
        s["wartezeit_mittel_ms"] = round(s["wartezeit_s"] / n * 1000, 1)
        s["haltezeit_mittel_ms"] = round(s["haltezeit_s"] / n * 1000, 1)
        s["max_wartezeit_ms"] = round(s["max_wartezeit_s"] * 1000); s["max_haltezeit_ms"] = round(s["max_haltezeit_s"] * 1000)
        return s


def verbinden(path: str, name: str, timeout: float = 30, isolation_level: str | None = "IMMEDIATE",
              check_same_thread: bool = True) -> KoordinierteVerbindung:
    """Koordinierte Schreibverbindung mit den Projektvorgaben (WAL, busy_timeout)."""
    con = sqlite3.connect(path, timeout=timeout, isolation_level=isolation_level,
                          check_same_thread=check_same_thread, factory=KoordinierteVerbindung)
    con.koordination(path, name)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute(f"PRAGMA busy_timeout={int(timeout * 1000)}")
    return con


if __name__ == "__main__":
    # Probe: N Prozesse schreiben gleichzeitig -- ohne Koordination scheitern welche mit
    # "database is locked" (kurzer busy_timeout macht es sichtbar), mit Koordination keiner.
    import multiprocessing as mp, tempfile

    def arbeiter(pfad, koordiniert, n, q):
        fehler = 0; t0 = time.time(); waits = 0.0
        if koordiniert:
            con = verbinden(pfad, "p", timeout=0.05)
        else:
            con = sqlite3.connect(pfad, timeout=0.05, isolation_level="IMMEDIATE"); con.execute("PRAGMA busy_timeout=50")
        for i in range(n):
            try:
                con.execute("INSERT INTO t (v) VALUES (?)", (i,))
                con.execute("UPDATE t SET v=v+1 WHERE k=1")
                con.commit()
            except sqlite3.OperationalError as e:
                fehler += 1
                try:
                    con.rollback()
                except sqlite3.Error:
                    pass
        q.put((fehler, time.time() - t0, con.kennzahlen() if koordiniert else {}))

    tmp = tempfile.mkdtemp(); pfad = os.path.join(tmp, "p.db")
    c = sqlite3.connect(pfad); c.execute("PRAGMA journal_mode=WAL"); c.execute("CREATE TABLE t (k INTEGER PRIMARY KEY, v INTEGER)"); c.commit(); c.close()
    for koordiniert in (False, True):
        q = mp.Queue(); ps = [mp.Process(target=arbeiter, args=(pfad, koordiniert, 300, q)) for _ in range(4)]
        [p.start() for p in ps]; erg = [q.get() for _ in ps]; [p.join() for p in ps]
        fehler = sum(e[0] for e in erg); dauer = max(e[1] for e in erg)
        maxw = max((e[2].get("max_wartezeit_ms", 0) for e in erg), default=0)
        print(f"  {'mit' if koordiniert else 'ohne'} Koordination: 4 Prozesse x 300 Transaktionen, busy_timeout 50 ms -> "
              f"{fehler} Fehler 'database is locked', {dauer:.1f} s" + (f", längstes Warten {maxw} ms" if koordiniert else ""))
    n = sqlite3.connect(pfad).execute("SELECT COUNT(*) FROM t").fetchone()[0]
    print(f"  Zeilen in der Tabelle: {n:,} (Soll {2 * 4 * 300:,} abzüglich der Fehler ohne Koordination)")
    assert erg and sum(e[0] for e in erg) == 0, "mit Koordination darf kein Fehler auftreten"
    print("Alles in Ordnung.")
