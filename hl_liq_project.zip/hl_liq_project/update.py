#!/usr/bin/env python3
"""
update.py — spielt ein neues Projektarchiv ein und startet die Dienste neu.

    python3 update.py                          # neuestes hl_liq_project*.zip aus ~/Downloads
    python3 update.py ~/Downloads/hl_liq_project.zip
    python3 update.py --no-db-backup           # ohne vorheriges Datenbank-Backup

Ablauf:
  1. Archiv finden (auch hl_liq_project-2.zip, -3.zip … — Browser hängen das an)
  2. Datenbank-Backup über hl_recorder.py --backup
  3. Sicherungskopie der bisherigen Skripte
  4. Dienste stoppen
  5. Dateien aus dem Archiv einspielen (Datenbank, Backups, Logs bleiben unberührt)
  6. Syntaxprüfung aller Skripte — schlägt sie fehl, wird die Sicherung zurückgespielt
  7. systemd-Units neu erzeugen und installieren
  8. Dienste starten und prüfen

Nur die Befehle, die es brauchen, laufen über sudo (systemctl, Kopieren nach
/etc/systemd). Das Skript selbst als normaler Benutzer starten.
"""

from __future__ import annotations

import argparse
import glob
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SERVICES = ["hl-recorder", "hl-binance", "hl-coinbase", "hl-dashboard", "hl-watchdog"]
# Dateien, die der Nutzer selbst pflegt: werden nur angelegt, wenn sie fehlen, nie überschrieben
KEEP_IF_EXISTS = {"labels.json", "accesstokens.json"}
PROJECT_FILES = {"install.py", "requirements.txt", "README.md", "run_all.py", "labels.json", "accesstokens.json",
                 "hl_recorder.py", "hl_viz.py", "hl_binance.py", "hl_timestats.py",
                 "hl_watchdog.py", "hl_backtest.py", "macro_corr.py", "update.py",
                 "migrate_db.py", "check_daily.py", "db_size.py", "check_orders.py", "check_leaderboard.py", "hl_forecast.py", "check_forecast.py", "check_writes.py", "check_report.py", "hl_coinbase.py",
                 "hl_score.py", "check_m9.py", "check_fills.py", "check_sources.py", "hl_ext.py", "check_magnet.py", "hl_dbcoord.py", "hl_indikatoren.py", "check_elite.py", "check_treiber.py", "make_treiber_pdf.py", "version.py", "make_treiber_pdf_en.py", "check_pool.py", "KONZEPT_Aktive_Profis.md", "check_sperre.py", "REVIEW_Audit_v10_22-09-2026.md", "UPDATE_PLAN.md", "hl_profis.py", "check_profis.py", "hl_kalib.py", "hl_konstellation.py", "hl_familien.py", "hl_anker.py", "hl_labor.py", "hl_adressfluss.py", "PROJEKTUEBERGABE_OPUS55_23-09-2026.md",
                 "hl_fusion.py", "KONZEPT_Fusion.md", "hl_kaskade.py", "hl_magnet.py",
                 "hl_makro.py", "hl_makro_js.py", "hl_makro_signal.py", "hl_makro_korr.py", "KONZEPT_Makro.md", "RECHERCHE_Makro_Chart_05-10-2026.md",
                 "hl_regime.py", "KONZEPT_Regime.md", "RECHERCHE_Regime_07-10-2026.md",
                 "hl_swing.py", "KONZEPT_Swing.md", "hl_zyklus.py", "KONZEPT_Zyklen.md"}
OK, WARN, FAIL = "  [ok]   ", "  [!]    ", "  [FEHLER]"


SUDO_PW: str | None = None


def load_sudo_password() -> str | None:
    """
    sudo.txt im Projektordner: erlaubt Updates ohne Terminal (Dashboard-Knopf).
    Nur mit Rechten 600 akzeptiert -- sonst könnte jeder Benutzer des Systems
    das Passwort lesen. Das Passwort landet nie im Log.
    """
    f = ROOT / "sudo.txt"
    if not f.exists():
        return None
    mode = f.stat().st_mode & 0o777
    if mode & 0o077:
        print(f"{WARN}sudo.txt hat Rechte {oct(mode)} — andere Benutzer könnten sie lesen. "
              "Nicht verwendet; bitte: chmod 600 sudo.txt")
        return None
    pw = f.read_text(errors="replace").strip()
    return pw or None


def run(cmd, sudo=False, check=False, capture=True):
    if sudo and os.geteuid() != 0:
        if SUDO_PW:
            # -S liest das Passwort von stdin, -p "" unterdrückt den Prompt
            r = subprocess.run(["sudo", "-S", "-p", ""] + cmd, input=SUDO_PW + "\n",
                               capture_output=capture, text=True)
            if check and r.returncode != 0:
                raise RuntimeError(f"{' '.join(cmd)}\n{r.stderr.strip()}")
            return r
        cmd = ["sudo"] + cmd
    r = subprocess.run(cmd, capture_output=capture, text=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)}\n{r.stderr.strip()}")
    return r


def have_systemd() -> bool:
    return shutil.which("systemctl") is not None and Path("/run/systemd/system").exists()


def unit_arg(flag: str) -> str | None:
    """Wert eines Arguments aus der installierten Recorder-Unit, z. B. --backup-dir."""
    unit = Path("/etc/systemd/system/hl-recorder.service")
    if unit.exists():
        import re
        m = re.search(flag + r"\s+(\S+)", unit.read_text(errors="replace"))
        if m:
            return m.group(1)
    return None


def db_path(explicit: str | None) -> Path:
    """
    Wo liegt die Datenbank? Vorrang: --db, dann die installierte Unit
    (dort steht der Pfad nach einem Umzug), zuletzt neben den Skripten.
    """
    if explicit:
        return Path(explicit).expanduser()
    unit = Path("/etc/systemd/system/hl-recorder.service")
    if unit.exists():
        import re
        m = re.search(r"--db\s+(\S+)", unit.read_text(errors="replace"))
        if m:
            return Path(m.group(1))
    return ROOT / "hl_liq.db"


def find_archive(explicit: str | None) -> Path:
    if explicit:
        p = Path(explicit).expanduser()
        if not p.exists():
            sys.exit(f"Archiv nicht gefunden: {p}")
        return p
    candidates = []
    homes = [Path.home()]
    if os.environ.get("SUDO_USER"):
        homes.append(Path("/home") / os.environ["SUDO_USER"])
    dirs = [h / "Downloads" for h in homes] + [ROOT, ROOT.parent, Path.cwd()]
    for d in dirs:
        candidates += [Path(x) for x in glob.glob(str(d / "hl_liq_project*.zip"))]
    if not candidates:
        sys.exit("Kein hl_liq_project*.zip gefunden. Pfad angeben:\n"
                 "  python3 update.py /pfad/zum/archiv.zip")
    newest = max(candidates, key=lambda p: p.stat().st_mtime)
    if len(candidates) > 1:
        print(f"  {len(candidates)} Archive gefunden, nehme das neueste:")
    return newest


def service_state(name: str) -> str:
    r = run(["systemctl", "is-active", name])
    return r.stdout.strip() or "unbekannt"


def drop_root() -> None:
    """
    Unter sudo gestartet: als der eigentliche Benutzer neu starten.

    Sonst gehören Backup, Sicherung und Bytecode danach root, und die Dienste,
    die als normaler Benutzer laufen, können sie nicht mehr überschreiben.
    Ausserdem zeigt ~ unter sudo auf /root, wo kein Downloads-Ordner liegt.
    """
    user = os.environ.get("SUDO_USER")
    if os.geteuid() == 0 and user and user != "root":
        print(f"Als root gestartet — wechsle zu Benutzer '{user}' "
              "(sudo wird nur für die Dienste gebraucht).\n")
        os.execvp("sudo", ["sudo", "-u", user, "-H", sys.executable] + sys.argv)
    if os.geteuid() == 0:
        print(f"{WARN}Läuft als root. Dateien gehören danach root — falls die Dienste "
              "als anderer Benutzer laufen, Besitz danach anpassen.\n")


def clean_pycache() -> None:
    """Bytecode-Cache entfernen, notfalls mit sudo, wenn er root gehört."""
    pc = ROOT / "__pycache__"
    if not pc.exists():
        return
    try:
        shutil.rmtree(pc)
    except PermissionError:
        r = run(["rm", "-rf", str(pc)], sudo=True)
        if r.returncode == 0:
            print(f"{OK}root-gehöriges __pycache__ entfernt (sudo)")
        else:
            print(f"{WARN}__pycache__ gehört root und ließ sich nicht entfernen")


def syntax_ok(path: Path) -> str | None:
    """Reine Syntaxprüfung ohne Schreiben auf die Platte. None = in Ordnung."""
    import ast
    try:
        ast.parse(path.read_text(encoding="utf-8", errors="replace"), filename=str(path))
        return None
    except SyntaxError as e:
        return f"{path.name}, Zeile {e.lineno}: {e.msg}"


SIDE_FILES = ("forecasts.db", "sys_history.json")


def move_side_files(db: Path) -> None:
    """
    forecasts.db (Prognosen, gelernte Gewichte, Lernstand) und sys_history.json gehören neben
    die Hauptdatenbank: dort liegt das externe Medium, die SD-Karte wird geschont. Vorhandene
    Dateien werden mitsamt WAL verschoben, nichts überschrieben.
    """
    target_dir = db.parent
    if not target_dir.is_dir() or not os.access(target_dir, os.W_OK):
        print(f"{WARN}Zielordner {target_dir} nicht beschreibbar — Prognosedateien bleiben im Projektordner")
        return
    if target_dir.resolve() == ROOT.resolve():
        return
    print("\n8. Prognosedateien neben die Hauptdatenbank")
    moved = 0
    for name in SIDE_FILES:
        src = ROOT / name; dst = target_dir / name
        if not src.exists():
            continue
        if dst.exists():
            if src.stat().st_size > dst.stat().st_size:      # die größere ist die gepflegte
                dst.rename(dst.with_suffix(dst.suffix + ".alt"))
                print(f"{WARN}{name} lag schon am Ziel — die kleinere als {dst.name}.alt beiseitegelegt")
            else:
                print(f"{OK}{name:<20} am Ziel bereits aktuell, Projektkopie entfernt")
                for ext in ("", "-wal", "-shm"):
                    Path(str(src) + ext).unlink(missing_ok=True)
                continue
        for ext in ("", "-wal", "-shm"):                      # WAL mitnehmen, sonst fehlen die letzten Zeilen
            s_, d_ = Path(str(src) + ext), Path(str(dst) + ext)
            if s_.exists():
                shutil.move(str(s_), str(d_))
        size = dst.stat().st_size / 1e6 if dst.exists() else 0
        print(f"{OK}{name:<20} -> {dst}  ({size:,.1f} MB)")
        moved += 1
    if moved:
        print(f"        Ab jetzt schreibt das Dashboard dorthin (erkannt über den --db-Pfad der Unit).")
    else:
        print(f"{OK}nichts zu verschieben")


# Dateien, die eine Wiederherstellung NIE anfasst -- Datenbanken und Laufzeitzustand.
# Wiederhergestellt werden nur Projektdateien (PROJECT_FILES); alles andere im Backup-Ordner
# wird ignoriert, Datenbankmuster werden zusätzlich ausdrücklich abgewiesen.
DB_MUSTER = ("*.db", "*.db-wal", "*.db-shm", "*.db-journal", "*.sqlite", "*.sqlite3", "*.sqlite-*")
NIE_WIEDERHERSTELLEN = {"sys_history.json", "labels_cache.json", "sudo.txt", "forecasts.db", "hl_liq.db"}


def letztes_backup() -> Path | None:
    """Der jüngste Ordner updates/vor_* (Sicherung der Projektdateien vor einem Update)."""
    ordner = sorted((ROOT / "updates").glob("vor_*"), key=lambda d: d.stat().st_mtime) if (ROOT / "updates").exists() else []
    ordner = [d for d in ordner if d.is_dir()]
    return ordner[-1] if ordner else None


def backup_info() -> dict:
    """Für den Dashboard-Knopf: welches Backup würde wiederhergestellt, was ist darin?"""
    import fnmatch
    b = letztes_backup()
    if not b:
        return {"vorhanden": False}
    dateien = [f for f in b.iterdir() if f.is_file()]
    wieder = [f.name for f in dateien if f.name in PROJECT_FILES and f.name not in NIE_WIEDERHERSTELLEN
              and not any(fnmatch.fnmatch(f.name, m) for m in DB_MUSTER)]
    uebersprungen = sorted(f.name for f in dateien if f.name not in wieder)
    return {"vorhanden": True, "ordner": b.name, "zeit": int(b.stat().st_mtime), "dateien": len(wieder),
            "uebersprungen": uebersprungen}


def restore_last(yes: bool) -> None:
    """
    Das letzte Code-Backup zurückspielen: Dienste stoppen, Projektdateien aus updates/vor_<jüngst>
    kopieren, Syntax prüfen, Dienste starten. Datenbanken und Laufzeitzustand werden NICHT
    berührt -- weder gelesen noch geschrieben; Dateien mit Datenbankmustern im Backup-Ordner
    werden ausdrücklich übersprungen. Der jetzige Stand wird vorher selbst gesichert
    (updates/vor_<stamp>_rueck), damit auch die Wiederherstellung rückgängig gemacht werden kann.
    """
    import fnmatch
    print("=" * 62)
    print(" Wiederherstellung des letzten Backups (nur Projektdateien)")
    print("=" * 62)
    b = letztes_backup()
    if not b:
        sys.exit("Kein Backup-Ordner updates/vor_* vorhanden.")
    info = backup_info()
    print(f"\n1. Backup\n{OK}{b.relative_to(ROOT)}  ({time.strftime('%d.%m.%Y %H:%M', time.localtime(info['zeit']))}, {info['dateien']} Projektdateien)")
    if info["uebersprungen"]:
        print(f"{WARN}übersprungen (keine Projektdateien oder Datenbank/Zustand): {', '.join(info['uebersprungen'][:12])}")
    if not yes:
        antwort = input("Diesen Stand wiederherstellen? Dienste werden neu gestartet. [j/N] ").strip().lower()
        if antwort not in ("j", "ja", "y", "yes"):
            sys.exit("Abgebrochen.")

    print("\n2. Jetzigen Stand sichern")
    stamp = time.strftime("%Y%m%d_%H%M%S")
    sich = ROOT / "updates" / f"vor_{stamp}_rueck"
    sich.mkdir(parents=True, exist_ok=True)
    n = 0
    for f in PROJECT_FILES:
        src = ROOT / f
        if src.exists():
            shutil.copy2(src, sich / f); n += 1
    print(f"{OK}{n} Dateien nach {sich.relative_to(ROOT)}")

    print("\n3. Dienste")
    active = []
    if have_systemd():
        active = [s_ for s_ in SERVICES if service_state(s_) == "active"]
        if active:
            run(["systemctl", "stop"] + active, sudo=True, check=True)
            print(f"{OK}gestoppt: {', '.join(active)}")
    else:
        print(f"{WARN}kein systemd — Dienste werden nicht verwaltet")

    print("\n4. Zurückspielen")
    kopiert, geschuetzt = [], []
    for f in sorted(b.iterdir()):
        if not f.is_file():
            continue
        if f.name in NIE_WIEDERHERSTELLEN or any(fnmatch.fnmatch(f.name, m) for m in DB_MUSTER):
            geschuetzt.append(f.name); continue
        if f.name not in PROJECT_FILES:
            continue
        shutil.copy2(f, ROOT / f.name); kopiert.append(f.name)
    print(f"{OK}{len(kopiert)} Dateien wiederhergestellt" + (f" · ausdrücklich geschützt: {', '.join(geschuetzt)}" if geschuetzt else ""))

    print("\n5. Syntax")
    fehler = [(f, e) for f in kopiert if f.endswith(".py") for e in [syntax_ok(ROOT / f)] if e]
    if fehler:
        print(f"{FAIL}Syntaxfehler in {', '.join(f for f, _ in fehler)} — Wiederherstellung wird ZURÜCKGENOMMEN (Stand aus {sich.name})")
        for f, e in fehler:
            print(f"        {f}: {e}")
        # Audit v4 M5: Vorher blieben die kaputten Dateien liegen und die Dienste wurden damit gestartet.
        # Jetzt: den vorher gesicherten Stand zurückkopieren, dann starten.
        zurueck = 0
        for f in sich.iterdir():
            if f.is_file() and f.name in PROJECT_FILES:
                shutil.copy2(f, ROOT / f.name); zurueck += 1
        print(f"{OK}{zurueck} Dateien aus {sich.name} zurückgespielt")
        clean_pycache()
        if active:
            run(["systemctl", "start"] + active, sudo=True)
        sys.exit(1)
    print(f"{OK}alle Skripte syntaktisch in Ordnung")
    clean_pycache()

    print("\n6. Start")
    if have_systemd() and active:
        run(["systemctl", "start"] + active, sudo=True)
        time.sleep(3)
        for s_ in active:
            print(f"{OK if service_state(s_) == 'active' else FAIL}{s_}: {service_state(s_)}")
    print("\nFertig. Datenbanken wurden nicht berührt.")


def main() -> None:
    global SUDO_PW
    drop_root()
    SUDO_PW = load_sudo_password()
    p = argparse.ArgumentParser(description="Projekt aktualisieren")
    p.add_argument("archive", nargs="?", help="ZIP-Datei; sonst automatische Suche")
    p.add_argument("--no-db-backup", action="store_true")
    p.add_argument("--force-db-backup", action="store_true",
                   help="Backup auch dann, wenn eines jünger als 24 h vorliegt")
    p.add_argument("--db", help="Datenbankpfad; sonst aus der installierten Unit")
    p.add_argument("--yes", action="store_true",
                   help="keine Rückfragen (für den Dashboard-Knopf); bei Backup-Fehler abbrechen")
    p.add_argument("--restore-last", action="store_true",
                   help="das letzte Code-Backup (updates/vor_*) zurückspielen; Datenbanken bleiben unberührt")
    p.add_argument("--backup-info", action="store_true", help="nur anzeigen, welches Backup wiederhergestellt würde (JSON)")
    args = p.parse_args()
    if args.backup_info:
        import json as _j
        print(_j.dumps(backup_info())); return
    if args.restore_last:
        restore_last(args.yes); return
    py = str(ROOT / ".venv" / "bin" / "python") if (ROOT / ".venv").exists() else sys.executable

    print("=" * 62)
    print(" Update hl_liq_project")
    print("=" * 62)

    # 1. Archiv
    print("\n1. Archiv")
    archive = find_archive(args.archive)
    age = (time.time() - archive.stat().st_mtime) / 60
    print(f"{OK}{archive}  ({archive.stat().st_size/1024:.0f} kB, vor {age:.0f} min)")
    with zipfile.ZipFile(archive) as z:
        names = [n for n in z.namelist() if n.endswith(".py") or n.endswith((".md", ".txt"))]
        inner = {Path(n).name for n in names}
        missing = {"hl_recorder.py", "hl_viz.py", "install.py"} - inner
        if missing:
            sys.exit(f"Archiv unvollständig, es fehlen: {', '.join(sorted(missing))}")
        print(f"{OK}{len(inner)} Projektdateien im Archiv")

    # 2. Datenbank-Backup
    print("\n2. Datenbank")
    db = db_path(args.db)
    print(f"        Datenbank: {db}")
    fresh = None
    try:
        import json as _json
        bdir0 = unit_arg("--backup-dir") or str(db.parent / "dbbackup")
        st0 = _json.load(open(Path(bdir0) / "backup.json"))
        if st0.get("ok") and time.time() - st0["ts"] < 24 * 3600:
            fresh = (time.time() - st0["ts"]) / 3600
    except (OSError, ValueError, KeyError):
        pass
    if args.no_db_backup:
        print(f"{WARN}Backup übersprungen (--no-db-backup)")
    elif not db.exists():
        print(f"{WARN}keine Datenbank vorhanden, nichts zu sichern")
    elif fresh is not None and not args.force_db_backup:
        print(f"{OK}Backup vor {fresh:.1f} h vorhanden — kein neues nötig "
              "(--force-db-backup erzwingt eines)")
    else:
        print("        Backup läuft (kann bei großer Datenbank eine Minute dauern) …")
        bdir = unit_arg("--backup-dir")
        r = run([py, str(ROOT / "hl_recorder.py"), "--db", str(db), "--backup"]
                + (["--backup-dir", bdir] if bdir else []))
        last = [l for l in r.stdout.splitlines() if l.strip()][-1:] or [r.stderr.strip()[-200:]]
        if r.returncode == 0:
            print(f"{OK}{last[0]}")
        else:
            print(f"{FAIL}{last[0]}")
            if args.yes or input("        Trotzdem fortfahren? [j/N] ").strip().lower() != "j":
                print("        Abbruch — Update ohne gültiges Backup nicht ausgeführt.")
                sys.exit(1)

    # 3. Sicherung der Skripte
    print("\n3. Sicherung")
    stamp = time.strftime("%Y%m%d_%H%M%S")
    bak = ROOT / "updates" / f"vor_{stamp}"
    bak.mkdir(parents=True, exist_ok=True)
    n = 0
    for f in PROJECT_FILES:
        src = ROOT / f
        if src.exists():
            shutil.copy2(src, bak / f); n += 1
    print(f"{OK}{n} Dateien nach {bak.relative_to(ROOT)}")

    # 4. Dienste stoppen
    print("\n4. Dienste")
    active = []
    if have_systemd():
        for s in SERVICES:
            if service_state(s) == "active":
                active.append(s)
        if active:
            print(f"        stoppe {', '.join(active)} (sudo) …")
            run(["systemctl", "stop"] + active, sudo=True, check=True)
            print(f"{OK}gestoppt")
        else:
            print(f"{WARN}kein Dienst aktiv")
    else:
        print(f"{WARN}kein systemd — Dienste werden nicht verwaltet")

    # 5. Einspielen
    print("\n5. Einspielen")
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(archive) as z:
            z.extractall(tmp)
        src_files = {Path(f).name: Path(f) for f in glob.glob(f"{tmp}/**/*", recursive=True)
                     if Path(f).is_file()}
        changed, same = [], []
        extra = sorted(n for n in src_files if n not in PROJECT_FILES and n.endswith((".py", ".json")) and "/" not in n)
        if extra:
            print(f"        {len(extra)} weitere Datei(en) aus dem Archiv übernommen: {', '.join(extra)}")
        for name in sorted(PROJECT_FILES | set(extra)):
            if name not in src_files:
                continue
            dst = ROOT / name
            new = src_files[name].read_bytes()
            if name in KEEP_IF_EXISTS and dst.exists():
                same.append(name)             # eigene Pflege bleibt unangetastet
                continue
            if dst.exists() and dst.read_bytes() == new:
                same.append(name)
            else:
                dst.write_bytes(new); changed.append(name)
            if name.endswith(".py"):
                dst.chmod(dst.stat().st_mode | 0o111)
    for f in changed:
        print(f"{OK}{f:<20} aktualisiert")
    if same:
        print(f"        {len(same)} Dateien unverändert")
    # Reste alter Downloads mit -2/-3-Suffix aufräumen
    for junk in glob.glob(str(ROOT / "hl_*-[0-9].py")) + glob.glob(str(ROOT / "hl_*-[0-9][0-9].py")):
        os.remove(junk); print(f"{OK}Altlast entfernt: {Path(junk).name}")
    clean_pycache()

    # 6. Syntaxprüfung
    print("\n6. Prüfung")
    errors = [e for e in (syntax_ok(ROOT / f) for f in sorted(PROJECT_FILES)
                          if f.endswith(".py") and (ROOT / f).exists()) if e]
    if errors:
        print(f"{FAIL}Syntaxfehler — Sicherung wird zurückgespielt")
        for e in errors:
            print(f"        {e}")
        for f in bak.iterdir():
            shutil.copy2(f, ROOT / f.name)
        if active:
            run(["systemctl", "start"] + active, sudo=True)
        sys.exit(1)
    print(f"{OK}alle Skripte syntaktisch in Ordnung")
    clean_pycache()
    for marker, label in (("fvgtoggle", "FVG-Schalter"), ("computeSignal", "Konfluenz"),
                          ("kpi_backup", "Backup-Kachel")):
        has = marker in (ROOT / "hl_viz.py").read_text(errors="replace")
        print(f"{OK if has else WARN}Dashboard enthält {label}")

    # 7. Units erneuern
    print("\n7. systemd-Units")
    if have_systemd():
        bdir = unit_arg("--backup-dir")
        ldir = None
        unit = Path("/etc/systemd/system/hl-recorder.service")
        if unit.exists():
            import re
            m = re.search(r"append:(\S+)/recorder\.log", unit.read_text(errors="replace"))
            ldir = m.group(1) if m else None
        r = run([sys.executable, str(ROOT / "install.py"), "--units-only",
                 "--db", str(db)] + (["--backup-dir", bdir] if bdir else [])
                + (["--log-dir", ldir] if ldir else []))
        units = sorted((ROOT / "systemd").glob("*.service"))
        if r.returncode != 0 or not units:
            print(f"{FAIL}Units konnten nicht erzeugt werden\n{r.stderr[-400:]}")
        else:
            run(["cp"] + [str(u) for u in units] + ["/etc/systemd/system/"], sudo=True, check=True)
            run(["systemctl", "daemon-reload"], sudo=True, check=True)
            print(f"{OK}{len(units)} Units installiert: "
                  + ", ".join(u.stem for u in units))
            # Neue Dienste selbst aktivieren. Ohne das läge die Unit zwar auf der Platte,
            # würde aber weder starten noch beim Neustart mitkommen -- der Nutzer müsste
            # von Hand nachhelfen und wüsste nicht, dass es nötig ist.
            neu = []
            for u in units:
                if run(["systemctl", "is-enabled", u.stem]).stdout.strip() not in ("enabled", "enabled-runtime"):
                    r2 = run(["systemctl", "enable", u.stem], sudo=True)
                    if r2.returncode == 0:
                        neu.append(u.stem)
            if neu:
                print(f"{OK}neu aktiviert: {', '.join(neu)}")
    else:
        print(f"{WARN}übersprungen (kein systemd)")

    # 8. Starten und prüfen
    print("\n8. Start")
    if have_systemd():
        to_start = [s for s in SERVICES
                    if run(["systemctl", "is-enabled", s]).stdout.strip() in ("enabled", "enabled-runtime")]
        if not to_start:
            to_start = active
        if to_start:
            run(["systemctl", "start"] + to_start, sudo=True, check=True)
            time.sleep(6)
            all_ok = True
            for s in to_start:
                st = service_state(s)
                all_ok &= st == "active"
                print(f"{OK if st == 'active' else FAIL}{s:<16} {st}")
            if not all_ok:
                print("\n        Ein Dienst läuft nicht. Ursache:")
                for s in to_start:
                    if service_state(s) != "active":
                        r = run(["journalctl", "-u", s, "-n", "15", "--no-pager"], sudo=True)
                        print("        " + r.stdout.strip().replace("\n", "\n        ")[-900:])
        else:
            print(f"{WARN}kein Dienst eingerichtet — python3 install.py --enable")

    # 8. Seitendateien der Prognose neben die Hauptdatenbank legen (schont die SD-Karte)
    try:
        move_side_files(db_path(args.db))
    except Exception as e:
        print(f"{WARN}Seitendateien nicht verschoben: {e}")

    print("\n" + "=" * 62)
    print(" Fertig. Im Browser mit Strg+F5 neu laden (nicht nur F5).")
    print(f" Rückgängig: Dateien aus {bak.relative_to(ROOT)} zurückkopieren.")
    print("=" * 62)


if __name__ == "__main__":
    main()
