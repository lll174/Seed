#!/usr/bin/env python3
"""
hl_ext.py -- Reihen der Fremdbörsen dauerhaft speichern.

Bis 14.09.2026 wurden Bybit, OKX, Crypto.com, die Binance-Verhältnisse, das Binance-Orderbuch
und die ETF-Flüsse nur LIVE abgefragt: Ihr Beitrag landete als fertiger Treiberwert im
Prognose-Payload, die Rohreihe ging verloren. Kein Backtest, kein neuer Treiber aus alten
Daten, keine einheitlichen Zeitfenster. Dieses Modul schreibt sie in die Hauptdatenbank:

  ext_metrics       alle 5 min je Börse und Coin: Kurs, Open Interest, Funding, Taker-
                    Verhältnis (mit Zeitspanne der Stichprobe), Long/Short, Volumen
  bnc_metrics       Binance-Verhältnisse (Taker, Long/Short global/Top) im 5-min-Raster --
                    dieselbe Tabelle wie das Open Interest, damit die Reihe lückenlos wird
  bnc_book          Binance-Orderbuch alle 5 min: Tiefe je Abstand und Wände je Preisstufe,
                    gleiches Muster wie cb_book (Coinbase)
  ext_liquidations  Liquidationen von Bybit (WebSocket allLiquidation, vollständig) und OKX
                    (REST liquidation-orders, alle 2 min), Seite = LIQUIDIERTE POSITION
  etf_flows         tägliche Netto-Flüsse der Spot-ETFs (Farside), eine Zeile je Tag und Coin

Konventionen wie im ganzen Projekt: Zeitstempel in SEKUNDEN, Seiten "long"/"short", Werte in
USD, Fehler je Aufruf abgefangen und gezählt. Nicht gelistete Paare werden je Börse erkannt
(Bybit retCode != 0, OKX 51001, Crypto.com 40004) und für einen Tag ausgelassen.

Läuft als Zusatzaufgaben im Binance-Dienst (hl_binance.py) -- eine Unit, eine Verbindung.
Ratenbudget (öffentliche Endpunkte, je 5 min): Bybit 18 Aufrufe (Limit 600 je 5 s), OKX
~26 + 4 je 2 min (Limit 20 je 2 s je Endpunkt, rubik 5 je 2 s), Crypto.com 12 (Limit 100/s),
Binance 24 Verhältnis-Aufrufe (eigenes Limit der /futures/data-Endpunkte) und 60 Gewicht
Orderbuch (von 2.400 je Minute). Zwischen den Aufrufen 0,3 s Pause.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import math
import re
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

BYBIT = "https://api.bybit.com/v5/market"
BYBIT_WS = "wss://stream.bybit.com/v5/public/linear"
OKX = "https://www.okx.com/api/v5"
CDC = "https://api.crypto.com/exchange/v1/public/"
BNC_F = "https://fapi.binance.com"
FARSIDE = "https://farside.co.uk/"
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux) hl-dashboard/1.0"}
PAUSE = 0.3
VORHALT_TAGE = 90            # ext_metrics, bnc_book, ext_liquidations
SPERRE_UNGELISTET = 86_400   # Sekunden, bis ein nicht gelistetes Paar erneut probiert wird

SCHEMA = """
CREATE TABLE IF NOT EXISTS ext_metrics (
    ts INTEGER, exchange TEXT, coin TEXT, metric TEXT, value REAL,
    PRIMARY KEY (ts, exchange, coin, metric));
CREATE INDEX IF NOT EXISTS ix_ext_metrics ON ext_metrics(exchange, coin, metric, ts);
CREATE TABLE IF NOT EXISTS bnc_book (
    ts INTEGER, coin TEXT, bid REAL, ask REAL, mid REAL,
    bid5 REAL, ask5 REAL, bid25 REAL, ask25 REAL, bid100 REAL, ask100 REAL, walls TEXT,
    PRIMARY KEY (ts, coin));
CREATE TABLE IF NOT EXISTS ext_liquidations (
    ts INTEGER, exchange TEXT, coin TEXT, side TEXT, price REAL, qty REAL, notional REAL, uid TEXT,
    PRIMARY KEY (exchange, uid));
CREATE INDEX IF NOT EXISTS ix_ext_liq ON ext_liquidations(coin, ts);
CREATE TABLE IF NOT EXISTS etf_flows (
    day TEXT, coin TEXT, flow_musd REAL, fetched INTEGER,
    PRIMARY KEY (day, coin));
"""


# ---------------------------------------------------------------------------
# Hilfen
# ---------------------------------------------------------------------------

def _f(v, default=0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def http(url: str, timeout: int = 15, text: bool = False):
    """(Antwort, Fehlertext). Fehler werden nie geworfen -- der Sammler läuft weiter."""
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        return None, f"HTTP {e.code}: {e.read()[:120].decode('utf-8', 'replace')}"
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"
    if text:
        return raw.decode("utf-8", "replace"), None
    try:
        return json.loads(raw), None
    except ValueError:
        return None, "kein JSON"


def verbinden(path: str) -> sqlite3.Connection:
    """
    Eigene Verbindung des Sammlers. Die Abrufe laufen in Threads (asyncio.to_thread), der
    Bybit-Stream auf der Ereignisschleife -- SQLite-Verbindungen sind an ihren Thread gebunden,
    deshalb check_same_thread=False und ein Schloss um jeden Zugriff (siehe schreibe()).
    busy_timeout kurz: Bei Sperre wird der Datenpunkt gezählt und ausgelassen, nicht gewartet.
    """
    con = sqlite3.connect(path, timeout=5, check_same_thread=False, isolation_level="IMMEDIATE")
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=5000")
    con.execute("PRAGMA synchronous=NORMAL")
    return con


class Sammler:
    """Zustand des Sammlers: Zähler, Sperren für nicht gelistete Paare, Schreibhelfer."""

    def __init__(self, con: sqlite3.Connection, coins: list, bnc_sym: dict | None = None):
        self.con = con
        self.lock = threading.Lock()
        self.coins = [c.upper() for c in coins]
        self.bnc_sym = bnc_sym or {}            # coin -> Binance-Symbol (aus exchangeInfo)
        self.stats: dict = {"metrics_rows": 0, "book_rows": 0, "liq_rows": 0, "etf_rows": 0,
                            "fehler": 0, "db_locked": 0, "db_retry": 0, "ungelistet": 0, "bybit_ws_events": 0, "bybit_ws_reconnects": 0}
        self.liq_rest: list = []                # bei Sperre zurückgehaltene Liquidations-Zeilen (kein Verlust)
        self.ungelistet: dict = {}              # (exchange, coin) -> bis wann ausgelassen
        self._ctval: dict = {}                  # OKX: Kontraktwert je Coin (einmal geholt)
        self.letzter_fehler: str = ""
        con.executescript(SCHEMA)

    # -- Schreiben, sperr-tolerant --------------------------------------------
    def schreibe(self, sql: str, rows, viele: bool = True, versuche: int = 3) -> bool:
        """
        Schreiben mit kurzer Wiederholung bei gesperrter Datenbank (0,4 / 0,8 s), dann Verzicht.
        Am 14.09. standen nach einer Stunde 38 verworfene Schreibversuche -- der Recorder hält
        die Datei bei Checkpoints länger als die 5 s busy_timeout. db_retry zählt die
        Wiederholungen, db_locked nur den endgültigen Verlust.
        """
        for versuch in range(versuche):
            with self.lock:
                try:
                    (self.con.executemany if viele else self.con.execute)(sql, rows)
                    self.con.commit()
                    return True
                except sqlite3.OperationalError as e:
                    if "locked" not in str(e) and "busy" not in str(e):
                        raise
                    try:
                        self.con.rollback()
                    except sqlite3.Error:
                        pass
            if versuch < versuche - 1:
                self.stats["db_retry"] += 1
                time.sleep(0.4 * (versuch + 1))
        self.stats["db_locked"] += 1
        return False

    def gesperrt(self, exchange: str, coin: str) -> bool:
        return self.ungelistet.get((exchange, coin), 0) > time.time()

    def sperren(self, exchange: str, coin: str) -> None:
        self.ungelistet[(exchange, coin)] = time.time() + SPERRE_UNGELISTET
        self.stats["ungelistet"] += 1

    def fehler(self, wo: str, was: str) -> None:
        self.stats["fehler"] += 1
        self.letzter_fehler = f"{wo}: {was}"[:200]

    # -----------------------------------------------------------------------
    # Kennzahlen je Börse -> {metric: value}; None = nicht gelistet / Fehler
    # -----------------------------------------------------------------------

    def bybit_metrics(self, coin: str) -> dict | None:
        sym = f"{coin}USDT"
        d, err = http(f"{BYBIT}/tickers?category=linear&symbol={sym}")
        if err:
            self.fehler("bybit tickers", err); return None
        lst = ((d or {}).get("result") or {}).get("list") or []
        rc = (d or {}).get("retCode")
        if rc == 10001 or (rc == 0 and not lst):          # "params error" = Symbol unbekannt -> ein Tag Sperre
            self.sperren("bybit", coin); return None
        if rc != 0 or not lst:                             # anderes (Ratenlimit, Wartung): zählen, nicht sperren
            self.fehler("bybit tickers", f"retCode {rc}: {(d or {}).get('retMsg')}"); return None
        t = lst[0]
        out = {"last": _f(t.get("lastPrice")), "oi_coins": _f(t.get("openInterest")), "oi_usd": _f(t.get("openInterestValue")),
               "funding_8h": _f(t.get("fundingRate")), "turnover_24h_usd": _f(t.get("turnover24h"))}
        time.sleep(PAUSE)
        d, err = http(f"{BYBIT}/recent-trade?category=linear&symbol={sym}&limit=500")
        tr = ((d or {}).get("result") or {}).get("list") or [] if not err else []
        if tr:
            buy = sum(_f(x.get("size")) for x in tr if str(x.get("side", "")).lower() == "buy")
            sell = sum(_f(x.get("size")) for x in tr if str(x.get("side", "")).lower() == "sell")
            ts_ = [_f(x.get("time")) for x in tr if x.get("time")]
            if sell > 0:
                out["taker_ls"] = buy / sell
            out["taker_span_s"] = (max(ts_) - min(ts_)) / 1000 if len(ts_) > 1 else 0.0
            out["taker_n"] = float(len(tr))
        elif err:
            self.fehler("bybit recent-trade", err)
        time.sleep(PAUSE)
        d, err = http(f"{BYBIT}/account-ratio?category=linear&symbol={sym}&period=5min&limit=1")
        r = (((d or {}).get("result") or {}).get("list") or [{}])[0] if not err else {}
        if r and _f(r.get("sellRatio")) > 0:
            out["ls_account"] = _f(r.get("buyRatio")) / _f(r.get("sellRatio"))
        return out

    def okx_metrics(self, coin: str) -> dict | None:
        inst = f"{coin}-USDT-SWAP"
        d, err = http(f"{OKX}/market/ticker?instId={inst}")
        if err:
            self.fehler("okx ticker", err); return None
        if str((d or {}).get("code")) == "51001" or not (d or {}).get("data"):
            self.sperren("okx", coin); return None
        t = d["data"][0]
        out = {"last": _f(t.get("last")), "vol_24h_coins": _f(t.get("volCcy24h"))}
        time.sleep(PAUSE)
        d, err = http(f"{OKX}/public/funding-rate?instId={inst}")
        if not err and (d or {}).get("data"):
            out["funding_8h"] = _f(d["data"][0].get("fundingRate"))
        time.sleep(PAUSE)
        d, err = http(f"{OKX}/public/open-interest?instType=SWAP&instId={inst}")
        if not err and (d or {}).get("data"):
            out["oi_coins"] = _f(d["data"][0].get("oiCcy"))
            if d["data"][0].get("oiUsd"):
                out["oi_usd"] = _f(d["data"][0].get("oiUsd"))
        time.sleep(PAUSE)
        # rubik: 5-min-Buckets [ts, sellVol, buyVol] bzw. [ts, ratio]; der jüngste Bucket zählt
        d, err = http(f"{OKX}/rubik/stat/taker-volume?ccy={coin}&instType=CONTRACTS&period=5m")
        tv = (d or {}).get("data") or [] if not err else []
        if tv and len(tv[0]) >= 3:
            sell, buy = _f(tv[0][1]), _f(tv[0][2])
            if sell > 0:
                out["taker_ls"] = buy / sell
            out["taker_span_s"] = 300.0
        time.sleep(PAUSE)
        d, err = http(f"{OKX}/rubik/stat/contracts/long-short-account-ratio?ccy={coin}&period=5m")
        ls = (d or {}).get("data") or [] if not err else []
        if ls and len(ls[0]) >= 2:
            out["ls_account"] = _f(ls[0][1])
        return out

    def cdc_metrics(self, coin: str) -> dict | None:
        inst = f"{coin}USD-PERP"
        d, err = http(f"{CDC}get-tickers?instrument_name={inst}")
        if err and "40004" in err:
            self.sperren("cdc", coin); return None
        if err:
            self.fehler("cdc tickers", err); return None
        lst = ((d or {}).get("result") or {}).get("data") or []
        if not lst:
            self.sperren("cdc", coin); return None
        t = lst[0]
        out = {"last": _f(t.get("a")), "oi_contracts": _f(t.get("oi")), "vol_24h_usd": _f(t.get("vv"))}
        time.sleep(PAUSE)
        d, err = http(f"{CDC}get-trades?instrument_name={inst}&count=150")
        tr = ((d or {}).get("result") or {}).get("data") or [] if not err else []
        if tr:
            buy = sum(_f(x.get("q")) for x in tr if str(x.get("s", "")).upper() == "BUY")
            sell = sum(_f(x.get("q")) for x in tr if str(x.get("s", "")).upper() == "SELL")
            if sell > 0:
                out["taker_ls"] = buy / sell
            out["taker_span_s"] = (_f(tr[0].get("t")) - _f(tr[-1].get("t"))) / 1000 if len(tr) > 1 else 0.0
            out["taker_n"] = float(len(tr))
        time.sleep(PAUSE)
        d, err = http(f"{CDC}get-valuations?instrument_name={inst}&valuation_type=mark_price&count=1")
        v = (((d or {}).get("result") or {}).get("data") or [{}])[0] if not err else {}
        if v.get("v"):
            out["mark"] = _f(v.get("v"))
        return out

    def bnc_ratios(self, coin: str) -> list:
        """Binance-Verhältnisse (5-min-Raster) als bnc_metrics-Zeilen mit dem Zeitstempel der API."""
        sym = self.bnc_sym.get(coin)
        if not sym:
            return []
        rows = []
        for pfad, metric, feld in (("/futures/data/takerlongshortRatio", "taker_ls", "buySellRatio"),
                                   ("/futures/data/globalLongShortAccountRatio", "global_ls_account", "longShortRatio"),
                                   ("/futures/data/topLongShortPositionRatio", "top_ls_position", "longShortRatio"),
                                   ("/futures/data/topLongShortAccountRatio", "top_ls_account", "longShortRatio")):
            d, err = http(f"{BNC_F}{pfad}?symbol={sym}&period=5m&limit=2")
            if err or not isinstance(d, list):
                self.fehler(f"binance {metric}", err or "Form"); time.sleep(PAUSE); continue
            for r in d:
                ts = int(_f(r.get("timestamp")) // 1000)          # ms -> s
                if ts > 0:
                    rows.append((ts, coin, metric, _f(r.get(feld))))
            time.sleep(PAUSE)
        return rows

    # -----------------------------------------------------------------------
    # Binance-Orderbuch: Tiefe je Abstand und Wände je Preisstufe (wie cb_book)
    # -----------------------------------------------------------------------

    def bnc_book(self, coin: str) -> tuple | None:
        sym = self.bnc_sym.get(coin)
        if not sym:
            return None
        d, err = http(f"{BNC_F}/fapi/v1/depth?symbol={sym}&limit=500")
        if err or not isinstance(d, dict):
            self.fehler("binance depth", err or "Form"); return None
        bids = [(_f(p), _f(q)) for p, q in d.get("bids") or []]
        asks = [(_f(p), _f(q)) for p, q in d.get("asks") or []]
        if not bids or not asks:
            return None
        bid, ask = bids[0][0], asks[0][0]; mid = (bid + ask) / 2
        def tiefe(seite, bps):
            lo, hi = mid * (1 - bps / 1e4), mid * (1 + bps / 1e4)
            return sum(p * q for p, q in seite if lo <= p <= hi)
        # Wände: Preisstufen im 0,25-%-Raster (bucket_px wie im Dashboard), ab 2 % der Tiefe
        # innerhalb 100 bps und mindestens 100.000 USD
        min_wand = max(100_000.0, (tiefe(bids, 100) + tiefe(asks, 100)) * 0.02)
        stufen: dict = {}
        step = math.log(1.0025)
        for kind, seite in (("limit_buy", bids), ("limit_sell", asks)):
            for p, q in seite:
                if abs(p / mid - 1) > 0.30:
                    continue
                b = round(math.exp(round(math.log(p) / step) * step), 6)
                s = stufen.setdefault((kind, b), {"kind": kind, "px": b, "notional": 0.0, "n": 0})
                s["notional"] += p * q; s["n"] += 1
        walls = sorted([s for s in stufen.values() if s["notional"] >= min_wand], key=lambda s: -s["notional"])[:25]
        return (int(time.time()), coin, bid, ask, mid, tiefe(bids, 5), tiefe(asks, 5), tiefe(bids, 25), tiefe(asks, 25),
                tiefe(bids, 100), tiefe(asks, 100), json.dumps(walls))

    # -----------------------------------------------------------------------
    # Liquidationen: OKX (REST) und Bybit (WebSocket)
    # -----------------------------------------------------------------------

    def okx_ctval(self, coin: str) -> float:
        d, err = http(f"{OKX}/public/instruments?instType=SWAP&instId={coin}-USDT-SWAP")
        if err or not (d or {}).get("data"):
            return 0.0
        return _f(d["data"][0].get("ctVal"))

    def okx_liquidations(self, coin: str, ctval: float) -> list:
        """Die jüngsten 100 gefüllten Liquidationen; Seite aus posSide (long/short liquidiert)."""
        d, err = http(f"{OKX}/public/liquidation-orders?instType=SWAP&uly={coin}-USDT&state=filled&limit=100")
        if err:
            self.fehler("okx liquidation-orders", err); return []
        rows = []
        for blk in (d or {}).get("data") or []:
            for x in blk.get("details") or []:
                ts = int(_f(x.get("ts")) // 1000)
                pos = str(x.get("posSide", "")).lower()
                side = "long" if pos == "long" else "short" if pos == "short" else ("long" if str(x.get("side", "")).lower() == "sell" else "short")
                px = _f(x.get("bkPx")); sz = _f(x.get("sz")) * (ctval or 0.0)      # Kontrakte -> Coins
                if ts <= 0 or px <= 0 or sz <= 0:
                    continue
                uid = hashlib.blake2b(f"{coin}|{ts}|{side}|{px}|{sz}".encode(), digest_size=8).hexdigest()
                rows.append((ts, "okx", coin, side, px, sz, px * sz, uid))
        return rows

    def bybit_liq_rows(self, msg: dict) -> list:
        """allLiquidation-Nachricht -> Zeilen. S = Seite der LIQUIDIERTEN Position (Buy = Long)."""
        topic = str(msg.get("topic", ""))
        if not topic.startswith("allLiquidation."):
            return []
        sym = topic.split(".", 1)[1]; coin = sym[:-4] if sym.endswith("USDT") else sym
        data = msg.get("data")
        if isinstance(data, dict):
            data = [data]
        rows = []
        for x in data or []:
            ts = int(_f(x.get("T")) // 1000)
            side = "long" if str(x.get("S", "")).lower() == "buy" else "short"
            px, sz = _f(x.get("p")), _f(x.get("v"))
            if ts <= 0 or px <= 0 or sz <= 0:
                continue
            uid = hashlib.blake2b(f"{sym}|{x.get('T')}|{side}|{px}|{sz}".encode(), digest_size=8).hexdigest()
            rows.append((ts, "bybit", coin, side, px, sz, px * sz, uid))
        return rows

    # -----------------------------------------------------------------------
    # ETF-Flüsse (Farside): eine Zeile je Tag
    # -----------------------------------------------------------------------

    def etf_farside(self, coin: str) -> list:
        html, err = http(f"{FARSIDE}{coin.lower()}/", timeout=25, text=True)
        if err:
            self.fehler("farside", err); return []
        months = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}
        rows = []; now = int(time.time())
        for row in re.findall(r"<tr[^>]*>(.*?)</tr>", html, re.S):
            cells = [re.sub(r"<[^>]+>", "", c).replace("&nbsp;", " ").strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)]
            if len(cells) < 3:
                continue
            m = re.match(r"(\d{1,2}) (\w{3}) (\d{4})", cells[0])
            if not m or m.group(2) not in months:
                continue
            tot = cells[-1].replace(",", "")
            if tot in ("-", ""):
                val = 0.0
            else:
                neg = tot.startswith("(")
                val = _f(tot.strip("()"), 0.0) * (-1 if neg else 1)
            rows.append((f"{m.group(3)}-{months[m.group(2)]:02d}-{int(m.group(1)):02d}", coin, val, now))
        return rows

    # -----------------------------------------------------------------------
    # Ein Durchlauf je Aufgabe (synchron; der Dienst ruft sie per to_thread auf)
    # -----------------------------------------------------------------------

    def lauf_metrics(self) -> int:
        ts = int(time.time()) // 300 * 300
        rows = []; bnc_rows = []
        for coin in self.coins:
            for ex, fn in (("bybit", self.bybit_metrics), ("okx", self.okx_metrics), ("cdc", self.cdc_metrics)):
                if self.gesperrt(ex, coin):
                    continue
                try:
                    m = fn(coin)
                except Exception as e:                         # eine Börse darf die anderen nicht anhalten
                    self.fehler(ex, f"{type(e).__name__}: {e}"); m = None
                for k, v in (m or {}).items():
                    if v is not None and math.isfinite(v):
                        rows.append((ts, ex, coin, k, float(v)))
                time.sleep(PAUSE)
            try:
                bnc_rows.extend(self.bnc_ratios(coin))
            except Exception as e:
                self.fehler("binance ratios", f"{type(e).__name__}: {e}")
        n = 0
        if rows and self.schreibe("INSERT OR REPLACE INTO ext_metrics VALUES (?,?,?,?,?)", rows):
            n += len(rows)
        if bnc_rows and self.schreibe("INSERT OR REPLACE INTO bnc_metrics VALUES (?,?,?,?)", bnc_rows):
            n += len(bnc_rows)
        self.stats["metrics_rows"] += n
        return n

    def lauf_book(self) -> int:
        rows = []
        for coin in self.coins:
            try:
                r = self.bnc_book(coin)
            except Exception as e:
                self.fehler("binance book", f"{type(e).__name__}: {e}"); r = None
            if r:
                rows.append(r)
            time.sleep(PAUSE)
        if rows and self.schreibe("INSERT OR REPLACE INTO bnc_book VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows):
            self.stats["book_rows"] += len(rows); return len(rows)
        return 0

    def lauf_okx_liq(self) -> int:
        rows = []
        for coin in self.coins:
            if self.gesperrt("okx", coin):
                continue
            ct = self._ctval.get(coin)
            if ct is None:
                ct = self.okx_ctval(coin); self._ctval[coin] = ct; time.sleep(PAUSE)
            if not ct:
                continue
            try:
                rows.extend(self.okx_liquidations(coin, ct))
            except Exception as e:
                self.fehler("okx liq", f"{type(e).__name__}: {e}")
            time.sleep(PAUSE)
        return self.liq_schreiben(rows)

    def liq_schreiben(self, rows: list) -> int:
        rows = self.liq_rest + list(rows)               # zurückgehaltene Zeilen der letzten Sperre mitnehmen
        self.liq_rest = []
        if not rows:
            return 0
        try:
            with self.lock:
                vorher = self.con.total_changes
            if self.schreibe("INSERT OR IGNORE INTO ext_liquidations VALUES (?,?,?,?,?,?,?,?)", rows, versuche=2):
                with self.lock:
                    neu = self.con.total_changes - vorher
                self.stats["liq_rows"] += neu; return neu
            self.liq_rest = rows[-2000:]                # bei Sperre behalten (höchstens 2.000), nächster Flush holt nach
        except sqlite3.Error as e:
            self.fehler("ext_liquidations", str(e))
        return 0

    def lauf_etf(self) -> int:
        rows = []
        for coin in ("BTC", "ETH"):
            if coin in self.coins:
                rows.extend(self.etf_farside(coin)); time.sleep(PAUSE)
        if rows and self.schreibe("INSERT OR REPLACE INTO etf_flows VALUES (?,?,?,?)", rows):
            self.stats["etf_rows"] += len(rows); return len(rows)
        return 0

    def aufraeumen(self) -> None:
        cut = int(time.time()) - VORHALT_TAGE * 86_400
        for t in ("ext_metrics", "ext_liquidations"):
            self.schreibe(f"DELETE FROM {t} WHERE ts < ?", (cut,), viele=False)
        self.schreibe("DELETE FROM bnc_book WHERE ts < ?", (int(time.time()) - 60 * 86_400,), viele=False)   # Wände sind die größten Zeilen

    # -----------------------------------------------------------------------
    # Bybit-Liquidations-Stream (asynchron, eigene Verbindung, Ping alle 20 s)
    # -----------------------------------------------------------------------

    async def bybit_ws(self, stop: asyncio.Event) -> None:
        try:
            import websockets
        except ImportError as e:
            self.fehler("bybit ws", f"websockets fehlt: {e}")
            print(f"  Bybit-Stream: Paket websockets fehlt ({e}) -- Stream bleibt aus", flush=True)
            return
        wartezeit = 1
        topics = [f"allLiquidation.{c}USDT" for c in self.coins if not self.gesperrt("bybit", c)]
        while not stop.is_set():
            try:
                async with websockets.connect(BYBIT_WS, ping_interval=None, open_timeout=15) as ws:
                    # je Thema ein Abonnement: ein einziges ungültiges Thema würde sonst die ganze
                    # Anfrage ablehnen, und alle Coins blieben stumm
                    for t in topics:
                        await ws.send(json.dumps({"op": "subscribe", "args": [t]}))
                        await asyncio.sleep(0.2)
                    verbunden_seit = time.time(); letzter_ping = time.time(); puffer = []; letzter_flush = time.time()
                    while not stop.is_set():
                        if time.time() - letzter_ping > 20:
                            await ws.send(json.dumps({"op": "ping"})); letzter_ping = time.time()
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=5)
                        except asyncio.TimeoutError:
                            # Sammeln statt sofort schreiben: höchstens ein Schreibvorgang je Minute.
                            # Jede Transaktion mehr ist eine Sperre mehr für den Recorder.
                            if puffer and time.time() - letzter_flush > 60:
                                self.liq_schreiben(puffer); puffer = []; letzter_flush = time.time()
                            continue
                        msg = json.loads(raw)
                        if msg.get("op") in ("ping", "pong", "subscribe") or msg.get("success") is not None and "topic" not in msg:
                            if msg.get("success") is False:
                                self.fehler("bybit ws subscribe", str(msg)[:120])
                            continue
                        rows = self.bybit_liq_rows(msg)
                        if rows:
                            self.stats["bybit_ws_events"] += len(rows); puffer.extend(rows)
                        if len(puffer) >= 200 or (puffer and time.time() - letzter_flush > 60):
                            self.liq_schreiben(puffer); puffer = []; letzter_flush = time.time()
                        if wartezeit > 1 and time.time() - verbunden_seit > 60:
                            wartezeit = 1
                    if puffer:                                   # beim Beenden nichts liegen lassen
                        self.liq_schreiben(puffer); puffer = []
            except Exception as e:
                if stop.is_set():
                    return
                self.stats["bybit_ws_reconnects"] += 1
                self.fehler("bybit ws", f"{type(e).__name__}: {e}")
                print(f"  Bybit-Stream: {type(e).__name__}: {e} -- neuer Versuch in {wartezeit} s", flush=True)
                for _ in range(int(wartezeit)):
                    if stop.is_set():
                        return
                    await asyncio.sleep(1)
                wartezeit = min(wartezeit * 2, 60)


# ---------------------------------------------------------------------------
# Betrieb: die Schleifen, die der Binance-Dienst startet
# ---------------------------------------------------------------------------

async def betreiben(db_path: str, coins: list, bnc_sym: dict, stop: asyncio.Event,
                    stats_sink=None) -> None:
    """
    Alle Sammler nebeneinander: Kennzahlen alle 5 min, Binance-Buch alle 5 min, OKX-
    Liquidationen alle 2 min, ETF-Flüsse alle 6 h, Bybit-Stream dauernd, Aufräumen täglich.
    Die synchronen Abrufe laufen in Threads (asyncio.to_thread), damit sie die Ereignisschleife
    des Dienstes nicht anhalten. stats_sink(dict) bekommt nach jedem Lauf die Zähler.
    """
    con = verbinden(db_path)
    s = Sammler(con, coins, bnc_sym)

    async def warten(sek: float) -> None:
        """Schlafen, aber jede Sekunde auf das Stop-Signal hören -- sonst hängt der Dienst beim Beenden."""
        ende = time.time() + sek
        while time.time() < ende and not stop.is_set():
            await asyncio.sleep(min(1.0, max(0.0, ende - time.time())))

    async def takt(name, fn, sekunden, versatz=0):
        await warten(versatz)
        while not stop.is_set():
            t0 = time.time()
            try:
                n = await asyncio.to_thread(fn)
                if stats_sink:
                    stats_sink({"ext_" + k: int(v) for k, v in s.stats.items()})     # nur Zähler (bnc_stats erwartet Ganzzahlen)
                if name == "Kennzahlen":                                              # Stempel nur alle 5 min, in EINER Transaktion
                    try:
                        s.schreibe("INSERT OR REPLACE INTO meta VALUES (?,?)",
                                   [("ext_letzter_fehler", s.letzter_fehler), ("ext_alive", str(int(time.time())))])
                    except sqlite3.Error:
                        pass
                print(f"[{time.strftime('%H:%M:%S')}] Fremdbörsen {name}: {n} Zeilen in {time.time() - t0:.1f} s", flush=True)
            except Exception as e:
                print(f"  Fremdbörsen {name}: {type(e).__name__}: {e}", flush=True)
            await warten(max(1.0, sekunden - (time.time() - t0)))

    # return_exceptions: Stirbt eine Schleife unerwartet, laufen die anderen weiter und werden
    # beim Neustart durch run_ext nicht verdoppelt (die takt-Schleifen fangen ohnehin alles ab).
    ergebnisse = await asyncio.gather(
        takt("Kennzahlen", s.lauf_metrics, 300, 15),
        takt("Binance-Buch", s.lauf_book, 300, 45),
        takt("OKX-Liquidationen", s.lauf_okx_liq, 120, 30),
        takt("ETF-Flüsse", s.lauf_etf, 6 * 3600, 60),
        takt("Aufräumen", lambda: (s.aufraeumen(), 0)[1], 86_400, 600),
        s.bybit_ws(stop),
        return_exceptions=True,
    )
    for r in ergebnisse:
        if isinstance(r, Exception):
            print(f"  Fremdbörsen: Schleife beendet mit {type(r).__name__}: {r}", flush=True)
    try:
        con.close()
    except sqlite3.Error:
        pass


if __name__ == "__main__":
    # Selbsttest ohne Netz: Parser und Seitenlogik gegen dokumentierte Beispielnachrichten
    con = sqlite3.connect(":memory:")
    s = Sammler(con, ["BTC", "ETH"], {"BTC": "BTCUSDT"})
    # Bybit allLiquidation (Doku: S = Seite der liquidierten Position, Buy = Long)
    msg = {"topic": "allLiquidation.BTCUSDT", "type": "snapshot", "ts": 1739502303204,
           "data": [{"T": 1739502302929, "s": "BTCUSDT", "S": "Buy", "v": "0.5", "p": "95000.5"},
                    {"T": 1739502302930, "s": "BTCUSDT", "S": "Sell", "v": "0.2", "p": "95100"}]}
    rows = s.bybit_liq_rows(msg)
    assert [r[3] for r in rows] == ["long", "short"], rows
    assert rows[0][0] == 1739502302 and rows[0][2] == "BTC" and abs(rows[0][6] - 47500.25) < 1e-6
    print("  ok  Bybit allLiquidation: Buy -> long liquidiert, Sell -> short, ts in s, Notional USD")
    n = s.liq_schreiben(rows); n2 = s.liq_schreiben(rows)
    assert n == 2 and n2 == 0, (n, n2)
    print("  ok  ext_liquidations: Duplikate werden ignoriert (uid)")
    # OKX liquidation-orders: posSide hat Vorrang, sonst side (sell = long liquidiert), sz in Kontrakten x ctVal
    class _H:
        pass
    okx = {"data": [{"details": [{"posSide": "long", "side": "sell", "sz": "10", "bkPx": "60000", "ts": "1739502302929"},
                                 {"posSide": "net", "side": "buy", "sz": "5", "bkPx": "60500", "ts": "1739502302930"}]}]}
    import types
    s_http = http
    globals()["http"] = lambda url, timeout=15, text=False: (okx, None)
    rows = s.okx_liquidations("BTC", 0.01)
    globals()["http"] = s_http
    assert [r[3] for r in rows] == ["long", "short"] and abs(rows[0][5] - 0.1) < 1e-9 and abs(rows[0][6] - 6000) < 1e-6, rows
    print("  ok  OKX liquidation-orders: posSide/side -> long/short, Kontrakte x ctVal -> Coins, Notional USD")
    # Binance-Buch: Wände im 0,25-%-Raster, Notional in USD
    globals()["http"] = lambda url, timeout=15, text=False: ({"bids": [["60000", "1"], ["59900", "40"], ["59000", "2"]], "asks": [["60010", "1"], ["60100", "35"]]}, None)
    r = s.bnc_book("BTC")
    globals()["http"] = s_http
    walls = json.loads(r[-1])
    assert r[1] == "BTC" and r[2] == 60000 and r[3] == 60010 and r[9] > 0 and any(w["kind"] == "limit_buy" for w in walls), (r[:5], walls)
    print(f"  ok  Binance-Buch: bid/ask/mid, Tiefe je Abstand, {len(walls)} Wände (USD, 0,25-%-Raster)")
    # Farside-Parser
    html = "<table><tr><td>12 Sep 2026</td><td>1.0</td><td>(123.4)</td></tr><tr><td>11 Sep 2026</td><td>2</td><td>56.7</td></tr></table>"
    globals()["http"] = lambda url, timeout=15, text=False: (html, None)
    rows = s.etf_farside("BTC")
    globals()["http"] = s_http
    assert sorted(rows)[0][0] == "2026-09-11" and rows[0][2] == -123.4 and rows[1][2] == 56.7, rows
    print("  ok  Farside: Datum -> ISO, Klammern -> negativ, Mio USD")
    # Einheiten-Invariante: alle ts in Sekunden
    con.executemany("INSERT OR REPLACE INTO ext_metrics VALUES (?,?,?,?,?)", [(int(time.time()) // 300 * 300, "bybit", "BTC", "last", 60000.0)])
    for t in ("ext_metrics", "ext_liquidations"):
        mx = con.execute(f"SELECT MAX(ts) FROM {t}").fetchone()[0]
        assert mx is None or mx < 1e11, (t, mx)
    print("  ok  Zeitstempel in Sekunden (Audit-Invariante)")
    print("Alles in Ordnung.")
