#!/usr/bin/env python3
"""
hl_staking_studie.py -- Unstaking: Folgt auf große Abzüge ein Kursrückgang? (U255, KONZEPT_Unstaking.md 6 und 6a; Paket 23.101)

Anlass (Nutzer, 14.11.2026): „wenn sehr große Mengen Ethereum vom Staking abgerufen werden, [kommt] es häufig zu signifikanten
Kursrückgängen“. Das Modul prüft diese Beobachtung mit Regeln, die am 14.11.2026 festgelegt wurden, BEVOR die Schlange der Abzüge
mit Kursen zusammengeführt wurde. Es rechnet einmal, speichert das Urteil und rechnet nicht still neu.

Daten:   Schlange der Abzüge je UTC-Tag (staking.db, Tabelle st_tag = Tagesdatei von validatorqueue.com, erste Messung des Tages);
         Kurse von ETH und BTC zu Beginn jedes UTC-Tags aus den 30-min-Kerzen des Swing-Moduls (swing.db, sw_klines).
Fall A:  Tag, an dem die Schlange gegen den Vortag um mindestens 57.600 ETH gewachsen ist; neuer Fall erst nach 14 Tagen ohne
         solchen Tag.
Fall B:  erster UTC-Tag, der beginnt, nachdem das erste ETH der Welle frei geworden ist (Vortag + Wartezeit des Vortags + 27,3 h).
Ziel:    Log-Rendite von ETH minus der von BTC über 7 Tage ab Beginn des Falltags.
Test:    Mittel nach den Fällen minus Mittel über alle Tage, einseitig (niedriger); Nullverteilung durch Verschieben der Fallreihe
         gegen die Kursreihe im Kreis (alle Verschiebungen um mindestens 30 Tage); Holm über A und B.
Urteil:  „belegt“ nur mit p (Holm) < 0,05, mindestens 8 Fällen und negativem Unterschied in beiden Hälften der Fälle.
Proben:  Nullprobe (zufällig gelegte Fälle gleicher Zahl) und Fundquote für eingebaute Nachteile (Nachweisgrenze).

Nur lesen (swing.db) und ein Eintrag in staking.db (st_meta „studie_u255“). Wirkt auf nichts anderes: keine Lampe, keine Prognose.

Aufruf:  hl_staking_studie.py --bericht [--db hl_liq.db] [--ohne-abruf]     Text für Debug 147
         hl_staking_studie.py --selbsttest                                   ohne Netz
"""
import argparse
import calendar
import hashlib
import json
import math
import os
import re
import sqlite3
import sys
import time
import urllib.parse

import numpy as np

import hl_staking as ST

VERSION_MODUL = "2026-09-23.102"
NAME = "Unstaking: Prüfung der Kursfolge (U255)"
REGEL = "U255/1"                                # Fassung der vorab festgelegten Regeln; eine andere Fassung rechnet neu und legt die alte ab
FESTGELEGT = "14.11.2026"
SCHLUESSEL = "studie_u255"
TAG = 86_400
BAR = 1_800                                     # 30-min-Kerzen des Swing-Moduls

# ---- Regeln, fest und vorab (KONZEPT_Unstaking.md 6; Klarstellungen vor dem ersten Lauf in 6a)
SCHWELLE_ETH = ST.DURCHSATZ_TAG                 # Fall A: Zuwachs der Schlange gegen den Vortag ab 57.600 ETH (ein voller Tagesdurchsatz)
RUHE_TAGE = 14                                  # ein neuer Fall beginnt erst nach 14 Tagen ohne solchen Tag
HORIZONT = 7                                    # Zielgröße: 7 Tage ab Beginn des Falltags
HORIZONT_LANG = 14                              # nur beschreibend
MIN_VERSCHIEBUNG = 30                           # Kreistest: alle Verschiebungen um mindestens 30 Tage
MIN_FAELLE = 8
ALPHA = 0.05
MIN_TAGE = 365                                  # darunter wird nicht gerechnet (zu kurze Reihe für die Nullverteilung)
ABDECKUNG_MIN = 0.98                            # Anteil der Tage mit Kursen; darunter wird nicht gerechnet
NULL_LAEUFE = 2_000
NULL_GRENZE = 0.05                              # „in höchstens 5 % der Läufe“ -- dazu drei Standardfehler der Simulation (null_erlaubt)
KONTROLLE_LAEUFE = 400
KONTROLLE_STUFEN = tuple(round(0.005 * i, 3) for i in range(1, 41))     # eingebauter Nachteil 0,5 % … 20 %
KONTROLLE_NENNWERT = 0.03                       # „ein eingebauter Nachteil von 3 %“
FUNDQUOTE = 0.80                                # Nachweisgrenze: kleinster Nachteil, der in 80 % der Läufe gefunden wird
NEUE_WELLEN = 5                                 # neue Prüfung frühestens nach fünf weiteren Wellen
ANLASS = ("2026-11-01", "2026-11-14")           # Wellen mit Falltag A in dieser Zeit gaben den Anlass (Beobachtung des Nutzers am 14.11.2026):
                                                # Das Urteil zählt sie nach der Regel mit; daneben steht eine Gegenprobe ohne sie.
SAAT = 255
WARTE_MAX = 400.0                               # Wartezeiten darüber gelten als nicht lesbar
TIEF_MIN_KERZEN = 40                            # Tagestief nur aus einem (fast) vollständigen Tag
PECTRA_AB = "2025-05-22"                        # nur Bericht (23.102): erster verlässlicher Tag der Tagesdatei nach Pectra (wie hl_staking)
STEHT_AB_TAGEN = 3                              # nur Bericht (23.102): liegt der letzte Tag der Schlange so weit zurück, gilt die Tagesdatei
                                                # der Quelle als stehengeblieben -- der Bericht sagt es dann beim Urteil


# ================================================================================================ kleine Helfer

def tag_nr(tag: str) -> int:
    """„2026-11-14“ -> Tage seit dem 01.01.1970 (UTC)."""
    return calendar.timegm(time.strptime(tag, "%Y-%m-%d")) // TAG


def iso(D: int) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(int(D) * TAG))


def datum(D) -> str:
    if D is None:
        return "—"
    return time.strftime("%d.%m.%Y", time.gmtime(int(D) * TAG))


def _pz(x, nd: int = 2, vz: bool = True) -> str:
    """Log-Rendite als Prozentzahl mit Vorzeichen (ohne das Zeichen %)."""
    if x is None:
        return "·"
    s = ST._de(x * 100.0, nd)
    return ("+" + s) if vz and x > 0 and s.strip("0,") else s


def _p(x) -> str:
    return "—" if x is None else ST._de(x, 3)


U0, U1 = tag_nr(ST.TAGESDATEI_UNSICHER[0]), tag_nr(ST.TAGESDATEI_UNSICHER[1])


def swing_pfad(db: str) -> str:
    """Wie hl_swing.swing_pfad (der Selbsttest prüft die Gleichheit) -- hier ohne den Import des ganzen Swing-Moduls."""
    p = os.environ.get("HL_SWING_DB")
    if p:
        return p
    return os.path.join(os.path.dirname(os.path.abspath(db)), "swing.db")


# ================================================================================================ Daten lesen

def schlange_lesen(p: str) -> dict:
    """Schlange der Abzüge je UTC-Tag aus staking.db. Ausgeschlossen: 07.05.–21.05.2025 (laut Quelle falsche Einheit), Tage ohne Wert."""
    out = {"ok": False, "fehlt": [], "Q": {}, "W": {}, "ausgeschlossen": 0}
    con = ST.lesen(p)
    if con is None:
        out["fehlt"].append("staking.db fehlt noch (das Dashboard lädt die Tagesdatei rund 90 s nach seinem Start).")
        return out
    try:
        tage = ST.tage_lesen(con)
    finally:
        con.close()
    for t in tage:
        D = int(t["ts"]) // TAG
        q = ST._zahl(t.get("exit_eth"))
        if U0 <= D <= U1:
            out["ausgeschlossen"] += 1
            continue
        if q is None or q < 0 or q > 60e6:
            continue
        out["Q"][D] = float(q)
        w = ST._zahl(t.get("exit_tage"))
        out["W"][D] = float(w) if w is not None and 0 <= w <= WARTE_MAX else None
    if not out["Q"]:
        out["fehlt"].append("Die Tagesdatei der Warteschlangen ist noch nicht geladen (staking.db ohne Tageswerte).")
        return out
    out["von_D"], out["bis_D"] = min(out["Q"]), max(out["Q"])
    out["n"] = len(out["Q"])
    im_bereich = sum(1 for D in range(U0, U1 + 1) if out["von_D"] <= D <= out["bis_D"])
    out["fehlen"] = (out["bis_D"] - out["von_D"] + 1) - out["n"] - im_bereich
    out["ausgeschlossen_im_bereich"] = im_bereich
    out["ok"] = True
    return out


def faelle_bestimmen(Q: dict, W: dict) -> dict:
    """
    Fall A: Tag D mit Q[D] − Q[D−1] ≥ SCHWELLE_ETH (beide Tage gemessen); ein neuer Fall beginnt erst, wenn der letzte solche Tag mehr
    als RUHE_TAGE zurückliegt. Fall B: (D − 1) + aufgerundet(Wartezeit des Vortags + Sperrfrist) -- der erste UTC-Tag, der beginnt,
    nachdem das erste ETH der Welle frei geworden ist. Ohne Wartezeit des Vortags gibt es keinen Fall B.
    """
    ausloeser = [D for D in sorted(Q) if (D - 1) in Q and Q[D] - Q[D - 1] >= SCHWELLE_ETH]
    faelle = []
    letzter = None
    for D in ausloeser:
        if letzter is None or D - letzter > RUHE_TAGE:
            w = W.get(D - 1)
            faelle.append({"a": D, "zuwachs": Q[D] - Q[D - 1], "schlange": Q[D], "warte_vortag": w, "ausloeser": 1,
                           "b": (D - 1) + int(math.ceil(w + ST.SPERR_S / TAG)) if w is not None else None,
                           # Vorlauf mit Lücke: an einem der 14 Tage davor ließ sich der Zuwachs nicht bestimmen (Tag oder Vortag fehlt)
                           "luecke": any((d not in Q) or ((d - 1) not in Q) for d in range(D - RUHE_TAGE, D))})
        else:
            faelle[-1]["ausloeser"] += 1
        letzter = D
    for i, f in enumerate(faelle, 1):
        f["nr"] = i
    return {"ausloeser": ausloeser, "faelle": faelle}


def kurse_lesen(p: str, von_D: int, bis_D: int) -> dict:
    """
    Kurs zu Beginn jedes UTC-Tags = Schluss der letzten 30-min-Kerze des Vortags (ersatzweise Eröffnung der ersten Kerze des Tags);
    dazu das Tagestief von ETH. Nur lesen.
    """
    out = {"ok": False, "fehlt": [], "eth": {}, "btc": {}, "tief": {}, "ersatz": 0, "bis_D": None}
    if not p or not os.path.exists(p):
        out["fehlt"].append("swing.db fehlt (30-min-Kerzen des Swing-Moduls) -- ohne Kurse keine Prüfung.")
        return out
    try:
        con = sqlite3.connect("file:" + urllib.parse.quote(os.path.abspath(p)) + "?mode=ro", uri=True, timeout=30)
        try:
            con.execute("PRAGMA busy_timeout=30000")
            for coin, ziel in (("ETH", out["eth"]), ("BTC", out["btc"])):
                schluss, auf, tief, zahl = {}, {}, {}, {}
                for ts, o, c, lo in con.execute("SELECT ts, o, c, l FROM sw_klines WHERE coin=? AND ts>=? AND ts<? ORDER BY ts",
                                                (coin, von_D * TAG - BAR, (bis_D + 1) * TAG)):
                    D, r = divmod(int(ts), TAG)
                    if r == TAG - BAR and c is not None and c > 0:
                        schluss[D + 1] = float(c)
                    elif r == 0 and o is not None and o > 0:
                        auf[D] = float(o)
                    if coin == "ETH" and lo is not None and lo > 0:
                        tief[D] = min(tief.get(D, float(lo)), float(lo)); zahl[D] = zahl.get(D, 0) + 1
                for D in set(schluss) | set(auf):
                    if D in schluss:
                        ziel[D] = schluss[D]
                    else:
                        ziel[D] = auf[D]; out["ersatz"] += 1
                if coin == "ETH":
                    out["tief"] = {D: v for D, v in tief.items() if zahl.get(D, 0) >= TIEF_MIN_KERZEN}
        finally:
            con.close()
    except sqlite3.Error as e:
        out["fehlt"].append(f"swing.db nicht lesbar ({type(e).__name__}: {e})"[:200])
        return out
    gemeinsam = set(out["eth"]) & set(out["btc"])
    if not gemeinsam:
        out["fehlt"].append("swing.db enthält für diese Zeit keine Kerzen von ETH und BTC.")
        return out
    out["bis_D"] = max(gemeinsam)
    out["ok"] = True
    return out


def zielgroessen(K: dict, von_D: int, bis_D: int) -> dict:
    """Je Tag D: y7 = ETH gegen BTC über 7 Tage (Zielgröße); eth7, y14 und tief7 nur beschreibend."""
    E, B, T = K["eth"], K["btc"], K["tief"]
    Z = {"y7": {}, "eth7": {}, "y14": {}, "tief7": {}}
    for D in range(von_D, bis_D + 1):
        if D not in E or D not in B:
            continue
        if D + HORIZONT in E and D + HORIZONT in B:
            Z["eth7"][D] = math.log(E[D + HORIZONT] / E[D])
            Z["y7"][D] = Z["eth7"][D] - math.log(B[D + HORIZONT] / B[D])
            if all((D + i) in T for i in range(HORIZONT)):
                Z["tief7"][D] = math.log(min(T[D + i] for i in range(HORIZONT)) / E[D])
        if D + HORIZONT_LANG in E and D + HORIZONT_LANG in B:
            Z["y14"][D] = math.log(E[D + HORIZONT_LANG] / E[D]) - math.log(B[D + HORIZONT_LANG] / B[D])
    return Z


# ================================================================================================ Test und Urteil

def kreistest(y: np.ndarray, pos: np.ndarray, min_s: int = MIN_VERSCHIEBUNG) -> dict:
    """
    Mittel der Zielgröße an den Falltagen minus Mittel über alle Tage; p = Anteil der Verschiebungen der Fallreihe im Kreis (um
    mindestens min_s Tage in beide Richtungen), bei denen der Unterschied mindestens so niedrig ausfällt -- einseitig, mit der
    beobachteten Lage mitgezählt (p wird nie 0).
    """
    N = len(y)
    s = np.arange(min_s, N - min_s + 1, dtype=np.int64)
    if len(s) < 1 or len(pos) < 1:
        raise ValueError("Reihe zu kurz für den Kreistest")
    alle = float(y.mean())
    m0 = float(y[pos].mean())
    ms = y[(pos[None, :] + s[:, None]) % N].mean(axis=1)
    p = (1 + int(np.sum(ms <= m0 + 1e-12))) / (1 + len(s))
    return {"mittel": m0, "diff": m0 - alle, "p": p, "verschiebungen": int(len(s)),
            "zufall_5": float(np.quantile(ms, 0.05)) - alle, "zufall_95": float(np.quantile(ms, 0.95)) - alle}


def holm(ps: list) -> list:
    """Holm über die genannten p-Werte, in der Reihenfolge der Eingabe."""
    m = len(ps)
    out = [None] * m
    bisher = 0.0
    for rang, i in enumerate(sorted(range(m), key=lambda j: ps[j])):
        bisher = max(bisher, min(1.0, ps[i] * (m - rang)))
        out[i] = bisher
    return out


def urteil_je(n: int, p_holm, diff, h, alpha: float = ALPHA) -> str:
    if n < MIN_FAELLE:
        return "zu wenige Fälle"
    if p_holm is not None and p_holm < alpha and diff is not None and diff < 0 and h and h[0] < 0 and h[1] < 0:
        return "belegt"
    return "nicht belegt"


def gesamt_urteil(a: str, b: str) -> str:
    if "belegt" in (a, b):
        return "belegt"
    if a == b == "zu wenige Fälle":
        return "zu wenige Fälle"
    return "nicht belegt"


def pruefen(y: np.ndarray, pos_a, pos_b, alpha: float = ALPHA, min_s: int = MIN_VERSCHIEBUNG) -> dict:
    """Das ganze Verfahren für eine Lage der Fälle: beide Fragen, Holm (immer über zwei), Hälften, Urteil je Frage und gesamt."""
    alle = float(y.mean())
    H = {}
    for name, pos in (("A", pos_a), ("B", pos_b)):
        pos = np.asarray(sorted({int(x) for x in pos}), dtype=np.int64)
        e = {"n": int(len(pos)), "mittel": None, "diff": None, "p": None, "p_holm": None, "haelften": None, "negativ": None}
        if len(pos):
            e["mittel"] = float(y[pos].mean()); e["diff"] = e["mittel"] - alle; e["negativ"] = int(np.sum(y[pos] < 0))
        if len(pos) >= MIN_FAELLE:
            e.update(kreistest(y, pos, min_s))
            k = len(pos) // 2
            e["haelften"] = [float(y[pos[:k]].mean()) - alle, float(y[pos[k:]].mean()) - alle]
        H[name] = e
    for name, a in zip(("A", "B"), holm([H[k]["p"] if H[k]["p"] is not None else 1.0 for k in ("A", "B")])):
        e = H[name]
        e["p_holm"] = a if e["p"] is not None else None
        e["urteil"] = urteil_je(e["n"], e["p_holm"], e["diff"], e["haelften"], alpha)
    return {"A": H["A"], "B": H["B"], "alle": alle, "urteil": gesamt_urteil(H["A"]["urteil"], H["B"]["urteil"])}


# ================================================================================================ Proben: Nullprobe und Fundquote

def lagen_ziehen(rs, N: int, n_a: int, versatz: list, n_b: int) -> tuple:
    """
    Zufällige Lage: n_a Falltage A mit mindestens RUHE_TAGE + 1 Tagen Abstand (wie die echten), gleichverteilt; Falltage B = A plus
    ein Versatz aus den echten Abständen (zufällig zugeteilt), im Kreis.
    """
    frei = N - (n_a - 1) * RUHE_TAGE
    if n_a < 1 or frei < n_a:
        raise ValueError("zu viele Fälle für die Reihe")
    a = np.sort(rs.choice(frei, size=n_a, replace=False)) + np.arange(n_a) * RUHE_TAGE
    b = np.zeros(0, dtype=np.int64)
    k = min(n_b, n_a, len(versatz))
    if k > 0:
        wahl = rs.permutation(n_a)[:k]
        v = rs.permutation(np.asarray(versatz, dtype=np.int64))[:k]
        b = np.unique((a[wahl] + v) % N)
    return a.astype(np.int64), b.astype(np.int64)


def null_erlaubt(laeufe: int) -> float:
    """
    Höchstens 5 % -- dazu drei Standardfehler der Simulation (bei 2.000 Läufen 6,5 %). Holm hält das Verfahren knapp unter 5 %
    (gemessen auf erfundenen Kursreihen: 4,4 bis 4,9 %); die Probe soll grobe Fehler finden, nicht am Zufall der Simulation scheitern.
    """
    return NULL_GRENZE + 3.0 * math.sqrt(NULL_GRENZE * (1 - NULL_GRENZE) / max(1, laeufe))


def nullprobe(y: np.ndarray, n_a: int, versatz: list, n_b: int, laeufe: int = NULL_LAEUFE, saat: int = SAAT, alpha: float = ALPHA) -> dict:
    """Zufällig gelegte Fälle gleicher Zahl durchlaufen das ganze Verfahren; gezählt wird, wie oft es „belegt“ meldet."""
    rs = np.random.RandomState(saat)
    belegt = 0
    for _ in range(laeufe):
        a, b = lagen_ziehen(rs, len(y), n_a, versatz, n_b)
        if pruefen(y, a, b, alpha)["urteil"] == "belegt":
            belegt += 1
    quote = belegt / laeufe if laeufe else None
    return {"laeufe": laeufe, "belegt": belegt, "quote": quote, "erlaubt": null_erlaubt(laeufe),
            "bestanden": quote is not None and quote <= null_erlaubt(laeufe)}


def fund_eine_lage(y: np.ndarray, pos: np.ndarray, stufen, alpha: float = ALPHA, min_s: int = MIN_VERSCHIEBUNG, mit_p: bool = False):
    """
    Für eine Lage und jeden eingebauten Nachteil δ (Zielgröße an den Falltagen um δ gesenkt): Wird er gefunden? Gerechnet ohne die
    Reihe je δ neu zu verschieben: Das verschobene Mittel sinkt um δ × (Zahl der Falltage, die auf Falltagen landen) ÷ n.
    Gefunden = p < alpha ÷ 2 (Holm bei zwei Fragen), Unterschied negativ, beide Hälften negativ.
    """
    N, n = len(y), len(pos)
    s = np.arange(min_s, N - min_s + 1, dtype=np.int64)
    idx = (pos[None, :] + s[:, None]) % N
    ms = y[idx].mean(axis=1)
    marke = np.zeros(N); marke[pos] = 1.0
    ks = marke[idx].sum(axis=1)
    alle = float(y.mean()); m0 = float(y[pos].mean())
    k = n // 2
    h1, h2 = float(y[pos[:k]].mean()), float(y[pos[k:]].mean())
    out = np.zeros(len(stufen), dtype=bool)
    ps = []
    for i, d in enumerate(stufen):
        alle_d = alle - d * n / N
        p = (1 + int(np.sum(ms - d * ks / n <= m0 - d + 1e-12))) / (1 + len(s))
        ps.append(p)
        out[i] = p < alpha / 2 and (m0 - d) < alle_d and (h1 - d) < alle_d and (h2 - d) < alle_d
    return (out, ps) if mit_p else out


def fundquoten(y: np.ndarray, n_a: int, versatz: list, n_b: int, laeufe: int = KONTROLLE_LAEUFE, saat: int = SAAT + 1,
               stufen=KONTROLLE_STUFEN, alpha: float = ALPHA) -> dict:
    """Je Frage: Anteil der zufälligen Lagen, in denen ein eingebauter Nachteil gefunden wird; Nachweisgrenze = kleinster Nachteil ab FUNDQUOTE."""
    rs = np.random.RandomState(saat)
    summe = {"A": np.zeros(len(stufen)), "B": np.zeros(len(stufen))}
    zahl = {"A": 0, "B": 0}
    for _ in range(laeufe):
        a, b = lagen_ziehen(rs, len(y), n_a, versatz, n_b)
        for name, pos in (("A", a), ("B", b)):
            if len(pos) >= MIN_FAELLE:
                summe[name] += fund_eine_lage(y, pos, stufen, alpha); zahl[name] += 1
    out = {"laeufe": laeufe, "stufen": list(stufen)}
    for name in ("A", "B"):
        if not zahl[name]:
            out[name] = {"quote": None, "bei_nennwert": None, "grenze": None}
            continue
        q = summe[name] / zahl[name]
        ueber = [d for d, v in zip(stufen, q) if v >= FUNDQUOTE]
        nenn = [float(v) for d, v in zip(stufen, q) if abs(d - KONTROLLE_NENNWERT) < 1e-9]
        out[name] = {"quote": [round(float(v), 4) for v in q], "bei_nennwert": nenn[0] if nenn else None,
                     "grenze": min(ueber) if ueber else None}
    return out


# ================================================================================================ Rechnen, Speichern

def rechnen(db: str, jetzt: int | None = None, laeufe_null: int = NULL_LAEUFE, laeufe_kontrolle: int = KONTROLLE_LAEUFE) -> dict:
    """Die ganze Prüfung auf den vorhandenen Daten. ok=False mit Gründen, wenn Daten fehlen -- dann wird nichts gespeichert."""
    jetzt = int(jetzt or time.time())
    t0 = time.time()
    out = {"ok": False, "regel": REGEL, "version": VERSION_MODUL, "ts": jetzt, "fehlt": []}
    S = schlange_lesen(ST.pfad(db))
    if not S["ok"]:
        out["fehlt"] += S["fehlt"]
        return out
    F = faelle_bestimmen(S["Q"], S["W"])
    von_D, bis_D = S["von_D"] + 1, S["bis_D"]
    spaet = max([bis_D] + [f["b"] for f in F["faelle"] if f["b"] is not None])
    K = kurse_lesen(swing_pfad(db), von_D - HORIZONT, spaet + HORIZONT_LANG + 1)
    if not K["ok"]:
        out["fehlt"] += K["fehlt"]
        return out
    Z = zielgroessen(K, von_D - HORIZONT, spaet + 1)
    Z["vor7"] = {D: Z["y7"][D - HORIZONT] for D in range(von_D, spaet + 1) if (D - HORIZONT) in Z["y7"]}      # die 7 Tage vor dem Tag
    Z["ab_folgetag"] = {D: Z["y7"][D + 1] for D in range(von_D, spaet + 1) if (D + 1) in Z["y7"]}             # 7 Tage ab dem Tag danach
    erwartbar = [D for D in range(von_D, bis_D + 1) if D + HORIZONT <= K["bis_D"]]
    raster = [D for D in erwartbar if D in Z["y7"]]
    if len(erwartbar) < MIN_TAGE:
        out["fehlt"].append(f"Zu kurze Reihe: {len(erwartbar)} Tage mit Schlange und abgeschlossenem 7-Tage-Fenster (nötig {MIN_TAGE}).")
        return out
    if len(raster) < ABDECKUNG_MIN * len(erwartbar):
        out["fehlt"].append(f"Kurse unvollständig: {len(raster)} von {len(erwartbar)} Tagen ({ST._de(100 * len(raster) / len(erwartbar), 1)} %; "
                            f"nötig {ST._de(100 * ABDECKUNG_MIN, 0)} %) -- swing.db lädt vermutlich noch.")
        return out
    idx = {D: i for i, D in enumerate(raster)}
    y = np.asarray([Z["y7"][D] for D in raster], dtype=float)
    N = len(raster)

    def stand(D):
        return None if D is None else ("gewertet" if D in idx else ("offen" if D > raster[-1] else "ohne Kurs"))

    faelle = []
    for f in F["faelle"]:
        e = dict(f)
        e["a_tag"], e["b_tag"] = iso(f["a"]), (iso(f["b"]) if f["b"] is not None else None)
        for k, D in (("a", f["a"]), ("b", f["b"])):
            e[k + "_stand"] = stand(D)
            for g in ("y7", "eth7", "y14", "tief7", "vor7", "ab_folgetag"):
                e[f"{k}_{g}"] = Z[g].get(D) if D is not None else None
        faelle.append(e)
    pos_a = [idx[f["a"]] for f in F["faelle"] if f["a"] in idx]
    pos_b = sorted({idx[f["b"]] for f in F["faelle"] if f["b"] is not None and f["b"] in idx})
    versatz = [idx[f["b"]] - idx[f["a"]] for f in F["faelle"] if f["a"] in idx and f["b"] is not None and f["b"] in idx]
    P = pruefen(y, pos_a, pos_b)

    def beschreibend(tage: list) -> dict:
        return {g: (float(np.mean([Z[g][D] for D in tage if D in Z[g]])) if any(D in Z[g] for D in tage) else None)
                for g in ("eth7", "y14", "tief7", "vor7", "ab_folgetag")}
    for name, tage in (("A", [f["a"] for f in F["faelle"] if f["a"] in idx]),
                       ("B", sorted({f["b"] for f in F["faelle"] if f["b"] is not None and f["b"] in idx}))):
        P[name].update(beschreibend(tage))
    alle = {"y7": P["alle"], "sd_y7": float(y.std()), **beschreibend(raster)}
    null = fund = None
    if len(pos_a) >= MIN_FAELLE:
        null = nullprobe(y, len(pos_a), versatz, len(pos_b), laeufe_null)
        fund = fundquoten(y, len(pos_a), versatz, len(pos_b), laeufe_kontrolle)
        for name in ("A", "B"):
            P[name]["fund_nennwert"] = fund[name]["bei_nennwert"]
            P[name]["grenze"] = fund[name]["grenze"]
    a0, a1 = tag_nr(ANLASS[0]), tag_nr(ANLASS[1])
    anl = [f for f in F["faelle"] if a0 <= f["a"] <= a1]
    anlass = {"von": ANLASS[0], "bis": ANLASS[1], "wellen": [iso(f["a"]) for f in anl],
              "gewertet": any(f["a"] in idx or (f["b"] is not None and f["b"] in idx) for f in anl), "ohne": None}
    if anlass["gewertet"]:
        rest = [f for f in F["faelle"] if not a0 <= f["a"] <= a1]
        P2 = pruefen(y, [idx[f["a"]] for f in rest if f["a"] in idx],
                     sorted({idx[f["b"]] for f in rest if f["b"] is not None and f["b"] in idx}))
        anlass["ohne"] = {"urteil": P2["urteil"], **{k: {g: P2[k][g] for g in ("n", "diff", "p", "p_holm", "urteil")} for k in ("A", "B")}}
    urteil = P["urteil"]
    if null is not None and not null["bestanden"]:
        urteil = "kein Urteil"                                            # das Verfahren hält auf diesen Daten sein Fehlerniveau nicht
    h = hashlib.sha1(json.dumps([raster[0], raster[-1], [int(round(v * 1e7)) for v in y.tolist()],
                                 [[f["a"], f["b"]] for f in F["faelle"]]]).encode()).hexdigest()[:12]
    out.update({
        "ok": True, "urteil": urteil, "A": P["A"], "B": P["B"], "alle": alle, "faelle": faelle, "ausloeser": len(F["ausloeser"]),
        "nullprobe": null, "fund": ({"laeufe": fund["laeufe"]} if fund else None), "anlass": anlass,
        "daten": {"schlange_von": iso(S["von_D"]), "schlange_bis": iso(S["bis_D"]), "schlange_bis_D": S["bis_D"], "schlange_tage": S["n"],
                  "luecken": S["fehlen"], "ausgeschlossen": S["ausgeschlossen_im_bereich"], "kurs_bis": iso(K["bis_D"]),
                  "kurs_ersatz": K["ersatz"], "raster_von": iso(raster[0]), "raster_bis": iso(raster[-1]), "raster_bis_D": raster[-1], "raster_tage": N,
                  "abdeckung": N / len(erwartbar), "pruefsumme": h},
        "dauer_s": round(time.time() - t0, 2),
    })
    return out


def gespeichert(p: str):
    con = ST.lesen(p)
    if con is None:
        return None
    try:
        E = ST.meta(con, SCHLUESSEL)
    finally:
        con.close()
    return E if isinstance(E, dict) and E.get("ok") else None


def speichern(p: str, E: dict) -> dict:
    """
    Das Urteil festhalten. Steht schon eines derselben Fassung da, bleibt es stehen (es wird zurückgegeben) -- so entsteht kein zweites
    Urteil durch wiederholtes Rechnen. Ein Urteil einer älteren Fassung der Regeln wird mit Datum abgelegt und ersetzt.
    """
    con = ST.verbinden(p)
    try:
        with ST.schreiben(con):
            alt = ST.meta(con, SCHLUESSEL)
            if isinstance(alt, dict) and alt.get("ok") and alt.get("regel") == E.get("regel"):
                return alt
            if isinstance(alt, dict) and alt.get("ok"):
                ablage = ST.meta(con, SCHLUESSEL + "_archiv") or []
                ablage.append({"regel": alt.get("regel"), "ts": alt.get("ts"), "urteil": alt.get("urteil"), "version": alt.get("version"),
                               "A": {k: (alt.get("A") or {}).get(k) for k in ("n", "diff", "p", "p_holm", "urteil")},
                               "B": {k: (alt.get("B") or {}).get(k) for k in ("n", "diff", "p", "p_holm", "urteil")}})
                ST.meta_setzen(con, SCHLUESSEL + "_archiv", ablage[-20:])
            ST.meta_setzen(con, SCHLUESSEL, E)
    finally:
        con.close()
    return E


def kurz(p: str) -> dict:
    """Für das Cockpit: das gespeicherte Urteil in wenigen Feldern. {"da": False} = noch nicht gerechnet."""
    E = gespeichert(p)
    if E is None:
        return {"da": False, "debug": 147, "min_faelle": MIN_FAELLE}

    def h(k):
        e = E.get(k) or {}
        return {g: e.get(g) for g in ("n", "urteil", "diff", "p", "p_holm", "grenze")}
    return {"da": True, "regel": E.get("regel"), "aktuell": E.get("regel") == REGEL, "ts": E.get("ts"), "urteil": E.get("urteil"),
            "A": h("A"), "B": h("B"), "daten_bis": (E.get("daten") or {}).get("raster_bis"), "debug": 147, "min_faelle": MIN_FAELLE}


def datenalter(E: dict) -> int | None:
    """Tage zwischen dem letzten Tag der Schlange und dem Tag des Rechnens (None = unbekannt). Nur für den Bericht."""
    bis = (E.get("daten") or {}).get("schlange_bis_D")
    if bis is None or E.get("ts") is None:
        return None
    return int(E["ts"]) // TAG - int(bis)


def seit_dem_urteil(p: str, E: dict, jetzt: int | None = None) -> dict | None:
    """Wellen (Fälle A) nach dem letzten bewerteten Tag der gespeicherten Prüfung (auch die damals noch offenen) -- nur gezählt."""
    S = schlange_lesen(p)
    bis = (E.get("daten") or {}).get("raster_bis_D")
    if not S["ok"] or bis is None:
        return None
    neu = [f["a"] for f in faelle_bestimmen(S["Q"], S["W"])["faelle"] if f["a"] > int(bis)]
    return {"wellen": len(neu), "tage": [iso(D) for D in neu], "schlange_bis": iso(S["bis_D"]),
            "alt_tage": int(jetzt or time.time()) // TAG - S["bis_D"]}


# ================================================================================================ Bericht

WAS_ES_HEISST = {
    "belegt": ("Nach großen Abzügen war ETH in den 7 Tagen danach gegen BTC schwächer als sonst, und Zufall erklärt das schlecht. Das "
               "ist ein Zusammenhang in der Zeit, kein Beweis der Ursache. Warnlampe und Einbau in den Ausblick werden eigens festgelegt."),
    "nicht belegt": ("Nach großen Abzügen war ETH gegen BTC nicht verlässlich schwächer als an anderen Tagen. Das heißt: mit diesen "
                     "Daten nicht zu zeigen -- nicht: widerlegt. Die Karte im Cockpit bleibt ein Messwert ohne Warnfarbe."),
    "zu wenige Fälle": (f"Es gibt weniger als {MIN_FAELLE} Wellen mit abgeschlossenem 7-Tage-Fenster. Ohne Urteil; die Karte im Cockpit "
                        "bleibt ein Messwert ohne Warnfarbe."),
    "kein Urteil": ("Die Nullprobe ist nicht bestanden: Das Verfahren meldet auf diesen Kursen auch bei zufällig gelegten Fällen zu oft "
                    "„belegt“. Sein Ergebnis gilt deshalb nicht."),
}


def _zeile_frage(name: str, titel: str, e: dict, alle: float) -> list:
    if not e["n"]:
        return [f"  {name}  {titel}: kein Fall mit abgeschlossenem Fenster  -> {e['urteil']}"]
    z = [f"  {name}  {titel}: {e['n']} Fälle · Mittel {_pz(e['mittel'])} % · alle Tage {_pz(alle)} % · Unterschied {_pz(e['diff'])} %-Punkte"
         + (f" · {e['negativ']} von {e['n']} negativ" if e.get("negativ") is not None else "")]
    if e["p"] is not None:
        z.append(f"       p {_p(e['p'])} · nach Holm {_p(e['p_holm'])} · Hälften {_pz(e['haelften'][0])} / {_pz(e['haelften'][1])} · "
                 f"bei zufälliger Lage in 90 % der Fälle zwischen {_pz(e['zufall_5'])} und {_pz(e['zufall_95'])}  -> {e['urteil']}")
    else:
        z.append(f"       kein Test (nötig {MIN_FAELLE} Fälle)  -> {e['urteil']}")
    return z


def bericht_text(E: dict, jetzt: int | None = None, neu: bool = False, seit: dict | None = None, hinweise: list | None = None) -> str:
    """Debug 147: Urteil, die beiden Fragen, Proben, Daten, jede Welle einzeln."""
    jetzt = int(jetzt or time.time())
    Z = []; a = Z.append
    a(f"★ Unstaking: Folgt auf große Abzüge ein Kursrückgang? (U255) · Modul {VERSION_MODUL} · {ST._datum(jetzt)}")
    a(f"Regeln vorab festgelegt am {FESTGELEGT} (KONZEPT_Unstaking.md 6 und 6a), bevor Schlange und Kurse zusammengeführt wurden. "
      f"Fassung {REGEL}.")
    for h in hinweise or []:
        a(h)
    if not E.get("ok"):
        a("")
        a("NICHT GERECHNET -- es fehlt:")
        for f in E.get("fehlt") or ["Grund unbekannt"]:
            a("  - " + f)
        a("Nichts gespeichert. Sobald die Daten da sind, rechnet dieser Lauf die Prüfung einmal und hält das Urteil fest.")
        return "\n".join(Z)
    d = E["daten"]
    a(f"Gerechnet am {time.strftime('%d.%m.%Y %H:%M', time.gmtime(E['ts']))} UTC mit Daten bis {datum(tag_nr(d['schlange_bis']))}"
      + (" -- jetzt, zum ersten Mal; das Urteil ist gespeichert." if neu else " -- gespeichertes Urteil, nicht neu gerechnet.")
      + (f" (Fassung der Regeln damals: {E.get('regel')})" if E.get("regel") != REGEL else ""))
    a("")
    a("URTEIL: " + E["urteil"].upper())
    a("  " + WAS_ES_HEISST.get(E["urteil"], ""))
    alt = datenalter(E)
    if alt is not None and alt >= STEHT_AB_TAGEN:
        a(f"  Gilt für die Wellen bis {datum(d['schlange_bis_D'])}: Die Tagesdatei der Quelle endete dort, {alt} Tage vor dem Rechnen. "
          "Spätere Wellen sind nicht geprüft.")
    a("")
    a(f"Die beiden Fragen (Zielgröße: ETH gegen BTC über {HORIZONT} Tage ab Tagesbeginn, in %; negativ = ETH schwächer)")
    Z += _zeile_frage("A", "Anmeldung (Tag, zu dessen Beginn der Zuwachs der Schlange gemessen ist)", E["A"], E["alle"]["y7"])
    Z += _zeile_frage("B", "Freigabe (erster Tag, nachdem das erste ETH der Welle frei geworden ist)", E["B"], E["alle"]["y7"])
    m = E["A"].get("verschiebungen") or E["B"].get("verschiebungen")
    if m:
        a(f"  p = Anteil der {ST._de(m)} Verschiebungen der Fälle gegen die Kurse (jede um mindestens {MIN_VERSCHIEBUNG} Tage), bei denen der "
          "Unterschied mindestens so niedrig ausfiel.")
    a(f"  „Belegt“ verlangt: p nach Holm unter {ST._de(ALPHA, 2)}, mindestens {MIN_FAELLE} Fälle, Unterschied in beiden Hälften der Fälle negativ.")
    an = E.get("anlass") or {}
    if an.get("ohne"):
        o = an["ohne"]
        a(f"  Gegenprobe ohne die Welle, die den Anlass zur Prüfung gab (Falltag {', '.join(datum(tag_nr(t)) for t in an['wellen'])}): "
          + "; ".join(f"{k} {o[k]['n']} Fälle, Unterschied {_pz(o[k]['diff'])}, p nach Holm {_p(o[k]['p_holm'])} -> {o[k]['urteil']}" for k in ("A", "B"))
          + ". Das Urteil oben folgt der vorab festgelegten Regel und zählt sie mit.")
    elif an.get("wellen"):
        a(f"  Die Welle, die den Anlass zur Prüfung gab (Falltag {', '.join(datum(tag_nr(t)) for t in an['wellen'])}), ist nicht mitgezählt: "
          "Ihr 7-Tage-Fenster war beim Rechnen noch offen.")
    elif an:
        a0, a1 = tag_nr(an["von"]), tag_nr(an["bis"])
        bis_D = d.get("schlange_bis_D")
        if bis_D is not None and bis_D < a0:
            a(f"  Die Wellen vom {datum(a0)} bis {datum(a1)} (Anlass der Prüfung) sind NICHT in den Daten: Die Tagesdatei der Quelle endet "
              f"am {datum(bis_D)}. Über sie sagt dieses Urteil nichts.")
        elif bis_D is not None and bis_D < a1:
            a(f"  Vom {datum(a0)} bis {datum(bis_D)} gab es nach der Regel keine Welle; für die Tage danach bis {datum(a1)} (Anlass der "
              f"Prüfung) fehlen die Daten: Die Tagesdatei der Quelle endet am {datum(bis_D)}.")
        else:
            a(f"  Vom {datum(a0)} bis {datum(a1)} (Anlass der Prüfung) gab es nach der Regel keine Welle: kein Tag mit Zuwachs ab "
              f"{ST._de(SCHWELLE_ETH)} ETH.")
    a("")
    a("Wie fein die Prüfung ist (Proben mit zufällig gelegten Fällen gleicher Zahl)")
    n0 = E.get("nullprobe")
    if n0:
        a(f"  Nullprobe: {ST._de(n0['laeufe'])} Läufe ohne eingebauten Nachteil -> {ST._de(n0['belegt'])}-mal „belegt“ "
          f"({ST._de(100 * n0['quote'], 1)} %; erlaubt bis {ST._de(100 * n0['erlaubt'], 1)} %): "
          + ("bestanden" if n0["bestanden"] else "NICHT bestanden"))
        fa, fb = E["A"].get("fund_nennwert"), E["B"].get("fund_nennwert")
        lf = (E.get("fund") or {}).get("laeufe")
        a(f"  Eingebauter Nachteil von {ST._de(100 * KONTROLLE_NENNWERT, 0)} %: gefunden in "
          + " und ".join(f"{ST._de(100 * v, 0)} % ({k})" for k, v in (("A", fa), ("B", fb)) if v is not None)
          + (f" von {ST._de(lf)} Läufen" if lf else ""))
        ga, gb = E["A"].get("grenze"), E["B"].get("grenze")
        gr = [f"{k} ab {ST._de(100 * v, 1)} %" if v is not None else f"{k} über {ST._de(100 * KONTROLLE_STUFEN[-1], 0)} %"
              for k, v in (("A", ga), ("B", gb)) if E[k]["n"] >= MIN_FAELLE]
        a(f"  Nachweisgrenze (in {ST._de(100 * FUNDQUOTE, 0)} % der Läufe gefunden): " + ", ".join(gr))
        a("  Ein kleinerer Nachteil wäre mit diesen Daten oft nicht zu erkennen.")
    else:
        a(f"  Nicht gerechnet: weniger als {MIN_FAELLE} Fälle.")
    a("")
    a("Daten")
    a(f"  Schlange der Abzüge: {ST._de(d['schlange_tage'])} Tage vom {datum(tag_nr(d['schlange_von']))} bis {datum(tag_nr(d['schlange_bis']))} · "
      f"{ST._de(d['luecken'])} Tage fehlen · {d['ausgeschlossen']} ausgeschlossen (07.05.–21.05.2025, laut Quelle falsche Einheit)")
    a(f"  Kurse: 30-min-Kerzen der Binance-Perpetuals (swing.db), gelesen bis {datum(tag_nr(d['kurs_bis']))} · bewertet {ST._de(d['raster_tage'])} Tage "
      f"({datum(tag_nr(d['raster_von']))} bis {datum(tag_nr(d['raster_bis']))}), Abdeckung {ST._de(100 * d['abdeckung'], 1)} %"
      + (f" · {d['kurs_ersatz']}-mal Eröffnung statt Schluss" if d.get("kurs_ersatz") else ""))
    F = E["faelle"]
    offen = sum(1 for f in F if f["a_stand"] == "offen")
    a(f"  Tage mit Zuwachs ab {ST._de(SCHWELLE_ETH)} ETH: {E['ausloeser']} · daraus Wellen: {len(F)} · Freigabe bestimmbar: "
      f"{sum(1 for f in F if f['b'] is not None)} · Fenster noch offen: {offen}"
      + (f" · mit Lücke im Vorlauf: {sum(1 for f in F if f['luecke'])}" if any(f["luecke"] for f in F) else ""))
    a(f"  Prüfsumme der Eingabe: {d['pruefsumme']} · Rechenzeit {ST._de(E.get('dauer_s') or 0, 1)} s")
    a("")
    a("Die Wellen im Einzelnen (Vortag = Schlange am Tag davor; Zuwachs = Schlange gegen den Vortag; Renditen in %; · = Fenster offen "
      "oder kein Kurs)")
    a("   Nr  Falltag A    Vortag ETH  Zuwachs ETH  Tage  Wartezeit  Falltag B     A: ETH−BTC   ETH allein   B: ETH−BTC   ETH allein")
    for f in F:
        a(f"  {f['nr']:>3}  {datum(f['a'])}  {ST._de(f['schlange'] - f['zuwachs']):>10}  {ST._de(f['zuwachs']):>11}  {f['ausloeser']:>4}  "
          f"{(ST._de(f['warte_vortag'], 1) + ' T') if f['warte_vortag'] is not None else '—':>9}  {datum(f['b']):<10}   "
          f"{_pz(f['a_y7'], 1):>9}   {_pz(f['a_eth7'], 1):>9}    {_pz(f['b_y7'], 1):>9}   {_pz(f['b_eth7'], 1):>9}"
          + ("  (Lücke im Vorlauf)" if f["luecke"] else ""))
    if not F:
        a("  (keine Welle in den Daten)")
    a("  Falltag A = Tag, zu dessen Beginn der Zuwachs gemessen ist (angemeldet wurde am Vortag); Tage = Tage mit Zuwachs ab der Schwelle in "
      "dieser Welle; Wartezeit = Dauer der Schlange am Vortag; Falltag B = erster Tag nach dem Freiwerden des ersten ETH.")
    a("")
    a("Daneben, nur beschreibend (kein Test)")
    al = E["alle"]
    for titel, g in ((f"ETH allein über {HORIZONT} Tage", "eth7"), (f"ETH gegen BTC über {HORIZONT_LANG} Tage", "y14"),
                     (f"Tiefster Stand von ETH in den {HORIZONT} Tagen (gegen den Kurs zu Beginn)", "tief7"),
                     (f"ETH gegen BTC in den {HORIZONT} Tagen VOR dem Falltag (lief der Kurs voraus?)", "vor7"),
                     (f"ETH gegen BTC über {HORIZONT} Tage ab dem Tag NACH dem Falltag (hält der Unterschied einen Tag später?)", "ab_folgetag")):
        a(f"  {titel}: bei A {_pz(E['A'].get(g))} %, bei B {_pz(E['B'].get(g))} %, alle Tage {_pz(al.get(g))} %")
    a("")
    if seit is not None:
        a(f"Seit dem Urteil: {seit['wellen']} neue Welle(n)" + (f" ({', '.join(datum(tag_nr(t)) for t in seit['tage'])})" if seit["tage"] else "")
          + f"; Schlange bis {datum(tag_nr(seit['schlange_bis']))}"
          + (f" (die Tagesdatei der Quelle ist seit {seit['alt_tage']} Tagen ohne neuen Eintrag -- neuere Wellen kann dieser Bericht nicht "
             "zählen)" if (seit.get("alt_tage") or 0) >= STEHT_AB_TAGEN else "")
          + f". Eine neue Prüfung ist frühestens nach {NEUE_WELLEN} weiteren Wellen vorgesehen und wird nicht von selbst gerechnet.")
    else:
        a(f"Eine neue Prüfung ist frühestens nach {NEUE_WELLEN} weiteren Wellen vorgesehen und wird nicht von selbst gerechnet.")
    a("Was die Prüfung nicht zeigt: ob frei gewordenes ETH an den Markt kam, und ob der Abzug Ursache oder Folge einer Kursbewegung war.")
    spaet = sum(1 for f in F if f["a"] >= tag_nr(PECTRA_AB))
    a(f"Offen ist auch, ob die Schlange der Tagesdatei seit Mai 2025 Zusammenlegungen mitzählt (sie bleiben gestakt; Hinweis darauf in "
      f"Debug 145). Dann wären einzelne der {spaet} Wellen ab {datum(tag_nr(PECTRA_AB))} keine Abzüge gewesen -- nicht geprüft.")
    return "\n".join(Z)


def bericht(db: str, mit_abruf: bool = True, transport=None, jetzt: int | None = None, laeufe_null: int = NULL_LAEUFE,
            laeufe_kontrolle: int = KONTROLLE_LAEUFE) -> str:
    """
    Debug 147. Steht ein Urteil dieser Fassung da, wird es gezeigt (und gezählt, was seither kam). Sonst wird gerechnet: Ist die
    Tagesdatei noch nie oder vor mehr als 6 Stunden geladen worden, holt der Lauf sie vorher selbst (braucht Netz).
    """
    jetzt = int(jetzt or time.time())
    p = ST.pfad(db)
    E = gespeichert(p)
    if E is not None and E.get("regel") == REGEL:
        return bericht_text(E, jetzt, neu=False, seit=seit_dem_urteil(p, E, jetzt))
    hinweise = []
    if E is not None:
        hinweise.append(f"Ein Urteil der älteren Fassung {E.get('regel')} ({E.get('urteil')}) wird abgelegt; gerechnet wird nach {REGEL}.")
    if mit_abruf:
        con = ST.verbinden(p)
        try:
            td = ST.meta(con, "tagesdatei") or {}
            if jetzt - int(td.get("ts") or 0) > ST.TAGESDATEI_TAKT_S:
                r = ST.lauf_tagesdatei(con, ST.Abruf(transport, frist_s=ST.TAGESDATEI_MAX_S), jetzt)
                hinweise.append(f"Tagesdatei frisch geladen: {ST._de(r['n'])} Tage bis {r['letzter']}." if r["ok"] else
                                "Tagesdatei: Abruf nicht gelungen (" + "; ".join(r["fehler"])[:200] + ")"
                                + (f" -- gerechnet wird mit dem Stand vom {ST._datum(td['ts'])}." if td.get("ts") else "."))
        finally:
            con.close()
    R = rechnen(db, jetzt, laeufe_null, laeufe_kontrolle)
    neu = True
    if R["ok"]:
        fest = speichern(p, R)
        neu = fest is R                                                   # ein zweiter Lauf zur selben Zeit war schneller: dessen Urteil gilt
        R = fest
    return bericht_text(R, jetzt, neu=neu, hinweise=hinweise)


# ================================================================================================ Selbsttest (ohne Netz)

def _probe_welt(ordner: str, tage: int = 900, abstand: int = 37, nachteil: float = 0.0, saat: int = 1, ende: str = "2026-11-10",
                voll: bool = False, kurs_bis_plus: int = 0, sd: float = 0.02, extra: tuple = ()) -> dict:
    """
    Erfundene Welt mit bekanntem Ergebnis: staking.db (Schlange je Tag, im Mittel alle `abstand` Tage eine Welle in unregelmäßigem
    Abstand: +120.000 ETH, am Tag darauf +60.000, dann Abbau um 57.600 je Tag; eine Welle liegt in der ausgeschlossenen Zeit) und swing.db (Kerzen von ETH und BTC: Zufallsweg; bei `nachteil` fällt ETH in den 7 Tagen
    ab jedem Falltag A um diesen Betrag). Wartezeit des Vortags je Welle 0 / 1,3 / 2,6 / 3,9 Tage -> Freigabe A + 1 / 2 / 3 / 5.
    „A“ und „B“ der Antwort sind die Fälle, die das Verfahren finden soll: Wellen in der ausgeschlossenen Zeit (Mai 2025) zählen nicht.
    """
    ende_D = tag_nr(ende)
    D0 = ende_D - tage + 1
    rs = np.random.RandomState(saat)
    rw = np.random.RandomState(10_000 + saat)                             # eigener Strom: die Kurse hängen nicht von den Wellen ab
    A = []
    d = D0 + 20
    while d <= ende_D - 9:                                                # unregelmäßige Abstände (im Mittel `abstand`, mindestens 15 Tage)
        A.append(d)
        d += abstand - 17 + int(rw.randint(0, 35))
    A = [a for a in A if not U0 - 16 <= a <= U1 + 16]
    if D0 + 20 < U0 - 40 and U1 + 40 < ende_D:
        A.append(U0 + 5)                                                  # eine Welle mitten in der ausgeschlossenen Zeit
    for x in extra:                                                       # Wellen an festen Tagen (z. B. der Anlass im November 2026)
        A = [a for a in A if abs(a - tag_nr(x)) > 16] + [tag_nr(x)]
    A.sort()
    warte = {a: (k % 4) * 1.3 for k, a in enumerate(A)}
    B = [(a - 1) + int(math.ceil(warte[a] + ST.SPERR_S / TAG)) for a in A]
    Q, W = {}, {}
    q = 0.0
    for D in range(D0, ende_D + 1):
        basis = 2_000.0 + 500.0 * ((D * 7) % 5)
        if D in warte:
            q = max(q, basis) + 120_000.0
        elif (D - 1) in warte:
            q += 60_000.0
        else:
            q = max(basis, q - 57_600.0)
        Q[D] = q
        W[D] = round(q / ST.DURCHSATZ_TAG, 4)
    for a in A:
        W[a - 1] = warte[a]
    p_st = os.path.join(ordner, "staking.db")
    con = ST.verbinden(p_st)
    with ST.schreiben(con):
        con.executemany("INSERT OR REPLACE INTO st_tag VALUES (?,?,?,?,?,?,?,?,?,?)",
                        [(iso(D), D * TAG, Q[D], W[D], 900_000.0, 15.6, 800_000.0, 44.6e6, 122e6, 2.5) for D in range(D0, ende_D + 1)])
    con.close()
    K0 = D0 - 8                                                           # die Kurse beginnen 8 Tage vor der Schlange (Vorlauf)
    n = tage + 8 + 16 + kurs_bis_plus
    r_btc = rs.normal(0.0, sd, n)
    r_eth = r_btc + rs.normal(0.0, sd, n)
    for a in A:
        for i in range(HORIZONT):
            if 0 <= a + i - K0 < n:
                r_eth[a + i - K0] -= nachteil / HORIZONT
    P = {"ETH": {K0: 2_000.0}, "BTC": {K0: 60_000.0}}
    for i in range(n):
        P["ETH"][K0 + i + 1] = P["ETH"][K0 + i] * math.exp(r_eth[i])
        P["BTC"][K0 + i + 1] = P["BTC"][K0 + i] * math.exp(r_btc[i])
    p_sw = os.path.join(ordner, "swing.db")
    sw = sqlite3.connect(p_sw)
    sw.execute("CREATE TABLE IF NOT EXISTS sw_klines (coin TEXT, ts INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, PRIMARY KEY (coin, ts)) WITHOUT ROWID")
    zeilen = []
    for coin in ("ETH", "BTC"):
        for i in range(n):
            D = K0 + i
            p0, p1 = P[coin][D], P[coin][D + 1]
            if voll:
                for j in range(48):
                    o = p0 + (p1 - p0) * j / 48.0; c = p0 + (p1 - p0) * (j + 1) / 48.0
                    zeilen.append((coin, D * TAG + j * BAR, o if j else p0 * 1.0001, max(o, c), min(o, c) * 0.999, c if j < 47 else p1, 1.0))
            else:
                zeilen.append((coin, D * TAG, p0 * 1.0001, p0 * 1.001, p0 * 0.999, p0 * 1.0002, 1.0))
                zeilen.append((coin, D * TAG + TAG - BAR, p1 * 0.9998, p1 * 1.001, p1 * 0.999, p1, 1.0))
    sw.executemany("INSERT OR REPLACE INTO sw_klines VALUES (?,?,?,?,?,?,?)", zeilen)
    sw.commit(); sw.close()
    soll = [(a, b) for a, b in zip(A, B) if not U0 <= a <= U1 + 1]          # eine Welle in der ausgeschlossenen Zeit ist kein Fall
    return {"db": os.path.join(ordner, "hl_liq.db"), "staking": p_st, "swing": p_sw, "D0": D0, "ende_D": ende_D,
            "A": [a for a, _b in soll], "B": [b for _a, b in soll], "A_gebaut": A, "Q": Q, "W": W, "P": P, "kurs_bis_D": K0 + n}


def _tagesdatei_aus(W: dict) -> list:
    """Die Schlange einer Probe-Welt in der Form der Tagesdatei von validatorqueue.com."""
    return [{"date": iso(D), "validators": 800000, "entry_queue": 900000, "entry_wait": 15.6, "exit_queue": W["Q"][D], "exit_wait": W["W"][D],
             "current_entry_churn": 256, "current_exit_churn": 256, "supply": 122000000, "staked_amount": 44600000, "staked_percent": 36.5,
             "apr": 2.5} for D in sorted(W["Q"])]


def _probe_transport(tagesdatei=None, fehler: BaseException | None = None, aufrufe: list | None = None):
    """Falscher Transport für den Selbsttest: liefert die Tagesdatei in Stücken oder wirft den genannten Fehler."""
    def transport(url, timeout):
        if aufrufe is not None:
            aufrufe.append(url)
        if fehler is not None:
            raise fehler
        roh = json.dumps(tagesdatei).encode()
        return 200, {}, iter([roh[i:i + 5000] for i in range(0, len(roh), 5000)])
    return transport


def _kreistest_schlicht(y: list, pos: list, min_s: int) -> tuple:
    """Gegenrechnung ohne numpy, Schleife für Schleife."""
    N = len(y)
    alle = sum(y) / N
    m0 = sum(y[i] for i in pos) / len(pos)
    zahl = 0; anz = 0
    for s in range(min_s, N - min_s + 1):
        anz += 1
        if sum(y[(i + s) % N] for i in pos) / len(pos) <= m0 + 1e-12:
            zahl += 1
    return m0 - alle, (1 + zahl) / (1 + anz), anz


def selbsttest(verbose: bool = True) -> bool:
    import shutil
    import tempfile
    global REGEL
    pruef = []

    def ok(name, bed, info=""):
        pruef.append((name, bool(bed)))
        if verbose or not bed:
            print(("  ok   " if bed else "  FEHL ") + name + (f" -- {info}" if info else ""))

    umgebung = {k: os.environ.pop(k, None) for k in ("HL_STAKING_DB", "HL_SWING_DB")}
    tmp = tempfile.mkdtemp(prefix="hl_studie_")
    jetzt = tag_nr("2026-11-14") * TAG + 8 * 3600
    spr = ST.SPERR_S / TAG
    try:
        # ---------------------------------------------------------------- Zeit und Fälle, von Hand
        ok("Zeitrechnung: Tagesnummern gegen den Kalender (21.05.2023 = 19.498, 14.11.2026 = 20.771), hin und zurück; die ausgeschlossene "
           "Zeit sind 15 Tage",
           tag_nr("2023-05-21") == 19498 and tag_nr("2026-11-14") == 20771 and iso(19860) == "2024-05-17" and datum(19860) == "17.05.2024"
           and (U0, U1) == (20215, 20229) and U1 - U0 + 1 == 15, f"{tag_nr('2023-05-21')}, {iso(19860)}, {U0}–{U1}")
        Q = {100: 10_000.0, 101: 67_600.0, 102: 125_199.0, 104: 500_000.0, 105: 557_600.0}
        F = faelle_bestimmen(Q, {100: 0.0})
        ok("Fall A an der Schwelle: Zuwachs von genau 57.600 ETH zählt, 57.599 nicht; ohne Messung am Vortag kein Fall; zwei solche Tage "
           "binnen 14 Tagen sind eine Welle",
           SCHWELLE_ETH == 57_600 and F["ausloeser"] == [101, 105] and [f["a"] for f in F["faelle"]] == [101] and F["faelle"][0]["ausloeser"] == 2
           and F["faelle"][0]["zuwachs"] == 57_600.0 and F["faelle"][0]["nr"] == 1, f"Auslöser {F['ausloeser']}, Fälle {[f['a'] for f in F['faelle']]}")
        Q2 = {D: 1_000.0 for D in range(180, 260)}
        for D in range(200, 260):
            Q2[D] += 60_000.0 * sum(1 for t in (200, 214, 229) if D >= t)
        F2 = faelle_bestimmen(Q2, {D: 0.0 for D in Q2})
        Qk = {D: 1_000.0 + 60_000.0 * sum(1 for t in (300, 310, 320, 330) if D >= t) for D in range(280, 350)}
        Fk = faelle_bestimmen(Qk, {D: 0.0 for D in Qk})
        ok("Ruhe von 14 Tagen: nach einem Tag mit Zuwachs beginnt 14 Tage später noch keine neue Welle, 15 Tage später schon; die Ruhe "
           "zählt ab dem letzten Tag mit Zuwachs, nicht ab dem Beginn der Welle (vier Tage im Abstand von 10 Tagen sind eine Welle)",
           F2["ausloeser"] == [200, 214, 229] and [f["a"] for f in F2["faelle"]] == [200, 229] and [f["ausloeser"] for f in F2["faelle"]] == [2, 1]
           and not F2["faelle"][0]["luecke"] and Fk["ausloeser"] == [300, 310, 320, 330] and [f["a"] for f in Fk["faelle"]] == [300]
           and Fk["faelle"][0]["ausloeser"] == 4, f"{[f['a'] for f in F2['faelle']]}; Kette {[f['a'] for f in Fk['faelle']]}")
        fb = {}
        for w in (0.0, 0.86, 0.87, 5.5, None):
            fb[w] = faelle_bestimmen({300: 0.0, 301: 60_000.0}, {300: w})["faelle"][0]["b"]
        ok("Fall B von Hand: Vortag + Wartezeit des Vortags + 27,3 h, aufgerundet -- Wartezeit 0 -> Tag nach der Anmeldung; 0,86 -> ebenso; "
           "0,87 -> zwei Tage danach; 5,5 -> sechs Tage danach; ohne Wartezeit kein Fall B",
           abs(spr - 98_304 / 86_400) < 1e-12 and fb == {0.0: 302, 0.86: 302, 0.87: 303, 5.5: 307, None: None}, f"{fb}")
        Q3 = {D: 5_000.0 for D in range(400, 440)}
        del Q3[410]
        Q3[411] = 90_000.0; Q3[412] = 150_000.0; Q3[430] = 80_000.0
        F3 = faelle_bestimmen(Q3, {D: 0.0 for D in Q3})
        ok("Lücke: der Tag nach einem fehlenden Tag kann kein Fall sein (kein Vortag), der Tag danach schon; ein Fall, in dessen 14 Tagen "
           "Vorlauf Messungen fehlen, ist gekennzeichnet",
           [f["a"] for f in F3["faelle"]] == [412, 430] and F3["faelle"][0]["luecke"] and not F3["faelle"][1]["luecke"],
           f"{[(f['a'], f['luecke']) for f in F3['faelle']]}")

        # ---------------------------------------------------------------- Tagesdatei -> staking.db -> Fälle (drei echte Zeilen, Mai 2024)
        o1 = os.path.join(tmp, "echt"); os.makedirs(o1)
        echt = [{"date": "2024-05-16", "validators": 1010063, "entry_queue": 10080, "entry_wait": 0.18, "exit_queue": 26592, "exit_wait": 0.25,
                 "current_entry_churn": 8, "current_exit_churn": 15, "supply": 120111518, "staked_amount": 32218651, "staked_percent": 26.82, "apr": 3.14},
                {"date": "2024-05-17", "validators": 1007892, "entry_queue": 1952, "entry_wait": 0.03, "exit_queue": 123776, "exit_wait": 1.15,
                 "current_entry_churn": 8, "current_exit_churn": 15, "supply": 120113283, "staked_amount": 32141017, "staked_percent": 26.76, "apr": 3.16},
                {"date": "2024-05-18", "validators": 1005021, "entry_queue": 1504, "entry_wait": 0.03, "exit_queue": 34560, "exit_wait": 0.32,
                 "current_entry_churn": 8, "current_exit_churn": 15, "supply": 120115545, "staked_amount": 32040121, "staked_percent": 26.67, "apr": 3.17}]
        unsicher = [{"date": iso(D), "exit_queue": 100 if D < U1 else 900_000, "exit_wait": 0.1} for D in range(U0 - 2, U1 + 3)]
        con = ST.verbinden(os.path.join(o1, "staking.db"))
        r_e = ST.lauf_tagesdatei(con, ST.Abruf(_probe_transport(echt + unsicher)), jetzt)
        con.close()
        S_e = schlange_lesen(os.path.join(o1, "staking.db"))
        F_e = faelle_bestimmen(S_e["Q"], S_e["W"])
        ok("Drei echte Zeilen der Tagesdatei (16.–18.05.2024: 26.592 -> 123.776 -> 34.560 ETH, Wartezeit am Vortag 0,25 Tage): Anmeldung am "
           "17.05.2024 mit Zuwachs 97.184 ETH, Freigabe ab 18.05.2024",
           r_e["ok"] and [(iso(f["a"]), f["zuwachs"], iso(f["b"])) for f in F_e["faelle"]][:1] == [("2024-05-17", 97_184.0, "2024-05-18")],
           f"{[(iso(f['a']), f['zuwachs'], f['b'] and iso(f['b'])) for f in F_e['faelle']]}")
        ok("Ausgeschlossene Zeit (07.05.–21.05.2025): Die 15 Tage fehlen in der Schlange; ein Sprung darin und am Tag danach ist kein Fall",
           S_e["ausgeschlossen"] == 15 and not any(U0 <= D <= U1 for D in S_e["Q"]) and (U1 + 1) in S_e["Q"] and (U0 - 1) in S_e["Q"]
           and not any(U0 - 1 <= f["a"] <= U1 + 2 for f in F_e["faelle"]) and S_e["ausgeschlossen_im_bereich"] == 15,
           f"ausgeschlossen {S_e['ausgeschlossen']}; Fälle {[iso(f['a']) for f in F_e['faelle']]}")

        # ---------------------------------------------------------------- Kurse und Zielgröße
        o2 = os.path.join(tmp, "voll"); os.makedirs(o2)
        Wv = _probe_welt(o2, tage=420, saat=3, voll=True)
        Kv = kurse_lesen(Wv["swing"], Wv["D0"], Wv["ende_D"] + HORIZONT_LANG)
        Zv = zielgroessen(Kv, Wv["D0"], Wv["ende_D"])
        Dp = Wv["D0"] + 50
        y_hand = math.log(Wv["P"]["ETH"][Dp + 7] / Wv["P"]["ETH"][Dp]) - math.log(Wv["P"]["BTC"][Dp + 7] / Wv["P"]["BTC"][Dp])
        tief_hand = min(min(Wv["P"]["ETH"][Dp + i], Wv["P"]["ETH"][Dp + i + 1]) for i in range(7)) * 0.999
        ok("Kurs zu Beginn des UTC-Tags = Schluss der letzten 30-min-Kerze des Vortags; Zielgröße (ETH gegen BTC über 7 Tage) und Tagestief "
           "stimmen mit der Rechnung von Hand überein",
           Kv["ok"] and all(abs(Kv["eth"][D] - Wv["P"]["ETH"][D]) < 1e-9 and abs(Kv["btc"][D] - Wv["P"]["BTC"][D]) < 1e-6
                            for D in range(Wv["D0"] + 1, Wv["ende_D"] + 1))
           and abs(Zv["y7"][Dp] - y_hand) < 1e-12 and abs(Zv["eth7"][Dp] - math.log(Wv["P"]["ETH"][Dp + 7] / Wv["P"]["ETH"][Dp])) < 1e-12
           and abs(Zv["y14"][Dp] - (math.log(Wv["P"]["ETH"][Dp + 14] / Wv["P"]["ETH"][Dp]) - math.log(Wv["P"]["BTC"][Dp + 14] / Wv["P"]["BTC"][Dp]))) < 1e-12
           and abs(Zv["tief7"][Dp] - math.log(tief_hand / Wv["P"]["ETH"][Dp])) < 1e-9 and Kv["ersatz"] == 0,
           f"y7 {Zv['y7'][Dp]:.6f} / von Hand {y_hand:.6f}; Tief {Zv['tief7'][Dp]:.5f}; Ersatz {Kv['ersatz']}")
        sw = sqlite3.connect(Wv["swing"])
        sw.execute("DELETE FROM sw_klines WHERE coin='ETH' AND ts=?", ((Dp + 3) * TAG - BAR,))
        sw.execute("DELETE FROM sw_klines WHERE coin='ETH' AND ts IN (?,?)", ((Dp + 20) * TAG - BAR, (Dp + 20) * TAG))
        sw.execute("DELETE FROM sw_klines WHERE coin='ETH' AND ts >= ? AND ts < ?", ((Dp + 40) * TAG + 5 * BAR, (Dp + 40) * TAG + 15 * BAR))
        sw.commit(); sw.close()
        Kl = kurse_lesen(Wv["swing"], Wv["D0"], Wv["ende_D"] + HORIZONT_LANG)
        Zl = zielgroessen(Kl, Wv["D0"], Wv["ende_D"])
        ok("Fehlt die letzte Kerze des Vortags, gilt die Eröffnung der ersten Kerze des Tags (gezählt); fehlen beide, hat der Tag keinen Kurs "
           "und zwei Zielgrößen entfallen (der Tag selbst und der 7 Tage davor); ein Tag mit nur 38 von 48 Kerzen hat kein Tagestief -- "
           "dann fehlt das Tief der sieben Fenster, die ihn enthalten, nicht aber die Zielgröße; 47 Kerzen genügen",
           abs(Kl["eth"][Dp + 3] - Wv["P"]["ETH"][Dp + 3] * 1.0001) < 1e-9 and Kl["ersatz"] == Kv["ersatz"] + 1 and (Dp + 20) not in Kl["eth"]
           and (Dp + 20) not in Zl["y7"] and (Dp + 13) not in Zl["y7"] and (Dp + 12) in Zl["y7"] and (Dp + 19) in Zl["y7"]
           and (Dp + 19) in Kl["tief"] and (Dp + 40) not in Kl["tief"] and (Dp + 40) in Zl["y7"] and (Dp + 34) in Zl["y7"]
           and all((Dp + 34 + i) not in Zl["tief7"] for i in range(7)) and (Dp + 33) in Zl["tief7"] and (Dp + 41) in Zl["tief7"]
           and TIEF_MIN_KERZEN == 40 and len(Zl["y7"]) == len(Zv["y7"]) - 2,
           f"Ersatz {Kl['ersatz']}; Zielgrößen {len(Zl['y7'])} statt {len(Zv['y7'])}")
        import hl_swing as SW
        os.environ["HL_SWING_DB"] = "/x/y.db"
        gleich_env = swing_pfad("/a/b/hl_liq.db") == SW.swing_pfad("/a/b/hl_liq.db") == "/x/y.db"
        del os.environ["HL_SWING_DB"]
        ok("Ort der Kerzen wie im Swing-Modul (swing.db neben der Hauptdatenbank; HL_SWING_DB lenkt um)",
           gleich_env and swing_pfad("/a/b/hl_liq.db") == SW.swing_pfad("/a/b/hl_liq.db") == "/a/b/swing.db" and BAR == SW.BAR, swing_pfad("/a/b/hl_liq.db"))

        # ---------------------------------------------------------------- Kreistest, Holm, Urteil
        rs = np.random.RandomState(7)
        yz = rs.normal(0.0, 0.05, 400)
        posz = np.asarray([11, 60, 123, 200, 251, 300, 333, 390, 395])
        kt = kreistest(yz, posz)
        d_s, p_s, anz_s = _kreistest_schlicht(yz.tolist(), posz.tolist(), MIN_VERSCHIEBUNG)
        yn = yz.copy(); yn[posz] -= 0.5
        yp = yz.copy(); yp[posz] += 0.5
        ok("Kreistest gegen eine Gegenrechnung ohne numpy: gleicher Unterschied, gleiches p; N − 59 Verschiebungen (30 … N − 30); ein grober "
           "Nachteil gibt das kleinste mögliche p (nie 0), ein grober Vorteil p nahe 1 (einseitig)",
           abs(kt["diff"] - d_s) < 1e-12 and abs(kt["p"] - p_s) < 1e-12 and kt["verschiebungen"] == anz_s == 400 - 59
           and kreistest(yn, posz)["p"] == 1 / (1 + 341) and kreistest(yp, posz)["p"] > 0.99 and kreistest(yz, posz, 100)["verschiebungen"] == 201
           and kt["zufall_5"] < 0 < kt["zufall_95"], f"p {kt['p']:.4f} / {p_s:.4f}; {kt['verschiebungen']} Verschiebungen")
        ok("Holm von Hand: (0,01; 0,04) -> (0,02; 0,04) · (0,03; 0,02) -> (0,04; 0,04) · (0,6; 0,7) -> (1; 1) · (0,02; 1) -> (0,04; 1)",
           holm([0.01, 0.04]) == [0.02, 0.04] and holm([0.03, 0.02]) == [0.04, 0.04] and holm([0.6, 0.7]) == [1.0, 1.0]
           and holm([0.02, 1.0]) == [0.04, 1.0], f"{holm([0.01, 0.04])} {holm([0.03, 0.02])}")
        ok("Urteil an den Grenzen: 7 Fälle -> zu wenige Fälle; 8 Fälle, p 0,049, beide Hälften negativ -> belegt; p 0,05 -> nicht belegt; "
           "eine Hälfte positiv -> nicht belegt; Unterschied positiv -> nicht belegt",
           urteil_je(7, 0.001, -0.1, [-0.1, -0.1]) == "zu wenige Fälle" and urteil_je(8, 0.049, -0.1, [-0.1, -0.1]) == "belegt"
           and urteil_je(8, 0.05, -0.1, [-0.1, -0.1]) == "nicht belegt" and urteil_je(8, 0.001, -0.1, [-0.3, 0.1]) == "nicht belegt"
           and urteil_je(8, 0.001, 0.1, [-0.1, -0.1]) == "nicht belegt" and urteil_je(8, None, -0.1, [-0.1, -0.1]) == "nicht belegt"
           and gesamt_urteil("nicht belegt", "belegt") == "belegt" and gesamt_urteil("zu wenige Fälle", "zu wenige Fälle") == "zu wenige Fälle"
           and gesamt_urteil("nicht belegt", "zu wenige Fälle") == "nicht belegt", "")
        Pn = pruefen(yn, posz, [5, 6])
        yh = yz.copy(); yh[posz[:4]] -= 0.9; yh[posz[4:]] += 0.2
        Ph = pruefen(yh, posz, [])
        ym = yz + 0.5; ym[posz] = 0.3 + 0.01 * np.arange(len(posz))          # alle Tage im Mittel +0,5; die Falltage +0,3: schwächer, aber über 0
        Pm = pruefen(ym, posz, [])
        ok("Verfahren im Ganzen: Holm zählt immer zwei Fragen (fehlt B, verdoppelt sich p von A); B mit zwei Fällen bleibt ohne Test; ein "
           "Nachteil, der nur aus der ersten Hälfte der Fälle kommt, ist trotz kleinem p nicht belegt; gemessen wird gegen das Mittel "
           "aller Tage, nicht gegen null (Falltage mit +0,3 bei sonst +0,5 sind ein Nachteil)",
           Pn["A"]["p_holm"] == 2 * Pn["A"]["p"] and Pn["A"]["urteil"] == "belegt" and Pn["B"]["n"] == 2 and Pn["B"]["p"] is None
           and Pn["B"]["urteil"] == "zu wenige Fälle" and Pn["urteil"] == "belegt" and Pn["A"]["negativ"] == 9
           and Ph["A"]["p_holm"] < 0.05 and Ph["A"]["haelften"][0] < 0 < Ph["A"]["haelften"][1] and Ph["A"]["urteil"] == "nicht belegt"
           and Pm["A"]["urteil"] == "belegt" and Pm["A"]["mittel"] > 0 and Pm["A"]["haelften"][0] < 0 and Pm["A"]["haelften"][1] < 0
           and Pm["A"]["negativ"] == 0,
           f"p {Pn['A']['p']:.4f} -> Holm {Pn['A']['p_holm']:.4f}; Hälften {[round(v, 2) for v in Ph['A']['haelften']]} p Holm {Ph['A']['p_holm']:.4f}")

        # ---------------------------------------------------------------- Proben: zufällige Lagen, Nullprobe, Fundquote
        rs2 = np.random.RandomState(11)
        lagen = [lagen_ziehen(rs2, 500, 20, [1, 1, 2, 5] * 5, 20) for _ in range(200)]
        ok("Zufällige Lagen: 20 Falltage A mit mindestens 15 Tagen Abstand, innerhalb der Reihe; Falltage B = A plus einer der echten Abstände",
           all(len(a) == 20 and a.min() >= 0 and a.max() < 500 and np.diff(a).min() >= RUHE_TAGE + 1 for a, _b in lagen)
           and all(1 <= len(b) <= 20 and all(any((int(x) - int(v)) % 500 in set(a.tolist()) for v in (1, 2, 5)) for x in b) for a, b in lagen)
           and len({tuple(a.tolist()) for a, _b in lagen}) == 200 and max(a.max() for a, _b in lagen) > 480 and min(a.min() for a, _b in lagen) < 5,
           f"kleinster Abstand {min(int(np.diff(a).min()) for a, _b in lagen)}")
        y0 = np.random.RandomState(5).normal(0.0, 0.053, 900)
        n0 = nullprobe(y0, 20, [1, 2, 3, 5] * 5, 20, laeufe=300, saat=3)
        n_schlecht = nullprobe(y0, 20, [1, 2, 3, 5] * 5, 20, laeufe=120, saat=3, alpha=0.6)
        ok("Nullprobe: zufällig gelegte Fälle werden auf einem Zufallsweg höchstens so oft „belegt“ wie erlaubt (5 % plus drei Standardfehler "
           "der Simulation; bei 2.000 Läufen 6,5 %); die Probe schlägt an, wenn das Verfahren zu großzügig ist (Gegenprobe mit α = 0,6)",
           n0["bestanden"] and n0["quote"] <= n0["erlaubt"] and abs(null_erlaubt(2000) - 0.0646) < 0.0005 and n0["laeufe"] == 300
           and not n_schlecht["bestanden"] and n_schlecht["quote"] > 0.2,
           f"{n0['belegt']} von {n0['laeufe']} ({n0['quote']:.3f}, erlaubt {n0['erlaubt']:.3f}); Gegenprobe {n_schlecht['quote']:.2f}")
        stufen_p = (0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.2)
        gleich = True
        im_band = ueberdeckt = 0
        lagen_p = [lagen_ziehen(rs2, 900, 12, [1, 2], 12)[0] for _ in range(40)] + [np.arange(12, dtype=np.int64) * 30 + 7]
        for a_ in lagen_p:
            schnell, p_schnell = fund_eine_lage(y0, a_, stufen_p, mit_p=True)
            for i, dlt in enumerate(stufen_p):
                yd = y0.copy(); yd[a_] -= dlt
                kd = kreistest(yd, a_)
                k_ = len(a_) // 2
                hand = (kd["p"] < 0.025 and kd["diff"] < 0 and float(yd[a_[:k_]].mean()) < float(yd.mean())
                        and float(yd[a_[k_:]].mean()) < float(yd.mean()))
                gleich = gleich and bool(schnell[i]) == bool(hand) and abs(p_schnell[i] - kd["p"]) < 1e-12
                im_band += 0.025 <= kd["p"] < 0.05
                yo = y0.copy(); yo[a_] -= dlt                                 # ohne Überdeckung gerechnet wäre p kleiner: zählen, wie oft das vorkommt
                ueberdeckt += dlt > 0 and (1 + int(np.sum(y0[(a_[None, :] + np.arange(30, 871)[:, None]) % 900].mean(axis=1)
                                                          <= float(yo[a_].mean()) + 1e-12))) / 842 < kd["p"] - 1e-12
        fq = fundquoten(y0, 20, [1, 2, 3, 5] * 5, 20, laeufe=120, saat=4)
        qa = fq["A"]["quote"]
        ok("Fundquote: die abgekürzte Rechnung (ohne die Reihe je Nachteil neu zu verschieben) gibt in jedem Fall dasselbe p und dasselbe "
           "Ergebnis wie die volle Rechnung -- auch dort, wo verschobene Falltage auf Falltagen landen, und an der Schwelle 0,025; die "
           "Quote steigt mit dem Nachteil, bei 20 % wird er immer gefunden; die Nachweisgrenze ist der kleinste Nachteil ab 80 %",
           gleich and im_band >= 5 and ueberdeckt >= 5
           and all(x <= y_ + 1e-12 for x, y_ in zip(qa, qa[1:])) and qa[-1] == 1.0 and qa[0] < 0.3 and fq["A"]["grenze"] is not None
           and qa[list(KONTROLLE_STUFEN).index(fq["A"]["grenze"])] >= 0.8
           and (list(KONTROLLE_STUFEN).index(fq["A"]["grenze"]) == 0 or qa[list(KONTROLLE_STUFEN).index(fq["A"]["grenze"]) - 1] < 0.8)
           and abs(fq["A"]["bei_nennwert"] - qa[5]) < 1e-4 and KONTROLLE_STUFEN[5] == KONTROLLE_NENNWERT and len(KONTROLLE_STUFEN) == 40,
           f"A: bei 3 % {fq['A']['bei_nennwert']:.2f}, Grenze {fq['A']['grenze']}; B: {fq['B']['grenze']}; p im Band 0,025–0,05: {im_band}; "
           f"mit Überdeckung anderes p: {ueberdeckt}")

        # ---------------------------------------------------------------- Ende zu Ende: drei Welten
        o3 = os.path.join(tmp, "null"); os.makedirs(o3)
        W0 = _probe_welt(o3, saat=3, kurs_bis_plus=20)
        E0 = rechnen(W0["db"], jetzt, 200, 60)
        bewertet = [a for a in W0["A"] if a + HORIZONT <= W0["ende_D"]]
        ok("Welt ohne Nachteil (900 Tage, rund zwei Dutzend Wellen in unregelmäßigem Abstand, eine davon in der ausgeschlossenen Zeit): "
           "Fälle A und B wie gebaut, die Welle im Mai 2025 fehlt (Freigabe 1, 2, 3 oder 5 Tage nach der Anmeldung), jede Welle mit zwei "
           "Tagen über der Schwelle; Urteil „nicht belegt“; Nullprobe bestanden",
           E0["ok"] and [f["a"] for f in E0["faelle"]] == W0["A"] and [f["b"] for f in E0["faelle"]] == W0["B"]
           and len(W0["A_gebaut"]) == len(W0["A"]) + 1 and (U0 + 5) in W0["A_gebaut"] and E0["A"]["p"] != E0["B"]["p"]
           and {b - a for a, b in zip(W0["A"], W0["B"])} == {1, 2, 3, 5} and all(f["ausloeser"] == 2 for f in E0["faelle"])
           and E0["ausloeser"] == 2 * len(W0["A"]) and E0["A"]["n"] == len(bewertet) >= 20 and E0["urteil"] == "nicht belegt"
           and E0["A"]["urteil"] == E0["B"]["urteil"] == "nicht belegt" and E0["nullprobe"]["bestanden"] and E0["A"]["p"] > 0.05,
           f"{E0.get('urteil')}; A n {E0['A']['n']} p {E0['A']['p']:.3f}; B n {E0['B']['n']} p {E0['B']['p']:.3f}; Nullprobe {E0['nullprobe']['quote']:.3f}")
        d0 = E0["daten"]
        y_a = [math.log(W0["P"]["ETH"][a + 7] / W0["P"]["ETH"][a]) - math.log(W0["P"]["BTC"][a + 7] / W0["P"]["BTC"][a]) for a in bewertet]
        ok("Zahlen des Ergebnisses gegen die Welt: Mittel nach A und B von Hand, Raster ab dem zweiten Tag der Schlange, Abdeckung 100 %, "
           "jede Welle mit ihren Renditen; beschreibend daneben die 7 Tage vor dem Falltag und die 7 Tage ab dem Tag danach, von Hand",
           abs(E0["A"]["mittel"] - sum(y_a) / len(y_a)) < 1e-12 and d0["raster_von"] == iso(W0["D0"] + 1) and d0["raster_bis"] == iso(W0["ende_D"])
           and d0["raster_tage"] == 899 and d0["abdeckung"] == 1.0 and d0["schlange_tage"] == 885 and d0["luecken"] == 0
           and d0["ausgeschlossen"] == 15
           and abs(E0["B"]["mittel"] - float(np.mean([math.log(W0["P"]["ETH"][b + 7] / W0["P"]["ETH"][b]) - math.log(W0["P"]["BTC"][b + 7] / W0["P"]["BTC"][b])
                                                     for b in W0["B"]]))) < 1e-12
           and abs(E0["faelle"][3]["a_y7"] - y_a[3]) < 1e-12 and E0["faelle"][3]["a_stand"] == "gewertet"
           and abs(E0["alle"]["y7"] - float(np.mean([math.log(W0["P"]["ETH"][D + 7] / W0["P"]["ETH"][D]) - math.log(W0["P"]["BTC"][D + 7] / W0["P"]["BTC"][D])
                                                     for D in range(W0["D0"] + 1, W0["ende_D"] + 1)]))) < 1e-12
           and len(d0["pruefsumme"]) == 12 and E0["A"]["tief7"] is None and E0["A"]["eth7"] is not None
           and abs(E0["A"]["vor7"] - float(np.mean([math.log(W0["P"]["ETH"][a_] / W0["P"]["ETH"][a_ - 7]) - math.log(W0["P"]["BTC"][a_] / W0["P"]["BTC"][a_ - 7])
                                                    for a_ in bewertet]))) < 1e-12
           and abs(E0["A"]["ab_folgetag"] - float(np.mean([math.log(W0["P"]["ETH"][a_ + 8] / W0["P"]["ETH"][a_ + 1])
                                                           - math.log(W0["P"]["BTC"][a_ + 8] / W0["P"]["BTC"][a_ + 1]) for a_ in bewertet]))) < 1e-12
           and abs(E0["faelle"][3]["a_vor7"] - (math.log(W0["P"]["ETH"][bewertet[3]] / W0["P"]["ETH"][bewertet[3] - 7])
                                                - math.log(W0["P"]["BTC"][bewertet[3]] / W0["P"]["BTC"][bewertet[3] - 7]))) < 1e-12
           and E0["alle"]["vor7"] is not None and E0["alle"]["ab_folgetag"] is not None,
           f"Mittel A {E0['A']['mittel']:.5f}; Raster {d0['raster_von']} … {d0['raster_bis']} ({d0['raster_tage']})")
        o4 = os.path.join(tmp, "nachteil"); os.makedirs(o4)
        W1 = _probe_welt(o4, saat=3, nachteil=0.08)
        E1 = rechnen(W1["db"], jetzt, 200, 60)
        ok("Positivkontrolle im Ganzen: Fällt ETH in den 7 Tagen ab jeder Anmeldung um 8 % (in die Kurse eingebaut), lautet das Urteil "
           "„belegt“ -- mit dem kleinsten möglichen p (nach Holm verdoppelt) und negativem Unterschied in beiden Hälften; der Unterschied "
           "liegt bei −7 %-Punkten (8 % abzüglich dessen, was der Nachteil am Mittel aller Tage ändert)",
           E1["ok"] and E1["urteil"] == "belegt" and E1["A"]["urteil"] == "belegt" and E1["A"]["p_holm"] == 2 / (1 + E1["A"]["verschiebungen"])
           and -0.10 < E1["A"]["diff"] < -0.04 and E1["A"]["haelften"][0] < 0 and E1["A"]["haelften"][1] < 0
           and E1["A"]["negativ"] >= 0.75 * E1["A"]["n"],
           f"A: Unterschied {E1['A']['diff']:.4f}, p Holm {E1['A']['p_holm']:.4f}; B: {E1['B']['urteil']} ({E1['B']['diff']:.4f})")
        aufrufe1 = []
        con = ST.verbinden(W1["staking"])
        with ST.schreiben(con):
            ST.meta_setzen(con, "tagesdatei", {"ts": jetzt - 3600, "n": 885, "letzter": "2026-11-10"})
        con.close()
        t_b = bericht(W1["db"], transport=_probe_transport([], aufrufe=aufrufe1), jetzt=jetzt, laeufe_null=100, laeufe_kontrolle=30)
        ok("Bericht bei „belegt“: Urteil in Großbuchstaben mit dem Satz, dass Lampe und Ausblick eigens festgelegt werden; ist die "
           "Tagesdatei vor weniger als 6 Stunden geladen worden, holt der Lauf sie nicht noch einmal",
           "URTEIL: BELEGT" in t_b and "Warnlampe und Einbau in den Ausblick werden eigens festgelegt." in t_b and aufrufe1 == []
           and "kein Beweis der Ursache" in t_b and gespeichert(W1["staking"])["urteil"] == "belegt" and "-> belegt" in t_b,
           f"Abrufe {len(aufrufe1)}")
        erlaubt_alt = globals()["null_erlaubt"]
        try:
            globals()["null_erlaubt"] = lambda laeufe: -1.0                 # so fällt jede Nullprobe durch
            E_k = rechnen(W1["db"], jetzt, 50, 20)
        finally:
            globals()["null_erlaubt"] = erlaubt_alt
        t_k = bericht_text(E_k, jetzt)
        ok("Fällt die Nullprobe durch, gibt es kein Urteil -- auch wenn der Test selbst „belegt“ meldet; der Bericht sagt es",
           E_k["ok"] and E_k["A"]["urteil"] == "belegt" and E_k["nullprobe"]["bestanden"] is False and E_k["urteil"] == "kein Urteil"
           and "URTEIL: KEIN URTEIL" in t_k and "NICHT bestanden" in t_k and "Sein Ergebnis gilt deshalb nicht." in t_k,
           f"{E_k['urteil']}; Nullprobe {E_k['nullprobe']['quote']}")
        o4b = os.path.join(tmp, "nachteil3"); os.makedirs(o4b)
        E1b = rechnen(_probe_welt(o4b, saat=3, nachteil=0.03, sd=0.006)["db"], jetzt, 200, 60)
        ok("Positivkontrolle aus dem Konzept: ein eingebauter Nachteil von 3 % wird gefunden (ruhiger Markt); die Nachweisgrenze dieser Welt "
           "liegt unter 3 %",
           E1b["urteil"] == "belegt" and E1b["A"]["urteil"] == "belegt" and E1b["A"]["grenze"] is not None and E1b["A"]["grenze"] < 0.03
           and E1b["A"]["fund_nennwert"] >= 0.8, f"p Holm {E1b['A']['p_holm']:.4f}; Grenze {E1b['A']['grenze']}; Fundquote bei 3 % {E1b['A']['fund_nennwert']}")
        o5 = os.path.join(tmp, "wenige"); os.makedirs(o5)
        W2 = _probe_welt(o5, saat=2, abstand=140, nachteil=0.3)
        E2 = rechnen(W2["db"], jetzt, 200, 60)
        ok("Zu wenige Fälle: weniger als 8 Wellen geben kein Urteil, auch bei grobem Nachteil; Nullprobe und Nachweisgrenze entfallen",
           E2["ok"] and 3 <= len(W2["A"]) < MIN_FAELLE and E2["A"]["n"] == len(W2["A"]) and E2["urteil"] == "zu wenige Fälle" and E2["A"]["p"] is None
           and E2["nullprobe"] is None and E2["A"].get("grenze") is None and E2["A"]["diff"] < -0.2, f"{E2['A']['n']} Fälle, {E2['urteil']}")

        # ---------------------------------------------------------------- Bericht, Speichern, kein stilles Neurechnen
        p0 = ST.pfad(W0["db"])
        k_vor = kurz(p0)
        aufrufe = []
        tr = _probe_transport(_tagesdatei_aus(W0), aufrufe=aufrufe)
        t1 = bericht(W0["db"], transport=tr, jetzt=jetzt, laeufe_null=200, laeufe_kontrolle=60)
        G1 = gespeichert(p0)
        t2 = bericht(W0["db"], transport=tr, jetzt=jetzt + 3 * TAG, laeufe_null=200, laeufe_kontrolle=60)
        G2 = gespeichert(p0)
        ok("Bericht (Debug 147): rechnet beim ersten Lauf und speichert; der zweite Lauf zeigt dasselbe Urteil und rechnet nicht neu; vor "
           "dem ersten Lauf holt er die Tagesdatei selbst (hier: einmal)",
           k_vor == {"da": False, "debug": 147, "min_faelle": MIN_FAELLE} and G1 is not None and G1["ts"] == jetzt and G2 == G1
           and "jetzt, zum ersten Mal; das Urteil ist gespeichert." in t1 and "gespeichertes Urteil, nicht neu gerechnet." in t2
           and "URTEIL: NICHT BELEGT" in t1 and "URTEIL: NICHT BELEGT" in t2 and len(aufrufe) == 1 and "historical_data.json" in aufrufe[0]
           and "Tagesdatei frisch geladen: 900 Tage bis 2026-11-10." in t1 and "Seit dem Urteil: 0 neue Welle(n)" in t2
           and "Schlange bis 10.11.2026 (die Tagesdatei der Quelle ist seit 7 Tagen ohne neuen Eintrag" in t2,
           f"{len(t1)} Zeichen; Abrufe {len(aufrufe)}")
        zl = [z for z in t1.splitlines() if z[:5].strip().isdigit()]
        ea = G1["A"]
        ok("Bericht nennt dieselben Zahlen wie das Ergebnis: je Frage Fälle, Mittel, Unterschied, p, Holm, Hälften; je Welle eine Zeile; "
           "Nullprobe, Fundquote bei 3 %, Nachweisgrenze, Daten, Prüfsumme; keine Handelswörter",
           len(zl) == len(W0["A"]) and f"A  Anmeldung (Tag, zu dessen Beginn der Zuwachs der Schlange gemessen ist): {ea['n']} Fälle · Mittel {_pz(ea['mittel'])} %" in t1
           and f"Unterschied {_pz(ea['diff'])} %-Punkte" in t1 and f"p {_p(ea['p'])} · nach Holm {_p(ea['p_holm'])} · Hälften" in t1
           and f"  {1:>3}  {datum(W0['A'][0])}  {ST._de(W0['Q'][W0['A'][0] - 1]):>10}  {'120.000':>11}  {2:>4}  {'0,0 T':>9}  {datum(W0['B'][0])}" in t1
           and 2_000.0 <= W0["Q"][W0["A"][0] - 1] <= 4_000.0 and "(swing.db), gelesen bis " in t1
           and "Nullprobe: 200 Läufe ohne eingebauten Nachteil" in t1 and "Eingebauter Nachteil von 3 %: gefunden in " in t1
           and "Nachweisgrenze (in 80 % der Läufe gefunden): A ab " in t1 and G1["daten"]["pruefsumme"] in t1 and "899 Tage" in t1
           and "vorab festgelegt am 14.11.2026" in t1 and "nicht: widerlegt" in t1
           and not [w for w in ("kaufen", "verkaufen", "empfehl", "einstieg", "ausstieg", "kursziel", "undefined") if w in t1.lower()]
           and not re.search(r"\b(None|nan|inf)\b", t1) and "Falltag A = Tag, zu dessen Beginn der Zuwachs gemessen ist" in t1,
           f"{len(zl)} Zeilen der Wellen")
        con = ST.verbinden(p0)
        with ST.schreiben(con):
            for i, zus in enumerate([0.0] * 17 + [200_000.0, 150_000.0, 90_000.0]):      # 17 ruhige Tage, dann eine neue Welle
                D = W0["ende_D"] + 1 + i
                con.execute("INSERT OR REPLACE INTO st_tag VALUES (?,?,?,?,?,?,?,?,?,?)", (iso(D), D * TAG, 2_000.0 + zus, 0.1, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0))
        con.close()
        t3 = bericht(W0["db"], mit_abruf=False, jetzt=jetzt + 9 * TAG)
        kz = kurz(p0)
        ok("Kein stilles Neurechnen: kommt nach dem Urteil eine neue Welle hinzu, bleibt das Urteil stehen; der Bericht zählt sie nur "
           "(„Seit dem Urteil: 1 neue Welle“); ein zweites Urteil derselben Fassung wird nicht gespeichert; die Kurzform für das Cockpit "
           "trägt Urteil, Fälle, p und Nachweisgrenze",
           gespeichert(p0) == G1 and speichern(p0, dict(G1, ts=G1["ts"] + 5, urteil="belegt")) == G1 and gespeichert(p0) == G1
           and f"Seit dem Urteil: 1 neue Welle(n) ({datum(W0['ende_D'] + 18)})" in t3 and "nach 5 weiteren Wellen" in t3
           and kz["da"] and kz["aktuell"] and kz["urteil"] == "nicht belegt" and kz["ts"] == jetzt and kz["A"]["n"] == ea["n"]
           and kz["A"]["p_holm"] == ea["p_holm"] and kz["A"]["grenze"] == ea["grenze"] and kz["B"]["urteil"] == G1["B"]["urteil"]
           and kz["daten_bis"] == G1["daten"]["raster_bis"] and kz["regel"] == REGEL,
           f"{kz['urteil']}; A {kz['A']['n']} Fälle; Grenze {kz['A']['grenze']}")
        regel_alt = REGEL
        try:
            REGEL = "U255/probe"
            t4 = bericht(W0["db"], mit_abruf=False, jetzt=jetzt + 10 * TAG, laeufe_null=100, laeufe_kontrolle=30)
        finally:
            REGEL = regel_alt
        con = ST.lesen(p0); ablage = ST.meta(con, SCHLUESSEL + "_archiv"); con.close()
        G4 = gespeichert(p0)
        ok("Neue Fassung der Regeln: erst dann wird neu gerechnet; das alte Urteil liegt mit Datum in der Ablage; die Kurzform meldet ein "
           "Urteil einer anderen Fassung als nicht aktuell",
           G4["regel"] == "U255/probe" and G4["ts"] == jetzt + 10 * TAG and isinstance(ablage, list) and len(ablage) == 1
           and ablage[0]["regel"] == regel_alt and ablage[0]["ts"] == jetzt and ablage[0]["urteil"] == "nicht belegt"
           and "Ein Urteil der älteren Fassung U255/1 (nicht belegt) wird abgelegt" in t4 and kurz(p0)["aktuell"] is False
           and G4["A"]["n"] == ea["n"] + 1, f"Ablage {len(ablage or [])}; neu {G4['regel']} mit {G4['A']['n']} Fällen")

        # ---------------------------------------------------------------- Fehlende Daten: nicht rechnen, nichts speichern
        o6 = os.path.join(tmp, "leer"); os.makedirs(o6)
        db6 = os.path.join(o6, "hl_liq.db")
        t_ohne = bericht(db6, mit_abruf=False, jetzt=jetzt)
        t_netz = bericht(db6, transport=_probe_transport(fehler=OSError("kein Netz")), jetzt=jetzt)
        ok("Ohne Daten wird nicht gerechnet und nichts gespeichert: staking.db fehlt; Tagesdatei nicht abrufbar (der Grund steht im Bericht)",
           "NICHT GERECHNET" in t_ohne and "staking.db fehlt noch" in t_ohne and "NICHT GERECHNET" in t_netz and "kein Netz" in t_netz
           and "noch nicht geladen" in t_netz and gespeichert(ST.pfad(db6)) is None and kurz(ST.pfad(db6))["da"] is False, "")
        o7 = os.path.join(tmp, "kurse"); os.makedirs(o7)
        W7 = _probe_welt(o7, saat=4)
        os.rename(W7["swing"], W7["swing"] + ".weg")
        R_ohne = rechnen(W7["db"], jetzt, 50, 20)
        os.rename(W7["swing"] + ".weg", W7["swing"])
        sw = sqlite3.connect(W7["swing"])
        sw.execute("DELETE FROM sw_klines WHERE coin='BTC' AND ts >= ? AND ts < ?", ((W7["D0"] + 300) * TAG, (W7["D0"] + 330) * TAG))
        sw.commit(); sw.close()
        R_loch = rechnen(W7["db"], jetzt, 50, 20)
        o8 = os.path.join(tmp, "kurz"); os.makedirs(o8)
        R_kurz = rechnen(_probe_welt(o8, tage=300, saat=4)["db"], jetzt, 50, 20)
        ok("Sperren vor dem Rechnen: ohne swing.db, mit Kursen für weniger als 98 % der Tage und mit weniger als 365 Tagen gibt es kein "
           "Ergebnis, sondern den Grund",
           not R_ohne["ok"] and "swing.db fehlt" in R_ohne["fehlt"][0] and not R_loch["ok"] and "Kurse unvollständig" in R_loch["fehlt"][0]
           and not R_kurz["ok"] and "Zu kurze Reihe: 299 Tage" in R_kurz["fehlt"][0] and "urteil" not in R_loch,
           f"{(R_loch.get('fehlt') or ['gerechnet'])[0][:60]} | {(R_kurz.get('fehlt') or ['gerechnet'])[0][:40]}")
        o9 = os.path.join(tmp, "offen"); os.makedirs(o9)
        W9 = _probe_welt(o9, saat=6)
        a9 = W9["A"][-1]                                                   # letzte Welle; Kurse enden 5 Tage nach ihrer Anmeldung
        sw = sqlite3.connect(W9["swing"])
        sw.execute("DELETE FROM sw_klines WHERE ts >= ?", ((a9 + 5) * TAG,))
        sw.commit(); sw.close()
        E9 = rechnen(W9["db"], jetzt, 50, 20)
        letzte = E9["faelle"][-1] if E9.get("ok") else {}
        ok("Offenes Fenster: Eine Welle, deren 7 Tage noch nicht um sind, zählt nicht mit und steht im Bericht als offen; das Raster endet "
           "7 Tage vor dem letzten Kurs",
           E9["ok"] and letzte.get("a") == a9 and letzte.get("a_stand") == "offen" and letzte.get("a_y7") is None
           and E9["A"]["n"] == len(W9["A"]) - 1 and E9["daten"]["kurs_bis"] == iso(a9 + 5) and E9["daten"]["raster_bis"] == iso(a9 + 5 - 7)
           and "Fenster noch offen: 1" in bericht_text(E9, jetzt),
           f"letzte Welle {letzte.get('a_tag')} {letzte.get('a_stand')}; Raster bis {E9.get('daten', {}).get('raster_bis')}")
        o10 = os.path.join(tmp, "anlass"); os.makedirs(o10)
        W10 = _probe_welt(o10, saat=7, ende="2026-11-25", extra=("2026-11-05",), kurs_bis_plus=5)
        E10 = rechnen(W10["db"], jetzt + 20 * TAG, 50, 20)
        an = E10["anlass"]
        idx10 = {D: i for i, D in enumerate(range(W10["D0"] + 1, W10["ende_D"] + 1))}
        y10 = np.asarray([math.log(W10["P"]["ETH"][D + 7] / W10["P"]["ETH"][D]) - math.log(W10["P"]["BTC"][D + 7] / W10["P"]["BTC"][D])
                          for D in range(W10["D0"] + 1, W10["ende_D"] + 1)])
        rest10 = [(a_, b_) for a_, b_ in zip(W10["A"], W10["B"]) if a_ != tag_nr("2026-11-05")]
        P10 = pruefen(y10, [idx10[a_] for a_, _b in rest10], [idx10[b_] for _a, b_ in rest10])
        t10 = bericht_text(E10, jetzt + 20 * TAG)
        sw = sqlite3.connect(W10["swing"])
        sw.execute("DELETE FROM sw_klines WHERE ts >= ?", (tag_nr("2026-11-09") * TAG,))
        sw.commit(); sw.close()
        E11 = rechnen(W10["db"], jetzt + 20 * TAG, 50, 20)
        ok("Anlass der Prüfung (Wellen mit Falltag A vom 01. bis 14.11.2026): Das Urteil zählt sie nach der Regel mit; daneben steht die "
           "Gegenprobe ohne sie (ein Fall weniger, gleich der Rechnung von Hand). Ist ihr Fenster noch offen, sagt der Bericht das; gab es "
           "keine, auch",
           tag_nr("2026-11-05") in W10["A"] and an["wellen"] == ["2026-11-05"] and an["gewertet"] and an["ohne"] is not None
           and an["ohne"]["A"]["n"] == E10["A"]["n"] - 1
           and abs(an["ohne"]["A"]["diff"] - P10["A"]["diff"]) < 1e-12 and an["ohne"]["A"]["p_holm"] == P10["A"]["p_holm"]
           and an["ohne"]["B"]["n"] == E10["B"]["n"] - 1 and an["ohne"]["urteil"] == P10["urteil"]
           and "Gegenprobe ohne die Welle, die den Anlass zur Prüfung gab (Falltag 05.11.2026): A " in t10
           and E11["anlass"]["wellen"] == ["2026-11-05"] and not E11["anlass"]["gewertet"] and E11["anlass"]["ohne"] is None
           and "(Falltag 05.11.2026), ist nicht mitgezählt" in bericht_text(E11, jetzt) and E0["anlass"]["wellen"] == []
           and ("Vom 01.11.2026 bis 10.11.2026 gab es nach der Regel keine Welle; für die Tage danach bis 14.11.2026 (Anlass der Prüfung) "
                "fehlen die Daten: Die Tagesdatei der Quelle endet am 10.11.2026.") in t1,
           f"Anlass {an['wellen']}; ohne ihn: A {((an.get('ohne') or {}).get('A') or {}).get('n')} Fälle (mit: {E10['A']['n']})")
        # ---- 23.102: Ende der Daten im Bericht (Anlass: Debug 147 vom 15.11.2026 -- Tagesdatei bis 25.10., Bericht sprach von „keine Welle“)
        o12 = os.path.join(tmp, "steht"); os.makedirs(o12)
        W12 = _probe_welt(o12, saat=5, ende="2026-10-25")
        j15 = tag_nr("2026-11-15") * TAG + 3 * 3600 + 24 * 60
        t12 = bericht(W12["db"], mit_abruf=False, jetzt=j15, laeufe_null=50, laeufe_kontrolle=20)
        G12 = gespeichert(W12["staking"])
        t12b = bericht(W12["db"], mit_abruf=False, jetzt=j15 + 2 * TAG)
        o13 = os.path.join(tmp, "gedeckt"); os.makedirs(o13)
        W13 = _probe_welt(o13, saat=1, ende="2026-11-25", kurs_bis_plus=5)
        sw13 = sqlite3.connect(W13["swing"])                                 # gesunder Alltag: Schlange bis gestern, Kurse bis gestern --
        sw13.execute("DELETE FROM sw_klines WHERE ts >= ?", (tag_nr("2026-11-26") * TAG,))    # bewertet ist dann nur bis vor 7 Tagen
        sw13.commit(); sw13.close()
        E13 = rechnen(W13["db"], tag_nr("2026-11-26") * TAG + 3600, 50, 20)
        t13 = bericht_text(E13, tag_nr("2026-11-26") * TAG + 3600)
        ok("Ende der Daten (23.102): Endet die Tagesdatei 21 Tage vor dem Rechnen, steht beim Urteil, bis wohin es gilt, und zur Anlass-Welle "
           "„nicht in den Daten“ statt „keine Welle“; ein späterer Lauf sagt, dass er neuere Wellen nicht zählen kann. Reicht die Tagesdatei "
           "über die Anlass-Zeit und gab es dort keine Welle, steht „keine Welle“ und kein Vermerk beim Urteil -- auch wenn (wie im "
           "Alltag) erst die Tage bis vor einer Woche bewertet sind: Maß ist das Ende der Schlange, nicht der letzte bewertete Tag",
           G12 is not None and datenalter(G12) == 21 and G12["daten"]["schlange_bis"] == "2026-10-25" and G12["anlass"]["wellen"] == []
           and ("  Gilt für die Wellen bis 25.10.2026: Die Tagesdatei der Quelle endete dort, 21 Tage vor dem Rechnen. Spätere Wellen sind "
                "nicht geprüft.") in t12
           and ("Die Wellen vom 01.11.2026 bis 14.11.2026 (Anlass der Prüfung) sind NICHT in den Daten: Die Tagesdatei der Quelle endet am "
                "25.10.2026. Über sie sagt dieses Urteil nichts.") in t12
           and "gab es nach der Regel keine Welle" not in t12 and "gespeichertes Urteil, nicht neu gerechnet." in t12b
           and "Gilt für die Wellen bis 25.10.2026" in t12b and "seit 23 Tagen ohne neuen Eintrag -- neuere Wellen kann dieser Bericht nicht zählen" in t12b
           and E13["ok"] and E13["daten"]["schlange_bis"] == "2026-11-25" and E13["daten"]["raster_bis"] == "2026-11-19" and datenalter(E13) == 1
           and not any(tag_nr("2026-11-01") <= a_ <= tag_nr("2026-11-14") for a_ in W13["A"]) and E13["anlass"]["wellen"] == []
           and "Vom 01.11.2026 bis 14.11.2026 (Anlass der Prüfung) gab es nach der Regel keine Welle: kein Tag mit Zuwachs ab 57.600 ETH." in t13
           and "Gilt für die Wellen bis" not in t13 and "NICHT in den Daten" not in t13 and "fehlen die Daten" not in t13
           and datenalter({"daten": {}, "ts": 5}) is None and STEHT_AB_TAGEN == 3 and PECTRA_AB == ST.ABBAU_AB_TAG == "2025-05-22"
           and (f"Dann wären einzelne der {sum(1 for a_ in W12['A'] if a_ >= tag_nr('2025-05-22'))} Wellen ab 22.05.2025 keine Abzüge gewesen "
                "-- nicht geprüft.") in t12 and 0 < sum(1 for a_ in W12["A"] if a_ >= tag_nr("2025-05-22")) < len(W12["A"]),
           f"Alter {datenalter(G12) if G12 else None} Tage; Wellen der gedeckten Welt im November: "
           f"{[iso(a_) for a_ in W13['A'] if a_ >= tag_nr('2026-11-01')]}")
        t_start = time.time()
        E_voll = rechnen(W0["db"], jetzt)
        dauer = time.time() - t_start
        ok("Voller Umfang (2.000 Läufe der Nullprobe, 400 Läufe je Nachteil): dasselbe Urteil wie mit kleinem Umfang, Nullprobe bestanden, "
           "Rechenzeit im Rahmen",
           E_voll["ok"] and E_voll["nullprobe"]["laeufe"] == 2000 and E_voll["nullprobe"]["bestanden"] and E_voll["A"]["p"] == G4["A"]["p"]
           and dauer < 120, f"{dauer:.1f} s; Nullprobe {E_voll['nullprobe']['quote']:.3f}; Grenze A {E_voll['A']['grenze']}")
    except Exception as e:  # noqa: BLE001 -- ein Absturz ist ein Fehlschlag mit Namen, kein stiller Abbruch
        import traceback
        ort = [z.strip() for z in traceback.format_exc().splitlines() if z.strip().startswith("File ")][-1:]
        ok("Selbsttest läuft ohne Absturz durch", False, f"{type(e).__name__}: {e} · {' '.join(ort)}"[:300])
    finally:
        for k, v in umgebung.items():
            if v is not None:
                os.environ[k] = v
        REGEL = "U255/1" if REGEL == "U255/probe" else REGEL
        shutil.rmtree(tmp, ignore_errors=True)
    alles = all(b for _n, b in pruef)
    print(f"{NAME} -- Selbsttest: {sum(1 for _n, b in pruef if b)} von {len(pruef)} Proben bestanden" + ("" if alles else " -- NICHT bestanden"))
    return alles


def main() -> int:
    ap = argparse.ArgumentParser(description=NAME)
    ap.add_argument("--bericht", action="store_true", help="Text für Debug 147 (rechnet beim ersten Mal und speichert das Urteil)")
    ap.add_argument("--selbsttest", action="store_true")
    ap.add_argument("--db", default="hl_liq.db")
    ap.add_argument("--ohne-abruf", action="store_true", help="die Tagesdatei nicht selbst laden")
    a = ap.parse_args()
    if a.selbsttest:
        return 0 if selbsttest() else 1
    if a.bericht:
        print("Unstaking: Prüfung der Kursfolge -- gerechnet wird nur beim ersten Lauf (meist unter einer Minute) …", flush=True)
        print(bericht(a.db, mit_abruf=not a.ohne_abruf))
        return 0
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
