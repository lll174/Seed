#!/usr/bin/env python3
"""
check_magnet.py -- Ziehen Liquidationscluster den Kurs an? Zwei Varianten, vier Horizonte.

Variante A: Cluster 0,5-1 % vom Kurs entfernt · Variante B: 1-2 % entfernt.
Horizonte 4, 8, 12, 24 h. Je Zelle (hl_forecast.magnet_varianten):

  Berührt / Placebo  Anteil der Fälle, in denen der Kurs das Cluster binnen h erreicht, gegen ein
                     Niveau in gleichem Abstand auf der anderen Seite zum selben Zeitpunkt.
  Δ (z)              Differenz beider Quoten in Prozentpunkten mit z-Wert auf n_eff -- das
                     Hauptmaß (der Lift als Quotient ist bei kleinem n nach oben verzerrt).
  Anziehung (t)      Überschussbewegung zum Cluster nach h Stunden in Prozent des Kurses,
                     nach Abzug der Marktdrift derselben Tage, mit t-Wert.
  näher              Anteil der Fälle, in denen der Kurs nach h näher am Cluster steht, gegen Placebo.
  Cho 15 min         bedingte Wahrscheinlichkeit einer Bewegung zum Cluster in den nächsten
                     15 Minuten (im Band) gegen die unbedingte (Cho/Russell/Tiao/Tsay 2003).

Lesart: Ein Magnet ist belegt, wenn Δ und Anziehung positiv sind UND z bzw. t über 2 liegen
UND Cho über der Basis -- in mehreren Horizonten. Ein einzelner Wert bei n_eff unter 20 ist
noch keine Aussage. Läuft nur lesend.

    python3 check_magnet.py --db /media/seed/marketdatabase/hl_liq/hl_liq.db [--coins BTC ETH] [--days 14]
"""
import argparse
import sqlite3
import time

import hl_forecast


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db", required=True)
    p.add_argument("--coins", nargs="+", default=["BTC", "ETH", "HYPE", "ZEC", "XMR", "PAXG"])
    p.add_argument("--days", type=int, default=14, help="Heatmap-Vorhalt ist 14 Tage")
    a = p.parse_args()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    print(f"Magnet-Varianten · {time.strftime('%d.%m.%Y %H:%M')} · letzte {a.days} Tage · Cluster ab {hl_forecast.MAGNET_MIN_USD / 1e6:.0f} Mio")
    print("Variante A: 0,5-1 % vom Kurs · Variante B: 1-2 % · Horizonte 4/8/12/24 h\n")
    for coin in a.coins:
        t0 = time.time()
        r = hl_forecast.magnet_varianten(con, coin, days=a.days)
        if not r:
            print(f"{coin}: zu wenig Daten (Heatmap-Schnappschüsse oder Bars)\n"); continue
        m = r["meta"]
        print(f"{coin}  (Drift {a.days} T je Horizont: " + ", ".join(f"{h}h {m['drift'][h]:+.2f} %" for h in hl_forecast.MAGNET_HORIZONTE)
              + f" · P(auf) 15 min {m['p_up15']:.2f} · {time.time() - t0:.1f} s)")
        for name, lo, hi in hl_forecast.MAGNET_VARIANTEN:
            z = r.get(name) or {}
            print(f"  Variante {'A' if name == '0.5-1' else 'B'} ({name} %): {z.get('n', 0)} Ereignisse")
            print(f"    {'h':>3} {'n_eff':>5} {'berührt':>8} {'Placebo':>8} {'Δ pp':>6} {'z':>5} {'Anziehung':>10} {'t':>5} {'näher':>6} {'Plc':>5}")
            for h in hl_forecast.MAGNET_HORIZONTE:
                c = z.get(h) or {}
                if c.get("p_touch") is None:
                    print(f"    {h:>3} {c.get('n_eff', 0):>5}  (weniger als 3 Ereignisse)"); continue
                print(f"    {h:>3} {c['n_eff']:>5} {c['p_touch']:>8.0%} {c['p_placebo']:>8.0%} {c['delta_pp']:>+6.0f} {str(c['z_delta']):>5} "
                      f"{c['anziehung_pct']:>+9.2f} % {str(c['t']):>5} {c['naeher']:>6.0%} {c['naeher_placebo']:>5.0%}")
            ch = z.get("cho15")
            if ch:
                print(f"    Cho 15 min: zum Cluster {ch['p_zum']:.0%} ({ch['ci'][0]:.0%}–{ch['ci'][1]:.0%}) gegen Basis {ch['basis']:.0%} · n {ch['n']}")
            else:
                print("    Cho 15 min: zu wenige Schnappschüsse im Band (< 20)")
        print()
    print("Lesart: Magnet belegt = Δ > 0 und Anziehung > 0 mit z bzw. t > 2 in mehreren Horizonten, Cho über Basis.")
    print("        z/t unter 2 oder n_eff unter 20: keine Aussage -- weiter sammeln. Negative Werte mit t < -2: das Cluster stößt ab.")


if __name__ == "__main__":
    main()
