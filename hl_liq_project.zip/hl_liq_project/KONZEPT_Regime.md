# KONZEPT Regime-Modul (U138) — die letzten 4–8 Wochen lesen: Größe, Zeitpunkt, Stufen, Teilnehmer

Stand 08.10.2026, Version 2026-09-23.60 (Opus 5.5). **Status: Phase 0 auf echten Daten gelaufen** (08.10. 02:06, Ergebnis in
Abschnitt 9.4). Belegt sind nur Kalendereffekte bei XMR (und, noch mit dem fehlerhaften K3, PAXG) sowie die Fensterkombination bei
ZEC und XMR; alles andere nicht. K3 war bis 23.59 nicht driftneutral (eigener Fehler, 9.1a Punkt 8), in 23.60 berichtigt; der
geplante Lauf 08.10. 21:00 rechnet K3 neu. Phasen 1–3 offen, Entscheidungen beim Nutzer (Abschnitt 12, nach Phase 0 neu gefasst).

**Grundlagen:**
- `RECHERCHE_Regime_07-10-2026.md` (Bericht „Kurze Fenster erkennen Volatilität, nicht Richtung“): sechs Recherchen und eine
  Synthese, rund 160 Quellen, unbestätigte Angaben gekennzeichnet.
- Eine Zufallsweg-Simulation in der Sandbox (Abschnitt 2). Echte Kursdaten erreicht die Sandbox nicht; die Prüfung an Daten ist
  Phase 0 auf dem Pi (Abschnitt 9).

**Wunsch des Nutzers (07.10. 21:51), sinngemäß:** ein Modul, das die jüngsten 4–8 Wochen „rückwärts“ analysiert. Es soll das
aktuelle Regime erkennen, also den Zeithorizont, den die Marktteilnehmer gerade nutzen, und daraus die nächsten Schritte ableiten:
- mehrtägige Stufen (2–3 Tage Anstieg, dann ein Rücksetzer mit höherem Tief, Schritte von typisch x %);
- Uhrzeiten („zwischen 2 und 5 Uhr fällt der Kurs“);
- Wochentage („samstags nachts fällt er“).

Die tatsächlichen Bewegungen sind größer als der heutige Vorhersagewert. Das Modul soll die Prognose über den 4-h-Takt hinaus
verbessern.

**Lesart:** Analysefenster 4–8 Wochen (adaptiv, Abschnitt 4.3), Prognose der nächsten Schritte von Stunden bis 7 Tage. 28 Tage
gibt es nur als Bandbreite.

**Zusage bis 25.10. bleibt:** keine Änderung an Fusion, v3, Kaskaden und dem Lernen von v1. Das Modul läuft zuerst im Schatten.

## 0. Kurzfassung

1. **Vorhersagbar ist, wie groß und wann, kaum aber, wohin.**
   - Robust außerhalb der Stichprobe sind das Tages- und Wochenprofil der Schwankung und die Größe der Bewegungen über 1–7 Tage.
     Für BTC erklärt ein HAR-Modell rund ein Drittel der Schwankung, gemessen in der Lernstichprobe.
   - Die Richtung ist über Tage nur schwach vorhersagbar. Wochenmomentum liefert bei BTC 2011–2018 ein R² von 3–5 %, also rund
     55–57 % Vorzeichentreffer, und ist seit 2020 kleiner.
2. **Deshalb wirkt unsere Prognose „zu klein“.**
   - Bei P(aufwärts) nahe 50 % liegt der Erwartungswert nahe null.
   - Die Bewegung selbst hat die volle Schwankung, und deren Größe ist vorhersagbar.
   - Das Modul gibt deshalb **Verteilungen** aus: Spannweite, Zonen, Zeitfenster und Berührwahrscheinlichkeiten statt eines
     Punktwerts.
3. **Das Stufenschema ist zum großen Teil Zufallsgeometrie.**
   - Ein Zufallsweg mit BTC-Schwankung erzeugt Beine von 2–3 Tagen und rund 2θ Größe.
   - Ein höheres Tief kommt dort in rund 50 % der Fälle, ein höheres Hoch nach einem höheren Tief in rund 2/3.
   - Fibonacci-Niveaus sind statistisch unauffällig.
   - Information steckt nur in den **Abweichungen** von diesen Werten; das Modul zieht die Zufallsgeometrie ab (Abschnitt 2, R4).
4. **Uhrzeit- und Wochentagsmuster der Richtung sind in 4–8 Wochen nicht von Zufall zu unterscheiden.**
   - In 8 Wochen ist ein Effekt erst ab 17–21 bp je Stunde nachweisbar; der größte dokumentierte liegt bei rund 4–5 bp.
   - Rein zufällig zeigt ein 8-Wochen-Fenster in 2 von 3 Fällen einen Wochentag, dessen Nacht in mindestens 6 von 8 Wochen fiel.
   - Solche Muster werden deshalb nur auf der dreijährigen Historie geprüft, höchstens drei davon vorab festgelegt. Live erscheinen
     sie als „Beobachtung mit Zufallsvergleich“ (R5).
5. **Grundregel: Die Historie schätzt, das Fenster filtert.**
   - Drei Jahre Binance-30-min-Kerzen schätzen Profile, Parameter und Nullverteilungen.
   - Das 4–8-Wochen-Fenster liefert nur den Zustand: Schwankungsniveau, Regime, laufendes Bein, Positionierung.
   - „4 oder 8 Wochen“ wird nicht gewählt, sondern kombiniert, und die Fensterlänge folgt dem letzten Bruch.
6. **Acht Bausteine** (R1–R8) liefern zwölf Anzeigen (RG1–RG12, Abschnitt 5), unter anderem:
   - Schwankungsprofil der nächsten 72 h und erwartete Spannweite;
   - Bein-Zustand mit Rücksetzer-Zone und „nächster Stufe“, jeweils gegen Zufall;
   - Regime-Lage mit Bruchalarm;
   - Teilnehmer an den Wendepunkten;
   - Pfadfächer über 7 Tage.
7. **Das eigentliche „Reverse Engineering“ läuft über unsere Kontodaten (R7).**
   - Wer kauft die Rücksetzer, wer verkauft die Anstiege, liegen an den Tiefs Liquidationen?
   - Hyperliquid macht das direkt beobachtbar. Auf 1–7 Tage hat das noch niemand untersucht; es ist Neuland und braucht eine
     strenge Vorwärtsprüfung.
8. **Jede Aussage hat eine Zufallsbaseline und eine vorab festgelegte Prüfung** (Abschnitt 9):
   - Nullmodelle in drei Stufen;
   - Positivkontrollen mit eingepflanzten Effekten;
   - Mutationen;
   - gezählte Konfigurationen (Deflated Sharpe, PBO);
   - kritische Werte für kleine Stichproben.
9. **Stufenplan** (Abschnitt 10):
   - Phase 0: Vorprüfung auf der Historie als Debug-Bericht, berührt nichts.
   - Phase 1: Schattenbetrieb mit eigener Anzeige.
   - Phase 2: Analoge, Pfadfächer, Labor-Strategien und Vorwärtsprüfung.
   - Phase 3: Einbindung belegter Teile als Experten der Fusion, frühestens nach dem 25.10. und den eigenen Urteilen.
10. **Erwartung, ehrlich:**
    - Spürbar besser werden Bandbreiten, Zonen und Zeitfenster.
    - Die Richtung wird um wenige Prozentpunkte verschoben, wenn überhaupt.
    - Muster, die nur im Fenster auftauchen, gelten als Rauschen, bis die Historie sie bestätigt.

## 1. Was die Idee leistet und was die Literatur dazu sagt

Die Idee trifft eine echte Lücke. Das System hat heute:
- den 4-h- und 24-h-Takt: v1, v2, v3, Fusion;
- Ereignisse: Ereignis-Profile U43, Vorbedingungen U131;
- die lange Lage: Makro U121, U126.

Für die **mittlere Ebene** (mehrtägige Schritte im aktuellen Regime) gibt es nur die globale Analog-Suche, ein festes Zeitprofil
der Schwankung und einen Band-Multiplikator aus Regime-Flags (`hl_indikatoren.regime`: Schwankung 24 h gegen 20 Tage,
OI-Überhitzung, Liquidationsintensität, Taker-Varianz). Die Recherche beantwortet die drei Teile der Idee unterschiedlich:

| Teil der Idee | Befund der Literatur | Folge für das Modul |
|---|---|---|
| Aktuelles Regime aus 4–8 Wochen erkennen | **Volatilitätsregime ja, binnen Stunden** (CUSUM: Verdopplung nach ≈ 4,5 h auf 30-min-Bars). **Drift- und Bull/Bear-Regime nein**: Echtzeitsignale hinken rund zwei Wochen hinterher, ein Driftwechsel von 1 %/Tag braucht 34–126 Tage. | Regime = Schwankungs-, Liquiditäts- und Positionierungszustand. Für die Richtung nur als Risikofilter. |
| Mehrtägige Stufen erkennen, Rücksetzer und nächste Stufe vorhersagen | **Segmentieren gelingt kausal** (Directional Change). Die **Statistik der Beine ist überwiegend Zufallsweg-Identität** (Überschießen ≈ θ, höheres Hoch nach höherem Tief = 2/3, Retracements glatt). Eine einzige Krypto-DC-Studie (Preprint) findet eine kleine Abweichung (≈ 7,5 % von θ). | Bein-Zustand anzeigen, Prognosen nur als **Verbesserung über die geschlossene Zufallsbaseline** (D/θ, Exp(θ)). Rücksetzertiefe ist vor allem eine Schwankungsprognose. |
| Uhrzeit- und Wochentagsmuster | **Kalenderrenditen wechseln das Vorzeichen** über Stichproben (Baur et al. 2019; Kinateder & Papavassiliou 2021; Sahu 2024: 2020–2023 keine Anomalie). Nach Data-Snooping-Korrektur bleibt nichts (Sullivan, Timmermann & White 2001). **Kalenderprofile der Schwankung sind dagegen robust** (Hansen, Kim & Kimbrough 2024). | Zeitmuster der Schwankung als Kernbaustein (R1). Zeitmuster der Richtung nur vorab festgelegt auf der Historie (R5). |

Neu gegenüber der Literatur ist, was nur dieses System hat: Positionen, Liquidationsniveaus und Händlergruppen von Hyperliquid.
Die einzige Hyperliquid-Renditeevidenz endet bei 30 Sekunden (Zhai 2026). Ob Kontodaten mehrtägige Wendepunkte erklären, ist
offen, und genau das prüft R7.

## 2. Was ein Zufallsweg schon erzeugt (Sandbox-Simulation 07.10.)

`zufall_regime.py` (Arbeitsbereich, nicht im Paket): log-Kurs als Zufallsweg mit 2,5 % Tagesschwankung (BTC-ähnlich) in
5-min-Schritten, 4.000 Tage. Die Directional-Change-Segmentierung ist kausal: ein Extremum gilt als bestätigt, sobald der Kurs sich
um θ davon entfernt hat.

| Größe | θ 3 %, ohne Drift | θ 3 %, Drift +0,2 %/Tag | θ 4 %, ohne Drift | θ 4 %, Drift +0,2 %/Tag | geschlossene Form (ohne Drift) |
|---|---|---|---|---|---|
| Beine je 4 Wochen | 16,9 | 16,9 | 10,0 | 10,0 | 28 T ÷ (θ²/σ²) |
| Aufwärtsbein: Größe, Dauer | 2,10θ, 1,67 T | 2,22θ, 1,78 T | 2,07θ, 2,77 T | 2,21θ, 3,02 T | 2θ; θ²/σ² = 1,44 T bzw. 2,56 T |
| Abwärtsbein: Größe, Dauer | 2,12θ, 1,64 T | 2,01θ, 1,54 T | 2,09θ, 2,80 T | 1,95θ, 2,55 T | wie oben |
| P(höheres Tief) | 0,495 | 0,539 | 0,469 | 0,532 | 1/2 |
| P(höheres Hoch \| höheres Tief) | 0,658 | 0,682 | 0,696 | 0,682 | 2/3 |
| Rücksetzer kleiner als 38,2 / 50 / 61,8 % des vorigen Beins | 0,07 / 0,14 / 0,22 | 0,09 / 0,17 / 0,26 | 0,06 / 0,12 / 0,21 | 0,09 / 0,17 / 0,25 | 0,055 / 0,123 / 0,206 |
| Rücksetzer 0,5θ bzw. 0,75θ erreicht → Hoch war endgültig | — | — | 0,515 / 0,749 | — | D/θ = 0,50 / 0,75 |

**Lesart:**
- Der Zufall allein liefert bei θ ≈ 4 % und BTC-Schwankung **Beine von knapp drei Tagen und rund 8 %**.
- Ein **höheres Hoch nach einem höheren Tief kommt in zwei von drei Fällen**. Das ist ein reiner Auswahleffekt: Die Bedingung
  „höheres Tief“ wählt kurze Rücksetzer aus.
- Selbst ein kräftiger Trend (+0,2 %/Tag ≈ +6 % im Monat) hebt die Quote höherer Tiefs nur auf 53–54 %.
- Die Abweichungen von den geschlossenen Formen erklären sich aus den 5-min-Schritten: Die wirksame Schwelle ist rund
  θ + 1,2·σ_Schritt; damit werden aus 2,56 T rechnerisch 2,78 T (simuliert 2,77–2,80).
- **Für die Umsetzung heißt das:** Diskretisierung verlängert Beine messbar, bei 30-min-Bars und θ = 4 % um rund 20 %.
  Nullsimulationen laufen deshalb immer in derselben Bar-Auflösung und mit derselben Datierungsregel wie die Daten.

**Kalender-Scheinmuster unter dem Zufall** (Vorzeichen je Nacht 50/50, exakt bzw. 4.000 Läufe):

| Fenster | vorab gewähltes Fenster | irgendein Fenster (Suche) |
|---|---|---|
| 4 Wochen, Nachtfenster eines Wochentags, 4 von 4 negativ | 6,2 % | 36 % (7 Wochentage); fallend oder steigend 61 % |
| 8 Wochen, dasselbe mit mind. 6 von 8 | 14,5 % | 66 %; fallend oder steigend **91 %** |
| 28 Tage, 3-h-Fenster an mind. 18 von 28 Tagen fallend | 9,2 % | **98 %** (24 Startstunden, fallend oder steigend) |
| 56 Tage, dasselbe an mind. 36 von 56 Tagen | 2,2 % | 61 % |
| 8 Wochen, Mittel je Stunde: beste und schlechteste Stunde | — | **±13 bp** (Median, reiner Zufall) |

Wer in 4–8 Wochen nach „immer“-Mustern sucht, findet fast sicher welche. Das Modul zeigt deshalb zu jeder Beobachtung, wie oft der
Zufall sie liefert, und zwar bereinigt für die Suche (R5).

## 3. Grundregeln (fest eingebaut)

1. **Die Historie schätzt, das Fenster filtert.**
   - Parameter, Profile und Nullverteilungen kommen aus rund drei Jahren 30-min-Kerzen: `klines30` (BTC vorhanden), die übrigen
     Coins über `hl_timestats` nachladen, soweit Binance-Futures sie führen.
   - Das 4–8-Wochen-Fenster liefert den Zustand.
   - Warum: Acht Wochen enthalten 8 unabhängige Wochenausgänge, 56 Tagesausgänge, 10–25 Beine und 2–4 Schwankungsregime. Das ist zu
     wenig zum Schätzen, genug zum Einordnen.
2. **Jede Statistik gegen ihre Zufallsweg-Null**, in drei Stufen:
   - (a) geschlossene Formeln der Brownschen Bewegung (D/θ, Exp(θ), 1/2, 2/3, Retracement-Verteilung, Berührformel);
   - (b) schwankungserhaltende Surrogate: GARCH-t je Coin, Vorzeichen-Zufall bei gleichen |Renditen|;
   - (c) stationärer Block-Bootstrap.
3. **Kausal („as of“).**
   - Segmentierungen werden zu jedem Zeitpunkt gespeichert, wie sie damals aussahen; keine nachgezeichnete ZigZag-Linie.
   - Keine zweiseitigen Glätter.
   - Nur gefilterte Regimewahrscheinlichkeiten, keine geglätteten.
   - Bewertung mit Embargo von mindestens der Horizontlänge.
4. **Verteilungen statt Punkte.**
   - Bewertung mit CRPS, Log-Score, PIT-Histogramm und Bandtreffern.
   - Baseline ist der Zufallsweg mit HAR-Schwankung, nicht „50 %“.
5. **Schwankung normieren.** Schwellen θ, Beingrößen und Analog-Ausgänge stehen in Einheiten der jeweiligen Schwankung, so werden
   ruhige und turbulente Phasen vergleichbar.
6. **Zwei Uhren.**
   - New York (mit Sommerzeit und US-Feiertagen) für US-Sitzung, ETF-Fixing und Makrotermine; 8:30 ET ist im Winter 13:30 UTC.
   - UTC für Börsenmechanik: Funding zentraler Börsen um 0/8/16 Uhr, volle Stunde.
   - Berliner Zeit nur zur Anzeige.
7. **Vorab festgelegt und gezählt.**
   - Hypothesen, Schwellen, Prüfgrößen und Termine stehen fest, bevor Daten da sind.
   - Jede probierte Konfiguration wird gezählt (Deflated Sharpe, PBO); Holm über Hypothesenfamilien.
8. **Schatten zuerst.**
   - Keine Wirkung auf v1, v2, v3, Fusion, Kaskaden, Labor oder Familien, bevor ein Baustein sein vorab festgelegtes Urteil
     bestanden hat.
   - In die Fusion frühestens nach dem 25.10.

## 4. Bausteine

### 4.1 R1 — Zwei-Uhren-Profil der Schwankung (Kernbaustein)

**Zweck:** sagen, *wann* Bewegungen groß werden, und die Renditen für alle anderen Bausteine vom Tagesrhythmus bereinigen. Ohne diese
Bereinigung verzerrt der Tagesrhythmus die Abhängigkeit der Schwankung (Andersen & Bollerslev 1996), und ein Detektor auf rohen
30-min-Daten würde die US-Sitzung als „Regime“ melden.

**Rechnung:**
- Multiplikative Zerlegung: r_t = σ_Tag(t) · s(t) · ε_t, wobei s(t) im Wochenmittel quadratisch 1 ist.
- log s²(t) besteht aus:
  - einer Fourier-Reihe in **New Yorker Tageszeit** (k = 1…4 Harmonische, Andersen & Bollerslev 1997);
  - eigenen Wochenendformen (Samstag, Sonntag) und einem US-Feiertagszustand;
  - **UTC-Zuschlägen** für die Funding-Zeiten 0/8/16 Uhr und die Tagesgrenze;
  - optional Termin-Zuschlägen für 8:30 ET (Datentage) und 14:00 ET (FOMC). Dafür ist ein kleiner Terminkalender je Jahr nötig.
- Geschätzt wird sprungrobust (Boudt, Croux & Laurent 2011), auf der Historie je Coin. HYPE, XMR und ZEC werden zum BTC/ETH-Profil
  geschrumpft; PAXG bekommt ein eigenes Profil (Gold: London/COMEX-Zeiten als Hypothese).
- **Das Fenster passt drei Größen an:**
  - das Niveau (steckt in σ_Tag);
  - die Höhe des US-Buckels, die mit dem Volatilitätsregime wachsen darf (Andersen, Thyrsgaard & Todorov 2019);
  - den Wochenendfaktor.

  Alle drei sind per empirischem Bayes zur Historie geschrumpft. 4–8 Wochen reichen für die grobe Form (rund 10–19 % relativer
  Fehler je Stundenslot), nicht für 168 Zellen Wochentag × Stunde (35–50 % Fehler).

**Ausgabe:** Multiplikator je Stunde für die nächsten 7 Tage (RG1).

**Prüfung (Phase 0):** Log-Likelihood-Gewinn außerhalb der Stichprobe (monatlich neu geschätzt, Folgemonat bewertet) gegen:
- ein flaches Profil;
- ein reines UTC-Profil;
- das heutige `Zeitprofil` der Prognose.

Dazu ein **Sommerzeit-Versuch** (Abschnitt 4.5): Am 25.10. stellt Europa um, am 01.11. die USA.
- Folgt der Buckel New York, bleibt er am 25.10. in UTC stehen und rückt am 01.11. eine Stunde später (10 Uhr New York = 14 bzw.
  15 Uhr UTC). In Berliner Zeit liegt er nur in der Woche dazwischen eine Stunde früher.
- Folgt er UTC, rückt er in Berliner Zeit am 25.10. dauerhaft eine Stunde früher und am 01.11. nicht mehr.

### 4.2 R2 — Bewegungsgröße über 1–7 Tage: Spannweite, Berührwahrscheinlichkeit, „Restbudget“

**Zweck:** die Größe der nächsten Bewegungen vorhersagen. Das ist der prognostizierbare Kern und die Antwort auf „die Bewegungen
sind größer als unsere Prognose“.

**Rechnung:**
- **HAR** auf bereinigter realisierter Varianz mit 1-, 7- und 30-Tage-Komponenten, log-Form, je Coin auf der Historie geschätzt
  (Corsi 2009; Bitcoin: Shen, Urquhart & Wang 2020; Bergsli et al. 2022). Volumen geht als Zusatzgröße ein, für BTC zusätzlich die
  implizite Volatilität DVOL aus `makro.db`; DVOL ist ab etwa 7 Tagen besser als HAR, kombiniert am besten (Hoang & Baur 2020).
- Daraus die **integrierte Varianz V(h)** über den Horizont, verteilt auf die Stunden mit s(t)² aus R1.
- **Erwartete Spannweite:** E[Hoch − Tief] ≈ 1,60·√V, mit Band aus der Verteilung der HAR-Fehler.
- **Berührwahrscheinlichkeit** eines Niveaus im log-Abstand d: P ≈ 2·[1 − Φ((d + 0,5826·σ_Bar)/√V)] (Spiegelungsprinzip mit
  Korrektur für diskrete Bars nach Broadie, Glasserman & Kou 1997). Weil V zeitlich verteilt ist, ergibt sich auch das
  **wahrscheinlichste Zeitfenster** der Berührung.
- **Restbudget:** erwartete Spannweite des laufenden Tags minus bereits erreichte, also wie viel Bewegung bis Tagesende noch zu
  erwarten ist. Das ist eine reine Größenaussage, keine Richtung.
- **Ränder:** standardisierte HAR-Residuen (Student-t). Nachts und am Wochenende gilt ein eigener Randparameter für dünne
  Liquidität: große Bewegungen entstehen oft dort (ParaFi 2026, Branchenquelle).

**Ausgabe:** RG2 (Spannweite 24 h, 72 h, 7 T; Restbudget), RG3 (Berührwahrscheinlichkeiten markanter Niveaus mit Zeitfenster).

**Prüfung:**
- QLIKE gegen EWMA und gegen das heutige Band.
- Bandtreffer im 80-%-Band innerhalb ±2 SE.
- Zuverlässigkeitsdiagramm der Berührwahrscheinlichkeiten (Steigung 0,8–1,2) je Coin und Horizont.

**Bezug:**
- Das HAR ist dasselbe wie in U109 (HAR-RV, konforme Bänder) und wird nur einmal gebaut. R2 ergänzt es um das Zwei-Uhren-Profil,
  die Spannweite, die Berührwahrscheinlichkeit und das Restbudget; die konformen Bänder aus U109 sind eine Variante der RG2-Bänder
  und werden in P0.2 mitgeprüft.
- R2 ist die σ(t)-Hälfte von U116 (Strukturgleichung als Verteilung).
- Nach dem 25.10. kann R2 auch Nullmodell für Magnet (U110) und Kaskaden werden, aber erst nach deren Auswertung.

### 4.3 R3 — Regime-Zustand: schneller Bruchmelder, langsamer Zustand, „seit wann“

**Zweck:** den aktuellen Zustand bestimmen und die Fensterlänge an ihm ausrichten.

**Schneller Bruchmelder:** CUSUM auf bereinigten quadrierten 30-min-Renditen (Schwankung ↑/↓), dazu auf Funding-Niveau und
OI-Wachstum.
- Die Fehlalarmrate ist vorab gesetzt: 1 je 30 Tage und Coin.
- Erwartete Verzögerung: Verdopplung der Volatilität ≈ 4,5 h, Halbierung der Varianz ≈ 38 h. Beruhigung wird langsamer erkannt als
  Turbulenz.

**Langsamer Zustand:** statistisches Jump-Modell mit 2–3 Zuständen (Nystrup et al. 2020; greedy online, ohne Latenz) auf
Tagesmerkmalen:
- log-Schwankung (EWMA, Halbwertszeit 10 und 20 Tage, entspricht 4 und 8 Wochen);
- Schwankung der Schwankung;
- Trendstärke (t-Wert der 28-T-Drift);
- Effizienzquote 14 T (|Nettobewegung| ÷ Summe |Bewegungen|);
- Varianzquote (1 T gegen 6 h, 28 T);
- Funding-z, OI-Wachstum 7 T, Liquidationsintensität.

Der Strafparameter wird auf der Historie so gewählt, dass Regime im Mittel rund zwei Wochen dauern (wie bei Ardia et al. 2019:
14–17 Tage). Ausgegeben werden **Wahrscheinlichkeiten, keine harten Etiketten**.

**„Seit wann“:** BOCPD (Adams & MacKay 2007) liefert die Laufzeit seit dem letzten Bruch. Daraus folgt die **Fensterlänge
W = Laufzeit, begrenzt auf 14–56 Tage**. Zusätzlich werden Schätzungen aus 2, 4 und 8 Wochen und der Historie mit Fixed-Share-
Gewichten kombiniert (Pesaran & Pick 2011: der Mittelwert über Fenster schlägt jedes einzelne „außer bei den kleinsten Brüchen“).

**Ausgabe:** RG4 (Regime-Lage, seit wann, Bruchalarm).

**Wofür (und wofür nicht):**
- **Ja:** Bänder je Zustand verbreitern; Momentum (R6) nur im Trendzustand.
- **Ja, Regime-Bilanz der vorhandenen Treiber:** Giacomini-White-Test mit Zustandsindikatoren, also welcher Treiber, welche Familie
  und welche Labor-Strategie in welchem Regime trägt. Das ist billig und klärt, warum Treiber im Mittel bei 50 % liegen. Es gilt als
  vorab festgelegter, beschreibender Teil; keine Gewichtsänderung vor dem 25.10.
- **Nein:** keine Richtungsprognose aus dem Etikett. Prognostizierte Regime korrelieren mit Renditen zu rund 2 % (Shu, Yu &
  Mulvey 2024).

**Prüfung:**
- Verzögerung und Fehlalarme mit eingepflanzten Brüchen in der Historie (Positivkontrolle) und auf GARCH-Pfaden (Null).
- Der Nutzen zeigt sich als bessere Bandtreffer von R2 mit gegen ohne Zustand.

### 4.4 R4 — Stufen und Beine (Directional Change mit Schwellengitter)

**Zweck:** das Stufenschema des Nutzers automatisch und kausal erkennen. Ausgegeben werden das laufende Bein, die Rücksetzer-Zone und
die nächste Stufe, jeweils gegen die Zufallsgeometrie.

**Segmentierung:**
- **Gitter von Schwellen** θ_k = c_k·σ̂_Tag mit c ∈ {1,0; 1,25; 1,5; 1,75; 2,0}, also 2–3-Tage-Beine bei c ≈ 1,4–1,7.
- θ wird je Bein bei der Bestätigung festgehalten, damit die Schwelle nicht flattert.
- Live auf 1-min-Hyperliquid-Bars. Auf der Historie (30 min) gilt eine konservative Reihenfolge von Hoch und Tief, wenn die
  Spannweite einer Bar θ übersteigt; bei HYPE, XMR und ZEC kommt das vor.
- Gespeichert wird jedes bestätigte Extremum „as of“ (Zeit der Bestätigung, Zeit und Kurs des Extremums, θ).
- Statt eines θ wird der **Anteil zustimmender Schwellen** berichtet (nach Gerlach, Demos & Sornette), z. B. „aufwärts in 4 von 5“.

**Zustand je θ:**
- Richtung;
- Alter in Einheiten θ²/σ² (unter dem Zufall ≈ 1 je Bein);
- Größe bisher in θ und Überschießen bisher;
- Rücksetzer vom laufenden Extremum D/θ;
- die letzten bestätigten Hochs und Tiefs.

**Regime-Statistik des Fensters** (beschreibend, mit Zufallsvergleich):
- Zahl der Beine;
- Ū und D̄ (mittlere Auf- und Abwärtsbeine in θ) und ihre **Asymmetrie** mit z-Wert gegen den Zufall: Ein Bein streut um θ, der
  Standardfehler ist θ/√n;
- Dauerquote;
- Anteil höherer Tiefs gegen 1/2 und höherer Hochs nach höheren Tiefs gegen 2/3;
- Median der Rücksetzertiefe gegen die geschlossene Verteilung P(R < r) = r·e^−(1/r − 1)/(1 + r).

In 4 Wochen (je rund 6 Auf- und Abwärtsbeine) hat die Differenz Ū − D̄ einen Standardfehler von rund 0,6θ. Sicher erkennbar
(80 % Teststärke) wäre erst eine Asymmetrie von rund 1,6θ; in 8 Wochen (je rund 12 Beine) wären es rund 1,1θ. Das Fenster ordnet
ein, die Historie prüft.

**Prognosen:**
- (a) **Endet das laufende Bein binnen 24 bzw. 72 h?**
  - Baseline ist die geschlossene Form: Bei Rücksetzer D ist das Extremum mit Wahrscheinlichkeit D/θ schon endgültig; dazu die
    Zufalls-Hazardrate. Sie ist bei jungen Beinen nahe null und danach flach, etwa π²/8 je Einheit θ²/σ².
  - Ein kleines logistisches Modell auf der Historie (gepoolt, geschrumpft) darf diese Baseline nur verschieben. Eingänge: Alter,
    Größe, Asymmetrie- und Momentumzustand, Schwankungszustand, Teilnehmer aus R7.
  - Es zählt nur, wenn es D/θ im Brier- und Log-Score außerhalb der Stichprobe schlägt.
- (b) **Rücksetzer-Zone:**
  - Verteilung der nächsten Gegenbewegung in θ (Historie, bedingt auf den Zustand) × aktuelles θ ergibt Preiszone (Median,
    25–75 %).
  - Darin werden Liquidationscluster (Kaskaden-Heatmap) und runde Zahlen markiert. Liquidationen wirken wie Stop-Loss-Orders,
    und gehäufte Stop-Loss-Orders beschleunigen den Kurs nach Osler (2001) eher, als ihn zu stoppen. Ob ein Cluster also
    **Beschleuniger** statt Boden ist, ist für Krypto ungeprüft (R7, T3).
  - Dazu die Berührwahrscheinlichkeit der Zone binnen 72 h aus R2.
  - Die Tiefe in Prozent ist vor allem eine Schwankungsprognose.
- (c) **Nächste Stufe:** P(höheres Tief) und P(höheres Hoch | höheres Tief) aus der Historie im ähnlichen Zustand, **immer neben 1/2
  und 2/3**.

**Ausgabe:** RG5 (Bein-Zustand), RG6 (Rücksetzer-Zone, nächste Stufe), RG7 (Stufen-Asymmetrie des Regimes).

**Prüfung (Phase 0):**
- Alle Beinstatistiken je Coin und θ gegen die drei Null-Stufen.
- **Persistenz:** Sagt die Asymmetrie eines 4- bzw. 8-Wochen-Fensters die Asymmetrie der folgenden 4 Wochen voraus? Das ist
  Momentum auf Beinskala; geprüft per Regression über rollierende Fenster mit Block-Bootstrap.
- Beinende-Prognose gegen D/θ (Diebold-Mariano mit Coroneo-Iacone-Werten).

**Bezug:** Die Vorbedingungen (U131) zählen Bewegungen ≥ 3 % binnen 24 h. R4 mit θ = 3 % liefert dieselben Wendepunkte als Beine
und verknüpft beide Listen; U131 selbst bleibt unverändert.

### 4.5 R5 — Zeitmuster der Richtung: vorab festgelegte Fenster statt Suche

**Zweck:** die Beispiele des Nutzers („2–5 Uhr fällt“, „Samstagnacht fällt“) ehrlich prüfen und live einordnen.

**Teststärke:** BTC-Tagesschwankung 2,24–2,80 % (Eingangswerte der Recherche), Wochenende mit Schwankungsfaktor 0,6; zweiseitig
5 %, Teststärke 80 %, ein vorab gewähltes Fenster. Eigene Rechnung; die Recherche rechnet die Fenster teils einseitig, dann rund
10 % kleiner.

| Muster | Nachweisgrenze in 4 Wochen | in 8 Wochen | in 3 Jahren | Datenbedarf für einen realistischen Effekt |
|---|---|---|---|---|
| eine Stunde | 24–30 bp | 17–21 bp | 3,9–4,8 bp | 5 bp/h: 660–1.030 Tage (vorab gewählt), 3,5–5,5 Jahre (nach Suche über 24 h) |
| 02–05 Uhr | 42–52 bp je Nacht | 30–37 bp | 6,7–8,4 bp | −9 bp je Nacht: 610–950 Tage |
| ein Wochentag | 3,1–3,9 % | 2,2–2,8 % | 0,5–0,6 % | 44 bp: 3,9–6,1 Jahre |
| Samstagnacht (6 h) | 0,9–1,2 % | 0,7–0,8 % | 0,15–0,19 % | −10 bp: 7–11 Jahre |

**Daraus:**
- **Keine 168-Zellen-Schätzung aus dem Fenster.**
- **Historie (3 Jahre):**
  - Stunde (24) und Wochentag (7) mit HAC-Standardfehlern, Benjamini-Hochberg q = 0,10 und Vorzeichen je Jahr.
  - Dazu **höchstens drei vorab festgelegte Hypothesen**, Holm über die drei, Vorschlag:
    - K1 „02–05 Uhr Berliner Zeit fällt im Mittel“ (Hypothese des Nutzers);
    - K2 „Samstagnacht (Sa 22 – So 04 Uhr Berliner Zeit) fällt im Mittel“ (Hypothese des Nutzers);
    - K3 „US-Kernsitzung (9:30–16:00 New York) schwächer als der Rest“ (Literatur: „über Nacht schlägt US-Handelszeit“ seit dem
      ETF-Start, Branchenquelle).
  - Jede Hypothese wird zusätzlich auf **Persistenz** geprüft: Sagt das 8-Wochen-Mittel des Fensters die Folgewoche voraus? Das ist
    der Test nach Heston, Korajczyk & Sadka (2010), für Krypto bisher nicht repliziert.
- **Uhren-Versuch zur Zeitumstellung 25.10./01.11.2026:**
  - In der Woche dazwischen liegt Berlin nur fünf statt sechs Stunden vor New York.
  - K1 liegt im Sommer bei 00–03 UTC, im Winter bei 01–04 UTC.
  - Für die Richtung ist die Teststärke gering; für die Schwankung (R1) reicht sie, um zu sehen, welcher Uhr der Buckel folgt.
- **Live-Beobachtung:**
  - Für K1–K3 und das jeweils auffälligste Fenster des Zeitraums: Zahl negativer Nächte, Mittel ± Standardfehler, Wahrscheinlichkeit
    unter dem Zufall für das vorab gewählte Fenster und **für die Suche über alle Fenster** (Simulation mit der aktuellen
    Schwankung).
  - Klar gekennzeichnet als „Beobachtung, kein Treiber“ (RG8).
- **Werkzeug:** `hl_timestats.py --test-window 02:00-05:00 --tz Europe/Berlin` prüft heute die Größe der Bewegungen. Es wird um
  Richtung und Persistenz erweitert; die 336-Felder-Heatmap bleibt.

**Erwartung nach Literatur und Teststärke:** K1–K3 vermutlich nicht belegt. Eine Bestätigung von K1 über drei Jahre mit gleichem
Vorzeichen in jedem Jahr wäre ein echter Befund.

### 4.6 R6 — Mehrtägige Richtung: Wochenmomentum (klein, long/flat)

**Zweck:** die einzige halbwegs robuste Richtungsquelle auf Tagesskala nutzen.

**Rechnung:**
- Signal z = r_21T ÷ (σ̂_Tag·√21), daneben 14 und 28 T. Das sind drei Varianten, gezählt für den Deflated-Sharpe-Test.
- **Nur long oder flat**: Short-Portfolios verlieren in der Literatur meist (Han, Kang & Ryu, SSRN 4675565, Daten bis August
  2023).
- Zunächst nur BTC und ETH. Bei dünneren Coins gibt es eher Tagesumkehr (Zaremba et al. 2021); bei zehn Privacy-Coins schlug
  eine Durchschnittsregel 2016–2018 Buy-and-Hold nur bei Dash (Ahmed, Grobys & Sapkota 2020), XMR und ZEC erben also keine
  BTC-Trendparameter.
- Ausgabe als Neigung P(aufwärts 7 T) = 0,5 + κ·tanh(z), κ aus der Historie geschätzt und geschrumpft (erwartet ≤ 0,05).
- Aktiv nur im Trendzustand (R3).

**Ausgabe:** RG9.

**Prüfung (Phase 0):**
- Brier-Score gegen die Basisrate über 7 T auf drei Jahren (156 Wochen, kleinste nachweisbare Verbesserung d ≈ 0,22).
- Deflated Sharpe einer Long/Flat-Regel mit Kosten; PBO per kombinatorisch symmetrischer Kreuzvalidierung, abgelehnt bei > 0,05.

**Erwartung:** schwach. Das ist eine Überlagerung der Verteilung, kein Kern.

### 4.7 R7 — Teilnehmer an den Wendepunkten (das eigentliche „Reverse Engineering“)

**Zweck:** nicht aus Preisen auf latente Händlertypen zurückschließen, sondern **messen**, was die Gruppen an den Wendepunkten tun.
Latente Händleranteile sind aus wenigen Wochen Preisdaten nur schwach bestimmbar (Einschätzung der Recherche zu Platt 2020 und
Lux 2018). Hyperliquid erlaubt das direkt: Jia et al. (2026) klassifizieren
Wallets aus dem vollständigen Register.

**Messung je bestätigtem Bein (R4, as of) und Coin:**
- **Positionsänderung** der Gruppen über das Bein und den Rücksetzer, normiert auf ihren typischen Fluss: Pool (799 Konten), Darwin,
  Wale (direktional), Leaderboard, Elite, Smart Money (Top-50). Quellen sind `pool_positions`, `whale_positions`, `lb_pos_hourly` und
  die vorhandenen Fluss-Treiber.
- **Liquidationen** am Extremum (HL abgeleitet, Binance, drei Börsen) gegen normal: „Kapitulation“ an Tiefs, „Short-Squeeze“ an
  Hochs.
- **Funding und OI** über das Bein (Crowding).
- **Heatmap:** Lag das Extremum innerhalb 0,3θ eines großen Clusters (Cluster „abgeholt“), oder lief der Kurs hindurch
  (beschleunigt)? Mit Placebo-Karten von vor 3 Tagen, wie beim Magnet-Test.

**Fenstermerkmale (RG10):**
- **Dip-Käufer-Quote:** Anteil der Rücksetzer, in denen der Pool netto Long aufbaute;
- Verteilungsquote an Hochs;
- **Kapitulationsquote:** Tiefs mit Liquidationsausbruch;
- Cluster-Abhol-Quote gegen Placebo.

**Hypothesen (vorab festgelegt, vorwärts, gepoolt über Coins, Holm über drei):**
- **T1:** Rücksetzer, in denen der Pool netto Long aufbaut, enden flacher (Tiefe in θ) als solche, in denen er abbaut. Einseitiger
  Rangtest, mindestens 60 Rücksetzer aus mindestens 3 Coins.
- **T2:** Tiefs mit Liquidationsausbruch (≥ 3× normal) halten öfter, das heißt das folgende Tief ist höher, als Tiefs ohne.
  Gegen 1/2 und gegen die Quote ohne Ausbruch.
- **T3 (Osler):** Nach dem Durchbruch eines großen Liquidationsclusters ist das Überschießen größer als die Zufallserwartung θ,
  gegen Durchbrüche von Placebo-Niveaus.

**Datenlage:**
- Kontodaten seit Mitte September 2026. Gezählt werden nur Beine, die **nach dem Festschreiben** bestätigt werden (vorwärts, wie
  beim Schatten der Darwin-Liste).
- Bei θ ≈ 1,2–1,6σ entstehen je Coin 10–17 Beine in 4 Wochen (Abschnitt 2). Über sechs Coins sind 60 Rücksetzer nach 6–8 Wochen
  erreichbar; BTC und ETH laufen oft gleichzeitig, deshalb Bootstrap nach Zeitblöcken.
- **Urteil frühestens am 16.12.2026**, sonst am 13.01.2027 mit denselben Bedingungen.

**Grenze:** Eine Person kann mehrere Wallets steuern. Gruppen sind Näherungen.

### 4.8 R8 — Regime-Analoge und Pfadfächer (Szenarien)

**(a) Regime-Analog**, ein **paralleler** Schatten-Experte; die vorhandene Analog-Suche bleibt bis zum 25.10. unverändert:
- **Zustand:** höchstens 4–5 schwankungsnormierte Merkmale: r_1T/σ, r_7T/(σ√7), r_28T/(σ√28), log(σ_7T ÷ σ_90T) und der
  Bein-Zustand (Richtung × D/θ). Heute sind es neun, und der Fluch der Dimension trifft: Bei 10 Dimensionen liegt der 50. Nachbar
  im relativen Abstand 0,73 statt 0,46 bei vier Dimensionen, die Abstände werden fast gleich, und die Prognose fällt auf den
  Durchschnitt zurück (Rechnung der Recherche nach Platzer et al.).
- **Gewichte:**
  - Merkmalsgewichte per Maximum Likelihood („Empirical Similarity“, Gilboa et al. 2006);
  - dazu weiche Kerne für die **Regime-Ähnlichkeit** (Fingerabdruck der 4–8 Wochen: Schwankungsniveau, Schwankung der Schwankung,
    Asymmetrie, Funding-z, OI-Wachstum) und für die Aktualität.
- **Ausgänge** in Einheiten der damaligen Schwankung, mit der R2-Prognose zurückskaliert.
- Nur Analoge, deren Ausgang vor dem Prognosezeitpunkt vollständig vorlag.
- **Mindestabstand** max(h, 1 Tag) zwischen Nachbarn.
- **Effektive Analogzahl** (Kish) ≥ 20, sonst wird der Kern breiter.
- **Ausgabe:** Verteilungsform (Schiefe, Ränder) für 24 h, 72 h und 7 T, nicht der Median (RG11).

**(b) Pfadfächer** (U116 erweitert, das „Modell des Regimes“):
- 5.000 Pfade je Coin alle 4 h, 7 Tage weit.
- σ(t) aus R2 × R1; Zustandswechsel aus dem Jump-Modell (R3).
- Student-t-Innovationen; später Sprünge aus Kaskaden bzw. eine Hawkes-Komponente für Liquidationen. Hawkes nur auf stationären
  Abschnitten schätzen, sonst wird die Verzweigungsrate künstlich ≈ 1 (Filimonov & Sornette 2015).
- Drift = R6-Neigung oder null.
- Auf jedem Pfad läuft die R4-Segmentierung. So entsteht die Verteilung des **nächsten Wendepunkts** (Zeit und Kurs) und der
  Berührungen von Zonen (RG12).
- **Ehrliche Grenze:** Ein an die Fakten des Fensters angepasstes Modell erklärt diese Fakten. Prognosegüte zeigt erst der CRPS
  gegen einfachere Baselines; in der Literatur liegen solche Modelle bei der Schwankung etwa auf GARCH-Niveau und zeigen keine
  Richtungsgüte.

**Prüfung:**
- CRPS bzw. Energy Score gegen den Zufallsweg mit HAR-Schwankung und gegen flache Schwankung.
- PIT-Histogramm und Bandtreffer.
- Diebold-Mariano mit Coroneo-Iacone-Werten, auf der Historie (rollierend, monatlich neu geschätzt) und vorwärts.
- Regime-Analog gegen die vorhandene Analog-Suche (CRPS je Horizont).

## 5. Die neuen Anzeigen (Indikatoren)

| Nr. | Anzeige | Inhalt | Status bis zum Urteil |
|---|---|---|---|
| RG1 | Schwankungsprofil 72 h | Multiplikator je Stunde, Hauptzeitfenster („morgen 15–18 Uhr ×1,6“) | Anzeige |
| RG2 | Erwartete Spannweite | 24 h / 72 h / 7 T: Median und 80-%-Band, in % und Preis; Restbudget des Tags | Anzeige, danach Experte |
| RG3 | Berührwahrscheinlichkeiten | markante Niveaus (Cluster, letzte Extrema, runde Zahlen, Rücksetzer-Zone) binnen 24/72 h mit wahrscheinlichstem Zeitfenster | Anzeige |
| RG4 | Regime-Lage | P(ruhig / normal / turbulent) bzw. Trend / Seitwärts, seit wann (Laufzeit), Bruchalarm, Fensterlänge W | Anzeige, Risikofilter |
| RG5 | Bein-Zustand | Richtung (Zustimmung der Schwellen), Alter, Größe in θ, D/θ, P(Bein endet 24/72 h) **neben der Zufallsbaseline** | Anzeige, danach Experte |
| RG6 | Rücksetzer-Zone / nächste Stufe | Preiszone (Median, 25–75 %) mit Clustern und runden Zahlen; P(höheres Tief) neben 1/2, P(höheres Hoch \| höheres Tief) neben 2/3 | Anzeige |
| RG7 | Stufen-Asymmetrie | Ū ÷ D̄ in θ, z gegen Zufall, 4 / 8 Wochen / kombiniert, Historienvergleich | Anzeige |
| RG8 | Zeitfenster-Beobachtung | K1–K3 und auffälligstes Fenster: Zählung, Mittel ± SE, Zufallswahrscheinlichkeit vorab und nach Suche | Beobachtung |
| RG9 | Wochenmomentum-Neigung | P(aufwärts 7 T) − 0,5, nur BTC/ETH, nur im Trendzustand, geschrumpft | Anzeige, danach Experte |
| RG10 | Teilnehmer an Wendepunkten | Dip-Käufer-, Verteilungs-, Kapitulations-, Cluster-Abhol-Quote (mit Placebo) | Messung, Hypothesen T1–T3 |
| RG11 | Regime-Analog | Verteilungsform 24 h / 72 h / 7 T, effektive Analogzahl | paralleler Schatten-Experte |
| RG12 | Pfadfächer und nächster Wendepunkt | Quantile je Stunde über 7 T; Verteilung von Zeit und Kurs des nächsten Extremums | Anzeige, danach Experte |

**Beispiel einer Bein-Anzeige (erfundene Zahlen, nur zur Form):**
> BTC · Bein aufwärts (4 von 5 Schwellen) seit 2,3 T (1,0 θ²/σ²), +6,1 % = 2,3θ (θ = 2,6 % = 1,5σ) · Rücksetzer vom Hoch 0,9 %
> (D/θ 0,35: im Zufall ist das Hoch damit zu 35 % schon endgültig; Modell 41 %, nicht belegt) · Rücksetzer-Zone 81.300–82.400
> (Median 1,3θ), darin Cluster 19,8 Mio bei 82.319 · Berührung binnen 72 h 58 %, am ehesten morgen 15–19 Uhr · P(höheres Tief)
> 0,55 (Zufall 0,50), P(höheres Hoch | höheres Tief) 0,69 (Zufall 0,67) — Abweichungen nicht belegt.

**Beispiel einer Zeitfenster-Beobachtung (erfundene Zahlen):**
> 02–05 Uhr (Berlin), letzte 8 Wochen: 33 von 56 Nächten negativ, Mittel −0,06 % ± 0,09 % · so viele negative Nächte im Zufall
> für dieses vorab gewählte Fenster: 11 %, für irgendein 3-h-Fenster (fallend oder steigend): über 99 % · Historie 3 Jahre:
> −0,02 % ± 0,02 % — nicht belegt.

## 6. Anzeige (Abschnitt „RG Regime“)

**Kopf je Coin:** Regime-Lage mit Laufzeit, Bruchalarm, Bein-Zustand, Spannweite 24 h, Restbudget des Tags.

**Chart (8 Wochen + 7 Tage voraus):**
- Kurs mit den bestätigten Extrema (as of; das laufende Bein gestrichelt);
- Rücksetzer-Zone schraffiert, Liquidationscluster als Marken;
- Pfadfächer (10/25/50/75/90 %);
- darunter die Leiste des Schwankungsprofils für 72 h.

Gleiche Zeitachse, keine zweite y-Achse (wie die Kursleiste U132).

**Tabellen:** Stufen-Statistik gegen Zufall (RG7), Zeitfenster-Beobachtung (RG8), Teilnehmer (RG10), Prüfstand (Abschnitt 9) mit
„belegt / nicht belegt / offen“ je Baustein.

**Lesehilfe unter jeder Zahl:** was der Zufall liefert. Kein Wert ohne Baseline.

**Debug-Einträge:**
- „★ Regime: Vorprüfung auf der Historie (U138)“ (Phase 0);
- „★ Regime: Stand und Prüfstand“ (Phase 1).

Wochenprüfung (mittwochs 19:00) mit dem Stand.

## 7. Daten, Speicher, Takt, Last

- **Historie:** `klines30` (Binance USDT-M 30 min, BTC ≈ 52.600 Zeilen). ETH, HYPE, ZEC, XMR und PAXG werden mit `hl_timestats`
  nachgeladen, soweit Binance-Futures sie führen; was fehlt, wird zu BTC/ETH geschrumpft. Funding-Historie von Binance gibt es
  bereits in `makro.db` (Tagessumme BTC); für die übrigen Coins bei Bedarf über das Binance-Archiv, das der Pi erreicht (OI-Archiv
  des Makro-Moduls).
- **Live:** 1-min-Bars (`bars`), Funding/OI, Liquidationen (HL, Binance, drei Börsen), Positionen (`pool_positions`,
  `whale_positions`, `lb_pos_hourly`), Heatmap-Cluster.
- **Speicher:** Prognosespeicher, `learned` „<coin>“/„regime“ (Stand), dazu neue Tabellen:
  - `regime_hist` (stündlich je Coin, kompakt);
  - `regime_extrema` (bestätigte Extrema je Coin und θ, as of; Pflicht gegen Nachzeichnen);
  - `regime_prognose` (Verteilungen mit Ausgangszeitpunkt, zur Bewertung).

  Schreiben mit BEGIN IMMEDIATE.
- **Takt:**
  - R1, R2 und der Bruchmelder: stündlich bzw. je 30-min-Bar.
  - Jump-Modell und BOCPD: täglich.
  - R4 inkrementell je Bar.
  - R7 bei jeder Bestätigung.
  - R8a stündlich.
  - Pfadfächer alle 4 h: 5.000 × 336 Schritte × 6 Coins ≈ 10 Mio. Schritte, mit numpy wenige Sekunden.
  - Phase 0 einmalig, wenige Minuten.
- **Last auf dem Pi** heute: Last 2,1 von 4 Kernen, 5,75 GB RAM frei, 52–55 °C. Das reicht. Der Pfadfächer läuft gestaffelt, nicht
  zur vollen Stunde, wenn die anderen Berichte rechnen.

## 8. Einbindung ins bestehende System (keine Doppelungen)

| Vorhanden | Verhältnis zum Regime-Modul |
|---|---|
| v1, v2, v3, Fusion (4 h / 24 h) | unberührt bis zum 25.10.; danach belegte Bausteine (RG2, RG5, RG9, RG12) als neue Experten über Fixed Share, Prüffrage: Fusion mit gegen ohne |
| Zeitprofil der Prognose (Schwankung je Wochentag und Stunde) | R1 läuft parallel; ersetzt es erst nach bestandenem Test und nach dem 25.10. |
| Regime-Flags und Band-Multiplikator (`hl_indikatoren.regime`: Schwankung 24 h gegen 20 Tage, OI-Überhitzung, Liquidationsintensität, Taker-Varianz; Treiber „Vol-Spike-Reversion“) | bleiben bis zum 25.10. unverändert. R3 liefert denselben Zustand als Wahrscheinlichkeit mit „seit wann“, R2 die Bandbreite; P0.2 und V1 prüfen die R2-Bänder gegen das heutige Band mit Multiplikator. Ersatz erst nach Beleg (Phase 3) |
| U109 Schwankung (HAR-RV, konforme Bänder, Grid-Variante) | dasselbe HAR wie R2, nur einmal gebaut; die Grid-Variante bleibt eine eigene Labor-Kennung |
| `hl_timestats.py` (336 Felder Bewegungsgröße, Fenstertest) | Datenlader `klines30` wird mitbenutzt; der Fenstertest wird um Richtung und Persistenz erweitert (R5) |
| Analog-Suche (9 Merkmale, k = 50, global) | R8a als paralleler Experte „Analog-Regime“; keine Änderung am bestehenden vor dem 25.10. |
| U116 Strukturgleichung als Verteilung | R2 + R8b sind deren Ausbau; U116 wird darin aufgehen |
| Kaskaden, Magnet (Heatmap-Cluster, Nullmodell) | R4 und R7 lesen die Cluster; R2 als künftiges Nullmodell erst nach U110/U115 |
| Ereignis-Profile U43, Vorbedingungen U131 | R4 verknüpft deren Ereignisse mit Beinen; beide bleiben unverändert |
| Makro (Zyklus, Jahre) | Kulisse; das 4–8-Wochen-Regime liegt darunter |
| Aktive Profis, Darwin, Pool | R7 liest Positionen und Gruppen, schreibt nichts |
| TradeLabor | neue Strategien nur mit **neuer Kennung** (Regeln eingefroren), Abschnitt 10 |
| Familien | später eventuell Familie „Regime“; nicht vor eigenen Urteilen |

## 9. Prüfplan — vorab festgelegt am 07.10.2026 (Entwurf; endgültig mit der Entscheidung des Nutzers)

### 9.1 Phase 0: Historie (rollierend, monatlich neu geschätzt, Embargo ≥ Horizont)

Je Coin, soweit Historie vorhanden, BTC zuerst:

| Nr. | Frage | Prüfgröße | „belegt“, wenn |
|---|---|---|---|
| P0.1 | Zwei-Uhren-Profil (R1) | Log-Likelihood außerhalb der Stichprobe gegen flach, UTC-only, heutiges Zeitprofil | Gewinn > 0 in ≥ 2/3 der Monate und gepoolt p < 0,05 |
| P0.2 | Bewegungsgröße (R2) | QLIKE gegen EWMA; 80-%-Bandtreffer; Zuverlässigkeit der Berührwahrscheinlichkeit | QLIKE besser (DM p < 0,05); Treffer im Band ± 2 SE; Steigung 0,8–1,2 |
| P0.3 | Bein-Statistik (R4) | Überschießen, P(höheres Tief), P(höheres Hoch \| höheres Tief), Retracement, Hazard gegen die drei Nullen; **Persistenz der Fenster-Asymmetrie** | Abweichung mit p < 0,05 nach Holm über Coins × θ **und** gleiches Vorzeichen in beiden Hälften |
| P0.4 | Beinende-Prognose (R4a) | Brier und Log-Score gegen D/θ-Baseline | DM (Coroneo-Iacone) p < 0,05 und Abdeckung ≥ 50 % der Beine |
| P0.5 | Kalender (R5) | K1–K3 (Holm), 24 Stunden und 7 Tage (BH q = 0,10), Persistenz nach Heston-Korajczyk-Sadka | wie links, Vorzeichen in jedem Jahr gleich |
| P0.6 | Wochenmomentum (R6) | Brier 7 T gegen Basisrate; Deflated Sharpe (3 Varianten, Kosten); PBO | DM p < 0,05, DSR ≥ 0,95, PBO ≤ 0,05 |
| P0.7 | Fensterkombination | QLIKE der Schwankung: 2 / 4 / 8 Wochen, EWMA, Historie, Mittel über Fenster | Kombination nicht schlechter als das beste Einzelfenster (± 1 SE) |
| P0.8 | Regime-Analog (R8a) | CRPS 24 h / 72 h / 7 T gegen bestehende Analog-Suche; effektive Analogzahl | DM p < 0,05 auf mindestens 2 Horizonten |
| P0.9 | Bruchmelder (R3) | Verzögerung und Fehlalarme mit eingepflanzten Brüchen; GARCH-Null | Fehlalarme ≤ 1,5 je 30 Tage, Verzögerung Verdopplung ≤ 12 h |

**Konsequenz:** Ein Baustein geht als Anzeige auch ohne Beleg in den Schatten, dann beschreibend und als „nicht belegt“ markiert.
Experte der Fusion kann nur werden, was hier belegt ist **und** vorwärts besteht.

### 9.1a Präzisierung für den Bau (07.10.2026 spät abends, Nutzer 23:34: „Lass uns mit Phase 0 beginnen“; vor jedem Lauf auf echten Daten)

Die Entwurfsbedingungen aus 9.1 sind hier so genau gefasst, wie der Code sie rechnet (`hl_regime.py`). Für die beiden offenen
Entscheidungen gelten die Empfehlungen: Kalenderhypothesen K1–K3 wie vorgeschlagen, alle Coins mit Historie.

**Gemeinsam:**
- **Daten:** 30-min-Kerzen der USDT-Perpetuals, bis 1.096 Tage je Coin, in einer eigenen Datei `regime.db` neben der
  Hauptdatenbank.
  - Quelle je Coin ist die mit der längeren Historie (Binance-Futures, sonst Bybit); sie wird beim ersten Laden festgehalten.
  - `klines30` in `hl_liq.db` bleibt unberührt. Die Analog-Suche der Prognose liest diese Tabelle; neue Coins dort würden die
    Prognose vor dem 25.10. ändern.
- **Mindestlänge:** 456 Tage (365 Tage Training und 3 Bewertungsmonate). Kürzere Coins erscheinen nur mit ihren Daten
  („zu kurz“).
- **Außerhalb der Stichprobe:** wachsendes Fenster, neu geschätzt zu jedem Monatsanfang (UTC), erster Bewertungsmonat nach 365
  Tagen. Embargo: Trainingsziele enden vor dem Monatsanfang.
- **σ̂_Tag:** EWMA der Tagesvarianz aus 30-min-Renditen (Halbwertszeit 20 Tage), kausal: am Tag d nur Tage vor d.
- **DM-Tests:** Coroneo-Iacone, also gewichtetes Periodogramm mit m = ⌊T^{1/3}⌋ und t-Verteilung mit 2m Freiheitsgraden,
  zweiseitig.

**P0.1 Zwei-Uhren-Profil.**
- Varianz einer 30-min-Bar: v = σ̂²_Tag / 48 · s². Vier Profile s²:
  - A flach;
  - B UTC: Fourier k = 1…4 der UTC-Tageszeit an Werktagen, k = 1…2 am Wochenende, Niveau Sa/So, Funding-Zuschläge (Bar vor
    und Bar nach 0/8/16 UTC);
  - C heutiges Zeitprofil: mittleres |r| je UTC-Wochentag × Stunde aus den letzten 180 Tagen, wie `hl_forecast`;
  - D zwei Uhren: wie B, aber Tageszeit und Wochentag in New York, dazu Zuschläge 8:30 und 9:30 ET an Werktagen; Funding in UTC.
- Form per Regression von log(r² + δ) − log(σ̂²/48); Niveau so normiert, dass im Training r²/v im Mittel 1 ist.
- Maß: Gauß-Log-Likelihood (QLIKE) je Bar, gemittelt je Monat.
- Belegt je Coin, wenn D gegen jedes von A, B und C in ≥ 2/3 der Monate gewinnt und der t-Test über die Monate p < 0,05 bei
  positivem Mittel ergibt.
- Beschreibend: Lage des Werktags-Buckels in UTC während Sommer- und Winterzeit in New York.

**P0.2 Bewegungsgröße.**
- HAR-log (1, 7, 30 Tage) gegen EWMA (λ 0,94) und gegen die 7-Tage-Schwankung (das σ des heutigen Bands).
- Ziel: Summe der Tagesvarianzen über h = 1, 3, 7 Tage; Maß QLIKE.
- Belegt je Coin, wenn alle drei Bedingungen gelten:
  - HAR schlägt EWMA bei h = 1 und h = 7 (DM p < 0,05);
  - das 80-%-Band (Quantile der standardisierten Rendite aus dem Training) trifft bei allen h innerhalb ± 2 SE (n_eff = Tage/h);
  - die Berührquoten haben eine Steigung von 0,8–1,2. Gemessen an Hoch und Tief der 30-min-Bars, Niveaus 0,5/1/1,5/2·√V je
    Seite, Soll 2[1 − Φ(k)].
- Beschreibend: realisierte Spannweite gegen 1,60·√V.

**P0.3 Beine.**
- c ∈ {1,0; 1,25; 1,5; 1,75; 2,0}; θ je Bein = c·σ̂_Tag beim Bestätigen des vorigen Extremums; Directional Change auf
  30-min-Schlusskursen.
- Sechs Größen mit Soll unter dem Zufallsweg:
  - Überschießen in θ (1);
  - Dauer in θ²/σ² (1);
  - P(höheres Tief) (1/2);
  - P(höheres Hoch | höheres Tief) (2/3);
  - Median des Rücksetzers, also Bein ÷ voriges Bein (1);
  - Asymmetrie Ū − D̄ in θ (0).
- Null: 100 Vorzeichen-Surrogate mit gleicher Drift (r* = μ + s·(r − μ)), also gleiche |Renditen|, gleiche θ und keine
  Richtungsabhängigkeit; z gegen Mittel und Streuung der Surrogate, p aus der t-Verteilung mit 99 Freiheitsgraden.
- Belegt je Größe, Coin und c: Holm über die Coins × c ergibt p < 0,05, und die Abweichung hat in beiden Hälften das gleiche
  Vorzeichen.
- Persistenz:
  - c = 1,5, Fenster 4 und 8 Wochen, wöchentlich: Korrelation der Asymmetrie mit der Asymmetrie der folgenden 4 Wochen, gegen
    dieselbe Korrelation in den Surrogaten;
  - Holm über Coins × Fenster;
  - belegt bei positivem ρ und gleichem Vorzeichen in beiden Hälften.

**P0.4 Beinende.**
- c = 1,5; alle 4 h innerhalb eines Beins mit D/θ in [0,1; 0,9]. Ereignis: Das laufende Extremum wird bestätigt.
- Drei Prognosen:
  - roh: D/θ;
  - kalibrierte Baseline: logistisch, Achsenabschnitt und Steigung auf logit(D/θ);
  - Modell: kalibrierte Baseline plus Alter, Größe bisher, Zeit seit dem Extremum, Schwankungszustand log(σ_1T/σ_20T),
    Momentum in Beinrichtung (r_21T/(σ√21)) und Asymmetrie der letzten 8 Wochen in Beinrichtung; Ridge mit λ = 2 % der
    Trainingsfälle.
- Gepoolt über Coins, monatlich neu geschätzt; Training nur mit Fällen, die vor dem Monatsanfang aufgelöst waren. Verlust je Bein
  summiert (jeder Prognosepunkt zählt wie im Training, das Bein ist der Klumpen), DM über die Beine in Zeitfolge.
- Belegt, wenn das Modell die kalibrierte Baseline im Log- und im Brier-Score schlägt (je p < 0,05) und Prognosen für ≥ 50 % der
  Beine vorliegen.
- Strenger als der Entwurf, der gegen D/θ prüfte: Ein Gewinn gegen D/θ allein kann bloß die Diskretisierung ausgleichen. Der Wert
  gegen D/θ wird mit berichtet.

**P0.5 Kalender.**
- K1: 02:00–05:00 Berliner Zeit, täglich; Tage mit Zeitumstellung fallen aus.
- K2: Sa 22:00 – So 04:00 Berliner Zeit, wöchentlich.
- K3: New York Mo–Fr, Rendite 9:30–16:00 minus Rendite vom Vortag 16:00 bis 9:30 (montags mit Wochenende; US-Feiertage nicht
  ausgenommen). **Seit 23.60 je Stunde verglichen:** Sitzung − (6,5 h ÷ Länge des Rests) × Rest; die Längen kommen aus den
  Zeitstempeln (17,5 h, montags 65,5 h, Zeitumstellungen eingeschlossen). Bis 23.59 roh, siehe Punkt 8 unten.
- Mittel mit HAC-Fehler (Newey-West, Lag 5 bzw. 2), zweiseitig, Holm über K1–K3.
- Belegt bei p_Holm < 0,05 und gleichem Vorzeichen in jedem Kalenderjahr mit ≥ 120 Tagen bzw. ≥ 26 Wochen.
- 24 UTC-Stunden und 7 UTC-Wochentage: Benjamini-Hochberg (q = 0,10) über die 31 Tests und gleiches Vorzeichen in jedem Jahr.
- Persistenz nach Heston, Korajczyk & Sadka:
  - wöchentliche Querschnittsregression der 24 Stundenrenditen auf ihr 8-Wochen-Mittel davor;
  - t-Test der Steigungen (HAC, Lag 8);
  - belegt bei p < 0,05, positiver Steigung und gleichem Vorzeichen in beiden Hälften.

**P0.6 Wochenmomentum.**
- Nur BTC und ETH; Prognose montags 00 UTC für 7 Tage.
- z_L = r_L / (σ̂_Tag·√L) mit L = 14, 21, 28. P = Basisrate + κ·tanh z; κ aus dem Training, mit positivem James-Stein-Schrumpf.
- Brier gegen die Basisrate, DM, Holm über die 6 Varianten (Coins × L).
- Regel long/flat (z > 0) mit Kosten 0,06 % je Wechsel, gemessen als Timing-Rendite: (Position − mittlere Trainingsposition) ×
  Wochenrendite.
- Deflated Sharpe über die 6 Varianten; PBO per CSCV mit 16 Blöcken (berichtet, keine Bedingung).
- Belegt je Coin und L: Brier p_Holm < 0,05 und DSR ≥ 0,95.

**P0.7 Fensterkombination.**
- Tagesvarianz für h = 1 und h = 7:
  - fünf Einzelverfahren: Mittel der letzten 2, 4 und 8 Wochen, EWMA, ganze Historie;
  - Kombination nach R3: Fixed Share über die fünf (α = 0,05 je Tag, Verlust = Gauß-Quasi-Log-Verlust des Tages);
  - berichtet: das gleichgewichtete Mittel aus 2, 4 und 8 Wochen und Historie (Pesaran & Pick).
- Belegt je Coin, wenn Fixed Share bei beiden h höchstens 1 SE (HAC) schlechter ist als das beste Einzelverfahren.

**P0.8 Regime-Analog.**
- Täglich um 00 UTC, Horizonte 24 h, 72 h und 7 T.
- Die bestehende Analog-Suche wird nachgebaut: 9 Merkmale, k = 50, Mindestabstand 12 Bars, Kandidaten bis 14 Tage vor dem
  Zeitpunkt.
- Regime-Analog:
  - Merkmale: r_1T/σ, r_7T/(σ√7), r_28T/(σ√28), log(σ_7T/σ_90T) und Richtung × D/θ bei c = 1,5;
  - Merkmale gleich gewichtet (Empirical Similarity erst in Phase 2);
  - die 150 Nächsten mit Mindestabstand 12 Bars, Gauß-Kern, Kish ≥ 20;
  - Ausgänge in Einheiten von σ̂, mit dem aktuellen σ̂ zurückskaliert.
- Beide Verfahren nutzen dieselben Kandidaten.
- Belegt je Coin, wenn das Regime-Analog die bestehende Suche **und** den Zufallsweg mit σ̂ (Normalverteilung) auf je ≥ 2 von 3
  Horizonten schlägt (DM p < 0,05).

**P0.9 Bruchmelder.**
- Bereinigte Renditen a = r/s (Profil D aus P0.1, ganze Probe), Referenz EWMA(a²) mit Halbwertszeit 10 Tagen.
- CUSUM für Verdopplung der Schwankung (Varianz ×4, wie in R3) und für Halbierung der Varianz; z² bei 9 gekappt. Nach einem Alarm
  Neustart mit der Varianz der letzten 24 h und 24 h Sperre.
- Null: GARCH(1,1)-t je Coin (Gitter-Quasi-ML). Schwellen: erst je Melder allein über ein Gitter, dann beide gemeinsam; gewählt wird
  das empfindlichste Paar gleicher Einzelrate mit höchstens 1 Fehlalarm je 30 Tage zusammen. Geprüft wird auf neuen Nullpfaden.
- Belegt je Coin, wenn dort ≤ 1,5 Fehlalarme je 30 Tage auftreten und eine Verdopplung im Median nach ≤ 12 h gemeldet wird.
- Beschreibend: Alarme je 30 Tage auf den echten Daten, Verzögerung bei Halbierung.

**Beim Bau geändert (08.10., vor jedem Lauf auf echten Daten), jeweils mit Grund aus den Nullen und Positivkontrollen:**
1. P0.4: Verlust je Bein summiert statt gemittelt. Das Mittel gewichtet kurze Beine stärker als das Training und zeigte auf einem
   Zufallsmarkt „belegt“ (p 0,0035); mit der Summe nicht (p 0,13), 0 von 16 weiteren Zufallsmärkten.
2. P0.6: PBO ist keine Bedingung mehr. Bei sechs fast gleichen Varianten lag es auch für wirksames Momentum bei 0,44 und 0,63; die
   Mehrfachprüfung tragen Holm (Brier) und der Deflated Sharpe über die 6 Varianten.
3. P0.7: Kombination = Fixed Share wie in R3. Das gleichgewichtete Mittel mit Historie lag auf Zufallsmärkten mit wechselnder
   Schwankung 23–65 % hinter dem besten Fenster (QLIKE); es wird nur noch berichtet.
4. P0.8: Das Regime-Analog muss auch den Zufallsweg mit σ̂ schlagen. Gegen die bestehende Suche allein gewinnt schon jede Prognose in
   σ̂-Einheiten (Zufallsmarkt ohne Struktur: p 0,009 bei 24 h).
5. P0.9: Verdopplung heißt Schwankung ×2 (Varianz ×4), wie in R3. Dazu z² gekappt, 24 h Sperre und gemeinsame Kalibrierung.
   - Getrennt kalibriert machten beide Melder zusammen 2,6 statt 1 Fehlalarm je 30 Tage (nach einem Alarm löst die neue Referenz den
     Gegenmelder aus).
   - Ohne Kappe trieben dicke Ränder die Schwellen so hoch, dass selbst bei konstanter Schwankung eine Verdopplung erst nach 16 h
     gemeldet wurde; mit Kappe nach 10 h.
6. P0.3: p aus der t-Verteilung mit (Surrogate − 1) Freiheitsgraden statt aus der Normalverteilung; die Streuung der Null ist selbst
   geschätzt.
7. P0.1 beschreibend: Der Versatz des Buckels kommt aus den geglätteten Fourier-Formen (Korrelation über ±3 h), nicht aus
   Feldmitteln, die bei dicken Rändern an Einzelbars hingen.

**Nach dem ersten echten Lauf korrigiert (08.10., 23.60) -- eigener Fehler, keine neue Hypothese:**

8. **K3 war nicht driftneutral.** Die Sitzung (6,5 h) wurde mit dem ganzen Rest verglichen, der im Mittel 27,1 h dauert (17,5 h,
   montags 65,5 h). Schon eine feste Drift d je Stunde ergibt so (6,5 − 27,1)·d ≈ −0,86 × mittlere Tagesrendite, ohne jeden
   Sitzungseffekt.
   - Im Zeitraum 10/2023–10/2026 sind das grob −8,5 bp bei BTC (Kurs rund 27.900 → 83.300 $) und −6 bp bei PAXG (rund 1.845 →
     4.116 $; Anfangskurse Oktober 2023 aus dem Gedächtnis, nicht nachgeprüft; Endkurse Crypto.com 08.10.), bei einem gemessenen
     K3 von −24,9 bzw. −13,5 bp. Der Bericht ab 23.60 rechnet den Driftanteil aus den eigenen Kerzen.
   - Nulltest und Positivkontrolle von P0.5 liefen ohne Drift; den Fall „Drift ohne Sitzungseffekt“ gab es nicht.
   - Die Hypothese „US-Sitzung schwächer als der Rest“ meint je Stunde. Darum vergleicht K3 seit 23.60 je Stunde (oben). Jede feste
     Drift hebt sich dabei genau auf; ein echter Unterschied je Stunde bleibt (Positivkontrolle).
   - Proben: Drift +40 bp/Tag → K3 bis auf 10⁻⁹ gleich wie ohne Drift, nicht belegt (roh: −42 bp, p 0,0008); −40 bp je Sitzung →
     belegt, −40,4 bp. 40 Zufallsmärkte je Fall: berichtigt 1, 1 und 2 von 40 belegt bei Drift 0, −40 und +80 bp/Tag; roh 3, 27 und
     40 von 40 mit p < 0,05. Wirksamkeit bei −40 bp: 38 von 40.
   - K1 und K2 bleiben absolut („fällt“ heißt Rendite < 0). Der Bericht nennt ihren Driftanteil (Drift × 3 h bzw. 6 h) und für K3
     das rohe Maß samt dem, was die Drift allein ergäbe.

### 9.2 Phase 2: vorwärts (Schatten), Termine bei Start von Phase 1 festzuschreiben

- **V1, Bänder R2:** CRPS 24 h gegen den Zufallsweg mit HAR-Schwankung. Panel-DM über Coins (8 Wochen ≈ 56 Tagesausgänge je Coin,
  kleinstes nachweisbares d ≈ 0,37). Dazu Bandtreffer.
- **V2, Beinende R4a:** Brier gegen D/θ, vorwärts.
- **V3, Teilnehmer R7:** T1–T3 wie in 4.7, Urteil frühestens 16.12.2026, sonst 13.01.2027.
- **V4, Labor (neue Kennungen):**
  - L1 „Rücksetzer-Zone kaufen im Aufwärtsregime“ gegen L1-Placebo „Zufallszone gleicher Tiefe“;
  - L2 „Wochenmomentum long/flat“ (BTC/ETH);
  - L3 „Grid Long mit Bruchfilter“ gegen das heutige Grid Long.

  Gewertet mit Glück, Blöcken und Stufen wie alle Labor-Strategien.

**Hinweis zur Teststärke:** Mehrtägige Güte lässt sich nur auf der Historie belegen. Acht Wochen liefern 8 unabhängige
Wochenausgänge (kleinstes nachweisbares d ≈ 0,99). Vorwärts wird vor allem geprüft, dass nichts in die Zukunft schaut und die
Kalibrierung hält.

### 9.3 Nullmodelle, Positivkontrollen, Mutationen (für jeden Baustein)

**Nullen:**
- Zufallsweg mit gleicher, zeitvariabler Schwankung (geschlossene Formen);
- GARCH-t je Coin;
- Vorzeichen-Zufall bei gleichen |Renditen| (zerstört die Richtung, behält Schwankung und Profil);
- stationärer Block-Bootstrap;
- für Cluster: Placebo-Karten von vor 3 Tagen.

**Positivkontrollen (eingepflanzt):**
- asymmetrische Beine: Drift nur in Aufwärtsbeinen, Rücksetzer im Mittel 0,5 des vorigen Beins → R4 muss die Asymmetrie finden
  und D/θ schlagen;
- ein Stundenfenster mit −30 bp (im Fenster nachweisbar) und eines mit −5 bp (nur in der Historie);
- ein New-York-Buckel mit Sommerzeitwechsel → R1 muss die Uhr erkennen;
- ein Volatilitätsbruch ×2 → R3 innerhalb der Sollverzögerung;
- Pool-Käufe, die Rücksetzer verkürzen → T1 muss anschlagen.

**Mutationen (müssen die Proben rot machen):**
- θ nicht schwankungsnormiert;
- geglättete statt gefilterte Regimewahrscheinlichkeit;
- zweiseitiger Glätter;
- nachgezeichnete ZigZag-Linie;
- ohne Embargo;
- nur UTC-Uhr;
- ohne Schrumpfung;
- D/θ-Baseline weggelassen;
- Suche über Fenster ohne Bereinigung;
- Analog ohne Mindestabstand;
- Placebo-Karte = echte Karte.

**Zählen:** Jede Konfiguration, jedes Gitter und jede Fixed-Share-Einstellung wird protokolliert. Deflated Sharpe und PBO werden
gegen diese Zahl gerechnet. Für neue Befunde gilt t > 3 als Richtwert (Harvey, Liu & Zhu 2016).

### 9.4 Ergebnis Phase 0 auf echten Daten (Lauf 08.10.2026 02:06 mit 23.59; K3 berichtigt in 23.60)

**Daten:** BTC, ETH, ZEC und XMR von Binance-Futures, PAXG von Bybit, je 08.10.2023–07.10.2026 (1.096 Tage, 52.608 Kerzen, keine
Lücke); HYPE von Binance-Futures erst ab 30.05.2025 (496 Tage, daher P0.1 nur 4 Bewertungsmonate, P0.8 nur 123 Tage). Laufzeit
480,7 s, davon Rechnen 162 s.

| Prüfung | belegt | Zahlen |
|---|---|---|
| P0.1 Zwei-Uhren-Profil | keiner | D schlägt das flache Profil (5 von 6, nicht XMR) und das heutige Zeitprofil (5 von 6: +0,047 bis +0,198 QLIKE je Bar, p 0,040 bis < 0,0001; HYPE nicht). Gegen die glatte UTC-Form B gewinnt D nicht (BTC +0,0017, p 0,65; PAXG −0,013, p 0,0006). Der Werktags-Buckel wandert mit der US-Sommerzeit: BTC +0,83 h, ETH +0,75 h, HYPE +1,0 h, PAXG +0,83 h; ZEC +0,25 h und XMR +0,42 h bleiben eher bei UTC |
| P0.2 Bewegungsgröße | keiner | HAR schlägt EWMA bei 1 Tag in allen sechs Coins (BTC QLIKE 0,329 gegen 0,401, p 0,0023; ETH p 0,0004; XMR p < 0,0001; HYPE p 0,047). Bei 7 Tagen ist nur XMR signifikant; die Punktschätzung liegt aber in 18 von 18 Fällen bei HAR. Das 80-%-Band hält bei BTC, ETH und HYPE (79,5–84,4 %), bei ZEC (74–76 %), XMR (76–77 %) und PAXG (69–72 %) ist es zu schmal. Berührquoten 0,82–0,93 der Formel 2[1 − Φ(k)] (PAXG 0,75 bei 1 Tag); Spannweite 0,85–1,14 |
| P0.3 Beine | Dauer: ETH c 1,0; PAXG c 1,0 und 1,25 (Richtung druckt der Bericht erst ab 23.60) | Alles andere wie bei den Surrogaten. Bei c = 1,5 für BTC: θ ≈ 3,7 %, 8,1 Beine je 4 Wochen, Bein median 6,9 % in 2,5 Tagen, P(höheres Tief) 0,57 (Surrogate 0,54), P(höheres Hoch \| höheres Tief) 0,67 (0,68), Überschießen 1,12 (1,10). Die Asymmetrie der letzten 4 oder 8 Wochen sagt in keinem Coin etwas über die folgenden 4 Wochen |
| P0.4 Beinende | nein | Log-Verlust: Modell 0,6130, kalibrierte Baseline 0,6097, roh D/θ 0,6102 (18.650 Punkte in 1.120 Beinen). Roh gegen kalibriert p 0,60: D/θ allein ist schon kalibriert |
| P0.5 Kalender (K3 noch roh) | XMR: K1 +12,3 ± 4,9 bp und K3 −82,6 ± 15,9 bp; PAXG: K3 −13,5 ± 4,0 bp. XMR-Stunden 07–08 UTC +8,0, 12–13 −11,1, 13–14 −8,6 bp; XMR-Persistenz (HKS) Steigung +0,249, p < 0,0001 | Nicht belegt: BTC K3 −24,9 ± 9,6 und ETH K3 −38,7 ± 13,6 (p Holm 0,029 bzw. 0,014, aber die Jahre wechseln das Vorzeichen); HYPE K3 −67,3 ± 32,5. K1 und K2 liegen bei BTC und ETH um null (BTC +0,6 ± 2,3 und −1,8 ± 4,9 bp). ETH 21–22 UTC +6,8 bp ist ein Einzeltreffer. K3 wird mit 23.60 neu gerechnet (9.1a Punkt 8) |
| P0.6 Wochenmomentum | keiner | Brier nirgends besser als die Basisrate. Beste Variante ETH L 28: Sharpe +1,73 je Jahr, DSR 0,89. PBO 0,56 |
| P0.7 Fenster | ZEC, XMR | Bei BTC, ETH und HYPE ist EWMA das beste Fenster; Fixed Share liegt 0,006–0,013 QLIKE dahinter (1,3–2,8 SE). Beschreibend: Bei 7 Tagen liegt das einfache Mittel bei BTC, ETH und HYPE vor jedem Einzelfenster |
| P0.8 Regime-Analog | keiner | Der Zufallsweg mit σ̂ ist bei 72 h und 7 Tagen meist am besten. Das Regime-Analog verliert gegen ihn bei BTC (p 0,045/0,037), ETH (0,0074/0,0072) und ZEC (0,016/0,017). Der Nachbau der bestehenden Suche liegt dort 2–7 % über dem Zufallsweg (beschreibend; p ab 23.60 im Bericht). Bei XMR schlägt das Regime-Analog den Zufallsweg bei 24 h (p 0,0077); bei HYPE schlägt es die bestehende Suche, aber nicht den Zufallsweg |
| P0.9 Bruchmelder | keiner | Fehlalarme 0,70–0,96 je 30 Tage (im Soll). Eine Verdopplung der Schwankung meldet er im Median aber erst nach 51–366 h (Soll ≤ 12 h), eine Halbierung nach 422–587 h. Die GARCH-Null echter Kurse (α 0,04–0,13, β 0,86–0,955) treibt die Schwellen hoch; auf synthetischen Märkten mit fast konstanter Schwankung waren es 10 h |

**Lesart:**
1. **Richtung über Stunden bis Tage:** in diesen Daten nicht vorhersagbar, wie Abschnitt 0 erwartet hat.
   - Stufen, Rücksetzer und höhere Tiefs sind Zufallsgeometrie bei wechselnder Schwankung.
   - Die Asymmetrie der letzten 4–8 Wochen sagt nichts über die nächsten 4 Wochen.
   - Wochenmomentum und Analoge tragen nicht.
2. **Vorhersagbar ist die Größe.**
   - HAR schlägt bei 1 Tag EWMA in allen sechs Coins (BTC rund 18 % weniger QLIKE) und die 7-Tage-Schwankung des heutigen Bands
     in vier (BTC, ETH, ZEC, PAXG; p 0,0014–0,014).
   - Ein glattes Tagesprofil der Schwankung schlägt das heutige Zellenprofil (168 Mittelwerte aus 180 Tagen). Der Gewinn kommt vom
     Glätten; die New-York-Uhr ist zwar richtig, bringt messbar aber nichts dazu.
   - Die Geometrie der Beine ist kalibriert. D/θ ist die Chance, dass ein Extrem steht. Pegel werden etwas seltener berührt, als
     die Brownsche Formel sagt (Faktor 0,75–0,93).
3. **Fenster:** Für die Größe ist schnelles Gedächtnis besser als 2–8-Wochen-Fenster (EWMA mit rund 11 Tagen Halbwertszeit, HAR).
   „4 oder 8 Wochen“ ist für die Größe die falsche Frage. Für die Richtung gibt es nichts, was ein Fenster wählen könnte.
4. **Kalender:**
   - K1 („02–05 Uhr fällt“) und K2 („Samstagnacht fällt“) sind bei BTC und ETH nicht nachweisbar (BTC K1 +0,6 ± 2,3 bp, K2
     −1,8 ± 4,9 bp). Bei XMR ist K1 belegt, aber mit dem umgekehrten Vorzeichen: 02–05 Uhr steigt XMR (+12,3 ± 4,9 bp).
   - K3 („US-Sitzung schwächer“) hat in allen sechs Coins ein negatives Vorzeichen, war aber roh driftbehaftet (9.1a Punkt 8).
   - Grobe Abschätzung für das berichtigte K3: Sie nimmt je Coin eine Rate für die Sitzung und eine für den Rest an und nutzt die
     Drift aus Anfangs- und Endkurs. Danach bleibt XMR deutlich (rund −45 bp je Sitzung, also rund −7 bp je Stunde gegenüber dem
     Rest). BTC schrumpft auf rund −10 bp, ETH auf rund −20 bp, PAXG auf rund −5 bp. Das gerechnete Urteil liefert der Lauf
     08.10. 21:00 mit 23.60.
   - XMR ist auffällig: ein großer, über drei Jahre in jedem Jahr gleicher Effekt mit beständigem Stundenmuster. So etwas wäre
     handelbar und ist deshalb verdächtig, bis eine zweite Quelle und ältere Daten es bestätigen. Denkbare Ursachen sind die
     Marktstruktur nach dem Spot-Delisting bei Binance (Februar 2024, nicht geprüft) oder Eigenheiten einer einzigen Börse.
   - PAXG: Nach der Driftkorrektur bleibt laut Abschätzung wenig übrig (oben).
5. **Bruchmelder:** Bei 1 Fehlalarm je 30 Tage ist ein Bruch erst nach Tagen von gewöhnlicher Häufung zu trennen. Für die Größe
   genügt HAR, das sich binnen eines Tages anpasst. R3 als eigener Baustein entfällt (Vorschlag).

**Folgen (Vorschlag; Entscheidung beim Nutzer, Abschnitt 12):**
- **Phase 0b, Vorhaltetest:** dieselben Prüfungen auf 10/2020–10/2023. Diese Daten hat niemand angesehen. Geprüft wird nur, was
  getragen hat:
  - (a) HAR schlägt EWMA bei 1 Tag;
  - (b) das glatte Profil schlägt das heutige Zellenprofil;
  - (c) D/θ ist kalibriert;
  - (d) XMR: K3 (berichtigt) < 0, K1 > 0, Stunden 12–14 UTC < 0;
  - (e) PAXG K3 < 0, nur wenn es im Lauf 21:00 belegt bleibt.

  Die Liste wird vorab festgeschrieben. Urteil: gleiches Vorzeichen und p < 0,05, Holm über die Liste. Dazu XMR aus einer zweiten
  Quelle (Bybit) für 2023–2026. Die Daten liegen in Stunden vor; vorwärts bräuchte ein Effekt dieser Größe Monate (XMR-K3:
  Standardfehler über 20 Sitzungen grob 50–100 bp).
- **Phase 1 schlanker:** Abschnitt „RG Regime“ nur mit dem, was trägt:
  - Größe (HAR-Band für 1–7 Tage; Bandkalibrierung für ZEC, XMR und PAXG vorab festgelegt);
  - Tagesprofil der Schwankung (glatt, New-York-Uhr);
  - Bein-Zustand als Geometrie (θ, Bein bisher, D/θ, typische Beinlänge und -dauer);
  - Kalender nur, soweit der Vorhaltetest ihn bestätigt.

  Ohne Wochenmomentum, Regime-Analog und Bruchmelder.
- **Nach dem 25.10. vormerken** (Phase 3, nach U108):
  - `hl_forecast.time_vol_profile` durch das glatte Profil ersetzen;
  - die 7-Tage-Schwankung des Bands durch HAR ersetzen;
  - die Analog-Suche der Prognose gegen den Zufallsweg mit σ̂ bewerten (P0.8: bei 72 h und 7 Tagen nicht besser).
- **Labor L1–L3** (Rücksetzer-Zone, Wochenmomentum, Grid mit Bruchfilter) entfallen, weil P0.3, P0.6 und P0.9 sie nicht tragen.

## 10. Stufenplan und Aufwand

| Phase | Inhalt | Wirkung | Aufwand (Sitzungen) | frühester Beginn |
|---|---|---|---|---|
| 0 | `hl_regime.py --vorpruefung`: Historie laden, P0.1–P0.9, Debug-Bericht „★ Regime: Vorprüfung auf der Historie (U138)“ | keine (nur Bericht) | 1 | **gebaut 23.59, gelaufen 08.10. 02:06** (Ergebnis 9.4); K3 berichtigt in 23.60, zweiter Lauf 08.10. 21:00 |
| 0b | Vorhaltetest 10/2020–10/2023 für das, was getragen hat (9.4), dazu XMR aus einer zweiten Quelle | keine (nur Bericht) | 1 | Vorschlag, nach Entscheidung des Nutzers |
| 1 | Schattenmodul R1–R5, R7-Messung, Speicher, Abschnitt „RG Regime“, Wochenprüfung | nur Anzeige | 2–3 | nach Phase 0 |
| 2 | R8 (Regime-Analog parallel, Pfadfächer), Labor L1–L3 (neue Kennungen), Vorwärtsprüfung V1–V4 | Labor nur neue Kennungen | 2–3 | nach Phase 1 |
| 3 | Belegte Bausteine als Experten der Fusion (RG2, RG5, RG9, RG12), Ersatz des Zeitprofils durch R1 | Prognose | 1–2 | nach 25.10. (U108) und den eigenen Urteilen |

Im UPDATE_PLAN steht das als **U138** (Phasen 0–3 als Unterpunkte). Die Zusage bis 25.10. bleibt unberührt: Phasen 0–2 ändern
weder Fusion noch v3, Kaskaden oder das Lernen von v1.

## 11. Grenzen und Risiken

- **Richtung bleibt schwach.** Wer vom Modul Trefferquoten von 60 % und mehr erwartet, wird enttäuscht; sein Wert liegt in
  Bandbreiten, Zonen und Zeitfenstern.
- **Kurze Historie der Kontodaten.**
  - R7 hat erst seit Mitte September 2026 Daten. Urteile sind vor Dezember nicht möglich.
  - Eine Person kann mehrere Wallets steuern.
- **Historie von einer anderen Börse.** Binance (≈ 49 % des Perpetual-Volumens 2020–2022) für Parameter, Hyperliquid für den
  Zustand. Unterschiede in Funding-Takt (stündlich gegen 8-stündlich) und Liquidität sind möglich. Das wird als Bruch geprüft.
- **Strukturbrüche in der Historie:**
  - US-Uhr seit November 2021 (unbestätigt, nur Presse);
  - Spot-ETF Januar 2024;
  - CME rund um die Uhr seit 29.05.2026 (Wochenendlücken verschwinden).

  Wochenend- und Sitzungsparameter vor und nach diesen Daten werden getrennt geprüft.
- **Reihenfolge innerhalb einer Bar.** 30-min-Historie kennt die Reihenfolge von Hoch und Tief nicht. Bei HYPE, XMR und ZEC
  (Spannweite > θ) ist das konservativ zu ordnen; live gibt es 1-min-Bars.
- **Datenschnüffelei.** Das größte Risiko. Dagegen stehen vorab festgelegte Hypothesen, gezählte Konfigurationen, Nullen in drei
  Stufen und die Regel „was nur im Fenster auftaucht, ist Rauschen“.
- **PAXG** ist Gold, kein Krypto-Regime; eigene Parameter, keine Teilung mit Krypto.
- **Erkennungsverzögerung.** Drift-Regime zeigen sich erst nach Wochen. Ein neues Regime ist in seinen ersten Tagen am schlechtesten
  bedient, und genau dort berichtet der Prüfstand die Güte gesondert.

## 12. Entscheidungen beim Nutzer

1. **Phase 0 jetzt bauen?** Ein Debug-Bericht auf der Historie, berührt nichts. Empfehlung: ja, zuerst. Er zeigt, welche
   Bausteine auf unseren Daten tragen, bevor etwas live geht. **Entschieden 07.10. 23:34: ja; gebaut in 23.59.** Für Phase 0 gelten
   bei 2 und 3 die Empfehlungen (K1–K3, alle Coins mit Historie).
2. **Kalenderhypothesen (höchstens drei)**, Vorschlag:
   - K1 „02–05 Uhr Berliner Zeit fällt“;
   - K2 „Samstagnacht Sa 22 – So 04 Uhr fällt“;
   - K3 „US-Kernsitzung schwächer als der Rest“.

   Andere Fenster bitte vor dem Bau nennen; danach gilt die Liste.
3. **Coins:** alle sechs (dünne Coins zu BTC/ETH geschrumpft) oder zuerst BTC und ETH. Empfehlung: Phase 0 mit allen, für die
   Historie existiert; Phase 1 alle sechs.
4. **Anzeige:** eigener Abschnitt „RG Regime“ (Empfehlung) oder als Teil der Prognose.
5. **Labor:** neue Strategien L1–L3 mit eigenen Kennungen (Empfehlung: ja, ab Phase 2).
6. **Reihenfolge nach Phase 0:** Phase 1 im Schatten noch vor dem 25.10. (berührt die Zusage nicht), Fusion erst danach. Oder alles
   erst nach dem 25.10.
7. **Teilnehmer-Hypothesen:** T1–T3 (Abschnitt 4.7) oder eigene Fragen an die Kontodaten, etwa ob bestimmte Gruppen Hochs
   verkaufen. Sie müssen vor dem Bau von Phase 1 feststehen, weil vorwärts nur gezählt wird, was danach bestätigt wird.

**Nach Phase 0 (08.10., Abschnitt 9.4) neu gefasst, Empfehlungen:**
- Zu 2: K1 und K2 sind bei BTC und ETH nicht nachweisbar (95-%-Intervalle BTC: K1 −3,9 bis +5,1 bp, K2 −11 bis +8 bp). K3
  entscheidet der Lauf 08.10. 21:00 mit 23.60.
- Zu 5: L1–L3 nicht bauen (P0.3, P0.6, P0.9 tragen sie nicht).
- Zu 6: zuerst Phase 0b (Vorhaltetest, eine Sitzung), dann Phase 1 schlank im Schatten, noch vor dem 25.10. möglich.
- Neu 8: Phase 0b bauen? Empfehlung: ja. Die Prüfliste (9.4, a–e) wird vor dem Lauf festgeschrieben.
- Neu 9: Umfang Phase 1 wie in 9.4 (Größe, Tagesprofil, Bein-Geometrie, Kalender nur bestätigt). Bruchmelder, Regime-Analog und
  Wochenmomentum fallen weg.
- 3, 4 und 7 bleiben wie oben.

## 13. Literatur (Auswahl; vollständig mit Links in `RECHERCHE_Regime_07-10-2026.md`)

- **Kalender und Uhren:**
  - Baur, Cahill, Godfrey & Liu 2019 (*FRL* 31);
  - Kinateder & Papavassiliou 2021 (*FRL* 38);
  - Sullivan, Timmermann & White 2001 (*J. Econometrics* 105);
  - McLean & Pontiff 2016 (*J. Finance* 71);
  - Heston, Korajczyk & Sadka 2010 (*J. Finance* 65);
  - Sahu 2024 (*The Anáhuac Journal* 24);
  - Shen, Urquhart & Wang 2022 (*Financial Review* 57);
  - Hansen, Kim & Kimbrough 2024 (*J. Financial Econometrics* 22);
  - Andersen & Bollerslev 1996 (NBER WP 5752) und 1997 (*J. Empirical Finance* 4);
  - Andersen, Thyrsgaard & Todorov 2019 (*JASA* 114);
  - Boudt, Croux & Laurent 2011 (*J. Empirical Finance* 18);
  - JRFM 19(9) 707, 2026 (New-York-Uhr; unbestätigt).
- **Schwankung über Tage:**
  - Corsi 2009;
  - Shen, Urquhart & Wang 2020 (*European Financial Management* 26);
  - Bergsli, Lind, Molnár & Polasik 2022 (*RIBAF* 59);
  - Hoang & Baur 2020 (*J. Futures Markets* 40);
  - Ardia, Bluteau & Rüede 2019 (*FRL* 29);
  - Molnár 2012 (*IRFA* 23);
  - Broadie, Glasserman & Kou 1997 (*Math. Finance* 7).
- **Beine und Stufen:**
  - Glattfelder, Dupuis & Olsen 2011 (*Quantitative Finance*);
  - Houweling 2025 (arXiv 2511.14408, Preprint);
  - Pagan & Sossounov 2003 (*J. Applied Econometrics* 18);
  - Lunde & Timmermann 2004 (*JBES*);
  - Zakamulin 2023 (*Applied Economics* 55);
  - Lo, Mamaysky & Wang 2000 (*J. Finance* 55);
  - Osler 2000, 2001 (FRBNY);
  - Urquhart 2017 (*Economics Letters* 159);
  - Tsang, Ma & Chinthalapati 2024;
  - Gerlach, Demos & Sornette (arXiv 1804.06261).
- **Regime und Fenster:**
  - Nystrup, Kolm & Lindström 2020 (*J. Financial Data Science* 2);
  - Shu, Yu & Mulvey 2024 (*J. Asset Management* 25);
  - Adams & MacKay 2007;
  - Page 1954;
  - Lorden 1971;
  - Pesaran & Pick 2011 (*JBES* 29);
  - Pesaran & Timmermann 2007;
  - Inoue, Jin & Rossi 2017;
  - Bessec & Bouabdallah 2005;
  - Noda 2021;
  - Catania, Grassi & Ravazzolo 2019 (*IJF* 35).
- **Richtung über Tage:**
  - Liu & Tsyvinski 2021 (*RFS* 34);
  - Liu, Tsyvinski & Wu 2022 (*J. Finance*);
  - Borri, Liu, Tsyvinski & Wu 2025 (arXiv 2510.14435);
  - Han, Kang & Ryu (SSRN 4675565);
  - Zaremba et al. 2021 (*IRFA* 78);
  - Ahmed, Grobys & Sapkota 2020 (*FRL*);
  - Hudson & Urquhart 2021 (*Annals of OR* 297);
  - Deprez & Frömmel 2024 (*IREF* 93);
  - Zarattini, Pagani & Barbon 2025;
  - He, Manela, Ross & von Wachter (arXiv 2212.06888);
  - Schmeling, Schrimpf & Todorov 2023 (BIS WP 1087).
- **Hyperliquid:**
  - Zhai 2026 (arXiv 2608.04373);
  - Jia, Moallemi, Wang & Zeng 2026 (AFT 2026);
  - Lim 2026 (*J. FinTech & Digital Assets* 1(2)).
- **Analoge, Simulation, Bewertung:**
  - Fernández-Rodríguez, Sosvilla-Rivero & Andrada-Félix 1999;
  - Gilboa, Lieberman & Schmeidler 2006 (*REStat* 88);
  - Delle Monache et al. 2013 (*MWR* 141);
  - Franke & Westerhoff 2012 (*JEDC* 36);
  - Platt 2020 (*JEDC* 113);
  - Filimonov & Sornette 2015 (*Quantitative Finance* 15);
  - Gneiting & Raftery 2007 (*JASA* 102);
  - Coroneo & Iacone 2020 (*J. Applied Econometrics*);
  - Giacomini & White 2006 (*Econometrica* 74);
  - Slutsky 1937;
  - White 2000;
  - Hansen 2005;
  - Romano & Wolf 2005;
  - Harvey, Liu & Zhu 2016 (*RFS* 29);
  - Bailey, Borwein, López de Prado & Zhu 2014/2017.
