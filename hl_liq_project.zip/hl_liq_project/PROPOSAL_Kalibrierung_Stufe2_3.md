# Proposal: Kalibrierung der Prognose — Stufe 2 und Stufe 3

**Projekt:** hl_liq_project (Hyperliquid-Liquidationscluster, Raspberry Pi 5)
**Stand:** 22.09.2026 (Revision 2 nach Auditbericht v9) · Codebasis `hl_forecast.py`
**Zweck:** Vorlage für ein externes Audit vor der Umsetzung. Stufe 1 ist in der vom Audit v9 bestätigten
**Hybrid-Form** umgesetzt (Nenner konstant; monotoner Ereignis-Faktor; Aktivitätsschwelle 0,05); Stufe 2
und 3 ändern das Lernverhalten und die Ensemble-Architektur und sollen vorher geprüft werden.

**Revision 2 — was sich gegenüber Revision 1 geändert hat (Audit v9, 21.09.):** F2 („Nenner
konstant") war kein Fehler, sondern die korrekte Spezifikation einer Evidenzsumme — der Nenner je Fall
ist verworfen. λ für die Null-Regularisierung war um ~2 Größenordnungen zu stark; Warm-Start, ein
statistisch tauglicher OOS-Wächter und Toleranz-Labels im Training fehlten. Stufe 3: Freiheitsgrade
tragen 3–5 Parameter, die Familien-Normierung wiederholte den Nenner-Fehler, die Lernebenen waren
skaleninkonsistent — das Familien-Ensemble ist auf 6–8 Wochen nach Stufe 2 verschoben; die Lift-Bilanz
(E) und OOS je Treiber (F) sind bereits umgesetzt (22.09.). Rollback per Gewichtsversion existiert seit
22.09. (`weights_hist`).

---

## 0. Kurzfassung

Das Ensemble kombiniert 30 Treiber-Scores x_j ∈ [−1, 1] zu einer Richtungswahrscheinlichkeit
P(auf) = σ(β · Σ w_j x_j / S). Die Gewichte w_j werden je Horizont (4 h, 24 h) mit einem
regularisierten Logit auf den bewerteten Prognosen gelernt. Ein Audit der Bewertungslogik
(21.09.) fand zwei Fehler und drei signifikante Schwächen; Stufe 1 hat die Anzeige-Inkonsistenz
behoben. Dieses Proposal beschreibt:

- **Stufe 2 — Lernregel:** Regularisierung gegen null statt gegen den Prior (Prior als Startwert),
  Aufhebung der unteren Gewichtsklemmung (Kontra-Treiber dürfen negatives Gewicht bekommen),
  Schutz gegen Überanpassung durch n_eff-abhängige Freigabe und Out-of-sample-Wächter.
- **Stufe 3 — Ensemble-Architektur:** Kombination in Treiber-Familien (Positionierung, Fluss,
  Kurs, Mikrostruktur, Spot, ETF, Historie, Audit-v3-Indikatoren) gegen die Doppelzählung
  korrelierter Treiber; Basisraten-bereinigte Trefferbilanz je Treiber; Familien-Gewichte lernbar.

Jede Stufe hat Erfolgskriterien, ein Rollback und einen Nulltest.

---

## 1. Ist-Zustand (nach Stufe 1)

### 1.1 Modell

```
z_t   = β · Σ_j w_j · x_{j,t} / S            S = Σ_j prior_j (konstant; fehlender Treiber = Beitrag 0)
P_t   = σ(z_t)
Loss  = Σ_t s_t · [ −y_t ln P_t − (1−y_t) ln(1−P_t) ] / Σ s_t  +  λ · [ Σ_j (w_j − prior_j)² + (β − 1)² ]
λ     = 4 / n_eff          n_eff = Zahl getrennter Horizont-Blöcke (nicht Fensterzahl)
s_t   = 0.5^{(now − t)/T_half}   Alters-Gewicht
Update: w_j ← clip(w_j − lr·∂Loss/∂w_j, 0, 2·prior_j);  β ← clip(β − lr_β·∂Loss/∂β, 0.2, 4.0)
```

Lernen beginnt ab n_eff ≥ 40 je Horizont; ein Treiber wird erst freigegeben, wenn er in
n_eff ≥ 50 (4 h) bzw. 30 (24 h) Blöcken aktiv war (|x| > 0,05). Nicht freigegebene Treiber
stehen im Logit mit ihrem Prior.

### 1.2 Bewertung

- Fall = Prognose t mit Richtung des realen Kurses nach h Stunden; Fenster mit |Bewegung| unter
  der Toleranz gelten als „offen" (kein Treffer, kein Fehlschlag).
- Je Treiber: Trefferquote des Vorzeichens (in-sample, 4-h-Spur), Wilson-Intervall auf n_eff.
- Gesamt: Trefferquote, Brier-Skill gegen die Basisrate, Out-of-sample-Quote seit der letzten
  Gewichtsversion (`wver`), Nulltest (Rauschen → Gewichte am Prior, β ≈ 1, Quote 50 %).

### 1.3 Befunde des Audits (21.09.)

| # | Befund | Art |
|---|---|---|
| F1 | Regularisierung zieht zum **Prior**, nicht zu null: ein Treiber mit 50 % Trefferquote behält sein Prior-Gewicht dauerhaft. Das dokumentierte „Killkriterium" existiert nicht. | Fehler |
| F2 | ~~P(auf) teilte durch die Summe aller Priors~~ — **kein Fehler** (Audit v9 §3.1): Der Logit ist eine Evidenzsumme; ein fehlender Treiber ist ein Beleg mit Bayes-Faktor 1. Der Nenner je Fall (Revision 1) blähte den Logit bei 2 aktiven Treibern um das 11-fache auf und ist verworfen. Bias (Mittelwert) und P(auf) (Summe) sind verschiedene Größen. | zurückgezogen |
| S1 | Sieben Treiber lesen dieselbe Konten-Population, sechs dieselbe Kursreihe; der Logit addiert sie als unabhängige Belege → Überkonfidenz in Konsensrichtung. | Schwäche |
| S2 | Klemmung [0, 2·prior]: kein Treiber darf umgedreht werden; ein zuverlässig kontra-prädiktiver Treiber geht bestenfalls auf null. | Schwäche |
| S3 | Trefferbilanz je Treiber ist in-sample und ohne Basisrate; in Trendphasen sieht jeder gleichgerichtete Treiber gut aus. | Schwäche |

---

## 2. Stufe 2 — Lernregel

### 2.1 Ziel

Nutzlose Treiber verlieren tatsächlich Gewicht; zuverlässig falsche Treiber dürfen umgedreht
werden; das Lernen bleibt bei kleinem n_eff konservativ und ist out-of-sample überwacht.

### 2.2 Änderung A: Regularisierung gegen null, Prior als Startwert

Parametrisierung in u_j = w_j / prior_j (Audit v9 §4.2: als nachträglicher Gradiententerm mit 1/prior²
oszilliert die Strafe bei Priors 0,3 und n_eff ≤ 50; in u ist sie strukturell stabil):

```
Loss_reg = λ · Σ_j u_j²  + λ_β · (β − 1)²          u_j = w_j / prior_j,  Start u_j = 1
λ        = max(0,5 / n_eff, 0,005)                  (Audit v9 §4.1: 4/n_eff war ~2 Größenordnungen zu stark:
                                                     65-%-Treiber landete bei 0,2·Prior, c ≈ 7.100 Blöcke)
```

Erwartetes Gleichgewicht mit λ = 0,5/n_eff: Rausch-Treiber bei n_eff 100 unter 0,15·Prior, 65-%-Treiber
≈ 1,0·Prior. Das ist vor dem Einspielen mit dem Positivtest (2.6) nachzuweisen, nicht zu behaupten.

- Die Strafe wirkt auf das Verhältnis u = w/prior (relatives Killkriterium), nicht auf den Absolutwert.
- **Warm-Start** (Audit v9 §4.2): Jede Kalibrierung startet bei den zuletzt gespeicherten Gewichten,
  nicht kalt am Prior — sonst ist die Schrittbegrenzung (C3) eine permanente Fessel und Inversion
  unmöglich. Beim Wechsel der Lernregel wird eine Reset-Marke gesetzt (neue Gewichtsversion `wver`,
  Start u = 1), damit die OOS-Bilanz sauber neu beginnt.
- **Toleranz-Labels im Training** (Audit v9 §4.2): Das Training benutzt bisher `label = 1 if close > p0`
  ohne Toleranz; die Bewertung kennt „offen". Fälle mit |Bewegung| unter der Toleranz werden aus dem
  Training ausgeschlossen (Gewicht 0) — sonst bestrafen Zufallslabels gute Treiber unter reg→null.
- Ein Treiber ohne Vorhersagekraft wandert mit wachsendem n_eff gegen null, weil die Strafe ihn
  zieht und kein Gradient hält. Ein guter Treiber verdient sein Gewicht.

**Alternative (verworfen):** Prior-Schrumpfung nach Wilson-Intervall („Prior halbieren, wenn das
Intervall bei n_eff ≥ 50 die 50 % einschließt"). Einfacher zu erklären, aber ein zweiter,
diskreter Lernmechanismus neben dem Logit; die Null-Regularisierung erreicht dasselbe stetig.

### 2.3 Änderung B: Klemmung öffnen

```
w_j ∈ [−prior_j, 2·prior_j]      (vorher [0, 2·prior_j])
```

- Ein negatives Gewicht bedeutet: Der Treiber wird als Kontra-Indikator genutzt. Untergrenze
  −prior_j (nicht −2·prior_j): Umdrehen darf nie stärker wirken als der ursprüngliche Prior —
  die Evidenz für „zuverlässig falsch" ist meist dünner als für „zuverlässig richtig".
- **Höhere Evidenzschwelle für die Inversion** (Audit v9 §4.3): negatives Vorzeichen erst ab
  n_eff_j ≥ 80 oder wenn die Obergrenze des Wilson-Intervalls der Trefferquote unter 45 % liegt.
  Vorbehalt Regime-Wechsel: Ein Treiber, der in einem Regime kontra war, kann im nächsten richtig
  liegen; die Schrittbegrenzung und die OOS-Bilanz begrenzen den Schaden.
- Anzeige: negatives Gewicht wird in der Treibertabelle ausdrücklich als „invertiert" markiert;
  der Score bleibt unverändert, damit die Lesart des Treibers erhalten bleibt.
- Wechselwirkung mit Stufe 3: Innerhalb einer Familie muss die Inversion je Treiber erlaubt
  bleiben; die Familie selbst wird nicht invertiert.

### 2.4 Änderung C: Wächter

1. **Freigabe je Treiber** bleibt (n_eff ≥ 50 / 30).
2. **Out-of-sample-Wächter, statistisch korrekt** (Audit v9 §4.2: die Fassung „5 pp ab n_oos 20"
   hätte 33 % Fehlalarm bei stabilem Modell): Referenz ist die walk-forward-Bilanz aller
   gespeicherten Prognosen (Gewichte bis Tag d, Bewertung Tag d+1), nicht das wver-Fenster; ab
   n_eff_oos ≥ 100 ein Differenztest (Differenz > 2 SE) — erst dann gilt eine Version als
   überangepasst und λ wird für die nächste Version verdoppelt.
3. **Schrittbegrenzung:** Je Kalibrierungslauf darf sich u_j um höchstens 0,25 bewegen — bezogen
   auf den Warm-Start-Wert (Trägheit gegen einzelne Blöcke; mit Warm-Start summieren sich Schritte).

### 2.5 Was sich NICHT ändert

Score-Formeln, Horizonte, n_eff-Definition, Alters-Gewicht, Toleranz „offen", Freigabeschwellen,
β-Klemmung, Nenner je Fall (Stufe 1), Regime-Band.

### 2.6 Validierung

- **Nulltest (Pflicht, erweitert):** Rauschen mit 200 Blöcken → alle |u_j| < 0,15 (relativ, für
  alle Priors gleich streng — Audit v9: das absolute Kriterium war für große Priors schwächer),
  β ∈ [0,8, 1,2], Quote 50 ± 3 %, Brier-Skill ≈ 0.
- **Positivtest (Gate):** Ein synthetischer Treiber mit 65 % Trefferquote muss innerhalb von 100
  Blöcken u ≥ 1,0 erreichen; ein Treiber mit 35 % und n_eff ≥ 80 ein negatives u (Inversion).
  Dieser Test hat die λ-Fehldimensionierung der Revision 1 aufgedeckt und ist Bedingung für das
  Einspielen.
- **Rückschau auf echten Daten:** Quelle ist `forecast_drivers` (unbegrenzt, je Prognose alle
  Treiber-Scores) bzw. `forecast.payload` — nicht `forecast_slim` (enthält keine Scores). Walk-
  forward (Gewichte bis Tag d, Bewertung Tag d+1) frühestens mit 6–8 Wochen Daten: eine Woche sind
  ~42 4-h-Blöcke (SE ±8 pp), das Erfolgskriterium wäre untestbar. Kriterium: neue Regel ≥ alte
  − 1 Punkt und Brier-Skill ≥ alt.
- **Betrieb:** Snapshot `forecasts.db` vor dem Einspielen; Beobachtung 2–3 Wochen; Rollback =
  Gewichtsversion aus `weights_hist` zurückspielen (seit 22.09.; `weights_h` wird je Name
  überschrieben und taugt nicht als Historie — Audit v9 §5.5).

### 2.7 Risiken

- Zu starke Schrumpfung bei kleinem n_eff → Prognose wird flach (P ≈ 0,5) — sichtbar am Brier-
  Skill; Gegenmittel: λ-Konstante 4 → 2 prüfen (Parameter, keine Strukturänderung).
- Inversion durch Zufall bei Treibern mit wenigen Blöcken → durch Freigabeschwelle und
  Schrittbegrenzung begrenzt; Anzeige „invertiert" macht es sichtbar.
- Kollinearität (S1) kann Gewichte zwischen korrelierten Treibern hin- und herschieben →
  Stufe 3 adressiert das; bis dahin Schrittbegrenzung.

---

## 3. Stufe 3 — Ensemble-Architektur

### 3.1 Ziel

Korrelierte Treiber sollen nicht als unabhängige Belege addiert werden; die Bilanz je Treiber
soll die Basisrate berücksichtigen.

### 3.2 Änderung D: Treiber-Familien

Vorschlag der Familien (aus der Datenquelle abgeleitet, nicht aus Korrelationsschätzungen):

| Familie | Treiber |
|---|---|
| Positionierung Konten | Direktionale Wale, Smart Money, Elite-Positionierung, Top-20-Trend, Crowding-Extrem, Crowding-Trend |
| Fluss Konten | Wal-Flow 30 min, Leaderboard-Flow 60 min, Käufe/Verkäufe 24 h, Smart-Flow 4 h, Gegen-Flow |
| Kurs | MA 200 T, MA 50 W, 60-min-Trend, RSI 14, 7-Tage-Drift, Vol-Spike-Reversion |
| Mikrostruktur | Taker-Flow, Funding, Funding-Spread, Orderbuch, OI-Überhitzung |
| Liquidationen | Kapitulation, Liquidationsdruck (3 Börsen) |
| Spot | Coinbase-Prämie, Spot-Taker-Flow, Spot-Orderbuch |
| ETF | ETF-Flows, ETF-Momentum |
| Historie | Analog-Suche |

Kombination in zwei Ebenen — **Revision 2: konstante Nenner** (Audit v9 §5.2: die Normierung über
nur aktive Mitglieder wiederholte den Nenner-Fehler auf Familienebene; ein einzelner schwacher Treiber
hätte die ganze Familie mit voller Stimme sprechen lassen):

```
F_k,t = Σ_{j∈k} w_j x_{j,t} / Σ_{j∈k} prior_j         Nenner über ALLE Mitglieder, fehlende = 0
z_t   = β · Σ_k v_k · F_k,t / Σ_k v_k                 Nenner über ALLE Familien
```

Lernkopplung (Audit v9 §5.2): Entweder wird durch die Struktur hindurch differenziert (Treiber-
Gradienten über die Familienebene), oder es werden **nur die Familiengewichte v_k gelernt** und die
Treiber innerhalb bleiben am Prior. Revision 2 empfiehlt das Letztere — 8 Parameter statt 39 bei
n_eff ~50 (Faustregel 10–20 Blöcke je Parameter trägt 3–5).

- Innerhalb der Familie werden die Treiber wie bisher gelernt (Stufe 2), aber ihre Summe ist auf
  ±1 normiert: Sieben einige Positionierungs-Treiber ergeben **eine** Stimme, nicht sieben.
- Familien-Gewichte v_k werden mit derselben Regel gelernt (Prior 1,0 je Familie, Regularisierung
  gegen null, Klemmung [0, 2]); Familien werden nicht invertiert.
- Der Bias für den Pfad wird aus z_t gebildet (Σ v_k F_k / Σ v_k), die Einigkeit aus dem
  Vorzeichen der Familienscores.

**Erwarteter Effekt (relativiert):** Mit konstantem Nenner liefert die Lage „sieben einige Konten-
Treiber" bereits P ≈ 0,57, nicht 0,75 — die grobe Überkonfidenz der Revision 1 war der Nenner je
Fall. Was bleibt, ist das Verhältnis Parameter/Blöcke; der Gewinn der Familien liegt in weniger
Parametern, nicht in „Stimmen zählen". Hinweis des Audits: Familien nach Datenquelle trennen nicht
die Akteure — Positionierung und Fluss lesen dieselben Konten. Alternative Zuordnung nach Akteuren:
Großkonten (Positionierung + Fluss), Kurs, Fremdmarkt (Mikrostruktur + Spot + ETF), Historie — vier
Familien. Entscheidung vor Umsetzung.

**Alternative (dokumentiert):** Korrelationsgewichtung im Logit (Ridge mit geschätzter
Kovarianz). Statistisch sauberer, aber mit n_eff ~60 nicht schätzbar und schwer erklärbar. Die
Familien sind eine Vorab-Struktur aus Sachwissen — ein Prior über die Kovarianz.

### 3.3 Änderung E: Basisraten-bereinigte Treiberbilanz — **umgesetzt 22.09.**

Je Treiber zusätzlich zur Trefferquote:

```
erwartet_j = q·p + (1−q)(1−p)      q = Anteil Aufwärts-Rufe, p = Anteil Aufwärts-Ausgänge in den eigenen Fällen
Lift_j     = Trefferquote_j − erwartet_j
z          = Lift_j / SE,   SE² = [q̂(1−q̂) + ê(1−ê)] / n_eff_j     (Differenz gepaarter Quoten, kein Wilson)
```

- Ein Treiber, der im Aufwärtstrend immer „auf" sagt, hat hohe Quote und Lift null (Probe: Quote
  78 %, Basis 78 %, Lift 0; ein Treiber mit echter Kante: Quote 69 %, Basis 56 %, Lift +13 pp, z 2,1).
- Multiple-Testing-Vorbehalt (Audit v9): 30 Treiber × 2 Horizonte ergeben unter der Null 1,5–3
  Scheintreffer bei z ≥ 2; die Anzeige färbt ab |z| ≥ 2, eine FDR-Korrektur ist für die Kachel
  „trägt/trägt nicht" nachzurüsten, sobald sie Entscheidungen steuert.

### 3.4 Änderung F: Out-of-sample je Treiber — **umgesetzt 22.09.**

Trefferquote je Treiber in den Fällen seit der laufenden Gewichtsversion (`wver` der Prognose);
Anzeige ab n_eff_oos ≥ 25 Blöcken (Audit v9: 10 wäre zu wenig).

### 3.5 Validierung

- Nulltest wie 2.6, zusätzlich: Familienscores auf Rauschen im Mittel null, v_k → null.
- Positivtest: sieben korrelierte synthetische Treiber (gleiche Quelle, 60 %) → als Familie eine
  Stimme; der Brier-Skill der Familienkombination muss den der Einzelkombination übertreffen
  (die Einzelkombination ist überkonfident).
- Rückschau auf echten Daten wie 2.6 mit beiden Architekturen.
- Betrieb: 4 Wochen nach Stufe 2; Rollback = Architektur-Schalter (`ENSEMBLE_FAMILIEN = False`).

### 3.6 Risiken

- Familienzuordnung ist ein Urteil; ein falsch zugeordneter Treiber verliert Stimme.
  Gegenmittel: Familien in der Treibertabelle sichtbar; Zuordnung als Tabelle im Code, nicht
  verstreut.
- Familien mit einem Treiber (Historie) sind Sonderfälle: Familienscore = Treiberscore.
- Zwei Lernebenen (Treiber, Familie) verdoppeln die Parameter; bei n_eff ~60 sind es 30 + 8.
  Die Regularisierung gegen null hält das im Rahmen; das Wilson-Intervall der OOS-Quote muss
  die Verbesserung belegen, sonst bleibt der Schalter aus.

---

## 4. Reihenfolge, Zeitplan, Rollback

| Stufe | Inhalt | Vorbedingung | Beobachtung | Rollback |
|---|---|---|---|---|
| 1 (Hybrid, 22.09.) | Nenner konstant, monotoner Ereignis-Faktor, Aktivitätsschwelle 0,05; dazu E, F, weights_hist, Version | — | sofort | Paket zurück |
| 2 | Null-Regularisierung in u, λ = max(0,5/n_eff, 0,005), Warm-Start mit Reset-Marke, Toleranz-Labels, Klemmung [−prior, 2·prior] mit Inversionsschwelle, OOS-Wächter (n ≥ 100, 2 SE), Schrittbegrenzung | Snapshot forecasts.db; Nulltest 2.6 grün; **Positivtest bestanden** | 2–3 Wochen | Gewichtsversion aus weights_hist |
| 3 | Familien-Ensemble (konstante Nenner, nur v_k lernen, Zuordnung nach Akteuren zu entscheiden) | 6–8 Wochen Stufe-2-Daten; walk-forward auf forecast_drivers | 4 Wochen | Architektur-Schalter |

## 5. Offene Fragen — Stand nach Audit v9

1. 1/prior² vs. absolut → **beantwortet:** relativ, als Umparametrisierung in u (stabil).
2. Untergrenze der Inversion → **beantwortet:** −prior; entscheidend ist die höhere Evidenzschwelle.
3. Crowding-Familie → **beantwortet:** Positionierung (liest `lb_trend`, dieselbe Population).
4. Familien-Freigabe → **beantwortet:** je Familie.
5. Rückschau-Datenbasis → **beantwortet:** `forecast_drivers`, frühestens nach 6–8 Wochen.

**Neu offen:**
6. λ konstant 0,005 oder 0,5/n_eff mit Untergrenze? (Revision 2 wählt 0,5/n_eff mit Boden 0,005 —
   bei wenig Daten stärker schrumpfen ist der Sinn; eine Konstante schrumpft bei n_eff 40 wie bei 400.)
7. Familien nach Datenquelle (acht) oder nach Akteuren (vier)?
8. Nur v_k lernen (8 Parameter) oder durch die Struktur differenzieren?

## Anhang: Stufe 1 (Hybrid, 22.09.) — was genau im Code steht

- Nenner in `calibrate_weights` und `compute_forecast`: **konstant `PRIOR_SUMME`** (Revision 1 hatte
  einen Nenner je Fall; verworfen nach Audit v9).
- Ereignis-Signal (Wal-Flow, Leaderboard-Flow): `score ← score + 0,5·(sign(score) − score)` statt
  `×1,5` (monoton, kein Clipping-Verlust; 0,6 → 0,8).
- `AKTIV_SCHWELLE = 0,05` für die Zählung in der Treiberbilanz (vorher 0,1).
- Änderung E (Lift, z) und F (OOS je Treiber ab 25 Blöcken) in `calibrate_weights`, gespeichert
  unter `learned cal_stats_<h>`, angezeigt in der Treibertabelle.
- `weights_hist`: jede geschriebene Gewichtsversion bleibt erhalten (Rollback-Grundlage).
- `version.py`: Projektversion + Prüfsumme der Projektdateien, Systemkachel „Version".
- Gelernte Gewichte, Lernregel, Freigabeschwellen, β-Klemmung: unverändert.
- Tests: Nulltest grün, Treiber-Funktionstest 73/73, Lift-Probe (Trendfolger Lift 0, Kante +13 pp).
