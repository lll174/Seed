# Käufer-Bot (hl_buyer)

Drei Regeln, zwei Anker, sonst nichts. Ergebnis der Analyse auf echten
Binance-Tageskerzen 2022–2026 (altes Paket, echte_daten/ERGEBNISSE.md, Abschnitte 7–11).

**Regel 1 — Zufuhr sofort anlegen.** Jede Monatsrate im festen Takt (Sparplan).
Auf diesen Daten war der wöchentliche Sparplan der härteste Maßstab: er verliert
nur gegen einen Einmalbetrag, der durch eine Baisse getragen wird.

**Regel 2 — Einmalbeträge und Verkaufserlöse in die Reserve.** Die Reserve liegt
als ruhende Kauforders im Buch: Stufen unter dem *Anker*, und der Anker ist der
Kurs beim Eintreffen des Geldes bzw. der Verkaufskurs — nie das laufende Hoch.
Vorgabe: −10 % → 25 %, −15 % → 20 %, −25 % → 25 %, −40 % → 40 %, −55 % → 100 %
der jeweils noch freien Reserve. Dazu feste Kursmarken, live änderbar. Auffang:
berührt der Kurs den MA200 (+5 %), wird der Rest am Markt gekauft.

**Regel 3 — Verkauf nur bei Überdehnung.** 50 % des Bestands, wenn der Kurs 40 %
über dem MA200 steht (alle drei Episoden 2023–2025 drehten bei 45–53 %). Der
Erlös geht in die Reserve. Sonst wird nie verkauft.

**Sperre für den Sparplan:** keine Sparplan-Käufe, solange der Kurs mehr als
20 % über dem MA200 steht (Käufe dort brachten über 60 Tage −3 bis −4 %).
Ausgesetzte Raten werden beim Rückkehr nachgeholt oder in die Staffel gegeben.
Auf Tageskerzen 2022–2026 ändert das ±1 %: das Top 2025 lag nur 15 % über dem
MA200. Tiefer als 20 % setzt den halben Bullenmarkt aus.

**Wichtigster Einzelhebel: die MA200-Historie.** Beginnt klines30 erst im
September 2023, gibt es bis März 2024 keinen MA200, und die Start-Reserve liegt
zehn Monate unangelegt: Bot +38 % statt +79 % (Sparplan +42 %). Vorher
`python3 hl_timestats.py --coin BTC --years 6` ausführen.

## Zahlen (Tageskerzen, 10.000 Start + 200 USD/Monat)

| | Bot | Sparplan | Halten |
|---|---|---|---|
| Jan 2022 → Sep 2026 | **+107 %** | +100 % | +75 % |
| Sep 2023 → Sep 2026 | **+82 %** | +42 % | +128 % |

Im Bullenmarkt schlägt nichts das sofortige Halten. Der Bot schlägt den Sparplan
in beiden Zeiträumen. Vorbehalt: Lücken Q4 2023 und Q4 2025 in den Testdaten;
der Verkauf Anfang 2024 fand dadurch bei 44.000 statt bei rund 65.000 statt.

## Start

    python3 test_buyer.py                          # 10 bestanden
    python3 hl_buyer.py --db ../hl_liq.db --from 2023-09-04 --to now
    python3 hl_buyerdash.py --db ../hl_liq.db --host 0.0.0.0     # Port 8767

Datenquelle: die längste Kerzentabelle in hl_liq.db (klines30, bnc_bars, bars).
Für den MA200 ab September 2023: `python3 hl_timestats.py --coin BTC --years 6`.
Ergebnisse in hl_buyer_results.db. Keine Abhängigkeiten, nur Standardbibliothek.

## Prüfung 5.9.2026 (Version i)

Fünf Fehler gefunden und behoben:

1. Feste Kursmarken konnten zusammen mit der Staffel mehr binden als die
   Reserve hat (zwei Marken à 60 % = 120 %). Jetzt: Summe aller Orders ≤ Reserve;
   eine von Hand gesetzte Marke hat Vorrang, die Staffel gibt anteilig ab.
2. Eine im Betrieb eingetragene Kursmarke wurde erst beim nächsten Verkauf zur
   Order. Jetzt: Abgleich bei jedem Schritt, Löschen wirkt sofort.
3. Änderungen im Dashboard erreichten den laufenden Bot nicht (neues
   Konfigurationsobjekt). Jetzt wird das bestehende Objekt aktualisiert —
   Verkaufsschwelle, Staffel, Pause gelten sofort, auch im Live-Betrieb.
4. Eine Order, die größer war als die verbliebene Reserve, blieb stumm liegen.
   Jetzt füllt sie mit dem, was da ist.
5. Der Vergleichs-Sparplan rechnete ohne Slippage. Jetzt gleiche Kosten.

## Nachtrag 5.9.2026 (Version l): Dezember 2025 und Oktober 2025

**Der Kauf „3× −15/−25/Rest" im Dezember 2025.** Zwei Stufen waren regelgerecht;
„Rest" war der Auffang, der die restliche Reserve bei 75.000 kaufte, als der
Kurs von oben durch den MA200 stürzte — Geld, das für die Stufen −40/−55
gedacht war. Am Tag selbst ist ein Absturz durch den MA200 nicht von einem
Rücksetzer an den MA200 unterscheidbar (der MA200 steigt noch 100 Tage nach).
Unterscheidbar ist nur die Richtung: **Auffang jetzt nur beim Kreuzen von
unten nach oben** — Ende einer Baisse wie September 2023 oder August 2026.
Berührungen von oben übernehmen die Stufen −10/−15. Modus umschaltbar.

**Der Oktober 2025.** Das Hoch lag ≈ 15 % über dem MA200, die Verkaufslinie
bei +40 % weit darüber. Der einzige Verkauf mit Grundlage ist der Regimebruch
(Schluss unter MA200 − 5 %): Mitte Januar 2026 bei rund 88.000, Rückkauf
gestaffelt darunter. Zahlen auf Tageskerzen: ab Januar 2025 +3 % statt −10 %,
Rückgang 31 statt 46 %; über 2022–2026 aber +70 % statt +103 %, weil er 2023
und 2024 je einmal zu früh verkauft. Als Feld verfügbar, aus. Er ist eine
Versicherung, keine Rendite — dieselbe Aussage wie im alten Paket.

## Ende einer Baisse: Fehlverkäufe verhindern (Version n)

In der Vorgabe gibt es keine Verkaufsregel nahe am MA200 — nur die Überdehnung
bei +40 %. Rücksetzer bei +5/+10 % nach dem Kreuzen lösen nichts aus.

Ist der Regimebruch-Verkauf eingeschaltet, halten ihn drei Bedingungen am
Ende einer Baisse ruhig: Puffer 5 % statt 3 (8 → 5 Verkäufe), fünf
Tagesschlüsse in Folge darunter (→ 4), und scharf erst, wenn der Kurs seit dem
Ende der letzten Baisse (≥ 30 Tage unter dem MA200) einmal 25 % darüber stand
(→ 3). Ab 2025: +10 % statt −10 %, Rückgang 29 statt 46 %.

Option „Baisse-Coins nie verkaufen" vorhanden, aus: sie kostet, wenn der
Verkauf richtig war, weil Geld keinen Einkaufskurs kennt.

## Dashboard

- Chart verdichtet automatisch auf höchstens ~1.500 Kerzen (Anzeige sagt es).
- Logarithmische Skala wahlweise — über mehrere Jahre die ehrlichere Sicht.
- Fadenkreuz mit Datum, O/H/L/S, MA200 und Abstand am Mauszeiger.
- Verlaufsgrafik in Prozent auf das eingezahlte Kapital, Nulllinie markiert.
- Legende unter dem Chart erklärt jedes Element; Werte folgen den Einstellungen.
- Einstellungen überleben den Neustart; benannte Sätze speicher- und ladbar.

Kopfzeile: Bot gegen Sparplan und Halten **mit denselben Einzahlungen**. Lila:
MA200, Verkaufslinie (+40 %), Auffangband (+5 %). Grün gestrichelt: die ruhenden
Kauforders mit Kurs und Betrag. Staffel und Kursmarken links editierbar, live.

## Was hier absichtlich fehlt

RSI, FVG, Cluster, Leiter, Trailing-Stop, Regimefilter auf der Kaufseite,
Korrekturausstieg. Alles geprüft, alles hat weniger gebracht als diese Tabelle.
Das alte Paket bleibt liegen, bis der Recorder die Kaskaden-These beantworten kann.
