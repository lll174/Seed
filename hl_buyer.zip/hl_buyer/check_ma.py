#!/usr/bin/env python3
"""Prueft den MA200 des Bots gegen die Rohdaten:  python3 check_ma.py --db ../hl_liq.db

Listet die 200 Tagesschluesse, aus denen der Bot rechnet, und daneben zum Vergleich
den Durchschnitt ueber andere Zeitrahmen (200 x 4h, 200 x 30 min) und den EMA200 —
damit klar ist, welche Linie eine andere Quelle zeigt, wenn sie abweicht."""
import argparse, sqlite3
from datetime import datetime, timezone
p = argparse.ArgumentParser(); p.add_argument("--db", default="../hl_liq.db"); p.add_argument("--coin", default="BTC"); a = p.parse_args()
con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
def d(ts): return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M")
for table in ("klines30", "klines", "bnc_bars", "bars"):
    if table not in names: continue
    rows = con.execute(f"SELECT ts, close FROM {table} WHERE coin=? ORDER BY ts", (a.coin,)).fetchall()
    if len(rows) < 10: continue
    days = {}
    for ts, c in rows: days[ts // 86400] = (ts, c)               # letzter Schluss je UTC-Tag
    keys = sorted(days); closes = [days[k][1] for k in keys]
    last_ts, last_px = rows[-1]
    print(f"\n=== {table}: {len(rows):,} Kerzen, {d(rows[0][0])} bis {d(last_ts)}, letzter Kurs {last_px:,.0f}")
    if len(closes) >= 201:
        win = closes[-201:-1]                                        # 200 ABGESCHLOSSENE Tage, wie im Bot
        print(f"  MA200 des Bots = Mittel der 200 Tagesschluesse {d(days[keys[-201]][0])[:10]} bis {d(days[keys[-2]][0])[:10]}")
        print(f"     Mittel {sum(win)/200:,.0f}   Minimum {min(win):,.0f}   Maximum {max(win):,.0f}   ->  Kurs liegt {(last_px/(sum(win)/200)-1)*100:+.1f} % davon entfernt")
        print(f"     Stichproben: erster Tag {win[0]:,.0f}, Tag 50 {win[49]:,.0f}, Tag 100 {win[99]:,.0f}, Tag 150 {win[149]:,.0f}, letzter Tag {win[-1]:,.0f}")
        ema = win[0]; k = 2 / 201
        for c in win[1:]: ema = c * k + ema * (1 - k)
        print(f"  zum Vergleich: EMA200 (Tage) {ema:,.0f}")
    else:
        print(f"  nur {len(closes)} Tage vorhanden — kein MA200 moeglich")
    # 200 Kerzen auf feineren Zeitrahmen
    sp = (rows[-1][0] - rows[-50][0]) // 49 if len(rows) > 50 else 0
    if sp:
        for label, step in (("4 h", 14400), ("1 h", 3600), ("30 min", 1800)):
            if step < sp: continue
            b = {}
            for ts, c in rows: b[ts // step] = c
            ks = sorted(b)[-200:]
            if len(ks) == 200:
                m = sum(b[k] for k in ks) / 200
                print(f"  200 Kerzen auf {label:6s} = {m:,.0f}  (Zeitraum {ks[-1]*step-ks[0]*step:>8,} s = {(ks[-1]-ks[0])*step/86400:.1f} Tage)  Kurs {(last_px/m-1)*100:+.1f} %")
