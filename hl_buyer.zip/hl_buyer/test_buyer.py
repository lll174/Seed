"""Kurzpruefung der drei Regeln."""
from hl_buyer import Cfg, Buyer
ok=fail=0
def check(n,c,i=""):
    global ok,fail
    ok+=bool(c); fail+=not c; print(f"  {'ok  ' if c else 'FEHL'} {n} {i}")
T=1_800_000_000; D=86400
def feed(b, series, start=T):
    for k,(o,h,l,c) in enumerate(series): b.step(start+k*D,o,h,l,c)
print("1. Start: Haelfte in die Staffel als ruhende Orders, Rest per Sparplan")
b=Buyer(Cfg(start_usd=10000, start_to_ladder_pct=50, monthly_usd=0)); feed(b,[(100,101,99,100)])
check("Reserve 5000", abs(b.reserve+sum(o.usd for o in b.orders)-5000)<1 or abs(b.reserve-5000)<1, f"-> Reserve {b.reserve:.0f}, Orders {len(b.orders)}")
check("5 Orders unter Anker 100", len(b.orders)==5 and all(o.price<100 for o in b.orders), f"-> {[round(o.price) for o in b.orders]}")
check("Anteile sequentiell (25 % von 5000 = 1250 zuerst)", abs(b.orders[0].usd-1250)<1, f"-> {b.orders[0].usd:.0f}")
print("2. Ruhende Order fuellt am Tief, nie ueber dem Markt")
feed(b,[(100,100,89.5,95)],T+D)            # Tief beruehrt -10 %
check("−10 %-Order gefuellt", any(t['how'].startswith('Staffel −10') for t in b.trades), f"-> {[t['how'] for t in b.trades]}")
check("Fuellkurs 90", any(abs(t['px']-90)<0.01 for t in b.trades))
feed(b,[(70,72,68,70)],T+2*D)               # Gap weit unter −15 und −25: Fuellung zur Eroeffnung 70, nicht zum Orderkurs
f=[t for t in b.trades if t['how'] in ('Staffel −15 %','Staffel −25 %')]
check("Gap: Fuellung zur Eroeffnung 70, nicht 85/75", len(f)==2 and all(abs(t['px']-70)<0.01 for t in f), f"-> {[t['px'] for t in f]}")
print("3. Verkauf bei +40 % ueber MA, Erloes wird zur Staffel unter dem VERKAUFSKURS")
b=Buyer(Cfg(start_usd=10000, start_to_ladder_pct=0, monthly_usd=0, ma_days=5, start_dca_weeks=1, rebuy_mode="touch"))
feed(b,[(100,100,100,100)]*6)               # MA5 = 100, alles investiert
feed(b,[(150,150,150,150)],T+6*D)           # +50 % ueber MA
s=[t for t in b.trades if t['side']=='sell']
check("50 % verkauft", len(s)==1 and abs(s[0]['coin']-b.coin)<1e-6, f"-> {len(s)} Verkaeufe")
check("Anker = Verkaufskurs 150", b.anchor==150, f"-> {b.anchor}")
check("Orders unter 150", all(o.price<150 for o in b.orders) and len(b.orders)==5, f"-> {[round(o.price) for o in b.orders]}")
print("4. Rest der Reserve am MA200 zurueck (Modus Beruehrung)")
feed(b,[(150,150,150,150)]*3,T+7*D)         # MA steigt Richtung 150
feed(b,[(150,150,150,150)]*3,T+10*D)
feed(b,[(150,151,149,150)],T+13*D)          # dist ~0 -> Auffang
check("Reserve leer, keine Orders", b.reserve<1 and not b.orders, f"-> Reserve {b.reserve:.0f}, Orders {len(b.orders)}")
print("4b. Auffang-Modus 'von unten kreuzen': kein Kauf beim Absturz durch den MA200, Kauf beim Kreuzen von unten")
b=Buyer(Cfg(start_usd=10000, start_to_ladder_pct=50, monthly_usd=0, ma_days=5, start_dca_weeks=1, rebuy_mode="cross_up",
            ladder=[{"below_pct":60,"share_pct":100}]))          # Stufe so tief, dass sie nie fuellt
feed(b,[(100,100,100,100)]*6)                                   # MA5 = 100, Reserve 5000 liegt als Order bei 40
feed(b,[(130,130,130,130)]*2,T+6*D)                              # weit ueber dem MA
feed(b,[(98,99,97,98)],T+8*D)                                    # Absturz von oben durch den MA
check("kein Auffang beim Durchschlagen von oben", b.reserve>4999, f"-> Reserve {b.reserve:.0f}")
feed(b,[(95,96,94,95)]*8,T+9*D)                                  # unter dem MA bleiben, MA sinkt auf ~95
feed(b,[(97,98,96,97)],T+17*D)                                   # von unten nach oben kreuzen
check("Auffang beim Kreuzen von unten", b.reserve<1 and not b.orders, f"-> Reserve {b.reserve:.0f}, Orders {len(b.orders)}")

print("5. Kursmarken: Vorrang vor der Staffel, nie mehr als die Reserve, live aenderbar")
cfg=Cfg(start_usd=10000, start_to_ladder_pct=50, monthly_usd=0); b=Buyer(cfg); feed(b,[(100,101,99,100)])
cfg.manual_levels.append({"price":80,"share_pct":30}); feed(b,[(100,101,99,100)],T+D)
m=[o for o in b.orders if o.tag.startswith("Marke")]
check("nachtraegliche Marke liegt als Order", bool(m) and abs(m[0].usd-1500)<1, f"-> {round(m[0].usd) if m else None} USD")
check("Summe der Orders <= Reserve", sum(o.usd for o in b.orders)<=b.reserve+0.01, f"-> {sum(o.usd for o in b.orders):.0f} / {b.reserve:.0f}")
cfg.manual_levels.clear(); feed(b,[(100,101,99,100)],T+2*D)
check("geloeschte Marke verschwindet", not any(o.tag.startswith("Marke") for o in b.orders))
print("6. Order fuellt mit dem, was von der Reserve noch da ist")
cfg=Cfg(start_usd=10000, start_to_ladder_pct=50, monthly_usd=0); b=Buyer(cfg); feed(b,[(100,101,99,100)]); b.reserve=1000.0; feed(b,[(100,100,89,95)],T+D)
f=[t for t in b.trades if t['how'].startswith('Staffel')]; check("Fuellung 1000 statt 1250", bool(f) and abs(f[0]['usd']-1000)<1)
print("7. Konfiguration wird im gleichen Objekt aktualisiert")
c=Cfg(); ref=c; c.update({"overheat_pct":45}); check("update() behaelt das Objekt", c is ref and c.overheat_pct==45)

print(f"\n{ok} bestanden, {fail} fehlgeschlagen")
raise SystemExit(1 if fail else 0)
