"""
hl_buyer.py — strategischer Kaeufer. Drei Regeln, zwei Anker, sonst nichts.

  Regel 1  Zufuhr wird sofort angelegt: jede Rate im festen Takt (Sparplan).
  Regel 2  Einmalbetraege und Verkaufserloese gehen in eine Reserve. Die Reserve
           liegt als ruhende Kauforders im Buch: Stufen unter dem ANKER, wobei
           der Anker der Kurs beim Eintreffen des Geldes bzw. der Verkaufskurs
           ist — nie das laufende Hoch. Auffang: beruehrt der Kurs den MA200,
           wird der Rest der Reserve am Markt gekauft.
  Regel 3  Steht der Kurs 40 % ueber dem MA200, wird die Haelfte verkauft. Der
           Erloes geht in die Reserve (Regel 2). Sonst wird nie verkauft.

Grundlage: Tageskerzen Binance 2022-2026, siehe ERGEBNISSE.md im alten Paket,
Abschnitte 7-11. Alles andere, was dort geprueft wurde, hat weniger gebracht.

Datenquelle: liest hl_liq.db schreibgeschuetzt (klines30, klines, bnc_bars
oder bars — die laengste Quelle gewinnt). Ergebnisse gehen in hl_buyer_results.db.

    python3 hl_buyer.py --db hl_liq.db --from 2023-09-04 --to now
    python3 hl_buyer.py --db hl_liq.db --live
"""

from __future__ import annotations

import argparse
import json
import logging
import sqlite3
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

log = logging.getLogger("buyer")
DAY = 86400


def utc(ts: int) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M")


def parse_time(s: str) -> int:
    if s in ("now", "jetzt"):
        return int(time.time())
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return int(datetime.strptime(s, fmt).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            pass
    return int(s)


# ---------------------------------------------------------------------------
# Konfiguration — alles hiervon ist im Dashboard editierbar
# ---------------------------------------------------------------------------


@dataclass
class Cfg:
    coin: str = "BTC"
    # Kapital
    start_usd: float = 10000.0          # Einmalbetrag zu Beginn
    start_to_ladder_pct: float = 50.0   # davon in die Reserve-Staffel; Rest sofort per Sparplan
    start_dca_weeks: int = 26           # der Sparplan-Anteil des Starts wird so lange gestreckt
    monthly_usd: float = 200.0          # Zufuhr je Monat -> Regel 1
    dca_every_days: int = 7             # Takt des Sparplans
    no_buy_above_ma_pct: float = 20.0   # Sparplan setzt aus, wenn Kurs mehr als x % ueber MA200
                                        # (0 = nie aussetzen). Ausgesetzte Raten sammeln sich an ...
    backlog_to: str = "catchup"         # ... und werden "catchup" = beim Rueckkehr unter die Schwelle
                                        # auf einmal angelegt, oder "reserve" = in die Staffel gegeben
    # Regel 2: Staffel unter dem Anker (Abstand %, Anteil der noch freien Reserve)
    # Anteile beziehen sich auf die jeweils NOCH freie Reserve; 100 % steht nur
    # ganz unten. Tief genug fuer Zyklustiefs (2022: −55 % unter dem Anker).
    ladder: list = field(default_factory=lambda: [
        {"below_pct": 10.0, "share_pct": 25.0},
        {"below_pct": 15.0, "share_pct": 20.0},
        {"below_pct": 25.0, "share_pct": 25.0},
        {"below_pct": 40.0, "share_pct": 40.0},
        {"below_pct": 55.0, "share_pct": 100.0},
    ])
    manual_levels: list = field(default_factory=list)   # [{"price": 60000, "share_pct": 50}]
    # Auffang: Rest der Reserve am Markt kaufen, wenn der Kurs den MA200 VON UNTEN kreuzt
    # (Ende einer Baisse). Beruehrungen von oben uebernehmen die Stufen -10/-15 —
    # sonst wird die Reserve im Absturz durch den MA200 verschenkt (Dezember 2025).
    rebuy_mode: str = "cross_up"        # "cross_up" | "touch" (auch von oben, bis band) | "off"
    rebuy_at_ma_band_pct: float = 5.0   # nur fuer "touch": bis so viel % ueber dem MA200
    # Regimebruch-Verkauf: Schluss unter MA200 minus Puffer -> Anteil verkaufen, Erloes in die
    # Reserve (Staffel unter dem Verkaufskurs). 0 = aus.
    regime_exit_pct: float = 0.0
    regime_ma_days: int = 350           # Durchschnitt fuer den Regimebruch: 350 = 50-Wochen-MA (ruhige
                                        # Regime-Linie, 2024 kein einziges Kreuzen), 200 = wie der MA200
    regime_buffer_pct: float = 3.0
    regime_confirm_days: int = 2        # Schluss muss so viele Tage in Folge unter Regime-Linie − Puffer liegen
    regime_arm_pct: float = 25.0        # ... und seit dem Ende der letzten Baisse muss der Kurs
                                        # mindestens einmal so weit ueber dem MA200 gestanden haben
    bear_min_days: int = 30             # "Baisse" = so viele Tage in Folge unter dem MA200; erst ein
                                        # Kreuzen danach ist ein neues Regime und entschaerft den Verkauf
    protect_bear_lots: int = 0          # 1 = Coins, die unter dem MA200 gekauft wurden, werden vom
                                        # Regimebruch-Verkauf nie angefasst. Kostet Rendite, wenn der
                                        # Verkauf richtig war (2026) — Geld kennt keinen Einkaufskurs.
    # Regel 3
    ma_days: int = 200
    overheat_pct: float = 40.0          # 0 = nie verkaufen
    sell_frac_pct: float = 50.0
    # Kosten
    fee_bps: float = 8.0
    slip_bps: float = 3.0               # nur bei Marktkaeufen; Limit-Orders fuellen ohne Slippage
    # Betrieb
    live_poll_seconds: int = 30

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Cfg":
        c = cls()
        c.update(d)
        return c

    def update(self, d: dict) -> "Cfg":
        """Werte in DIESES Objekt uebernehmen — der laufende Bot haelt eine
        Referenz darauf, ein neues Objekt wuerde ihn nicht erreichen."""
        for k, v in (d or {}).items():
            if hasattr(self, k):
                setattr(self, k, v)
        return self


# ---------------------------------------------------------------------------
# Kerzenquelle
# ---------------------------------------------------------------------------


def connect_ro(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=5.0,
                          check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def pick_source(con: sqlite3.Connection, coin: str) -> tuple[str, int, int] | None:
    """Laengste Kerzentabelle mit diesem Coin: (Tabelle, von, bis)."""
    best = None
    names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    for t in ("klines30", "klines", "bnc_bars", "bars"):
        if t not in names:
            continue
        try:
            r = con.execute(f"SELECT MIN(ts), MAX(ts), COUNT(*) FROM {t} WHERE coin=?",
                            (coin,)).fetchone()
        except sqlite3.Error:
            continue
        if r and r[2] and (best is None or (r[1] - r[0]) > (best[2] - best[1])):
            best = (t, int(r[0]), int(r[1]))
    return best


def pick_fine_source(con: sqlite3.Connection, coin: str) -> tuple[str, int] | None:
    """Tabelle mit den feinsten Kerzen, die in den letzten 3 Tagen Daten hat: (Tabelle, Abstand s).
    Live muss der Bot aus der Tabelle lesen, die der Recorder laufend fuellt (bars), nicht
    aus einem einmaligen Download (klines30)."""
    names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    best = None; now = int(time.time())
    for t in ("bars", "bnc_bars", "klines", "klines30"):
        if t not in names:
            continue
        try:
            rows = con.execute(f"SELECT ts FROM {t} WHERE coin=? AND ts>=? ORDER BY ts DESC LIMIT 50",
                               (coin, now - 3 * DAY)).fetchall()
        except sqlite3.Error:
            continue
        if len(rows) >= 3:
            gaps = sorted(g for g in (rows[i][0] - rows[i + 1][0] for i in range(len(rows) - 1)) if g > 0) or [60]
            sp = max(60, gaps[len(gaps) // 2])
            if best is None or sp < best[1]:
                best = (t, int(sp))
    return best


def load_candles(con, table: str, coin: str, t_from: int, t_to: int) -> list[tuple]:
    cur = con.execute(
        f"SELECT ts, open, high, low, close FROM {table} WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
        (coin, t_from, t_to))
    return [(int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4])) for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


@dataclass
class Order:
    price: float
    usd: float
    tag: str                 # "Staffel -10 %", "Marke 60000"


class Buyer:
    def __init__(self, cfg: Cfg):
        self.cfg = cfg
        self.coin = 0.0
        self.cash_dca = 0.0          # Regel 1
        self.reserve = 0.0           # Regel 2
        self.paid_in = 0.0
        self.orders: list[Order] = []
        self.anchor: float | None = None
        self.sold = False
        self.sale_px: float | None = None
        self.trades: list[dict] = []
        self.journal: list[dict] = []
        self.equity: list[dict] = []
        self.daily: list[float] = []   # Tagesschluesse fuer den MA200
        self._day: int | None = None
        self._month: int | None = None
        self._last_dca_day: int | None = None
        self._start_per: float = 0.0
        self._start_left: float = 0.0
        # Vergleich, gleiche Zufuhr
        self.bench_dca_coin = 0.0; self.bench_dca_cash = 0.0
        self.bench_hold_coin = 0.0; self.bench_hold_started = False
        self.ma_hist: list[tuple] = []

    # ---- Hilfen
    def ma(self, n: int | None = None) -> float | None:
        d = self.daily[:-1]              # abgeschlossene Tage
        n = n or self.cfg.ma_days
        return sum(d[-n:]) / n if len(d) >= n else None

    def ma_regime(self) -> float | None:
        return self.ma(self.cfg.regime_ma_days or self.cfg.ma_days)

    def value(self, px: float) -> float:
        return self.cash_dca + self.reserve + self.coin * px

    def note(self, ts: int, kind: str, text: str, **extra):
        self.journal.append({"ts": ts, "t": utc(ts), "kind": kind, "text": text, **extra})

    def _buy(self, ts: int, px: float, usd: float, how: str, bucket: str):
        fee = usd * self.cfg.fee_bps / 1e4
        got = (usd - fee) / px
        self.coin += got
        mr = self.ma_regime()
        # "Baisse-Coin" nur, wenn der Kurs beim Kauf schon bear_min_days in Folge
        # unter der Regime-Linie lag — ein zweiwoechiger Ruecksetzer im Bullenmarkt zaehlt nicht
        if mr is not None and px < mr and getattr(self, "_under_days", 0) >= self.cfg.bear_min_days:
            self.protected = getattr(self, "protected", 0.0) + got
        if bucket == "dca":
            self.cash_dca -= usd
        else:
            self.reserve -= usd
        self.trades.append({"ts": ts, "side": "buy", "px": px, "usd": usd, "coin": got, "how": how})
        self.note(ts, "buy", f"Kauf {usd:,.0f} USD zu {px:,.0f} — {how}")

    def _place_ladder(self, ts: int, anchor: float, why: str):
        """Reserve als ruhende Orders unter den Ausgangskurs legen — sequentielle Anteile."""
        self.orders = []
        left = self.reserve
        for step in self.cfg.ladder:
            usd = left * step["share_pct"] / 100.0
            if usd < 1:
                continue
            self.orders.append(Order(anchor * (1 - step["below_pct"] / 100.0), usd,
                                     f"Staffel −{step['below_pct']:g} %"))
            left -= usd
        self.anchor = anchor
        self._sync_manual()
        self.note(ts, "info", f"Reserve {self.reserve:,.0f} USD als {len(self.orders)} ruhende Orders "
                              f"unter Ausgangskurs {anchor:,.0f} gelegt ({why}): "
                              + ", ".join(f"{o.tag} @ {o.price:,.0f} für {o.usd:,.0f}" for o in self.orders))

    def _sync_manual(self):
        """
        Feste Kursmarken mit den Orders abgleichen — bei jedem Schritt, damit
        eine im Betrieb eingetragene Marke sofort im Buch liegt und eine
        geloeschte verschwindet. Kursmarken binden nur, was die Staffel nicht
        schon bindet: die Summe aller Orders bleibt unter der Reserve.
        """
        wanted = {float(m["price"]): float(m.get("share_pct", 0)) for m in self.cfg.manual_levels
                  if m.get("price") and float(m.get("share_pct", 0)) > 0}
        self.orders = [o for o in self.orders if not o.tag.startswith("Marke") or o.price in wanted]
        have = {o.price for o in self.orders if o.tag.startswith("Marke")}
        for price, share in sorted(wanted.items(), reverse=True):
            if price in have:
                continue
            usd = min(self.reserve * share / 100.0, self.reserve)
            if usd < 1:
                continue
            free = self.reserve - sum(o.usd for o in self.orders)
            if usd > free:
                # Eine von Hand gesetzte Marke hat Vorrang: die Staffel gibt
                # anteilig ab, bis die Marke gedeckt ist.
                need = usd - free
                ladder = [o for o in self.orders if not o.tag.startswith("Marke")]
                total = sum(o.usd for o in ladder)
                if total > 0:
                    f = max(0.0, (total - need) / total)
                    for o in ladder:
                        o.usd *= f
                    self.orders = [o for o in self.orders if o.usd >= 1]
                usd = min(usd, self.reserve - sum(o.usd for o in self.orders))
            if usd >= 1:
                self.orders.append(Order(price, usd, f"Marke {price:,.0f}"))

    # ---- ein Schritt je Kerze
    def step(self, ts: int, o: float, h: float, l: float, c: float):
        cfg = self.cfg
        day = ts // DAY
        # Tagesschluesse
        if day != self._day:
            self.daily.append(c); self._day = day
        else:
            self.daily[-1] = c
        # Start und Zufuhr
        if not self.paid_in:
            self.paid_in = cfg.start_usd
            to_ladder = cfg.start_usd * cfg.start_to_ladder_pct / 100.0
            self.reserve = to_ladder
            self._start_left = cfg.start_usd - to_ladder
            self._start_per = self._start_left / max(1, cfg.start_dca_weeks) if self._start_left else 0
            self.cash_dca = self._start_left
            self.bench_dca_cash = cfg.start_usd
            self.bench_hold_coin = cfg.start_usd * (1 - cfg.fee_bps / 1e4) / c
            self.note(ts, "info", f"Start: {cfg.start_usd:,.0f} USD — {to_ladder:,.0f} in die Reserve, "
                                  f"{self._start_left:,.0f} über {cfg.start_dca_weeks} Wochen per Sparplan")
            if to_ladder > 0:
                self._place_ladder(ts, c, "Startkapital")
        month = datetime.fromtimestamp(ts, timezone.utc).month
        if self._month is not None and month != self._month and cfg.monthly_usd > 0:
            self.cash_dca += cfg.monthly_usd; self.paid_in += cfg.monthly_usd
            self.bench_dca_cash += cfg.monthly_usd
            self.bench_hold_coin += cfg.monthly_usd * (1 - cfg.fee_bps / 1e4) / c
            self.note(ts, "info", f"Zufuhr {cfg.monthly_usd:,.0f} USD")
        self._month = month

        # Regel 1: Sparplan im Takt — ausgesetzt, solange der Kurs zu weit ueber dem MA liegt
        m0 = self.ma()
        too_high = (cfg.no_buy_above_ma_pct > 0 and m0 is not None
                    and (c / m0 - 1) * 100.0 > cfg.no_buy_above_ma_pct)
        if self._last_dca_day is None or day - self._last_dca_day >= cfg.dca_every_days:
            per_month = cfg.monthly_usd * cfg.dca_every_days / 30.0
            rate = per_month + (self._start_per if self._start_left > 0 else 0)
            if too_high:
                self._backlog = getattr(self, "_backlog", 0.0) + min(rate, self.cash_dca - getattr(self, "_backlog", 0.0))
                if not getattr(self, "_paused_noted", False):
                    self.note(ts, "info", f"Sparplan ausgesetzt: {(c/m0-1)*100:+.0f} % ueber MA{cfg.ma_days} "
                                          f"(Grenze {cfg.no_buy_above_ma_pct:g} %) — Raten sammeln sich")
                    self._paused_noted = True
                self._start_left = max(0.0, self._start_left - self._start_per)
            else:
                backlog = getattr(self, "_backlog", 0.0)
                if backlog >= 1 and cfg.backlog_to == "reserve":
                    self.cash_dca -= backlog; self.reserve += backlog; self._backlog = 0.0
                    self.note(ts, "info", f"Angesammelte Raten {backlog:,.0f} USD in die Reserve")
                    self._place_ladder(ts, c, "angesammelte Sparplan-Raten")
                    backlog = 0.0
                amt = min(self.cash_dca, rate + backlog)
                if amt >= 1:
                    px = c * (1 + cfg.slip_bps / 1e4)
                    self._buy(ts, px, amt, "Sparplan" + (f" + Nachholung {backlog:,.0f}" if backlog >= 1 else ""), "dca")
                    self._start_left = max(0.0, self._start_left - self._start_per)
                self._backlog = 0.0; self._paused_noted = False
            # Vergleich: reiner Sparplan mit derselben Zufuhr
            bamt = min(self.bench_dca_cash, per_month + (cfg.start_usd / max(1, cfg.start_dca_weeks)
                                                         if self.bench_dca_cash > cfg.monthly_usd * 2 else 0))
            if bamt >= 1:
                self.bench_dca_coin += bamt * (1 - cfg.fee_bps / 1e4) / (c * (1 + cfg.slip_bps / 1e4))
                self.bench_dca_cash -= bamt
            self._last_dca_day = day

        # Regel 2: ruhende Orders fuellen, wenn das Tief sie beruehrt (nie ueber dem Markt)
        self._sync_manual()
        for od in list(self.orders):
            if l <= od.price:
                usd = min(od.usd, self.reserve)
                if usd < 1:                       # Reserve verbraucht: Order ist gegenstandslos
                    self.orders.remove(od); continue
                px = min(od.price, o) if o < od.price else od.price   # Gap unter die Order: Eroeffnung
                self._buy(ts, px, usd, od.tag, "reserve")
                self.orders.remove(od)
        m = self.ma()
        if m is not None:
            dist = (c / m - 1) * 100.0
            self.ma_hist.append((ts, m))
            # Auffang: Kurs beruehrt den MA200 -> Rest der Reserve am Markt.
            # Nur bei steigendem MA200 und Beruehrung von oben (Ruecksetzer im
            # Bullenmarkt). Im Absturz durch einen fallenden MA200 bleibt die
            # Reserve fuer die tiefen Stufen — genau dort wurde sie im Dezember
            # 2025 sonst verschenkt.
            prev_dist = getattr(self, "_prev_dist", None); self._prev_dist = dist
            crossed_up = prev_dist is not None and prev_dist < 0 <= dist        # von unten durch den MA200
            touch = dist <= cfg.rebuy_at_ma_band_pct
            fire = (cfg.rebuy_mode == "cross_up" and crossed_up) or (cfg.rebuy_mode == "touch" and touch)
            if self.reserve >= 1 and self.orders and fire:
                px = c * (1 + cfg.slip_bps / 1e4)
                self._buy(ts, px, self.reserve, f"Rest der Reserve am MA200 ({dist:+.1f} %)", "reserve")
                self.orders = []
            # Regimebruch: Schluss unter MA200 minus Puffer -> Anteil verkaufen.
            # Scharf erst, wenn seit dem letzten Kreuzen von unten ein echter
            # Bullenmarkt da war (regime_arm_pct), bestaetigt durch mehrere
            # Tagesschluesse (regime_confirm_days), und nie die in der Baisse
            # gekauften Coins (protect_bear_lots).
            # --- Regime-Linie (Vorgabe 50-Wochen-MA): alles ab hier bezieht sich auf sie
            mr = self.ma_regime() or m
            dist_r = (c / mr - 1) * 100.0
            prev_r = getattr(self, "_prev_dist_r", None); self._prev_dist_r = dist_r
            crossed_up_r = prev_r is not None and prev_r < 0 <= dist_r
            if dist_r < 0 and day != getattr(self, "_under_day", None):
                self._under_days = getattr(self, "_under_days", 0) + 1; self._under_day = day
            if dist_r >= 0 and not crossed_up_r and getattr(self, "_under_days", 0) and prev_r is not None and prev_r >= 0:
                self._under_days = 0
            if crossed_up_r:
                if getattr(self, "_under_days", 0) >= cfg.bear_min_days:      # Ende einer Baisse
                    self.armed = False; self.peak_dist = 0.0
                    self.note(ts, "info", f"Ende einer Baisse ({self._under_days} Tage unter der Regime-Linie MA{cfg.regime_ma_days or cfg.ma_days}): "
                                          f"Regimebruch-Verkauf entschärft bis +{cfg.regime_arm_pct:g} %")
                self._under_days = 0
            self.peak_dist = max(getattr(self, "peak_dist", 0.0), dist_r)
            if self.peak_dist >= cfg.regime_arm_pct:
                self.armed = True
            below = c < mr * (1 - cfg.regime_buffer_pct / 100.0)
            if below and day != getattr(self, "_below_day", None):
                self._below_days = getattr(self, "_below_days", 0) + 1; self._below_day = day
            if not below:
                self._below_days = 0
            sellable = self.coin - (getattr(self, "protected", 0.0) if cfg.protect_bear_lots else 0.0)
            if cfg.regime_exit_pct > 0 and sellable > 0 and not getattr(self, "regime_out", False) \
                    and below and self._below_days >= cfg.regime_confirm_days \
                    and (getattr(self, "armed", False) or cfg.regime_arm_pct <= 0):
                amt = sellable * cfg.regime_exit_pct / 100.0
                usd = amt * c; fee = usd * cfg.fee_bps / 1e4
                prot = self.coin - sellable
                self.coin -= amt; self.reserve += usd - fee; self.regime_out = True; self.sale_px = c
                why = (f"Regimebruch {dist_r:+.0f} % unter MA{cfg.regime_ma_days or cfg.ma_days} · {cfg.regime_exit_pct:g} % von "
                       f"{sellable:.4f} BTC" + (f", {prot:.4f} BTC als Baisse-Coins geschützt" if prot > 1e-9 else ""))
                self.trades.append({"ts": ts, "side": "sell", "px": c, "usd": usd, "coin": amt, "how": why})
                self.note(ts, "sell", f"Regimebruch: Verkauf {amt:.4f} BTC zu {c:,.0f} — {why}")
                self._place_ladder(ts, c, "Regimebruch-Erlös")
            if getattr(self, "regime_out", False) and c > mr * (1 + cfg.regime_buffer_pct / 100.0):
                self.regime_out = False
            # Regel 3: Ueberdehnung
            if cfg.overheat_pct > 0 and dist > cfg.overheat_pct and not self.sold and self.coin > 0:
                amt = self.coin * cfg.sell_frac_pct / 100.0
                usd = amt * c; fee = usd * cfg.fee_bps / 1e4
                self.coin -= amt; self.reserve += usd - fee; self.sold = True; self.sale_px = c
                unprot = self.coin + amt - getattr(self, "protected", 0.0)          # zuerst die teuren Coins
                if amt > unprot:
                    self.protected = max(0.0, getattr(self, "protected", 0.0) - (amt - unprot))
                self.trades.append({"ts": ts, "side": "sell", "px": c, "usd": usd, "coin": amt,
                                    "how": f"Überdehnung {dist:+.0f} % über MA{cfg.ma_days}"})
                self.note(ts, "sell", f"Verkauf {cfg.sell_frac_pct:g} % ({amt:.4f} BTC) zu {c:,.0f} — "
                                      f"{dist:+.0f} % über MA{cfg.ma_days}")
                self._place_ladder(ts, c, "Verkaufserlös")
            if self.sold and dist < cfg.overheat_pct * 0.5:
                self.sold = False
        self.equity.append({"ts": ts, "px": c, "equity": round(self.value(c), 2),
                            "paid": round(self.paid_in, 2), "reserve": round(self.reserve, 2),
                            "coin": round(self.coin, 6),
                            "bench_dca": round(self.bench_dca_cash + self.bench_dca_coin * c, 2),
                            "bench_hold": round(self.bench_hold_coin * c, 2)})

    # ---- Was der Bot als naechstes tun wuerde
    def pending(self) -> list[dict]:
        cfg = self.cfg; out = []
        px = self.equity[-1]["px"] if self.equity else None
        m = self.ma()
        if px is None:
            return out
        # Sparplan
        if cfg.monthly_usd > 0 or self._start_left > 0:
            per = cfg.monthly_usd * cfg.dca_every_days / 30.0 + (self._start_per if self._start_left > 0 else 0)
            nxt = (self._last_dca_day + cfg.dca_every_days) * DAY if self._last_dca_day else None
            paused = m and cfg.no_buy_above_ma_pct > 0 and (px / m - 1) * 100 > cfg.no_buy_above_ma_pct
            if paused:
                out.append({"was": "Sparplan pausiert", "wann": f"bis Kurs ≤ {m * (1 + cfg.no_buy_above_ma_pct / 100):,.0f} "
                            f"(MA200 + {cfg.no_buy_above_ma_pct:g} %)", "betrag": f"aufgelaufen {getattr(self, '_backlog', 0.0):,.0f} USD"})
            else:
                out.append({"was": "Sparplan-Kauf", "wann": f"{utc(nxt)[:10]}" if nxt else "nächste Kerze",
                            "betrag": f"≈ {min(self.cash_dca, per):,.0f} USD (Kasse {self.cash_dca:,.0f})"})
        # offene Orders
        for o in sorted(self.orders, key=lambda o: -o.price):
            out.append({"was": f"Kauf {o.tag}", "wann": f"wenn Kurs ≤ {o.price:,.0f} ({(o.price / px - 1) * 100:+.1f} %)", "betrag": f"{o.usd:,.0f} USD"})
        # Auffang
        if self.reserve >= 1 and self.orders and m:
            if cfg.rebuy_mode == "cross_up":
                out.append({"was": "Auffang: restliche Reserve", "wann": f"wenn Kurs den MA200 ({m:,.0f}) von unten nach oben kreuzt"
                            + (" — Kurs steht darüber, erst nach einem Fall darunter" if px >= m else ""),
                            "betrag": f"{self.reserve:,.0f} USD (abzüglich gefüllter Stufen)"})
            elif cfg.rebuy_mode == "touch":
                out.append({"was": "Auffang: restliche Reserve", "wann": f"wenn Kurs ≤ {m * (1 + cfg.rebuy_at_ma_band_pct / 100):,.0f} (MA200 + {cfg.rebuy_at_ma_band_pct:g} %)",
                            "betrag": f"{self.reserve:,.0f} USD"})
        # Ueberdehnung
        if cfg.overheat_pct > 0 and m and self.coin > 0:
            lvl = m * (1 + cfg.overheat_pct / 100)
            out.append({"was": f"Verkauf {cfg.sell_frac_pct:g} % (Überdehnung)" + (" — schon ausgelöst, neu scharf unter +%g %%" % (cfg.overheat_pct * 0.5) if self.sold else ""),
                        "wann": f"wenn Kurs > {lvl:,.0f} (MA200 + {cfg.overheat_pct:g} %, {(lvl / px - 1) * 100:+.1f} %)",
                        "betrag": f"≈ {self.coin * cfg.sell_frac_pct / 100 * lvl:,.0f} USD"})
        # Regimebruch
        mr = self.ma_regime()
        if cfg.regime_exit_pct > 0 and mr and self.coin > 0:
            m = mr; lvl = m * (1 - cfg.regime_buffer_pct / 100)
            armed = getattr(self, "armed", False) or cfg.regime_arm_pct <= 0
            sellable = self.coin - (getattr(self, "protected", 0.0) if cfg.protect_bear_lots else 0.0)
            if not armed:
                out.append({"was": "Regimebruch-Verkauf entschärft", "wann": f"scharf, sobald Kurs einmal > {m * (1 + cfg.regime_arm_pct / 100):,.0f} (MA200 + {cfg.regime_arm_pct:g} %)", "betrag": "—"})
            elif getattr(self, "regime_out", False):
                out.append({"was": "Regimebruch-Verkauf ausgelöst", "wann": f"neu scharf, sobald Kurs > {m * (1 + cfg.regime_buffer_pct / 100):,.0f}", "betrag": "—"})
            else:
                out.append({"was": f"Verkauf {cfg.regime_exit_pct:g} % (Regimebruch)", "wann": f"wenn {cfg.regime_confirm_days} Tagesschlüsse < {lvl:,.0f} (MA200 − {cfg.regime_buffer_pct:g} %), bisher {getattr(self, '_below_days', 0)}",
                            "betrag": f"≈ {sellable * cfg.regime_exit_pct / 100 * lvl:,.0f} USD" + (f", {self.coin - sellable:.4f} BTC geschützt" if self.coin - sellable > 1e-9 else "")})
        return out

    def ma_window(self) -> str | None:
        """Aus welchen Tagen der MA200 gerechnet ist — zum Vergleich mit anderen Quellen."""
        d = self.daily[:-1]; n = self.cfg.ma_days
        if len(d) < n or self._day is None:
            return f"erst {len(d)} von {n} Tagesschlüssen vorhanden"
        return f"Mittel der {n} Tagesschlüsse {utc((self._day - n) * DAY)[:10]} bis {utc((self._day - 1) * DAY)[:10]}"

    # ---- Kennzahlen
    def summary(self) -> dict:
        if not self.equity:
            return {}
        e = self.equity[-1]; px = e["px"]
        buys = [t for t in self.trades if t["side"] == "buy"]; sells = [t for t in self.trades if t["side"] == "sell"]
        peak = 0; mdd = 0
        for x in self.equity:
            peak = max(peak, x["equity"]); mdd = max(mdd, (peak - x["equity"]) / peak * 100 if peak else 0)
        return {
            "equity": e["equity"], "paid_in": e["paid"],
            "return_pct": round((e["equity"] / e["paid"] - 1) * 100, 1) if e["paid"] else 0,
            "bench_dca_pct": round((e["bench_dca"] / e["paid"] - 1) * 100, 1) if e["paid"] else 0,
            "bench_hold_pct": round((e["bench_hold"] / e["paid"] - 1) * 100, 1) if e["paid"] else 0,
            "max_dd_pct": round(mdd, 1), "coin": round(self.coin, 6),
            "avg_px": round(sum(t["usd"] for t in buys) / sum(t["coin"] for t in buys), 0) if buys else None,
            "n_buys": len(buys), "n_sells": len(sells),
            "reserve": round(self.reserve, 2), "cash_dca": round(self.cash_dca, 2),
            "open_orders": [{"price": round(o.price), "usd": round(o.usd), "tag": o.tag} for o in self.orders],
            "anchor": round(self.anchor) if self.anchor else None, "last_px": px,
            "ma": round(self.ma()) if self.ma() else None,
            "dist_ma_pct": round((px / self.ma() - 1) * 100, 1) if self.ma() else None,
            "ma_window": self.ma_window(), "pending": self.pending(),
            "ma_regime": round(self.ma_regime()) if self.ma_regime() else None, "regime_ma_days": self.cfg.regime_ma_days or self.cfg.ma_days,
            "coin_value": round(self.coin * px, 2),
        }


# ---------------------------------------------------------------------------
# Laeufe
# ---------------------------------------------------------------------------


class Runner:
    def __init__(self, db_path: str, cfg: Cfg, results_db: str | None = "hl_buyer_results.db"):
        self.db_path = db_path; self.cfg = cfg
        self.con = connect_ro(db_path)
        self.src = pick_source(self.con, cfg.coin)
        self.bot = Buyer(cfg)
        self.running = False; self.progress = 0.0
        self.status = "bereit"; self._stop_event = None; self.last_poll = None; self.last_candle = None; self.fine = None
        self.results = sqlite3.connect(results_db, check_same_thread=False) if results_db else None
        if self.results:
            self.results.executescript("""
            CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY, started INT, mode TEXT, config TEXT);
            CREATE TABLE IF NOT EXISTS trades(run_id TEXT, ts INT, side TEXT, px REAL, usd REAL, coin REAL, how TEXT);
            """); self.results.commit()
        self.run_id = None

    def _record(self, mode: str):
        if not self.results:
            return
        self.run_id = f"{mode}-{int(time.time())}"
        self.results.execute("INSERT INTO runs VALUES(?,?,?,?)", (self.run_id, int(time.time()), mode,
                                                                json.dumps(self.cfg.to_dict()))); self.results.commit()

    def _flush(self, since: int):
        if not self.results or not self.run_id:
            return
        for t in self.bot.trades[since:]:
            self.results.execute("INSERT INTO trades VALUES(?,?,?,?,?,?,?)",
                                 (self.run_id, t["ts"], t["side"], t["px"], t["usd"], t["coin"], t["how"]))
        self.results.commit()

    def backtest(self, t_from: int, t_to: int) -> dict:
        if not self.src:
            return {"error": "Keine Kerzentabelle mit diesem Coin gefunden."}
        table, lo, hi = self.src
        t_from, t_to = max(t_from, lo), min(t_to, hi)
        lead = (self.cfg.ma_days + 5) * DAY
        rows = load_candles(self.con, table, self.cfg.coin, t_from - lead, t_to)
        if not rows:
            return {"error": "Keine Kerzen im Zeitraum."}
        self._record("backtest"); self.running = True
        self.bot.note(t_from, "info", f"Backtest {utc(t_from)} bis {utc(t_to)} auf {table} ({len(rows):,} Kerzen)")
        n = len(rows); done = 0
        for i, (ts, o, h, l, c) in enumerate(rows):
            if ts < t_from:                 # Anlauf: nur Tagesschluesse fuer den MA sammeln
                d = ts // DAY
                if d != self.bot._day: self.bot.daily.append(c); self.bot._day = d
                else: self.bot.daily[-1] = c
                continue
            if not self.running:
                break
            self.bot.step(ts, o, h, l, c)
            if i % 500 == 0:
                self._flush(done); done = len(self.bot.trades); self.progress = i / n
                self.status = f"Simulation {self.progress * 100:.0f} % · {utc(ts)[:10]}"
        self._flush(done); self.running = False; self.progress = 1.0
        self.status = "fertig" if i == n - 1 else "abgebrochen"
        return self.bot.summary()

    def live(self, stop=lambda: False):
        if not self.src:
            return
        table, lo, hi = self.src
        fine = pick_fine_source(self.con, self.cfg.coin) or (table, 1800)
        self.fine = fine
        self._record("live"); self.running = True
        seen = 0; done = 0
        lead = (self.cfg.ma_days + 5) * DAY
        # Vorlauf nur fuer den MA200 — nicht handeln, sonst kauft der Bot die Vergangenheit
        for ts, o, h, l, c in load_candles(self.con, table, self.cfg.coin, int(time.time()) - lead, int(time.time())):
            d = ts // DAY
            if d != self.bot._day: self.bot.daily.append(c); self.bot._day = d
            else: self.bot.daily[-1] = c
            seen = ts
        self.bot.note(int(time.time()), "info", f"Live gestartet: MA-Vorlauf aus {table} bis {utc(seen)}, "
                                               f"neue Kerzen aus {fine[0]} ({fine[1] // 60} min)")
        # erster echter Schritt auf der letzten feinen Kerze, damit Start und Orders sofort stehen
        last = load_candles(self.con, fine[0], self.cfg.coin, int(time.time()) - 3 * fine[1] - 60, int(time.time()))
        if last:
            ts, o, h, l, c = last[-1]; self.bot.step(ts, o, h, l, c); seen = ts
        self.status = "läuft"
        while self.running and not stop():
            try:
                new = load_candles(self.con, fine[0], self.cfg.coin, seen + 1, int(time.time()))
                for ts, o, h, l, c in new:
                    self.bot.step(ts, o, h, l, c); seen = ts
                self._flush(done); done = len(self.bot.trades)
                self.last_poll = int(time.time()); self.last_candle = seen
            except sqlite3.Error as e:
                self.bot.note(int(time.time()), "info", f"Datenbank vorübergehend nicht lesbar: {e}")
            # stop.wait statt sleep: Stopp wirkt sofort, nicht erst nach dem Takt
            if self._stop_event is not None:
                if self._stop_event.wait(self.cfg.live_poll_seconds):
                    break
            else:
                time.sleep(self.cfg.live_poll_seconds)
        self.running = False; self.status = "gestoppt"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="hl_liq.db")
    p.add_argument("--coin", default="BTC")
    p.add_argument("--from", dest="t_from", default="2023-09-04")
    p.add_argument("--to", dest="t_to", default="now")
    p.add_argument("--live", action="store_true")
    p.add_argument("--config", help="JSON-Datei")
    a = p.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    cfg = Cfg.from_dict(json.load(open(a.config))) if a.config else Cfg()
    cfg.coin = a.coin
    r = Runner(a.db, cfg)
    if a.live:
        try: r.live()
        except KeyboardInterrupt: pass
        print(json.dumps(r.bot.summary(), indent=2, ensure_ascii=False)); return
    s = r.backtest(parse_time(a.t_from), parse_time(a.t_to))
    print(json.dumps(s, indent=2, ensure_ascii=False))
    for e in r.bot.journal:
        if e["kind"] in ("buy", "sell"):
            print(f"  {e['t'][:10]}  {e['kind']:4s} {e['text'][:100]}")


if __name__ == "__main__":
    main()
