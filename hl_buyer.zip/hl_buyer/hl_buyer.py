"""
hl_buyer.py — strategischer Kaeufer. Drei Regeln, zwei Anker, sonst nichts.

  Regel 1  Zufuhr wird sofort angelegt: jede Rate im festen Takt (Sparplan).
  Regel 2  Einmalbetraege und Verkaufserloese gehen in eine Reserve. Die Reserve
           liegt als ruhende Kauforders im Buch: Stufen unter dem ANKER, wobei
           der Anker der Kurs beim Eintreffen des Geldes bzw. der Verkaufskurs
           ist — nie das laufende Hoch. Auffang: beruehrt der Kurs den MA200,
           wird der Rest der Reserve am Markt gekauft.
  Regel 3  Steht der Kurs 40 % ueber dem MA200, wird die Haelfte verkauft. Der
           Erloes geht in die Reserve (Regel 2). Sonst wird nie verkauft.

Grundlage: Tageskerzen Binance 2022-2026, siehe ERGEBNISSE.md im alten Paket,
Abschnitte 7-11. Alles andere, was dort geprueft wurde, hat weniger gebracht.

Datenquelle: liest hl_liq.db schreibgeschuetzt (klines30, klines, bnc_bars
oder bars — die laengste Quelle gewinnt). Ergebnisse gehen in hl_buyer_results.db.

    python3 hl_buyer.py --db hl_liq.db --from 2023-09-04 --to now
    python3 hl_buyer.py --db hl_liq.db --live
"""

from __future__ import annotations

import argparse
import json
import logging
import sqlite3
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

log = logging.getLogger("buyer")
DAY = 86400


def utc(ts: int) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M")


def parse_time(s: str) -> int:
    if s in ("now", "jetzt"):
        return int(time.time())
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return int(datetime.strptime(s, fmt).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            pass
    return int(s)


# ---------------------------------------------------------------------------
# Konfiguration — alles hiervon ist im Dashboard editierbar
# ---------------------------------------------------------------------------


@dataclass
class Cfg:
    coin: str = "BTC"
    # Kapital
    start_usd: float = 10000.0          # Einmalbetrag zu Beginn
    start_to_ladder_pct: float = 50.0   # davon in die Reserve-Staffel; Rest sofort per Sparplan
    start_dca_weeks: int = 26           # der Sparplan-Anteil des Starts wird so lange gestreckt
    monthly_usd: float = 200.0          # Zufuhr je Monat -> Regel 1
    dca_every_days: int = 7             # Takt des Sparplans
    no_buy_above_ma_pct: float = 20.0   # Sparplan setzt aus, wenn Kurs mehr als x % ueber MA200
                                        # (0 = nie aussetzen). Ausgesetzte Raten sammeln sich an ...
    backlog_to: str = "catchup"         # ... und werden "catchup" = beim Rueckkehr unter die Schwelle
                                        # auf einmal angelegt, oder "reserve" = in die Staffel gegeben
    # Regel 2: Staffel unter dem Anker (Abstand %, Anteil der noch freien Reserve)
    # Anteile beziehen sich auf die jeweils NOCH freie Reserve; 100 % steht nur
    # ganz unten. Tief genug fuer Zyklustiefs (2022: −55 % unter dem Anker).
    ladder: list = field(default_factory=lambda: [
        {"below_pct": 10.0, "share_pct": 25.0},
        {"below_pct": 15.0, "share_pct": 20.0},
        {"below_pct": 25.0, "share_pct": 25.0},
        {"below_pct": 40.0, "share_pct": 40.0},
        {"below_pct": 55.0, "share_pct": 100.0},
    ])
    manual_levels: list = field(default_factory=list)   # [{"price": 60000, "share_pct": 50}]
    rebuy_at_ma_band_pct: float = 5.0   # Rest der Reserve am Markt, wenn Kurs <= MA200 + x %
    # Regel 3
    ma_days: int = 200
    overheat_pct: float = 40.0          # 0 = nie verkaufen
    sell_frac_pct: float = 50.0
    # Kosten
    fee_bps: float = 8.0
    slip_bps: float = 3.0               # nur bei Marktkaeufen; Limit-Orders fuellen ohne Slippage
    # Betrieb
    live_poll_seconds: int = 30

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Cfg":
        c = cls()
        for k, v in (d or {}).items():
            if hasattr(c, k):
                setattr(c, k, v)
        return c


# ---------------------------------------------------------------------------
# Kerzenquelle
# ---------------------------------------------------------------------------


def connect_ro(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=5.0,
                          check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def pick_source(con: sqlite3.Connection, coin: str) -> tuple[str, int, int] | None:
    """Laengste Kerzentabelle mit diesem Coin: (Tabelle, von, bis)."""
    best = None
    names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    for t in ("klines30", "klines", "bnc_bars", "bars"):
        if t not in names:
            continue
        try:
            r = con.execute(f"SELECT MIN(ts), MAX(ts), COUNT(*) FROM {t} WHERE coin=?",
                            (coin,)).fetchone()
        except sqlite3.Error:
            continue
        if r and r[2] and (best is None or (r[1] - r[0]) > (best[2] - best[1])):
            best = (t, int(r[0]), int(r[1]))
    return best


def load_candles(con, table: str, coin: str, t_from: int, t_to: int) -> list[tuple]:
    cur = con.execute(
        f"SELECT ts, open, high, low, close FROM {table} WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts",
        (coin, t_from, t_to))
    return [(int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4])) for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


@dataclass
class Order:
    price: float
    usd: float
    tag: str                 # "Staffel -10 %", "Marke 60000"


class Buyer:
    def __init__(self, cfg: Cfg):
        self.cfg = cfg
        self.coin = 0.0
        self.cash_dca = 0.0          # Regel 1
        self.reserve = 0.0           # Regel 2
        self.paid_in = 0.0
        self.orders: list[Order] = []
        self.anchor: float | None = None
        self.sold = False
        self.sale_px: float | None = None
        self.trades: list[dict] = []
        self.journal: list[dict] = []
        self.equity: list[dict] = []
        self.daily: list[float] = []   # Tagesschluesse fuer den MA200
        self._day: int | None = None
        self._month: int | None = None
        self._last_dca_day: int | None = None
        self._start_per: float = 0.0
        self._start_left: float = 0.0
        # Vergleich, gleiche Zufuhr
        self.bench_dca_coin = 0.0; self.bench_dca_cash = 0.0
        self.bench_hold_coin = 0.0; self.bench_hold_started = False
        self.ma_hist: list[tuple] = []

    # ---- Hilfen
    def ma(self) -> float | None:
        d = self.daily[:-1]              # abgeschlossene Tage
        n = self.cfg.ma_days
        return sum(d[-n:]) / n if len(d) >= n else None

    def value(self, px: float) -> float:
        return self.cash_dca + self.reserve + self.coin * px

    def note(self, ts: int, kind: str, text: str, **extra):
        self.journal.append({"ts": ts, "t": utc(ts), "kind": kind, "text": text, **extra})

    def _buy(self, ts: int, px: float, usd: float, how: str, bucket: str):
        fee = usd * self.cfg.fee_bps / 1e4
        got = (usd - fee) / px
        self.coin += got
        if bucket == "dca":
            self.cash_dca -= usd
        else:
            self.reserve -= usd
        self.trades.append({"ts": ts, "side": "buy", "px": px, "usd": usd, "coin": got, "how": how})
        self.note(ts, "buy", f"Kauf {usd:,.0f} USD zu {px:,.0f} — {how}")

    def _place_ladder(self, ts: int, anchor: float, why: str):
        """Reserve als ruhende Orders unter den Anker legen — sequentielle Anteile."""
        self.orders = []
        left = self.reserve
        for step in self.cfg.ladder:
            usd = left * step["share_pct"] / 100.0
            if usd < 1:
                continue
            self.orders.append(Order(anchor * (1 - step["below_pct"] / 100.0), usd,
                                     f"Staffel −{step['below_pct']:g} %"))
            left -= usd
        for m in self.cfg.manual_levels:
            usd = self.reserve * m.get("share_pct", 0) / 100.0
            if usd >= 1 and m.get("price"):
                self.orders.append(Order(float(m["price"]), usd, f"Marke {float(m['price']):,.0f}"))
        self.anchor = anchor
        self.note(ts, "info", f"Reserve {self.reserve:,.0f} USD als {len(self.orders)} ruhende Orders "
                              f"unter Anker {anchor:,.0f} gelegt ({why}): "
                              + ", ".join(f"{o.tag} @ {o.price:,.0f} für {o.usd:,.0f}" for o in self.orders))

    # ---- ein Schritt je Kerze
    def step(self, ts: int, o: float, h: float, l: float, c: float):
        cfg = self.cfg
        day = ts // DAY
        # Tagesschluesse
        if day != self._day:
            self.daily.append(c); self._day = day
        else:
            self.daily[-1] = c
        # Start und Zufuhr
        if not self.paid_in:
            self.paid_in = cfg.start_usd
            to_ladder = cfg.start_usd * cfg.start_to_ladder_pct / 100.0
            self.reserve = to_ladder
            self._start_left = cfg.start_usd - to_ladder
            self._start_per = self._start_left / max(1, cfg.start_dca_weeks) if self._start_left else 0
            self.cash_dca = self._start_left
            self.bench_dca_cash = cfg.start_usd
            self.bench_hold_coin = cfg.start_usd * (1 - cfg.fee_bps / 1e4) / c
            self.note(ts, "info", f"Start: {cfg.start_usd:,.0f} USD — {to_ladder:,.0f} in die Reserve, "
                                  f"{self._start_left:,.0f} über {cfg.start_dca_weeks} Wochen per Sparplan")
            if to_ladder > 0:
                self._place_ladder(ts, c, "Startkapital")
        month = datetime.fromtimestamp(ts, timezone.utc).month
        if self._month is not None and month != self._month and cfg.monthly_usd > 0:
            self.cash_dca += cfg.monthly_usd; self.paid_in += cfg.monthly_usd
            self.bench_dca_cash += cfg.monthly_usd
            self.bench_hold_coin += cfg.monthly_usd * (1 - cfg.fee_bps / 1e4) / c
            self.note(ts, "info", f"Zufuhr {cfg.monthly_usd:,.0f} USD")
        self._month = month

        # Regel 1: Sparplan im Takt — ausgesetzt, solange der Kurs zu weit ueber dem MA liegt
        m0 = self.ma()
        too_high = (cfg.no_buy_above_ma_pct > 0 and m0 is not None
                    and (c / m0 - 1) * 100.0 > cfg.no_buy_above_ma_pct)
        if self._last_dca_day is None or day - self._last_dca_day >= cfg.dca_every_days:
            per_month = cfg.monthly_usd * cfg.dca_every_days / 30.0
            rate = per_month + (self._start_per if self._start_left > 0 else 0)
            if too_high:
                self._backlog = getattr(self, "_backlog", 0.0) + min(rate, self.cash_dca - getattr(self, "_backlog", 0.0))
                if not getattr(self, "_paused_noted", False):
                    self.note(ts, "info", f"Sparplan ausgesetzt: {(c/m0-1)*100:+.0f} % ueber MA{cfg.ma_days} "
                                          f"(Grenze {cfg.no_buy_above_ma_pct:g} %) — Raten sammeln sich")
                    self._paused_noted = True
                self._start_left = max(0.0, self._start_left - self._start_per)
            else:
                backlog = getattr(self, "_backlog", 0.0)
                if backlog >= 1 and cfg.backlog_to == "reserve":
                    self.cash_dca -= backlog; self.reserve += backlog; self._backlog = 0.0
                    self.note(ts, "info", f"Angesammelte Raten {backlog:,.0f} USD in die Reserve")
                    self._place_ladder(ts, c, "angesammelte Sparplan-Raten")
                    backlog = 0.0
                amt = min(self.cash_dca, rate + backlog)
                if amt >= 1:
                    px = c * (1 + cfg.slip_bps / 1e4)
                    self._buy(ts, px, amt, "Sparplan" + (f" + Nachholung {backlog:,.0f}" if backlog >= 1 else ""), "dca")
                    self._start_left = max(0.0, self._start_left - self._start_per)
                self._backlog = 0.0; self._paused_noted = False
            # Vergleich: reiner Sparplan mit derselben Zufuhr
            bamt = min(self.bench_dca_cash, per_month + (cfg.start_usd / max(1, cfg.start_dca_weeks)
                                                         if self.bench_dca_cash > cfg.monthly_usd * 2 else 0))
            if bamt >= 1:
                self.bench_dca_coin += bamt * (1 - cfg.fee_bps / 1e4) / c; self.bench_dca_cash -= bamt
            self._last_dca_day = day

        # Regel 2: ruhende Orders fuellen, wenn das Tief sie beruehrt (nie ueber dem Markt)
        for od in list(self.orders):
            if l <= od.price and self.reserve >= od.usd - 0.01:
                px = min(od.price, o) if o < od.price else od.price   # Gap unter die Order: Eroeffnung
                self._buy(ts, px, min(od.usd, self.reserve), od.tag, "reserve")
                self.orders.remove(od)
        m = self.ma()
        if m is not None:
            dist = (c / m - 1) * 100.0
            self.ma_hist.append((ts, m))
            # Auffang: MA200 beruehrt -> Rest der Reserve am Markt
            if self.reserve >= 1 and dist <= cfg.rebuy_at_ma_band_pct and self.orders:
                px = c * (1 + cfg.slip_bps / 1e4)
                self._buy(ts, px, self.reserve, f"Rest der Reserve am MA200 ({dist:+.1f} %)", "reserve")
                self.orders = []
            # Regel 3: Ueberdehnung
            if cfg.overheat_pct > 0 and dist > cfg.overheat_pct and not self.sold and self.coin > 0:
                amt = self.coin * cfg.sell_frac_pct / 100.0
                usd = amt * c; fee = usd * cfg.fee_bps / 1e4
                self.coin -= amt; self.reserve += usd - fee; self.sold = True; self.sale_px = c
                self.trades.append({"ts": ts, "side": "sell", "px": c, "usd": usd, "coin": amt,
                                    "how": f"Überdehnung {dist:+.0f} % über MA{cfg.ma_days}"})
                self.note(ts, "sell", f"Verkauf {cfg.sell_frac_pct:g} % ({amt:.4f} BTC) zu {c:,.0f} — "
                                      f"{dist:+.0f} % über MA{cfg.ma_days}")
                self._place_ladder(ts, c, "Verkaufserlös")
            if self.sold and dist < cfg.overheat_pct * 0.5:
                self.sold = False
        self.equity.append({"ts": ts, "px": c, "equity": round(self.value(c), 2),
                            "paid": round(self.paid_in, 2), "reserve": round(self.reserve, 2),
                            "coin": round(self.coin, 6),
                            "bench_dca": round(self.bench_dca_cash + self.bench_dca_coin * c, 2),
                            "bench_hold": round(self.bench_hold_coin * c, 2)})

    # ---- Kennzahlen
    def summary(self) -> dict:
        if not self.equity:
            return {}
        e = self.equity[-1]; px = e["px"]
        buys = [t for t in self.trades if t["side"] == "buy"]; sells = [t for t in self.trades if t["side"] == "sell"]
        peak = 0; mdd = 0
        for x in self.equity:
            peak = max(peak, x["equity"]); mdd = max(mdd, (peak - x["equity"]) / peak * 100 if peak else 0)
        return {
            "equity": e["equity"], "paid_in": e["paid"],
            "return_pct": round((e["equity"] / e["paid"] - 1) * 100, 1) if e["paid"] else 0,
            "bench_dca_pct": round((e["bench_dca"] / e["paid"] - 1) * 100, 1) if e["paid"] else 0,
            "bench_hold_pct": round((e["bench_hold"] / e["paid"] - 1) * 100, 1) if e["paid"] else 0,
            "max_dd_pct": round(mdd, 1), "coin": round(self.coin, 6),
            "avg_px": round(sum(t["usd"] for t in buys) / sum(t["coin"] for t in buys), 0) if buys else None,
            "n_buys": len(buys), "n_sells": len(sells),
            "reserve": round(self.reserve, 2), "cash_dca": round(self.cash_dca, 2),
            "open_orders": [{"price": round(o.price), "usd": round(o.usd), "tag": o.tag} for o in self.orders],
            "anchor": round(self.anchor) if self.anchor else None, "last_px": px,
            "ma": round(self.ma()) if self.ma() else None,
            "dist_ma_pct": round((px / self.ma() - 1) * 100, 1) if self.ma() else None,
        }


# ---------------------------------------------------------------------------
# Laeufe
# ---------------------------------------------------------------------------


class Runner:
    def __init__(self, db_path: str, cfg: Cfg, results_db: str | None = "hl_buyer_results.db"):
        self.db_path = db_path; self.cfg = cfg
        self.con = connect_ro(db_path)
        self.src = pick_source(self.con, cfg.coin)
        self.bot = Buyer(cfg)
        self.running = False; self.progress = 0.0
        self.results = sqlite3.connect(results_db, check_same_thread=False) if results_db else None
        if self.results:
            self.results.executescript("""
            CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY, started INT, mode TEXT, config TEXT);
            CREATE TABLE IF NOT EXISTS trades(run_id TEXT, ts INT, side TEXT, px REAL, usd REAL, coin REAL, how TEXT);
            """); self.results.commit()
        self.run_id = None

    def _record(self, mode: str):
        if not self.results:
            return
        self.run_id = f"{mode}-{int(time.time())}"
        self.results.execute("INSERT INTO runs VALUES(?,?,?,?)", (self.run_id, int(time.time()), mode,
                                                                json.dumps(self.cfg.to_dict()))); self.results.commit()

    def _flush(self, since: int):
        if not self.results or not self.run_id:
            return
        for t in self.bot.trades[since:]:
            self.results.execute("INSERT INTO trades VALUES(?,?,?,?,?,?,?)",
                                 (self.run_id, t["ts"], t["side"], t["px"], t["usd"], t["coin"], t["how"]))
        self.results.commit()

    def backtest(self, t_from: int, t_to: int) -> dict:
        if not self.src:
            return {"error": "Keine Kerzentabelle mit diesem Coin gefunden."}
        table, lo, hi = self.src
        t_from, t_to = max(t_from, lo), min(t_to, hi)
        lead = (self.cfg.ma_days + 5) * DAY
        rows = load_candles(self.con, table, self.cfg.coin, t_from - lead, t_to)
        if not rows:
            return {"error": "Keine Kerzen im Zeitraum."}
        self._record("backtest"); self.running = True
        self.bot.note(t_from, "info", f"Backtest {utc(t_from)} bis {utc(t_to)} auf {table} ({len(rows):,} Kerzen)")
        n = len(rows); done = 0
        for i, (ts, o, h, l, c) in enumerate(rows):
            if ts < t_from:                 # Anlauf: nur Tagesschluesse fuer den MA sammeln
                d = ts // DAY
                if d != self.bot._day: self.bot.daily.append(c); self.bot._day = d
                else: self.bot.daily[-1] = c
                continue
            if not self.running:
                break
            self.bot.step(ts, o, h, l, c)
            if i % 500 == 0:
                self._flush(done); done = len(self.bot.trades); self.progress = i / n
        self._flush(done); self.running = False; self.progress = 1.0
        return self.bot.summary()

    def live(self, stop=lambda: False):
        if not self.src:
            return
        table, lo, hi = self.src
        self._record("live"); self.running = True
        seen = 0; done = 0
        lead = (self.cfg.ma_days + 5) * DAY
        # Vorlauf nur fuer den MA200 — nicht handeln, sonst kauft der Bot die Vergangenheit
        for ts, o, h, l, c in load_candles(self.con, table, self.cfg.coin, int(time.time()) - lead, int(time.time())):
            d = ts // DAY
            if d != self.bot._day: self.bot.daily.append(c); self.bot._day = d
            else: self.bot.daily[-1] = c
            seen = ts
        self.bot.note(int(time.time()), "info", f"Live gestartet, MA-Vorlauf bis {utc(seen)}; "
                                               f"erster Schritt handelt auf der naechsten Kerze")
        # der erste echte Schritt: letzte Kerze erneut, damit Start und Orders sofort stehen
        last = load_candles(self.con, table, self.cfg.coin, seen, seen)
        if last:
            ts, o, h, l, c = last[-1]; self.bot.step(ts, o, h, l, c)
        while self.running and not stop():
            for ts, o, h, l, c in load_candles(self.con, table, self.cfg.coin, seen + 1, int(time.time())):
                self.bot.step(ts, o, h, l, c); seen = ts
            self._flush(done); done = len(self.bot.trades)
            time.sleep(self.cfg.live_poll_seconds)
        self.running = False


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="hl_liq.db")
    p.add_argument("--coin", default="BTC")
    p.add_argument("--from", dest="t_from", default="2023-09-04")
    p.add_argument("--to", dest="t_to", default="now")
    p.add_argument("--live", action="store_true")
    p.add_argument("--config", help="JSON-Datei")
    a = p.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    cfg = Cfg.from_dict(json.load(open(a.config))) if a.config else Cfg()
    cfg.coin = a.coin
    r = Runner(a.db, cfg)
    if a.live:
        try: r.live()
        except KeyboardInterrupt: pass
        print(json.dumps(r.bot.summary(), indent=2, ensure_ascii=False)); return
    s = r.backtest(parse_time(a.t_from), parse_time(a.t_to))
    print(json.dumps(s, indent=2, ensure_ascii=False))
    for e in r.bot.journal:
        if e["kind"] in ("buy", "sell"):
            print(f"  {e['t'][:10]}  {e['kind']:4s} {e['text'][:100]}")


if __name__ == "__main__":
    main()
