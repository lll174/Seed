"""
hl_buyerdash.py — Oberflaeche fuer den Kaeufer-Bot, Port 8767.

    python3 hl_buyerdash.py --db ../hl_liq.db --host 0.0.0.0

Liest die Recorder-Datenbank nur lesend. Keine echten Orders.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from hl_buyer import Cfg, Runner, parse_time, utc, connect_ro, pick_source, pick_fine_source, load_candles, DAY

VERSION = "buyer 2026-09-05q"
DB_PATH = "hl_liq.db"


PRESETS = "hl_buyer_presets.json"


def presets_load() -> dict:
    try:
        return json.load(open(PRESETS))
    except Exception:  # noqa: BLE001
        return {}


def presets_save(d: dict):
    json.dump(d, open(PRESETS, "w"), ensure_ascii=False, indent=1)


class Session:
    def __init__(self):
        saved = presets_load().get("_zuletzt")
        self.cfg = Cfg.from_dict(saved) if saved else Cfg()
        self.runner: Runner | None = None
        self.thread = None; self.mode = "idle"; self.stop = threading.Event(); self.error = None

    def busy(self): return self.thread is not None and self.thread.is_alive()

    def start(self, kind: str, t_from: int = 0, t_to: int = 0):
        if self.busy():
            # laeuft noch, aber Stopp wurde gedrueckt: kurz warten, dann uebernehmen
            self.halt(); self.thread.join(timeout=3.0)
            if self.busy():
                return {"error": "Der vorige Durchgang beendet sich gerade — bitte gleich noch einmal klicken."}
        self.stop.clear(); self.error = None; self.mode = kind
        def work():
            try:
                self.runner = Runner(DB_PATH, self.cfg)
                self.runner._stop_event = self.stop
                if kind == "live": self.runner.live(stop=self.stop.is_set)
                else:
                    r = self.runner.backtest(t_from, t_to)
                    if r.get("error"): self.error = r["error"]
            except Exception as e:  # noqa: BLE001
                self.error = f"{type(e).__name__}: {e}"
            finally: self.mode = "idle"
        self.thread = threading.Thread(target=work, daemon=True); self.thread.start()
        return {"ok": True}

    def halt(self):
        self.stop.set()
        if self.runner: self.runner.running = False
        return {"ok": True}


S = Session()

FIELDS = [
    ("sparplan", "Sparplan", "Regel 1. Legt die monatliche Einzahlung automatisch an — im festen Takt, ohne Kursbetrachtung. "
                 "Auf 2022–2026 war der reine Sparplan der härteste Vergleichsmaßstab.", [
        ("monthly_usd", "Einzahlung je Monat", "USD",
         "Dieser Betrag kommt am Monatsersten dazu und wird vom Sparplan angelegt."),
        ("dca_every_days", "Kauf-Takt", "Tage",
         "Alle so viele Tage kauft der Sparplan den bis dahin angesammelten Anteil der Monatsrate."),
        ("no_buy_above_ma_pct", "Pause, wenn der Kurs mehr als … über dem 200-Tage-Durchschnitt steht", "% (0 = keine Pause)",
         "Käufe weit über dem Durchschnitt brachten in der Analyse Verluste. Ab dieser Grenze setzt der Sparplan aus. "
         "Vorsicht: bei 10–15 % pausiert er in Bullenmärkten monatelang; 20 % ist der belegte Wert."),
        ("backlog_to", "Ausgesetzte Raten", "",
         "Nachholen: sobald der Kurs wieder unter der Grenze liegt, wird alles Aufgelaufene auf einmal gekauft. "
         "Reserve: das Geld geht an den Bot und wird als Kauforders unter den Kurs gelegt.",
         [["catchup", "beim Rückkehr nachholen"], ["reserve", "an den Bot (Reserve) geben"]]),
    ]),
    ("bot", "Bot — Startkapital und Reserve", "Regel 2. Der Bot verwaltet die Reserve: das Startkapital und alles, was Verkäufe einbringen. "
            "Die Reserve wird nicht sofort angelegt, sondern als Kauforders unter den Kurs gelegt.", [
        ("start_usd", "Startkapital", "USD", "Einmalbetrag zu Beginn."),
        ("start_to_ladder_pct", "davon in die Reserve", "%",
         "Dieser Anteil wird als Staffel-Orders unter den Startkurs gelegt. Der Rest geht in den Sparplan."),
        ("start_dca_weeks", "Rest des Startkapitals verteilt über", "Wochen",
         "Der Sparplan-Anteil des Startkapitals wird gleichmäßig über diese Zeit angelegt, nicht auf einmal."),
        ("rebuy_at_ma_band_pct", "Restliche Reserve sofort kaufen, wenn der Kurs höchstens … über dem 200-Tage-Durchschnitt steht", "%",
         "Auffang: kommt der Kurs an den Durchschnitt heran, wartet der Bot nicht mehr auf tiefere Stufen, sondern kauft die "
         "restliche Reserve am Markt. In der Analyse waren Käufe 0–5 % über dem Durchschnitt die besten."),
    ]),
    ("verkauf", "Bot — Verkauf", "Regel 3. Die einzige Verkaufsregel. Alles andere (Trailing-Stop, Leiter, Regimewechsel) "
                "hat in der Analyse Geld gekostet.", [
        ("ma_days", "Gleitender Durchschnitt", "Tage", "Grundlage für Pause, Auffang und Verkauf. 200 ist der belegte Wert."),
        ("overheat_pct", "Verkauf, wenn der Kurs mehr als … über dem Durchschnitt steht", "% (0 = nie verkaufen)",
         "Alle drei Überhitzungen 2023–2025 drehten bei 45–53 % über dem 200-Tage-Durchschnitt. 40 fängt sie alle; "
         "35 verkauft einmal zu früh; 50 hätte zwei verpasst."),
        ("regime_exit_pct", "Regimebruch-Verkauf: Anteil, wenn der Schluss unter MA200 − Puffer fällt", "% (0 = aus)",
         "Antwort auf den Oktober 2025: verkauft Mitte Januar 2026 bei rund 88.000, kauft gestaffelt darunter zurück. "
         "Tageskerzen: ab 2025 +10 % statt −10 %, Rückgang 29 statt 46 %; über 2022–2026 +77 % statt +106 %. "
         "Versicherung, keine Rendite — deshalb aus."),
        ("regime_buffer_pct", "… Puffer unter dem MA200", "%", "5 % vermeidet die meisten Fehlsignale; 3 % verkauft bei jedem Kratzer (8 statt 4 Verkäufe)."),
        ("regime_confirm_days", "… erst nach so vielen Tagesschlüssen in Folge darunter", "Tage",
         "Ein einzelner Tag unter der Linie ist Rauschen. 5 Tage halbieren die Fehlverkäufe fast ohne Verzögerung am Top."),
        ("regime_arm_pct", "… scharf erst, wenn der Kurs seit dem Ende der letzten Baisse so weit über dem MA200 stand", "% (0 = immer scharf)",
         "Schutz für die Coins aus der Baisse: nach dem Kreuzen von unten ist der Verkauf entschärft, bis ein echter Bullenmarkt da war. "
         "Rücksetzer bei +5 oder +10 % über dem MA200 direkt nach der Baisse können dann nichts auslösen."),
        ("bear_min_days", "… Baisse = so viele Tage in Folge unter dem MA200", "Tage",
         "Erst ein Kreuzen nach einer so langen Phase gilt als neues Regime. Ein paar Tage Gezappel um den MA200 (Sommer 2024) zählen nicht."),
        ("protect_bear_lots", "Coins, die unter dem MA200 gekauft wurden, nie per Regimebruch verkaufen", "", 
         "Geschützt sind nur Käufe in einer echten Baisse (Kurs seit mindestens der eingestellten Baisse-Tage unter dem MA200) — "
         "nicht Käufe in kurzen Rücksetzern. Kostet Rendite, wenn der Verkauf richtig war, weil Geld keinen Einkaufskurs kennt. "
         "Der Mouseover am S zeigt, wie viel verkaufbar war und wie viel geschützt.",
         [[0, "nein"], [1, "ja"]]),
        ("sell_frac_pct", "Verkaufter Anteil des Bestands", "%",
         "Der Erlös wird zur neuen Reserve und als Staffel unter den Verkaufskurs gelegt. 50 % statt 100 %, weil drei "
         "Episoden keine Statistik sind und eine echte Manie höher läuft."),
    ]),
    ("kosten", "Kosten", "", [
        ("fee_bps", "Gebühr je Kauf oder Verkauf", "Basispunkte", "8 bps = 0,08 %. Hyperliquid-Spot als Taker liegt bei 4–7 bps; 1 bps schönt jedes Ergebnis."),
        ("slip_bps", "Slippage bei Marktkäufen", "Basispunkte", "Nur für Käufe am Markt (Sparplan, Auffang). Ruhende Orders füllen ohne Slippage."),
        ("live_poll_seconds", "Live-Takt", "Sekunden", "Wie oft der Bot im Live-Betrieb nach neuen Kerzen sieht."),
    ]),
]


def chart(coin, t_from, t_to, agg_min):
    con = connect_ro(DB_PATH); src = pick_source(con, coin)
    if not src: return {"candles": [], "ma": []}
    table = src[0]
    if agg_min < 30:                      # feiner als der Download: aus der Recorder-Tabelle
        fine = pick_fine_source(con, coin)
        if fine and fine[1] // 60 <= agg_min: table = fine[0]
    # nie mehr als ~1500 Kerzen: Verdichtung automatisch anheben
    span_min = max(1, (t_to - t_from) // 60)
    while span_min // agg_min > 1500:
        agg_min = {1: 5, 5: 15, 15: 30, 30: 60, 60: 240, 240: 1440}.get(agg_min, agg_min * 4)
    step = agg_min * 60
    rows = load_candles(con, table, coin, t_from, t_to)
    if not rows:                                    # Download endet vor dem Fenster: Recorder-Tabelle nehmen
        fine = pick_fine_source(con, coin)
        if fine and fine[0] != table:
            rows = load_candles(con, fine[0], coin, t_from, t_to); table = fine[0]
    # Tagesschluesse fuer den MA200 IMMER aus der langen Tabelle, ergaenzt um die feinen Kerzen
    long_rows = load_candles(con, src[0], coin, t_from - (S.cfg.ma_days + 5) * DAY, t_to)
    buckets = {}
    for ts, o, h, l, c in rows:
        k = ts // step * step; b = buckets.get(k)
        if b is None: buckets[k] = {"ts": k, "o": o, "h": h, "l": l, "c": c}
        else: b["h"] = max(b["h"], h); b["l"] = min(b["l"], l); b["c"] = c
    candles = [buckets[k] for k in sorted(buckets)]
    # MA auf Tagesschluessen (lange Tabelle zuerst, feine Kerzen ueberschreiben die juengsten Tage)
    daily = {}
    for ts, o, h, l, c in long_rows: daily[ts // DAY] = c
    for ts, o, h, l, c in rows: daily[ts // DAY] = c
    days = sorted(daily); closes = [daily[d] for d in days]; idx = {d: i for i, d in enumerate(days)}; n = S.cfg.ma_days
    for b in candles:
        d = b["ts"] // DAY; i = idx.get(d)
        if i is None:
            prev = [x for x in days if x <= d]; i = idx[prev[-1]] if prev else None
        b["ma"] = sum(closes[i - n + 1:i + 1]) / n if i is not None and i + 1 >= n else None
    con.close()
    return {"candles": candles, "from": t_from, "to": t_to, "source": table, "agg_min": agg_min}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, obj, code=200, ctype="application/json"):
        body = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        try:
            if u.path == "/": return self._send(PAGE.encode(), ctype="text/html")
            if u.path == "/api/config":
                con = connect_ro(DB_PATH); src = pick_source(con, S.cfg.coin); con.close()
                import os
                return self._send({"config": S.cfg.to_dict(), "fields": FIELDS, "version": VERSION,
                                   "file": os.path.abspath(__file__),
                                   "presets": sorted(k for k in presets_load() if not k.startswith("_")),
                                   "source": {"table": src[0], "from": utc(src[1]), "to": utc(src[2])} if src else None})
            if u.path == "/api/state":
                r = S.runner
                if not r: return self._send({"mode": S.mode, "empty": True, "error": S.error})
                b = r.bot; q = b.summary(); m = b.ma()
                status = {"text": r.status, "mode": S.mode, "last_candle": utc(r.last_candle) if r.last_candle else (utc(b.equity[-1]["ts"]) if b.equity else None),
                          "last_poll": utc(r.last_poll) if r.last_poll else None, "source": r.fine[0] if r.fine else (r.src[0] if r.src else None),
                          "candle_min": (r.fine[1] // 60) if r.fine else None, "px": q.get("last_px"), "ma": q.get("ma"), "dist": q.get("dist_ma_pct"),
                          "reserve": q.get("reserve"), "orders": len(q.get("open_orders", [])), "coin": q.get("coin"),
                          "paused": bool(m and q.get("last_px") and S.cfg.no_buy_above_ma_pct > 0 and (q["last_px"] / m - 1) * 100 > S.cfg.no_buy_above_ma_pct)}
                return self._send({"mode": S.mode, "progress": round(r.progress, 3), "error": S.error, "status": status,
                                   "summary": b.summary(), "cursor": b.equity[-1]["ts"] if b.equity else None,
                                   "trades": b.trades[-300:], "journal": b.journal[-120:][::-1],
                                   "equity": b.equity[::max(1, len(b.equity) // 600)]})
            if u.path == "/api/chart":
                now = int(time.time()); t_to = int(q.get("to", [now])[0]); t_from = int(q.get("from", [t_to - 30 * DAY])[0])
                return self._send(chart(S.cfg.coin, t_from, t_to, int(q.get("agg", [1440])[0])))
        except Exception as e:  # noqa: BLE001
            return self._send({"error": f"{type(e).__name__}: {e}"}, 500)
        self._send({"error": "unbekannt"}, 404)

    def do_POST(self):
        u = urlparse(self.path); n = int(self.headers.get("Content-Length", 0)); d = json.loads(self.rfile.read(n) or b"{}")
        try:
            if u.path == "/api/config":
                S.cfg.update(d)                     # in place: der laufende Bot sieht es sofort
                p = presets_load(); p["_zuletzt"] = S.cfg.to_dict(); presets_save(p)   # ueberlebt Neustart
                return self._send({"ok": True})
            if u.path == "/api/preset/save":
                name = str(d.get("name", "")).strip()
                if not name or name.startswith("_"): return self._send({"error": "Name fehlt."})
                p = presets_load(); p[name] = S.cfg.to_dict(); presets_save(p)
                return self._send({"ok": True, "names": sorted(k for k in p if not k.startswith("_"))})
            if u.path == "/api/preset/load":
                p = presets_load(); name = str(d.get("name", ""))
                if name == "_standard": S.cfg.update(Cfg().to_dict())
                elif name in p: S.cfg.update(p[name])
                else: return self._send({"error": "Unbekannt."})
                p["_zuletzt"] = S.cfg.to_dict(); presets_save(p)
                return self._send({"ok": True, "config": S.cfg.to_dict()})
            if u.path == "/api/preset/delete":
                p = presets_load(); p.pop(str(d.get("name", "")), None); presets_save(p)
                return self._send({"ok": True, "names": sorted(k for k in p if not k.startswith("_"))})
            if u.path == "/api/backtest": return self._send(S.start("backtest", parse_time(str(d.get("from", "2023-09-04"))), parse_time(str(d.get("to", "now")))))
            if u.path == "/api/live": return self._send(S.start("live"))
            if u.path == "/api/stop": return self._send(S.halt())
        except Exception as e:  # noqa: BLE001
            return self._send({"error": f"{type(e).__name__}: {e}"}, 500)
        self._send({"error": "unbekannt"}, 404)


PAGE = r"""<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Käufer-Bot</title>
<style>
:root{--g:#0f151b;--p:#182028;--p2:#243040;--r:#3a4756;--t:#eef2f6;--m:#a9b6c3;--up:#4fc3ad;--dn:#e0745f;--lila:#a58cf0;--buy:#5fd3b1;--sell:#f07ea0;--fs:15px}
html.big{--fs:18px}
*{box-sizing:border-box}body{margin:0;background:var(--g);color:var(--t);font:var(--fs)/1.5 ui-sans-serif,system-ui,"Segoe UI",Roboto,sans-serif}
header{display:flex;gap:26px;align-items:baseline;flex-wrap:wrap;padding:16px 22px;border-bottom:2px solid var(--r);background:var(--p)}
h1{font-size:1.25em;margin:0;color:#fff}.sub{color:var(--m);font-size:.85em}.sp{flex:1}
.stat{display:flex;flex-direction:column}.stat b{font-size:1.55em;font-variant-numeric:tabular-nums;color:#fff}.stat span{font-size:.8em;color:var(--m)}
.pos{color:var(--up)!important}.neg{color:var(--dn)!important}
.status{margin-top:6px;font-size:.9em;color:#fff;background:var(--p2);border-left:4px solid var(--m);padding:4px 10px;border-radius:0 3px 3px 0;max-width:720px}
.status.live{border-left-color:var(--up)}.status.sim{border-left-color:var(--lila)}.status.stop{border-left-color:var(--dn)}
html,body{overflow-x:hidden;max-width:100vw}
main{display:grid;grid-template-columns:390px minmax(0,1fr) 320px;gap:2px;background:var(--r);max-width:100vw}
section{background:var(--g);padding:18px 20px;overflow:auto;min-width:0}
canvas{max-width:100%}td,th{word-break:break-word}.chartlegend div{min-width:0}
h2{font-size:1.05em;font-weight:700;color:#fff;margin:22px 0 10px;padding:6px 10px;background:var(--p2);border-left:4px solid var(--m);border-radius:0 3px 3px 0;letter-spacing:.01em}
h2.l{border-left-color:var(--lila);color:#d9ccff}
label{display:block;margin-bottom:6px;font-size:.95em}label span{display:block;color:var(--t);margin-bottom:4px;line-height:1.35}
label input,label select{display:inline-block;margin-right:6px}em{color:var(--m);font-style:normal;font-size:.85em}
.stufen{width:100%;border-collapse:collapse;margin:6px 0 8px}.stufen th{font-size:.8em;color:var(--m);font-weight:600;text-align:left;padding:2px 4px;border:0}
.stufen td{padding:3px 4px;border:0}.stufen input{width:82px;margin:0}.stufen button{padding:3px 9px}
input,select{background:var(--p2);border:1px solid var(--r);color:#fff;border-radius:4px;padding:7px 9px;width:96px;text-align:right;font:inherit;font-variant-numeric:tabular-nums}
input:focus,select:focus{outline:2px solid var(--lila);outline-offset:1px}
input.w{width:150px;text-align:left}button{background:var(--p2);border:1px solid var(--r);color:#fff;border-radius:4px;padding:9px 14px;font:inherit;cursor:pointer}
button.go{background:var(--up);border-color:var(--up);color:#0d1613;font-weight:700}button.halt{background:var(--dn);border-color:var(--dn);color:#1a0f0c;font-weight:700}
.row{display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap}canvas{width:100%;display:block;border:1px solid var(--r);border-radius:4px;background:var(--p)}
table{width:100%;border-collapse:collapse;font-size:.9em}th{text-align:left;color:var(--m);font-weight:600;padding:6px 8px;border-bottom:2px solid var(--r)}td{padding:6px 8px;border-bottom:1px solid #263140;font-variant-numeric:tabular-nums}.r{text-align:right}
.tag{display:inline-block;width:18px;height:18px;line-height:18px;text-align:center;border-radius:3px;font-size:.75em;font-weight:700;color:#101820}.b{background:var(--buy)}.s{background:var(--sell)}
.jrn{max-height:280px;overflow:auto;font-size:.9em}.jrn div{padding:5px 0;border-bottom:1px solid #263140;display:flex;gap:9px}.jrn time{color:var(--m);white-space:nowrap}
.hint{color:var(--m);font-size:.85em;margin:4px 0 10px}.bar{height:4px;background:var(--p2);margin:8px 0}.bar i{display:block;height:100%;background:var(--lila);width:0}
.lad{margin:0}
.help{color:var(--m);font-size:.8em;margin:-4px 0 12px 2px;line-height:1.4}
.chartlegend{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:4px 18px;margin:8px 0 4px;font-size:.85em;color:var(--t)}
.chartlegend div{display:flex;align-items:center;gap:8px;line-height:1.3}
.sw{display:inline-block;width:34px;height:0;flex:0 0 34px;border-top:2px solid}
.sw.ma{border-color:#a58cf0;border-top-width:3px}.sw.sell{border-color:#a58cf0;border-top-style:dashed}
.sw.pause{border-color:#e0a33e;border-top-style:dashed}.sw.band{border-color:rgba(165,140,240,.55);border-top-style:dotted}
.sw.order{border-color:#5fd3b1;border-top-style:dashed}.sw.cur{border-color:rgba(224,163,62,.9);width:0;height:16px;border-top:0;border-left:2px solid;flex:0 0 2px;margin:0 16px}
.chartlegend .dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#5fd3b1;opacity:.8;flex:0 0 8px;margin:0 13px}
.chartlegend .tag{flex:0 0 18px}.tagtxt{font:.75em ui-monospace,monospace;color:#5fd3b1;margin-left:-4px;margin-right:2px}
.legend div{display:flex;gap:8px;align-items:flex-start;font-size:.9em;margin-bottom:8px}.legend b{color:#fff}.legend .tag{flex:0 0 18px;margin-top:2px}
.legend .dot{flex:0 0 18px;height:18px;position:relative;margin-top:2px}.legend .dot::after{content:"";position:absolute;left:5px;top:5px;width:8px;height:8px;border-radius:50%;background:#5fd3b1;opacity:.75}
.font{margin-left:auto}
@media(max-width:1200px){main{grid-template-columns:1fr}}
</style></head><body>
<header><div><h1>Käufer-Bot <span id="ver" class="sub"></span></h1><div class="sub" id="src">…</div><div class="status" id="status">kein Durchgang</div></div><div class="sp"></div>
<div class="stat"><b id="s-eq">—</b><span>Kontostand · eingezahlt</span></div><div class="stat"><b id="s-ret">—</b><span>Bot</span></div><div class="stat"><b id="s-dca">—</b><span>Sparplan, gleiche Zufuhr</span></div>
<div class="stat"><b id="s-hold">—</b><span>Halten, gleiche Zufuhr</span></div><div class="stat"><b id="s-dd">—</b><span>Rückgang</span></div>
<div class="stat"><b id="s-coin">—</b><span>BTC · Ø-Kaufkurs</span></div><div class="stat"><b id="s-ma">—</b><span>Abstand MA200</span></div><div class="stat"><b id="s-n">—</b><span>Staffel-Käufe / Verkäufe</span></div>
<button id="font" class="font" title="Schriftgröße umschalten">Aa</button></header>
<main><section>
 <div class="row"><input class="w" id="from" value="2023-09-04"><input class="w" id="to" value="now"></div>
 <div class="row"><button class="go" id="run">Zeitraum simulieren</button><button id="live">Live</button><button class="halt" id="stop">Stopp</button></div>
 <div class="bar"><i id="prog"></i></div><div class="hint" id="msg"></div><div class="hint" id="ver2"></div>

 <h2>Einstellungen speichern</h2>
 <div class="hint">Die aktuellen Einstellungen bleiben beim Neustart erhalten. Zusätzlich kannst du benannte Sätze ablegen.</div>
 <div class="row"><input class="w" id="pname" placeholder="Name, z. B. konservativ"><button id="psave">Speichern</button></div>
 <div class="row"><select id="plist" style="width:auto;text-align:left"></select><button id="pload">Laden</button><button id="pdel">Löschen</button><button id="pstd">Standard</button></div>

 <h2>Was der Bot tut — und wie es im Chart aussieht</h2>
 <div class="legend">
  <div><i class="dot"></i><b>Sparplan:</b> jede Monatsrate im festen Takt. Kleine Punkte. Pausiert, wenn der Kurs zu weit über dem 200-Tage-Durchschnitt liegt (orange Linie).</div>
  <div><span class="tag b">B</span><b>Bot, Kauf:</b> Reserve als Kauforders unter dem Kurs, gefüllt am Kerzentief. Große B mit Stufe. Offene Orders: grün gestrichelt.</div>
  <div><span class="tag s">S</span><b>Bot, Verkauf:</b> ein Teil des Bestands, wenn der Kurs die lila Verkaufslinie erreicht. Der Erlös wird zur neuen Reserve.</div>
 </div>

 <h2 class="l">Bot — Kaufstaffel</h2>
 <div class="hint">So legt der Bot die Reserve als Kauforders unter den Kurs. <b>Ausgangskurs</b> ist der Kurs in dem Moment, in dem die Reserve gefüllt wird:
 beim Start der Startkurs, nach einem Verkauf der Verkaufskurs. Jede Zeile heißt: <i>fällt der Kurs um so viel Prozent unter den Ausgangskurs, kaufe so viel Prozent der noch freien Reserve.</i>
 Beispiel: Reserve 5.000 USD bei Kurs 80.000. Stufe „−10 % → 25 %" legt eine Order bei 72.000 über 1.250 USD; die nächste Stufe rechnet mit den verbleibenden 3.750.
 Die unterste Stufe sollte 100 % haben, damit nichts liegen bleibt.</div>
 <div class="lad" id="ladder"></div><div class="row"><button id="ladd">Stufe hinzufügen</button></div>
 <label><span>Restliche Reserve am Markt kaufen (Auffang)</span><select id="rmode" style="width:auto;text-align:left">
  <option value="cross_up">nur wenn der Kurs den MA200 von unten nach oben kreuzt (Ende einer Baisse)</option>
  <option value="touch">auch bei Berührung von oben, bis zum Band darunter</option>
  <option value="off">nie — die Reserve wartet nur auf die Stufen</option></select></label>
 <label><span>Band für „Berührung": bis höchstens <em>% über dem MA200</em></span><input type="number" step="any" id="maband"></label>
 <div class="help">Dezember 2025: der Kurs stürzte von oben durch den MA200, der Auffang „Berührung" kaufte die restliche Reserve bei 75.000, bevor die 58.000 kamen. Beim Kreuzen von unten (September 2023, August 2026) ist der Auffang richtig — das ist der Beginn eines neuen Regimes. Deshalb ist „von unten kreuzen" die Vorgabe.</div>

 <h2 class="l">Bot — feste Kursmarken</h2>
 <div class="hint">Zusätzliche Kauforders bei festen Kursen, unabhängig von der Staffel. Anteil bezieht sich auf die Reserve zum Zeitpunkt des Anlegens. Live änderbar.</div>
 <div class="lad" id="manual"></div><div class="row"><button id="madd">Marke hinzufügen</button></div>

 <div id="form"></div>
</section><section>
 <div class="row"><span class="sub" id="note"></span><span class="sp"></span>
  <select id="agg"><option value="1">1 min</option><option value="5">5 min</option><option value="15">15 min</option><option value="30">30 min</option><option value="240">4 h</option><option value="1440" selected>1 Tag</option></select>
  <select id="span"><option value="1">1 Tag</option><option value="3">3 Tage</option><option value="7">7 Tage</option><option value="30">30 Tage</option><option value="180">6 Monate</option><option value="365" selected>1 Jahr</option><option value="1460">4 Jahre</option></select>
  <label class="hint" style="margin:0"><input type="checkbox" id="follow" checked style="width:auto"> mitlaufen</label>
  <label class="hint" style="margin:0"><input type="checkbox" id="showdca" checked style="width:auto"> Sparplan-Punkte</label>
  <label class="hint" style="margin:0"><input type="checkbox" id="logy" style="width:auto"> log-Skala</label></div>
 <canvas id="chart" height="440"></canvas>
 <div class="chartlegend">
  <div><i class="sw ma"></i>MA200 (200-Tage-Durchschnitt)</div>
  <div><i class="sw sell"></i>Verkaufslinie: MA200 + <span id="lg-sell"></span> %</div>
  <div><i class="sw pause"></i>Sparplan-Pause ab MA200 + <span id="lg-pause"></span> %</div>
  <div><i class="sw band"></i>Auffang-Band: MA200 bis + <span id="lg-band"></span> % (gilt nur im Modus „Berührung")</div>
  <div><i class="sw order"></i>offene Kauforder des Bots (wartet auf ihren Kurs)</div>
  <div><i class="dot"></i>Sparplan-Kauf (wöchentliche Rate)</div>
  <div><span class="tag b">B</span>Bot-Kauf (Staffelstufe, Kursmarke oder Auffang). Fläche proportional zum Betrag. Dicht liegende Käufe werden zu einer Marke zusammengefasst, die Zahl im Kreis ist die Anzahl. <b>Mauszeiger auf die Marke: Datum, Grund, Kurs, Betrag.</b></div>
  <div><span class="tag s">S</span>Bot-Verkauf (Überdehnung oder Regimebruch). Details ebenfalls per Mauszeiger.</div>
  <div><i class="sw cur"></i>Zeitcursor: hier steht die Simulation gerade</div>
 </div>
 <h2>Verlauf in Prozent auf das eingezahlte Kapital: Bot gegen Sparplan und Halten</h2><canvas id="eq" height="190"></canvas>
 <h2>Protokoll</h2><div class="jrn" id="jrn"></div>
</section><section>
 <h2 class="l">Wartet auf …</h2><div class="hint">Alles, was der Bot als Nächstes tun würde, mit den Kursen, die es auslösen.</div>
 <table id="pend"><thead><tr><th>Was</th><th>Wann</th><th class="r">Betrag</th></tr></thead><tbody></tbody></table>
 <h2 class="l">Ruhende Orders</h2><table id="orders"><thead><tr><th>Stufe</th><th class="r">Kurs</th><th class="r">USD</th></tr></thead><tbody></tbody></table>
 <h2 class="l">Staffel-Käufe und Verkäufe</h2><div class="hint">Ohne die wöchentlichen Sparplan-Raten — die stehen im Protokoll.</div>
 <table id="tr"><thead><tr><th></th><th>Datum</th><th>Grund</th><th class="r">Kurs</th><th class="r">USD</th></tr></thead><tbody></tbody></table>
</section></main>
<script>
const $=s=>document.querySelector(s);let CFG={},FIELDS=[],CHART=null,CUR=null,ST=null;
const usd=v=>v==null?'—':(v<0?'-':'')+'$'+Math.abs(v).toLocaleString('de-DE',{maximumFractionDigits:0});
const pct=v=>v==null?'—':(v>0?'+':'')+v.toFixed(1)+' %';const px=v=>v==null?'—':Math.round(v).toLocaleString('de-DE');
function legend(){$('#lg-sell').textContent=CFG.overheat_pct;$('#lg-pause').textContent=CFG.no_buy_above_ma_pct;$('#lg-band').textContent=CFG.rebuy_at_ma_band_pct}
async function push(){legend();await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(CFG)})}
function form(){const b=$('#form');b.innerHTML='';for(const[id,g,intro,items]of FIELDS){const h=document.createElement('h2');h.textContent=g;if(id!=='kosten')h.className='l';b.appendChild(h);
 if(intro){const p=document.createElement('div');p.className='hint';p.textContent=intro;b.appendChild(p)}
 for(const[k,l,u,help,opts]of items){const L=document.createElement('label');L.innerHTML=`<span>${l}${u?' <em>'+u+'</em>':''}</span>`;let i;
 if(opts){i=document.createElement('select');i.style.width='auto';i.style.textAlign='left';for(const[v,t]of opts){const o=document.createElement('option');o.value=v;o.textContent=t;i.appendChild(o)}i.value=CFG[k];i.onchange=()=>{CFG[k]=i.value;push()}}
 else{i=document.createElement('input');i.type='number';i.step='any';i.value=CFG[k];i.onchange=()=>{CFG[k]=parseFloat(i.value);push()}}
 L.appendChild(i);b.appendChild(L);if(help){const p=document.createElement('div');p.className='help';p.textContent=help;b.appendChild(p)}}}}
function rows(id,key,heads,cols){const b=$(id);b.innerHTML='';const t=document.createElement('table');t.className='stufen';
 t.innerHTML='<thead><tr>'+heads.map(h=>'<th>'+h+'</th>').join('')+'<th></th></tr></thead>';const tb=document.createElement('tbody');
 (CFG[key]||[]).forEach((st,ix)=>{const tr=document.createElement('tr');cols.forEach(f=>{const td=document.createElement('td');const i=document.createElement('input');i.type='number';i.step='any';i.value=st[f];
  i.onchange=()=>{CFG[key][ix][f]=parseFloat(i.value);push()};td.appendChild(i);tr.appendChild(td)});
  const td=document.createElement('td');const d=document.createElement('button');d.textContent='×';d.title='Stufe entfernen';d.onclick=()=>{CFG[key].splice(ix,1);push();rows(id,key,heads,cols)};td.appendChild(d);tr.appendChild(td);tb.appendChild(tr)});
 t.appendChild(tb);b.appendChild(t)}
const ladder=()=>rows('#ladder','ladder',['Kurs fällt um … %','Bot kauft … % der freien Reserve'],['below_pct','share_pct']);
const manual=()=>rows('#manual','manual_levels',['Kurs (USD)','Bot kauft … % der Reserve'],['price','share_pct']);
$('#ladd').onclick=()=>{CFG.ladder.push({below_pct:20,share_pct:30});push();ladder()};
$('#maband').onchange=e=>{CFG.rebuy_at_ma_band_pct=parseFloat(e.target.value);push()};$('#rmode').onchange=e=>{CFG.rebuy_mode=e.target.value;push()};
$('#madd').onclick=()=>{(CFG.manual_levels=CFG.manual_levels||[]).push({price:60000,share_pct:30});push();manual()};
$('#run').onclick=async()=>{$('#msg').textContent='';CHART=null;const r=await(await fetch('/api/backtest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({from:$('#from').value,to:$('#to').value})})).json();if(r.error)$('#msg').textContent=r.error};
$('#live').onclick=async()=>{CHART=null;const r=await(await fetch('/api/live',{method:'POST'})).json();if(r.error)$('#msg').textContent=r.error};
$('#stop').onclick=async()=>{await fetch('/api/stop',{method:'POST'});$('#msg').textContent='Stopp gesendet.'};
async function api(p,d){return await(await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d||{})})).json()}
function plist(names){const sel=$('#plist');sel.innerHTML='';(names||[]).forEach(n=>{const o=document.createElement('option');o.value=n;o.textContent=n;sel.appendChild(o)});if(!sel.options.length){const o=document.createElement('option');o.value='';o.textContent='— keine gespeichert —';sel.appendChild(o)}}
$('#psave').onclick=async()=>{const r=await api('/api/preset/save',{name:$('#pname').value});if(r.error){$('#msg').textContent=r.error;return}plist(r.names);$('#msg').textContent='Gespeichert: '+$('#pname').value};
$('#pload').onclick=async()=>{const r=await api('/api/preset/load',{name:$('#plist').value});if(r.error){$('#msg').textContent=r.error;return}CFG=r.config;$('#maband').value=CFG.rebuy_at_ma_band_pct;$('#rmode').value=CFG.rebuy_mode||'cross_up';form();ladder();manual();$('#msg').textContent='Geladen: '+$('#plist').value};
$('#pdel').onclick=async()=>{const r=await api('/api/preset/delete',{name:$('#plist').value});plist(r.names)};
$('#pstd').onclick=async()=>{const r=await api('/api/preset/load',{name:'_standard'});CFG=r.config;$('#maband').value=CFG.rebuy_at_ma_band_pct;$('#rmode').value=CFG.rebuy_mode||'cross_up';form();ladder();manual();$('#msg').textContent='Standardwerte geladen'};
$('#font').onclick=()=>{document.documentElement.classList.toggle('big');try{localStorage.setItem('buyer_big',document.documentElement.classList.contains('big')?'1':'0')}catch(e){};draw();drawEq(ST&&ST.equity)};
try{if(localStorage.getItem('buyer_big')==='1')document.documentElement.classList.add('big')}catch(e){}$('#agg').onchange=$('#span').onchange=()=>load(CUR);$('#showdca').onchange=draw;
let loading=false;async function load(anchor){if(loading)return;loading=true;try{const d=parseInt($('#span').value),to=anchor||CUR||Math.floor(Date.now()/1000);
 CHART=await(await fetch(`/api/chart?from=${to-d*86400}&to=${to}&agg=${$('#agg').value}`)).json();draw()}finally{loading=false}}
// --- Marken ohne Ueberlappung: zusammenfassen, Beschriftungen ausweichen lassen (reine Geometrie, testbar)
function layoutMarks(items,W,H,dpr){
 // items: {x,y,side,usd,lab,trade}  ->  Marken {x,yy,r,side,usd,n,trades}; keine Beschriftung, Details per Mouseover
 const rad=u=>Math.max(7,Math.min(22,7*Math.sqrt(Math.max(1,u)/1000)))*dpr;
 const sorted=items.slice().sort((a,b)=>a.x-b.x);const groups=[];
 for(const it of sorted){const g=groups[groups.length-1];
  if(g&&g.side===it.side&&Math.abs(it.x-g.x)<(rad(g.usd)+rad(it.usd))*1.05){g.n++;g.usd+=it.usd;g.y=(g.y*(g.n-1)+it.y)/g.n;g.x=(g.x*(g.n-1)+it.x)/g.n;g.trades.push(it.trade)}
  else groups.push({x:it.x,y:it.y,side:it.side,usd:it.usd,n:1,trades:[it.trade]})}
 const marks=groups.map(g=>{const b=g.side==='buy',r=rad(g.usd),yy=Math.max(r+2*dpr,Math.min(H-r-2*dpr,g.y+(b?r+12*dpr:-r-12*dpr)));return {x:g.x,yy,r,side:g.side,usd:g.usd,n:g.n,trades:g.trades}});
 for(let i=0;i<marks.length;i++)for(let j=0;j<i;j++){const a=marks[i],b=marks[j];const need=a.r+b.r+2*dpr,dist=Math.hypot(a.x-b.x,a.yy-b.yy);
  if(dist<need){const dy=Math.sqrt(Math.max(0,need*need-(a.x-b.x)**2));a.yy=a.side==='buy'?Math.max(a.yy,b.yy+dy):Math.min(a.yy,b.yy-dy)}}
 return marks}
let MARKS=[];
function box(ctx,x,y,txt,col,align,dpr){if(!txt)return;ctx.font=`${11*dpr}px ui-monospace,monospace`;const w=ctx.measureText(txt).width+8*dpr,h=15*dpr;
 const x0=align==='right'?x-w:align==='center'?x-w/2:x;ctx.fillStyle='rgba(15,21,27,.88)';ctx.fillRect(x0,y-h+3*dpr,w,h);ctx.fillStyle=col;ctx.textAlign='left';ctx.fillText(txt,x0+4*dpr,y)}
function niceTicks(lo,hi,n){const span=hi-lo;if(span<=0)return[lo];const raw=span/n,mag=Math.pow(10,Math.floor(Math.log10(raw)));const f=raw/mag;const st=(f<1.5?1:f<3?2:f<7?5:10)*mag;const out=[];for(let v=Math.ceil(lo/st)*st;v<=hi;v+=st)out.push(v);return out}
function logTicks(lo,hi){const out=[];for(let e=Math.floor(Math.log10(lo));e<=Math.ceil(Math.log10(hi));e++)for(const m of[1,2,5]){const v=m*Math.pow(10,e);if(v>=lo&&v<=hi)out.push(v)}return out}
function dateLabel(t,span){const d=new Date(t*1000);if(span>2*365*86400)return d.toLocaleDateString('de-DE',{month:'short',year:'2-digit'});if(span>60*86400)return d.toLocaleDateString('de-DE',{day:'2-digit',month:'short'});return d.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'})+' '+d.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})}
let GEOM=null,MOUSE=null;
function draw(){const cv=$('#chart'),ctx=cv.getContext('2d'),dpr=devicePixelRatio,w=cv.width=cv.clientWidth*dpr,h=cv.height=440*dpr;ctx.clearRect(0,0,w,h);
 if(!CHART||!CHART.candles.length){ctx.fillStyle='#a9b6c3';ctx.font=`${15*dpr}px sans-serif`;ctx.fillText('Keine Kerzen im Zeitraum.',20*dpr,40*dpr);GEOM=null;return}
 const cs=CHART.candles,pr=84*dpr,pb=26*dpr,pt=8*dpr,W=w-pr,H=h-pb,LOG=$('#logy').checked;
 let lo=Math.min(...cs.map(c=>c.l)),hi=Math.max(...cs.map(c=>c.h));
 const ords=(ST&&ST.summary&&ST.summary.open_orders)||[];const shortSpan=(cs[cs.length-1].ts-cs[0].ts)<7*86400;
 ords.forEach(o=>{if(!shortSpan||o.price>lo*0.85)lo=Math.min(lo,o.price*0.99)});cs.forEach(c=>{if(c.ma&&(!shortSpan||c.ma>lo*0.8)){lo=Math.min(lo,c.ma*.97);hi=Math.max(hi,c.ma*1.03)}});
 if(LOG){lo*=0.97;hi*=1.03}else{const p=(hi-lo)*.05;lo-=p;hi+=p}
 const t0=cs[0].ts,t1=cs[cs.length-1].ts||t0+1,X=t=>(t-t0)/(t1-t0||1)*W;
 const Y=LOG?v=>pt+(H-pt)*(1-(Math.log(v)-Math.log(lo))/(Math.log(hi)-Math.log(lo))):v=>pt+(H-pt)*(1-(v-lo)/(hi-lo));
 const Yinv=LOG?y=>Math.exp(Math.log(lo)+(1-(y-pt)/(H-pt))*(Math.log(hi)-Math.log(lo))):y=>lo+(1-(y-pt)/(H-pt))*(hi-lo);
 GEOM={X,Y,Yinv,t0,t1,W,H,pr,dpr};
 // Raster und Preisachse
 ctx.font=`${12*dpr}px ui-monospace,monospace`;ctx.textAlign='left';
 (LOG?logTicks(lo,hi):niceTicks(lo,hi,6)).forEach(v=>{const y=Y(v);ctx.strokeStyle='rgba(58,71,86,.55)';ctx.lineWidth=dpr;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();ctx.fillStyle='#a9b6c3';ctx.fillText(px(v),W+8*dpr,y+4*dpr)});
 // Zeitachse
 const span=t1-t0,nT=Math.max(3,Math.min(8,Math.floor(W/(110*dpr))));ctx.textAlign='center';
 for(let i=0;i<=nT;i++){const t=t0+span*i/nT,x=X(t);ctx.strokeStyle='rgba(58,71,86,.35)';ctx.beginPath();ctx.moveTo(x,pt);ctx.lineTo(x,H);ctx.stroke();ctx.fillStyle='#a9b6c3';ctx.fillText(dateLabel(t,span),Math.min(W-30*dpr,Math.max(30*dpr,x)),H+18*dpr)}
 // Bänder und Linien des Bots
 const wm=cs.filter(c=>c.ma);
 if(wm.length>1){const band=(fnA,fnB,fill)=>{ctx.fillStyle=fill;ctx.beginPath();wm.forEach((c,k)=>{const y=Y(fnA(c));k?ctx.lineTo(X(c.ts),y):ctx.moveTo(X(c.ts),y)});[...wm].reverse().forEach(c=>ctx.lineTo(X(c.ts),Y(fnB(c))));ctx.closePath();ctx.fill()};
  band(c=>c.ma*(1+CFG.rebuy_at_ma_band_pct/100),c=>c.ma,'rgba(165,140,240,.10)');
  const line=(fn,col,wd,dash)=>{ctx.save();ctx.strokeStyle=col;ctx.lineWidth=wd*dpr;if(dash)ctx.setLineDash(dash.map(v=>v*dpr));ctx.lineJoin='round';ctx.beginPath();wm.forEach((c,k)=>{const y=Y(fn(c));k?ctx.lineTo(X(c.ts),y):ctx.moveTo(X(c.ts),y)});ctx.stroke();ctx.restore()};
  line(c=>c.ma,'#a58cf0',2.2);if(CFG.overheat_pct>0)line(c=>c.ma*(1+CFG.overheat_pct/100),'#a58cf0',1.2,[4,6]);if(CFG.no_buy_above_ma_pct>0)line(c=>c.ma*(1+CFG.no_buy_above_ma_pct/100),'#e0a33e',1.2,[2,6])}
 // Kerzen
 const cw=Math.max(1.2*dpr,Math.min(9*dpr,W/cs.length*.66));
 cs.forEach(c=>{const x=X(c.ts),up=c.c>=c.o;const col=up?'#4fc3ad':'#e0745f';ctx.strokeStyle=col;ctx.fillStyle=col;ctx.lineWidth=Math.max(1,dpr*.9);
  ctx.beginPath();ctx.moveTo(x,Y(c.h));ctx.lineTo(x,Y(c.l));ctx.stroke();const y0=Y(c.o),y1=Y(c.c);ctx.fillRect(x-cw/2,Math.min(y0,y1),cw,Math.max(1.4*dpr,Math.abs(y1-y0)))});
 // offene Orders
 ords.forEach(o=>{const y=Y(o.price);if(y<pt||y>H)return;ctx.save();ctx.strokeStyle='#5fd3b1';ctx.setLineDash([7*dpr,4*dpr]);ctx.lineWidth=1.2*dpr;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();ctx.restore();box(ctx,W-5*dpr,y-4*dpr,o.tag.replace('Staffel ','')+' · '+px(o.price)+' · '+usd(o.usd),'#5fd3b1','right',dpr)});
 // Käufe und Verkäufe — Marken ohne Text, Details per Mouseover
 const showdca=$('#showdca').checked;const items=[];
 (ST&&ST.trades||[]).filter(t=>t.ts>=t0&&t.ts<=t1).forEach(t=>{const x=X(t.ts),y=Y(t.px),b=t.side==='buy',dca=b&&t.how.startsWith('Sparplan');
  if(dca){if(!showdca)return;const rd=Math.max(2.5,Math.min(7,2.5*Math.sqrt(Math.max(1,t.usd)/50)))*dpr;ctx.fillStyle='rgba(95,211,177,.75)';ctx.beginPath();ctx.arc(x,y+9*dpr,rd,0,7);ctx.fill();return}
  items.push({x,y,side:t.side,usd:t.usd,trade:t})});
 MARKS=layoutMarks(items,W,H,dpr);
 MARKS.forEach(m=>{const b=m.side==='buy';ctx.fillStyle=b?'rgba(95,211,177,.85)':'rgba(240,126,160,.85)';ctx.beginPath();ctx.arc(m.x,m.yy,m.r,0,7);ctx.fill();ctx.strokeStyle='rgba(15,21,27,.8)';ctx.lineWidth=dpr;ctx.stroke();
  ctx.fillStyle='#101820';ctx.textAlign='center';ctx.font=`700 ${Math.max(10,Math.min(14,m.r/dpr))*dpr}px sans-serif`;ctx.fillText((b?'B':'S')+(m.n>1?m.n:''),m.x,m.yy+4*dpr)});
 // Zeitcursor
 if(CUR&&CUR>=t0&&CUR<=t1){const x=X(CUR);ctx.strokeStyle='rgba(224,163,62,.7)';ctx.lineWidth=1.2*dpr;ctx.beginPath();ctx.moveTo(x,pt);ctx.lineTo(x,H);ctx.stroke()}
 // Fadenkreuz und Mouseover
 if(MOUSE&&MOUSE.x<W){const mx=MOUSE.x,my=MOUSE.y;
  const hit=MARKS.find(m=>Math.hypot(m.x-mx,m.yy-my)<=m.r+2*dpr);
  ctx.save();ctx.setLineDash([3*dpr,3*dpr]);ctx.strokeStyle='rgba(238,242,246,.45)';ctx.lineWidth=dpr;ctx.beginPath();ctx.moveTo(mx,pt);ctx.lineTo(mx,H);ctx.moveTo(0,my);ctx.lineTo(W,my);ctx.stroke();ctx.restore();
  box(ctx,W+4*dpr+60*dpr,my+4*dpr,px(Yinv(my)),'#eef2f6','right',dpr);
  if(hit){ctx.strokeStyle='#fff';ctx.lineWidth=2*dpr;ctx.beginPath();ctx.arc(hit.x,hit.yy,hit.r+2*dpr,0,7);ctx.stroke();
   const lines=hit.trades.map(t=>{const d=new Date(t.ts*1000).toLocaleDateString('de-DE');const what=t.side==='buy'?(t.how.startsWith('Staffel')?'Bot-Kauf, '+t.how:t.how.startsWith('Rest')?'Bot-Kauf, Auffang am MA200':t.how.startsWith('Marke')?'Bot-Kauf, '+t.how:t.how):'Bot-Verkauf, '+t.how;
    return `${d}  ${what}  ·  Kurs ${px(t.px)}  ·  ${usd(t.usd)}`});
   if(hit.n>1)lines.push(`zusammen ${usd(hit.usd)} in ${hit.n} Ausführungen`);
   const lh=17*dpr,wmax=Math.max(...lines.map(l=>l.length))*6.8*dpr+12*dpr;const bx=Math.max(4*dpr,Math.min(W-wmax-4*dpr,hit.x-wmax/2)),by=hit.side==='buy'?hit.yy+hit.r+8*dpr:hit.yy-hit.r-8*dpr-lines.length*lh;
   ctx.fillStyle='rgba(15,21,27,.94)';ctx.fillRect(bx,by,wmax,lines.length*lh+6*dpr);ctx.strokeStyle=hit.side==='buy'?'#5fd3b1':'#f07ea0';ctx.lineWidth=dpr;ctx.strokeRect(bx,by,wmax,lines.length*lh+6*dpr);
   ctx.fillStyle='#eef2f6';ctx.textAlign='left';ctx.font=`${11.5*dpr}px ui-monospace,monospace`;lines.forEach((l,i)=>ctx.fillText(l,bx+6*dpr,by+lh*(i+1)))}
  else{let best=null,bd=1e18;cs.forEach(c=>{const d=Math.abs(X(c.ts)-mx);if(d<bd){bd=d;best=c}});
   if(best){const d=best.ma?((best.c/best.ma-1)*100):null;const txt=`${dateLabel(best.ts,span)}  O ${px(best.o)}  H ${px(best.h)}  L ${px(best.l)}  S ${px(best.c)}`+(best.ma?`  MA200 ${px(best.ma)} (${d>0?'+':''}${d.toFixed(1)} %)`:'');
    box(ctx,Math.min(mx+12*dpr,W-8*dpr),pt+16*dpr,txt,'#eef2f6',mx>W*.6?'right':'left',dpr)}}}
 $('#note').textContent=`${new Date(t0*1000).toLocaleDateString('de-DE')} – ${new Date(t1*1000).toLocaleDateString('de-DE')} · ${CHART.source||''} · Kerze ${CHART.agg_min>=1440?(CHART.agg_min/1440)+' Tag':CHART.agg_min>=60?(CHART.agg_min/60)+' h':CHART.agg_min+' min'}`+(CHART.agg_min!==parseInt($('#agg').value)?' (automatisch verdichtet)':'')}
$('#chart').addEventListener('mousemove',e=>{const r=e.target.getBoundingClientRect();MOUSE={x:(e.clientX-r.left)*devicePixelRatio,y:(e.clientY-r.top)*devicePixelRatio};draw();
 e.target.style.cursor=MARKS.some(m=>Math.hypot(m.x-MOUSE.x,m.yy-MOUSE.y)<=m.r+2*devicePixelRatio)?'pointer':'crosshair'});
$('#chart').addEventListener('mouseleave',()=>{MOUSE=null;draw()});
$('#logy').onchange=()=>{draw();drawEq(ST&&ST.equity)};
function drawEq(eq){const cv=$('#eq'),ctx=cv.getContext('2d'),dpr=devicePixelRatio,w=cv.width=cv.clientWidth*dpr,h=cv.height=190*dpr;ctx.clearRect(0,0,w,h);if(!eq||eq.length<2)return;
 const pr=70*dpr,pt=24*dpr,pb=6*dpr,W=w-pr,H=h-pb;const ser=[['equity','#eef2f6','Bot'],['bench_dca','#e0a33e','Sparplan'],['bench_hold','#a9b6c3','Halten']];
 const rel=(e,k)=>(e[k]/e.paid-1)*100;const vals=eq.flatMap(e=>ser.map(([k])=>rel(e,k)));let lo=Math.min(0,...vals),hi=Math.max(0,...vals);const p=(hi-lo)*.06;lo-=p;hi+=p;
 const t0=eq[0].ts,t1=eq[eq.length-1].ts,X=t=>(t-t0)/(t1-t0||1)*W,Y=v=>pt+(H-pt)*(1-(v-lo)/(hi-lo));
 ctx.font=`${12*dpr}px ui-monospace,monospace`;ctx.textAlign='left';niceTicks(lo,hi,4).forEach(v=>{const y=Y(v);ctx.strokeStyle=v===0?'rgba(238,242,246,.35)':'rgba(58,71,86,.55)';ctx.lineWidth=dpr;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();ctx.fillStyle='#a9b6c3';ctx.fillText((v>0?'+':'')+v.toFixed(0)+' %',W+8*dpr,y+4*dpr)});
 ser.forEach(([k,col,lab],j)=>{ctx.strokeStyle=col;ctx.lineWidth=(k==='equity'?2.2:1.3)*dpr;ctx.lineJoin='round';ctx.beginPath();eq.forEach((e,i)=>{i?ctx.lineTo(X(e.ts),Y(rel(e,k))):ctx.moveTo(X(e.ts),Y(rel(e,k)))});ctx.stroke();
  const last=eq[eq.length-1];ctx.fillStyle=col;ctx.font=`${12*dpr}px sans-serif`;ctx.textAlign='left';ctx.fillText(`${lab} ${(rel(last,k)>0?'+':'')}${rel(last,k).toFixed(1)} % · ${usd(last[k])}`,8*dpr+j*200*dpr,14*dpr)});
 ctx.fillStyle='#a9b6c3';ctx.fillText('eingezahlt '+usd(eq[eq.length-1].paid),8*dpr+3*200*dpr,14*dpr)}
function statusLine(){const s=ST.status;if(!s){$('#status').textContent='kein Durchgang';$('#status').className='status';return}
 const live=ST.mode==='live',sim=ST.mode==='backtest';let t='';
 if(live)t=`LIVE · ${s.text} · Quelle ${s.source} (${s.candle_min} min) · letzte Kerze ${s.last_candle||'—'} · geprüft ${s.last_poll||'—'}`;
 else if(sim)t=`SIMULATION · ${s.text}`;else t=`${s.text==='fertig'?'Simulation fertig':s.text==='abgebrochen'?'Simulation abgebrochen':s.text==='gestoppt'?'Live gestoppt':s.text} · Stand ${s.last_candle||'—'}`;
 if(s.px)t+=` · Kurs ${px(s.px)}`+(s.ma?` · MA200 ${px(s.ma)} (${s.dist>0?'+':''}${s.dist} %)`:' · MA200 fehlt noch');
 const q=ST.summary||{};t+=` · Bestand ${(s.coin||0).toFixed(4)} BTC (${usd(q.coin_value)}) · Sparplan-Kasse ${usd(q.cash_dca)} · Reserve ${usd(s.reserve)} in ${s.orders} Orders`+(s.paused?' · Sparplan pausiert':'');
 if(q.ma_window)t+=` · MA200: ${q.ma_window}`;
 $('#status').textContent=t;$('#status').className='status '+(live?'live':sim?'sim':'stop')}
async function tick(){ST=await(await fetch('/api/state')).json();if(ST.empty){$('#msg').textContent=ST.error||'Noch kein Durchgang.';statusLine();return}
 $('#prog').style.width=((ST.progress||0)*100)+'%';if(ST.error)$('#msg').textContent=ST.error;else if(ST.mode==='idle'&&/läuft bereits|beendet sich/.test($('#msg').textContent))$('#msg').textContent='';statusLine();const q=ST.summary||{};
 const set=(id,v,cls)=>{const e=$(id);e.textContent=v;e.className=cls||''};set('#s-eq',q.equity==null?'—':usd(q.equity)+' · '+usd(q.paid_in));set('#s-ret',pct(q.return_pct),q.return_pct>0?'pos':'neg');set('#s-dca',pct(q.bench_dca_pct));set('#s-hold',pct(q.bench_hold_pct));set('#s-dd',q.max_dd_pct==null?'—':q.max_dd_pct+' %');
 set('#s-coin',q.coin==null?'—':q.coin.toFixed(4)+' · '+px(q.avg_px));
 const lad=(ST.trades||[]).filter(t=>t.side==='buy'&&!t.how.startsWith('Sparplan')).length,sel=(ST.trades||[]).filter(t=>t.side==='sell').length;set('#s-n',lad+' / '+sel);set('#s-ma',q.dist_ma_pct==null?'—':pct(q.dist_ma_pct),(q.dist_ma_pct||0)>CFG.overheat_pct?'neg':'');
 CUR=ST.cursor;const pb=$('#pend tbody');pb.innerHTML='';(q.pending||[]).forEach(p=>{const tr=document.createElement('tr');tr.innerHTML=`<td>${p.was}</td><td>${p.wann}</td><td class="r">${p.betrag}</td>`;pb.appendChild(tr)});
 const ob=$('#orders tbody');ob.innerHTML='';(q.open_orders||[]).forEach(o=>{const tr=document.createElement('tr');tr.innerHTML=`<td>${o.tag}</td><td class="r">${px(o.price)}</td><td class="r">${usd(o.usd)}</td>`;ob.appendChild(tr)});
 if(!(q.open_orders||[]).length)ob.innerHTML='<tr><td colspan="3" class="hint">keine — Reserve '+usd(q.reserve)+'</td></tr>';
 const tb=$('#tr tbody');tb.innerHTML='';(ST.trades||[]).slice().reverse().filter(t=>t.side==='sell'||!t.how.startsWith('Sparplan')).slice(0,25).forEach(t=>{const tr=document.createElement('tr');tr.innerHTML=`<td><span class="tag ${t.side==='buy'?'b':'s'}">${t.side==='buy'?'B':'S'}</span></td><td>${new Date(t.ts*1000).toLocaleDateString('de-DE')}</td><td>${t.how.replace('Rest der Reserve am MA200','Rest am MA200').split(' (')[0]}</td><td class="r">${px(t.px)}</td><td class="r">${usd(t.usd)}</td>`;tb.appendChild(tr)});
 const j=$('#jrn');j.innerHTML='';(ST.journal||[]).forEach(e=>{const d=document.createElement('div');d.innerHTML=`<time>${e.t.slice(2,10)}</time>${e.kind==='buy'?'<span class="tag b">B</span>':e.kind==='sell'?'<span class="tag s">S</span>':''}<span>${e.text}</span>`;j.appendChild(d)});
 drawEq(ST.equity);const d=parseInt($('#span').value)*86400,to=(CHART&&CHART.to)||0;if($('#follow').checked&&CUR&&(CUR>to||CUR<to-d||(to-CUR)>d*.08))load(CUR);else draw()}
(async()=>{const c=await(await fetch('/api/config')).json();CFG=c.config;FIELDS=c.fields;$('#ver').textContent=c.version;$('#ver2').textContent='Version '+c.version+' · Datei: '+(c.file||'');plist(c.presets);legend();$('#src').textContent=c.source?`Quelle ${c.source.table}: ${c.source.from} bis ${c.source.to} UTC`:'keine Kerzenquelle gefunden';
 if(c.source)$('#from').value=c.source.from.slice(0,10);$('#maband').value=CFG.rebuy_at_ma_band_pct;$('#rmode').value=CFG.rebuy_mode||'cross_up';form();ladder();manual();await load();setInterval(tick,1500);tick()})();
</script></body></html>"""


def main():
    global DB_PATH
    p = argparse.ArgumentParser(); p.add_argument("--db", default="hl_liq.db"); p.add_argument("--host", default="127.0.0.1"); p.add_argument("--port", type=int, default=8767)
    a = p.parse_args(); DB_PATH = a.db
    print(f"Käufer-Bot {VERSION}\n  http://{a.host}:{a.port}   DB: {DB_PATH}\n  Datei: {__file__}\n  Simulation — keine echten Orders.")
    ThreadingHTTPServer((a.host, a.port), H).serve_forever()


if __name__ == "__main__":
    main()
