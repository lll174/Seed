"""
hl_buyerdash.py — Oberflaeche fuer den Kaeufer-Bot, Port 8767.

    python3 hl_buyerdash.py --db ../hl_liq.db --host 0.0.0.0

Liest die Recorder-Datenbank nur lesend. Keine echten Orders.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from hl_buyer import Cfg, Runner, parse_time, utc, connect_ro, pick_source, load_candles, DAY

VERSION = "buyer 2026-09-04b"
DB_PATH = "hl_liq.db"


class Session:
    def __init__(self):
        self.cfg = Cfg(); self.runner: Runner | None = None
        self.thread = None; self.mode = "idle"; self.stop = threading.Event(); self.error = None

    def busy(self): return self.thread is not None and self.thread.is_alive()

    def start(self, kind: str, t_from: int = 0, t_to: int = 0):
        if self.busy(): return {"error": "Es läuft bereits ein Durchgang."}
        self.stop.clear(); self.error = None; self.mode = kind
        def work():
            try:
                self.runner = Runner(DB_PATH, self.cfg)
                if kind == "live": self.runner.live(stop=self.stop.is_set)
                else:
                    r = self.runner.backtest(t_from, t_to)
                    if r.get("error"): self.error = r["error"]
            except Exception as e:  # noqa: BLE001
                self.error = f"{type(e).__name__}: {e}"
            finally: self.mode = "idle"
        self.thread = threading.Thread(target=work, daemon=True); self.thread.start()
        return {"ok": True}

    def halt(self):
        self.stop.set()
        if self.runner: self.runner.running = False
        return {"ok": True}


S = Session()

FIELDS = [
    ("Kapital", [("start_usd", "Startkapital", "USD"), ("start_to_ladder_pct", "davon in die Reserve-Staffel", "%"),
                 ("start_dca_weeks", "Rest per Sparplan über", "Wochen"), ("monthly_usd", "Zufuhr je Monat", "USD"),
                 ("dca_every_days", "Sparplan-Takt", "Tage")]),
    ("Regel 1 · Sparplan", [("no_buy_above_ma_pct", "Keine Sparplan-Käufe über MA200 +", "% (0 = nie aussetzen)"),
                            ("backlog_to", "Ausgesetzte Raten", "", [["catchup", "beim Rückkehr nachholen"], ["reserve", "in die Staffel geben"]])]),
    ("Regel 2 · Reserve", [("rebuy_at_ma_band_pct", "Rest der Reserve am Markt, wenn Kurs ≤ MA200 +", "%")]),
    ("Regel 3 · Verkauf", [("ma_days", "Gleitender Durchschnitt", "Tage"), ("overheat_pct", "Verkauf ab Abstand zum MA", "% (0 = nie)"),
                           ("sell_frac_pct", "Verkaufter Anteil", "%")]),
    ("Kosten", [("fee_bps", "Gebühr", "bps"), ("slip_bps", "Slippage bei Marktkäufen", "bps"), ("live_poll_seconds", "Live-Takt", "s")]),
]


def chart(coin, t_from, t_to, agg_min):
    con = connect_ro(DB_PATH); src = pick_source(con, coin)
    if not src: return {"candles": [], "ma": []}
    table = src[0]; step = agg_min * 60
    rows = load_candles(con, table, coin, t_from - (S.cfg.ma_days + 5) * DAY, t_to)
    buckets = {}
    for ts, o, h, l, c in rows:
        if ts < t_from: continue
        k = ts // step * step; b = buckets.get(k)
        if b is None: buckets[k] = {"ts": k, "o": o, "h": h, "l": l, "c": c}
        else: b["h"] = max(b["h"], h); b["l"] = min(b["l"], l); b["c"] = c
    candles = [buckets[k] for k in sorted(buckets)]
    # MA auf Tagesschluessen
    daily = {}
    for ts, o, h, l, c in rows: daily[ts // DAY] = c
    days = sorted(daily); closes = [daily[d] for d in days]; idx = {d: i for i, d in enumerate(days)}; n = S.cfg.ma_days
    for b in candles:
        d = b["ts"] // DAY; i = idx.get(d)
        if i is None:
            prev = [x for x in days if x <= d]; i = idx[prev[-1]] if prev else None
        b["ma"] = sum(closes[i - n + 1:i + 1]) / n if i is not None and i + 1 >= n else None
    con.close()
    return {"candles": candles, "from": t_from, "to": t_to, "source": table}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, obj, code=200, ctype="application/json"):
        body = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        try:
            if u.path == "/": return self._send(PAGE.encode(), ctype="text/html")
            if u.path == "/api/config":
                con = connect_ro(DB_PATH); src = pick_source(con, S.cfg.coin); con.close()
                return self._send({"config": S.cfg.to_dict(), "fields": FIELDS, "version": VERSION,
                                   "source": {"table": src[0], "from": utc(src[1]), "to": utc(src[2])} if src else None})
            if u.path == "/api/state":
                r = S.runner
                if not r: return self._send({"mode": S.mode, "empty": True, "error": S.error})
                b = r.bot
                return self._send({"mode": S.mode, "progress": round(r.progress, 3), "error": S.error,
                                   "summary": b.summary(), "cursor": b.equity[-1]["ts"] if b.equity else None,
                                   "trades": b.trades[-300:], "journal": b.journal[-120:][::-1],
                                   "equity": b.equity[::max(1, len(b.equity) // 600)]})
            if u.path == "/api/chart":
                now = int(time.time()); t_to = int(q.get("to", [now])[0]); t_from = int(q.get("from", [t_to - 30 * DAY])[0])
                return self._send(chart(S.cfg.coin, t_from, t_to, int(q.get("agg", [1440])[0])))
        except Exception as e:  # noqa: BLE001
            return self._send({"error": f"{type(e).__name__}: {e}"}, 500)
        self._send({"error": "unbekannt"}, 404)

    def do_POST(self):
        u = urlparse(self.path); n = int(self.headers.get("Content-Length", 0)); d = json.loads(self.rfile.read(n) or b"{}")
        try:
            if u.path == "/api/config": S.cfg = Cfg.from_dict(d); return self._send({"ok": True})
            if u.path == "/api/backtest": return self._send(S.start("backtest", parse_time(str(d.get("from", "2023-09-04"))), parse_time(str(d.get("to", "now")))))
            if u.path == "/api/live": return self._send(S.start("live"))
            if u.path == "/api/stop": return self._send(S.halt())
        except Exception as e:  # noqa: BLE001
            return self._send({"error": f"{type(e).__name__}: {e}"}, 500)
        self._send({"error": "unbekannt"}, 404)


PAGE = r"""<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Käufer-Bot</title>
<style>
:root{--g:#131a20;--p:#1c242c;--p2:#222c35;--r:#2c3742;--t:#d6dee6;--m:#7e8c99;--up:#3e9e8c;--dn:#c0604e;--lila:#8c6fd1;--buy:#4fb89c;--sell:#d96c8a}
*{box-sizing:border-box}body{margin:0;background:var(--g);color:var(--t);font:14px/1.5 ui-sans-serif,system-ui,sans-serif}
header{display:flex;gap:22px;align-items:baseline;flex-wrap:wrap;padding:14px 20px;border-bottom:1px solid var(--r);background:var(--p)}
h1{font-size:16px;margin:0}.sub{color:var(--m);font-size:12px}.sp{flex:1}
.stat{display:flex;flex-direction:column}.stat b{font-size:19px;font-variant-numeric:tabular-nums}.stat span{font-size:11px;color:var(--m)}
.pos{color:var(--up)}.neg{color:var(--dn)}
main{display:grid;grid-template-columns:300px 1fr 300px;gap:1px;background:var(--r)}section{background:var(--g);padding:16px 18px;overflow:auto}
h2{font-size:12.5px;color:var(--m);margin:14px 0 8px}h2.l{color:#b9a6ee}
label{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:7px;font-size:12.5px}label span{flex:1}em{color:var(--m);font-style:normal;font-size:11px}
input{background:var(--p2);border:1px solid var(--r);color:var(--t);border-radius:3px;padding:5px 7px;width:88px;text-align:right;font:inherit;font-variant-numeric:tabular-nums}
input.w{width:126px;text-align:left}button{background:var(--p2);border:1px solid var(--r);color:var(--t);border-radius:3px;padding:7px 12px;font:inherit;cursor:pointer}
button.go{background:var(--up);border-color:var(--up);color:#0d1613;font-weight:600}button.halt{background:var(--dn);border-color:var(--dn);color:#1a0f0c}
.row{display:flex;gap:8px;align-items:center;margin-bottom:9px;flex-wrap:wrap}canvas{width:100%;display:block;border:1px solid var(--r);border-radius:3px;background:var(--p)}
table{width:100%;border-collapse:collapse;font-size:12px}th{text-align:left;color:var(--m);font-weight:500;padding:4px 6px;border-bottom:1px solid var(--r)}td{padding:4px 6px;border-bottom:1px solid #232c34;font-variant-numeric:tabular-nums}.r{text-align:right}
.tag{display:inline-block;width:15px;height:15px;line-height:15px;text-align:center;border-radius:2px;font-size:10px;font-weight:700;color:#101820}.b{background:var(--buy)}.s{background:var(--sell)}
.jrn{max-height:260px;overflow:auto;font-size:12px}.jrn div{padding:4px 0;border-bottom:1px solid #232c34;display:flex;gap:8px}.jrn time{color:var(--m);white-space:nowrap}
.hint{color:var(--m);font-size:11.5px;margin:4px 0 10px}.bar{height:3px;background:var(--p2);margin:8px 0}.bar i{display:block;height:100%;background:var(--lila);width:0}
.lad input{width:62px}.lad button{padding:2px 8px}
@media(max-width:1100px){main{grid-template-columns:1fr}}
</style></head><body>
<header><div><h1>Käufer-Bot <span id="ver" class="sub"></span></h1><div class="sub" id="src">…</div></div><div class="sp"></div>
<div class="stat"><b id="s-ret">—</b><span>Bot</span></div><div class="stat"><b id="s-dca">—</b><span>Sparplan, gleiche Zufuhr</span></div>
<div class="stat"><b id="s-hold">—</b><span>Halten, gleiche Zufuhr</span></div><div class="stat"><b id="s-dd">—</b><span>Rückgang</span></div>
<div class="stat"><b id="s-coin">—</b><span>BTC · Ø-Kaufkurs</span></div><div class="stat"><b id="s-ma">—</b><span>Abstand MA200</span></div></header>
<main><section>
 <div class="row"><input class="w" id="from" value="2023-09-04"><input class="w" id="to" value="now"></div>
 <div class="row"><button class="go" id="run">Zeitraum simulieren</button><button id="live">Live</button><button class="halt" id="stop">Stopp</button></div>
 <div class="bar"><i id="prog"></i></div><div class="hint" id="msg"></div>
 <h2 class="l">Regel 2 · Staffel unter dem Anker</h2>
 <div class="hint">Anker = Kurs beim Eintreffen des Geldes bzw. Verkaufskurs. Anteil bezieht sich auf die noch freie Reserve.</div>
 <div id="ladder" class="lad"></div><div class="row"><button id="ladd">Stufe hinzufügen</button></div>
 <h2 class="l">Feste Kursmarken (optional, live änderbar)</h2>
 <div id="manual" class="lad"></div><div class="row"><button id="madd">Marke hinzufügen</button></div>
 <div id="form"></div>
</section><section>
 <div class="row"><span class="sub" id="note"></span><span class="sp"></span>
  <select id="agg"><option value="30">30 min</option><option value="240">4 h</option><option value="1440" selected>1 Tag</option></select>
  <select id="span"><option value="30">30 Tage</option><option value="180">6 Monate</option><option value="365" selected>1 Jahr</option><option value="1460">4 Jahre</option></select>
  <label class="hint" style="margin:0"><input type="checkbox" id="follow" checked style="width:auto"> mitlaufen</label></div>
 <canvas id="chart" height="400"></canvas>
 <h2>Verlauf: Bot gegen Sparplan und Halten (gleiche Einzahlungen)</h2><canvas id="eq" height="160"></canvas>
 <h2>Protokoll</h2><div class="jrn" id="jrn"></div>
</section><section>
 <h2 class="l">Ruhende Orders</h2><table id="orders"><thead><tr><th>Stufe</th><th class="r">Kurs</th><th class="r">USD</th></tr></thead><tbody></tbody></table>
 <h2>Letzte Käufe und Verkäufe</h2><table id="tr"><thead><tr><th></th><th>Datum</th><th class="r">Kurs</th><th class="r">USD</th></tr></thead><tbody></tbody></table>
</section></main>
<script>
const $=s=>document.querySelector(s);let CFG={},FIELDS=[],CHART=null,CUR=null,ST=null;
const usd=v=>v==null?'—':(v<0?'-':'')+'$'+Math.abs(v).toLocaleString('de-DE',{maximumFractionDigits:0});
const pct=v=>v==null?'—':(v>0?'+':'')+v.toFixed(1)+' %';const px=v=>v==null?'—':Math.round(v).toLocaleString('de-DE');
async function push(){await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(CFG)})}
function form(){const b=$('#form');b.innerHTML='';for(const[g,items]of FIELDS){const h=document.createElement('h2');h.textContent=g;if(g.startsWith('Regel'))h.className='l';b.appendChild(h);
 for(const[k,l,u,opts]of items){const L=document.createElement('label');L.innerHTML=`<span>${l}${u?' <em>'+u+'</em>':''}</span>`;let i;
 if(opts){i=document.createElement('select');i.style.width='auto';for(const[v,t]of opts){const o=document.createElement('option');o.value=v;o.textContent=t;i.appendChild(o)}i.value=CFG[k];i.onchange=()=>{CFG[k]=i.value;push()}}
 else{i=document.createElement('input');i.type='number';i.step='any';i.value=CFG[k];i.onchange=()=>{CFG[k]=parseFloat(i.value);push()}}
 L.appendChild(i);b.appendChild(L)}}}
function rows(id,key,cols,mk){const b=$(id);b.innerHTML='';(CFG[key]||[]).forEach((st,ix)=>{const L=document.createElement('label');
 cols.forEach(([f,lab])=>{const s=document.createElement('span');s.innerHTML=lab;s.style.flex='0 0 auto';const i=document.createElement('input');i.type='number';i.step='any';i.value=st[f];
 i.onchange=()=>{CFG[key][ix][f]=parseFloat(i.value);push()};L.append(s,i)});
 const d=document.createElement('button');d.textContent='×';d.onclick=()=>{CFG[key].splice(ix,1);push();rows(id,key,cols,mk)};L.appendChild(d);b.appendChild(L)})}
const ladder=()=>rows('#ladder','ladder',[['below_pct','− <em>%</em>'],['share_pct','→ <em>%</em>']]);
const manual=()=>rows('#manual','manual_levels',[['price','bei'],['share_pct','→ <em>%</em>']]);
$('#ladd').onclick=()=>{CFG.ladder.push({below_pct:20,share_pct:30});push();ladder()};
$('#madd').onclick=()=>{(CFG.manual_levels=CFG.manual_levels||[]).push({price:60000,share_pct:30});push();manual()};
$('#run').onclick=async()=>{$('#msg').textContent='';CHART=null;const r=await(await fetch('/api/backtest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({from:$('#from').value,to:$('#to').value})})).json();if(r.error)$('#msg').textContent=r.error};
$('#live').onclick=async()=>{CHART=null;const r=await(await fetch('/api/live',{method:'POST'})).json();if(r.error)$('#msg').textContent=r.error};
$('#stop').onclick=()=>fetch('/api/stop',{method:'POST'});$('#agg').onchange=$('#span').onchange=()=>load(CUR);
let loading=false;async function load(anchor){if(loading)return;loading=true;try{const d=parseInt($('#span').value),to=anchor||CUR||Math.floor(Date.now()/1000);
 CHART=await(await fetch(`/api/chart?from=${to-d*86400}&to=${to}&agg=${$('#agg').value}`)).json();draw()}finally{loading=false}}
function draw(){const cv=$('#chart'),ctx=cv.getContext('2d'),dpr=devicePixelRatio,w=cv.width=cv.clientWidth*dpr,h=cv.height=400*dpr;ctx.clearRect(0,0,w,h);
 if(!CHART||!CHART.candles.length){ctx.fillStyle='#7e8c99';ctx.font=`${13*dpr}px sans-serif`;ctx.fillText('Keine Kerzen im Zeitraum.',20,40);return}
 const cs=CHART.candles,pr=80*dpr,pb=24*dpr,W=w-pr,H=h-pb;let lo=Math.min(...cs.map(c=>c.l)),hi=Math.max(...cs.map(c=>c.h));
 const ords=(ST&&ST.summary&&ST.summary.open_orders)||[];ords.forEach(o=>{lo=Math.min(lo,o.price*0.99)});cs.forEach(c=>{if(c.ma){lo=Math.min(lo,c.ma*.98);hi=Math.max(hi,c.ma*1.02)}});
 const p=(hi-lo)*.05;lo-=p;hi+=p;const t0=cs[0].ts,t1=cs[cs.length-1].ts||t0+1,X=t=>(t-t0)/(t1-t0||1)*W,Y=v=>H-(v-lo)/(hi-lo)*H;
 const cw=Math.max(1.5*dpr,W/cs.length*.62);cs.forEach(c=>{const x=X(c.ts),up=c.c>=c.o;ctx.strokeStyle=ctx.fillStyle=up?'#3e9e8c':'#c0604e';ctx.lineWidth=dpr;ctx.beginPath();ctx.moveTo(x,Y(c.h));ctx.lineTo(x,Y(c.l));ctx.stroke();ctx.fillRect(x-cw/2,Math.min(Y(c.o),Y(c.c)),cw,Math.max(1.5,Math.abs(Y(c.c)-Y(c.o))))});
 const wm=cs.filter(c=>c.ma);if(wm.length>1){const line=(fn,col,wd,dash)=>{ctx.save();ctx.strokeStyle=col;ctx.lineWidth=wd*dpr;if(dash)ctx.setLineDash(dash.map(v=>v*dpr));ctx.beginPath();wm.forEach((c,k)=>{k?ctx.lineTo(X(c.ts),Y(fn(c))):ctx.moveTo(X(c.ts),Y(fn(c)))});ctx.stroke();ctx.restore()};
  line(c=>c.ma,'#8c6fd1',2);line(c=>c.ma*(1+CFG.overheat_pct/100),'#8c6fd1',1,[3,5]);line(c=>c.ma*(1+CFG.rebuy_at_ma_band_pct/100),'rgba(140,111,209,.5)',1,[2,4]);if(CFG.no_buy_above_ma_pct>0)line(c=>c.ma*(1+CFG.no_buy_above_ma_pct/100),'rgba(224,163,62,.7)',1,[2,6]);
  ctx.fillStyle='#b9a6ee';ctx.font=`${11*dpr}px ui-monospace,monospace`;ctx.textAlign='left';const L=wm[wm.length-1];
  const yy=Y(L.ma);if(yy>0&&yy<H)ctx.fillText('MA'+CFG.ma_days+' '+px(L.ma),5*dpr,yy-5*dpr);const yo=Y(L.ma*(1+CFG.overheat_pct/100));if(yo>0&&yo<H)ctx.fillText('Verkauf ab +'+CFG.overheat_pct+' %',5*dpr,yo-5*dpr);
  if(CFG.no_buy_above_ma_pct>0){const yn=Y(L.ma*(1+CFG.no_buy_above_ma_pct/100));if(yn>0&&yn<H){ctx.fillStyle='#e0a33e';ctx.fillText('Sparplan aus ab +'+CFG.no_buy_above_ma_pct+' %',5*dpr,yn-5*dpr)}}}
 ords.forEach(o=>{const y=Y(o.price);if(y<0||y>H)return;ctx.save();ctx.strokeStyle='#4fb89c';ctx.setLineDash([6*dpr,4*dpr]);ctx.lineWidth=dpr;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();ctx.restore();ctx.fillStyle='#4fb89c';ctx.textAlign='right';ctx.font=`${11*dpr}px ui-monospace,monospace`;ctx.fillText(o.tag+' '+px(o.price)+' · '+usd(o.usd),W-5*dpr,y-4*dpr)});
 ctx.fillStyle='#7e8c99';ctx.textAlign='left';ctx.font=`${11*dpr}px ui-monospace,monospace`;for(let i=0;i<=4;i++){const v=lo+(hi-lo)*i/4,y=Y(v);ctx.strokeStyle='#232c34';ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();ctx.fillText(px(v),W+6*dpr,y-4*dpr)}
 ctx.textAlign='center';for(let i=0;i<=5;i++){const t=t0+(t1-t0)*i/5;ctx.fillText(new Date(t*1000).toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',year:'2-digit'}),X(t),H+16*dpr)}
 (ST&&ST.trades||[]).filter(t=>t.ts>=t0&&t.ts<=t1).forEach(t=>{const x=X(t.ts),y=Y(t.px),b=t.side==='buy',r=7*dpr;ctx.fillStyle=b?'#4fb89c':'#d96c8a';ctx.beginPath();ctx.arc(x,y+(b?r*1.8:-r*1.8),r,0,7);ctx.fill();ctx.fillStyle='#101820';ctx.textAlign='center';ctx.font=`700 ${9*dpr}px sans-serif`;ctx.fillText(b?'B':'S',x,y+(b?r*1.8+3*dpr:-r*1.8+3*dpr))});
 if(CUR&&CUR>=t0&&CUR<=t1){const x=X(CUR);ctx.strokeStyle='rgba(224,163,62,.6)';ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
 $('#note').textContent=`${new Date(t0*1000).toLocaleDateString('de-DE')} – ${new Date(t1*1000).toLocaleDateString('de-DE')} · ${CHART.source||''} · lila = MA200 / Verkaufslinie · grün gestrichelt = ruhende Kauforders`}
function drawEq(eq){const cv=$('#eq'),ctx=cv.getContext('2d'),dpr=devicePixelRatio,w=cv.width=cv.clientWidth*dpr,h=cv.height=160*dpr;ctx.clearRect(0,0,w,h);if(!eq||eq.length<2)return;
 const ser=[['equity','#d6dee6','Bot'],['bench_dca','#e0a33e','Sparplan'],['bench_hold','#7e8c99','Halten']];const vals=eq.flatMap(e=>[e.equity,e.bench_dca,e.bench_hold,e.paid]);const lo=Math.min(...vals)*.97,hi=Math.max(...vals)*1.03;
 const t0=eq[0].ts,t1=eq[eq.length-1].ts,X=t=>(t-t0)/(t1-t0||1)*(w-8*dpr),Y=v=>h-8*dpr-(v-lo)/(hi-lo)*(h-16*dpr);
 ctx.save();ctx.strokeStyle='#2c3742';ctx.setLineDash([3*dpr,3*dpr]);ctx.beginPath();eq.forEach((e,k)=>{k?ctx.lineTo(X(e.ts),Y(e.paid)):ctx.moveTo(X(e.ts),Y(e.paid))});ctx.stroke();ctx.restore();
 ser.forEach(([k,col,lab],j)=>{ctx.strokeStyle=col;ctx.lineWidth=(k==='equity'?2:1)*dpr;ctx.beginPath();eq.forEach((e,i)=>{i?ctx.lineTo(X(e.ts),Y(e[k])):ctx.moveTo(X(e.ts),Y(e[k]))});ctx.stroke();ctx.fillStyle=col;ctx.font=`${11*dpr}px sans-serif`;ctx.textAlign='left';ctx.fillText(lab+' '+usd(eq[eq.length-1][k]),8*dpr+j*140*dpr,14*dpr)});
 ctx.fillStyle='#7e8c99';ctx.fillText('eingezahlt '+usd(eq[eq.length-1].paid),8*dpr+3*140*dpr,14*dpr)}
async function tick(){ST=await(await fetch('/api/state')).json();if(ST.empty){$('#msg').textContent=ST.error||'Noch kein Durchgang.';return}
 $('#prog').style.width=((ST.progress||0)*100)+'%';if(ST.error)$('#msg').textContent=ST.error;const q=ST.summary||{};
 const set=(id,v,cls)=>{const e=$(id);e.textContent=v;e.className=cls||''};set('#s-ret',pct(q.return_pct),q.return_pct>0?'pos':'neg');set('#s-dca',pct(q.bench_dca_pct));set('#s-hold',pct(q.bench_hold_pct));set('#s-dd',q.max_dd_pct==null?'—':q.max_dd_pct+' %');
 set('#s-coin',q.coin==null?'—':q.coin.toFixed(4)+' · '+px(q.avg_px));set('#s-ma',q.dist_ma_pct==null?'—':pct(q.dist_ma_pct),(q.dist_ma_pct||0)>CFG.overheat_pct?'neg':'');
 CUR=ST.cursor;const ob=$('#orders tbody');ob.innerHTML='';(q.open_orders||[]).forEach(o=>{const tr=document.createElement('tr');tr.innerHTML=`<td>${o.tag}</td><td class="r">${px(o.price)}</td><td class="r">${usd(o.usd)}</td>`;ob.appendChild(tr)});
 if(!(q.open_orders||[]).length)ob.innerHTML='<tr><td colspan="3" class="hint">keine — Reserve '+usd(q.reserve)+'</td></tr>';
 const tb=$('#tr tbody');tb.innerHTML='';(ST.trades||[]).slice().reverse().filter(t=>t.side==='sell'||!t.how.startsWith('Sparplan')).slice(0,25).forEach(t=>{const tr=document.createElement('tr');tr.innerHTML=`<td><span class="tag ${t.side==='buy'?'b':'s'}">${t.side==='buy'?'B':'S'}</span></td><td>${new Date(t.ts*1000).toLocaleDateString('de-DE')}</td><td class="r">${px(t.px)}</td><td class="r">${usd(t.usd)}</td>`;tb.appendChild(tr)});
 const j=$('#jrn');j.innerHTML='';(ST.journal||[]).forEach(e=>{const d=document.createElement('div');d.innerHTML=`<time>${e.t.slice(2,10)}</time>${e.kind==='buy'?'<span class="tag b">B</span>':e.kind==='sell'?'<span class="tag s">S</span>':''}<span>${e.text}</span>`;j.appendChild(d)});
 drawEq(ST.equity);const d=parseInt($('#span').value)*86400,to=(CHART&&CHART.to)||0;if($('#follow').checked&&CUR&&(CUR>to||CUR<to-d||(to-CUR)>d*.08))load(CUR);else draw()}
(async()=>{const c=await(await fetch('/api/config')).json();CFG=c.config;FIELDS=c.fields;$('#ver').textContent=c.version;$('#src').textContent=c.source?`Quelle ${c.source.table}: ${c.source.from} bis ${c.source.to} UTC`:'keine Kerzenquelle gefunden';
 if(c.source)$('#from').value=c.source.from.slice(0,10);form();ladder();manual();await load();setInterval(tick,1500);tick()})();
</script></body></html>"""


def main():
    global DB_PATH
    p = argparse.ArgumentParser(); p.add_argument("--db", default="hl_liq.db"); p.add_argument("--host", default="127.0.0.1"); p.add_argument("--port", type=int, default=8767)
    a = p.parse_args(); DB_PATH = a.db
    print(f"Käufer-Bot {VERSION}\n  http://{a.host}:{a.port}   DB: {DB_PATH}\n  Datei: {__file__}\n  Simulation — keine echten Orders.")
    ThreadingHTTPServer((a.host, a.port), H).serve_forever()


if __name__ == "__main__":
    main()
