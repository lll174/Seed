#!/usr/bin/env python3
"""Wochentag und Uhrzeit fuer den Sparplan-Kauf:  python3 check_time.py --db ../hl_liq.db

Fuer jede Woche (Mo-So, UTC) wird jeder 30-Minuten-Schluss ins Verhaeltnis zum Wochenmittel
gesetzt. Dann Mittelwert je Wochentag, je Stunde, je Wochentag+Stunde — mit Standardfehler,
damit man sieht, ob ein Unterschied mehr als Rauschen ist. Zusaetzlich: Wie oft lag das
Wochentief in welchem Slot?"""
import argparse, sqlite3, math, statistics as st
from datetime import datetime, timezone
p = argparse.ArgumentParser(); p.add_argument("--db", default="../hl_liq.db"); p.add_argument("--coin", default="BTC")
p.add_argument("--tz", type=int, default=0, help="Stundenversatz zu UTC fuer die Anzeige, z. B. 2 fuer MESZ")
a = p.parse_args()
con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
table = next((t for t in ("klines30", "klines", "bnc_bars", "bars") if t in names), None)
rows = con.execute(f"SELECT ts, low, close FROM {table} WHERE coin=? ORDER BY ts", (a.coin,)).fetchall()
WD = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]
weeks = {}
for ts, lo, c in rows:
    d = datetime.fromtimestamp(ts, timezone.utc); iso = d.isocalendar()[:2]
    weeks.setdefault(iso, []).append((d.weekday(), d.hour, d.minute, lo, c))
full = {k: v for k, v in weeks.items() if len(v) >= 300}          # (fast) vollstaendige Wochen
print(f"{table}: {len(rows):,} Kerzen, {len(full)} Wochen mit ausreichend Daten, Zeiten in UTC{'+%d' % a.tz if a.tz else ''}\n")
by_wd = {w: [] for w in range(7)}; by_h = {h: [] for h in range(24)}; by_wh = {}; low_slot = {}
for k, v in full.items():
    mean = sum(x[4] for x in v) / len(v)
    for wd, h, m, lo, c in v:
        rel = (c / mean - 1) * 100
        by_wd[wd].append(rel); by_h[(h + a.tz) % 24].append(rel); by_wh.setdefault((wd, (h + a.tz) % 24), []).append(rel)
    wd, h, m, lo, c = min(v, key=lambda x: x[3])
    low_slot[(wd, (h + a.tz) % 24)] = low_slot.get((wd, (h + a.tz) % 24), 0) + 1
def se(x): return st.stdev(x) / math.sqrt(len(x)) if len(x) > 2 else float("nan")
print("Wochentag (Schluss vs. Wochenmittel):")
for w in range(7):
    print(f"  {WD[w]}  {st.mean(by_wd[w]):+6.2f} %  ±{se(by_wd[w]):.2f}")
print("\nUhrzeit (alle Wochentage):")
hs = sorted(range(24), key=lambda h: st.mean(by_h[h]))
for h in range(24):
    tag = "  <- billigste Stunde" if h == hs[0] else ("  <- teuerste Stunde" if h == hs[-1] else "")
    print(f"  {h:02d}:00  {st.mean(by_h[h]):+6.2f} %  ±{se(by_h[h]):.2f}{tag}")
print("\nDie 8 billigsten und 4 teuersten Wochentag+Stunde-Slots (mindestens 40 Wochen):")
slots = [(k, st.mean(v), se(v), len(v)) for k, v in by_wh.items() if len(v) >= 40]
slots.sort(key=lambda x: x[1])
for (wd, h), m, e, n in slots[:8]: print(f"  {WD[wd]} {h:02d}:00  {m:+6.2f} %  ±{e:.2f}   (n={n})")
print("  ...")
for (wd, h), m, e, n in slots[-4:]: print(f"  {WD[wd]} {h:02d}:00  {m:+6.2f} %  ±{e:.2f}   (n={n})")
print("\nWo lag das Wochentief am haeufigsten?")
for (wd, h), n in sorted(low_slot.items(), key=lambda x: -x[1])[:6]:
    print(f"  {WD[wd]} {h:02d}:00  {n:3d}x  ({n / len(full) * 100:.0f} % der Wochen)")
best = slots[0]; worst = slots[-1]
print(f"\nUnterschied bester zu schlechtester Slot: {worst[1] - best[1]:.2f} % je Rate. "
      f"Ist der Standardfehler aehnlich gross wie der Unterschied, ist es Rauschen.")
