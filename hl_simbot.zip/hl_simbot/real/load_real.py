#!/usr/bin/env python3
"""
Echte BTC-Tageskerzen (Binance ueber static-klines, Stand 3.9.2026) in drei
Datenbanken laden und den Optimizer darueber laufen lassen.

    python3 real/load_real.py          # baut real/real_a.db, real_b.db, real_c.db
    python3 hl_candles.py --db real/real_b.db --from 2024-01-01 --to 2025-09-30

Bloecke (Luecken bewusst nicht ueberbrueckt):
    A  2022-01-01 .. 2023-10-01   Baerenmarkt 47k -> 15.5k und Erholung
    B  2024-01-01 .. 2025-09-30   Bullenmarkt mit Korrekturen von 27 und 31 %
    C  2026-01-01 .. 2026-09-03
Spalten: Tag (Unix-Tage), Hoch, Tief, Schluss. Open = Vortagesschluss.
"""
import csv, os, sqlite3
here = os.path.dirname(os.path.abspath(__file__))
for f, name in (("btc_2022.csv","a"),("btc_2024.csv","b"),("btc_2026.csv","c")):
    p = os.path.join(here, f"real_{name}.db")
    if os.path.exists(p): os.remove(p)
    con = sqlite3.connect(p)
    con.execute("CREATE TABLE klines(ts INT, coin TEXT, open REAL, high REAL, low REAL, "
                "close REAL, volume REAL, PRIMARY KEY(ts,coin))")
    prev = None
    for r in csv.DictReader(open(os.path.join(here, f))):
        ts = int(r["day"]) * 86400; h, l, c = float(r["h"]), float(r["l"]), float(r["c"])
        con.execute("INSERT INTO klines VALUES(?,?,?,?,?,?,?)", (ts, "BTC", prev or c, h, l, c, 0.0))
        prev = c
    con.commit(); con.close(); print("geschrieben:", p)
