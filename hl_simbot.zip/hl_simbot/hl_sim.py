"""
hl_sim.py — Simulations-Engine für den Liquidationscluster-Bot.

Spot-Long-Akkumulation auf BTC: kauft in Tranchen, führt eine Lot-Tabelle,
verkauft gestaffelt. Die Staffelung ist nicht fix, sondern richtet sich nach
der Cluster-Lage: liegt ein großes Short-Cluster nah über dem Kurs, wird die
Leiter unterdrückt (Magnet zieht weiter hoch); erreicht der Kurs das Cluster,
wird hinein verkauft.

Läuft in zwei Betriebsarten über denselben Code:
    backtest — Zeitraum aus der DB, Schritt für Schritt
    live     — pollt die DB im Takt, simuliert Orders (kein echtes Trading)

Benötigt hl_botcore.py im selben Verzeichnis.

    python hl_sim.py --db hl_liq.db --backtest --from 2026-09-01 --to now
    python hl_sim.py --db hl_liq.db --live
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import sqlite3
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

from hl_botcore import (
    Features,
    to_seconds,
    CascadeMachine,
    MachineConfig,
    State,
    connect_ro,
    features_at,
    simulate_fill,
)

log = logging.getLogger("hlsim")


def utc(ts: int) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# ===========================================================================
# Konfiguration — alles hiervon ist im Dashboard editierbar
# ===========================================================================


@dataclass
class SimConfig:
    coin: str = "BTC"

    # --- Kapital
    # budget_usd ist die Einsatzsumme: das Kapital, das der Bot bewirtschaften
    # darf. Im Livebetrieb käme dieser Wert später aus dem Kontostand der
    # Börse; in der Simulation wird er hier gesetzt.
    budget_usd: float = 10000.0
    # "equity" = Prozent vom aktuellen Kontostand (Bar plus Position), wächst
    # also mit dem Ergebnis. "budget" = Prozent der festen Einsatzsumme.
    order_basis: str = "equity"
    order_pct: float = 5.0              # Tranche in % der gewählten Basis
    order_usd: float = 100.0            # feste Tranche, falls order_pct = 0
    min_order_usd: float = 10.0         # darunter wird nicht gekauft
    max_lots: int = 20                  # Einstiegsplätze für lange Dip-Phasen

    # --- Kaufsteuerung
    entry_min_score: int = 3            # Konfluenzpunkte, volle Daten (max. 7)
    candles_min_score: int = 2          # Konfluenzpunkte, Kerzen-Test (max. 4)
    min_seconds_between_buys: int = 1800
    dip_buy_pct: float = 0.8            # Nachkauf ab % unter letztem Lot
    dip_confirm_seconds: int = 300      # so lange kein neues Tief -> Boden ok
    max_add_above_avg_pct: float = 1.5  # Nachkauf im Anstieg nur bis % über Einstand

    # --- Verkaufsleiter (greift, wenn kein Cluster den Kurs hält)
    # Prozentwerte beziehen sich auf die AUSGANGSPOSITION, nicht auf den Rest.
    # 20 + 25 + 25 verkauft heißt: 30 % laufen weiter bis zur Trendumkehr.
    ladder: list = field(default_factory=lambda: [
        {"gain_pct": 3.0, "sell_pct": 25},
        {"gain_pct": 7.0, "sell_pct": 25},
        {"gain_pct": 15.0, "sell_pct": 30},
    ])
    # Nach einer Leiterstufe wächst die Position beim Akkumulieren weiter.
    # Ist sie um diesen Faktor größer als beim Auslösen, wird die Stufe wieder
    # scharf — sonst ist die Leiter nach einer Runde für immer verbraucht.
    ladder_rearm_factor: float = 1.5

    # --- Cluster-Logik
    # cluster_big_ratio ist bewusst niedrig: die Heatmap erfasst nur 30-50 %
    # des Open Interest, gemessene Cluster sind also Untergrenzen.
    cluster_big_ratio: float = 0.25     # Cluster >= x * Stundenvolumen = "groß"
    hold_for_cluster_pct: float = 1.2   # großes Cluster näher als x % -> Leiter aus
    cluster_far_pct: float = 3.0        # weiter als x % -> Cluster ignorieren
    cluster_band_pct: float = 0.25      # Rasterbreite der Heatmap, nicht enger
    cluster_zone_pct: float = 0.5       # Raster, in dem zwei Cluster als
                                        # derselbe gelten
    cluster_cooldown_s: int = 14400     # Mindestabstand zwischen Cluster-Verkäufen
    sell_into_cluster_pct: float = 30.0
    sell_on_squeeze_pct: float = 50.0   # Liquidationen im Cluster = Spitze
    max_cluster_age_s: float = 700.0    # ein Snapshot-Takt (10 min) plus Reserve

    # --- Notausstieg
    # 0 schaltet ihn ab. Standard ist aus: in einem steigenden Markt verkauft
    # jede Panikregel in Rücksetzer hinein, die sich danach erholt haben.
    # In einem fallenden Markt kehrt sich das um — der Wert ist regimeabhängig,
    # nicht allgemeingültig.
    crash_drop_pct: float = 1.0         # entspricht dem move60-Auslöser ...
    crash_window_s: int = 60            # ... des Recorders
    crash_sell_pct: float = 0.0         # 0 = kein Notausstieg
    depth_collapse_ratio: float = 0.4   # bid_50 unter x des Medians der letzten Std.
    cooldown_after_exit_s: int = 3600   # Kaufsperre nach Stop oder Notausstieg

    # --- Trendumkehr für den Runner
    trend_horizons_min: list = field(default_factory=lambda: [60, 120, 180, 360])
    reversal_min_horizons: int = 2      # so viele Horizonte negativ -> Ausstieg
    trend_flat_pct_per_h: float = 0.08  # Betrag, ab dem eine Steigung zählt

    # --- Indikatoren
    rsi_period: int = 14
    rsi_grid_min: int = 15              # 5 min ist für Akkumulation zu unruhig
    rsi_buy: float = 40.0
    rsi_sell: float = 72.0
    fvg_near_pct: float = 0.5
    book_imb_buy: float = 0.25
    funding_buy: float = -0.00005       # Rate je Stunde
    whale_ratio: float = 1.5
    whale_hours: int = 12

    # --- Absicherung
    stop_loss_pct: float = 0.0          # 0 = aus, passend zum Halten-Ansatz
    time_stop_hours: float = 0.0        # 0 = aus

    # --- Kerzen-Modus (nur Chartdaten, ohne Cluster/Buch/Wale)
    candle_source: str = "auto"         # auto | bars | bnc_bars | klines30
    candles_pullback_pct: float = 1.0   # Rücksetzer vom Hoch der letzten Stunden
    candles_pullback_hours: int = 12
    candles_trend_min: int = 360        # Horizont, der intakt sein muss
    candles_slippage_bps: float = 3.0   # pauschal, da kein Orderbuch vorliegt

    # --- Plausibilitaet des Fuellpreises
    max_book_age_s: int = 60            # aelterer Buch-Snapshot wird verworfen
    max_fill_deviation_pct: float = 2.0 # weicht der Fuellpreis weiter vom Mid
                                        # ab, stimmt etwas nicht: verwerfen

    # --- Ausführung
    # 8 bps = 0,08 % je Trade.
    fee_bps_taker: float = 8.0
    fee_bps_maker: float = 1.5
    step_seconds: int = 60              # Auflösung des Backtests
    live_poll_seconds: int = 10

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SimConfig":
        base = cls()
        for k, v in (d or {}).items():
            if hasattr(base, k):
                setattr(base, k, v)
        return base


# ===========================================================================
# Indikatoren
# ===========================================================================


def _grid_closes(conn, coin: str, ts: int, grid_min: int, n: int):
    """Schlusskurse auf einem Minutenraster, rückwärts ab ts. Kein Lookahead."""
    span = grid_min * n * 60
    cur = conn.execute(
        "SELECT ts, close FROM bars WHERE coin=? AND ts<=? AND ts>? ORDER BY ts",
        (coin, ts, ts - span),
    )
    rows = cur.fetchall()
    if not rows:
        return []
    buckets: dict[int, float] = {}
    step = grid_min * 60
    for r in rows:
        buckets[(r["ts"] // step) * step] = r["close"]
    return [buckets[k] for k in sorted(buckets)]


def rsi(values: list[float], period: int = 14) -> float | None:
    if len(values) < period + 1:
        return None
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = values[i] - values[i - 1]
        gains += max(d, 0.0)
        losses += max(-d, 0.0)
    ag, al = gains / period, losses / period
    for i in range(period + 1, len(values)):
        d = values[i] - values[i - 1]
        ag = (ag * (period - 1) + max(d, 0.0)) / period
        al = (al * (period - 1) + max(-d, 0.0)) / period
    if al == 0:
        return 100.0
    return 100.0 - 100.0 / (1.0 + ag / al)


def find_fvgs(conn, coin: str, ts: int, grid_min: int, lookback: int, px: float):
    """
    Dreikerzen-Lücke nach Definition aus der Übergabe.
    Bullisch: Tief der 3. Kerze > Hoch der 1. Gefüllt, wenn der Kurs die
    ferne Kante erreicht hat. Gibt nur ungefüllte Lücken zurück.
    """
    span = grid_min * lookback * 60
    cur = conn.execute(
        "SELECT ts, high, low FROM bars WHERE coin=? AND ts<=? AND ts>? ORDER BY ts",
        (coin, ts, ts - span),
    )
    rows = cur.fetchall()
    step = grid_min * 60
    agg: dict[int, list[float]] = {}
    for r in rows:
        k = (r["ts"] // step) * step
        if k not in agg:
            agg[k] = [r["high"], r["low"]]
        else:
            agg[k][0] = max(agg[k][0], r["high"])
            agg[k][1] = min(agg[k][1], r["low"])
    keys = sorted(agg)
    out = []
    for i in range(len(keys) - 2):
        h1, l1 = agg[keys[i]]
        h3, l3 = agg[keys[i + 2]]
        if l3 > h1:
            lo, hi, kind = h1, l3, "bull"
        elif h3 < l1:
            lo, hi, kind = h3, l1, "bear"
        else:
            continue
        # Füllung prüfen: Kurs seit Entstehung an der fernen Kante?
        far = lo if kind == "bull" else hi
        later = [agg[k] for k in keys[i + 3:]]
        filled = any(
            (c[1] <= far if kind == "bull" else c[0] >= far) for c in later
        )
        if filled:
            continue
        out.append({
            "kind": kind, "lo": lo, "hi": hi, "ts": keys[i + 2],
            "dist_pct": 0.0 if lo <= px <= hi else
                        (min(abs(px - lo), abs(px - hi)) / px * 100.0),
            "inside": lo <= px <= hi,
        })
    return out


def trend_slopes(conn, coin: str, ts: int, horizons_min: list[int]) -> dict:
    """Steigung je Horizont in Prozent pro Stunde, aus einfacher Regression."""
    out = {}
    for h in horizons_min:
        cur = conn.execute(
            "SELECT ts, close FROM bars WHERE coin=? AND ts<=? AND ts>? ORDER BY ts",
            (coin, ts, ts - h * 60),
        )
        rows = cur.fetchall()
        if len(rows) < 5:
            out[h] = None
            continue
        n = len(rows)
        t0 = rows[0]["ts"]
        xs = [(r["ts"] - t0) / 3600.0 for r in rows]
        ys = [r["close"] for r in rows]
        mx, my = sum(xs) / n, sum(ys) / n
        den = sum((x - mx) ** 2 for x in xs)
        if den == 0:
            out[h] = None
            continue
        slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den
        out[h] = slope / my * 100.0
    return out


def zones(buckets: list[dict], px: float, band_pct: float,
          floor_frac: float = 0.35) -> list[dict]:
    """
    Benachbarte Buckets zu Zonen verschmelzen. Ein reales Cluster verteilt sich
    über mehrere Buckets und fiele einzeln betrachtet unter jede sinnvolle
    Größenschwelle.

    Vorher wird auf auffällige Buckets gefiltert: die Heatmap hat in fast jedem
    Bucket einen Wert, und da das Raster (0,25 %) genauso breit ist wie das
    Verschmelzungsfenster, würde sonst die gesamte Preisachse zu einer Zone.
    """
    if not buckets:
        return []
    top = max(b["notional"] for b in buckets)
    items = sorted((b for b in buckets if b["notional"] >= floor_frac * top),
                   key=lambda b: b["bucket_px"])
    if not items:
        return []
    out, cur = [], None
    for b in items:
        if cur and (b["bucket_px"] - cur["hi"]) / px * 100.0 <= band_pct:
            cur["notional"] += b["notional"]
            cur["n_pos"] += b.get("n_pos") or 0
            cur["hi"] = b["bucket_px"]
            cur["_w"] += b["notional"] * b["bucket_px"]
        else:
            if cur:
                out.append(cur)
            cur = {"lo": b["bucket_px"], "hi": b["bucket_px"],
                   "notional": b["notional"], "n_pos": b.get("n_pos") or 0,
                   "side": b["side"], "_w": b["notional"] * b["bucket_px"]}
    if cur:
        out.append(cur)
    for z in out:
        z["bucket_px"] = (z["_w"] / z["notional"]) if z["notional"] else z["lo"]
        z.pop("_w")
        z["dist_pct"] = abs(z["bucket_px"] - px) / px * 100.0
        z["in_band"] = (z["lo"] * (1 - band_pct / 100.0) <= px
                        <= z["hi"] * (1 + band_pct / 100.0))
        z["n_buckets"] = 1
    return out


def clusters_at(conn, coin: str, ts: int, px: float, band_pct: float,
                far_pct: float = 3.0):
    """
    Liquidationscluster aus dem jüngsten Heatmap-Snapshot <= ts.
    side 'short' = Liquidationen über dem Kurs, 'long' = darunter.
    Gewählt wird die größte Zone INNERHALB der Reichweite — nicht die größte
    überhaupt, die sonst eine nähere, handelbare Zone verdecken würde.
    """
    cur = conn.execute(
        "SELECT MAX(ts) t FROM heatmap WHERE coin=? AND ts<=?", (coin, ts)
    )
    row = cur.fetchone()
    if not row or not row["t"]:
        return {"snapshot_ts": None, "age_s": None,
                "above": None, "below": None, "buckets": []}
    snap = row["t"]
    cur = conn.execute(
        """SELECT bucket_px, side, notional, n_pos, lev_wavg
           FROM heatmap WHERE coin=? AND ts=?""",
        (coin, snap),
    )
    buckets = [dict(r) for r in cur.fetchall()]

    up = zones([b for b in buckets if b["bucket_px"] > px], px, band_pct)
    dn = zones([b for b in buckets if b["bucket_px"] < px], px, band_pct)

    def pick(zs):
        near = [z for z in zs if z["dist_pct"] <= far_pct]
        return max(near, key=lambda z: z["notional"]) if near else None

    return {
        "snapshot_ts": snap,
        "age_s": ts - snap,
        "above": pick(up),
        "below": pick(dn),
        "buckets": buckets,
    }


def whale_net(conn, coin: str, ts: int, hours: int) -> dict:
    cur = conn.execute(
        """SELECT side, COALESCE(SUM(delta_usd),0) d FROM whale_positions
           WHERE coin=? AND ts<=? AND ts>? GROUP BY side""",
        (coin, ts, ts - hours * 3600),
    )
    agg = {r["side"]: abs(float(r["d"])) for r in cur.fetchall()}
    long_, short_ = agg.get("long", 0.0), agg.get("short", 0.0)
    ratio = (long_ / short_) if short_ else (math.inf if long_ else 1.0)
    return {"long": long_, "short": short_, "ratio": ratio}


# ===========================================================================
# Marktsicht: Features + Indikatoren an einem Zeitpunkt
# ===========================================================================


@dataclass
class View:
    ts: int
    f: Features
    px: float
    rsi: float | None
    fvgs: list
    trend: dict
    clusters: dict
    whales: dict
    velocity_pct: float          # Kursänderung im Crash-Fenster
    depth_median_1h: float | None


def build_view(conn, cfg: SimConfig, ts: int) -> View | None:
    f = features_at(conn, cfg.coin, ts)
    px = f.mark_px or f.mid_px
    if px is None:
        return None

    closes = _grid_closes(conn, cfg.coin, ts, cfg.rsi_grid_min, cfg.rsi_period * 4)
    cur = conn.execute(
        "SELECT close FROM bars WHERE coin=? AND ts<=? AND ts>? ORDER BY ts LIMIT 1",
        (cfg.coin, ts, ts - cfg.crash_window_s),
    )
    r = cur.fetchone()
    vel = ((px - r["close"]) / r["close"] * 100.0) if r else 0.0

    cur = conn.execute(
        "SELECT bid_50 FROM book_summary WHERE coin=? AND ts<=? AND ts>? ",
        (cfg.coin, ts, ts - 3600),
    )
    depths = sorted(x["bid_50"] for x in cur.fetchall() if x["bid_50"])
    med = depths[len(depths) // 2] if depths else None

    return View(
        ts=ts,
        f=f,
        px=px,
        rsi=rsi(closes, cfg.rsi_period),
        fvgs=find_fvgs(conn, cfg.coin, ts, cfg.rsi_grid_min, 60, px),
        trend=trend_slopes(conn, cfg.coin, ts, cfg.trend_horizons_min),
        clusters=clusters_at(conn, cfg.coin, ts, px, cfg.cluster_band_pct,
                             cfg.cluster_far_pct),
        whales=whale_net(conn, cfg.coin, ts, cfg.whale_hours),
        velocity_pct=vel,
        depth_median_1h=med,
    )


# ===========================================================================
# Lot-Tabelle
# ===========================================================================


@dataclass
class Lot:
    ts: int
    px: float
    size: float          # Coin-Einheiten
    cost: float          # USD inkl. Gebühr
    reason: str
    open_size: float = 0.0

    def __post_init__(self):
        if not self.open_size:
            self.open_size = self.size


@dataclass
class Trade:
    ts: int
    side: str            # "buy" | "sell"
    px: float
    size: float
    usd: float
    fee: float
    reason: str
    realized: float = 0.0


class Portfolio:
    """FIFO-Kostenbasis. Teilverkäufe werden als Anteil der Gesamtmenge geordert."""

    def __init__(self, cfg: SimConfig):
        self.cfg = cfg
        self.cash = cfg.budget_usd
        self.lots: list[Lot] = []
        self.trades: list[Trade] = []
        self.realized = 0.0
        self.fees = 0.0
        self.ladder_done: dict[int, float] = {}   # Stufe -> peak_size beim Auslösen
        self.cluster_sold_at: set[float] = set()
        self.last_buy_ts = 0
        self.first_entry_ts: int | None = None
        self.peak_size = 0.0     # größte Position der laufenden Runde
        self.emergency_latched = False   # ein Notausstieg je Episode
        self.last_forced_exit_ts = 0
        self.last_cluster_sell_ts = 0

    def fraction_for(self, d) -> float:
        """
        Rechnet einen Anteil der Ausgangsposition in einen Anteil des
        aktuellen Bestands um. Ohne das verkauft eine Leiter aus dreimal
        25 % am Ende 58 % statt 75 %.
        """
        if getattr(d, "basis", "current") != "peak":
            return d.amount
        if not self.size or not self.peak_size:
            return d.amount
        return min(1.0, d.amount * self.peak_size / self.size)

    def next_order_usd(self, px: float | None = None) -> float:
        """
        Größe der nächsten Tranche. 0 = Kauf nicht möglich.
        Bei order_basis = "equity" wächst die Tranche mit dem Kontostand,
        statt an der ursprünglichen Einsatzsumme zu kleben.
        """
        cfg = self.cfg
        basis = cfg.budget_usd
        if cfg.order_basis == "equity" and px:
            basis = max(0.0, self.equity(px))
        usd = (basis * cfg.order_pct / 100.0
               if cfg.order_pct > 0 else cfg.order_usd)
        usd = min(usd, self.cash)
        return usd if usd >= cfg.min_order_usd else 0.0

    # ---- Kennzahlen
    @property
    def size(self) -> float:
        return sum(l.open_size for l in self.lots)

    @property
    def cost_basis(self) -> float:
        return sum(l.open_size / l.size * l.cost for l in self.lots if l.size)

    @property
    def avg_px(self) -> float | None:
        s = self.size
        return (self.cost_basis / s) if s else None

    def unrealized(self, px: float) -> float:
        return self.size * px - self.cost_basis if self.size else 0.0

    def equity(self, px: float) -> float:
        return self.cash + self.size * px

    def gain_pct(self, px: float) -> float:
        a = self.avg_px
        return ((px - a) / a * 100.0) if a else 0.0

    # ---- Aktionen
    def buy(self, ts: int, px: float, usd: float, fee_bps: float, reason: str):
        usd = min(usd, self.cash)
        if usd < 1.0:
            return None
        fee = usd * fee_bps / 1e4
        size = (usd - fee) / px
        self.cash -= usd
        self.fees += fee
        lot = Lot(ts=ts, px=px, size=size, cost=usd, reason=reason)
        self.lots.append(lot)
        self.peak_size = max(self.peak_size, self.size)
        self.last_buy_ts = ts
        if self.first_entry_ts is None:
            self.first_entry_ts = ts
        t = Trade(ts, "buy", px, size, usd, fee, reason)
        self.trades.append(t)
        return t

    def sell_fraction(self, ts: int, px: float, frac: float,
                      fee_bps: float, reason: str):
        frac = max(0.0, min(1.0, frac))
        want = self.size * frac
        if want <= 0:
            return None
        remaining, cost_out = want, 0.0
        for lot in self.lots:
            if remaining <= 1e-12:
                break
            take = min(lot.open_size, remaining)
            if take <= 0:
                continue
            cost_out += take / lot.size * lot.cost
            lot.open_size -= take
            remaining -= take
        sold = want - remaining
        gross = sold * px
        fee = gross * fee_bps / 1e4
        self.cash += gross - fee
        self.fees += fee
        pnl = gross - fee - cost_out
        self.realized += pnl
        self.lots = [l for l in self.lots if l.open_size > 1e-12]
        if not self.lots:
            self.ladder_done.clear()
            self.cluster_sold_at.clear()
            self.first_entry_ts = None
            self.peak_size = 0.0
        t = Trade(ts, "sell", px, sold, gross, fee, reason, realized=pnl)
        self.trades.append(t)
        return t


# ===========================================================================
# Ausführung: Füllpreis
# ===========================================================================


def fill_price(conn, cfg: SimConfig, v: View, is_buy: bool, usd: float) -> float:
    """
    Bevorzugt das echte Buch aus book_ticks (nur in Ereignisfenstern vorhanden),
    sonst book_summary mit Tiefenmodell. Nie den letzten Trade als Füllpreis.
    """
    # t_start/t_end stehen in Millisekunden, v.ts in Sekunden.
    ms = v.ts * 1000
    cur = conn.execute(
        """SELECT id FROM tick_events WHERE coin=? AND t_start<=? AND t_end>=?
           ORDER BY t_start DESC LIMIT 1""",
        (cfg.coin, ms, ms),
    )
    ev = cur.fetchone()
    if ev:
        cur = conn.execute(
            """SELECT levels, ts_ms FROM book_ticks WHERE event_id=? AND coin=?
               AND ts_ms<=? ORDER BY ts_ms DESC LIMIT 1""",
            (ev["id"], cfg.coin, ms),
        )
        b = cur.fetchone()
        if b and (ms - b["ts_ms"]) <= cfg.max_book_age_s * 1000:
            res = simulate_fill(b["levels"], is_buy, usd / v.px)
            avg = res["avg_px"]
            # Ein Buch, das nicht zum Kurs passt, erzeugt sonst lautlos
            # Scheingewinne. Lieber das groebere Modell als ein falscher Fill.
            plausible = (avg and abs(avg / v.px - 1.0) * 100.0
                         <= cfg.max_fill_deviation_pct)
            if plausible and not res["book_exhausted"]:
                return avg

    base = (v.f.ask or v.px) if is_buy else (v.f.bid or v.px)
    depth = (v.f.ask_50 if is_buy else v.f.bid_50) or 0.0
    extra_bps = 0.0
    if depth > 0:
        extra_bps = min(50.0, (usd / depth) * 25.0)
    return base * (1 + extra_bps / 1e4) if is_buy else base * (1 - extra_bps / 1e4)


# ===========================================================================
# Strategie
# ===========================================================================


@dataclass
class Decision:
    action: str          # "buy" | "sell" | "hold"
    amount: float = 0.0  # USD bei buy, Anteil 0..1 bei sell
    reason: str = ""
    score: int = 0
    detail: dict = field(default_factory=dict)
    basis: str = "current"   # "peak" = Anteil der Ausgangsposition


class Strategy:
    def __init__(self, cfg: SimConfig):
        self.cfg = cfg
        self.min_score = cfg.entry_min_score
        self.machine = CascadeMachine(MachineConfig(
            cluster_dist=cfg.hold_for_cluster_pct / 100.0,
            cluster_size_ratio=cfg.cluster_big_ratio,
            max_cluster_age=cfg.max_cluster_age_s,
        ))
        self.low_since_dip: float | None = None
        self.low_ts: int = 0

    # ---------------------------------------------------------------- Kauf
    def entry_score(self, v: View) -> tuple[int, list[str]]:
        cfg, notes, s = self.cfg, [], 0

        if self.machine.state is State.END:
            s += 2
            notes.append("Kaskade abgeschlossen (+2)")
        if v.rsi is not None and v.rsi <= cfg.rsi_buy:
            s += 1
            notes.append(f"RSI {v.rsi:.0f} (+1)")
        near_fvg = [g for g in v.fvgs
                    if g["kind"] == "bull" and (g["inside"] or g["dist_pct"] <= cfg.fvg_near_pct)]
        if near_fvg:
            s += 1
            notes.append("bullisches FVG am Kurs (+1)")
        if v.f.imb_50 is not None and v.f.imb_50 >= cfg.book_imb_buy:
            s += 1
            notes.append(f"Buch-Imbalance {v.f.imb_50:+.2f} (+1)")
        if v.f.funding is not None and v.f.funding <= cfg.funding_buy:
            s += 1
            notes.append("negatives Funding (+1)")
        if v.whales["ratio"] >= cfg.whale_ratio:
            s += 1
            notes.append("Wale netto long (+1)")

        below = v.clusters.get("below")
        if below and below["dist_pct"] <= cfg.hold_for_cluster_pct:
            hv = v.f.hourly_notional or 0.0
            if hv and below["notional"] >= cfg.cluster_big_ratio * hv:
                s -= 2
                notes.append(f"großes Long-Cluster {below['dist_pct']:.2f}% "
                             f"darunter — Abholung wahrscheinlich (-2)")
        return s, notes

    def want_buy(self, v: View, pf: Portfolio) -> Decision:
        cfg = self.cfg
        order = pf.next_order_usd(v.px)
        if order <= 0 or len(pf.lots) >= cfg.max_lots:
            return Decision("hold", reason="Einsatzsumme aufgebraucht "
                                           "oder alle Plätze belegt")
        if v.ts - pf.last_buy_ts < cfg.min_seconds_between_buys:
            return Decision("hold", reason="Mindestabstand zum letzten Kauf")
        if pf.last_forced_exit_ts and \
                v.ts - pf.last_forced_exit_ts < cfg.cooldown_after_exit_s:
            return Decision("hold", reason="Sperre nach Zwangsausstieg")
        if not v.f.usable():
            return Decision("hold", reason="Marktdaten zu alt")

        score, notes = self.entry_score(v)
        threshold = self.min_score

        # Nachkauf im Dip: Kurs unter letztem Lot, Boden bestätigt.
        dip = False
        if pf.lots:
            last = pf.lots[-1]
            drop = (last.px - v.px) / last.px * 100.0
            if drop >= cfg.dip_buy_pct:
                if self.low_since_dip is None or v.px < self.low_since_dip:
                    self.low_since_dip, self.low_ts = v.px, v.ts
                stable = (v.ts - self.low_ts) >= cfg.dip_confirm_seconds
                quiet = v.f.n_liq_60s == 0
                if stable and quiet:
                    dip = True
                    threshold -= 1
                    notes.append(f"Dip {drop:.2f}% unter letztem Lot, "
                                 f"{v.ts - self.low_ts}s ohne neues Tief")
                else:
                    return Decision("hold", score=score,
                                    reason="Dip noch nicht bestätigt")
            else:
                self.low_since_dip = None
                # Nachkauf im Anstieg nur begrenzt über dem Einstand
                a = pf.avg_px
                if a and (v.px - a) / a * 100.0 > cfg.max_add_above_avg_pct and not dip:
                    return Decision("hold", score=score,
                                    reason="zu weit über Einstand für Nachkauf")

        if score >= threshold:
            return Decision("buy", order,
                            "; ".join(notes) or "Konfluenz", score,
                            {"threshold": threshold, "dip": dip})
        return Decision("hold", score=score,
                        reason=f"Score {score} < {threshold}")

    # ------------------------------------------------------------- Verkauf
    def big_cluster_above(self, v: View):
        cfg = self.cfg
        c = v.clusters.get("above")
        if not c:
            return None
        if v.clusters.get("age_s", 0) > cfg.max_cluster_age_s:
            return None
        hv = v.f.hourly_notional or 0.0
        if hv and c["notional"] < cfg.cluster_big_ratio * hv:
            return None
        if c["dist_pct"] > cfg.cluster_far_pct:
            return None
        return c

    def trend_reversed(self, v: View) -> tuple[bool, str]:
        cfg = self.cfg
        neg = [h for h, s in v.trend.items()
               if s is not None and s < -cfg.trend_flat_pct_per_h]
        if len(neg) >= cfg.reversal_min_horizons:
            return True, f"Trend negativ auf {sorted(neg)} min"
        return False, ""

    def want_sell(self, v: View, pf: Portfolio) -> Decision:
        cfg = self.cfg
        if not pf.lots:
            return Decision("hold")
        # Was übrig ist, muss eine Order wert sein. Sonst entstehen Verkäufe
        # über wenige Cent, deren Gebühr das Ergebnis übersteigt.
        if pf.size * v.px < cfg.min_order_usd:
            return Decision("hold", reason="Restposition unter der Mindestorder")
        gain = pf.gain_pct(v.px)

        # 1. Notausstieg: schneller Abverkauf oder wegbrechende Bid-Tiefe.
        #    Bei crash_sell_pct = 0 abgeschaltet.
        on = cfg.crash_sell_pct > 0 and cfg.crash_drop_pct > 0
        depth_gone = on and bool(
            v.depth_median_1h and v.f.bid_50 is not None
            and v.f.bid_50 < cfg.depth_collapse_ratio * v.depth_median_1h
        )
        crash = on and v.velocity_pct <= -cfg.crash_drop_pct
        if not crash and not depth_gone:
            pf.emergency_latched = False        # Episode vorbei, Sperre lösen
        elif not pf.emergency_latched:
            pf.emergency_latched = True
            pf.last_forced_exit_ts = v.ts
            why = (f"Abverkauf {v.velocity_pct:.2f}% in {cfg.crash_window_s}s"
                   if crash else "Bid-Tiefe eingebrochen")
            return Decision("sell", cfg.crash_sell_pct / 100.0, f"Notausstieg: {why}")

        # 2. Stop und Zeitstop
        if cfg.stop_loss_pct and gain <= -cfg.stop_loss_pct:
            pf.last_forced_exit_ts = v.ts
            return Decision("sell", 1.0, f"Stop bei {gain:.2f}%")
        if cfg.time_stop_hours and pf.first_entry_ts:
            if v.ts - pf.first_entry_ts > cfg.time_stop_hours * 3600:
                pf.last_forced_exit_ts = v.ts
                return Decision("sell", 1.0, "Zeitstop")

        cluster = self.big_cluster_above(v)

        # 3. Liquidationen laufen, während der Kurs am Cluster steht: das ist
        #    die Spitze. Muss VOR dem einfachen Cluster-Verkauf stehen, sonst
        #    nimmt der kleinere Anteil dem grösseren die Gelegenheit weg.
        # Der Bucket-Preis verschiebt sich mit jedem Snapshot. Ohne Raster
        # gilt dieselbe Zone jedes Mal als neu und wird erneut verkauft.
        key = None
        if cluster:
            grid = max(1e-9, v.px * cfg.cluster_zone_pct / 100.0)
            key = int(cluster["bucket_px"] / grid)
        cooled = (v.ts - pf.last_cluster_sell_ts) >= cfg.cluster_cooldown_s
        if cluster and v.f.n_liq_60s > 0 and gain > 0 and cooled \
                and key not in pf.cluster_sold_at \
                and cluster["dist_pct"] <= cfg.cluster_band_pct * 3:
            pf.cluster_sold_at.add(key)
            pf.last_cluster_sell_ts = v.ts
            return Decision("sell", cfg.sell_on_squeeze_pct / 100.0,
                            f"Squeeze am Cluster bei {cluster['bucket_px']:.0f} "
                            f"({v.f.n_liq_60s} Liquidationen)",
                            detail={"cluster": cluster}, basis="peak")

        # 4. Kurs steht im Short-Cluster, aber ohne Kaskade: hinein verkaufen
        if cluster and cluster["in_band"] and cooled \
                and key not in pf.cluster_sold_at and gain > 0:
            pf.cluster_sold_at.add(key)
            pf.last_cluster_sell_ts = v.ts
            return Decision(
                "sell", cfg.sell_into_cluster_pct / 100.0,
                f"im Short-Cluster bei {cluster['bucket_px']:.0f} "
                f"({cluster['notional']/1e6:.1f} Mio)",
                detail={"cluster": cluster}, basis="peak")

        # 5. Leiter — unterdrückt, solange ein großes Cluster nah darüber zieht
        hold_for_magnet = cluster and cluster["dist_pct"] <= cfg.hold_for_cluster_pct
        if not hold_for_magnet:
            for i, step in enumerate(cfg.ladder):
                fired_at = pf.ladder_done.get(i)
                if fired_at is not None:
                    # Stufe wieder scharf, wenn seither deutlich nachgekauft wurde
                    if pf.peak_size < fired_at * cfg.ladder_rearm_factor:
                        continue
                if gain >= step["gain_pct"]:
                    pf.ladder_done[i] = pf.peak_size
                    again = " (erneut)" if fired_at is not None else ""
                    return Decision("sell", step["sell_pct"] / 100.0,
                                    f"Leiterstufe {i+1} bei {gain:+.2f}%{again}",
                                    detail={"step": step}, basis="peak")

        # 6. Runner: Rest halten, bis der Trend kippt
        all_steps_done = len(pf.ladder_done) >= len(cfg.ladder)
        if all_steps_done and gain > 0:
            rev, why = self.trend_reversed(v)
            overbought = v.rsi is not None and v.rsi >= cfg.rsi_sell
            if rev and (overbought or not cluster):
                return Decision("sell", 1.0, f"Trendumkehr: {why}")

        if hold_for_magnet:
            return Decision("hold", reason=(
                f"halte — Short-Cluster {cluster['dist_pct']:.2f}% darüber "
                f"({cluster['notional']/1e6:.1f} Mio)"))
        return Decision("hold", reason=f"Gewinn {gain:+.2f}%")


# ===========================================================================
# Engine
# ===========================================================================


class ResultLog:
    """
    Schreibt Läufe, Trades und Protokoll in eine eigene Datei. Ohne das ist
    ein Live-Test nach einem Neustart des Dienstes verloren. Getrennt von
    hl_liq.db, damit der Recorder alleiniger Schreiber seiner Datenbank bleibt.
    """

    def __init__(self, path: str):
        self.con = sqlite3.connect(path, check_same_thread=False, timeout=10.0)
        self.con.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS sim_runs(
            run_id TEXT PRIMARY KEY, started INT, mode TEXT, coin TEXT,
            t_from INT, t_to INT, config TEXT);
        CREATE TABLE IF NOT EXISTS sim_trades(
            run_id TEXT, ts INT, side TEXT, px REAL, size REAL, usd REAL,
            fee REAL, realized REAL, reason TEXT);
        CREATE TABLE IF NOT EXISTS sim_journal(
            run_id TEXT, ts INT, kind TEXT, text TEXT);
        CREATE INDEX IF NOT EXISTS ix_trades ON sim_trades(run_id, ts);
        """)
        self.con.commit()
        self.run_id: str | None = None

    def start(self, mode: str, cfg: SimConfig, t_from: int, t_to: int) -> str:
        self.run_id = f"{mode}-{int(time.time())}"
        self.con.execute("INSERT INTO sim_runs VALUES(?,?,?,?,?,?,?)",
                         (self.run_id, int(time.time()), mode, cfg.coin,
                          t_from, t_to, json.dumps(cfg.to_dict())))
        self.con.commit()
        return self.run_id

    def trade(self, t: "Trade") -> None:
        if not self.run_id:
            return
        self.con.execute("INSERT INTO sim_trades VALUES(?,?,?,?,?,?,?,?,?)",
                         (self.run_id, t.ts, t.side, t.px, t.size, t.usd,
                          t.fee, t.realized, t.reason))
        self.con.commit()

    def note(self, ts: int, kind: str, text: str) -> None:
        if not self.run_id or kind == "hold":
            return
        self.con.execute("INSERT INTO sim_journal VALUES(?,?,?,?)",
                         (self.run_id, ts, kind, text))
        self.con.commit()


class Engine:
    def __init__(self, db_path: str, cfg: SimConfig, results_db: str | None = None):
        self.db_path = db_path
        self.cfg = cfg
        self.conn = connect_ro(db_path)
        self.results = ResultLog(results_db) if results_db else None
        self.pf = Portfolio(cfg)
        self.strat = Strategy(cfg)
        self.marks: list[dict] = []      # B/S-Markierungen für den Chart
        self.equity: list[dict] = []
        self.journal: list[dict] = []
        self.last_view: View | None = None
        self.running = False
        self.progress = 0.0

    def _log(self, ts: int, kind: str, text: str, extra: dict | None = None):
        self.journal.append({"ts": ts, "t": utc(ts), "kind": kind,
                             "text": text, **(extra or {})})
        if self.results:
            self.results.note(ts, kind, text)
        if len(self.journal) > 4000:
            del self.journal[:1000]

    # Erweiterungspunkte: der Kerzen-Modus ersetzt diese beiden Methoden.
    def view(self, ts: int) -> "View | None":
        return build_view(self.conn, self.cfg, ts)

    def fill(self, v: "View", is_buy: bool, usd: float) -> float:
        return fill_price(self.conn, self.cfg, v, is_buy, usd)

    def step(self, ts: int) -> None:
        v = self.view(ts)
        if v is None:
            return
        self.last_view = v
        self.strat.machine.step(v.f)

        d = self.strat.want_sell(v, self.pf)
        if d.action == "sell":
            frac = self.pf.fraction_for(d)
            px = self.fill(v, False, self.pf.size * v.px * frac)
            t = self.pf.sell_fraction(ts, px, frac, self.cfg.fee_bps_taker, d.reason)
            if t:
                if self.results:
                    self.results.trade(t)
                self.marks.append({"ts": ts, "px": px, "side": "S",
                                   "reason": d.reason, "size": t.size,
                                   "pnl": t.realized})
                anteil = (f"{d.amount*100:.0f}% der Ausgangsposition"
                          if d.basis == "peak" else f"{frac*100:.0f}% des Bestands")
                self._log(ts, "sell",
                          f"Verkauf {anteil} zu {px:,.0f} — {d.reason}",
                          {"pnl": round(t.realized, 2)})
        else:
            b = self.strat.want_buy(v, self.pf)
            if b.action == "buy":
                px = self.fill(v, True, b.amount)
                t = self.pf.buy(ts, px, b.amount, self.cfg.fee_bps_taker, b.reason)
                if t:
                    if self.results:
                        self.results.trade(t)
                    self.marks.append({"ts": ts, "px": px, "side": "B",
                                       "reason": b.reason, "size": t.size})
                    self._log(ts, "buy",
                              f"Kauf {b.amount:.0f} USD zu {px:,.0f} — {b.reason}",
                              {"score": b.score})

        self.equity.append({
            "ts": ts, "equity": round(self.pf.equity(v.px), 2),
            "px": v.px, "size": round(self.pf.size, 6),
            "realized": round(self.pf.realized, 2),
            "unrealized": round(self.pf.unrealized(v.px), 2),
        })

    # ---- Betriebsarten
    def data_range(self) -> dict:
        out = {}
        for tbl in ("bars", "bars10", "ctx_bars", "book_summary",
                    "heatmap", "proximity", "whale_positions"):
            try:
                cur = self.conn.execute(
                    f"SELECT MIN(ts) a, MAX(ts) b FROM {tbl} WHERE coin=?",
                    (self.cfg.coin,))
                r = cur.fetchone()
            except sqlite3.Error:
                cur = self.conn.execute(f"SELECT MIN(ts) a, MAX(ts) b FROM {tbl}")
                r = cur.fetchone()
            out[tbl] = {"from": r["a"], "to": r["b"]}
        return out

    def usable_range(self) -> tuple[int, int]:
        """Engster gemeinsamer Bereich der strategierelevanten Tabellen."""
        r = self.data_range()
        need = ["bars", "ctx_bars", "book_summary", "heatmap", "proximity"]
        starts = [r[t]["from"] for t in need if r[t]["from"]]
        ends = [r[t]["to"] for t in need if r[t]["to"]]
        return (max(starts) if starts else 0, min(ends) if ends else 0)

    def run_backtest(self, t_from: int, t_to: int, on_progress=None) -> dict:
        lo, hi = self.usable_range()
        clipped = False
        if lo and t_from < lo:
            t_from, clipped = lo, True
        if hi and t_to > hi:
            t_to, clipped = hi, True
        if t_from >= t_to:
            return {"error": "Kein nutzbarer Zeitraum in der Datenbank.",
                    "usable": {"from": lo, "to": hi}}

        self.running = True
        if self.results:
            self.results.start("backtest", self.cfg, t_from, t_to)
        total = max(1, t_to - t_from)
        self._log(t_from, "info",
                  f"Backtest {utc(t_from)} bis {utc(t_to)}"
                  + (" (auf verfügbare Daten beschnitten)" if clipped else ""))
        ts = t_from
        while ts <= t_to and self.running:
            self.step(ts)
            ts += self.cfg.step_seconds
            self.progress = (ts - t_from) / total
            if on_progress and int(self.progress * 100) % 5 == 0:
                on_progress(self.progress)
        self.running = False
        self.progress = 1.0

        px = self.last_view.px if self.last_view else 0.0
        return self.summary(px) | {"clipped": clipped}

    def run_live(self, stop_flag=lambda: False) -> None:
        self.running = True
        now = int(time.time())
        if self.results:
            self.results.start("live", self.cfg, now, 0)
        self._log(now, "info", "Live-Simulation gestartet")
        while self.running and not stop_flag():
            self.step(int(time.time()))
            time.sleep(self.cfg.live_poll_seconds)
        self.running = False

    def summary(self, px: float | None = None) -> dict:
        px = px or (self.last_view.px if self.last_view else 0.0)
        buys = [t for t in self.pf.trades if t.side == "buy"]
        sells = [t for t in self.pf.trades if t.side == "sell"]
        wins = [t for t in sells if t.realized > 0]
        invested = sum(t.usd for t in buys)
        return {
            "equity": round(self.pf.equity(px), 2),
            "start_budget": self.cfg.budget_usd,
            "realized": round(self.pf.realized, 2),
            "unrealized": round(self.pf.unrealized(px), 2),
            "fees": round(self.pf.fees, 2),
            "fees_pct_budget": round(
                self.pf.fees / self.cfg.budget_usd * 100.0, 2)
                if self.cfg.budget_usd else 0.0,
            "turnover_x": round(invested / self.cfg.budget_usd, 1)
                if self.cfg.budget_usd else 0.0,
            "return_pct": round(
                (self.pf.equity(px) - self.cfg.budget_usd)
                / self.cfg.budget_usd * 100.0, 3),
            "n_buys": len(buys), "n_sells": len(sells),
            "hit_rate": round(len(wins) / len(sells) * 100.0, 1) if sells else None,
            "invested": round(invested, 2),
            "cash": round(self.pf.cash, 2),
            "deployed": round(self.pf.cost_basis, 2),
            "deployed_pct": round(
                self.pf.cost_basis / self.cfg.budget_usd * 100.0, 1)
                if self.cfg.budget_usd else 0.0,
            "max_lots": self.cfg.max_lots,
            "next_order": round(self.pf.next_order_usd(px), 2),
            "open_lots": len(self.pf.lots),
            "open_size": round(self.pf.size, 6),
            "avg_px": round(self.pf.avg_px, 2) if self.pf.avg_px else None,
            "last_px": px,
        }

    def lots_view(self) -> list[dict]:
        px = self.last_view.px if self.last_view else 0.0
        return [{
            "t": utc(l.ts), "px": round(l.px, 2),
            "size": round(l.open_size, 6),
            "usd0": round(l.cost, 2),
            "rest_pct": round(l.open_size / l.size * 100.0, 0) if l.size else 0,
            "usd": round(l.open_size / l.size * l.cost, 2) if l.size else 0.0,
            "pnl": round(l.open_size * (px - l.px), 2),
            "pnl_pct": round((px - l.px) / l.px * 100.0, 2),
            "reason": l.reason,
        } for l in self.pf.lots]


# ===========================================================================
# CLI
# ===========================================================================


def parse_time(s: str) -> int:
    if s in ("now", "jetzt"):
        return int(time.time())
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return int(datetime.strptime(s, fmt).replace(
                tzinfo=timezone.utc).timestamp())
        except ValueError:
            continue
    return int(s)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="hl_liq.db")
    p.add_argument("--coin", default="BTC")
    p.add_argument("--backtest", action="store_true")
    p.add_argument("--live", action="store_true")
    p.add_argument("--from", dest="t_from", default="2026-09-01")
    p.add_argument("--to", dest="t_to", default="now")
    p.add_argument("--config", help="JSON-Datei mit Parametern")
    p.add_argument("--results", default="hl_sim_results.db",
                   help="Datei fuer Trades und Protokoll ('' schaltet ab)")
    a = p.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    cfg = SimConfig.from_dict(json.load(open(a.config))) if a.config else SimConfig()
    cfg.coin = a.coin
    eng = Engine(a.db, cfg, results_db=a.results or None)

    if a.backtest:
        res = eng.run_backtest(parse_time(a.t_from), parse_time(a.t_to))
        print(json.dumps(res, indent=2, ensure_ascii=False))
        for e in eng.journal[-40:]:
            print(f"{e['t']}  {e['kind']:>5}  {e['text']}")
    elif a.live:
        try:
            eng.run_live()
        except KeyboardInterrupt:
            print(json.dumps(eng.summary(), indent=2, ensure_ascii=False))
    else:
        print(json.dumps(eng.data_range(), indent=2))


if __name__ == "__main__":
    main()
