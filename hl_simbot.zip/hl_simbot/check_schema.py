#!/usr/bin/env python3
"""
check_schema.py — prueft die echte hl_liq.db gegen das, was der Simulator
erwartet, bevor ein Lauf startet.

    python3 check_schema.py --db hl_liq.db

Meldet fehlende Tabellen und Spalten, erkennt Sekunden gegen Millisekunden
an der Groessenordnung und zeigt die Wertebereiche der Felder, deren Einheit
sich aus dem Schema nicht ablesen laesst (Abstaende in Prozent oder Anteil).
Aendert nichts; oeffnet die Datenbank schreibgeschuetzt.
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from datetime import datetime, timezone

# Tabelle -> Spalten, die der Simulator tatsaechlich liest
NEEDED = {
    "bars":          ["ts", "coin", "open", "high", "low", "close", "volume"],
    "bars10":        ["ts", "coin", "vol_buy", "vol_sell", "n_liq", "liq_notional"],
    "ctx_bars":      ["ts", "coin", "mark_px", "mid_px", "funding", "oi"],
    "book_summary":  ["ts", "coin", "bid", "ask", "spread_bps",
                      "bid_50", "ask_50", "imb_50"],
    "heatmap":       ["ts", "coin", "bucket_px", "side", "notional", "n_pos"],
    "proximity":     ["ts", "coin", "px", "up_px", "up_notional", "up_dist",
                      "dn_px", "dn_notional", "dn_dist"],
    "whale_positions": ["ts", "coin", "side", "delta_usd"],
    "snapshot_meta": ["ts", "age_p90"],
    "tick_events":   ["id", "coin", "t_start", "t_end", "t_trigger",
                      "reason", "n_liqs", "complete"],
    "book_ticks":    ["event_id", "ts_ms", "coin", "levels"],
}
OPTIONAL = {"bnc_bars", "klines30"}          # nur fuer den Kerzen-Modus

MS_THRESHOLD = 100_000_000_000


def open_ro(path: str) -> sqlite3.Connection:
    """Oeffnet schreibgeschuetzt und erklaert im Fehlerfall, was fehlt."""
    import glob
    import os
    if not os.path.exists(path):
        print(f"Datenbank nicht gefunden: {path}")
        print(f"Aktuelles Verzeichnis: {os.getcwd()}")
        found = sorted(set(glob.glob("*.db") + glob.glob("../*.db")
                           + glob.glob("*/*.db")))
        if found:
            print("Gefunden in der Naehe:")
            for f in found:
                print(f"  --db {f}    ({os.path.getsize(f)/1e6:.0f} MB)")
        else:
            print("Keine .db-Datei in der Naehe. Aus dem Verzeichnis starten, "
                  "in dem hl_liq.db liegt.")
        raise SystemExit(2)
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10.0)
        con.execute("SELECT 1 FROM sqlite_master LIMIT 1")
        return con
    except sqlite3.OperationalError as e:
        print(f"Datenbank nicht lesbar: {e}")
        if os.path.exists(path + "-wal"):
            print("Es liegt ein WAL vor. Schreibgeschuetzt geht das nur, "
                  "solange der Recorder laeuft: sudo systemctl start hl-recorder")
        raise SystemExit(2)


def utc(ts):
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M") \
        if ts else "—"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="hl_liq.db")
    ap.add_argument("--coin", default="BTC")
    a = ap.parse_args()

    con = open_ro(a.db)
    con.row_factory = sqlite3.Row
    present = {r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}

    problems = warnings = 0
    print(f"Datenbank: {a.db}\n")

    for table, cols in NEEDED.items():
        if table not in present:
            print(f"  FEHLT   {table}")
            problems += 1
            continue
        have = {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
        missing = [c for c in cols if c not in have]
        n = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        if missing:
            print(f"  SPALTE  {table}: fehlt {', '.join(missing)}")
            problems += 1
        elif n == 0:
            print(f"  LEER    {table}: 0 Zeilen — der Recorder hat hier "
                  f"noch nichts geschrieben")
            warnings += 1
        else:
            tcol = "t_start" if table == "tick_events" else (
                   "ts_ms" if table == "book_ticks" else "ts")
            lo, hi = con.execute(
                f"SELECT MIN({tcol}), MAX({tcol}) FROM {table}").fetchone()
            unit = "ms" if (hi or 0) > MS_THRESHOLD else "s"
            div = 1000 if unit == "ms" else 1
            print(f"  ok      {table:15s} {n:>9,} Zeilen  "
                  f"{utc((lo or 0)//div)} bis {utc((hi or 0)//div)}  [{unit}]")

    for t in OPTIONAL:
        if t in present:
            n = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            lo, hi = con.execute(f"SELECT MIN(ts), MAX(ts) FROM {t}").fetchone()
            print(f"  ok      {t:15s} {n:>9,} Zeilen  "
                  f"{utc(lo)} bis {utc(hi)}   (Kerzen-Modus)")
        else:
            print(f"  fehlt   {t} — nur fuer lange Kerzen-Tests noetig")

    # Einheiten, die aus dem Schema nicht hervorgehen
    print("\nWertebereiche, an denen Einheiten haengen:")
    if "proximity" in present:
        r = con.execute(
            "SELECT MIN(up_dist), MAX(up_dist), AVG(up_dist) FROM proximity "
            "WHERE coin=? AND up_dist IS NOT NULL", (a.coin,)).fetchone()
        if r and r[1] is not None:
            unit = "Prozent" if r[2] > 0.5 else "Anteil (0..1)"
            print(f"  proximity.up_dist  {r[0]:.4f} .. {r[1]:.4f} "
                  f"(Mittel {r[2]:.4f})  -> {unit}")
            if unit == "Prozent":
                print("     Hinweis: hl_botcore vergleicht up_dist mit einem "
                      "Anteil. Bei Prozent gehoert dort ein Faktor 100 hin.")
                warnings += 1
    if "coverage" in present:
        r = con.execute("SELECT AVG(ratio) FROM coverage WHERE coin=?",
                        (a.coin,)).fetchone()
        if r and r[0]:
            print(f"  coverage.ratio     Mittel {r[0]:.3f} "
                  f"-> {r[0]*100:.0f} % des Open Interest erfasst")
    if "snapshot_meta" in present:
        r = con.execute("SELECT AVG(age_p90), MAX(age_p90) FROM snapshot_meta"
                        ).fetchone()
        if r and r[0]:
            print(f"  snapshot_meta.age_p90  Mittel {r[0]:.0f}s, "
                  f"max {r[1]:.0f}s -> Alter der Positionen in der Heatmap")

    con.close()
    print(f"\n{problems} Fehler, {warnings} Hinweise")
    if problems:
        print("Bei fehlenden Spalten die Abfragen anpassen, bevor ein Lauf startet.")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
