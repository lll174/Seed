"""
hl_botcore.py — gemeinsame Kernschicht für Replay/Papierhandel und Live-Bot.

Zweck: Replay und Live benutzen DIESELBEN Funktionen. Alles, was der Bot über
den Markt weiß, kommt aus `features_at()`. Damit kann eine Simulation nichts
sehen, was live nicht auch verfügbar wäre.

Drei Bausteine:
  1. features_at()      — Zustand zum Zeitpunkt t, inklusive Datenalter
  2. CascadeMachine     — IDLE -> CLUSTER_NEAR -> RUNNING -> END
  3. simulate_fill()    — Market-Order gegen das echte Buch aus book_ticks

Lesend, read-only. Der Recorder bleibt alleiniger Schreiber.

    python hl_botcore.py --db hl_liq.db --coin BTC --replay
    python hl_botcore.py --db hl_liq.db --coin BTC --at 1757000000

ACHTUNG: gegen die Schemabeschreibung aus der Übergabe geschrieben, nicht
gegen die echte DB getestet. Spaltennamen bei erstem Lauf prüfen.
"""

from __future__ import annotations

import argparse
import json
import logging
import sqlite3
from dataclasses import dataclass, asdict
from enum import Enum

log = logging.getLogger("botcore")


def to_seconds(v) -> int:
    """
    tick_events fuehrt t_trigger/t_start/t_end in MILLISEKUNDEN, die
    Zeitreihen dagegen in Sekunden. Groessenordnung entscheidet, damit der
    Code auch dann stimmt, wenn eine Tabelle spaeter umgestellt wird.
    """
    v = int(v or 0)
    return v // 1000 if v > 100_000_000_000 else v


def connect_ro(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=5.0)
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------------------
# 1. Point-in-Time-Features
# ---------------------------------------------------------------------------


@dataclass
class Features:
    ts: int
    coin: str

    # ctx_bars
    mark_px: float | None = None
    mid_px: float | None = None
    funding: float | None = None
    oi: float | None = None

    # book_summary
    bid: float | None = None
    ask: float | None = None
    spread_bps: float | None = None
    bid_50: float | None = None
    ask_50: float | None = None
    imb_50: float | None = None

    # bars10, aggregiert über das Fenster
    n_liq_60s: int = 0
    liq_notional_60s: float = 0.0
    vol_buy_60s: float = 0.0
    vol_sell_60s: float = 0.0

    # proximity
    up_px: float | None = None
    up_notional: float | None = None
    up_dist: float | None = None
    dn_px: float | None = None
    dn_notional: float | None = None
    dn_dist: float | None = None

    # Kontext
    hourly_notional: float = 0.0

    # ---- Datenalter in Sekunden. Ohne diese Felder ist alles oben wertlos.
    age_ctx: float | None = None
    age_book: float | None = None
    age_proximity: float | None = None
    age_heatmap: float | None = None
    age_positions_p90: float | None = None

    def cluster_freshness(self) -> float | None:
        """
        Effektives Alter der Cluster-Aussage: Heatmap-Snapshot plus das Alter
        der Positionen, aus denen er gebaut wurde. Das ist die Zahl, die bei
        der Magnet-These wirklich zählt — nicht das Alter von `proximity`.
        """
        if self.age_heatmap is None:
            return None
        return self.age_heatmap + (self.age_positions_p90 or 0.0)

    def usable(self, max_book_age: float = 30.0, max_ctx_age: float = 120.0) -> bool:
        return (
            self.age_book is not None
            and self.age_book <= max_book_age
            and self.age_ctx is not None
            and self.age_ctx <= max_ctx_age
        )


_DIST_SCALE: dict = {}


def dist_scale(conn, coin: str) -> float:
    """
    proximity.up_dist/dn_dist koennen Prozent (0..5) oder Anteil (0..0.05)
    sein; im Schema steht die Einheit nicht. Die Abstaende sind laut Recorder
    auf 5 % begrenzt, also entscheidet die Groessenordnung eindeutig.
    Ergebnis wird je Coin einmal bestimmt und gemerkt.
    """
    if coin in _DIST_SCALE:
        return _DIST_SCALE[coin]
    scale = 1.0
    try:
        r = conn.execute(
            "SELECT MAX(up_dist), MAX(dn_dist) FROM proximity WHERE coin=?",
            (coin,)).fetchone()
        top = max((x or 0) for x in (r[0], r[1])) if r else 0
        scale = 0.01 if top > 0.06 else 1.0     # > 6 % waere kein Anteil mehr
    except sqlite3.Error:
        pass
    _DIST_SCALE[coin] = scale
    return scale


def _last_row(conn, table: str, coin: str, ts: int) -> sqlite3.Row | None:
    cur = conn.execute(
        f"SELECT * FROM {table} WHERE coin=? AND ts<=? ORDER BY ts DESC LIMIT 1",
        (coin, ts),
    )
    return cur.fetchone()


def features_at(conn: sqlite3.Connection, coin: str, ts: int) -> Features:
    """Alles, was zum Zeitpunkt ts bekannt gewesen wäre. Kein Blick nach vorn."""
    f = Features(ts=ts, coin=coin)

    if (r := _last_row(conn, "ctx_bars", coin, ts)) is not None:
        f.mark_px, f.mid_px = r["mark_px"], r["mid_px"]
        f.funding, f.oi = r["funding"], r["oi"]
        f.age_ctx = ts - r["ts"]

    if (r := _last_row(conn, "book_summary", coin, ts)) is not None:
        f.bid, f.ask, f.spread_bps = r["bid"], r["ask"], r["spread_bps"]
        f.bid_50, f.ask_50, f.imb_50 = r["bid_50"], r["ask_50"], r["imb_50"]
        f.age_book = ts - r["ts"]

    if (r := _last_row(conn, "proximity", coin, ts)) is not None:
        k = dist_scale(conn, coin)          # auf Anteil normieren
        f.up_px, f.up_notional = r["up_px"], r["up_notional"]
        f.dn_px, f.dn_notional = r["dn_px"], r["dn_notional"]
        f.up_dist = (r["up_dist"] or 0) * k
        f.dn_dist = (r["dn_dist"] or 0) * k
        f.age_proximity = ts - r["ts"]

    cur = conn.execute(
        "SELECT MAX(ts) AS t FROM heatmap WHERE coin=? AND ts<=?", (coin, ts)
    )
    if (row := cur.fetchone()) and row["t"]:
        f.age_heatmap = ts - row["t"]
        cur = conn.execute(
            "SELECT age_p90 FROM snapshot_meta WHERE ts<=? ORDER BY ts DESC LIMIT 1",
            (ts,),
        )
        if (m := cur.fetchone()) is not None:
            f.age_positions_p90 = m["age_p90"]

    cur = conn.execute(
        """SELECT COALESCE(SUM(n_liq),0) nl, COALESCE(SUM(liq_notional),0) ln,
                  COALESCE(SUM(vol_buy),0) vb, COALESCE(SUM(vol_sell),0) vs
           FROM bars10 WHERE coin=? AND ts<=? AND ts>?""",
        (coin, ts, ts - 60),
    )
    r = cur.fetchone()
    f.n_liq_60s, f.liq_notional_60s = int(r["nl"]), float(r["ln"])
    f.vol_buy_60s, f.vol_sell_60s = float(r["vb"]), float(r["vs"])

    cur = conn.execute(
        """SELECT COALESCE(SUM(volume*close),0) v FROM bars
           WHERE coin=? AND ts<=? AND ts>?""",
        (coin, ts, ts - 3600),
    )
    f.hourly_notional = float(cur.fetchone()["v"])
    return f


# ---------------------------------------------------------------------------
# 2. Zustandsmaschine
# ---------------------------------------------------------------------------


class State(str, Enum):
    IDLE = "IDLE"
    CLUSTER_NEAR = "CLUSTER_NEAR"
    RUNNING = "RUNNING"
    END = "END"


@dataclass
class MachineConfig:
    cluster_dist: float = 0.006        # 0,6 % Nähe zum Cluster
    cluster_size_ratio: float = 0.5    # Cluster >= 0,5 x Stundenvolumen
    quiet_bars: int = 3                # bars10 ohne Liquidation = Kaskade vorbei
    depth_recovery: float = 0.7        # bid_50 zurück auf 70 % des Vorwerts
    min_retrace: float = 0.003         # 0,3 % Abstand vom Extrem
    max_cluster_age: float = 900.0     # Cluster älter als 15 min: nicht handeln


@dataclass
class Transition:
    ts: int
    frm: State
    to: State
    reason: str
    features: dict


class CascadeMachine:
    """
    Wird sequenziell mit Features gefüttert (Replay wie Live identisch).
    Gibt Transition-Objekte zurück; jede enthält den vollen Featurestand,
    damit der Papierhandel jede Entscheidung nachvollziehbar protokolliert.
    """

    def __init__(self, cfg: MachineConfig | None = None):
        self.cfg = cfg or MachineConfig()
        self.state = State.IDLE
        self.quiet = 0
        self.depth_before: float | None = None
        self.extreme_px: float | None = None
        self.side: str | None = None   # "down" = Long-Kaskade, "up" = Squeeze
        self.entered_at: int | None = None

    def _big_cluster_near(self, f: Features) -> str | None:
        if not f.hourly_notional:
            return None
        thr = self.cfg.cluster_size_ratio * f.hourly_notional
        cands = []
        if f.dn_dist is not None and f.dn_notional and f.dn_notional >= thr:
            cands.append(("down", f.dn_dist))
        if f.up_dist is not None and f.up_notional and f.up_notional >= thr:
            cands.append(("up", f.up_dist))
        near = [(s, d) for s, d in cands if d <= self.cfg.cluster_dist]
        if not near:
            return None
        return min(near, key=lambda x: x[1])[0]

    def step(self, f: Features) -> Transition | None:
        prev = self.state
        px = f.mark_px or f.mid_px
        reason = ""

        if self.state in (State.IDLE, State.CLUSTER_NEAR):
            if f.n_liq_60s > 0:
                self.state = State.RUNNING
                self.quiet = 0
                self.depth_before = f.bid_50
                self.extreme_px = px
                self.side = self.side or self._big_cluster_near(f) or "down"
                reason = f"Liquidationen aktiv (n={f.n_liq_60s})"
            else:
                side = self._big_cluster_near(f)
                if side and self.state is State.IDLE:
                    self.state = State.CLUSTER_NEAR
                    self.side = side
                    self.depth_before = f.bid_50
                    reason = f"großes Cluster {side} in Reichweite"
                elif not side and self.state is State.CLUSTER_NEAR:
                    self.state = State.IDLE
                    self.side = None
                    reason = "Cluster außer Reichweite"

        elif self.state is State.RUNNING:
            if px is not None and self.extreme_px is not None:
                if self.side == "down":
                    self.extreme_px = min(self.extreme_px, px)
                else:
                    self.extreme_px = max(self.extreme_px, px)

            if f.n_liq_60s == 0:
                self.quiet += 1
            else:
                self.quiet = 0

            depth_ok = (
                self.depth_before is None
                or not self.depth_before
                or (f.bid_50 or 0) >= self.cfg.depth_recovery * self.depth_before
            )
            retrace_ok = (
                px is not None
                and self.extreme_px
                and abs(px - self.extreme_px) / self.extreme_px >= self.cfg.min_retrace
            )
            if self.quiet >= self.cfg.quiet_bars and depth_ok and retrace_ok:
                self.state = State.END
                self.entered_at = f.ts
                reason = (
                    f"Kaskade beendet: {self.quiet} ruhige Bars, "
                    f"Tiefe {(f.bid_50 or 0):.0f}/{self.depth_before:.0f}, "
                    f"Retrace {abs(px - self.extreme_px) / self.extreme_px:.4f}"
                )

        elif self.state is State.END:
            self.state = State.IDLE
            self.side = None
            self.extreme_px = None
            self.depth_before = None
            reason = "zurück in IDLE"

        if self.state is not prev:
            return Transition(f.ts, prev, self.state, reason, asdict(f))
        return None

    def entry_allowed(self, f: Features) -> tuple[bool, str]:
        """Handelsfreigabe getrennt von der Zustandserkennung."""
        if self.state is not State.END:
            return False, "keine abgeschlossene Kaskade"
        if not f.usable():
            return False, f"Daten zu alt (Buch {f.age_book}s, ctx {f.age_ctx}s)"
        age = f.cluster_freshness()
        if age is not None and age > self.cfg.max_cluster_age:
            return False, f"Cluster-Information {age:.0f}s alt"
        return True, "ok"


# ---------------------------------------------------------------------------
# 3. Füllpreis gegen das echte Buch
# ---------------------------------------------------------------------------


def simulate_fill(levels_json: str, is_buy: bool, size: float) -> dict:
    """
    Market-Order gegen einen book_ticks-Snapshot. levels = [[bids],[asks]],
    je Eintrag [px, sz]. Gibt Durchschnittspreis, gefüllte Menge und Slippage.
    In Kaskaden ist das Buch dünn — teilweise Füllung ist der Normalfall.
    """
    levels = json.loads(levels_json)
    bids, asks = levels[0], levels[1]
    side = sorted(asks, key=lambda x: float(x[0])) if is_buy else sorted(
        bids, key=lambda x: -float(x[0])
    )
    best = float(side[0][0]) if side else None

    remaining, cost, consumed = size, 0.0, 0
    for px, sz in side:
        px, sz = float(px), float(sz)
        take = min(remaining, sz)
        cost += take * px
        remaining -= take
        consumed += 1
        if remaining <= 1e-12:
            break

    filled = size - remaining
    avg = cost / filled if filled else None
    slip = None
    if avg is not None and best:
        slip = (avg - best) / best * (1 if is_buy else -1)
    return {
        "avg_px": avg,
        "filled": filled,
        "unfilled": remaining,
        "best_px": best,
        "slippage": slip,
        "levels_consumed": consumed,
        "book_exhausted": remaining > 1e-12,
    }


def book_at(conn: sqlite3.Connection, event_id: int, coin: str, ts_ms: int):
    cur = conn.execute(
        """SELECT levels, ts_ms FROM book_ticks
           WHERE event_id=? AND coin=? AND ts_ms<=? ORDER BY ts_ms DESC LIMIT 1""",
        (event_id, coin, ts_ms),
    )
    return cur.fetchone()


# ---------------------------------------------------------------------------
# Replay
# ---------------------------------------------------------------------------


def replay(conn: sqlite3.Connection, coin: str, cfg: MachineConfig | None = None):
    """
    Läuft über alle tick_events — Auslöser UND Kontrollfenster. Ohne die
    Kontrollgruppe kennt die Auswertung nur Treffer, nie Fehlalarme.
    """
    cur = conn.execute(
        """SELECT id, reason, t_start, t_end, t_trigger, n_liqs, move_pct
           FROM tick_events WHERE coin=? AND complete=1 ORDER BY t_start""",
        (coin,),
    )
    for ev in cur.fetchall():
        machine = CascadeMachine(cfg)
        out = []
        t_start, t_end = to_seconds(ev["t_start"]), to_seconds(ev["t_end"])
        t_trigger = to_seconds(ev["t_trigger"])
        for ts in range(t_start, t_end + 1, 10):
            f = features_at(conn, coin, ts)
            if (t := machine.step(f)) is not None:
                out.append(t)
                if t.to is State.END:
                    ok, why = machine.entry_allowed(f)
                    b = book_at(conn, ev["id"], coin, ts * 1000)
                    fill = simulate_fill(b["levels"], True, 0.01) if b else None
                    yield {
                        "event_id": ev["id"],
                        "reason": ev["reason"],
                        "is_control": ev["reason"] == "control",
                        "detected_at": ts,
                        "lag_s": ts - t_trigger,
                        "entry_allowed": ok,
                        "why": why,
                        "fill": fill,
                        "features": asdict(f),
                    }
        log.debug("event %s (%s): %d Übergänge", ev["id"], ev["reason"], len(out))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="hl_liq.db")
    p.add_argument("--coin", default="BTC")
    p.add_argument("--replay", action="store_true")
    p.add_argument("--at", type=int)
    a = p.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    conn = connect_ro(a.db)

    if a.at:
        f = features_at(conn, a.coin, a.at)
        print(json.dumps(asdict(f), indent=2))
        print("Cluster-Alter effektiv:", f.cluster_freshness(), "s")
        return

    if a.replay:
        hits = ctrl = 0
        for r in replay(conn, a.coin):
            hits += not r["is_control"]
            ctrl += r["is_control"]
            print(
                f"ev={r['event_id']:>5} {r['reason']:>9} lag={r['lag_s']:>4}s "
                f"entry={r['entry_allowed']} slip="
                f"{(r['fill'] or {}).get('slippage')} — {r['why']}"
            )
        print(f"\nErkennungen: {hits} auf Auslösern, {ctrl} auf Kontrollfenstern")
        print("Letztere sind die Fehlalarmquote. Wenn sie nicht deutlich")
        print("niedriger liegt, erkennt die Maschine nichts Spezifisches.")


if __name__ == "__main__":
    main()
