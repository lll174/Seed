"""
hl_simdash.py — Weboberfläche für die Handelssimulation, Port 8766.

    python hl_simdash.py --db hl_liq.db --host 0.0.0.0

Liest die Recorder-Datenbank nur lesend. Es werden keine echten Orders
gesendet; alle Käufe und Verkäufe sind simuliert.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from hl_sim import Engine, SimConfig, parse_time, utc
from hl_candles import CandleEngine, choose, discover, load_rows
from hl_optimize import optimise

VERSION = "2026-09-04l · Optimizer-Regime"
DB_PATH = "hl_liq.db"
RESULTS_DB = "hl_sim_results.db"


# ---------------------------------------------------------------------------
# Sitzung
# ---------------------------------------------------------------------------


class Session:
    def __init__(self):
        self.cfg = SimConfig()
        self.engine: Engine | None = None
        self.thread: threading.Thread | None = None
        self.mode = "idle"          # idle | backtest | live
        self.stop = threading.Event()
        self.error: str | None = None
        self.result: dict | None = None
        self.report: dict | None = None      # Ergebnis der Analyse
        self.opt_progress = 0.0
        self.opt_note = ""
        self.lock = threading.Lock()

    def busy(self) -> bool:
        return self.thread is not None and self.thread.is_alive()

    def _make_engine(self, kind: str = "full") -> Engine:
        cls = CandleEngine if kind == "candles" else Engine
        eng = cls(DB_PATH, self.cfg, RESULTS_DB or None)
        eng.conn = ro_conn()
        if kind == "candles":
            # Quellen auf der neuen Verbindung erneut bestimmen
            eng.sources = discover(eng.conn)
            eng.source = choose(eng.sources, self.cfg.candle_source, self.cfg.coin)
        return eng

    def start_backtest(self, t_from: int, t_to: int, kind: str = "full"):
        if self.busy():
            return {"error": "Es läuft bereits ein Durchgang."}
        self.stop.clear()
        self.error = self.result = None
        self.mode = "candles" if kind == "candles" else "backtest"

        def work():
            try:
                self.engine = self._make_engine(kind)
                self.result = self.engine.run_backtest(t_from, t_to)
            except Exception as e:                      # noqa: BLE001
                self.error = f"{type(e).__name__}: {e}"
            finally:
                self.mode = "idle"

        self.thread = threading.Thread(target=work, daemon=True)
        self.thread.start()
        return {"ok": True}

    def start_optimize(self, t_from: int, t_to: int, n: int = 16,
                       depth: str = "gruendlich"):
        if self.busy():
            return {"error": "Es läuft bereits ein Durchgang."}
        self.stop.clear()
        self.error = self.result = self.report = None
        self.opt_progress, self.opt_note = 0.0, "Analyse startet"
        self.mode = "analyse"

        def work():
            try:
                eng = CandleEngine(DB_PATH, self.cfg)
                eng.conn = ro_conn()
                eng.sources = discover(eng.conn)
                eng.source = choose(eng.sources, self.cfg.candle_source,
                                    self.cfg.coin)
                if not eng.source:
                    self.error = "Keine Kerzenquelle gefunden."
                    return
                rep = optimise(
                    eng, t_from, t_to, self.cfg, n, depth=depth,
                    on_progress=lambda p: setattr(self, "opt_progress", p),
                    on_note=lambda t: setattr(self, "opt_note", t))
                self.report = rep
                if rep.get("error"):
                    self.error = rep["error"]
                    return
                # Gefundene Werte übernehmen und damit rechnen
                self.cfg = SimConfig.from_dict(rep["chosen"]["config"])
                self.opt_note = "Simulation mit den gefundenen Werten"
                self.mode = "candles"
                self.engine = self._make_engine("candles")
                self.engine._log(
                    t_from, "info",
                    f"Zeitraum enthält die Trainingshälfte bis "
                    f"{utc(rep['split_ts'])}. Belastbar ist nur, was rechts "
                    f"der violetten Linie liegt.")
                self.result = self.engine.run_backtest(t_from, t_to)
            except Exception as e:                  # noqa: BLE001
                self.error = f"{type(e).__name__}: {e}"
            finally:
                self.mode = "idle"

        self.thread = threading.Thread(target=work, daemon=True)
        self.thread.start()
        return {"ok": True}

    def start_live(self):
        if self.busy():
            return {"error": "Es läuft bereits ein Durchgang."}
        self.stop.clear()
        self.error = self.result = None
        self.mode = "live"

        def work():
            try:
                self.engine = self._make_engine()
                self.engine.run_live(stop_flag=self.stop.is_set)
            except Exception as e:                      # noqa: BLE001
                self.error = f"{type(e).__name__}: {e}"
            finally:
                self.mode = "idle"

        self.thread = threading.Thread(target=work, daemon=True)
        self.thread.start()
        return {"ok": True}

    def halt(self):
        self.stop.set()
        if self.engine:
            self.engine.running = False
        return {"ok": True}


SESSION = Session()


def ro_conn() -> sqlite3.Connection:
    c = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True,
                        timeout=5.0, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


# ---------------------------------------------------------------------------
# Chartdaten
# ---------------------------------------------------------------------------


def daily_closes(conn, coin: str, t_from: int, t_to: int) -> dict:
    """Tagesschluesse day -> close, aus bars, aufgefuellt aus klines30/bnc_bars."""
    out: dict = {}
    for table in ("klines30", "klines", "bnc_bars", "bars"):    # feinste Quelle zuletzt = ueberschreibt
        try:
            cur = conn.execute(
                f"""SELECT ts/86400 AS d, close FROM {table} WHERE coin=? AND ts>=? AND ts<=?
                    AND ts IN (SELECT MAX(ts) FROM {table} WHERE coin=? AND ts>=? AND ts<=? GROUP BY ts/86400)""",
                (coin, t_from, t_to, coin, t_from, t_to))
            for r in cur.fetchall():
                out[int(r["d"])] = r["close"]
        except sqlite3.Error:
            continue
    return out


def chart_data(coin: str, t_from: int, t_to: int, agg_min: int,
               src: str = "bars") -> dict:
    """
    Die Kursquelle muss dieselbe sein, auf der die Simulation handelt.
    Im Kerzen-Modus ist das klines30 oder bnc_bars, nicht `bars` — sonst
    zeigt der Chart nichts, sobald der Cursor vor den Recorder-Start laeuft.
    """
    conn = ro_conn()
    step = agg_min * 60
    rows: list[tuple] = []
    used = "bars"

    if src == "candles":
        srcs = discover(conn)
        chosen = choose(srcs, SESSION.cfg.candle_source, coin)
        if chosen:
            used = chosen.table
            rows = load_rows(conn, chosen, coin, t_from, t_to)
    if not rows:
        used = "bars" if src != "candles" else used
        cur = conn.execute(
            """SELECT ts, open, high, low, close, volume FROM bars
               WHERE coin=? AND ts>=? AND ts<=? ORDER BY ts""",
            (coin, t_from, t_to))
        rows = [(r["ts"], r["open"], r["high"], r["low"], r["close"],
                 r["volume"] or 0) for r in cur.fetchall()]
        if src == "candles" and rows:
            used = "bars"

    buckets: dict[int, dict] = {}
    for ts, o, h, l, c, v in rows:
        k = (ts // step) * step
        b = buckets.get(k)
        if b is None:
            buckets[k] = {"ts": k, "o": o, "h": h, "l": l, "c": c, "v": v}
        else:
            b["h"] = max(b["h"], h)
            b["l"] = min(b["l"], l)
            b["c"] = c
            b["v"] += v
    candles = [buckets[k] for k in sorted(buckets)]

    # gleitende Durchschnitte auf Tagesbasis, je Kerze der Wert ihres Tages
    slow, fast = SESSION.cfg.ma_slow_days, SESSION.cfg.ma_fast_days
    dc = daily_closes(conn, coin, t_from - (slow + 5) * 86400, t_to)
    days = sorted(dc); closes = [dc[d] for d in days]
    idx = {d: i for i, d in enumerate(days)}
    def ma_at(day, w):
        i = idx.get(day)
        if i is None:
            # letzter bekannter Tag davor
            prev = [d for d in days if d <= day]
            if not prev: return None
            i = idx[prev[-1]]
        if i + 1 < w: return None
        return sum(closes[i - w + 1:i + 1]) / w
    for b in candles:
        d = b["ts"] // 86400
        b["ma_slow"] = ma_at(d, slow); b["ma_fast"] = ma_at(d, fast)

    cur = conn.execute(
        "SELECT MAX(ts) t FROM heatmap WHERE coin=? AND ts<=?", (coin, t_to))
    row = cur.fetchone()
    clusters = []
    snap = row["t"] if row else None
    if snap:
        cur = conn.execute(
            """SELECT bucket_px, side, notional FROM heatmap
               WHERE coin=? AND ts=? ORDER BY notional DESC LIMIT 60""",
            (coin, snap))
        clusters = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"candles": candles, "clusters": clusters, "from": t_from, "to": t_to,
            "source": used,
            "regime": {"buffer": SESSION.cfg.regime_buffer_pct,
                       "band": [SESSION.cfg.reserve_band_lo, SESSION.cfg.reserve_band_hi],
                       "overheat": SESSION.cfg.overheat_level_pct,
                       "slow": slow, "fast": fast},
            "cluster_ts": snap, "cluster_age_s": (t_to - snap) if snap else None}


# ---------------------------------------------------------------------------
# Feldbeschriftungen für das Formular
# ---------------------------------------------------------------------------

FIELDS = [
    ("Strategie", [
        ("strategy", "Strategie", "", [["regime", "Regime-Akkumulation (empfohlen)"],
                                       ["konfluenz", "Konfluenz / Leiter / Cluster"]]),
    ]),
    ("Regime-Akkumulation", [
        ("ma_slow_days", "Langsamer Durchschnitt (Regime)", "Tage"),
        ("regime_buffer_pct", "Regimewechsel ab Abstand zum MA200", "±%"),
        ("bear_tranches", "Baisse: Tranchen (Budget geteilt durch)", "", None, "bear_accumulate"),
        ("bear_gap_days", "Baisse: höchstens eine Tranche je", "Tage"),
        ("bear_dip_pct", "Baisse: nur bei Rücksetzer ab", "% vom 30d-Hoch"),
        ("bear_depth1_pct", "Tiefenstaffel: Tranche ×1 ab", "% unter MA200", None, "depth_ladder"),
        ("bear_depth2_pct", "Tiefenstaffel: Tranche ×2 ab", "% unter MA200"),
        ("bear_depth3_pct", "Tiefenstaffel: Tranche ×3 ab", "% unter MA200"),
        ("reserve_pct", "Bulle: Reserve zurückhalten", "% des Budgets", None, "reserve_buy"),
        ("reserve_band_lo", "Reserve nachlegen ab", "% über MA200"),
        ("reserve_band_hi", "Reserve nachlegen bis", "% über MA200"),
        ("reserve_dip_pct", "Reserve: nur bei Rücksetzer ab", "% vom 30d-Hoch"),
        ("reserve_gap_days", "Reserve: höchstens alle", "Tage"),
        ("reserve_tranche_pct", "Reserve: je Tranche", "% des Budgets"),
        ("regime_exit", "Regimebruch-Ausstieg (Versicherung)", "", [[1, "ja"], [0, "nein"]], "regime_exit"),
        ("regime_reentry_pct", "… Wiedereinstieg sofort mit", "% des Kapitals"),
        ("overheat_sell_pct", "Verkauf bei Überdehnung", "% des Bestands (0 = aus)", None, "overheat"),
        ("overheat_level_pct", "… ab Abstand zum MA200", "% (Analyse: 40–45)"),
        ("overheat_rebuy_pct", "… alles zurück bei Abstand zum MA200 unter", "%"),
    ]),
    ("Kapital", [
        ("budget_usd", "Einsatzsumme", "USD"),
        ("order_basis", "Tranche berechnen von", "",
         [["equity", "aktuellem Kontostand"], ["budget", "fester Einsatzsumme"]]),
        ("order_pct", "Tranche je Kauf (Konfluenz)", "% davon"),
        ("order_usd", "feste Tranche, falls oben 0", "USD"),
        ("min_order_usd", "Kleinste Order", "USD"),
        ("max_lots", "Einstiegsplätze (Konfluenz)", ""),
    ]),
    ("Einstieg (Konfluenz)", [
        ("entry_min_score", "Nötige Punkte (volle Daten)", "max. 7"),
        ("candles_min_score", "Nötige Punkte (Kerzen-Test)", "max. 4"),
        ("min_seconds_between_buys", "Mindestabstand zwischen Käufen", "s"),
        ("dip_buy_pct", "Nachkauf ab Rücksetzer", "%"),
        ("dip_confirm_seconds", "Wartezeit auf Bodenbestätigung", "s"),
        ("max_add_above_avg_pct", "Nachkauf höchstens über Einstand", "% (Baisse/unbekannt)"),
        ("add_above_avg_bull_pct", "Nachkauf höchstens über Einstand", "% (über dem MA)"),
        ("rsi_buy", "RSI-Schwelle für Kauf", "", None, "rsi"),
        ("rsi_grid_min", "Raster für RSI und FVG", "min"),
        ("fvg_near_pct", "FVG gilt als am Kurs bis", "%", None, "fvg"),
        ("book_imb_buy", "Buch-Imbalance für Kauf", "", None, "book"),
        ("funding_buy", "Funding-Schwelle für Kauf", "Rate/h", None, "funding"),
        ("whale_ratio", "Wal-Verhältnis long/short", "", None, "whales"),
        ("candles_pullback_pct", "Rücksetzer vom Hoch ab (Kerzen-Test)", "%", None, "pullback"),
        ("candles_trend_min", "Übergeordneter Trendhorizont", "min", None, "trend"),
    ]),
    ("Cluster und Verkauf (Konfluenz)", [
        ("cluster_big_ratio", "Cluster gilt als groß ab × Stundenvolumen", "", None, "cluster"),
        ("hold_for_cluster_pct", "Leiter aussetzen, wenn Cluster näher als", "%"),
        ("cluster_far_pct", "Cluster ignorieren ab Entfernung", "%"),
        ("cluster_band_pct", "Kurs gilt als im Cluster bis", "%"),
        ("max_cluster_age_s", "Cluster-Snapshot höchstens alt", "s"),
        ("cluster_zone_pct", "Zwei Cluster gelten als einer bis", "%"),
        ("cluster_cooldown_s", "Wartezeit zwischen Cluster-Verkäufen", "s"),
        ("ladder_rearm_factor", "Leiterstufe erneut ab × Positionsgröße", "", None, "ladder"),
        ("sell_into_cluster_pct", "Verkauf im Cluster", "%"),
        ("sell_on_squeeze_pct", "Verkauf beim Squeeze", "%"),
        ("rsi_sell", "RSI-Schwelle für Ausstieg", "", None, "trend_exit"),
    ]),
    ("Trend und Ausstieg (Konfluenz)", [
        ("ma_fast_days", "Schneller Durchschnitt", "Tage"),
        ("buy_requires_bull", "Unter dem langsamen MA nicht kaufen", "", [[1, "ja"], [0, "nein"]], "regime_filter"),
        ("exit_loss_pct", "Ausstieg, wenn Position im Verlust ab", "% (0 = aus)", None, "exit_loss"),
        ("exit_drawdown_pct", "Ausstieg, wenn Kurs unter Hoch seit Einstieg ab",
         "% (0 = aus)", None, "exit_drawdown"),
        ("exit_requires_bear", "Ausstieg nur unter dem langsamen MA", "", [[1, "ja"], [0, "nein"]]),
        ("exit_sell_pct", "Beim Ausstieg verkaufen", "% des Bestands"),
        ("reentry_bounce_pct", "Wiedereinstieg ab Erholung vom Tief", "%"),
        ("reentry_above_fast_ma", "Wiedereinstieg nur über dem schnellen MA", "", [[1, "ja"], [0, "nein"]]),
    ]),
    ("Absicherung (Konfluenz)", [
        ("crash_drop_pct", "Notausstieg bei Kursverlust", "%", None, "crash"),
        ("crash_window_s", "gemessen über", "s"),
        ("crash_sell_pct", "Notverkauf", "%"),
        ("depth_collapse_ratio", "Bid-Tiefe eingebrochen unter × Median", ""),
        ("stop_loss_pct", "Stop unter Einstand (0 = aus)", "%", None, "stop"),
        ("time_stop_hours", "Zeitstop (0 = aus)", "h"),
        ("reversal_min_horizons", "Negative Horizonte für Trendumkehr", ""),
    ]),
    ("Kerzen-Test", [
        ("candles_pullback_hours", "Hoch gemessen über", "h"),
        ("candles_slippage_bps", "Pauschale Slippage", "bps"),
    ]),
    ("Ausführung", [
        ("fee_bps_taker", "Taker-Gebühr", "bps"),
        ("step_seconds", "Backtest-Auflösung", "s"),
        ("live_poll_seconds", "Live-Takt", "s"),
    ]),
]

# Felder, die die Analyse als massgeblich ausgewiesen hat — im Dashboard lila
IMPORTANT = {"strategy", "ma_slow_days", "regime_buffer_pct", "bear_tranches", "bear_gap_days",
             "bear_dip_pct", "reserve_pct", "reserve_band_lo", "reserve_band_hi", "reserve_dip_pct"}


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


class Handler(BaseHTTPRequestHandler):
    server_version = "hl_simdash"

    def log_message(self, *a):  # ruhiges Log
        pass

    def _send(self, obj, code=200, ctype="application/json"):
        body = (obj if isinstance(obj, bytes)
                else json.dumps(obj, ensure_ascii=False).encode())
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            if u.path == "/":
                return self._send(PAGE.encode(), ctype="text/html")

            if u.path == "/api/config":
                return self._send({"config": SESSION.cfg.to_dict(),
                                   "fields": FIELDS, "version": VERSION,
                                   "important": sorted(IMPORTANT),
                                   "has_optimize": True})

            if u.path == "/api/range":
                eng = Engine(DB_PATH, SESSION.cfg)
                eng.conn = ro_conn()
                lo, hi = eng.usable_range()
                ce = CandleEngine(DB_PATH, SESSION.cfg)
                ce.conn = ro_conn()
                ce.sources = discover(ce.conn)
                ce.source = choose(ce.sources, SESSION.cfg.candle_source,
                                   SESSION.cfg.coin)
                clo, chi = ce.usable_range()
                return self._send({
                    "tables": eng.data_range(),
                    "full": {"from": lo, "to": hi,
                             "from_s": utc(lo) if lo else None,
                             "to_s": utc(hi) if hi else None},
                    "candles": {"from": clo, "to": chi,
                                "from_s": utc(clo) if clo else None,
                                "to_s": utc(chi) if chi else None,
                                **ce.source_info()},
                })

            if u.path == "/api/state":
                eng = SESSION.engine
                if not eng:
                    return self._send({
                        "mode": SESSION.mode, "empty": True,
                        "error": SESSION.error, "report": SESSION.report,
                        "opt_progress": round(SESSION.opt_progress, 3),
                        "opt_note": SESSION.opt_note,
                        "config": SESSION.cfg.to_dict()})
                with SESSION.lock:
                    return self._send({
                        "mode": SESSION.mode,
                        "progress": round(eng.progress, 3),
                        "cursor": eng.last_view.ts if eng.last_view else None,
                        "error": SESSION.error,
                        "result": SESSION.result,
                        "report": SESSION.report,
                        "opt_progress": round(SESSION.opt_progress, 3),
                        "opt_note": SESSION.opt_note,
                        "config": SESSION.cfg.to_dict(),
                        "summary": eng.summary(),
                        "lots": eng.lots_view(),
                        "marks": eng.marks[-500:],
                        "equity": eng.equity[-1500:],
                        "journal": eng.journal[-200:][::-1],
                        "note": (eng.last_view and {
                            "rsi": round(eng.last_view.rsi, 1)
                            if eng.last_view.rsi else None,
                            "cluster_age": eng.last_view.clusters.get("age_s"),
                            "imb": eng.last_view.f.imb_50,
                        }) or {},
                    })

            if u.path == "/api/chart":
                coin = q.get("coin", [SESSION.cfg.coin])[0]
                now = int(time.time())
                t_to = int(q.get("to", [now])[0])
                t_from = int(q.get("from", [t_to - 6 * 3600])[0])
                agg = int(q.get("agg", [5])[0])
                src = q.get("src", ["bars"])[0]
                return self._send(chart_data(coin, t_from, t_to, agg, src))

        except Exception as e:                          # noqa: BLE001
            return self._send({"error": f"{type(e).__name__}: {e}"}, 500)
        self._send({"error": "unbekannter Pfad"}, 404)

    def do_POST(self):
        u = urlparse(self.path)
        n = int(self.headers.get("Content-Length", 0))
        payload = json.loads(self.rfile.read(n) or b"{}")
        try:
            if u.path == "/api/config":
                SESSION.cfg = SimConfig.from_dict(payload)
                return self._send({"ok": True, "config": SESSION.cfg.to_dict()})

            if u.path == "/api/backtest":
                t_from = parse_time(str(payload.get("from", "2026-09-01")))
                t_to = parse_time(str(payload.get("to", "now")))
                kind = payload.get("kind", "full")
                return self._send(SESSION.start_backtest(t_from, t_to, kind))

            if u.path == "/api/optimize":
                t_from = parse_time(str(payload.get("from", "2023-09-01")))
                t_to = parse_time(str(payload.get("to", "now")))
                n = int(payload.get("candidates", 16))
                depth = payload.get("depth", "gruendlich")
                return self._send(
                    SESSION.start_optimize(t_from, t_to, n, depth))

            if u.path == "/api/live":
                return self._send(SESSION.start_live())

            if u.path == "/api/stop":
                return self._send(SESSION.halt())

        except Exception as e:                          # noqa: BLE001
            return self._send({"error": f"{type(e).__name__}: {e}"}, 500)
        self._send({"error": "unbekannter Pfad"}, 404)


# ---------------------------------------------------------------------------
# Oberfläche
# ---------------------------------------------------------------------------

PAGE = r"""<!doctype html>
<html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Handelssimulation — Liquidationscluster</title>
<style>
:root{
  --ground:#131a20; --panel:#1c242c; --panel2:#222c35; --rule:#2c3742;
  --text:#d6dee6; --muted:#7e8c99;
  --up:#3e9e8c; --down:#c0604e;
  --short:#e0a33e; --long:#8c6fd1;
  --buy:#4fb89c; --sell:#d96c8a;
}
*{box-sizing:border-box}
body{margin:0;background:var(--ground);color:var(--text);
  font:14px/1.5 ui-sans-serif,system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.num{font-variant-numeric:tabular-nums}
header{display:flex;gap:18px;align-items:baseline;flex-wrap:wrap;
  padding:14px 20px;border-bottom:1px solid var(--rule);background:var(--panel)}
header h1{font-size:16px;font-weight:600;margin:0;letter-spacing:.01em}
header .sub{color:var(--muted);font-size:12.5px}
header .spacer{flex:1}
.stat{display:flex;flex-direction:column}
.stat b{font-size:19px;font-weight:600;font-variant-numeric:tabular-nums}
.stat span{font-size:11.5px;color:var(--muted)}
.pos{color:var(--up)} .neg{color:var(--down)}
main{display:grid;grid-template-columns:290px 1fr 300px;gap:1px;
  background:var(--rule);min-height:calc(100vh - 58px)}
section{background:var(--ground);padding:16px 18px;overflow:auto}
h2{font-size:12.5px;font-weight:600;color:var(--muted);margin:0 0 10px}
fieldset{border:none;border-top:1px solid var(--rule);margin:0 0 14px;padding:12px 0 0}
legend{display:none}
.grp{font-size:12px;color:var(--muted);margin:14px 0 8px}
label{display:flex;justify-content:space-between;align-items:center;gap:10px;
  margin-bottom:7px;font-size:12.5px}
label span{flex:1;color:var(--text)}
label em{color:var(--muted);font-style:normal;font-size:11px}
input,select{background:var(--panel2);border:1px solid var(--rule);color:var(--text);
  border-radius:3px;padding:5px 7px;width:88px;text-align:right;
  font:inherit;font-variant-numeric:tabular-nums}
input:focus,select:focus{outline:2px solid var(--short);outline-offset:1px}
input.wide{width:130px;text-align:left}
button{background:var(--panel2);border:1px solid var(--rule);color:var(--text);
  border-radius:3px;padding:7px 13px;font:inherit;cursor:pointer}
button:hover{background:#2a3540}
button.go{background:var(--up);border-color:var(--up);color:#0d1613;font-weight:600}
button.halt{background:var(--down);border-color:var(--down);color:#1a0f0c}
button:disabled{opacity:.45;cursor:default}
.row{display:flex;gap:8px;align-items:center;margin-bottom:9px;flex-wrap:wrap}
canvas{width:100%;display:block;border:1px solid var(--rule);border-radius:3px;
  background:var(--panel)}
table{width:100%;border-collapse:collapse;font-size:12px}
th{text-align:left;font-weight:500;color:var(--muted);padding:5px 6px;
  border-bottom:1px solid var(--rule);position:sticky;top:0;background:var(--ground)}
td{padding:5px 6px;border-bottom:1px solid #232c34;font-variant-numeric:tabular-nums}
td.r,th.r{text-align:right}
.tag{display:inline-block;width:15px;height:15px;line-height:15px;text-align:center;
  border-radius:2px;font-size:10px;font-weight:700;color:#101820}
.tag.b{background:var(--buy)} .tag.s{background:var(--sell)}
.report{margin-top:16px;border-top:1px solid var(--rule);padding-top:14px}
.report h3{font-size:13px;font-weight:600;margin:0 0 8px}
.report .why{font-size:12px;color:var(--muted);margin-bottom:4px}
.report .why b{color:var(--text);font-weight:600;font-variant-numeric:tabular-nums}
.report table{margin:10px 0 14px}
.report .bench{background:var(--panel2);border-left:2px solid var(--short);
  padding:9px 12px;margin:10px 0;font-size:12.5px;border-radius:0 3px 3px 0}
.jrn{max-height:240px;overflow:auto;font-size:12px}
.jrn div{padding:5px 0;border-bottom:1px solid #232c34;display:flex;gap:9px}
.jrn time{color:var(--muted);white-space:nowrap;font-variant-numeric:tabular-nums}
.ladder input{width:64px}
.hint{color:var(--muted);font-size:11.5px;margin:6px 0 12px}
label.imp{border-left:3px solid var(--long);padding-left:8px;margin-left:-11px}
label.imp span{color:#b9a6ee;font-weight:600}
label.off span{color:var(--muted);text-decoration:line-through}
label.off input[type=number],label.off select{opacity:.4}
label input[type=checkbox]{width:auto;margin:0 6px 0 0;accent-color:var(--long)}
.grp.imp{color:#b9a6ee}
.legend{font-size:11.5px;color:var(--muted);margin:6px 0 12px}
.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:4px;vertical-align:-1px}
.follow{display:flex;align-items:center;gap:6px;font-size:12.5px;
  color:var(--muted);margin:0}
.follow input{width:auto;margin:0}
.follow span{flex:0 0 auto}
.bar{height:3px;background:var(--panel2);border-radius:2px;overflow:hidden;margin:8px 0}
.bar i{display:block;height:100%;background:var(--short);width:0}
@media(max-width:1100px){main{grid-template-columns:1fr}}
</style></head><body>

<header>
  <div><h1>Handelssimulation <span id="ver" class="sub"></span></h1>
    <div class="sub" id="range">Datenbereich wird geladen …</div></div>
  <div class="spacer"></div>
  <div class="stat"><b id="s-equity" class="num">—</b><span>Kontostand</span></div>
  <div class="stat"><b id="s-deployed" class="num">—</b><span>eingesetzt</span></div>
  <div class="stat"><b id="s-cash" class="num">—</b><span>frei</span></div>
  <div class="stat"><b id="s-real" class="num">—</b><span>realisiert</span></div>
  <div class="stat"><b id="s-unreal" class="num">—</b><span>offen</span></div>
  <div class="stat"><b id="s-trades" class="num">—</b><span>Käufe / Verkäufe</span></div>
  <div class="stat"><b id="s-fees" class="num">—</b><span>Gebühren</span></div>
</header>

<main>
<section>
  <h2>Parameter</h2>
  <div class="row">
    <select id="mode">
      <option value="candles">Kerzen-Test — nur Chartdaten</option>
      <option value="full">Volle Daten — mit Clustern und Buch</option>
      <option value="live">Live mitlaufen</option>
    </select>
  </div>
  <div class="row" id="daterow">
    <input class="wide" id="t-from" value="2026-09-01">
    <input class="wide" id="t-to" value="now">
  </div>
  <div class="row">
    <button class="go" id="run">Simulation starten</button>
    <button class="halt" id="stop">Anhalten</button>
  </div>
  <div class="row">
    <button id="opt">Zeitraum analysieren und optimieren</button>
  </div>
  <label><span>Varianten in der Suche</span>
    <input type="number" id="ncand" value="20" min="1" max="200"></label>
  <label><span>Umfang</span>
    <select id="depth" style="width:auto;text-align:left">
      <option value="gruendlich" selected>gründlich</option>
      <option value="schnell">schnell</option>
    </select></label>
  <div class="hint">Leitet Schwellen aus Tagesspanne, RSI-Verteilung und
    Rücksetzertiefe ab. „Gründlich" prüft zusätzlich mit Walk-Forward, trennt
    das Ergebnis nach Marktphasen und misst Empfindlichkeit, Kosten und
    Startdatum-Abhängigkeit — drei Jahre dauern damit einige Minuten.</div>
  <div class="bar"><i id="prog"></i></div>
  <div class="hint" id="msg"></div>

  <div class="grp">Verkaufsleiter</div>
  <div class="hint">Prozentwerte beziehen sich auf die Ausgangsposition, nicht
    auf den Restbestand. Die Leiter setzt aus, solange ein großes Short-Cluster
    nah über dem Kurs steht.</div>
  <div id="ladder" class="ladder"></div>
  <div class="row"><button id="ladder-add">Stufe hinzufügen</button>
    <span class="hint" id="runner" style="margin:0"></span></div>

  <div id="form"></div>
</section>

<section>
  <div class="row">
    <span class="sub" id="chart-note"></span>
    <div class="spacer" style="flex:1"></div>
    <select id="agg">
      <option value="1">1 min</option><option value="5">5 min</option>
      <option value="15">15 min</option><option value="30" selected>30 min</option>
      <option value="60">1 h</option><option value="240">4 h</option>
      <option value="1440">1 Tag</option>
    </select>
    <select id="span">
      <option value="6">6 h</option><option value="24">24 h</option>
      <option value="72">3 Tage</option><option value="168" selected>7 Tage</option>
      <option value="720">30 Tage</option><option value="2160">90 Tage</option>
      <option value="8760">1 Jahr</option>
    </select>
    <label class="follow"><input type="checkbox" id="follow" checked>
      <span>mitlaufen</span></label>
    <button id="jump" title="Zum aktuellen Zeitpunkt springen">jetzt</button>
  </div>
  <canvas id="chart" height="430"></canvas>
  <div id="report" class="report" hidden></div>
  <h2 style="margin-top:18px">Handelsprotokoll</h2>
  <div class="jrn" id="journal"></div>
</section>

<section>
  <h2>Offene Tranchen <span id="slots" style="float:right"></span></h2>
  <table id="lots"><thead><tr>
    <th>Zeit</th><th class="r">Kurs</th><th class="r">Tranche</th>
    <th class="r">Rest</th><th class="r">P/L</th>
  </tr></thead><tbody></tbody></table>
  <h2 style="margin-top:20px">Abgeschlossen</h2>
  <table id="closed"><thead><tr>
    <th></th><th>Zeit</th><th class="r">Kurs</th><th class="r">Ergebnis</th>
  </tr></thead><tbody></tbody></table>
</section>
</main>

<script>
const $ = s => document.querySelector(s);
let CFG = {}, FIELDS = [], MARKS = [], CHART = null, IMPORTANT = new Set();

const fmtUsd = v => (v==null?'—':(v<0?'-':'')+'$'+Math.abs(v).toLocaleString('de-DE',
  {minimumFractionDigits:2,maximumFractionDigits:2}));
const fmtPx = v => v==null?'—':v.toLocaleString('de-DE',{maximumFractionDigits:0});
const hhmm = ts => new Date(ts*1000).toLocaleTimeString('de-DE',
  {hour:'2-digit',minute:'2-digit'});
const stamp = (ts, span) => span > 36*3600
  ? new Date(ts*1000).toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'})
  : hhmm(ts);
const sign = (el,v) => {el.className = 'num ' + (v>0?'pos':v<0?'neg':'')};

// ---------- Formular ----------
function buildForm(){
  const box = $('#form'); box.innerHTML = '';
  const off = new Set(CFG.disabled || []);
  const legend = document.createElement('div'); legend.className='legend';
  legend.innerHTML = '<i style="background:var(--long)"></i>lila = von der Analyse '
    + 'als maßgeblich ausgewiesen · Häkchen weg = Regel abgeschaltet';
  box.appendChild(legend);
  for (const [group, items] of FIELDS){
    const g = document.createElement('div');
    g.className = 'grp' + (group.startsWith('Regime') ? ' imp' : '');
    g.textContent = group; box.appendChild(g);
    for (const item of items){
      const [key,label,unit,options,rule] = item;
      const l = document.createElement('label');
      if (IMPORTANT.has(key)) l.classList.add('imp');
      if (rule && off.has(rule)) l.classList.add('off');
      if (rule){
        const cb = document.createElement('input'); cb.type='checkbox';
        cb.checked = !off.has(rule); cb.title = 'Regel ' + rule + ' ein/aus';
        cb.addEventListener('change', ()=>{
          const d = new Set(CFG.disabled || []);
          if (cb.checked) d.delete(rule); else d.add(rule);
          CFG.disabled = [...d]; pushCfg(); buildForm(); });
        l.appendChild(cb);
      }
      const sp = document.createElement('span');
      sp.innerHTML = `${label}${unit?` <em>${unit}</em>`:''}`; l.appendChild(sp);
      let i;
      if (options){
        i = document.createElement('select');
        i.style.width='auto'; i.style.textAlign='left';
        for (const [v,t] of options){
          const o = document.createElement('option');
          o.value = v; o.textContent = t; i.appendChild(o);
        }
        i.value = CFG[key];
        i.addEventListener('change', ()=>{
          CFG[key] = isNaN(+i.value) ? i.value : +i.value; pushCfg();
          if (key==='strategy') buildForm(); });
      } else {
        i = document.createElement('input');
        i.type='number'; i.step='any'; i.value = CFG[key];
        i.addEventListener('change', ()=>{
          CFG[key] = parseFloat(i.value); pushCfg(); });
      }
      if (rule && off.has(rule)) i.disabled = true;
      l.appendChild(i); box.appendChild(l);
    }
  }
}
function buildLadder(){
  const box = $('#ladder'); box.innerHTML='';
  (CFG.ladder||[]).forEach((st,ix)=>{
    const l = document.createElement('label');
    l.innerHTML = `<span>ab <em>%</em></span>`;
    const a = document.createElement('input'); a.type='number'; a.step='any';
    a.value = st.gain_pct;
    const b = document.createElement('input'); b.type='number'; b.step='any';
    b.value = st.sell_pct;
    const sp = document.createElement('span'); sp.innerHTML = 'verkaufe <em>%</em>';
    sp.style.flex='0 0 auto';
    a.onchange = ()=>{ CFG.ladder[ix].gain_pct = parseFloat(a.value);
                       pushCfg(); buildLadder(); };
    b.onchange = ()=>{ CFG.ladder[ix].sell_pct = parseFloat(b.value);
                       pushCfg(); buildLadder(); };
    const del = document.createElement('button');
    del.textContent='×'; del.style.padding='2px 8px';
    del.onclick = ()=>{ CFG.ladder.splice(ix,1); pushCfg(); buildLadder(); };
    l.append(a, sp, b, del); box.appendChild(l);
  });
  const sold = (CFG.ladder||[]).reduce((s,x)=>s+(+x.sell_pct||0),0);
  const rest = 100 - sold;
  $('#runner').textContent = rest > 0
    ? `${rest.toFixed(0)} % laufen bis zur Trendumkehr weiter`
    : `Leiter verkauft ${sold.toFixed(0)} % — kein Rest für den Trendlauf`;
}
$('#ladder-add').onclick = ()=>{
  CFG.ladder.push({gain_pct:5, sell_pct:20}); pushCfg(); buildLadder(); };

async function pushCfg(){
  await fetch('/api/config',{method:'POST',
    headers:{'Content-Type':'application/json'}, body:JSON.stringify(CFG)});
}

// ---------- Steuerung ----------
let RANGE = null;
function applyRange(){
  const m = $('#mode').value;
  $('#daterow').style.display = m==='live' ? 'none' : 'flex';
  if (!RANGE) return;
  if (m === 'live'){
    $('#range').textContent = 'Live: der Bot folgt den Daten, '
      + 'die der Recorder gerade schreibt.';
    return;
  }
  const r = m==='candles' ? RANGE.candles : RANGE.full;
  if (!r || !r.from_s){
    $('#range').textContent = m==='candles'
      ? 'Keine Kerzentabelle gefunden.'
      : 'Keine vollständigen Daten gefunden.';
    return;
  }
  $('#range').textContent = (m==='candles'
      ? `Kerzenquelle ${r.chosen||'?'} · `
      : 'Cluster, Buch und Wale · ')
    + `${r.from_s} bis ${r.to_s} UTC`;
  $('#t-from').value = r.from_s.slice(0,10);
  $('#t-to').value = 'now';
}
$('#mode').onchange = applyRange;
$('#run').onclick = async () => {
  $('#msg').textContent = '';
  const kind = $('#mode').value, live = kind === 'live';
  const r = await fetch(live ? '/api/live' : '/api/backtest', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({from:$('#t-from').value, to:$('#t-to').value, kind})});
  const j = await r.json();
  if (j.error) { $('#msg').textContent = j.error; return; }
  RUNMODE = kind === 'live' ? 'live' : kind;
  CHART = null;                      // Fenster neu aufbauen, Quelle wechselt
  $('#follow').checked = true;
};
$('#stop').onclick = () => fetch('/api/stop',{method:'POST'});
$('#opt').onclick = async () => {
  $('#msg').textContent = 'Analyse läuft — die Marktsicht wird einmal berechnet.';
  $('#report').hidden = true; REPORTED = false;
  const r = await fetch('/api/optimize', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({from:$('#t-from').value, to:$('#t-to').value,
                          candidates: parseInt($('#ncand').value)||20,
                          depth: $('#depth').value})});
  const j = await r.json();
  if (j.error) { $('#msg').textContent = j.error; return; }
  RUNMODE = 'candles'; CHART = null; $('#follow').checked = true;
};

const pct = v => (v==null ? '—' : (v>0?'+':'') + v.toFixed(2) + ' %');

function sectWalk(w){
  if (!w || w.error) return '';
  const rows = (w.folds||[]).map(f => '<tr>'
    + '<td>' + new Date(f.von*1000).toLocaleDateString('de-DE') + '</td>'
    + '<td class="r ' + (f.bot>0?'pos':'neg') + '">' + pct(f.bot) + '</td>'
    + '<td class="r">' + pct(f.sparplan) + '</td>'
    + '<td class="r ' + (f.diff>0?'pos':'neg') + '">' + pct(f.diff) + '</td>'
    + '<td class="r">' + f.dd.toFixed(0) + ' %</td>'
    + '<td class="r">' + f.kaeufe + '</td></tr>').join('');
  const verdict = w.anteil_besser >= 55
    ? 'Der Vorsprung ist über die Fenster hinweg beständig.'
    : 'Kein beständiger Vorsprung — die Signallogik trägt sich hier nicht.';
  return '<h3>Walk-Forward</h3>'
    + '<div class="why">' + w.n_folds + ' Prüffenster à ' + w.test_days
      + ' Tage, jeweils kalibriert auf den ' + w.train_days
      + ' Tagen davor. Jede Zahl liegt außerhalb der Daten, auf denen '
      + 'gewählt wurde.</div>'
    + '<div class="bench">Median gegenüber Sparplan <b>' + pct(w.median_diff)
      + '</b> · <b>' + w.anteil_besser + ' %</b> der Fenster besser · '
      + 'kumuliert Bot <b>' + pct(w.kumuliert_bot) + '</b> gegen Sparplan <b>'
      + pct(w.kumuliert_sparplan) + '</b> · schlechtestes Fenster <b>'
      + pct(w.schlechtestes_fenster) + '</b>. ' + verdict + '</div>'
    + '<table><thead><tr><th>Prüffenster ab</th><th class="r">Bot</th>'
      + '<th class="r">Sparplan</th><th class="r">Differenz</th>'
      + '<th class="r">Rückgang</th><th class="r">Käufe</th></tr></thead>'
      + '<tbody>' + rows + '</tbody></table>';
}

function sectRegime(g){
  if (!g || !g.fenster) return '';
  const lab = {auf:'Aufwärts', ab:'Abwärts', seit:'Seitwärts'};
  const rows = ['auf','ab','seit'].map(k => '<tr><td>' + lab[k] + '</td>'
    + '<td class="r">' + (g[k]?g[k].n:0) + '</td>'
    + '<td class="r ' + ((g[k]&&g[k].median_vs_sparplan>0)?'pos':'neg') + '">'
    + (g[k] && g[k].median_vs_sparplan!=null
       ? pct(g[k].median_vs_sparplan) : '—') + '</td></tr>').join('');
  return '<h3>Nach Marktphase</h3>'
    + '<div class="why">' + g.tage_je_fenster + '-Tage-Fenster, jeweils nach '
      + 'eigener Marktbewegung eingeordnet und gegen den Sparplan im selben '
      + 'Fenster gemessen. Beschreibend über den ganzen Zeitraum, enthält '
      + 'also auch die Trainingshälfte.</div>'
    + '<table><thead><tr><th>Phase</th><th class="r">Fenster</th>'
      + '<th class="r">Median gegen Sparplan</th></tr></thead><tbody>'
      + rows + '</tbody></table>';
}

function sectSens(list){
  if (!list || !list.length) return '';
  const rows = list.map(x => '<tr><td>' + x.param + '</td>'
    + '<td class="r">' + pct(x.minus20) + '</td>'
    + '<td class="r">' + pct(x.plus20) + '</td>'
    + '<td class="r">' + x.spanne.toFixed(1) + '</td></tr>').join('');
  const worst = list[0];
  return '<h3>Empfindlichkeit</h3>'
    + '<div class="why">Jeder Wert einzeln um ±20 % verschoben. Große Spanne '
      + 'heißt: das Ergebnis hängt an diesem Wert, ist also eher an die '
      + 'Stichprobe angepasst als robust. Hier am stärksten: <b>'
      + worst.param + '</b> mit ' + worst.spanne.toFixed(1)
      + ' Prozentpunkten.</div>'
    + '<table><thead><tr><th>Wert</th><th class="r">−20 %</th>'
      + '<th class="r">+20 %</th><th class="r">Spanne</th></tr></thead>'
      + '<tbody>' + rows + '</tbody></table>';
}

function sectCost(list){
  if (!list || !list.length) return '';
  const rows = list.map(c => '<tr><td>' + c.fall + '</td>'
    + '<td class="r">' + c.gebuehr_bps + ' bps</td>'
    + '<td class="r">' + c.slippage_bps + ' bps</td>'
    + '<td class="r ' + (c.return_pct>0?'pos':'neg') + '">'
    + pct(c.return_pct) + '</td></tr>').join('');
  return '<h3>Kosten</h3><table><thead><tr><th>Fall</th>'
    + '<th class="r">Gebühr</th><th class="r">Slippage</th>'
    + '<th class="r">Ergebnis</th></tr></thead><tbody>' + rows
    + '</tbody></table>';
}

function sectStarts(s){
  if (!s || !s.laeufe) return '';
  return '<h3>Startdatum</h3>'
    + '<div class="why">' + s.laeufe.length + ' verschobene Startpunkte, je '
      + s.fenster_tage + ' Tage, gleiche Werte. Hängt das Ergebnis am '
      + 'Startmonat, ist es Zufall.</div>'
    + '<div class="bench">Median gegen Sparplan <b>'
      + pct(s.median_vs_sparplan) + '</b> · Spanne von <b>'
      + pct(s.schlechtester) + '</b> bis <b>' + pct(s.bester) + '</b> · <b>'
      + s.anteil_besser + ' %</b> der Startpunkte besser als der Sparplan.</div>';
}

function renderReport(rep){
  const box = $('#report');
  if (!rep || rep.error){ box.hidden = true; return; }
  const st = rep.stats || {}, ch = rep.chosen || {};
  const rows = (rep.candidates||[]).map(c => '<tr>'
    + '<td>' + c.kandidat + (c.kandidat===ch.kandidat ? ' \u2713' : '')
    + (c.kandidat===ch.kandidat ? '' : ' <span class="sub">(nur zur Einsicht)</span>')
    + '</td>'
    + '<td class="r ' + (c.train.return_pct>0?'pos':'neg') + '">'
      + pct(c.train.return_pct) + '</td>'
    + '<td class="r ' + (c.holdout.return_pct>0?'pos':'neg') + '">'
      + pct(c.holdout.return_pct) + '</td>'
    + '<td class="r">' + c.holdout.fees_pct_budget.toFixed(1) + ' %</td>'
    + '<td class="r">' + c.holdout.n_buys + '</td>'
    + '<td class="r">' + (c.holdout.hit_rate==null ? '—' : c.holdout.hit_rate+' %')
    + '</td></tr>').join('');

  const why = (rep.reasons||[]).map(w => {
    const val = Array.isArray(w.value)
      ? w.value.map(x => x.gain_pct + ' % \u2192 ' + x.sell_pct + ' %').join(' · ')
      : w.value + (w.unit ? ' ' + w.unit : '');
    return '<div class="why"><b>' + w.param + ' = ' + val + '</b> — '
         + w.reason + '</div>';
  }).join('');

  const beatDca = ch.holdout
    ? ch.holdout.return_pct - (rep.dca_holdout||0) : 0;
  const warn = beatDca < 0
    ? ' Die Strategie bleibt dahinter — dann sind die Parameter das kleinere '
      + 'Problem als die Grundannahme.'
    : '';
  box.hidden = false;
  box.innerHTML =
      '<h3>Analyse des Zeitraums</h3>'
    + '<div class="why">' + (st.n_candles||0).toLocaleString('de-DE')
      + ' Kerzen über ' + st.span_days + ' Tage · Tagesspanne im Median '
      + st.day_range_med + ' % (90. Perzentil ' + st.day_range_p90 + ' %)'
      + ' · RSI zwischen ' + st.rsi_p20 + ' und ' + st.rsi_p80
      + ' · Rücksetzer im Median ' + st.pullback_med + ' %</div>'
    + '<div class="bench">Maßstab auf der Prüfhälfte: Sparplan <b>'
      + pct(rep.dca_holdout) + '</b>, Kaufen-und-Halten <b>'
      + pct(rep.buyhold_holdout) + '</b>. Der gewählte Satz erreicht dort <b>'
      + pct(ch.holdout ? ch.holdout.return_pct : 0) + '</b>, also <b>'
      + pct(beatDca) + '</b> gegenüber dem Sparplan.' + warn
      + ' Der Sparplan ist der faire Vergleich — Kaufen-und-Halten setzt das '
      + 'gesamte Kapital sofort ein.</div>'
    + '<table><thead><tr><th>Satz</th><th class="r">Training</th>'
      + '<th class="r">Prüfhälfte</th><th class="r">Gebühren</th>'
      + '<th class="r">Käufe</th><th class="r">Treffer</th></tr></thead>'
      + '<tbody>' + rows + '</tbody></table>'
    + '<h3>Abgeleitete Werte</h3>' + why
    + '<div class="why" style="margin-top:10px">Gewählt wurde der beste Satz '
      + 'der <b>Trainingshälfte</b>; seine Zahl auf der Prüfhälfte ist damit '
      + 'unberührt von der Auswahl. Die beiden anderen stehen zur Einsicht '
      + 'daneben. Die Werte im Formular links sind bereits ersetzt.</div>'
    + sectWalk(rep.walk_forward) + sectRegime(rep.regimes)
    + sectSens(rep.sensitivity) + sectCost(rep.costs) + sectStarts(rep.starts);
}
$('#agg').onchange = $('#span').onchange = loadChart;

// ---------- Chart ----------
let CURSOR = null, POS = {}, loading = false, RUNMODE = null;
let REPORTED = false, SPLIT = null;
const follow = () => $('#follow').checked;

async function loadChart(anchor){
  if (loading) return;
  loading = true;
  try {
    const hours = parseInt($('#span').value), agg = parseInt($('#agg').value);
    const to = anchor || CURSOR || Math.floor(Date.now()/1000);
    const src = (RUNMODE === 'candles' || $('#mode').value === 'candles')
      ? 'candles' : 'bars';
    const r = await fetch(
      `/api/chart?from=${to - hours*3600}&to=${to}&agg=${agg}&src=${src}`);
    CHART = await r.json();
    draw();
  } finally { loading = false; }
}

// Nachladen, sobald der Simulationszeitpunkt aus dem geladenen Fenster
// herauslaeuft oder sich merklich darin bewegt hat.
function followCursor(){
  if (!follow() || !CURSOR) return false;
  const hours = parseInt($('#span').value);
  const to = (CHART && CHART.to) || 0;
  if (CURSOR > to || CURSOR < to - hours*3600 ||
      (CURSOR - to) > -1 || (to - CURSOR) > hours*3600*0.08) {
    loadChart(CURSOR);
    return true;
  }
  return false;
}

$('#jump').onclick = () => { $('#follow').checked = true; loadChart(CURSOR); };
function draw(){
  const cv = $('#chart'), ctx = cv.getContext('2d');
  const w = cv.width = cv.clientWidth * devicePixelRatio;
  const h = cv.height = 430 * devicePixelRatio;
  ctx.scale(1,1); ctx.clearRect(0,0,w,h);
  if(!CHART || !CHART.candles || !CHART.candles.length){
    ctx.fillStyle='#7e8c99'; ctx.font=`${13*devicePixelRatio}px sans-serif`;
    ctx.fillText('Keine Kursdaten in diesem Zeitraum.', 20*devicePixelRatio, 40);
    if (CHART && CHART.from) {
      const f = new Date(CHART.from*1000).toLocaleString('de-DE');
      const t = new Date(CHART.to*1000).toLocaleString('de-DE');
      ctx.fillText(`${f} – ${t}  (Quelle: ${CHART.source||'?'})`,
                   20*devicePixelRatio, 66*devicePixelRatio);
      $('#chart-note').textContent = `${f} – ${t} · keine Kerzen in dieser Quelle`;
    }
    return; }

  const cs = CHART.candles, padR = 108*devicePixelRatio, padB = 26*devicePixelRatio;
  const W = w - padR, H = h - padB;
  let lo = Math.min(...cs.map(c=>c.l)), hi = Math.max(...cs.map(c=>c.h));
  cs.forEach(c=>{ if(c.ma_slow){ lo=Math.min(lo,c.ma_slow*0.99); hi=Math.max(hi,c.ma_slow*1.01);} });
  (CHART.clusters||[]).forEach(c=>{ if(c.bucket_px>lo*0.97 && c.bucket_px<hi*1.03){
    lo=Math.min(lo,c.bucket_px); hi=Math.max(hi,c.bucket_px);} });
  const pad = (hi-lo)*0.06; lo-=pad; hi+=pad;
  const t0 = cs[0].ts, t1 = cs[cs.length-1].ts || t0+1;
  const X = t => (t-t0)/(t1-t0||1)*W;
  const Y = p => H - (p-lo)/(hi-lo)*H;

  // Cluster als Dichtebalken am rechten Rand — das Kernbild dieses Systems
  const maxN = Math.max(1,...(CHART.clusters||[]).map(c=>c.notional));
  (CHART.clusters||[]).forEach(c=>{
    const y = Y(c.bucket_px); if(y<0||y>H) return;
    const bw = (c.notional/maxN) * (padR-14*devicePixelRatio);
    ctx.fillStyle = c.side==='short' ? 'rgba(224,163,62,.5)' : 'rgba(140,111,209,.5)';
    ctx.fillRect(W+6*devicePixelRatio, y-2*devicePixelRatio, bw, 4*devicePixelRatio);
  });

  // Kerzen
  const cw = Math.max(1.5*devicePixelRatio, W/cs.length*0.62);
  cs.forEach(c=>{
    const x = X(c.ts), up = c.c>=c.o;
    ctx.strokeStyle = ctx.fillStyle = up ? '#3e9e8c' : '#c0604e';
    ctx.lineWidth = Math.max(1, devicePixelRatio);
    ctx.beginPath(); ctx.moveTo(x, Y(c.h)); ctx.lineTo(x, Y(c.l)); ctx.stroke();
    const yo=Y(c.o), yc=Y(c.c);
    ctx.fillRect(x-cw/2, Math.min(yo,yc), cw, Math.max(1.5,Math.abs(yc-yo)));
  });

  // Preisachse
  ctx.font = `${11*devicePixelRatio}px ui-monospace,monospace`;
  ctx.fillStyle = '#7e8c99'; ctx.textAlign='left';
  for(let i=0;i<=4;i++){
    const p = lo + (hi-lo)*i/4, y = Y(p);
    ctx.strokeStyle='#232c34'; ctx.beginPath();
    ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke();
    ctx.fillText(fmtPx(p), W+6*devicePixelRatio, y-4*devicePixelRatio);
  }
  // Zeitachse
  ctx.textAlign='center';
  for(let i=0;i<=5;i++){
    const t = t0 + (t1-t0)*i/5;
    ctx.fillText(stamp(t, t1-t0), X(t), H+17*devicePixelRatio);
  }

  const dpr = devicePixelRatio;
  // --- Regime in Lila: MA200, Reserveband, Ueberdehnung; MA50 duenn grau
  const rg = CHART.regime || {buffer:3, band:[0,5], overheat:40};
  const withMa = cs.filter(c => c.ma_slow);
  if (withMa.length > 1) {
    // Reserveband 0..5 % ueber MA200
    ctx.fillStyle = 'rgba(140,111,209,.18)';
    ctx.beginPath();
    withMa.forEach((c,k)=>{ const y=Y(c.ma_slow*(1+rg.band[1]/100)); k?ctx.lineTo(X(c.ts),y):ctx.moveTo(X(c.ts),y); });
    [...withMa].reverse().forEach(c=>ctx.lineTo(X(c.ts), Y(c.ma_slow*(1+rg.band[0]/100))));
    ctx.closePath(); ctx.fill();
    // Regime-Puffer als schmales Band um den MA200
    ctx.fillStyle = 'rgba(140,111,209,.10)';
    ctx.beginPath();
    withMa.forEach((c,k)=>{ const y=Y(c.ma_slow*(1+rg.buffer/100)); k?ctx.lineTo(X(c.ts),y):ctx.moveTo(X(c.ts),y); });
    [...withMa].reverse().forEach(c=>ctx.lineTo(X(c.ts), Y(c.ma_slow*(1-rg.buffer/100))));
    ctx.closePath(); ctx.fill();
    const poly = (fn, color, width, dash) => {
      ctx.save(); ctx.strokeStyle=color; ctx.lineWidth=width*dpr; if (dash) ctx.setLineDash(dash.map(v=>v*dpr));
      ctx.beginPath(); withMa.forEach((c,k)=>{ const y=Y(fn(c)); k?ctx.lineTo(X(c.ts),y):ctx.moveTo(X(c.ts),y); });
      ctx.stroke(); ctx.restore(); };
    poly(c=>c.ma_slow, '#8c6fd1', 2);                              // MA200
    poly(c=>c.ma_slow*(1+rg.overheat/100), '#8c6fd1', 1, [3,5]);   // +40 % Ueberdehnung
    const last = withMa[withMa.length-1];
    ctx.fillStyle='#b9a6ee'; ctx.textAlign='left'; ctx.font=`${11*dpr}px ui-monospace,monospace`;
    const yS=Y(last.ma_slow); if (yS>0 && yS<H) ctx.fillText('MA'+(rg.slow||200)+' '+fmtPx(last.ma_slow), 5*dpr, yS-5*dpr);
    const yO=Y(last.ma_slow*(1+rg.overheat/100)); if (yO>0 && yO<H) ctx.fillText('MA'+(rg.slow||200)+' +'+rg.overheat+' % Überdehnung', 5*dpr, yO-5*dpr);
    const yB=Y(last.ma_slow*(1+rg.band[1]/100)); if (yB>0 && yB<H) ctx.fillText('Reserveband '+rg.band[0]+'–'+rg.band[1]+' %', 5*dpr, yB-5*dpr);
  }
  const withF = cs.filter(c => c.ma_fast);
  if (withF.length > 1) {
    ctx.save(); ctx.strokeStyle='rgba(126,140,153,.7)'; ctx.lineWidth=Math.max(1,dpr);
    ctx.beginPath(); withF.forEach((c,k)=>{ const y=Y(c.ma_fast); k?ctx.lineTo(X(c.ts),y):ctx.moveTo(X(c.ts),y); });
    ctx.stroke(); ctx.restore();
  }
  // Einstand und laufender Kurs als Orientierung im Bild
  const line = (p, color, label) => {
    if (!p) return;
    const y = Y(p); if (y < 0 || y > H) return;
    ctx.save();
    ctx.setLineDash([5*dpr, 5*dpr]);
    ctx.strokeStyle = color; ctx.lineWidth = Math.max(1, dpr);
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    ctx.restore();
    ctx.font = `${11*dpr}px ui-monospace,monospace`;
    ctx.textAlign = 'left'; ctx.fillStyle = color;
    ctx.fillText(`${label} ${fmtPx(p)}`, 5*dpr, y - 5*dpr);
  };
  if (POS.size > 0) line(POS.avg, '#7e8c99', 'Einstand');
  line(POS.px, '#d6dee6', 'Kurs');

  // Grenze zwischen Trainings- und Prüfhälfte der letzten Analyse
  if (SPLIT && SPLIT >= t0 && SPLIT <= t1) {
    const x = X(SPLIT);
    ctx.save(); ctx.setLineDash([3*dpr, 6*dpr]);
    ctx.strokeStyle = 'rgba(140,111,209,.8)'; ctx.lineWidth = Math.max(1, dpr);
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    ctx.restore();
    ctx.fillStyle = '#8c6fd1'; ctx.textAlign = 'left';
    ctx.font = `${11*dpr}px ui-monospace,monospace`;
    ctx.fillText('Prüfhälfte ab hier \u2192', x + 5*dpr, 13*dpr);
  }

  // Zeitcursor: wo die Simulation gerade steht
  if (CURSOR && CURSOR >= t0 && CURSOR <= t1) {
    const x = X(CURSOR);
    ctx.strokeStyle = 'rgba(224,163,62,.6)'; ctx.lineWidth = Math.max(1, dpr);
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    ctx.fillStyle = '#e0a33e'; ctx.textAlign = 'right';
    ctx.font = `${11*dpr}px ui-monospace,monospace`;
    ctx.fillText(hhmm(CURSOR), x - 5*dpr, 13*dpr);
  }

  // Kauf- und Verkaufsmarken
  MARKS.filter(m=>m.ts>=t0-300 && m.ts<=t1+300).forEach(m=>{
    const x = X(m.ts), y = Y(m.px), buy = m.side==='B';
    const r = 8*devicePixelRatio;
    ctx.fillStyle = buy ? '#4fb89c' : '#d96c8a';
    ctx.beginPath();
    ctx.arc(x, y + (buy? r*1.8 : -r*1.8), r, 0, 7); ctx.fill();
    ctx.fillStyle = '#101820'; ctx.textAlign='center';
    ctx.font = `700 ${10*devicePixelRatio}px sans-serif`;
    ctx.fillText(m.side, x, y + (buy? r*1.8+3.5*devicePixelRatio
                                    : -r*1.8+3.5*devicePixelRatio));
  });

  const d0 = new Date(t0*1000).toLocaleString('de-DE',
    {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
  const d1 = new Date(t1*1000).toLocaleString('de-DE',
    {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
  const cl = CHART.cluster_age_s!=null
    ? ` · Cluster-Snapshot ${Math.round(CHART.cluster_age_s/60)} min alt, `
      + `orange = Short darüber, violett = Long darunter` : '';
  $('#chart-note').textContent = `${d0} – ${d1} · ${CHART.source||''}`
    + (follow() ? ' · läuft mit' : ' · angehalten') + cl;
}

// ---------- Zustand ----------
async function tick(){
  const s = await (await fetch('/api/state')).json();
  if (s.report && s.report.split_ts) SPLIT = s.report.split_ts;
  if (s.report && !REPORTED){
    REPORTED = true; renderReport(s.report);
    if (s.config){ CFG = s.config; buildForm(); buildLadder(); }
  }
  if (s.mode === 'analyse'){
    $('#prog').style.width = ((s.opt_progress||0)*100) + '%';
    $('#msg').textContent = s.opt_note || 'Analyse läuft';
  }
  if (s.empty){
    if (s.error) $('#msg').textContent = s.error;
    else if (s.mode !== 'analyse')
      $('#msg').textContent = 'Noch kein Durchgang gestartet.';
    return; }
  $('#prog').style.width = ((s.progress||0)*100)+'%';
  if (s.error) $('#msg').textContent = s.error;
  else if (s.result && s.result.error) $('#msg').textContent = s.result.error;
  else if (s.result && s.result.clipped) $('#msg').textContent =
    'Zeitraum wurde auf die tatsächlich vorhandenen Daten beschnitten.';

  const q = s.summary || {};
  $('#s-equity').textContent = fmtUsd(q.equity);
  $('#s-deployed').textContent = q.deployed==null ? '—'
    : `${fmtUsd(q.deployed)} · ${(q.deployed_pct||0).toFixed(0)}%`;
  $('#s-cash').textContent = fmtUsd(q.cash);
  $('#s-real').textContent = fmtUsd(q.realized); sign($('#s-real'), q.realized);
  $('#s-unreal').textContent = fmtUsd(q.unrealized); sign($('#s-unreal'), q.unrealized);
  $('#s-trades').textContent = `${q.n_buys||0} / ${q.n_sells||0}`;
  $('#s-fees').textContent = q.fees==null ? '—'
    : `${fmtUsd(q.fees)} · ${(q.fees_pct_budget||0).toFixed(1)}%`;
  $('#s-fees').className = 'num ' + ((q.fees_pct_budget||0) > 10 ? 'neg' : '');

  MARKS = s.marks || [];
  if (s.mode && s.mode !== 'idle') RUNMODE = s.mode;
  CURSOR = s.cursor || (s.equity && s.equity.length
    ? s.equity[s.equity.length-1].ts : null);
  POS = {avg: q.avg_px, px: q.last_px, size: q.open_size};

  const lb = $('#lots tbody'); lb.innerHTML='';
  $('#slots').textContent = `${(s.lots||[]).length} / ${q.max_lots||'—'}`
    + (q.next_order ? ` · nächste ${fmtUsd(q.next_order)}` : ' · kein Kapital frei');
  (s.lots||[]).forEach(l=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${l.t.slice(11,16)}</td><td class="r">${fmtPx(l.px)}</td>
      <td class="r">${fmtUsd(l.usd0)}</td>
      <td class="r">${(l.rest_pct??100).toFixed(0)} %</td>
      <td class="r ${l.pnl>0?'pos':l.pnl<0?'neg':''}">${l.pnl_pct.toFixed(2)}%</td>`;
    lb.appendChild(tr);
  });

  const cb = $('#closed tbody'); cb.innerHTML='';
  MARKS.slice().reverse().filter(m=>m.side==='S').slice(0,25).forEach(m=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td><span class="tag s">S</span></td>
      <td>${hhmm(m.ts)}</td><td class="r">${fmtPx(m.px)}</td>
      <td class="r ${m.pnl>0?'pos':'neg'}">${fmtUsd(m.pnl)}</td>`;
    cb.appendChild(tr);
  });

  const j = $('#journal'); j.innerHTML='';
  (s.journal||[]).forEach(e=>{
    const d = document.createElement('div');
    const tag = e.kind==='buy' ? '<span class="tag b">B</span>'
              : e.kind==='sell' ? '<span class="tag s">S</span>' : '';
    d.innerHTML = `<time>${e.t.slice(5,16)}</time>${tag}<span>${e.text}</span>`;
    j.appendChild(d);
  });
  if (!followCursor()) draw();
}

(async function init(){
  const c = await (await fetch('/api/config')).json();
  CFG = c.config; FIELDS = c.fields; IMPORTANT = new Set(c.important||[]);
  buildForm(); buildLadder();
  $('#ver').textContent = c.version || '';
  if (!c.has_optimize) $('#opt').hidden = true;
  RANGE = await (await fetch('/api/range')).json();
  applyRange();
  await loadChart();
  setInterval(tick, 1500); tick();
})();
</script></body></html>
"""


def main() -> None:
    global DB_PATH, RESULTS_DB
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="hl_liq.db")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8766)
    p.add_argument("--results", default="hl_sim_results.db",
                   help="Datei fuer Trades und Protokoll ('' schaltet ab)")
    a = p.parse_args()
    DB_PATH = a.db
    RESULTS_DB = a.results
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    print(f"Handelssimulation {VERSION}")
    print(f"  http://{a.host}:{a.port}   DB: {DB_PATH}")
    print(f"  Datei: {__file__}")
    print("Simulation only — es werden keine echten Orders gesendet.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
