"""
hl_candles.py — Kerzen-Modus für die Handelssimulation.

Zweck: die Ein- und Ausstiegsmechanik über einen langen Zeitraum prüfen, ohne
Cluster-, Orderbuch- und Waldaten. Damit lässt sich trennen, was die
Chartlogik leistet und was die Liquidationsdaten hinzufügen — der Vergleich
der beiden Läufe ist die eigentliche Aussage.

Die Kerzenquelle wird zur Laufzeit erkannt, weil die Binance-Tabellen des
Recorders anders heißen und anders aufgebaut sein können als `bars`. Statt
Spaltennamen zu raten, liest das Modul `PRAGMA table_info` und ordnet zu.

    python hl_candles.py --db hl_liq.db --sources
    python hl_candles.py --db hl_liq.db --coin BTC --from 2026-08-05 --to now
"""

from __future__ import annotations

import argparse
import json
import logging
import sqlite3
from collections import deque
from dataclasses import dataclass, field

from hl_sim import (
    Decision, Engine, Features, SimConfig, State, Strategy, View,
    parse_time, rsi, utc,
)

log = logging.getLogger("candles")

CANDIDATE_TABLES = ["bars", "bnc_bars", "klines30", "klines", "candles"]

TIME_COLS = ["ts", "open_time", "time", "t", "ts_ms"]
SYMBOL_COLS = ["coin", "symbol", "pair"]
OHLCV = {
    "o": ["open", "o", "open_px"],
    "h": ["high", "h", "high_px"],
    "l": ["low", "l", "low_px"],
    "c": ["close", "c", "close_px"],
    "v": ["volume", "v", "vol", "base_volume"],
}


# ---------------------------------------------------------------------------
# Quellenerkennung
# ---------------------------------------------------------------------------


@dataclass
class Source:
    table: str
    time_col: str
    unit: str                 # "s" oder "ms"
    symbol_col: str | None
    cols: dict                # o/h/l/c/v -> Spaltenname
    rows: int = 0
    t_from: int | None = None
    t_to: int | None = None
    symbols: list = field(default_factory=list)

    def label(self) -> str:
        span = ""
        if self.t_from and self.t_to:
            span = f", {utc(self.t_from)[:10]} bis {utc(self.t_to)[:10]}"
        return f"{self.table} ({self.rows:,} Kerzen{span})"


def _pick(cands: list[str], have: set[str]) -> str | None:
    for c in cands:
        if c in have:
            return c
    return None


def discover(conn: sqlite3.Connection) -> list[Source]:
    names = {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    out = []
    for t in CANDIDATE_TABLES:
        if t not in names:
            continue
        have = {r[1] for r in conn.execute(f"PRAGMA table_info({t})")}
        tc = _pick(TIME_COLS, have)
        cols = {k: _pick(v, have) for k, v in OHLCV.items()}
        if not tc or not all(cols[k] for k in ("o", "h", "l", "c")):
            continue
        s = Source(
            table=t, time_col=tc,
            unit="ms" if tc.endswith("_ms") or tc == "open_time" else "s",
            symbol_col=_pick(SYMBOL_COLS, have), cols=cols,
        )
        r = conn.execute(
            f"SELECT COUNT(*), MIN({tc}), MAX({tc}) FROM {t}").fetchone()
        s.rows = r[0] or 0
        if s.rows:
            div = 1000 if s.unit == "ms" else 1
            s.t_from, s.t_to = int(r[1] // div), int(r[2] // div)
            # Heuristik nachziehen: Sekundenwerte über 1e11 sind Millisekunden
            if r[1] and r[1] > 1e11 and s.unit == "s":
                s.unit = "ms"
                s.t_from, s.t_to = int(r[1] // 1000), int(r[2] // 1000)
        if s.symbol_col:
            s.symbols = [x[0] for x in conn.execute(
                f"SELECT DISTINCT {s.symbol_col} FROM {t} LIMIT 40")]
        out.append(s)
    return out


def choose(sources: list[Source], want: str, coin: str) -> Source | None:
    if not sources:
        return None
    if want != "auto":
        for s in sources:
            if s.table == want:
                return s
        return None
    usable = [s for s in sources if resolve_symbol(s, coin)]
    if not usable:
        return None
    # längste Historie gewinnt — darum geht es in diesem Modus
    return max(usable, key=lambda s: (s.t_to or 0) - (s.t_from or 0))


def resolve_symbol(s: Source, coin: str) -> str | None:
    if not s.symbol_col:
        return ""
    for cand in (coin, coin + "USDT", coin + "USD", coin + "-USD", coin + "/USDT"):
        if cand in s.symbols:
            return cand
    up = coin.upper()
    for sym in s.symbols:
        if str(sym).upper().startswith(up):
            return sym
    return None


def load_rows(conn, s: Source, coin: str, t_from: int, t_to: int) -> list[tuple]:
    """Normalisiert auf (ts_sekunden, o, h, l, c, v), aufsteigend."""
    div = 1000 if s.unit == "ms" else 1
    sel = (f"SELECT {s.time_col}, {s.cols['o']}, {s.cols['h']}, "
           f"{s.cols['l']}, {s.cols['c']}, "
           f"{s.cols['v'] or '0'} FROM {s.table} WHERE {s.time_col}>=? "
           f"AND {s.time_col}<=?")
    args = [t_from * div, t_to * div]
    sym = resolve_symbol(s, coin)
    if s.symbol_col and sym:
        sel += f" AND {s.symbol_col}=?"
        args.append(sym)
    sel += f" ORDER BY {s.time_col}"
    return [(int(r[0] // div), float(r[1]), float(r[2]), float(r[3]),
             float(r[4]), float(r[5] or 0)) for r in conn.execute(sel, args)]


# ---------------------------------------------------------------------------
# Indikatoren auf vorgeladenen Kerzen
# ---------------------------------------------------------------------------


def slopes(closes: list[float], times: list[int], horizons_min: list[int],
           now: int) -> dict:
    """
    Steigung je Horizont in Prozent pro Stunde. Sucht die Fenstergrenze
    binaer und rechnet nur ueber das Fenster — die frueher lineare Suche
    ueber die gesamte Reihe machte den Lauf quadratisch.
    """
    import bisect
    out = {}
    for h in horizons_min:
        lo = now - h * 60
        i = bisect.bisect_left(times, lo)
        n = len(times) - i
        if n < 5:
            out[h] = None
            continue
        sx = sy = sxx = sxy = 0.0
        for k in range(i, len(times)):
            x = (times[k] - lo) / 3600.0
            y = closes[k]
            sx += x; sy += y; sxx += x * x; sxy += x * y
        den = sxx - sx * sx / n
        my = sy / n
        out[h] = ((sxy - sx * sy / n) / den / my * 100.0) if den and my else None
    return out


def fvgs_from(ohlc: list[tuple], px: float, lookback: int = 60) -> list[dict]:
    """Dreikerzen-Lücke, ungefüllt, auf dem übergebenen Raster."""
    w = ohlc[-lookback:]
    out = []
    for i in range(len(w) - 2):
        h1, l1 = w[i][2], w[i][3]           # (ts, o, h, l, c, v)
        h3, l3 = w[i + 2][2], w[i + 2][3]
        if l3 > h1:
            lo, hi, kind, far = h1, l3, "bull", h1
        elif h3 < l1:
            lo, hi, kind, far = h3, l1, "bear", l1
        else:
            continue
        later = w[i + 3:]
        if any((c[3] <= far if kind == "bull" else c[2] >= far) for c in later):
            continue
        out.append({
            "kind": kind, "lo": lo, "hi": hi, "ts": w[i + 2][0],
            "inside": lo <= px <= hi,
            "dist_pct": 0.0 if lo <= px <= hi
                        else min(abs(px - lo), abs(px - hi)) / px * 100.0,
        })
    return out


# ---------------------------------------------------------------------------
# Strategie ohne Cluster
# ---------------------------------------------------------------------------


class CandleStrategy(Strategy):
    """
    Gleiche Verkaufsmechanik wie im vollen Modus — die Cluster-Zweige laufen
    ins Leere, weil die Marktsicht keine Cluster enthält. Nur der Einstieg
    braucht andere Faktoren, da Kaskade, Buch, Funding und Wale fehlen.
    """

    def __init__(self, cfg: SimConfig):
        super().__init__(cfg)
        self.min_score = cfg.candles_min_score

    def entry_score(self, v: View) -> tuple[int, list[str]]:
        cfg, notes, s = self.cfg, [], 0
        ex = v.f.__dict__.get("_extra", {})

        if v.rsi is not None and v.rsi <= cfg.rsi_buy:
            s += 1
            notes.append(f"RSI {v.rsi:.0f} (+1)")

        if any(g["kind"] == "bull" and (g["inside"] or g["dist_pct"] <= cfg.fvg_near_pct)
               for g in v.fvgs):
            s += 1
            notes.append("bullisches FVG am Kurs (+1)")

        # Übergeordneter Trend intakt
        long_slope = v.trend.get(cfg.candles_trend_min)
        if long_slope is not None and long_slope > cfg.trend_flat_pct_per_h:
            s += 1
            notes.append(f"Trend {cfg.candles_trend_min}min steigend (+1)")

        # Rücksetzer in diesen Trend hinein
        pull = ex.get("pullback_pct")
        if pull is not None and pull >= cfg.candles_pullback_pct:
            s += 1
            notes.append(f"Rücksetzer {pull:.2f}% vom Hoch (+1)")

        # Fallendes Messer meiden
        short_slope = v.trend.get(min(cfg.trend_horizons_min))
        if short_slope is not None and short_slope < -cfg.trend_flat_pct_per_h * 6:
            s -= 2
            notes.append(f"kurzfristig stark fallend ({short_slope:.2f}%/h, -2)")

        return s, notes


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


def apply_spacing(cfg: SimConfig, sp: int) -> list[str]:
    """
    Zieht alle zeitbezogenen Schwellen auf mindestens den Kerzenabstand.
    Muss von JEDEM Weg benutzt werden, der eine Konfiguration ausfuehrt —
    Simulation wie Optimizer —, sonst optimiert die Suche einen anderen Bot
    als den, der danach laeuft.
    """
    notes = []
    if cfg.rsi_grid_min * 60 < sp:
        cfg.rsi_grid_min = sp // 60
        notes.append(f"Raster auf {sp // 60} min angehoben")
    if cfg.min_seconds_between_buys < sp:
        cfg.min_seconds_between_buys = sp
        notes.append(f"Kaufabstand auf {sp} s angehoben")
    if cfg.dip_confirm_seconds < sp:
        cfg.dip_confirm_seconds = sp
        notes.append(f"Bodenbestaetigung auf {sp} s angehoben")
    if cfg.crash_window_s < sp:
        cfg.crash_window_s = sp
    return notes


class CandleEngine(Engine):
    def __init__(self, db_path: str, cfg: SimConfig, results_db: str | None = None):
        super().__init__(db_path, cfg, results_db)
        self.strat = CandleStrategy(cfg)
        self.sources = discover(self.conn)
        self.source = choose(self.sources, cfg.candle_source, cfg.coin)
        self.rows: list[tuple] = []
        self.i = 0
        self.grid: list[tuple] = []      # (ts, o, h, l, c, v) auf rsi_grid_min
        self._bucket: list | None = None
        self._peaks: deque = deque()     # Indizes fallender Hochs
        self._times: list[int] = []
        self._cum: list[float] = [0.0]

    # ---- Bereich
    def data_range(self) -> dict:
        return {s.table: {"from": s.t_from, "to": s.t_to, "rows": s.rows}
                for s in self.sources}

    def usable_range(self) -> tuple[int, int]:
        if not self.source:
            return (0, 0)
        return (self.source.t_from or 0, self.source.t_to or 0)

    def source_info(self) -> dict:
        return {
            "chosen": self.source.label() if self.source else None,
            "available": [s.label() for s in self.sources],
            "symbol": resolve_symbol(self.source, self.cfg.coin)
                      if self.source else None,
        }

    # ---- Vorladen
    def preload(self, t_from: int, t_to: int) -> int:
        if not self.source:
            return 0
        lead = max(self.cfg.candles_pullback_hours * 3600,
                   max(self.cfg.trend_horizons_min) * 60,
                   self.cfg.rsi_period * self.cfg.rsi_grid_min * 60 * 4)
        self.rows = load_rows(self.conn, self.source, self.cfg.coin,
                              t_from - lead, t_to)
        self.i = 0
        self.grid.clear()
        self._bucket = None
        self._peaks.clear()
        self._times = [r[0] for r in self.rows]
        self._cum = [0.0]
        acc = 0.0
        for r in self.rows:
            acc += r[5] * r[4]
            self._cum.append(acc)
        self.spacing = self._spacing()
        return len(self.rows)

    def _spacing(self) -> int:
        """Median-Abstand der Kerzen. klines30 liefert 1800 s, bars 60 s."""
        if len(self.rows) < 3:
            return 60
        d = sorted(b[0] - a[0] for a, b in zip(self.rows[:400], self.rows[1:401]))
        return max(1, d[len(d) // 2])

    def _advance(self, ts: int) -> None:
        step = self.cfg.rsi_grid_min * 60
        while self.i < len(self.rows) and self.rows[self.i][0] <= ts:
            t, o, h, l, c, vol = self.rows[self.i]
            dq = self._peaks
            while dq and self.rows[dq[-1]][2] <= h:
                dq.pop()
            dq.append(self.i)
            k = (t // step) * step
            if self._bucket is None or self._bucket[0] != k:
                if self._bucket is not None:
                    self.grid.append(tuple(self._bucket))
                self._bucket = [k, o, h, l, c, vol]
            else:
                b = self._bucket
                b[2] = max(b[2], h)
                b[3] = min(b[3], l)
                b[4] = c
                b[5] += vol
            self.i += 1

    # ---- Marktsicht
    def view(self, ts: int) -> View | None:
        self._advance(ts)
        if self.i == 0:
            return None
        t, o, h, l, c, vol = self.rows[self.i - 1]
        if ts - t > 2 * 3600:          # Lücke in den Kerzen
            return None
        px = c

        closed = self.grid[-self.cfg.rsi_period * 4:]
        closes = [g[4] for g in closed]
        times = [g[0] for g in closed]

        # Rücksetzer vom Hoch der letzten Stunden — monotone Schlange, damit
        # nicht bei jedem Schritt erneut über Tausende Zeilen gelaufen wird.
        lo_t = ts - self.cfg.candles_pullback_hours * 3600
        dq = self._peaks
        while dq and self.rows[dq[0]][0] < lo_t:
            dq.popleft()
        peak = self.rows[dq[0]][2] if dq else px
        pullback = (peak - px) / peak * 100.0 if peak else 0.0

        # Geschwindigkeit im Crash-Fenster
        import bisect
        j = bisect.bisect_right(self._times, ts - self.cfg.crash_window_s, 0, self.i)
        vel = ((px - self.rows[j - 1][4]) / self.rows[j - 1][4] * 100.0) if j else 0.0

        k = bisect.bisect_left(self._times, ts - 3600, 0, self.i)
        hourly = self._cum[self.i] - self._cum[k]

        f = Features(ts=ts, coin=self.cfg.coin, mark_px=px, mid_px=px,
                     age_ctx=0.0, age_book=0.0)
        f.hourly_notional = hourly
        f.__dict__["_extra"] = {"pullback_pct": pullback, "peak": peak}

        return View(
            ts=ts, f=f, px=px,
            rsi=rsi(closes, self.cfg.rsi_period),
            fvgs=fvgs_from(closed, px),
            trend=slopes([g[4] for g in self.grid], [g[0] for g in self.grid],
                         sorted(set(self.cfg.trend_horizons_min
                                    + [self.cfg.candles_trend_min])), ts),
            clusters={"snapshot_ts": None, "age_s": None,
                      "above": None, "below": None, "buckets": []},
            whales={"long": 0.0, "short": 0.0, "ratio": 1.0},
            velocity_pct=vel,
            depth_median_1h=None,
        )

    # ---- Ausführung: kein Buch, also pauschaler Aufschlag
    def fill(self, v: View, is_buy: bool, usd: float) -> float:
        bps = self.cfg.candles_slippage_bps
        return v.px * (1 + bps / 1e4) if is_buy else v.px * (1 - bps / 1e4)

    # ---- Lauf
    def run_backtest(self, t_from: int, t_to: int, on_progress=None) -> dict:
        if not self.source:
            return {"error": "Keine geeignete Kerzentabelle gefunden.",
                    "sources": self.source_info()}
        lo, hi = self.usable_range()
        clipped = False
        if t_from < lo:
            t_from, clipped = lo, True
        if t_to > hi:
            t_to, clipped = hi, True
        if t_from >= t_to:
            return {"error": "Kein nutzbarer Zeitraum.", "sources": self.source_info()}

        n = self.preload(t_from, t_to)
        sp = getattr(self, "spacing", 60)
        grid_before = self.cfg.rsi_grid_min
        for note in apply_spacing(self.cfg, sp):
            self._log(t_from, "info", note + f" — die Quelle "
                      f"{self.source.table} liefert nicht feiner.")
        if self.cfg.rsi_grid_min != grid_before:
            self.preload(t_from, t_to)
        step = max(self.cfg.step_seconds, sp)
        if (t_to - t_from) > 30 * 86400 and step < 300:
            step = max(300, sp)
            self._log(t_from, "info",
                      "Schrittweite auf 300 s vergröbert — bei diesem Zeitraum "
                      "wären feinere Schritte auf einem Pi unpraktikabel.")
        self._log(t_from, "info",
                  f"Kerzen-Test auf {self.source.table}: {n:,} Kerzen, "
                  f"{utc(t_from)} bis {utc(t_to)}"
                  + (" (beschnitten)" if clipped else ""))

        self.running = True
        if self.results:
            self.results.start("candles", self.cfg, t_from, t_to)
        total = max(1, t_to - t_from)
        ts = t_from
        while ts <= t_to and self.running:
            self.step(ts)
            ts += step
            self.progress = (ts - t_from) / total
        self.running = False
        self.progress = 1.0
        px = self.last_view.px if self.last_view else 0.0
        return self.summary(px) | {"clipped": clipped, "mode": "candles",
                                   "sources": self.source_info()}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="hl_liq.db")
    p.add_argument("--coin", default="BTC")
    p.add_argument("--sources", action="store_true")
    p.add_argument("--source", default="auto")
    p.add_argument("--from", dest="t_from", default="2026-08-05")
    p.add_argument("--to", dest="t_to", default="now")
    p.add_argument("--step", type=int, default=300)
    a = p.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    cfg = SimConfig(coin=a.coin, candle_source=a.source, step_seconds=a.step)
    eng = CandleEngine(a.db, cfg, results_db="hl_sim_results.db")

    if a.sources:
        for s in eng.sources:
            print(f"  {s.label()}")
            print(f"    Zeit: {s.time_col} ({s.unit}), Symbol: {s.symbol_col}, "
                  f"Spalten: {s.cols}")
            if s.symbols:
                print(f"    Symbole: {', '.join(map(str, s.symbols[:12]))}")
        print(f"\n  gewählt: {eng.source.label() if eng.source else 'keine'}")
        return

    res = eng.run_backtest(parse_time(a.t_from), parse_time(a.t_to))
    print(json.dumps(res, indent=2, ensure_ascii=False))
    for e in eng.journal[-30:]:
        print(f"{e['t']}  {e['kind']:>5}  {e['text']}")


if __name__ == "__main__":
    main()
