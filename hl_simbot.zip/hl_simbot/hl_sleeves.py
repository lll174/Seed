"""Drei-Arm-Strategie auf Tageskerzen, jeder Arm mit eigenem Kapital.

Kern    : Regimefolge. Voll investiert ueber dem MA200, raus bei Bruch
          (Schluss unter MA200 minus Puffer ODER Abstand vom Hoch >= Ausstieg),
          wieder rein bei Rueckkehr ueber den MA50 plus Erholung vom Tief.
Dip     : Nur im Bullenregime. Kauf bei Ruecksetzer >= X % vom 30-Tage-Hoch,
          Verkauf bei Rueckkehr an das alte Hoch oder +Y %, Stop bei -Z %.
Scalp   : Wie Dip, aber engere Schwellen (3-8 % rein, +5 % raus).
"""
from dataclasses import dataclass, field

@dataclass
class P:
    core_w: float = 0.6; dip_w: float = 0.3; scalp_w: float = 0.1
    ma_fast: int = 50; ma_slow: int = 200
    core_exit_dd: float = 20.0          # % unter Hoch seit Einstieg
    core_ma_buffer: float = 3.0         # % unter MA200 = Regimebruch
    core_reentry_bounce: float = 5.0
    dip_in: float = 10.0; dip_out: float = 12.0; dip_stop: float = 12.0
    scalp_in: float = 4.0; scalp_out: float = 5.0; scalp_stop: float = 6.0
    fee_bps: float = 8.0; slip_bps: float = 3.0

def sim(rows, p: P, start_cash=10000.0):
    c=[r[3] for r in rows]; h=[r[1] for r in rows]; l=[r[2] for r in rows]; n=len(c)
    fee=(p.fee_bps+p.slip_bps)/1e4
    def sma(i,w): return sum(c[i-w+1:i+1])/w if i>=w-1 else None
    # --- Zustaende
    core = dict(cash=start_cash*p.core_w, coin=0.0, hi=0.0, lo_exit=None, out=False)
    arms = {"dip": dict(cash=start_cash*p.dip_w, coin=0.0, entry=0.0, target=0.0, win=p.dip_in, out_=p.dip_out, stop=p.dip_stop),
            "scalp": dict(cash=start_cash*p.scalp_w, coin=0.0, entry=0.0, target=0.0, win=p.scalp_in, out_=p.scalp_out, stop=p.scalp_stop)}
    eq=[]; trades={"core":0,"dip":0,"scalp":0}; peak=start_cash; mdd=0.0
    for i in range(n):
        m50, m200 = sma(i,p.ma_fast), sma(i,p.ma_slow)
        bull = m200 is not None and c[i] > m200
        hi30 = max(h[max(0,i-30):i+1])
        # ---- Kern
        if core["coin"] > 0:
            core["hi"] = max(core["hi"], c[i])
            dd = (core["hi"]-c[i])/core["hi"]*100
            broke = m200 is not None and c[i] < m200*(1-p.core_ma_buffer/100)
            if dd >= p.core_exit_dd or broke:
                core["cash"] += core["coin"]*c[i]*(1-fee); core["coin"]=0.0
                core["out"]=True; core["lo_exit"]=c[i]; trades["core"]+=1
        else:
            if core["out"]:
                core["lo_exit"] = min(core["lo_exit"], c[i])
                bounce=(c[i]/core["lo_exit"]-1)*100
                ok = bounce>=p.core_reentry_bounce and (m50 is None or c[i]>m50) and (m200 is None or c[i]>m200)
            else:
                ok = m200 is None or bull          # Erstinvestition: sofort, sofern kein Baerenregime
            if ok and core["cash"]>1:
                core["coin"]=core["cash"]*(1-fee)/c[i]; core["cash"]=0.0; core["hi"]=c[i]; core["out"]=False; trades["core"]+=1
        # ---- Dip und Scalp (nur im Bullenregime kaufen)
        for name,a in arms.items():
            if a["coin"]>0:
                gain=(c[i]/a["entry"]-1)*100
                if c[i]>=a["target"] or gain>=a["out_"] or gain<=-a["stop"]:
                    a["cash"]+=a["coin"]*c[i]*(1-fee); a["coin"]=0.0; trades[name]+=1
            elif bull and a["cash"]>1:
                dd30=(1-c[i]/hi30)*100
                if dd30>=a["win"]:
                    a["coin"]=a["cash"]*(1-fee)/c[i]; a["cash"]=0.0; a["entry"]=c[i]; a["target"]=hi30; trades[name]+=1
        e = core["cash"]+core["coin"]*c[i]+sum(a["cash"]+a["coin"]*c[i] for a in arms.values())
        eq.append(e); peak=max(peak,e); mdd=max(mdd,(peak-e)/peak*100)
    parts = {"core": core["cash"]+core["coin"]*c[-1], **{k: a["cash"]+a["coin"]*c[-1] for k,a in arms.items()}}
    return dict(ret=(eq[-1]/start_cash-1)*100, mdd=mdd, trades=trades,
                arm_ret={k:((v/(start_cash*getattr(p,f"{k}_w"))-1)*100 if getattr(p,f"{k}_w")>0 else 0.0) for k,v in parts.items()})

def dca(rows, n=20, fee=0.0011):
    c=[r[3] for r in rows]; per=10000/n; step=max(1,len(c)//n); coin=0.0
    for k in range(n): coin += per*(1-fee)/c[min(len(c)-1,k*step)]
    return (coin*c[-1]/10000-1)*100
def bh(rows): c=[r[3] for r in rows]; return (c[-1]/c[0]-1)*100
