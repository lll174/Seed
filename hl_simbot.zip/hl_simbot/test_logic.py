"""Prüft die Entscheidungszweige, die ein Zufallslauf nicht zuverlässig trifft."""
from hl_sim import SimConfig, Portfolio, Strategy, View, Features
from hl_botcore import State

# Eigener Satz, unabhaengig von den Vorgaben: die duerfen sich aendern,
# ohne dass diese Pruefungen dadurch falsch werden.
cfg = SimConfig(
    budget_usd=1000.0,
    order_pct=5.0,
    max_lots=20,
    ladder=[{"gain_pct": 1.5, "sell_pct": 20},
            {"gain_pct": 3.0, "sell_pct": 25},
            {"gain_pct": 5.0, "sell_pct": 25}],
    crash_sell_pct=70.0,
    crash_drop_pct=1.0,
    stop_loss_pct=5.0,
)
ok = fail = 0


def check(name, cond, info=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"  ok    {name} {info}")
    else:
        fail += 1
        print(f"  FEHL  {name} {info}")


def view(px, cluster_px=None, notional=3e7, n_liq=0, hourly=3e7, rsi_=50, vel=0.0):
    f = Features(ts=1_800_000_000, coin="BTC", mark_px=px, mid_px=px,
                 age_ctx=0, age_book=0, bid_50=5e5)
    f.n_liq_60s = n_liq
    f.hourly_notional = hourly
    above = None
    if cluster_px:
        d = abs(cluster_px - px) / px * 100.0
        above = {"bucket_px": cluster_px, "notional": notional, "dist_pct": d,
                 "lo": cluster_px * 0.999, "hi": cluster_px * 1.001,
                 "in_band": d <= cfg.cluster_band_pct, "side": "short",
                 "n_pos": 20}
    return View(ts=f.ts, f=f, px=px, rsi=rsi_, fvgs=[],
                trend={60: .2, 120: .2, 180: .2, 360: .2},
                clusters={"snapshot_ts": f.ts - 60, "age_s": 60,
                          "above": above, "below": None, "buckets": []},
                whales={"long": 1, "short": 1, "ratio": 1.0},
                velocity_pct=vel, depth_median_1h=5e5)


def fresh(px=80000.0, lots=3, usd=50.0):
    pf = Portfolio(cfg)
    for i in range(lots):
        pf.buy(1_800_000_000 - 3600 * (lots - i), px, usd, cfg.fee_bps_taker, "test")
    return pf


print("1. Leiter verkauft Anteile der AUSGANGSPOSITION")
pf = fresh()
s = Strategy(cfg)
start = pf.size
for stufe, gain in enumerate([1.5, 3.0, 5.0]):
    px = pf.avg_px * (1 + gain / 100.0 + 0.001)
    d = s.want_sell(view(px), pf)
    frac = pf.fraction_for(d)
    pf.sell_fraction(d.reason and 1_800_000_000, px, frac, cfg.fee_bps_taker, d.reason)
rest = pf.size / start * 100
check("Rest nach 20+25+25", abs(rest - 30) < 1.5, f"-> {rest:.1f}% (Soll 30%)")

print("\n2. Grosses Cluster nah darueber setzt die Leiter aus")
pf = fresh()
s = Strategy(cfg)
px = pf.avg_px * 1.02                       # +2 % waere Stufe 1 und 2
d = s.want_sell(view(px, cluster_px=px * 1.008), pf)   # Cluster 0,8 % darueber
check("haelt statt zu verkaufen", d.action == "hold", f"-> {d.reason}")

print("\n3. Ohne Cluster feuert dieselbe Lage die Leiter")
pf = fresh()
s = Strategy(cfg)
d = s.want_sell(view(px), pf)
check("Leiterstufe ausgeloest", d.action == "sell" and "Leiterstufe" in d.reason,
      f"-> {d.reason}")

print("\n4. Kurs im Cluster: Verkauf hinein, aber nur einmal")
pf = fresh()
s = Strategy(cfg)
px = pf.avg_px * 1.02
d1 = s.want_sell(view(px, cluster_px=px * 1.0005), pf)
frac = pf.fraction_for(d1)
pf.sell_fraction(1_800_000_000, px, frac, cfg.fee_bps_taker, d1.reason)
d2 = s.want_sell(view(px, cluster_px=px * 1.0005), pf)
check("erster Verkauf im Cluster", d1.action == "sell" and "Short-Cluster" in d1.reason)
check("kein zweiter am selben Cluster", d2.action != "sell", f"-> {d2.reason}")

print("\n5. Squeeze am Cluster")
pf = fresh()
s = Strategy(cfg)
px = pf.avg_px * 1.02
d = s.want_sell(view(px, cluster_px=px * 1.002, n_liq=9), pf)
check("Squeeze erkannt", d.action == "sell" and "Squeeze" in d.reason, f"-> {d.reason}")

print("\n6. Notausstieg feuert nur einmal je Episode")
pf = fresh()
s = Strategy(cfg)
d1 = s.want_sell(view(80000, vel=-2.0), pf)
pf.sell_fraction(1_800_000_000, 80000, pf.fraction_for(d1), cfg.fee_bps_taker, "x")
d2 = s.want_sell(view(80000, vel=-2.0), pf)
check("erster Notausstieg", d1.action == "sell" and "Notausstieg" in d1.reason)
check("kein zweiter im selben Einbruch", d2.action != "sell" or
      "Notausstieg" not in d2.reason, f"-> {d2.reason}")

print("\n7. Kaufsperre nach Zwangsausstieg")
pf = fresh(lots=1)
s = Strategy(cfg)
pf.last_forced_exit_ts = 1_800_000_000 - 600
d = s.want_buy(view(70000, rsi_=20), pf)
check("Kauf gesperrt", d.action == "hold" and "Sperre" in d.reason, f"-> {d.reason}")

print("\n8. Leiterstufe wird nach Nachkauf wieder scharf")
pf = fresh(lots=2)
s = Strategy(cfg)
px = pf.avg_px * 1.016
d = s.want_sell(view(px), pf)
pf.sell_fraction(1_800_000_000, px, pf.fraction_for(d), cfg.fee_bps_taker, "l1")
for _ in range(6):                          # Position deutlich vergroessern
    pf.buy(1_800_000_000, px * 0.99, 50, cfg.fee_bps_taker, "nachkauf")
d2 = s.want_sell(view(pf.avg_px * 1.016), pf)
check("Stufe 1 erneut scharf", d2.action == "sell" and "erneut" in d2.reason,
      f"-> {d2.reason}")

print("\n9. Tranchengroesse aus Prozentsatz")
pf = Portfolio(cfg)
check("5 % von 1000 USD (Basis Einsatzsumme)",
      abs(pf.next_order_usd() - 50.0) < 0.01, f"-> {pf.next_order_usd()}")
pf.cash = 4.0
check("unter Mindestorder kein Kauf", pf.next_order_usd() == 0.0)

print("\n10. Tranche waechst mit dem Kontostand")
cfg2 = SimConfig(budget_usd=1000.0, order_pct=5.0, order_basis="equity",
                 min_order_usd=10.0)
pf2 = Portfolio(cfg2)
pf2.cash = 2000.0                       # Konto hat sich verdoppelt
check("5 % von 2000 USD", abs(pf2.next_order_usd(80000) - 100.0) < 0.01,
      f"-> {pf2.next_order_usd(80000)}")

print("\n11. Keine Zwergverkaeufe")
pf3 = fresh(lots=1, usd=50.0)
s3 = Strategy(cfg)
pf3.sell_fraction(1_800_000_000, 80000, 0.999, cfg.fee_bps_taker, "fast alles")
d3 = s3.want_sell(view(96000), pf3)     # +20 %: Leiter waere faellig
check("Restposition wird nicht weiter zerlegt",
      d3.action == "hold" and "Mindestorder" in d3.reason, f"-> {d3.reason}")

print("\n12. Cluster gilt nur einmal je Zone")
pf4 = fresh(lots=3)
s4 = Strategy(cfg)
base_px = pf4.avg_px * 1.05
n = 0
for k in range(6):                      # Zone wandert minimal je Snapshot
    v4 = view(base_px, cluster_px=base_px * (1 + 0.0003 * k))
    d4 = s4.want_sell(v4, pf4)
    if d4.action == "sell" and "Cluster" in d4.reason:
        n += 1
        pf4.sell_fraction(1_800_000_000, base_px, pf4.fraction_for(d4),
                          cfg.fee_bps_taker, d4.reason)
check("nur ein Verkauf trotz wandernder Zone", n == 1, f"-> {n} Verkaeufe")

print("\n13. Korrekturausstieg: Kurs 20 % unter dem Hoch seit Einstieg")
cfgx = SimConfig(budget_usd=1000.0, order_pct=5.0, max_lots=20,
                 exit_loss_pct=15.0, exit_drawdown_pct=20.0,
                 exit_requires_bear=0, crash_sell_pct=0.0, stop_loss_pct=0.0)
pfx = Portfolio(cfgx); sx = Strategy(cfgx)
pfx.buy(1_800_000_000, 80000, 50, cfgx.fee_bps_taker, "t")
vh = view(90000); vh.__dict__.update(ma_fast=None, ma_slow=None)
sx.want_sell(vh, pfx)                    # Hoch auf 90.000 setzen
vd = view(71000); vd.__dict__.update(ma_fast=None, ma_slow=None)
d = sx.want_sell(vd, pfx)                # -21 % vom Hoch, Position noch -11 %
check("Ausstieg wegen Abstand vom Hoch",
      d.action == "sell" and "Korrekturausstieg" in d.reason, f"-> {d.reason}")
pfx.sell_fraction(1_800_000_000, 71000, 1.0, cfgx.fee_bps_taker, "x")
check("Bot ist danach defensiv", pfx.defensive)

print("\n14. Kein Wiedereinstieg, solange der Kurs weiter faellt")
sx.machine.state = State.IDLE
for px in (69000, 66000, 64000):
    v = view(px, rsi_=25); v.__dict__.update(ma_fast=None, ma_slow=None)
    v.ts = 1_800_000_000 + 20000
    d = sx.want_buy(v, pfx)
check("haelt waehrend der Korrektur", d.action == "hold" and "Korrektur" in d.reason,
      f"-> {d.reason}")

print("\n15. Wiedereinstieg nach 5 % Erholung vom Tief")
v = view(64000 * 1.06, rsi_=25); v.__dict__.update(ma_fast=None, ma_slow=None)
v.ts = 1_800_000_000 + 30000
d = sx.want_buy(v, pfx)
check("kauft nach bestaetigtem Boden",
      d.action == "buy" and "Wiedereinstieg" in d.reason, f"-> {d.reason}")

print("\n16. Regimefilter: unter dem langsamen MA keine Akkumulation")
cfgr = SimConfig(budget_usd=1000.0, order_pct=5.0, max_lots=20,
                 buy_requires_bull=1, candles_min_score=0, entry_min_score=0)
pfr = Portfolio(cfgr); sr = Strategy(cfgr)
v = view(60000, rsi_=20); v.__dict__.update(ma_fast=65000.0, ma_slow=70000.0)
d = sr.want_buy(v, pfr)
check("kein Kauf unter dem MA", d.action == "hold" and "langsamen MA" in d.reason,
      f"-> {d.reason}")
v = view(75000, rsi_=20); v.__dict__.update(ma_fast=65000.0, ma_slow=70000.0)
d = sr.want_buy(v, pfr)
check("Kauf ueber dem MA erlaubt", d.action == "buy", f"-> {d.action} {d.reason}")

print(f"\n{ok} bestanden, {fail} fehlgeschlagen")
raise SystemExit(1 if fail else 0)
