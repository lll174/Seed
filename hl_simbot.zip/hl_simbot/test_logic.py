"""Prüft die Entscheidungszweige, die ein Zufallslauf nicht zuverlässig trifft."""
from hl_sim import SimConfig, Portfolio, Strategy, View, Features

cfg = SimConfig()
ok = fail = 0


def check(name, cond, info=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"  ok    {name} {info}")
    else:
        fail += 1
        print(f"  FEHL  {name} {info}")


def view(px, cluster_px=None, notional=3e7, n_liq=0, hourly=3e7, rsi_=50, vel=0.0):
    f = Features(ts=1_800_000_000, coin="BTC", mark_px=px, mid_px=px,
                 age_ctx=0, age_book=0, bid_50=5e5)
    f.n_liq_60s = n_liq
    f.hourly_notional = hourly
    above = None
    if cluster_px:
        d = abs(cluster_px - px) / px * 100.0
        above = {"bucket_px": cluster_px, "notional": notional, "dist_pct": d,
                 "lo": cluster_px * 0.999, "hi": cluster_px * 1.001,
                 "in_band": d <= cfg.cluster_band_pct, "side": "short",
                 "n_pos": 20}
    return View(ts=f.ts, f=f, px=px, rsi=rsi_, fvgs=[],
                trend={60: .2, 120: .2, 180: .2, 360: .2},
                clusters={"snapshot_ts": f.ts - 60, "age_s": 60,
                          "above": above, "below": None, "buckets": []},
                whales={"long": 1, "short": 1, "ratio": 1.0},
                velocity_pct=vel, depth_median_1h=5e5)


def fresh(px=80000.0, lots=3, usd=50.0):
    pf = Portfolio(cfg)
    for i in range(lots):
        pf.buy(1_800_000_000 - 3600 * (lots - i), px, usd, cfg.fee_bps_taker, "test")
    return pf


print("1. Leiter verkauft Anteile der AUSGANGSPOSITION")
pf = fresh()
s = Strategy(cfg)
start = pf.size
for stufe, gain in enumerate([1.5, 3.0, 5.0]):
    px = pf.avg_px * (1 + gain / 100.0 + 0.001)
    d = s.want_sell(view(px), pf)
    frac = pf.fraction_for(d)
    pf.sell_fraction(d.reason and 1_800_000_000, px, frac, cfg.fee_bps_taker, d.reason)
rest = pf.size / start * 100
check("Rest nach 20+25+25", abs(rest - 30) < 1.5, f"-> {rest:.1f}% (Soll 30%)")

print("\n2. Grosses Cluster nah darueber setzt die Leiter aus")
pf = fresh()
s = Strategy(cfg)
px = pf.avg_px * 1.02                       # +2 % waere Stufe 1 und 2
d = s.want_sell(view(px, cluster_px=px * 1.008), pf)   # Cluster 0,8 % darueber
check("haelt statt zu verkaufen", d.action == "hold", f"-> {d.reason}")

print("\n3. Ohne Cluster feuert dieselbe Lage die Leiter")
pf = fresh()
s = Strategy(cfg)
d = s.want_sell(view(px), pf)
check("Leiterstufe ausgeloest", d.action == "sell" and "Leiterstufe" in d.reason,
      f"-> {d.reason}")

print("\n4. Kurs im Cluster: Verkauf hinein, aber nur einmal")
pf = fresh()
s = Strategy(cfg)
px = pf.avg_px * 1.02
d1 = s.want_sell(view(px, cluster_px=px * 1.0005), pf)
frac = pf.fraction_for(d1)
pf.sell_fraction(1_800_000_000, px, frac, cfg.fee_bps_taker, d1.reason)
d2 = s.want_sell(view(px, cluster_px=px * 1.0005), pf)
check("erster Verkauf im Cluster", d1.action == "sell" and "Short-Cluster" in d1.reason)
check("kein zweiter am selben Cluster", d2.action != "sell", f"-> {d2.reason}")

print("\n5. Squeeze am Cluster")
pf = fresh()
s = Strategy(cfg)
px = pf.avg_px * 1.02
d = s.want_sell(view(px, cluster_px=px * 1.002, n_liq=9), pf)
check("Squeeze erkannt", d.action == "sell" and "Squeeze" in d.reason, f"-> {d.reason}")

print("\n6. Notausstieg feuert nur einmal je Episode")
pf = fresh()
s = Strategy(cfg)
d1 = s.want_sell(view(80000, vel=-2.0), pf)
pf.sell_fraction(1_800_000_000, 80000, pf.fraction_for(d1), cfg.fee_bps_taker, "x")
d2 = s.want_sell(view(80000, vel=-2.0), pf)
check("erster Notausstieg", d1.action == "sell" and "Notausstieg" in d1.reason)
check("kein zweiter im selben Einbruch", d2.action != "sell" or
      "Notausstieg" not in d2.reason, f"-> {d2.reason}")

print("\n7. Kaufsperre nach Zwangsausstieg")
pf = fresh(lots=1)
s = Strategy(cfg)
pf.last_forced_exit_ts = 1_800_000_000 - 600
d = s.want_buy(view(70000, rsi_=20), pf)
check("Kauf gesperrt", d.action == "hold" and "Sperre" in d.reason, f"-> {d.reason}")

print("\n8. Leiterstufe wird nach Nachkauf wieder scharf")
pf = fresh(lots=2)
s = Strategy(cfg)
px = pf.avg_px * 1.016
d = s.want_sell(view(px), pf)
pf.sell_fraction(1_800_000_000, px, pf.fraction_for(d), cfg.fee_bps_taker, "l1")
for _ in range(6):                          # Position deutlich vergroessern
    pf.buy(1_800_000_000, px * 0.99, 50, cfg.fee_bps_taker, "nachkauf")
d2 = s.want_sell(view(pf.avg_px * 1.016), pf)
check("Stufe 1 erneut scharf", d2.action == "sell" and "erneut" in d2.reason,
      f"-> {d2.reason}")

print("\n9. Tranchengroesse aus Prozentsatz")
pf = Portfolio(cfg)
check("5 % von 1000 USD", abs(pf.next_order_usd() - 50.0) < 0.01,
      f"-> {pf.next_order_usd()}")
pf.cash = 4.0
check("unter Mindestorder kein Kauf", pf.next_order_usd() == 0.0)

print(f"\n{ok} bestanden, {fail} fehlgeschlagen")
raise SystemExit(1 if fail else 0)
