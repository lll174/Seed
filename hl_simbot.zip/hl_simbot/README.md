# Handelssimulation auf dem Liquidationscluster-Recorder

Simuliert Spot-Käufe auf BTC anhand der Daten, die `hl_recorder.py` aufzeichnet.
Es werden **keine echten Orders gesendet** — es gibt keine Börsenanbindung und
keinen Schlüssel im Code.

Der Simulator liest `hl_liq.db` ausschließlich lesend (`mode=ro`) und öffnet
keine eigenen WebSocket- oder REST-Verbindungen. Der Recorder bleibt alleiniger
Schreiber und alleiniger Verbraucher der API-Limits.

## Dateien

| Datei | Zweck |
|---|---|
| `hl_botcore.py` | Point-in-Time-Features mit Datenalter, Kaskaden-Zustandsmaschine, Füllpreis aus `book_ticks` |
| `hl_sim.py` | Lot-Tabelle, Strategie, Backtest- und Live-Runner, Ergebnisprotokoll |
| `hl_candles.py` | Kerzen-Modus: Quellenerkennung, reduzierte Marktsicht, chart-technische Strategie |
| `hl_simdash.py` | Weboberfläche auf Port 8766 |
| `hl_optimize.py` | Leitet Parameter aus dem Kursverlauf ab und prüft sie auf einer Holdout-Hälfte |
| `check_schema.py` | Vergleicht die echte Datenbank mit dem, was der Simulator liest |
| `check_gaps.py` | Zeigt, ob fehlende Minuten Startversatz sind oder verstreute Lücken |
| `test_logic.py` | Prüft die Entscheidungszweige (12 Fälle) |
| `make_testdb.py` | Erzeugt eine synthetische Datenbank zum Ausprobieren ohne echte Daten |
| `hl-simdash.service` | Optionale systemd-Unit |

## Installation

Keine. Alles läuft mit der Standardbibliothek von Python 3.11+ — kein `pip`,
keine Abhängigkeiten, nichts, was sich mit dem Recorder beißen könnte.

Dateien neben die bestehenden Skripte legen:

```bash
cd ~/Desktop/bot/hl_liq_project
unzip -o ~/Downloads/hl_simbot.zip && cd hl_simbot
python3 check_schema.py --db ../hl_liq.db   # Schema gegen den Code pruefen
python3 check_gaps.py   --db ../hl_liq.db   # Luecken in den Zeitreihen
python3 test_logic.py                       # 12 bestanden, 0 fehlgeschlagen
```

`check_schema.py` zuerst. Es meldet fehlende Spalten, erkennt Sekunden gegen
Millisekunden an der Groessenordnung und zeigt die Wertebereiche der Felder,
deren Einheit im Schema nicht steht — etwa ob `proximity.up_dist` Prozent oder
ein Anteil ist. Es aendert nichts und oeffnet schreibgeschuetzt.

## Starten

Als normales Programm, kein Dienst nötig:

```bash
python3 hl_simdash.py --db hl_liq.db --host 0.0.0.0
```

Dann im LAN `http://<pi>:8766` öffnen. Port 8765 bleibt dem bestehenden
Dashboard, 8766 ist die Simulation.

Ohne Oberfläche geht es auch:

```bash
python3 hl_candles.py --db hl_liq.db --sources          # welche Kerzenquellen gibt es
python3 hl_candles.py --db hl_liq.db --from 2026-05-01 --to now --step 300
python3 hl_sim.py     --db hl_liq.db --backtest --from 2026-09-01 --to now
python3 hl_sim.py     --db hl_liq.db --live
```

## Die drei Betriebsarten

**Kerzen-Test.** Nur `bars` beziehungsweise die Binance-Rückfüllung. Keine
Cluster, kein Orderbuch, keine Wale. Läuft über Monate und beantwortet, ob die
Ein- und Ausstiegsmechanik überhaupt trägt.

**Volle Daten.** Zusätzlich Heatmap, Orderbuchtiefe, Funding und Wale, also die
Cluster-Logik. Reicht nur so weit zurück wie der Recorder — Beginn 1.9.2026.
Der Zeitraum wird automatisch auf die vorhandenen Daten beschnitten.

**Live.** Der Bot folgt im eingestellten Takt den Daten, die der Recorder gerade
schreibt, und simuliert Orders darauf.

Beide Backtests über denselben Zeitraum laufen zu lassen ist der eigentliche
Zweck: die Differenz ist der Beitrag der Liquidationsdaten.

## Strategie „Regime-Akkumulation" (Vorgabe seit Version i)

Ergebnis der Tageskerzen-Analyse (echte_daten/ERGEBNISSE.md, Abschnitt 8):

- **Regime** über den MA200 mit ±3 % Puffer. Fehlt `bars` die Historie, wird
  der MA200 aus `klines30`/`bnc_bars` berechnet.
- **Baisse** (unter MA200): Budget in 30 Tranchen, höchstens eine je 15 Tage,
  nur bei Rücksetzer ≥ 8 % vom 30-Tage-Hoch. Tiefenstaffel: Tranche ×1 ab 10 %
  unter dem MA200, ×2 ab 20 %, ×3 ab 30 %, halbe Tranche knapp darunter
  (Abschnitt 10). Kein Regimefilter gegen das Kaufen — die billigsten Dips
  liegen in der Baisse.
- **Bulle** (über MA200): beim Eintritt alles außer 30 % Reserve; Reserve in
  Tranchen von 10 % nachlegen, wenn der Kurs 0–5 % über dem MA200 und ≥ 5 %
  unter dem 30-Tage-Hoch steht, höchstens alle 10 Tage.
- **Verkauf nur bei Überdehnung:** 50 % des Bestands, sobald der Kurs 40 %
  über dem MA200 steht; alles zurück, sobald er wieder auf 5 % an den MA200
  herankommt. Grundlage: alle drei Überdehnungs-Episoden 2023–2025 drehten
  bei 45–53 % und kehrten binnen 2–4 Monaten zum MA200 zurück (−20 bis −26 %
  von der Spitze). Drei Episoden — deshalb 50 % und nicht 100 %.
- Regimebruch-Ausstieg (Versicherung) vorhanden, aus.

Über 2022–2026 auf echten Tageskerzen: +143 % (Baisse 2022: +25 %; Sparplan
+101 %, Halten +39 %).
In den ersten 200 Tagen ohne MA200 verhält sich der Bot wie in der Baisse.

Die alte Konfluenz-/Leiter-/Cluster-Strategie bleibt unter „Strategie" wählbar.

## Dashboard

- Lila markierte Felder sind die, die die Analyse als maßgeblich ausgewiesen
  hat. Im Chart: MA200 (lila Linie), Regimepuffer (schmales Band), Reserveband
  0–5 % (breiteres Band), Überdehnung +40 % (gestrichelt), MA50 (dünn grau).
- Jede Regel hat ein Häkchen. Häkchen weg = Regel abgeschaltet; der Wert
  bleibt stehen. Die abgeschalteten Regeln stehen in `disabled` der
  Konfiguration und gelten in Backtest, Optimizer und Live gleichermaßen.

## Trendregime und Korrekturausstieg (Konfluenz-Strategie)

Die Teilgewinnmitnahmen nach oben hatten kein Gegenstück nach unten: der Bot
fuhr Korrekturen und Baissen voll investiert mit. Drei Regeln schließen das:

- **Regimefilter.** Unter dem langsamen gleitenden Durchschnitt (Vorgabe
  200 Tage) wird nicht akkumuliert. Der Filter allein reicht nicht — wer beim
  Beginn der Baisse schon voll investiert ist, hat nichts mehr zu blockieren.
- **Korrekturausstieg.** Raus, wenn die Position mindestens `exit_loss_pct`
  im Verlust liegt ODER der Kurs mindestens `exit_drawdown_pct` unter dem Hoch
  seit Positionsaufbau steht. Vorgabe 15 / 20 %. Wahlweise nur unter dem
  langsamen MA (`exit_requires_bear`).
- **Wiedereinstieg.** Nach dem Ausstieg wird das Tief verfolgt. Gekauft wird,
  sobald der Kurs `reentry_bounce_pct` darüber liegt (Vorgabe 5 %) und, falls
  eingeschaltet, über dem schnellen MA (50 Tage). Der Wiedereinstieg ersetzt
  die Konfluenz — er ist das Signal.

Das ist ein Trendfolge-Überbau, und er hat einen bekannten Preis: in einem
Aufwärtsmarkt mit 15–20-%-Korrekturen steigt er aus und steigt teurer wieder
ein. Ob das über den geprüften Zeitraum mehr kostet als es in der Baisse
rettet, zeigt die Regime-Aufteilung im Bericht. Alle Schwellen und Schalter
sind Teil der Variantensuche; die Empfindlichkeitsprüfung zeigt, wie stark
das Ergebnis an `exit_drawdown_pct` hängt.

## Ergebnisse

Trades und Protokoll landen in `hl_sim_results.db` (eigene Datei, WAL,
Tabellen `sim_runs`, `sim_trades`, `sim_journal`). Ein Neustart verliert damit
keinen mehrtägigen Live-Lauf. Abschalten mit `--results ""`.

```sql
SELECT run_id, mode, datetime(started,'unixepoch') FROM sim_runs;
SELECT COUNT(*), SUM(realized) FROM sim_trades WHERE run_id='live-...';
```

## Als Dienst (optional)

Nur sinnvoll für einen mehrtägigen Live-Lauf. Für Backtests unnötig.

```bash
python3 install_sim.py --systemd          # sucht hl_liq.db daneben und eine Ebene hoeher
python3 install_sim.py --systemd --db /pfad/zu/hl_liq.db   # falls woanders
sudo cp systemd/hl-simdash.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now hl-simdash
```

Die Unit enthaelt absolute Pfade: Benutzer, Arbeitsverzeichnis, Python und
Datenbank. Verschiebst du den Ordner, muss sie neu erzeugt und kopiert werden.

Die Unit startet nur das Dashboard. Ein Live-Lauf beginnt weiterhin per Klick
in der Oberfläche, nicht automatisch beim Booten — sonst liefe nach jedem
Neustart eine neue, leere Simulation an.

## Kerzenquellen

`hl_candles.py --sources` zeigt, was gefunden wurde. `klines30` entsteht erst
durch `python3 hl_timestats.py --coin BTC --years 3` und liefert dann drei
Jahre in 30-Minuten-Kerzen — die längste verfügbare Historie und damit die
richtige Quelle für den Mechanik-Test.

Der Simulator misst den Kerzenabstand und hebt `rsi_grid_min`,
`min_seconds_between_buys` und `dip_confirm_seconds` auf mindestens diesen
Wert an. Feiner zu rechnen als die Quelle liefert, würde denselben
Kerzenschluss mehrfach als neue Lage werten.

## Analysieren und optimieren

Der Knopf im Dashboard arbeitet in zwei Schritten.

**Kalibrierung.** Aus dem gewählten Zeitraum werden Tagesspanne,
Kerzenvolatilität, RSI-Verteilung, Rücksetzertiefe und übliche Trendsteigung
gemessen. Daraus ergeben sich Schwellen, ohne dass etwas ausprobiert wird —
die Leiterstufen etwa als Vielfache der Tagesspanne, die RSI-Grenzen als
Perzentile der tatsächlichen Verteilung. Jeder Wert bekommt eine Begründung,
die im Bericht steht.

**Suche.** Um diese Werte herum werden Varianten durchgerechnet — auch die
Anzahl der Leiterstufen und die Frage, ob Notausstieg und Stop überhaupt an
sein sollen.

Unter „gründlich" kommen fünf Prüfungen dazu:

- **Walk-Forward.** Kalibrieren auf 180 Tagen, prüfen auf den folgenden 45,
  Fenster schieben. Zwanzig Prüfpunkte statt einem, jeder außerhalb der Daten,
  auf denen gewählt wurde.
- **Nach Marktphase getrennt.** 90-Tage-Fenster, eingeordnet nach eigener
  Bewegung. Zeigt, ob ein Ergebnis nur aus Aufwärtsphasen stammt.
- **Empfindlichkeit.** Jeder Wert einzeln um ±20 %. Große Spanne heißt
  angepasst, nicht robust.
- **Kosten.** Doppelte Gebühr, dreifache Slippage, beides.
- **Startdatum.** Zwölf verschobene Startpunkte gleicher Länge.

Maßstab ist der **Sparplan**: gleiche Summe, feste Abstände, kein Signal. Das
ist der faire Vergleich für eine Akkumulationsstrategie. Kaufen-und-Halten
steht daneben, setzt aber das gesamte Kapital sofort ein.

Mitgeführt wird außerdem der größte zwischenzeitliche Rückgang — 300 % mit
70 % Einbruch ist etwas anderes als 200 % mit 25 %.

## Audit des Optimizers (4.9.2026)

Sieben Befunde, alle behoben. Der Reihe nach, schwerster zuerst:

1. **Die Suche optimierte einen anderen Bot als den, der danach lief.** Die
   Simulation hebt `dip_confirm_seconds` und `min_seconds_between_buys` auf
   den Kerzenabstand an, der schnelle Durchlauf des Optimizers tat das nicht.
   Alle Trades lagen einen Schritt versetzt. Jetzt nutzen beide dieselbe
   Funktion `apply_spacing`; ein Vergleich Trade für Trade ist identisch.
2. **Die Kalibrierung sah die Prüfhälfte.** Tagesspanne und RSI-Verteilung
   wurden über den ganzen Zeitraum gemessen. Jetzt nur aus dem Training.
3. **Die Auswahl fand auf der Prüfhälfte statt.** Von drei Kandidaten wurde
   der mit der besten Prüfzahl genommen — damit war die Prüfhälfte Teil der
   Suche. Jetzt wird nach Training gewählt, die Prüfzahl bleibt unberührt.
4. **Zeitschwellen aus Kerzenabständen** ergaben bei Minutenkerzen 3 min
   Kaufabstand und 2 min Bodenbestätigung. Jetzt Untergrenzen 30 und 10 min.
5. **Rücksetzer-Schwelle am Median** hieß: jeder zweite Zeitpunkt galt als
   Rücksetzer. Jetzt 75. Perzentil.
6. **Varianten mit fünf Stufen à 35 %** verkauften 175 %. Gedeckelt auf 100.
7. **Der Sparplan zahlte eine Verkaufsgebühr am Ende**, der Bot für offene
   Positionen nicht. Beide werden jetzt zum Marktwert bewertet.

Im Dashboard trennt eine violette Linie im Chart Trainings- und Prüfhälfte.
Alles links davon hat der Optimizer gesehen.

## Die Zahl, auf die zuerst zu schauen ist

Nicht die Rendite, sondern **Gebühren in Prozent der Einsatzsumme**. Sie steht
in der Kopfzeile und wird rot ab 10 %. Im synthetischen Dreijahreslauf lag sie
bei 70 % — knapp 10.000 Käufe. Eine Strategie, die zwei Drittel des Kapitals
in Gebühren umsetzt, ist unabhängig von ihrem Endstand kaputt. Gegenmittel in
dieser Reihenfolge: `min_seconds_between_buys` erhöhen, `order_pct` senken,
`entry_min_score` beziehungsweise `candles_min_score` anheben,
`ladder_rearm_factor` vergrößern.

## Test auf echten Tageskerzen (4.9.2026)

Unter `real/` liegen echte BTC-Tageskerzen 2022–2026 (Binance über den
static-klines-Spiegel) in drei zusammenhängenden Blöcken. `real/load_real.py`
baut daraus Datenbanken, die der Kerzen-Modus direkt lesen kann.

Dabei kamen zwei Fehler im Werkzeug heraus, beide behoben: Trendhorizonte und
Rücksetzer-Fenster waren in Minuten definiert und lagen auf Tageskerzen
innerhalb einer einzigen Kerze; die Nachkaufgrenze von 1,5 % über Einstand
sperrte den Bot auf Tagesbasis nach dem ersten Kauf aus. `apply_spacing`
rechnet Horizonte jetzt in Kerzen, die Nachkaufgrenze wird kalibriert.

Das Ergebnis über alle drei Blöcke: der Bot verliert gegen einen stumpfen
Sparplan — in jedem Block, mit jeder Leiter, mit und ohne Ausstieg. Rückgänge
von 4–9 % gegen 40–50 % beim Markt, aber Renditen um null gegen +10 bis +60 %
beim Sparplan. Einzig in Abwärtsphasen liegt er vorn (+9 Punkte). Ursache ist
nicht die Verkaufs-, sondern die Kauflogik: sie wartet auf Rücksetzer, die ein
Trendmarkt nicht liefert, und ist deshalb meist in Bargeld.

## Was noch offen ist

- `proximity.up_dist` / `dn_dist`: die Einheit wird zur Laufzeit an der
  Größenordnung erkannt (Abstände sind auf 5 % begrenzt, also ist ein Wert
  über 0,06 Prozent und kein Anteil) und intern auf Anteil normiert.
- Alle Schwellen sind von Hand gesetzt und unvalidiert. Die Gewichtung sollte
  aus `--magnet-analyze` und `--analyze` kommen, sobald genug Daten da sind.
- Die Cluster-Zonen entstehen aus Buckets oberhalb von 35 % des größten Werts
  der jeweiligen Seite. Verhält sich die Erkennung im Chart merkwürdig, ist das
  die erste Stelle zum Nachsehen (`zones()` in `hl_sim.py`).
