# Handelssimulation auf dem Liquidationscluster-Recorder

Simuliert Spot-Käufe auf BTC anhand der Daten, die `hl_recorder.py` aufzeichnet.
Es werden **keine echten Orders gesendet** — es gibt keine Börsenanbindung und
keinen Schlüssel im Code.

Der Simulator liest `hl_liq.db` ausschließlich lesend (`mode=ro`) und öffnet
keine eigenen WebSocket- oder REST-Verbindungen. Der Recorder bleibt alleiniger
Schreiber und alleiniger Verbraucher der API-Limits.

## Dateien

| Datei | Zweck |
|---|---|
| `hl_botcore.py` | Point-in-Time-Features mit Datenalter, Kaskaden-Zustandsmaschine, Füllpreis aus `book_ticks` |
| `hl_sim.py` | Lot-Tabelle, Strategie, Backtest- und Live-Runner, Ergebnisprotokoll |
| `hl_candles.py` | Kerzen-Modus: Quellenerkennung, reduzierte Marktsicht, chart-technische Strategie |
| `hl_simdash.py` | Weboberfläche auf Port 8766 |
| `check_schema.py` | Vergleicht die echte Datenbank mit dem, was der Simulator liest |
| `check_gaps.py` | Zeigt, ob fehlende Minuten Startversatz sind oder verstreute Lücken |
| `test_logic.py` | Prüft die Entscheidungszweige (12 Fälle) |
| `make_testdb.py` | Erzeugt eine synthetische Datenbank zum Ausprobieren ohne echte Daten |
| `hl-simdash.service` | Optionale systemd-Unit |

## Installation

Keine. Alles läuft mit der Standardbibliothek von Python 3.11+ — kein `pip`,
keine Abhängigkeiten, nichts, was sich mit dem Recorder beißen könnte.

Dateien neben die bestehenden Skripte legen:

```bash
cd ~/Desktop/bot/hl_liq_project
unzip -o ~/Downloads/hl_simbot.zip && cd hl_simbot
python3 check_schema.py --db ../hl_liq.db   # Schema gegen den Code pruefen
python3 check_gaps.py   --db ../hl_liq.db   # Luecken in den Zeitreihen
python3 test_logic.py                       # 12 bestanden, 0 fehlgeschlagen
```

`check_schema.py` zuerst. Es meldet fehlende Spalten, erkennt Sekunden gegen
Millisekunden an der Groessenordnung und zeigt die Wertebereiche der Felder,
deren Einheit im Schema nicht steht — etwa ob `proximity.up_dist` Prozent oder
ein Anteil ist. Es aendert nichts und oeffnet schreibgeschuetzt.

## Starten

Als normales Programm, kein Dienst nötig:

```bash
python3 hl_simdash.py --db hl_liq.db --host 0.0.0.0
```

Dann im LAN `http://<pi>:8766` öffnen. Port 8765 bleibt dem bestehenden
Dashboard, 8766 ist die Simulation.

Ohne Oberfläche geht es auch:

```bash
python3 hl_candles.py --db hl_liq.db --sources          # welche Kerzenquellen gibt es
python3 hl_candles.py --db hl_liq.db --from 2026-05-01 --to now --step 300
python3 hl_sim.py     --db hl_liq.db --backtest --from 2026-09-01 --to now
python3 hl_sim.py     --db hl_liq.db --live
```

## Die drei Betriebsarten

**Kerzen-Test.** Nur `bars` beziehungsweise die Binance-Rückfüllung. Keine
Cluster, kein Orderbuch, keine Wale. Läuft über Monate und beantwortet, ob die
Ein- und Ausstiegsmechanik überhaupt trägt.

**Volle Daten.** Zusätzlich Heatmap, Orderbuchtiefe, Funding und Wale, also die
Cluster-Logik. Reicht nur so weit zurück wie der Recorder — Beginn 1.9.2026.
Der Zeitraum wird automatisch auf die vorhandenen Daten beschnitten.

**Live.** Der Bot folgt im eingestellten Takt den Daten, die der Recorder gerade
schreibt, und simuliert Orders darauf.

Beide Backtests über denselben Zeitraum laufen zu lassen ist der eigentliche
Zweck: die Differenz ist der Beitrag der Liquidationsdaten.

## Ergebnisse

Trades und Protokoll landen in `hl_sim_results.db` (eigene Datei, WAL,
Tabellen `sim_runs`, `sim_trades`, `sim_journal`). Ein Neustart verliert damit
keinen mehrtägigen Live-Lauf. Abschalten mit `--results ""`.

```sql
SELECT run_id, mode, datetime(started,'unixepoch') FROM sim_runs;
SELECT COUNT(*), SUM(realized) FROM sim_trades WHERE run_id='live-...';
```

## Als Dienst (optional)

Nur sinnvoll für einen mehrtägigen Live-Lauf. Für Backtests unnötig.

```bash
python3 install_sim.py --systemd
sudo cp systemd/hl-simdash.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now hl-simdash
```

Die Unit startet nur das Dashboard. Ein Live-Lauf beginnt weiterhin per Klick
in der Oberfläche, nicht automatisch beim Booten — sonst liefe nach jedem
Neustart eine neue, leere Simulation an.

## Kerzenquellen

`hl_candles.py --sources` zeigt, was gefunden wurde. `klines30` entsteht erst
durch `python3 hl_timestats.py --coin BTC --years 3` und liefert dann drei
Jahre in 30-Minuten-Kerzen — die längste verfügbare Historie und damit die
richtige Quelle für den Mechanik-Test.

Der Simulator misst den Kerzenabstand und hebt `rsi_grid_min`,
`min_seconds_between_buys` und `dip_confirm_seconds` auf mindestens diesen
Wert an. Feiner zu rechnen als die Quelle liefert, würde denselben
Kerzenschluss mehrfach als neue Lage werten.

## Die Zahl, auf die zuerst zu schauen ist

Nicht die Rendite, sondern **Gebühren in Prozent der Einsatzsumme**. Sie steht
in der Kopfzeile und wird rot ab 10 %. Im synthetischen Dreijahreslauf lag sie
bei 70 % — knapp 10.000 Käufe. Eine Strategie, die zwei Drittel des Kapitals
in Gebühren umsetzt, ist unabhängig von ihrem Endstand kaputt. Gegenmittel in
dieser Reihenfolge: `min_seconds_between_buys` erhöhen, `order_pct` senken,
`entry_min_score` beziehungsweise `candles_min_score` anheben,
`ladder_rearm_factor` vergrößern.

## Was noch offen ist

- `proximity.up_dist` / `dn_dist`: die Einheit wird zur Laufzeit an der
  Größenordnung erkannt (Abstände sind auf 5 % begrenzt, also ist ein Wert
  über 0,06 Prozent und kein Anteil) und intern auf Anteil normiert.
- Alle Schwellen sind von Hand gesetzt und unvalidiert. Die Gewichtung sollte
  aus `--magnet-analyze` und `--analyze` kommen, sobald genug Daten da sind.
- Die Cluster-Zonen entstehen aus Buckets oberhalb von 35 % des größten Werts
  der jeweiligen Seite. Verhält sich die Erkennung im Chart merkwürdig, ist das
  die erste Stelle zum Nachsehen (`zones()` in `hl_sim.py`).
