"""Baut eine synthetische hl_liq.db nach dem dokumentierten Schema."""
import math, random, sqlite3, json, os, sys, time

PATH = sys.argv[1] if len(sys.argv) > 1 else "test.db"
DAYS = 5
if os.path.exists(PATH):
    os.remove(PATH)
c = sqlite3.connect(PATH)
rng = random.Random(7)

c.executescript("""
CREATE TABLE bars(ts INT, coin TEXT, open REAL, high REAL, low REAL, close REAL,
                  volume REAL, trades INT, PRIMARY KEY(ts,coin));
CREATE TABLE bars10(ts INT, coin TEXT, open REAL, high REAL, low REAL, close REAL,
                  vol_buy REAL, vol_sell REAL, trades INT,
                  n_liq INT, liq_notional REAL, max_sz REAL, PRIMARY KEY(ts,coin));
CREATE TABLE ctx_bars(ts INT, coin TEXT, mark_px REAL, oracle_px REAL, mid_px REAL,
                  funding REAL, oi REAL, premium REAL, PRIMARY KEY(ts,coin));
CREATE TABLE book_summary(ts INT, coin TEXT, bid REAL, ask REAL, spread_bps REAL,
                  bid_10 REAL, bid_25 REAL, bid_50 REAL, bid_100 REAL,
                  ask_10 REAL, ask_25 REAL, ask_50 REAL, ask_100 REAL,
                  imb_50 REAL, PRIMARY KEY(ts,coin));
CREATE TABLE heatmap(ts INT, coin TEXT, bucket_px REAL, side TEXT, notional REAL,
                  n_pos INT, lev_wavg REAL, entry_wavg REAL, cross_share REAL);
CREATE TABLE proximity(ts INT, coin TEXT, px REAL, up_px REAL, up_notional REAL,
                  up_dist REAL, dn_px REAL, dn_notional REAL, dn_dist REAL,
                  PRIMARY KEY(ts,coin));
CREATE TABLE whale_positions(ts INT, addr TEXT, coin TEXT, event TEXT, side TEXT,
                  size REAL, pos_value REAL, entry_px REAL, liq_px REAL,
                  leverage REAL, upnl REAL, mark_px REAL, delta_usd REAL);
CREATE TABLE snapshot_meta(ts INT PRIMARY KEY, n_addresses INT, n_with_pos INT,
                  n_positions INT, n_stale_dropped INT, age_median REAL,
                  age_p90 REAL, backlog INT, uptime REAL);
CREATE TABLE tick_events(id INTEGER PRIMARY KEY, coin TEXT, t_trigger INT,
                  t_start INT, t_end INT, reason TEXT, move_pct REAL,
                  px_before REAL, px_trigger REAL, px_extreme REAL,
                  n_ticks INT, n_liqs INT, complete INT);
CREATE TABLE book_ticks(event_id INT, ts_ms INT, coin TEXT, levels TEXT);
CREATE TABLE bnc_bars(ts INT, coin TEXT, open REAL, high REAL, low REAL,
                  close REAL, volume REAL, PRIMARY KEY(ts,coin));
CREATE TABLE klines30(ts INT, coin TEXT, open REAL, high REAL, low REAL,
                  close REAL, volume REAL, PRIMARY KEY(ts,coin));
""")

now = int(time.time())
t0 = now - DAYS * 86400
px = 78000.0
bars, ctx, book, bars10, heat, prox, meta, whales = [], [], [], [], [], [], [], []
cascade_until = 0
prices = {}

for m in range(DAYS * 1440):
    ts = t0 + m * 60
    drift = 0.00004 * math.sin(m / 900.0)
    px *= math.exp(rng.gauss(drift, 0.0011))
    if rng.random() < 0.0025:                 # gelegentliche Kaskade
        cascade_until = ts + rng.randint(120, 420)
        px *= (1 - rng.uniform(0.004, 0.012))
    o = px * (1 + rng.gauss(0, 0.0002))
    h, l = max(o, px) * 1.0004, min(o, px) * 0.9996
    bars.append((ts, "BTC", o, h, l, px, rng.uniform(2, 14), rng.randint(40, 400)))
    prices[ts] = px
    ctx.append((ts, "BTC", px * 1.00002, px, px, rng.gauss(0, 3e-5),
                3.1e4, rng.gauss(0, 1e-5)))
    prox.append((ts, "BTC", px, px * 1.018, 9e6, 1.8, px * 0.985, 7e6, 1.5))

    for k in range(6):                        # 10-s-Bars
        t10 = ts + k * 10
        casc = t10 < cascade_until
        bars10.append((t10, "BTC", px, px, px, px,
                       rng.uniform(0.1, 1), rng.uniform(0.1, 1), 20,
                       rng.randint(1, 6) if casc else 0,
                       rng.uniform(2e4, 3e5) if casc else 0.0, 1.0))
    for k in range(12):                       # 5-s-Buchkennzahlen
        t5 = ts + k * 5
        depth = rng.uniform(3e5, 9e5) * (0.25 if t5 < cascade_until else 1.0)
        book.append((t5, "BTC", px * 0.99995, px * 1.00005, 1.0,
                     depth * .2, depth * .5, depth, depth * 1.8,
                     depth * .2, depth * .5, depth * 1.05, depth * 1.9,
                     rng.gauss(0, .28)))

    if m % 10 == 0:                           # Heatmap alle 10 min
        base = round(math.log(px) / math.log1p(0.0025))
        for k in range(-40, 41):
            if k == 0:
                continue
            bp = math.exp((base + k) * math.log1p(0.0025))
            size = abs(rng.gauss(0, 1)) * 1.5e6
            if k in (6, 7, 8):                # bewusst großes Short-Cluster
                size *= 9
            heat.append((ts, "BTC", bp, "long" if k < 0 else "short",
                         size, rng.randint(2, 40), 12.0, bp * .99, .7))
        meta.append((ts, 79000, 39000, 41000, 900, 420.0, 1500.0, 30, 99.0))
    if m % 240 == 0:
        whales.append((ts, f"0x{m:040x}", "BTC", "open",
                       "long" if rng.random() < .6 else "short",
                       1.0, 2.5e7, px, px * .8, 8, 0, px,
                       rng.uniform(1e6, 4e7)))

c.executemany("INSERT INTO bars VALUES(?,?,?,?,?,?,?,?)", bars)
c.executemany("INSERT INTO ctx_bars VALUES(?,?,?,?,?,?,?,?)", ctx)
c.executemany("INSERT INTO book_summary VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", book)
c.executemany("INSERT INTO bars10 VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", bars10)
c.executemany("INSERT INTO heatmap VALUES(?,?,?,?,?,?,?,?,?)", heat)
c.executemany("INSERT INTO proximity VALUES(?,?,?,?,?,?,?,?,?)", prox)
c.executemany("INSERT INTO snapshot_meta VALUES(?,?,?,?,?,?,?,?,?)", meta)
c.executemany("INSERT INTO whale_positions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", whales)

# Ereignisfenster mit Buch-Snapshots
evs, bt = [], []
for i in range(1, 9):
    trig = t0 + rng.randint(3600, DAYS * 86400 - 3600)
    p = prices.get((trig // 60) * 60, px)
    evs.append((i, "BTC", trig*1000, (trig - 300)*1000, (trig + 600)*1000,
                "control" if i % 3 == 0 else "move60",
                -1.1, p, p, p * .99, 500, 0 if i % 3 == 0 else 12, 1))
    for k in range(0, 900, 15):
        tsec = trig - 300 + k
        ref = prices.get((tsec // 60) * 60, p)      # Buch folgt dem Kurs
        lv = [[[ref * (1 - 0.0002 * j), rng.uniform(.05, .6)] for j in range(1, 11)],
              [[ref * (1 + 0.0002 * j), rng.uniform(.05, .6)] for j in range(1, 11)]]
        bt.append((i, tsec * 1000, "BTC", json.dumps(lv)))
c.executemany("INSERT INTO tick_events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", evs)
c.executemany("INSERT INTO book_ticks VALUES(?,?,?,?)", bt)

# Binance-Rückfüllung: 120 Tage 15-Minuten-Kerzen, Zeit in Millisekunden
bp = 61000.0
bnc = []
for i in range(120 * 96):
    t = t0 - 120 * 86400 + i * 900
    bp *= math.exp(rng.gauss(0.00012, 0.004))
    bnc.append((t, "BTC", bp, bp * 1.003, bp * 0.997, bp, rng.uniform(10, 90)))
c.executemany("INSERT INTO bnc_bars VALUES(?,?,?,?,?,?,?)", bnc)

# klines30: drei Jahre 30-Minuten-Kerzen, wie hl_timestats sie anlegt
kp, k30 = 27000.0, []
for i in range(3 * 365 * 48):
    t = t0 - 3 * 365 * 86400 + i * 1800
    kp *= math.exp(rng.gauss(0.00007, 0.006))
    k30.append((t, "BTC", kp, kp * 1.004, kp * 0.996, kp, rng.uniform(20, 200)))
c.executemany("INSERT INTO klines30 VALUES(?,?,?,?,?,?,?)", k30)
print(f"  klines30: {len(k30):,} 30-Minuten-Kerzen")

c.commit()
print(f"{PATH}: {len(bars):,} bars, {len(bars10):,} bars10, {len(heat):,} heatmap, "
      f"{len(bnc):,} bnc_bars, {len(evs)} Ereignisse")
c.close()
