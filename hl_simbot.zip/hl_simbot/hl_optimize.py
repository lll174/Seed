"""
hl_optimize.py — leitet Parameter aus dem Kursverlauf ab und prüft sie.

Zwei Schritte, bewusst getrennt:

1. **Kalibrierung.** Aus dem gewählten Zeitraum werden messbare Eigenschaften
   bestimmt — Tagesspanne, Kerzenvolatilität, RSI-Verteilung, typische Tiefe
   der Rücksetzer, übliche Trendsteigung. Daraus ergeben sich Schwellen, die
   zum Markt passen, ohne dass etwas ausprobiert wird. Jeder Wert bekommt
   eine Begründung, die im Dashboard sichtbar ist.

2. **Suche.** Um die kalibrierten Werte herum werden Varianten durchgerechnet.

Der Zeitraum wird dafür zeitlich halbiert: kalibriert und gesucht wird auf der
ersten Hälfte, ausgewiesen wird das Ergebnis auf der zweiten. Beides zu
mischen, erzeugt eine Zahl, die nur beschreibt, wie gut sich Parameter an
bekannte Daten anschmiegen lassen — und die in der Zukunft nicht hält.

Damit die Suche auf einem Pi durchführbar bleibt, wird die Marktsicht genau
einmal berechnet und dann für jede Variante wiederverwendet. Nur die
Entscheidungsregeln unterscheiden sich zwischen den Varianten; die Messgrößen
(Raster, Trendhorizonte, Rücksetzerfenster) stehen vorher fest.
"""

from __future__ import annotations

import math
import random
import statistics as st
from dataclasses import dataclass, field, replace

from hl_sim import Features, Portfolio, SimConfig, View
from hl_candles import CandleEngine, CandleStrategy, apply_spacing


# ---------------------------------------------------------------------------
# Schlanke Marktsicht: nur was die Entscheidungen brauchen
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class Frame:
    ts: int
    px: float
    rsi: float | None
    fvg_bull: bool
    pullback: float
    velocity: float
    hourly: float
    trend: tuple
    ma_fast: float | None = None
    ma_slow: float | None = None
    hi30: float | None = None


HORIZONS = [60, 120, 180, 360]


def frame_view(f: Frame, coin: str, horizons: list[int]) -> View:
    ft = Features(ts=f.ts, coin=coin, mark_px=f.px, mid_px=f.px,
                  age_ctx=0.0, age_book=0.0)
    ft.hourly_notional = f.hourly
    ft.__dict__["_extra"] = {"pullback_pct": f.pullback}
    fvgs = [{"kind": "bull", "inside": True, "dist_pct": 0.0,
             "lo": f.px, "hi": f.px, "ts": f.ts}] if f.fvg_bull else []
    return View(ts=f.ts, f=ft, px=f.px, rsi=f.rsi, fvgs=fvgs,
                ma_fast=f.ma_fast, ma_slow=f.ma_slow, hi30=f.hi30,
                trend=dict(zip(horizons, f.trend)),
                clusters={"snapshot_ts": None, "age_s": None,
                          "above": None, "below": None, "buckets": []},
                whales={"long": 0.0, "short": 0.0, "ratio": 1.0},
                velocity_pct=f.velocity, depth_median_1h=None)


def collect(engine: CandleEngine, t_from: int, t_to: int,
            on_progress=None) -> tuple[list[Frame], list[int]]:
    """Einmaliger Durchlauf. Danach ist jede Variante fast umsonst."""
    engine.preload(t_from, t_to)
    sp = getattr(engine, "spacing", 60)
    cfg = engine.cfg
    if apply_spacing(cfg, sp):
        engine.preload(t_from, t_to)      # Raster kann sich geaendert haben
    horizons = sorted(set(cfg.trend_horizons_min + [cfg.candles_trend_min]))
    step = max(cfg.step_seconds, sp)
    frames: list[Frame] = []
    total = max(1, t_to - t_from)
    ts = t_from
    while ts <= t_to:
        v = engine.view(ts)
        if v is not None:
            near = cfg.fvg_near_pct
            frames.append(Frame(
                ts=v.ts, px=v.px, rsi=v.rsi,
                fvg_bull=any(g["kind"] == "bull"
                             and (g["inside"] or g["dist_pct"] <= near)
                             for g in v.fvgs),
                pullback=v.f.__dict__.get("_extra", {}).get("pullback_pct", 0.0),
                velocity=v.velocity_pct,
                hourly=v.f.hourly_notional or 0.0,
                trend=tuple(v.trend.get(h) for h in horizons),
                ma_fast=v.ma_fast, ma_slow=v.ma_slow, hi30=v.hi30))
        ts += step
        if on_progress and len(frames) % 500 == 0:
            on_progress((ts - t_from) / total)
    return frames, horizons


def slice_frames(frames: list[Frame], a: int, b: int) -> list[Frame]:
    import bisect
    ts = [f.ts for f in frames]
    return frames[bisect.bisect_left(ts, a):bisect.bisect_right(ts, b)]


# ---------------------------------------------------------------------------
# Kennzahlen des Zeitraums
# ---------------------------------------------------------------------------


def q(values: list[float], p: float) -> float:
    vs = sorted(v for v in values if v is not None)
    if not vs:
        return 0.0
    k = min(len(vs) - 1, max(0, int(round(p * (len(vs) - 1)))))
    return vs[k]


def market_stats(rows: list[tuple], frames: list[Frame],
                 spacing: int = 60) -> dict:
    if len(rows) < 50 or not frames:
        return {}

    # Rendite je Kerze
    rets = [abs(b[4] - a[4]) / a[4] * 100.0
            for a, b in zip(rows, rows[1:]) if a[4]]
    # Tagesspanne aus den Kerzen eines Kalendertages
    days: dict[int, list] = {}
    for t, o, h, l, c, v in rows:
        days.setdefault(t // 86400, []).append((h, l, c))
    ranges = []
    for items in days.values():
        # Eine Kerze je Tag (Tageskerzen) ist der ganze Tag — nicht ueberspringen.
        hi = max(x[0] for x in items)
        lo = min(x[1] for x in items)
        cl = items[-1][2]
        if cl and hi > lo:
            ranges.append((hi - lo) / cl * 100.0)

    rsis = [f.rsi for f in frames if f.rsi is not None]
    pulls = [f.pullback for f in frames if f.pullback > 0]
    slopes = [abs(f.trend[-1]) for f in frames if f.trend and f.trend[-1] is not None]

    first, last = rows[0][4], rows[-1][4]
    span_days = max(1.0, (rows[-1][0] - rows[0][0]) / 86400.0)

    return {
        "n_candles": len(rows),
        "spacing_s": spacing,
        "span_days": round(span_days, 1),
        "candle_move_med": round(st.median(rets), 3) if rets else 0.0,
        "candle_move_p90": round(q(rets, 0.90), 3),
        "day_range_med": round(st.median(ranges), 2) if ranges else 0.0,
        "day_range_p90": round(q(ranges, 0.90), 2),
        "rsi_p20": round(q(rsis, 0.20), 1),
        "rsi_p80": round(q(rsis, 0.80), 1),
        "pullback_med": round(st.median(pulls), 2) if pulls else 0.0,
        "pullback_p75": round(q(pulls, 0.75), 2),
        "pullback_p75": round(q(pulls, 0.75), 2),
        "slope_med": round(st.median(slopes), 3) if slopes else 0.0,
        "buyhold_pct": round((last - first) / first * 100.0, 1) if first else 0.0,
        "px_first": first, "px_last": last,
    }


# ---------------------------------------------------------------------------
# Ableitung: Werte mit Begründung
# ---------------------------------------------------------------------------


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def derive(s: dict, base: SimConfig) -> tuple[SimConfig, list[dict]]:
    cfg = replace(base)
    why: list[dict] = []

    def set_(name, value, reason, unit=""):
        if base.strategy == "regime" and name not in (
                "step_seconds", "min_order_usd"):
            return          # Konfluenz-Werte sind fuer die Regime-Strategie bedeutungslos
        setattr(cfg, name, value)
        why.append({"param": name, "value": value, "unit": unit,
                    "reason": reason})

    dr = s.get("day_range_med") or 2.0
    cm = s.get("candle_move_med") or 0.2
    sp = s.get("spacing_s") or 60

    # --- Verkaufsleiter an der Tagesspanne ausrichten
    ladder = [
        {"gain_pct": round(clamp(dr * 0.6, 0.4, 20), 2), "sell_pct": 20},
        {"gain_pct": round(clamp(dr * 1.3, 0.8, 35), 2), "sell_pct": 25},
        {"gain_pct": round(clamp(dr * 2.2, 1.5, 60), 2), "sell_pct": 25},
    ]
    set_("ladder", ladder,
         f"Tagesspanne im Median {dr:.2f} %. Stufen bei 0,6 / 1,3 / 2,2 "
         f"Tagesspannen — die erste innerhalb eines üblichen Tages "
         f"erreichbar, die letzte nur in einer Bewegung.")

    set_("dip_buy_pct", round(clamp(dr * 0.35, 0.2, 6), 2),
         f"Ein Drittel der Tagesspanne. Darunter wäre der Nachkauf Rauschen.", "%")
    set_("max_add_above_avg_pct", round(clamp(dr * 3.0, 1.0, 30), 1),
         "Drei Tagesspannen über dem Einstand darf noch nachgekauft werden. "
         "Ein enger Wert sperrt den Bot nach dem ersten Kauf aus, sobald "
         "der Kurs läuft.", "%")

    if base.stop_loss_pct > 0:
        set_("stop_loss_pct", round(clamp(dr * 2.5, 2, 25), 1),
             f"2,5 Tagesspannen unter dem Einstand — außerhalb der normalen "
             f"Schwankung, greift also nur bei einem echten Bruch.", "%")
    if base.crash_sell_pct > 0:
        set_("crash_drop_pct", round(clamp(s.get("candle_move_p90", cm) * 2.0,
                                           0.3, 8), 2),
             f"Doppelter Wert der stärksten 10 % aller Kerzenbewegungen "
             f"({s.get('candle_move_p90', 0):.2f} %).", "%")
    set_("crash_window_s", int(sp),
         f"Ein Kerzenabstand ({sp} s) — feiner kann die Quelle nicht messen.", "s")

    # --- Schwellen aus den Verteilungen
    set_("rsi_buy", round(clamp(s.get("rsi_p20", 40), 20, 48), 1),
         f"20. Perzentil der RSI-Verteilung in diesem Zeitraum. Ein fester "
         f"Wert von 30 wäre in ruhigen Phasen nie erreicht worden.")
    set_("rsi_sell", round(clamp(s.get("rsi_p80", 70), 55, 88), 1),
         f"80. Perzentil der RSI-Verteilung.")
    set_("candles_pullback_pct", round(clamp(s.get("pullback_med", 1.0),
                                             0.3, 8), 2),
         f"Median aller Rücksetzer vom Hoch der letzten "
         f"{base.candles_pullback_hours} h. Die Hälfte der Gelegenheiten "
         f"liegt damit über der Schwelle.", "%")
    set_("trend_flat_pct_per_h", round(clamp(s.get("slope_med", 0.08) * 0.8,
                                             0.01, 2), 3),
         f"80 % der üblichen Steigung ({s.get('slope_med', 0):.3f} %/h). "
         f"Darunter ist eine Bewegung kein Trend, sondern Rauschen.", "%/h")

    # --- Kapitalaufteilung schlüssig machen
    slots = int(clamp(base.max_lots, 4, 40))
    set_("order_pct", round(100.0 / slots, 2),
         f"{slots} Einstiegsplätze ergeben {100.0/slots:.2f} % je Tranche. "
         f"Vorher konnten die Plätze rechnerisch gar nicht alle belegt "
         f"werden — die Grenze war wirkungslos.", "%")
    set_("min_order_usd", round(max(10.0, base.budget_usd * 0.002), 2),
         "0,2 % der Einsatzsumme, mindestens 10 USD, damit die Gebühr "
         "nicht den Gewinn der Tranche übersteigt.", "USD")

    set_("min_seconds_between_buys", int(max(sp * 3, sp)),
         f"Drei Kerzenabstände. Verhindert, dass alle Tranchen in dieselbe "
         f"Bewegung laufen.", "s")
    set_("dip_confirm_seconds", int(max(sp * 2, sp)),
         f"Zwei Kerzenabstände ohne neues Tief.", "s")
    set_("step_seconds", int(sp),
         f"Auflösung der Quelle. Feiner zu rechnen erzeugt nur "
         f"Wiederholungen.", "s")
    return cfg, why


# ---------------------------------------------------------------------------
# Schneller Durchlauf über die zwischengespeicherte Marktsicht
# ---------------------------------------------------------------------------


def fast_replay(frames: list[Frame], cfg: SimConfig, horizons: list[int]) -> dict:
    if len(frames) < 20:
        return {"return_pct": 0.0, "n_buys": 0, "n_sells": 0, "fees": 0.0,
                "fees_pct_budget": 0.0, "hit_rate": None, "max_dd_pct": 0.0,
                "invested_pct": 0.0, "open_lots": 0, "equity": cfg.budget_usd,
                "realized": 0.0}
    cfg = replace(cfg)
    if len(frames) > 1:
        apply_spacing(cfg, max(1, frames[1].ts - frames[0].ts))
    from hl_sim import make_strategy
    pf = Portfolio(cfg)
    strat = make_strategy(cfg, candles=True)
    fee = cfg.fee_bps_taker
    slip = cfg.candles_slippage_bps / 1e4
    peak_eq, max_dd, in_market = cfg.budget_usd, 0.0, 0
    for fr in frames:
        v = frame_view(fr, cfg.coin, horizons)
        d = strat.want_sell(v, pf)
        if d.action == "sell":
            frac = pf.fraction_for(d)
            pf.sell_fraction(fr.ts, fr.px * (1 - slip), frac, fee, d.reason)
        else:
            b = strat.want_buy(v, pf)
            if b.action == "buy":
                pf.buy(fr.ts, fr.px * (1 + slip), b.amount, fee, b.reason)
        eq = pf.equity(fr.px)
        peak_eq = max(peak_eq, eq)
        if peak_eq:
            max_dd = max(max_dd, (peak_eq - eq) / peak_eq * 100.0)
        in_market += 1 if pf.lots else 0

    px = frames[-1].px if frames else 0.0
    sells = [t for t in pf.trades if t.side == "sell"]
    wins = [t for t in sells if t.realized > 0]
    eq = pf.equity(px)
    return {
        "return_pct": round((eq - cfg.budget_usd) / cfg.budget_usd * 100.0, 2),
        "equity": round(eq, 2),
        "realized": round(pf.realized, 2),
        "fees": round(pf.fees, 2),
        "fees_pct_budget": round(pf.fees / cfg.budget_usd * 100.0, 2),
        "n_buys": len(pf.trades) - len(sells),
        "n_sells": len(sells),
        "hit_rate": round(len(wins) / len(sells) * 100.0, 1) if sells else None,
        "max_dd_pct": round(max_dd, 1),
        "invested_pct": round(in_market / len(frames) * 100.0, 1),
        "open_lots": len(pf.lots),
    }


def buyhold_pct(frames: list[Frame]) -> float:
    if len(frames) < 2 or not frames[0].px:
        return 0.0
    return round((frames[-1].px - frames[0].px) / frames[0].px * 100.0, 2)


def dca_pct(frames: list[Frame], cfg: SimConfig, n_tranchen: int = 20) -> float:
    """
    Sparplan: gleiche Summe, feste Abstände, kein Signal, kein Verkauf.
    Der faire Maßstab für eine Akkumulationsstrategie — Kaufen-und-Halten
    setzt dagegen das gesamte Kapital sofort ein und ist deshalb in einem
    steigenden Markt kaum zu schlagen, ohne dass das etwas über die
    Signallogik aussagt.
    """
    if len(frames) < n_tranchen:
        return 0.0
    per = cfg.budget_usd / n_tranchen
    fee = cfg.fee_bps_taker / 1e4
    step = max(1, len(frames) // n_tranchen)
    size = 0.0
    for k in range(n_tranchen):
        i = min(len(frames) - 1, k * step)
        if frames[i].px:
            size += (per - per * fee) / frames[i].px
    end = size * frames[-1].px          # Marktwert, wie beim Bot
    return round((end - cfg.budget_usd) / cfg.budget_usd * 100.0, 2)


def score(res: dict, bench: float) -> float:
    """
    Überrendite gegenüber dem Sparplan, mit Abzug für Umschlag und für tiefe
    zwischenzeitliche Einbrüche. Ohne diese Abzüge gewinnt regelmäßig eine
    Variante, die sich Rendite über Handelsfrequenz oder über das Aushalten
    eines 70-Prozent-Einbruchs erkauft.
    """
    if (res.get("n_sells") or 0) < 3:
        return -1e9
    churn = max(0.0, res["fees_pct_budget"] - 5.0) * 0.8
    dd = max(0.0, res.get("max_dd_pct", 0.0) - 35.0) * 0.5
    return res["return_pct"] - bench - churn - dd


# ---------------------------------------------------------------------------
# Prüfungen
# ---------------------------------------------------------------------------


def regime_report(frames: list[Frame], cfg: SimConfig, horizons: list[int],
                  window_days: int = 90) -> dict:
    """
    Feste Fenster, jedes für sich klassifiziert und gerechnet. Zeigt, ob ein
    Ergebnis nur aus Aufwärtsphasen stammt — die wichtigste Einzelfrage bei
    einer Halten-Strategie.
    """
    if not frames:
        return {}
    span = window_days * 86400
    t0, t1 = frames[0].ts, frames[-1].ts
    buckets = {"auf": [], "ab": [], "seit": []}
    detail = []
    a = t0
    while a + span <= t1:
        w = slice_frames(frames, a, a + span)
        if len(w) > 50 and w[0].px:
            move = (w[-1].px - w[0].px) / w[0].px * 100.0
            kind = "auf" if move > 10 else ("ab" if move < -10 else "seit")
            r = fast_replay(w, cfg, horizons)
            bench = dca_pct(w, cfg)
            buckets[kind].append(r["return_pct"] - bench)
            detail.append({"von": w[0].ts, "markt": round(move, 1),
                           "regime": kind, "bot": r["return_pct"],
                           "sparplan": bench, "dd": r["max_dd_pct"]})
        a += span
    out = {"fenster": detail, "tage_je_fenster": window_days}
    for k, v in buckets.items():
        out[k] = {"n": len(v),
                  "median_vs_sparplan": round(st.median(v), 1) if v else None}
    return out


def sensitivity(frames: list[Frame], cfg: SimConfig,
                horizons: list[int]) -> list[dict]:
    """Jeden Wert um ±20 %. Flaches Feld heißt robust, Zacken heißt angepasst."""
    base_r = fast_replay(frames, cfg, horizons)["return_pct"]
    params = (["regime_buffer_pct", "bear_tranches", "bear_gap_days", "bear_dip_pct",
               "reserve_pct", "reserve_band_hi", "overheat_level_pct",
               "overheat_sell_pct", "ma_slow_days"]
              if cfg.strategy == "regime" else
              ["dip_buy_pct", "candles_pullback_pct", "rsi_buy", "rsi_sell",
               "trend_flat_pct_per_h", "min_seconds_between_buys",
               "ladder_rearm_factor", "order_pct",
               "exit_loss_pct", "exit_drawdown_pct", "reentry_bounce_pct",
               "ma_slow_days", "max_add_above_avg_pct"])
    out = []
    for p in params:
        v0 = getattr(cfg, p, None)
        if not isinstance(v0, (int, float)) or isinstance(v0, bool) or not v0:
            continue
        got = []
        for k in (0.8, 1.2):
            c = replace(cfg)
            setattr(c, p, type(v0)(v0 * k))
            got.append(fast_replay(frames, c, horizons)["return_pct"])
        out.append({"param": p, "basis": base_r, "minus20": round(got[0], 1),
                    "plus20": round(got[1], 1),
                    "spanne": round(max(got) - min(got), 1)})
    got = []
    for k in (0.8, 1.2):
        c = replace(cfg)
        c.ladder = [{"gain_pct": round(x["gain_pct"] * k, 2),
                     "sell_pct": x["sell_pct"]} for x in cfg.ladder]
        got.append(fast_replay(frames, c, horizons)["return_pct"])
    out.append({"param": "Leiterstufen gesamt", "basis": base_r,
                "minus20": round(got[0], 1), "plus20": round(got[1], 1),
                "spanne": round(max(got) - min(got), 1)})
    out.sort(key=lambda x: -x["spanne"])
    return out


def cost_test(frames: list[Frame], cfg: SimConfig,
              horizons: list[int]) -> list[dict]:
    out = []
    for name, fee, slip in (
            ("wie eingestellt", cfg.fee_bps_taker, cfg.candles_slippage_bps),
            ("doppelte Gebühr", cfg.fee_bps_taker * 2, cfg.candles_slippage_bps),
            ("dreifache Slippage", cfg.fee_bps_taker,
             cfg.candles_slippage_bps * 3),
            ("beides", cfg.fee_bps_taker * 2, cfg.candles_slippage_bps * 3)):
        c = replace(cfg)
        c.fee_bps_taker, c.candles_slippage_bps = fee, slip
        r = fast_replay(frames, c, horizons)
        out.append({"fall": name, "gebuehr_bps": round(fee, 1),
                    "slippage_bps": round(slip, 1),
                    "return_pct": r["return_pct"],
                    "fees_pct": r["fees_pct_budget"]})
    return out


def start_robustness(frames: list[Frame], cfg: SimConfig, horizons: list[int],
                     n: int = 12, window_days: int = 365) -> dict:
    """Gleiche Werte, verschobene Startpunkte gleicher Länge."""
    if len(frames) < 100:
        return {}
    span = window_days * 86400
    t0, t1 = frames[0].ts, frames[-1].ts
    if t1 - t0 < span * 1.2:
        span = max(30 * 86400, (t1 - t0) // 3)
    starts = [t0 + int((t1 - span - t0) * i / max(1, n - 1)) for i in range(n)]
    res = []
    for a in starts:
        w = slice_frames(frames, a, a + span)
        if len(w) > 50:
            r = fast_replay(w, cfg, horizons)
            res.append({"von": a, "return_pct": r["return_pct"],
                        "sparplan": dca_pct(w, cfg), "dd": r["max_dd_pct"]})
    vals = [x["return_pct"] - x["sparplan"] for x in res]
    return {"fenster_tage": span // 86400, "laeufe": res,
            "median_vs_sparplan": round(st.median(vals), 1) if vals else None,
            "schlechtester": round(min(vals), 1) if vals else None,
            "bester": round(max(vals), 1) if vals else None,
            "anteil_besser": round(sum(1 for v in vals if v > 0)
                                   / len(vals) * 100.0) if vals else None}


def walk_forward(frames: list[Frame], base: SimConfig, horizons: list[int],
                 rows: list[tuple], spacing: int, n_cand: int,
                 train_days: int = 180, test_days: int = 45,
                 on_progress=None) -> dict:
    """
    Kalibrieren auf einem Fenster, prüfen auf dem folgenden, weiterschieben.
    Jede einzelne Prüfung liegt außerhalb der Daten, auf denen gewählt wurde.
    """
    t0, t1 = frames[0].ts, frames[-1].ts
    tr, te = train_days * 86400, test_days * 86400
    if t1 - t0 < tr + te:
        tr = max(30 * 86400, (t1 - t0) * 2 // 3)
        te = max(10 * 86400, (t1 - t0 - tr) // 2)
    starts = list(range(t0, t1 - tr - te + 1, te))
    if not starts:
        return {"error": "Zeitraum zu kurz für Walk-Forward."}
    folds = []
    for i, a in enumerate(starts):
        f_tr = slice_frames(frames, a, a + tr)
        f_te = slice_frames(frames, a + tr, a + tr + te)
        if len(f_tr) < 40 or len(f_te) < 8:
            continue
        s_ = market_stats([r for r in rows if a <= r[0] <= a + tr],
                          f_tr, spacing)
        cal, _ = derive(s_, base)
        bench_tr = dca_pct(f_tr, cal)
        best, best_sc = cal, -1e18
        for c in variants(cal, n_cand, seed=1000 + i):
            sc = score(fast_replay(f_tr, c, horizons), bench_tr)
            if sc > best_sc:
                best, best_sc = c, sc
        r_te = fast_replay(f_te, best, horizons)
        bench_te = dca_pct(f_te, best)
        folds.append({"von": a + tr, "bis": a + tr + te,
                      "bot": r_te["return_pct"], "sparplan": bench_te,
                      "markt": buyhold_pct(f_te),
                      "diff": round(r_te["return_pct"] - bench_te, 2),
                      "dd": r_te["max_dd_pct"], "kaeufe": r_te["n_buys"]})
        if on_progress:
            on_progress((i + 1) / len(starts))
    if not folds:
        return {"error": "Keine vollständigen Fenster."}
    diffs = [f["diff"] for f in folds]
    comp_bot = comp_dca = 1.0
    for f in folds:
        comp_bot *= (1 + f["bot"] / 100.0)
        comp_dca *= (1 + f["sparplan"] / 100.0)
    return {"train_days": tr // 86400, "test_days": te // 86400,
            "n_folds": len(folds), "folds": folds,
            "median_diff": round(st.median(diffs), 2),
            "anteil_besser": round(sum(1 for d in diffs if d > 0)
                                   / len(diffs) * 100.0),
            "kumuliert_bot": round((comp_bot - 1) * 100.0, 1),
            "kumuliert_sparplan": round((comp_dca - 1) * 100.0, 1),
            "schlechtestes_fenster": round(min(diffs), 2)}


# ---------------------------------------------------------------------------
# Suche
# ---------------------------------------------------------------------------


def variants(base: SimConfig, n: int, seed: int = 7) -> list[SimConfig]:
    rng = random.Random(seed)
    out = [replace(base)]
    if base.strategy == "regime":
        # Vorher wurden hier nur Konfluenz-Parameter variiert — fuer die
        # Regime-Strategie waren damit alle Varianten identisch.
        for _ in range(max(0, n - 1)):
            c = replace(base)
            c.regime_buffer_pct = rng.choice([2.0, 3.0, 5.0, 8.0])
            c.bear_tranches = rng.choice([15, 20, 30, 40])
            c.bear_gap_days = rng.choice([7, 10, 15, 21, 30])
            c.bear_dip_pct = rng.choice([0.0, 5.0, 8.0, 12.0])
            c.bear_depth1_pct = rng.choice([0.0, 10.0, 10.0, 15.0])
            c.reserve_pct = rng.choice([0.0, 15.0, 30.0, 50.0])
            c.reserve_band_hi = rng.choice([3.0, 5.0, 10.0, 15.0])
            c.reserve_dip_pct = rng.choice([0.0, 5.0, 8.0])
            c.reserve_gap_days = rng.choice([5, 10, 20])
            c.overheat_sell_pct = rng.choice([0.0, 30.0, 50.0, 100.0])
            c.overheat_level_pct = rng.choice([30.0, 35.0, 40.0, 45.0, 50.0])
            c.overheat_rebuy_pct = rng.choice([0.0, 5.0, 10.0])
            c.regime_exit = rng.choice([0, 0, 1])
            c.regime_reentry_pct = rng.choice([50.0, 100.0])
            out.append(c)
        return out
    for _ in range(max(0, n - 1)):
        c = replace(base)
        # Wie viele Stufen es geben soll, ist selbst eine Entscheidung
        top = max((x["gain_pct"] for x in base.ladder), default=5.0)
        k = rng.choice([2, 3, 3, 4, 5])
        gs = rng.choice([0.6, 0.8, 1.0, 1.3, 1.7, 2.2])
        keep = rng.choice([20, 25, 30, 35])
        runner = rng.choice([0, 10, 20, 30])
        keep = min(keep, (100 - runner) / k)      # nie mehr als 100 % gesamt
        c.ladder = [{"gain_pct": round(top * gs * (i + 1) / k, 2),
                     "sell_pct": round(keep, 1)} for i in range(k)]
        c.candles_min_score = rng.choice([1, 2, 2, 3])
        c.max_add_above_avg_pct = rng.choice([1.5, 3.0, 6.0])
        c.add_above_avg_bull_pct = rng.choice([1.5, 6.0, 12.0, 25.0, 100.0])
        # Gar keine Leiter ist eine legitime Variante: auf echten Tagesdaten
        # war sie im Bullenmarkt die groesste Bremse.
        if rng.random() < 0.2:
            c.ladder = [{"gain_pct": 999.0, "sell_pct": 25}]
        c.dip_buy_pct = round(base.dip_buy_pct * rng.choice([0.6, 1.0, 1.5, 2.2]), 2)
        c.max_add_above_avg_pct = round(
            base.max_add_above_avg_pct * rng.choice([0.5, 1.0, 2.0, 4.0]), 1)
        c.min_seconds_between_buys = int(
            base.min_seconds_between_buys * rng.choice([1, 2, 4, 8]))
        c.max_lots = rng.choice([8, 12, 20, 30, 40])
        c.order_pct = round(100.0 / c.max_lots, 2)
        c.ladder_rearm_factor = rng.choice([1.2, 1.5, 2.0, 3.0])
        # Halten gegen Absichern ausdrücklich gegeneinander antreten lassen,
        # statt eine der beiden Haltungen vorauszusetzen.
        if rng.random() < 0.5:
            c.crash_sell_pct = 0.0
            c.stop_loss_pct = 0.0
        else:
            c.crash_sell_pct = rng.choice([50.0, 70.0, 100.0])
            c.crash_drop_pct = round(rng.choice([1.5, 2.5, 4.0]), 2)
            c.stop_loss_pct = rng.choice([0.0, 8.0, 15.0, 25.0])
        c.reversal_min_horizons = rng.choice([1, 2, 3])
        c.trend_flat_pct_per_h = round(
            base.trend_flat_pct_per_h * rng.choice([0.5, 1.0, 2.0]), 3)
        out.append(c)
    return out


def optimise(engine: CandleEngine, t_from: int, t_to: int, base: SimConfig,
             n_candidates: int = 16, on_progress=None, on_note=None,
             depth: str = "gruendlich") -> dict:
    note = on_note or (lambda *_: None)
    prog = on_progress or (lambda *_: None)

    lo, hi = engine.usable_range()
    t_from, t_to = max(t_from, lo), min(t_to, hi)
    if t_to - t_from < 30 * 86400:
        return {"error": "Für eine Analyse werden mindestens 30 Tage benötigt."}

    note("Marktsicht wird einmal für den ganzen Zeitraum berechnet")
    frames, horizons = collect(engine, t_from, t_to, lambda p: prog(p * 0.30))
    if len(frames) < 60:
        return {"error": "Zu wenige Kerzen im Zeitraum (mindestens 60)."}
    rows, spacing = engine.rows, getattr(engine, "spacing", 60)

    split = t_from + (t_to - t_from) // 2
    f_tr = slice_frames(frames, t_from, split)
    f_ho = slice_frames(frames, split, t_to)

    # Kennzahlen NUR aus der Trainingshaelfte. Vorher flossen Tagesspanne und
    # RSI-Verteilung der Pruefhaelfte in die Kalibrierung ein — ein leiser
    # Blick in die Zukunft, der die Pruefhaelfte entwertet haette.
    stats = market_stats([r for r in rows if r[0] <= split], f_tr, spacing)
    stats_all = market_stats(rows, frames, spacing)

    note("Parameter werden aus den Kennzahlen abgeleitet")
    cal, why = derive(stats, base)
    bench_tr, bench_ho = dca_pct(f_tr, cal), dca_pct(f_ho, cal)

    note(f"{n_candidates} Varianten auf der ersten Hälfte")
    cands = variants(cal, n_candidates)
    ranked = []
    for i, c in enumerate(cands):
        r = fast_replay(f_tr, c, horizons)
        ranked.append((score(r, bench_tr), i, c, r))
        prog(0.30 + 0.15 * (i + 1) / len(cands))
    ranked.sort(key=lambda x: -x[0])

    note("Die besten drei auf der zweiten Hälfte nachrechnen")
    checked = []
    for sc, i, c, r_tr in ranked[:3]:
        r_ho = fast_replay(f_ho, c, horizons)
        checked.append({"kandidat": "kalibriert" if i == 0 else f"Variante {i}",
                        "train": r_tr, "holdout": r_ho,
                        "score_train": round(sc, 2),
                        "score_holdout": round(score(r_ho, bench_ho), 2),
                        "config": c.to_dict()})
    # Wer nach der Pruefzahl auswaehlt, hat auf der Pruefhaelfte gesucht —
    # dann ist sie keine Pruefung mehr. Auswahl nach Training, Pruefhaelfte
    # bleibt unberuehrt. Die drei Kandidaten stehen zur Einsicht daneben.
    best = checked[0]
    chosen = SimConfig.from_dict(best["config"])
    prog(0.47)

    report = {
        "stats": stats_all, "stats_train": stats, "reasons": why,
        "split_ts": split,
        "t_from": t_from, "t_to": t_to,
        "buyhold_train": buyhold_pct(f_tr), "buyhold_holdout": buyhold_pct(f_ho),
        "dca_train": bench_tr, "dca_holdout": bench_ho,
        "candidates": checked, "chosen": best,
        "n_frames": {"train": len(f_tr), "holdout": len(f_ho)},
        "depth": depth,
    }
    if depth == "schnell":
        prog(1.0)
        return report

    note("Walk-Forward: kalibrieren, prüfen, Fenster schieben")
    report["walk_forward"] = walk_forward(
        frames, base, horizons, rows, spacing, max(8, n_candidates // 2),
        on_progress=lambda p: prog(0.47 + p * 0.33))

    note("Ergebnis nach Marktphasen getrennt")
    report["regimes"] = regime_report(frames, chosen, horizons)
    prog(0.86)

    note("Empfindlichkeit gegenüber jedem einzelnen Wert")
    report["sensitivity"] = sensitivity(f_ho, chosen, horizons)
    prog(0.92)

    note("Kosten- und Startdatum-Robustheit")
    report["costs"] = cost_test(f_ho, chosen, horizons)
    report["starts"] = start_robustness(frames, chosen, horizons)
    prog(1.0)
    return report
