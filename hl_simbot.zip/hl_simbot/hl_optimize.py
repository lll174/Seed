"""
hl_optimize.py — leitet Parameter aus dem Kursverlauf ab und prüft sie.

Zwei Schritte, bewusst getrennt:

1. **Kalibrierung.** Aus dem gewählten Zeitraum werden messbare Eigenschaften
   bestimmt — Tagesspanne, Kerzenvolatilität, RSI-Verteilung, typische Tiefe
   der Rücksetzer, übliche Trendsteigung. Daraus ergeben sich Schwellen, die
   zum Markt passen, ohne dass etwas ausprobiert wird. Jeder Wert bekommt
   eine Begründung, die im Dashboard sichtbar ist.

2. **Suche.** Um die kalibrierten Werte herum werden Varianten durchgerechnet.

Der Zeitraum wird dafür zeitlich halbiert: kalibriert und gesucht wird auf der
ersten Hälfte, ausgewiesen wird das Ergebnis auf der zweiten. Beides zu
mischen, erzeugt eine Zahl, die nur beschreibt, wie gut sich Parameter an
bekannte Daten anschmiegen lassen — und die in der Zukunft nicht hält.

Damit die Suche auf einem Pi durchführbar bleibt, wird die Marktsicht genau
einmal berechnet und dann für jede Variante wiederverwendet. Nur die
Entscheidungsregeln unterscheiden sich zwischen den Varianten; die Messgrößen
(Raster, Trendhorizonte, Rücksetzerfenster) stehen vorher fest.
"""

from __future__ import annotations

import math
import random
import statistics as st
from dataclasses import dataclass, field, replace

from hl_sim import Features, Portfolio, SimConfig, View
from hl_candles import CandleEngine, CandleStrategy


# ---------------------------------------------------------------------------
# Schlanke Marktsicht: nur was die Entscheidungen brauchen
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class Frame:
    ts: int
    px: float
    rsi: float | None
    fvg_bull: bool
    pullback: float
    velocity: float
    hourly: float
    trend: tuple                  # ausgerichtet an HORIZONS


HORIZONS = [60, 120, 180, 360]


def frame_view(f: Frame, coin: str, horizons: list[int]) -> View:
    ft = Features(ts=f.ts, coin=coin, mark_px=f.px, mid_px=f.px,
                  age_ctx=0.0, age_book=0.0)
    ft.hourly_notional = f.hourly
    ft.__dict__["_extra"] = {"pullback_pct": f.pullback}
    fvgs = [{"kind": "bull", "inside": True, "dist_pct": 0.0,
             "lo": f.px, "hi": f.px, "ts": f.ts}] if f.fvg_bull else []
    return View(ts=f.ts, f=ft, px=f.px, rsi=f.rsi, fvgs=fvgs,
                trend=dict(zip(horizons, f.trend)),
                clusters={"snapshot_ts": None, "age_s": None,
                          "above": None, "below": None, "buckets": []},
                whales={"long": 0.0, "short": 0.0, "ratio": 1.0},
                velocity_pct=f.velocity, depth_median_1h=None)


def collect(engine: CandleEngine, t_from: int, t_to: int,
            on_progress=None) -> tuple[list[Frame], list[int]]:
    """Einmaliger Durchlauf. Danach ist jede Variante fast umsonst."""
    engine.preload(t_from, t_to)
    sp = getattr(engine, "spacing", 60)
    cfg = engine.cfg
    horizons = sorted(set(cfg.trend_horizons_min + [cfg.candles_trend_min]))
    step = max(cfg.step_seconds, sp)
    frames: list[Frame] = []
    total = max(1, t_to - t_from)
    ts = t_from
    while ts <= t_to:
        v = engine.view(ts)
        if v is not None:
            near = cfg.fvg_near_pct
            frames.append(Frame(
                ts=v.ts, px=v.px, rsi=v.rsi,
                fvg_bull=any(g["kind"] == "bull"
                             and (g["inside"] or g["dist_pct"] <= near)
                             for g in v.fvgs),
                pullback=v.f.__dict__.get("_extra", {}).get("pullback_pct", 0.0),
                velocity=v.velocity_pct,
                hourly=v.f.hourly_notional or 0.0,
                trend=tuple(v.trend.get(h) for h in horizons)))
        ts += step
        if on_progress and len(frames) % 500 == 0:
            on_progress((ts - t_from) / total)
    return frames, horizons


# ---------------------------------------------------------------------------
# Kennzahlen des Zeitraums
# ---------------------------------------------------------------------------


def q(values: list[float], p: float) -> float:
    vs = sorted(v for v in values if v is not None)
    if not vs:
        return 0.0
    k = min(len(vs) - 1, max(0, int(round(p * (len(vs) - 1)))))
    return vs[k]


def market_stats(engine: CandleEngine, frames: list[Frame]) -> dict:
    rows = engine.rows
    if len(rows) < 50 or not frames:
        return {}

    # Rendite je Kerze
    rets = [abs(b[4] - a[4]) / a[4] * 100.0
            for a, b in zip(rows, rows[1:]) if a[4]]
    # Tagesspanne aus den Kerzen eines Kalendertages
    days: dict[int, list] = {}
    for t, o, h, l, c, v in rows:
        days.setdefault(t // 86400, []).append((h, l, c))
    ranges = []
    for items in days.values():
        if len(items) < 3:
            continue
        hi = max(x[0] for x in items)
        lo = min(x[1] for x in items)
        cl = items[-1][2]
        if cl:
            ranges.append((hi - lo) / cl * 100.0)

    rsis = [f.rsi for f in frames if f.rsi is not None]
    pulls = [f.pullback for f in frames if f.pullback > 0]
    slopes = [abs(f.trend[-1]) for f in frames if f.trend and f.trend[-1] is not None]

    first, last = rows[0][4], rows[-1][4]
    span_days = max(1.0, (rows[-1][0] - rows[0][0]) / 86400.0)

    return {
        "n_candles": len(rows),
        "spacing_s": getattr(engine, "spacing", 60),
        "span_days": round(span_days, 1),
        "candle_move_med": round(st.median(rets), 3) if rets else 0.0,
        "candle_move_p90": round(q(rets, 0.90), 3),
        "day_range_med": round(st.median(ranges), 2) if ranges else 0.0,
        "day_range_p90": round(q(ranges, 0.90), 2),
        "rsi_p20": round(q(rsis, 0.20), 1),
        "rsi_p80": round(q(rsis, 0.80), 1),
        "pullback_med": round(st.median(pulls), 2) if pulls else 0.0,
        "pullback_p75": round(q(pulls, 0.75), 2),
        "slope_med": round(st.median(slopes), 3) if slopes else 0.0,
        "buyhold_pct": round((last - first) / first * 100.0, 1) if first else 0.0,
        "px_first": first, "px_last": last,
    }


# ---------------------------------------------------------------------------
# Ableitung: Werte mit Begründung
# ---------------------------------------------------------------------------


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def derive(s: dict, base: SimConfig) -> tuple[SimConfig, list[dict]]:
    cfg = replace(base)
    why: list[dict] = []

    def set_(name, value, reason, unit=""):
        setattr(cfg, name, value)
        why.append({"param": name, "value": value, "unit": unit,
                    "reason": reason})

    dr = s.get("day_range_med") or 2.0
    cm = s.get("candle_move_med") or 0.2
    sp = s.get("spacing_s") or 60

    # --- Verkaufsleiter an der Tagesspanne ausrichten
    ladder = [
        {"gain_pct": round(clamp(dr * 0.6, 0.4, 20), 2), "sell_pct": 20},
        {"gain_pct": round(clamp(dr * 1.3, 0.8, 35), 2), "sell_pct": 25},
        {"gain_pct": round(clamp(dr * 2.2, 1.5, 60), 2), "sell_pct": 25},
    ]
    set_("ladder", ladder,
         f"Tagesspanne im Median {dr:.2f} %. Stufen bei 0,6 / 1,3 / 2,2 "
         f"Tagesspannen — die erste innerhalb eines üblichen Tages "
         f"erreichbar, die letzte nur in einer Bewegung.")

    set_("dip_buy_pct", round(clamp(dr * 0.35, 0.2, 6), 2),
         f"Ein Drittel der Tagesspanne. Darunter wäre der Nachkauf Rauschen.", "%")

    set_("stop_loss_pct", round(clamp(dr * 2.5, 2, 25), 1),
         f"2,5 Tagesspannen unter dem Einstand — außerhalb der normalen "
         f"Schwankung, greift also nur bei einem echten Bruch.", "%")

    set_("crash_drop_pct", round(clamp(s.get("candle_move_p90", cm) * 2.0,
                                       0.3, 8), 2),
         f"Doppelter Wert der stärksten 10 % aller Kerzenbewegungen "
         f"({s.get('candle_move_p90', 0):.2f} %).", "%")
    set_("crash_window_s", int(sp),
         f"Ein Kerzenabstand ({sp} s) — feiner kann die Quelle nicht messen.", "s")

    # --- Schwellen aus den Verteilungen
    set_("rsi_buy", round(clamp(s.get("rsi_p20", 40), 20, 48), 1),
         f"20. Perzentil der RSI-Verteilung in diesem Zeitraum. Ein fester "
         f"Wert von 30 wäre in ruhigen Phasen nie erreicht worden.")
    set_("rsi_sell", round(clamp(s.get("rsi_p80", 70), 55, 88), 1),
         f"80. Perzentil der RSI-Verteilung.")
    set_("candles_pullback_pct", round(clamp(s.get("pullback_med", 1.0),
                                             0.3, 8), 2),
         f"Median aller Rücksetzer vom Hoch der letzten "
         f"{base.candles_pullback_hours} h. Die Hälfte der Gelegenheiten "
         f"liegt damit über der Schwelle.", "%")
    set_("trend_flat_pct_per_h", round(clamp(s.get("slope_med", 0.08) * 0.8,
                                             0.01, 2), 3),
         f"80 % der üblichen Steigung ({s.get('slope_med', 0):.3f} %/h). "
         f"Darunter ist eine Bewegung kein Trend, sondern Rauschen.", "%/h")

    # --- Kapitalaufteilung schlüssig machen
    slots = int(clamp(base.max_lots, 4, 40))
    set_("order_pct", round(100.0 / slots, 2),
         f"{slots} Einstiegsplätze ergeben {100.0/slots:.2f} % je Tranche. "
         f"Vorher konnten die Plätze rechnerisch gar nicht alle belegt "
         f"werden — die Grenze war wirkungslos.", "%")
    set_("min_order_usd", round(max(10.0, base.budget_usd * 0.002), 2),
         "0,2 % der Einsatzsumme, mindestens 10 USD, damit die Gebühr "
         "nicht den Gewinn der Tranche übersteigt.", "USD")

    set_("min_seconds_between_buys", int(max(sp * 3, sp)),
         f"Drei Kerzenabstände. Verhindert, dass alle Tranchen in dieselbe "
         f"Bewegung laufen.", "s")
    set_("dip_confirm_seconds", int(max(sp * 2, sp)),
         f"Zwei Kerzenabstände ohne neues Tief.", "s")
    set_("step_seconds", int(sp),
         f"Auflösung der Quelle. Feiner zu rechnen erzeugt nur "
         f"Wiederholungen.", "s")
    return cfg, why


# ---------------------------------------------------------------------------
# Schneller Durchlauf über die zwischengespeicherte Marktsicht
# ---------------------------------------------------------------------------


def fast_replay(frames: list[Frame], cfg: SimConfig, horizons: list[int]) -> dict:
    pf = Portfolio(cfg)
    strat = CandleStrategy(cfg)
    fee = cfg.fee_bps_taker
    slip = cfg.candles_slippage_bps / 1e4
    for fr in frames:
        v = frame_view(fr, cfg.coin, horizons)
        d = strat.want_sell(v, pf)
        if d.action == "sell":
            frac = pf.fraction_for(d)
            pf.sell_fraction(fr.ts, fr.px * (1 - slip), frac, fee, d.reason)
            continue
        b = strat.want_buy(v, pf)
        if b.action == "buy":
            pf.buy(fr.ts, fr.px * (1 + slip), b.amount, fee, b.reason)

    px = frames[-1].px if frames else 0.0
    sells = [t for t in pf.trades if t.side == "sell"]
    wins = [t for t in sells if t.realized > 0]
    eq = pf.equity(px)
    return {
        "return_pct": round((eq - cfg.budget_usd) / cfg.budget_usd * 100.0, 2),
        "equity": round(eq, 2),
        "realized": round(pf.realized, 2),
        "fees": round(pf.fees, 2),
        "fees_pct_budget": round(pf.fees / cfg.budget_usd * 100.0, 2),
        "n_buys": len(pf.trades) - len(sells),
        "n_sells": len(sells),
        "hit_rate": round(len(wins) / len(sells) * 100.0, 1) if sells else None,
        "open_lots": len(pf.lots),
    }


def buyhold_pct(frames: list[Frame]) -> float:
    if len(frames) < 2 or not frames[0].px:
        return 0.0
    return round((frames[-1].px - frames[0].px) / frames[0].px * 100.0, 2)


def score(res: dict, bh: float) -> float:
    """
    Überrendite gegenüber Kaufen-und-Halten, mit Abzug für Umschlag.
    Ohne den Abzug gewinnt regelmäßig eine Variante, die sich durch hohe
    Handelsfrequenz eine Scheinrendite erkauft.
    """
    if (res["n_sells"] or 0) < 5:
        return -1e9
    penalty = max(0.0, res["fees_pct_budget"] - 10.0) * 0.8
    return res["return_pct"] - bh - penalty


# ---------------------------------------------------------------------------
# Suche
# ---------------------------------------------------------------------------


def variants(base: SimConfig, n: int, seed: int = 7) -> list[SimConfig]:
    rng = random.Random(seed)
    out = [replace(base)]
    for _ in range(max(0, n - 1)):
        c = replace(base)
        gs = rng.choice([0.6, 0.8, 1.0, 1.3, 1.7])
        c.ladder = [{"gain_pct": round(s["gain_pct"] * gs, 2),
                     "sell_pct": s["sell_pct"]} for s in base.ladder]
        if rng.random() < 0.5:
            keep = rng.choice([(20, 20, 20), (25, 25, 25), (15, 25, 35),
                               (30, 30, 20)])
            for s_, k in zip(c.ladder, keep):
                s_["sell_pct"] = k
        c.candles_min_score = rng.choice([1, 2, 2, 3])
        c.dip_buy_pct = round(base.dip_buy_pct * rng.choice([0.6, 1.0, 1.5, 2.2]), 2)
        c.min_seconds_between_buys = int(
            base.min_seconds_between_buys * rng.choice([1, 2, 4, 8]))
        c.max_lots = rng.choice([8, 12, 20, 30])
        c.order_pct = round(100.0 / c.max_lots, 2)
        c.ladder_rearm_factor = rng.choice([1.2, 1.5, 2.0, 3.0])
        c.stop_loss_pct = rng.choice([0.0, base.stop_loss_pct,
                                      round(base.stop_loss_pct * 1.6, 1)])
        c.reversal_min_horizons = rng.choice([1, 2, 3])
        c.trend_flat_pct_per_h = round(
            base.trend_flat_pct_per_h * rng.choice([0.5, 1.0, 2.0]), 3)
        out.append(c)
    return out


def optimise(engine: CandleEngine, t_from: int, t_to: int, base: SimConfig,
             n_candidates: int = 16, on_progress=None, on_note=None) -> dict:
    note = on_note or (lambda *_: None)

    lo, hi = engine.usable_range()
    t_from, t_to = max(t_from, lo), min(t_to, hi)
    if t_to - t_from < 7 * 86400:
        return {"error": "Für eine Analyse werden mindestens sieben Tage "
                         "benötigt. Der gewählte Zeitraum ist kürzer."}
    split = t_from + (t_to - t_from) // 2

    note("Marktsicht wird einmal berechnet (Trainingshälfte)")
    tr_frames, horizons = collect(engine, t_from, split,
                                  lambda p: on_progress and on_progress(p * 0.35))
    if len(tr_frames) < 200:
        return {"error": "Zu wenige Kerzen in der Trainingshälfte."}
    stats = market_stats(engine, tr_frames)

    note("Parameter werden aus den Kennzahlen abgeleitet")
    cal, why = derive(stats, base)

    note(f"{n_candidates} Varianten werden auf der Trainingshälfte gerechnet")
    cands = variants(cal, n_candidates)
    bh_tr = buyhold_pct(tr_frames)
    ranked = []
    for i, c in enumerate(cands):
        r = fast_replay(tr_frames, c, horizons)
        ranked.append((score(r, bh_tr), i, c, r))
        if on_progress:
            on_progress(0.35 + 0.35 * (i + 1) / len(cands))
    ranked.sort(key=lambda x: -x[0])

    note("Die besten drei werden auf der Prüfhälfte nachgerechnet")
    ho_frames, _ = collect(engine, split, t_to,
                           lambda p: on_progress and on_progress(0.7 + p * 0.25))
    bh_ho = buyhold_pct(ho_frames)

    checked = []
    for sc, i, c, r_tr in ranked[:3]:
        r_ho = fast_replay(ho_frames, c, horizons)
        checked.append({
            "kandidat": "kalibriert" if i == 0 else f"Variante {i}",
            "train": r_tr, "holdout": r_ho,
            "score_train": round(sc, 2),
            "score_holdout": round(score(r_ho, bh_ho), 2),
            "config": c.to_dict(),
        })
    # Gewählt wird der, der auf der Prüfhälfte standhält, nicht der beste
    # auf der Trainingshälfte.
    best = max(checked, key=lambda x: x["score_holdout"])
    if on_progress:
        on_progress(1.0)

    return {
        "stats": stats,
        "reasons": why,
        "split_ts": split,
        "t_from": t_from, "t_to": t_to,
        "buyhold_train": bh_tr, "buyhold_holdout": bh_ho,
        "candidates": checked,
        "chosen": best,
        "n_frames": {"train": len(tr_frames), "holdout": len(ho_frames)},
    }
