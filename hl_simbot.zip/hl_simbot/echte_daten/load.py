import csv, os
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)))
def block(name):
    with open(os.path.join(BASE, name)) as f:
        rows = [(int(r['day']), float(r['h']), float(r['l']), float(r['c']))
                for r in csv.DictReader(l for l in f if not l.startswith('#'))]
    return rows
BLOCKS = {"A 2022-23": block("btc_2022.csv"), "B 2024-25": block("btc_2024.csv"), "C 2026": block("btc_2026.csv")}
