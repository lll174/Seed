# Mustersuche auf echten BTC-Tageskerzen (2022–2026)

Datenbasis: Binance BTCUSDT Tageskerzen, drei Blöcke: A 2022-01 bis 2023-10
(Baisse −77 %, Erholung), B 2024-01 bis 2025-09 (Bullenmarkt mit drei
Korrekturen von 20–30 %), C 2026-01 bis 2026-09 (Einbruch −35 %, Erholung).

## 1. Wie weit steigt der Kurs vor einer Korrektur?

Aufwärtsschwung vom Tief bis zum Hoch, bevor der Kurs um X % fällt.
In allen drei Blöcken nahezu gleich:

| Korrektur mindestens | Anstieg davor, Median | p75 | Dauer Median |
|---|---|---|---|
| 5 %  | 12 % | 18 % | 8 Tage |
| 10 % | 20 % | 26 % | 22 Tage |
| 15 % | 27 % | 31 % | 35 Tage |

Die Beobachtung „nach rund 15 % kommt ein Rücksetzer" ist also richtig — als
Beschreibung.

## 2. Ist das vorhersagbar? Nein.

P(Rücksetzer ≥ 10 % innerhalb 20 Tagen), Grundrate ohne Bedingung: 67 / 63 / 48 %
(Block A / B / C). Bedingt darauf, dass der Kurs bereits ≥ 15 % über dem
30-Tage-Tief steht: 71 / 71 / 43 %. Bei ≥ 5 % Rücksetzer in 10 Tagen: Grundrate
91 %, bedingt 92 %.

Der Rücksetzer kommt fast immer — unabhängig davon, wie weit der Kurs vorher
gestiegen ist. Wer bei +15 % verkauft, weil „der Rücksetzer kommt", verkauft
in etwas hinein, das auch ohne Verkauf gekommen wäre und danach weiterläuft.

## 3. Überhitzungsmaße: Forward-Rendite 20 Tage, Median

| Maß | Baisse A | Bulle B | 2026 C |
|---|---|---|---|
| RSI > 75 | −0,7 % | **+5,2 %** | — |
| > 20 % über MA50 | +3,4 % | **+3,6 %** | — |
| Anstieg > 35 % vom Tief | +2,2 % | +2,9 % | — |
| Rücksetzer 8–25 % vom Hoch | +0,2..0,7 % | **+2,6..4,8 %** | −1,4..−2,1 % |

Die extremsten Werte laufen weiter, statt zu kippen. Kein Oszillator liefert
ein regimeunabhängiges Verkaufssignal. Was hält: das Regime. Rücksetzer werden
über dem MA200 gekauft, darunter nicht.

## 4. Drei-Arm-Strategie und Kreuzprüfung

Kern (Regimefolge mit Ausstieg bei Trendbruch), Dip-Arm (Rücksetzerkauf nur im
Bullenregime), Scalp-Arm (enge Schwellen). 400 Parametersätze, jeweils auf
einem Block gewählt und auf den anderen geprüft — siehe `hl_sleeves.py`.

- Auf A gewählt: +20 % / +33 % / −5 %  (Sparplan: +10 / +60 / +15)
- Auf B gewählt: −1 % / +82 % / −10 %
- **0 von 400 Sätzen schlagen den Sparplan in allen drei Blöcken.**
- 166 von 400 schlagen Kaufen-und-Halten in zwei Blöcken — weil Kaufen-und-
  Halten in Baisse und Einbruch −41 % bzw. −9 % macht.

## 5. Was daraus folgt

Der einzige robuste Effekt ist **Rückgangskontrolle**: der Kern mit Ausstieg
bei 20–25 % Abstand vom Hoch und MA200-Bruch begrenzt den Rückgang auf 15–25 %,
wo Kaufen-und-Halten 41–77 % verliert. Das kostet im Bullenmarkt etwa die
Hälfte der Rendite.

Ein Timing-Vorteil gegenüber einem Sparplan ist auf Tageskerzen 2022–2026
nicht nachweisbar. Der Rücksetzer-Arm mit fester Gewinnschwelle hat keine
empirische Grundlage; der Dip-Arm funktioniert nur nach bestätigtem Regime-
wechsel und mit regimeabhängigen Parametern.

Wo ein Vorteil noch liegen könnte: nicht im Tageschart, sondern in der
Mikrostruktur — Liquidationscluster, Orderbuchtiefe, Kaskadenende. Das war die
ursprüngliche These des Recorders, und sie ist mit 30 Stunden Daten noch
ungeprüft.

## 6. Indikatorprüfung (alle aus Hoch/Tief/Schluss berechenbaren)

18 Indikatoren, je Block Spearman-Korrelation zur Forward-Rendite über 5/10/20/40
Tage, Schaltertest an natürlichen Schwellen, Redundanzmatrix. Code:
`indikatoren.py` (Berechnung), Rohergebnis `indikator_scan.json`.

**Redundanz.** SMA50-/EMA50-Abstand, MACD, RSI14/21, ROC 20d, Donchian 55,
Ichimoku-Wolke, Bollinger %B und Abstand zum 60d-Hoch korrelieren mit 0,8–0,98
untereinander: eine Information, zehn Namen. Unabhängige Gruppen: langer Trend
(MA200/ROC60), kurzfristige Ausdehnung, ADX, Trendalter (Tage seit 60d-Hoch),
Volatilität (ATR), Stochastik.

**Prognosekraft.** Kein Indikator erreicht |rho| ≥ 0,2 konsistent über alle
drei Blöcke. Die Ausdehnungsgruppe zeigt gesamt schwache Umkehr (−2 bis −4 %
über 20 Tage), im Bull-Regime aber +1 bis +3 % — regimeabhängig, kein
Verkaufssignal. ADX > 25: −1 bis −5 % konsistent (Trenderschöpfung). Tage seit
60d-Hoch > 1 Monat: +1 bis +8 % konsistent (Rücksetzer gereift). Volatilität:
keine Richtungsinformation (rho ≈ 0,03).

**Für das Board:** MA200 als Regime. Optional ADX und Tage-seit-Hoch als
schwache Gewichtung innerhalb des Regimes. Aus der Ausdehnungsgruppe genau
einen Vertreter (SMA50-Abstand). Volumen war nicht prüfbar.

## 7. Dip-Sparplan (immer nachkaufen, nie verkaufen)

Gleiches Budget wie der Kalender-Sparplan, 20 Tranchen, Kauf bei Rücksetzer
≥ X % vom 30-Tage-Hoch. Code: `dip_sparplan.py`.

**Der Dip-Effekt ist real.** Gegen einen gleich schnell investierenden
Kalenderplan kauft ein Dip von ≥ 8–10 % in allen drei Blöcken 4–8 % billiger,
≥ 15 % 7–12 %. Dips von 3–5 % bringen nichts (Rauschen).

**Das Tempo entscheidet.** Ohne Bremse sind die Tranchen nach ~100 Tagen weg:
Bullenmarkt +108 %, Baisse −28 % (alles bei 40.000 gekauft, nichts bei
16.000). Mit höchstens einer Tranche je 14 Tage: +9,5 / +68,9 / +7,3 %,
kumuliert +98,5 % gegen +92,5 % Kalenderplan — der erste Ansatz, der den
Sparplan in Summe schlägt. Der Vorsprung ist klein, weil der Kalenderplan die
Dips ebenfalls kauft; der Dip-Plan lässt nur die teuren Wochen aus.

**Kein Regimefilter beim Kaufen.** Nur über dem MA200 zu kaufen kostet
8–22 % am Kaufkurs, weil die billigsten Dips in der Baisse liegen.

Empfohlene Regel: Rücksetzer ≥ 10 % vom 30d-Hoch, höchstens alle 14 Tage,
Budget auf 20 Tranchen, kein Filter, nie verkaufen. Der MA200-Ausstieg kann
darüber als Versicherung liegen — aber er gehört auf die Verkaufsseite, nicht
auf die Kaufseite.

## 8. Regime-Akkumulation (Baisse kaufen, Bulle halten, Reserve am MA200)

Code: `regime_akkumulation.py`.

**Unterer Bereich über dem MA200.** Rücksetzer im Bullenmarkt enden im Median
9–12 % über dem MA200, ein Viertel bei 0–3 %. Forward-Rendite 60 Tage bei Kauf
im Bull-Regime: 0–5 % über MA200 → +23 bis +29 %; 5–10 % → +13 %; 10–20 % →
+9 %; über 20 % → −3 bis −4 %. Die Reserve gehört in das Band 0–5 %, die teure
Zone beginnt bei +20 %.

**Ausstiegssignale, Forward 60 Tage nach dem Signal (Grundrate +0,8 %):**

| Signal | n | 60 Tage danach | Urteil |
|---|---|---|---|
| Abstand MA200 > +40 % | 15 | **−5,1 %**, nur 27 % positiv | einziges echtes Überhitzungssignal |
| Schluss < MA200 −3 % | 34 | +1,7 % | neutral im Median, Wert nur im Extremfall 2022 |
| Rückgang vom Hoch ≥ 20 % | 26 | +5,4 % | verkauft das Tief |
| Rückgang vom Hoch ≥ 30 % | 10 | +13,2 % | verkauft das Tief |
| Todeskreuz MA50 < MA200 | 6 | +4,2 % | lahmt |
| RSI14 > 80 | 7 | +11,3 % | Kaufsignal, kein Verkaufssignal |
| 20-Tage-Anstieg > 30 % | 8 | 0,0 % | nichts |

**Strategie über die drei Blöcke** (Baisse: 20 Tranchen, alle 15 Tage, Dip ≥ 8 %;
Bulle: alles außer 30 % Reserve, Reserve bei MA200 +0..5 %):

| | Baisse | Bulle | 2026 | alle drei |
|---|---|---|---|---|
| ohne Ausstieg | −1 % | +139 % | −7 % | **+119 %** |
| Kalender-Sparplan | +12 % | +54 % | +17 % | +101 % |
| Halten | −41 % | +158 % | −9 % | +39 % |
| Teilverkauf 30 % bei MA200 +40 % | −10 % | +137 % | −7 % | +97 % |
| Regimebruch-Ausstieg, langsamer Wiedereinstieg | +20 % | −5 % | 0 % | +14 % |
| Regimebruch-Ausstieg, symmetrischer Wiedereinstieg, 8 % Puffer | +3 % | +33 % | +8 % | +49 % bei halbem Rückgang |

Erster Ansatz, der den Sparplan deutlich schlägt. Kein Ausstiegssignal erhöht
die Rendite; der Regimebruch mit symmetrischem Wiedereinstieg halbiert den
Rückgang bei etwa gleicher Rendite. Die Asymmetrie „schnell raus, langsam
rein" ist tödlich (−5 % im Bullenmarkt).

## 9. Ab welchem Abstand zum MA200 lohnte der Verkauf?

Alle Episoden mit mehr als 30 % über dem MA200 (Anlauf 60 Tage):

| Episode | Spitze über MA200 | nach +30 % noch | danach bis MA200 | Verkauf 40 → Rückkauf MA200 |
|---|---|---|---|---|
| Frühjahr 2023 | 45 % | +14,8 % | −20,0 % | 4,8 % billiger |
| Frühjahr 2024 | 46 % | +17,1 % | −22,6 % | 16,4 % billiger |
| Winter 2024/25 | 53 % | +19,7 % | −26,3 % | 10,7 % billiger |

Voll investiert, Verkauf bei > X %, Rückkauf bei Berührung des MA200, alle
drei Blöcke: X = 20 → +31 %, 25 → +39 %, 30 → +70 %, 35 → +85 %, **40 → +93 %**,
50 → +68 % (nur ein Signal). Halten: +39 %.

**Bereich: 40–45 % über dem MA200.** Darunter zu viele Fehlsignale, darüber zu
selten. Der Rückkauf am MA200 (0–5 % darüber) ist die Hälfte der Regel — bei
Rückkauf erst bei +15 % halbiert sich der Gewinn. In der Regime-Strategie war
der Teilverkauf vorher neutral, weil der Rückkauf über die Reserve zu langsam
lief; mit entschlossenem Rückkauf: +125 % → +153 % (100 % Verkauf) bzw. +139 %
(50 %). Vorgabe im Bot: 50 % bei 40 %, Rückkauf bei 5 %.

Vorbehalt: drei Episoden, alle aus einem Zyklus. In den Manien 2017 und 2021
lag die Spitze bei +100 % und mehr über dem MA200; dort hätte die Regel früh
verkauft und lange gewartet. Das ist der Grund für 50 % statt 100 %.

## 10. Wie tief unter dem MA200 lagen die Tiefs?

Echter MA200 (200 Tage Anlauf), Tiefstand je Episode unter dem MA200:
Bullenmarkt-Dips 2023–2026: 5–16 % (13–54 Tage). Einbruch 2026: ≈ 21 %
(Näherung, 84 Tage). Baisse 2022: Kurstief November 30 %, tiefster Abstand
September 39 %, Kapitulation Juni geschätzt ≈ 55 % (außerhalb des Fensters).

Kauf bei Abstand X unter dem MA200, Forward 180 Tage (Median, Anteil positiv):
0–5 % +37 % (100 %), 5–10 % +52 % (100 %), **10–20 % +58 % (100 %, weiterer
Rückgang nur 3 %)**, 20–30 % +55 % (80 %, erst 60 Tage −11 %), 30–45 % +15 %
(81 %, erst 120 Tage −17 %).

Drei Zonen: 10–20 % verlässlichste Kaufzone (alle Bullenmarkt-Dips enden hier),
20–30 % Zyklustiefs dieser Daten, 35–45 % und tiefer Kapitulation (2018 und
März 2020 lagen nach allgemeinem Wissen ebenfalls bei 40–45 %).

Tiefenstaffel im Bot (Tranche ×1/×2/×3 ab 10/20/30 %): mit 20 Grundtranchen
schlechter als die feste Tranche (+126 gegen +139 %), weil das Budget 2022
vor den Tiefs aufgebraucht war; mit 30 Grundtranchen +143 %, Baisse 2022
+25 % statt +14 %. Tempo entscheidet auch hier.
