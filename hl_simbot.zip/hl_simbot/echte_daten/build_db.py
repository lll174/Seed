#!/usr/bin/env python3
"""Baut aus den drei CSV-Bloecken je eine Datenbank mit Tabelle klines."""
import csv, sqlite3, os
here = os.path.dirname(os.path.abspath(__file__))
for name, src in (("a", "btc_2022.csv"), ("b", "btc_2024.csv"), ("c", "btc_2026.csv")):
    with open(os.path.join(here, src)) as f:
        rows = [(int(r['day']), int(r['h']), int(r['l']), int(r['c']))
                for r in csv.DictReader(l for l in f if not l.startswith('#'))]
    db = os.path.join(here, f"real_{name}.db")
    if os.path.exists(db): os.remove(db)
    c = sqlite3.connect(db)
    c.execute("CREATE TABLE klines(ts INT, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, PRIMARY KEY(ts,coin))")
    c.execute("CREATE TABLE bars(ts INT, coin TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, trades INT, PRIMARY KEY(ts,coin))")
    prev = rows[0][3]; out = []
    for d, h, l, cl in rows:
        o = prev; prev = cl
        out.append((d * 86400, "BTC", o, max(h, o), min(l, o), cl, 0.0))
    c.executemany("INSERT INTO klines VALUES(?,?,?,?,?,?,?)", out); c.commit(); c.close()
    print(f"{db}: {len(out)} Tageskerzen")
