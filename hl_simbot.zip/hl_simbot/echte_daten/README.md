# Echte BTCUSDT-Tageskerzen (Binance über static-klines)

Drei Blöcke, Spalten `day,h,l,c` (day = Tage seit 1970, Preise gerundet):

| Datei | Zeitraum | Charakter |
|---|---|---|
| btc_2022.csv | 2022-01-01 – 2023-10-01 | Bärenmarkt −77 %, dann Erholung |
| btc_2024.csv | 2024-01-01 – 2025-09-30 | Bullenmarkt mit mehreren 15–30-%-Korrekturen |
| btc_2026.csv | 2026-01-01 – 2026-09-02 | Einbruch −35 %, dann Erholung |

Lücken: Q4 2023 und Q4 2025 (Abrufgrenze). Datenbank bauen:

    python3 echte_daten/build_db.py        # legt echte_daten/real_a.db, real_b.db, real_c.db an
    python3 hl_candles.py --db echte_daten/real_b.db --from 2024-01-01 --to 2025-09-30

Der Bericht `bericht_tageskerzen.json` ist der Optimizer-Lauf über alle drei
Blöcke mit 40 Varianten (Stand 4.9.2026, Version h).
