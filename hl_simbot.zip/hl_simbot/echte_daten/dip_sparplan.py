"""Sparplan-Varianten mit gleichem Budget. Nie verkaufen. Kennzahlen: Endwert,
durchschnittlicher Kaufkurs, eingesetzter Budgetanteil."""
FEE=0.0011
def sma(c,i,w): k=min(w,i+1); return sum(c[i-k+1:i+1])/k
def calendar(rows, budget=10000, every=7):
    c=[r[3] for r in rows]; n=len(c); k=n//every or 1; per=budget/k; coin=0; spent=0
    for i in range(0,n,every):
        if spent+per>budget+1e-9: break
        coin+=per*(1-FEE)/c[i]; spent+=per
    return _out(coin,spent,budget,c)
def dip(rows, budget=10000, tranches=20, depth=10, lookback=30, cooldown=5,
        regime=None, ladder=None, calendar_share=0.0, every=7):
    """depth: Ruecksetzer vom lookback-Tage-Hoch in %, ab dem eine Tranche gekauft wird.
    ladder: Liste (tiefe, tranchen) — tiefere Dips bekommen mehr Tranchen.
    regime: None | 'bull' (nur ueber MA200) | 'bear' (nur unter MA200).
    calendar_share: Anteil des Budgets, der zusaetzlich im Kalenderrhythmus laeuft."""
    c=[r[3] for r in rows]; h=[r[1] for r in rows]; n=len(c)
    cal_budget=budget*calendar_share; dip_budget=budget-cal_budget
    per=dip_budget/tranches; coin=0; spent=0; last=-999
    kcal=n//every or 1; per_cal=cal_budget/kcal; spent_cal=0
    armed={}  # Leiter: je Tiefe merken, ob in diesem Dip schon gekauft
    for i in range(n):
        if cal_budget and i%every==0 and spent_cal+per_cal<=cal_budget+1e-9:
            coin+=per_cal*(1-FEE)/c[i]; spent_cal+=per_cal
        hi=max(h[max(0,i-lookback+1):i+1]); dd=(1-c[i]/hi)*100
        m=sma(c,i,200)
        if regime=="bull" and c[i]<m: continue
        if regime=="bear" and c[i]>m: continue
        if dd<=0: armed={}   # neues Hoch: Leiter zuruecksetzen
        if ladder:
            for lvl,ntr in ladder:
                if dd>=lvl and not armed.get(lvl) and spent+per*ntr<=dip_budget+1e-9 and i-last>=cooldown:
                    coin+=per*ntr*(1-FEE)/c[i]; spent+=per*ntr; last=i; armed[lvl]=True
        elif dd>=depth and i-last>=cooldown and spent+per<=dip_budget+1e-9:
            coin+=per*(1-FEE)/c[i]; spent+=per; last=i
    return _out(coin,spent+spent_cal,budget,c)
def _out(coin,spent,budget,c):
    end=coin*c[-1]+(budget-spent)
    return dict(ret=(end/budget-1)*100, avg=(spent/coin) if coin else None, deployed=spent/budget*100,
                invested_ret=((coin*c[-1]/spent-1)*100) if spent else 0)
