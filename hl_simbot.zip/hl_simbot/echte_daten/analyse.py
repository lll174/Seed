#!/usr/bin/env python3
"""Mustersuche aus ERGEBNISSE.md nachrechnen:  python3 echte_daten/analyse.py"""
import sys, os, statistics as st
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from load import BLOCKS
from hl_sleeves import P, sim, dca, bh
print("Drei-Arm-Strategie mit Vorgaben, je Block:")
for name, rows in BLOCKS.items():
    r = sim(rows, P())
    print(f"  {name:12s} {r['ret']:+7.1f} %  Rueckgang {r['mdd']:3.0f} %   Sparplan {dca(rows):+6.1f} %   K&H {bh(rows):+7.1f} %")
