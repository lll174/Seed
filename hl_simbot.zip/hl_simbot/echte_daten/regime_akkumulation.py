"""Regime-Akkumulation: Baisse gestaffelt kaufen, Bulle halten + Reserve an den MA200 legen,
optionale Ausstiege. Nie Leiter, nie Trailing-Stop."""
FEE=0.0011
def sma(c,i,w): k=max(1,min(w,i+1)); return sum(c[i-k+1:i+1])/k
def run(rows, budget=10000, bear_tranches=20, bear_gap=15, bear_dip=8, reserve_share=0.3,
        band_lo=0.0, band_hi=10.0, bull_gap=10, sell_at=None, sell_frac=0.3, regime_exit=False, buffer=3.0):
    c=[r[3] for r in rows]; h=[r[1] for r in rows]; l=[r[2] for r in rows]; n=len(c)
    cash=budget; coin=0.0; last_buy=-999; last_sell=-999; sold_level=False
    peak=budget; mdd=0; buys=sells=0; state=None
    for i in range(n):
        m200=sma(c,i,200); d=(c[i]/m200-1)*100
        bull = c[i]>m200*(1+buffer/100); bear = c[i]<m200*(1-buffer/100)
        if state is None: state="bull" if c[i]>m200 else "bear"
        elif state=="bear" and bull: state="bull"; sold_level=False
        elif state=="bull" and bear: state="bear"
        hi30=max(h[max(0,i-29):i+1]); dd30=(1-c[i]/hi30)*100
        if state=="bear":
            # gestaffelt kaufen: Tranche = Budgetanteil, hoechstens alle bear_gap Tage, bei Dip >= bear_dip
            per=budget/bear_tranches
            if cash>=per and dd30>=bear_dip and i-last_buy>=bear_gap:
                coin+=per*(1-FEE)/c[i]; cash-=per; last_buy=i; buys+=1
        else:
            # Bulle: Ersteinsatz alles ausser Reserve; Reserve an den MA200-Rand
            reserve=budget*reserve_share
            if cash>reserve+1 and last_buy<0:
                amt=cash-reserve; coin+=amt*(1-FEE)/c[i]; cash-=amt; last_buy=i; buys+=1
            if band_lo<=d<=band_hi and dd30>=5 and i-last_buy>=bull_gap and cash>1:
                amt=min(cash, budget*0.1); coin+=amt*(1-FEE)/c[i]; cash-=amt; last_buy=i; buys+=1
            # Ausstieg 1: Teilverkauf bei Ueberdehnung
            if sell_at and d>sell_at and not sold_level and coin>0:
                cash+=coin*sell_frac*c[i]*(1-FEE); coin*=(1-sell_frac); sold_level=True; sells+=1
            if d<sell_at*0.7 if sell_at else False: sold_level=False   # neu scharf nach Abkuehlung
        # Ausstieg 2: Regimebruch -> alles raus (Versicherung)
        if regime_exit and state=="bear" and coin>0 and i>0 and sma(c,i-1,200)*(1-buffer/100)<=c[i-1]:
            cash+=coin*c[i]*(1-FEE); coin=0; sells+=1
        e=cash+coin*c[i]; peak=max(peak,e); mdd=max(mdd,(peak-e)/peak*100)
    return dict(ret=((cash+coin*c[-1])/budget-1)*100, mdd=mdd, buys=buys, sells=sells, cash_end=cash/budget*100)
def dca(rows,budget=10000,every=7):
    c=[r[3] for r in rows]; n=len(c); k=n//every or 1; per=budget/k; coin=0
    for i in range(0,n,every): coin+=per*(1-FEE)/c[i]
    return (coin*c[-1]/budget-1)*100
def hold(rows): c=[r[3] for r in rows]; return (c[-1]/c[0]-1)*100
