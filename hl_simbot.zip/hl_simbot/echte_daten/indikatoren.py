"""Alle Indikatoren aus Hoch/Tief/Schluss. Jeder liefert eine Liste (None bis Anlauf)."""
import math
def sma(x,w): return [sum(x[i-w+1:i+1])/w if i>=w-1 else None for i in range(len(x))]
def ema(x,w):
    k=2/(w+1); out=[]; e=None
    for v in x:
        e = v if e is None else v*k+e*(1-k); out.append(e)
    return out
def rsi(c,w):
    out=[None]*len(c); g=l=None
    for i in range(1,len(c)):
        d=c[i]-c[i-1]; up=max(d,0); dn=max(-d,0)
        if i<=w:
            if i==w:
                g=sum(max(c[k]-c[k-1],0) for k in range(1,w+1))/w; l=sum(max(c[k-1]-c[k],0) for k in range(1,w+1))/w
        else:
            g=(g*(w-1)+up)/w; l=(l*(w-1)+dn)/w
        if g is not None: out[i]=100-100/(1+g/l) if l else 100.0
    return out
def atr(h,l,c,w):
    tr=[h[0]-l[0]]+[max(h[i]-l[i],abs(h[i]-c[i-1]),abs(l[i]-c[i-1])) for i in range(1,len(c))]
    return ema(tr,w)
def adx(h,l,c,w=14):
    n=len(c); dmp=[0.0]*n; dmm=[0.0]*n
    for i in range(1,n):
        up=h[i]-h[i-1]; dn=l[i-1]-l[i]
        dmp[i]=up if up>dn and up>0 else 0.0; dmm[i]=dn if dn>up and dn>0 else 0.0
    tr=[h[0]-l[0]]+[max(h[i]-l[i],abs(h[i]-c[i-1]),abs(l[i]-c[i-1])) for i in range(1,n)]
    atr_=ema(tr,w); dp=ema(dmp,w); dm=ema(dmm,w)
    dx=[(abs(dp[i]-dm[i])/(dp[i]+dm[i])*100 if dp[i]+dm[i] else 0) for i in range(n)]
    return ema(dx,w), dp, dm
def stoch(h,l,c,w=14):
    return [((c[i]-min(l[i-w+1:i+1]))/(max(h[i-w+1:i+1])-min(l[i-w+1:i+1]))*100
             if i>=w-1 and max(h[i-w+1:i+1])>min(l[i-w+1:i+1]) else None) for i in range(len(c))]
def cci(h,l,c,w=20):
    tp=[(h[i]+l[i]+c[i])/3 for i in range(len(c))]; out=[None]*len(c)
    for i in range(w-1,len(c)):
        win=tp[i-w+1:i+1]; m=sum(win)/w; md=sum(abs(v-m) for v in win)/w
        out[i]=(tp[i]-m)/(0.015*md) if md else 0
    return out
def std(x,w): return [ (sum((v-sum(x[i-w+1:i+1])/w)**2 for v in x[i-w+1:i+1])/w)**0.5 if i>=w-1 else None for i in range(len(x))]

def all_indicators(rows):
    h=[r[1] for r in rows]; l=[r[2] for r in rows]; c=[r[3] for r in rows]; n=len(c)
    I={}
    pct=lambda a,b: (a/b-1)*100 if (a is not None and b) else None
    for w in (20,50,100,200):
        m=sma(c,w); I[f"Abstand SMA{w} %"]=[pct(c[i],m[i]) for i in range(n)]
        I[f"SMA{w} Steigung 10d %"]=[pct(m[i],m[i-10]) if i>=10 and m[i] and m[i-10] else None for i in range(n)]
    for w in (12,26,50):
        e=ema(c,w); I[f"Abstand EMA{w} %"]=[pct(c[i],e[i]) for i in range(n)]
    m50,m200=sma(c,50),sma(c,200); I["SMA50 minus SMA200 %"]=[pct(m50[i],m200[i]) for i in range(n)]
    e12,e26=ema(c,12),ema(c,26); macd=[e12[i]-e26[i] for i in range(n)]; sig=ema(macd,9)
    I["MACD % vom Kurs"]=[macd[i]/c[i]*100 for i in range(n)]; I["MACD-Histogramm % vom Kurs"]=[(macd[i]-sig[i])/c[i]*100 for i in range(n)]
    for w in (7,14,21): I[f"RSI{w}"]=rsi(c,w)
    I["Stochastik 14"]=stoch(h,l,c,14); I["Williams %R 14"]=[(-100+v) if v is not None else None for v in I["Stochastik 14"]]
    I["CCI 20"]=cci(h,l,c,20)
    for w in (5,10,20,60): I[f"ROC {w}d %"]=[pct(c[i],c[i-w]) if i>=w else None for i in range(n)]
    a14=atr(h,l,c,14); I["ATR14 % vom Kurs"]=[a14[i]/c[i]*100 for i in range(n)]
    ax,dp,dm=adx(h,l,c,14); I["ADX 14"]=ax; I["DI+ minus DI-"]=[dp[i]-dm[i] for i in range(n)]
    s20=std(c,20); m20=sma(c,20)
    I["Bollinger %B (20,2)"]=[((c[i]-(m20[i]-2*s20[i]))/(4*s20[i])*100 if s20[i] else None) if i>=19 else None for i in range(n)]
    I["Bollinger Breite %"]=[(4*s20[i]/m20[i]*100) if i>=19 else None for i in range(n)]
    I["Z-Score zu SMA20"]=[((c[i]-m20[i])/s20[i]) if i>=19 and s20[i] else None for i in range(n)]
    rets=[None]+[math.log(c[i]/c[i-1]) for i in range(1,n)]
    I["Volatilitaet 20d %"]=[ (st_(rets[i-19:i+1])*math.sqrt(365)*100) if i>=20 else None for i in range(n)]
    for w in (20,55):
        I[f"Donchian-Position {w}d"]=[((c[i]-min(l[i-w+1:i+1]))/(max(h[i-w+1:i+1])-min(l[i-w+1:i+1]))*100 if i>=w-1 and max(h[i-w+1:i+1])>min(l[i-w+1:i+1]) else None) for i in range(n)]
    I["Abstand 60d-Hoch %"]=[(c[i]/max(h[max(0,i-59):i+1])-1)*100 for i in range(n)]
    I["Abstand 60d-Tief %"]=[(c[i]/min(l[max(0,i-59):i+1])-1)*100 for i in range(n)]
    # Ichimoku (9/26/52) ohne Verschiebung
    def mid(w): return [ (max(h[i-w+1:i+1])+min(l[i-w+1:i+1]))/2 if i>=w-1 else None for i in range(n)]
    ten,kij=mid(9),mid(26); I["Ichimoku Tenkan-Kijun %"]=[pct(ten[i],kij[i]) if ten[i] and kij[i] else None for i in range(n)]
    spanA=[(ten[i]+kij[i])/2 if ten[i] and kij[i] else None for i in range(n)]; spanB=mid(52)
    I["Ichimoku Abstand Wolke %"]=[pct(c[i],(spanA[i]+spanB[i])/2) if spanA[i] and spanB[i] else None for i in range(n)]
    up=[(i>=25 and (25 - (i-max(range(i-25,i+1), key=lambda k:h[k])))/25*100) for i in range(n)]
    dn=[(i>=25 and (25 - (i-min(range(i-25,i+1), key=lambda k:l[k])))/25*100) for i in range(n)]
    I["Aroon Osz. 25"]=[(up[i]-dn[i]) if i>=25 else None for i in range(n)]
    I["Tage seit 60d-Hoch"]=[ (i-max(range(max(0,i-59),i+1), key=lambda k:h[k])) for i in range(n)]
    return I
def st_(v):
    m=sum(v)/len(v); return (sum((x-m)**2 for x in v)/len(v))**0.5
